`timescale 1ns/1ps
`default_nettype none
module control_clock_reference(input wire fixture_load,input wire [31:0] fixture_state,
 input wire base,input wire [8:0] controls,output wire [31:0] state_q,
 output wire [8:0] clocks,output wire [4:0] enables,output wire [14:0] signals);
 wire n0; // AlwaysSH
 wire n1; // CLK.ca'
 wire n2; // CLKEnable'a
 wire n3; // CLKEnable'b
 wire n4; // CLKEnable'c
 wire n5; // CPAddr.0'
 wire n6; // CPStrb'
 wire n7; // CRamClock
 wire n8; // ClearMemStop
 wire n9; // ContA02.sil+1
 wire n10; // ContA27.sil+1
 wire n11; // ContA27.sil+2
 wire n12; // ContA28.sil+7
 wire n13; // ContA30.sil+1
 wire n14; // ContA31.sil+1
 wire n15; // ContA31.sil+2
 wire n16; // ContA31.sil+3
 wire n17; // ContA31.sil+4
 wire n18; // ContA31.sil+5
 wire n19; // Error'
 wire n20; // Freeze
 wire n21; // FreezeAC
 wire n22; // FreezeBD
 wire n23; // GND264
 wire n24; // GND266
 wire n25; // GND312
 wire n26; // GND394
 wire n27; // GND396
 wire n28; // GND398
 wire n29; // GND444
 wire n30; // GND530
 wire n31; // GND544
 wire n32; // GetTLink
 wire n33; // GetTLink'
 wire n34; // MemClkEnable'a
 wire n35; // MemClkEnable'b
 wire n36; // MemSH
 wire n37; // MemSH'
 wire n38; // NoDispatch
 wire n39; // Phase0
 wire n40; // Phase0'
 wire n41; // Phase1
 wire n42; // Phase2
 wire n43; // Phase2'
 wire n44; // Phase3
 wire n45; // Phase3'
 wire n46; // Phase4
 wire n47; // Phase4'
 wire n48; // RWTPCorRWIM
 wire n49; // Run'
 wire n50; // RunClk'a
 wire n51; // RunClk'b
 wire n52; // RunRefresh
 wire n53; // RunRefresh'
 wire n54; // SC&NoFreeze
 wire n55; // SC&NoFreeze'
 wire n56; // SCorFreezea
 wire n57; // SCorFreezeb
 wire n58; // SetRun
 wire n59; // SetRun'
 wire n60; // SetRunRfsh
 wire n61; // SetSS'
 wire n62; // StartCycle
 wire n63; // StartCycle'
 wire n64; // StartCycle'a
 wire n65; // Stop
 wire n66; // StopAtT1
 wire n67; // StopAtT1'
 wire n68; // StopRunClock
 wire n69; // TPCIclk'a
 wire n70; // TPCIclk'b
 wire n71; // TPCIclk'c
 wire n72; // TrueAC
 wire n73; // TrueBD
 wire n74; // UseDMD
 wire n75; // WIM'
 wire n76; // WantRunRfsh
 wire n77; // bCLKEnable'a
 wire n78; // bCLKEnable'b
 wire n79; // bCLKEnable'c
 wire n80; // bCLKEnable'd
 wire n81; // bCLKEnable'e
 wire n82; // bCLKEnable'f
 wire n83; // bpreStartC'a
 wire n84; // bpreStartC'b
 wire n85; // bpreStartC'c
 wire n86; // clk2'Ba
 wire n87; // clk2'Bb
 wire n88; // clk2'Bc
 wire n89; // clk2'Bd
 wire n90; // clk2'Be
 wire n91; // clk2'Bf
 wire n92; // dMemRun
 wire n93; // dRun
 wire n94; // dStartCycle
 wire n95; // dStop
 wire n96; // preCRamClock
 wire n97; // preFH'
 wire n98; // preRunClk'Ba
 wire n99; // preRunClk'Bb
 wire n100; // preRunClk'Bc
 wire n101; // preStartCyclea
 wire n102; // preclk1'Aa
 wire n103; // preclk1'Ca
 wire n104; // preclk1'Da
 wire n105; // preclk2'Aa
 wire n106; // preclk2'Ba
 wire n107; // preclk2'Bb
 wire n108; // preclk2'Bc
 wire n109; // preclk2'Bd
 wire n110; // preclk2'Ca
 wire n111; // preclk2'Da
 wire n112; // prepreclk'a
 wire n113; // prepreclk'b
 wire n114; // prepreclk'c
 wire n115; // prepreclk'd
 wire n116; // prepreclk'e
 wire n117; // rStop
 wire n118; // sPhase0
 assign n23=1'b0;
 assign n24=1'b0;
 assign n25=1'b0;
 assign n26=1'b0;
 assign n27=1'b0;
 assign n28=1'b0;
 assign n29=1'b0;
 assign n30=1'b0;
 assign n31=1'b0;
 assign n1=base;
 assign n5=1'b1;
 assign n6=1'b1;
 assign n12=1'b0;
 assign n13=1'b0;
 assign n19=controls[3];
 assign n32=1'b0;
 assign n38=controls[0];
 assign n48=controls[1];
 assign n58=controls[6];
 assign n60=controls[4];
 assign n61=controls[5];
 assign n66=controls[2];
 assign n75=controls[8];
 assign n117=controls[7];
 wire n0_l05_3;
 assign n0=n0_l05_3;
 wire n2_k02_15;
 wire n2_k01_14;
 assign n2=n2_k02_15 | n2_k01_14;
 wire n3_k02_2;
 wire n3_k01_3;
 assign n3=n3_k02_2 | n3_k01_3;
 wire n4_l02_14;
 wire n4_l02_2;
 assign n4=n4_l02_14 | n4_l02_2;
 wire n7_j01_3;
 assign n7=n7_j01_3;
 wire n8_h03_3;
 assign n8=n8_h03_3;
 wire n9_h03_14;
 assign n9=n9_h03_14;
 wire n10_j05_2;
 assign n10=n10_j05_2;
 wire n11_i04_3;
 assign n11=n11_i04_3;
 wire n14_i03_14;
 assign n14=n14_i03_14;
 wire n15_i03_13;
 assign n15=n15_i03_13;
 wire n16_i03_2;
 assign n16=n16_i03_2;
 wire n17_i03_3;
 assign n17=n17_i03_3;
 wire n18_i03_4;
 assign n18=n18_i03_4;
 wire n20_i07_14;
 assign n20=n20_i07_14;
 wire n21_i07_13;
 assign n21=n21_i07_13;
 wire n22_i07_12;
 assign n22=n22_i07_12;
 wire n33_g05_15;
 assign n33=n33_g05_15;
 wire n34_l04_15;
 wire n34_l03_14;
 assign n34=n34_l04_15 | n34_l03_14;
 wire n35_l04_2;
 wire n35_l03_3;
 assign n35=n35_l04_2 | n35_l03_3;
 wire n36_k03_3;
 assign n36=n36_k03_3;
 wire n37_k03_2;
 assign n37=n37_k03_2;
 wire n39_l07_15;
 assign n39=n39_l07_15;
 wire n40_l07_14;
 assign n40=n40_l07_14;
 wire n41_l07_2;
 assign n41=n41_l07_2;
 wire n42_k05_15;
 assign n42=n42_k05_15;
 wire n43_k05_14;
 assign n43=n43_k05_14;
 wire n44_k05_2;
 assign n44=n44_k05_2;
 wire n45_k05_3;
 assign n45=n45_k05_3;
 wire n46_j01_15;
 assign n46=n46_j01_15;
 wire n47_j01_14;
 assign n47=n47_j01_14;
 wire n49_j04_14;
 assign n49=n49_j04_14;
 wire n50_i06_3;
 assign n50=n50_i06_3;
 wire n51_i06_2;
 assign n51=n51_i06_2;
 wire n52_l06_15;
 assign n52=n52_l06_15;
 wire n53_l06_14;
 assign n53=n53_l06_14;
 wire n54_k04_2;
 assign n54=n54_k04_2;
 wire n55_k04_3;
 assign n55=n55_k04_3;
 wire n56_i06_13;
 assign n56=n56_i06_13;
 wire n57_i06_12;
 assign n57=n57_i06_12;
 wire n59_g05_3;
 assign n59=n59_g05_3;
 wire n62_k04_15;
 assign n62=n62_k04_15;
 wire n63_k04_14;
 assign n63=n63_k04_14;
 wire n64_k03_14;
 assign n64=n64_k03_14;
 wire n65_j04_2;
 assign n65=n65_j04_2;
 wire n67_g05_2;
 assign n67=n67_g05_2;
 wire n68_l05_2;
 assign n68=n68_l05_2;
 wire n69_j06_13;
 assign n69=n69_j06_13;
 wire n70_j06_12;
 assign n70=n70_j06_12;
 wire n71_j06_14;
 assign n71=n71_j06_14;
 wire n72_g05_13;
 assign n72=n72_g05_13;
 wire n73_g05_4;
 assign n73=n73_g05_4;
 wire n74_i04_15;
 assign n74=n74_i04_15;
 wire n76_l05_15;
 assign n76=n76_l05_15;
 wire n77_i05_3;
 assign n77=n77_i05_3;
 wire n78_i05_2;
 assign n78=n78_i05_2;
 wire n79_i05_4;
 assign n79=n79_i05_4;
 wire n80_i05_13;
 assign n80=n80_i05_13;
 wire n81_i05_12;
 assign n81=n81_i05_12;
 wire n82_i05_14;
 assign n82=n82_i05_14;
 wire n83_l08_3;
 assign n83=n83_l08_3;
 wire n84_l08_4;
 assign n84=n84_l08_4;
 wire n85_l08_2;
 assign n85=n85_l08_2;
 wire n86_j06_3;
 assign n86=n86_j06_3;
 wire n87_j06_2;
 assign n87=n87_j06_2;
 wire n88_j06_4;
 assign n88=n88_j06_4;
 wire n89_i07_3;
 assign n89=n89_i07_3;
 wire n90_i07_2;
 assign n90=n90_i07_2;
 wire n91_i07_4;
 assign n91=n91_i07_4;
 wire n92_g04_15;
 wire n92_h03_2;
 assign n92=n92_g04_15 | n92_h03_2;
 wire n93_i03_15;
 assign n93=n93_i03_15;
 wire n94_j05_3;
 assign n94=n94_j05_3;
 wire n95_i04_2;
 wire n95_j05_14;
 assign n95=n95_i04_2 | n95_j05_14;
 wire n96_g12_4;
 assign n96=n96_g12_4;
 wire n97_l06_3;
 assign n97=n97_l06_3;
 wire n98_f13_13;
 assign n98=n98_f13_13;
 wire n99_f13_12;
 assign n99=n99_f13_12;
 wire n100_f13_14;
 assign n100=n100_f13_14;
 wire n101_k03_15;
 assign n101=n101_k03_15;
 wire n102_f13_3;
 assign n102=n102_f13_3;
 wire n103_f13_2;
 assign n103=n103_f13_2;
 wire n104_f13_4;
 assign n104=n104_f13_4;
 wire n105_f12_3;
 assign n105=n105_f12_3;
 wire n106_f12_13;
 assign n106=n106_f12_13;
 wire n107_f12_12;
 assign n107=n107_f12_12;
 wire n108_f12_14;
 assign n108=n108_f12_14;
 wire n109_g12_14;
 assign n109=n109_g12_14;
 wire n110_f12_2;
 assign n110=n110_f12_2;
 wire n111_f12_4;
 assign n111=n111_f12_4;
 wire n112_l01_13;
 assign n112=n112_l01_13;
 wire n113_l01_12;
 assign n113=n113_l01_12;
 wire n114_l01_14;
 assign n114=n114_l01_14;
 wire n115_l01_3;
 assign n115=n115_l01_3;
 wire n116_l01_2;
 assign n116=n116_l01_2;
 wire n118_i04_14;
 assign n118=n118_i04_14;
 cell_SE10210 f12(.p2(n110_f12_2),.p3(n105_f12_3),.p4(n111_f12_4),.p5(n114),.p6(1'b0),.p7(n79),.p8(1'b0),.p9(n79),.p10(1'b0),.p11(n114),.p12(n107_f12_12),.p13(n106_f12_13),.p14(n108_f12_14),.p15(n23),.p16(1'b0));
 cell_SE10210 f13(.p2(n103_f13_2),.p3(n102_f13_3),.p4(n104_f13_4),.p5(n97),.p6(n112),.p7(n77),.p8(1'b0),.p9(1'b0),.p10(n68),.p11(n112),.p12(n99_f13_12),.p13(n98_f13_13),.p14(n100_f13_14),.p15(n24),.p16(1'b0));
 cell_MC10104 g04(.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(n76),.p13(n53),.p15(n92_g04_15),.p16(1'b0));
 cell_MC10195 g05(.p2(n67_g05_2),.p3(n59_g05_3),.p4(n73_g05_4),.p5(n66),.p6(n58),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p12(n32),.p13(n72_g05_13),.p15(n33_g05_15));
 cell_SE10212 g12(.p1(1'b0),.p4(n96_g12_4),.p5(n82),.p6(1'b0),.p7(n116),.p8(1'b0),.p9(n116),.p10(1'b0),.p11(n82),.p14(n109_g12_14),.p15(n25),.p16(1'b0));
 cell_MC10103 h03(.p1(1'b0),.p2(n92_h03_2),.p3(n8_h03_3),.p4(n93),.p5(1'b0),.p6(n117),.p7(n52),.p10(n5),.p11(n6),.p12(1'b0),.p13(1'b0),.p14(n9_h03_14),.p16(1'b0));
 original_MC10176 i03(.p1(1'b0),.p2(n16_i03_2),.p3(n17_i03_3),.p4(n18_i03_4),.p5(n61),.p6(n16),.p7(n17),.p8(1'b0),.p9(n51),.p10(n58),.p11(n15),.p12(n14),.p13(n15_i03_13),.p14(n14_i03_14),.p15(n93_i03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 cell_MC10104 i04(.p2(n95_i04_2),.p3(n11_i04_3),.p4(n39),.p5(n66),.p6(n10),.p7(n39),.p10(n67),.p11(n81),.p12(n12),.p13(n58),.p14(n118_i04_14),.p15(n74_i04_15),.p16(1'b0));
 cell_MC10210 i05(.p1(1'b0),.p2(n78_i05_2),.p3(n77_i05_3),.p4(n79_i05_4),.p5(n65),.p6(n49),.p7(1'b0),.p8(1'b0),.p9(n49),.p10(1'b0),.p11(n65),.p12(n81_i05_12),.p13(n80_i05_13),.p14(n82_i05_14),.p15(n26),.p16(1'b0));
 cell_SE10210 i06(.p2(n51_i06_2),.p3(n50_i06_3),.p5(1'b0),.p6(1'b0),.p7(n98),.p8(1'b0),.p9(1'b0),.p10(n22),.p11(n101),.p12(n57_i06_12),.p13(n56_i06_13),.p15(n27),.p16(1'b0));
 cell_SE10210 i07(.p2(n90_i07_2),.p3(n89_i07_3),.p4(n91_i07_4),.p5(1'b0),.p6(1'b0),.p7(n109),.p8(1'b0),.p9(n38),.p10(1'b0),.p11(1'b0),.p12(n22_i07_12),.p13(n21_i07_13),.p14(n20_i07_14),.p15(n28),.p16(1'b0));
 original_MC10231 j01(.p1(1'b0),.p3(n7_j01_3),.p4(1'b0),.p5(n75),.p6(n96),.p7(n43),.p8(1'b0),.p9(1'b0),.p10(n44),.p11(n88),.p12(1'b0),.p13(n118),.p14(n47_j01_14),.p15(n46_j01_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:2]),.state_q(state_q[30+:2]));
 original_MC10231 j04(.p1(1'b0),.p2(n65_j04_2),.p4(n117),.p5(1'b0),.p6(n88),.p7(n95),.p8(1'b0),.p9(1'b0),.p10(n93),.p11(n50),.p12(1'b0),.p13(1'b0),.p14(n49_j04_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:2]),.state_q(state_q[6+:2]));
 cell_MC10117 j05(.p2(n10_j05_2),.p3(n94_j05_3),.p4(n48),.p5(n40),.p6(1'b0),.p7(n47),.p9(1'b0),.p10(n84),.p11(n18),.p12(n84),.p13(n19),.p14(n95_j05_14));
 cell_SE10210 j06(.p2(n87_j06_2),.p3(n86_j06_3),.p4(n88_j06_4),.p5(1'b0),.p6(n106),.p7(1'b0),.p8(1'b0),.p9(n106),.p10(1'b0),.p11(n13),.p12(n70_j06_12),.p13(n69_j06_13),.p14(n71_j06_14),.p15(n29),.p16(1'b0));
 original_MC10231 k01(.p1(1'b0),.p3(n3_k01_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n93),.p8(1'b0),.p9(n99),.p10(n93),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n2_k01_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:2]),.state_q(state_q[8+:2]));
 original_MC10231 k02(.p1(1'b0),.p2(n3_k02_2),.p4(n117),.p5(1'b0),.p6(1'b0),.p7(n95),.p8(1'b0),.p9(n107),.p10(n95),.p11(1'b0),.p12(1'b0),.p13(n117),.p15(n2_k02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[10+:2]),.state_q(state_q[10+:2]));
 original_MC10231 k03(.p1(1'b0),.p2(n37_k03_2),.p3(n36_k03_3),.p4(1'b0),.p5(1'b0),.p6(n115),.p7(n0),.p8(1'b0),.p9(1'b0),.p10(n94),.p11(n107),.p12(1'b0),.p13(n118),.p14(n64_k03_14),.p15(n101_k03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[22+:2]),.state_q(state_q[22+:2]));
 original_MC10231 k04(.p1(1'b0),.p2(n54_k04_2),.p3(n55_k04_3),.p4(n118),.p5(1'b0),.p6(n22),.p7(n94),.p8(1'b0),.p9(n90),.p10(n94),.p11(1'b0),.p12(1'b0),.p13(n118),.p14(n63_k04_14),.p15(n62_k04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[24+:2]),.state_q(state_q[24+:2]));
 original_MC10231 k05(.p1(1'b0),.p2(n44_k05_2),.p3(n45_k05_3),.p4(n118),.p5(1'b0),.p6(1'b0),.p7(n42),.p8(1'b0),.p9(n90),.p10(n41),.p11(1'b0),.p12(1'b0),.p13(n118),.p14(n43_k05_14),.p15(n42_k05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:2]),.state_q(state_q[26+:2]));
 cell_SE10210 l01(.p2(n116_l01_2),.p3(n115_l01_3),.p5(1'b0),.p6(1'b0),.p7(n1),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n1),.p12(n113_l01_12),.p13(n112_l01_13),.p14(n114_l01_14),.p15(n30),.p16(1'b0));
 original_MC10231 l02(.p1(1'b0),.p2(n4_l02_2),.p4(n117),.p5(1'b0),.p6(n108),.p7(n95),.p8(1'b0),.p9(1'b0),.p10(n93),.p11(n100),.p12(1'b0),.p13(1'b0),.p14(n4_l02_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:2]),.state_q(state_q[12+:2]));
 original_MC10231 l03(.p1(1'b0),.p3(n35_l03_3),.p4(1'b0),.p5(n52),.p6(1'b0),.p7(n92),.p8(1'b0),.p9(n100),.p10(n92),.p11(1'b0),.p12(n52),.p13(1'b0),.p14(n34_l03_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[14+:2]),.state_q(state_q[14+:2]));
 original_MC10231 l04(.p1(1'b0),.p2(n35_l04_2),.p4(n8),.p5(1'b0),.p6(1'b0),.p7(n95),.p8(1'b0),.p9(n107),.p10(n95),.p11(1'b0),.p12(1'b0),.p13(n8),.p15(n34_l04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:2]),.state_q(state_q[16+:2]));
 original_MC10231 l05(.p1(1'b0),.p2(n68_l05_2),.p3(n0_l05_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n0),.p8(1'b0),.p9(n115),.p10(n60),.p11(n68),.p12(1'b0),.p13(1'b0),.p15(n76_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[18+:2]),.state_q(state_q[18+:2]));
 original_SE10231 l06(.p3(n97_l06_3),.p6(n80),.p7(n101),.p9(n115),.p10(n76),.p11(n68),.p13(1'b0),.p14(n53_l06_14),.p15(n52_l06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:2]),.state_q(state_q[20+:2]));
 original_MC10231 l07(.p1(1'b0),.p2(n41_l07_2),.p4(n118),.p5(1'b0),.p6(1'b0),.p7(n11),.p8(1'b0),.p9(n91),.p10(n62),.p11(1'b0),.p12(n118),.p13(1'b0),.p14(n40_l07_14),.p15(n39_l07_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[28+:2]),.state_q(state_q[28+:2]));
 cell_MC10211 l08(.p2(n85_l08_2),.p3(n83_l08_3),.p4(n84_l08_4),.p5(1'b0),.p6(n101),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n31),.p16(1'b0));
 assign clocks[0]=n115;
 assign clocks[1]=n68;
 assign clocks[2]=n100;
 assign clocks[3]=n50;
 assign clocks[4]=n107;
 assign clocks[5]=n88;
 assign clocks[6]=n115 | n80;
 assign clocks[7]=n90 | n22;
 assign clocks[8]=n96;
 assign enables[0]=n2;
 assign enables[1]=n3;
 assign enables[2]=n4;
 assign enables[3]=n34;
 assign enables[4]=n35;
 assign signals[0]=n95;
 assign signals[1]=n92;
 assign signals[2]=n8;
 assign signals[3]=n94;
 assign signals[4]=n118;
 assign signals[5]=n62;
 assign signals[6]=n101;
 assign signals[7]=n39;
 assign signals[8]=n41;
 assign signals[9]=n42;
 assign signals[10]=n44;
 assign signals[11]=n46;
 assign signals[12]=n36;
 assign signals[13]=n7;
 assign signals[14]=n54;
endmodule
`default_nettype wire
