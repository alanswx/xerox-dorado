module clock_fit(input wire host_clk,input wire [51:0] pins,
 output reg [50:0] result);
 reg [51:0] launch;
 always @(posedge host_clk) launch<=pins;
 wire [31:0] q,next_q;
 wire before_clock,after_clock;
 wire [8:0] before_controls,after_controls,events,repeated;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls}=launch;
 dorado_control_clock_step evaluator(q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled};
endmodule
