project_open clock_fit
create_timing_netlist -model slow
set corners {}
foreach_in_collection op [get_available_operating_conditions] {
 lappend corners [get_operating_conditions_info $op -name]
}
delete_timing_netlist
if {[llength $corners]!=4} {error "Expected four conditions: $corners"}
foreach name $corners {
 create_timing_netlist
 set_operating_conditions $name
 read_sdc
 update_timing_netlist
 puts "CONTROL_CLOCK_CORNER $name"
 foreach mode {setup hold recovery removal} {
  report_timing -$mode -npaths 10 -detail full_path -file clock-$mode-$name.rpt
 }
 report_timing -setup -from [get_registers {launch[*]}] -to [get_registers {result[*]}] -npaths 10 -detail full_path -file clock-evaluator-$name.rpt
 report_min_pulse_width -file clock-mpw-$name.rpt
 report_clocks -file clock-clocks-$name.rpt
 report_ucp -file clock-ucp-$name.rpt
 delete_timing_netlist
}
project_close
