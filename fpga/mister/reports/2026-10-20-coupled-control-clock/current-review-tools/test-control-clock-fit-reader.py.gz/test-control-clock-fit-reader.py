from pathlib import Path
import json,hashlib,importlib.util,argparse
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('qualified',type=Path);p.add_argument('--reader',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
s=importlib.util.spec_from_file_location('fit_audit',a.reader);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
root=a.root;qualified=a.qualified;base=m.audit(root,qualified,False);results=[]
def check(name,edits,rehash=None):
 paths=set(edits)
 if rehash:paths.update(['provenance.json','collected-input-check.json'])
 saved={n:(root/n).read_bytes()for n in paths}
 try:
  for n,value in edits.items():
   if value is None:(root/n).unlink()
   else:(root/n).write_bytes(value)
  if rehash:
   x=json.loads((root/'provenance.json').read_text());y=json.loads((root/'collected-input-check.json').read_text());h=hashlib.sha256((root/rehash).read_bytes()).hexdigest();x['files'][rehash]=h;y['actual'][rehash]=h
   (root/'provenance.json').write_text(json.dumps(x));(root/'collected-input-check.json').write_text(json.dumps(y))
  try:m.audit(root,qualified,False)
  except (AssertionError,FileNotFoundError):results.append(dict(case=name,rejected=True))
  else:raise AssertionError('bad evidence accepted: '+name)
 finally:
  for n,raw in saved.items():(root/n).write_bytes(raw)
corner='7_slow_1100mv_-40c'
n='clock-setup-MIN_fast_1100mv_-40c.rpt';check('missing_corner',{n:None})
n='clock-evaluator-'+corner+'.rpt';check('missing_evaluator_coverage',{n:None})
n='clock-ucp-'+corner+'.rpt';raw=(root/n).read_bytes();bad=raw.replace(b'; Illegal Clocks                  ; 0',b'; Illegal Clocks                  ; 1',1);assert bad!=raw;check('illegal_clock',{n:bad})
n='clock-setup-'+corner+'.rpt';raw=(root/n).read_bytes();old=b'Worst case slack is '+str(base['conditions'][1]['setup']).encode();assert old in raw;check('spoof_slack_header',{n:raw.replace(old,b'Worst case slack is 100.000',1)})
n='clock.sdc';raw=(root/n).read_bytes();check('rehashed_wrong_period',{n:raw.replace(b'period 15.000',b'period 30.000')},n)
check('rehashed_false_cut',{n:raw+b'\nset_false_path -from [all_registers] -to [all_registers]\n'},n)
n='dorado_control_clock_step.sv';check('rehashed_unqualified_source',{n:(root/n).read_bytes()+b'\n// altered\n'},n)
assert m.audit(root,qualified,False)==base
record=dict(status='PASS_CONTROL_CLOCK_FIT_READER_CONTROLS',cases=results,reader_sha256=hashlib.sha256(a.reader.read_bytes()).hexdigest(),original_status=base['status'])
a.output.write_text(json.dumps(record,indent=2)+'\n');print(record['status'],len(results),'bad variants rejected;original bytes restored')
