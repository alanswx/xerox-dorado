module clock_fit(input wire host_clk,input wire [1042:0] pins,
 output reg [846:0] result);
 // Fixture input staging avoids treating a virtual package pin as the
 // evaluator's launch register. The evaluator still has a full 15ns path
 // from launch to result; the new staging path has a stricter half period.
 reg [1042:0] input_stage;
 reg [1042:0] launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [635:0] q,next_q;
 wire before_clock,after_clock;
 wire [201:0] before_controls,after_controls;
 wire [44:0] events,repeated;
 wire [1:0] write_n,latch_n,t_latch_n,bypass;
 wire [3:0] parity_ok,faults,r_flags;
 wire [1:0] r_read_n,r_visible_n;wire [1:0] rm_flags_n;wire [31:0] address;wire [3:0] select_n;wire [1:0] forwarded_bypass,r_write_n,file_read_parity;wire [15:0] file_read_data;wire [31:0] port_address;wire [3:0] port_select_n;wire advance;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls,advance}=launch;
 dorado_r_memory_step evaluator(host_clk,advance,q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,address,select_n,forwarded_bypass,r_write_n,port_address,port_select_n,file_read_data,file_read_parity);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,address,select_n,forwarded_bypass,r_write_n,port_address,port_select_n,file_read_data,file_read_parity};
endmodule
