project_open clock_fit
create_timing_netlist -model slow
set corners {}
foreach_in_collection op [get_available_operating_conditions] {
 lappend corners [get_operating_conditions_info $op -name]
}
delete_timing_netlist
if {[llength $corners]!=4} {error "Expected four conditions: $corners"}
foreach name $corners {
 create_timing_netlist
 set_operating_conditions $name
 read_sdc
 update_timing_netlist
 puts "CONTROL_CLOCK_CORNER $name"
 foreach mode {setup hold recovery removal} {
  report_timing -$mode -npaths 10 -detail full_path -file clock-$mode-$name.rpt
 }
 set launches [get_registers {*launch*}]
 set results [get_registers {*result*}]
 if {[get_collection_size $launches]==0 || [get_collection_size $results]==0} {error "Missing launch/result register coverage"}
 puts "CONTROL_CLOCK_REGISTER_COVERAGE launch=[get_collection_size $launches] result=[get_collection_size $results]"
 report_timing -setup -from $launches -to $results -npaths 10 -detail full_path -file clock-evaluator-$name.rpt
 report_min_pulse_width -file clock-mpw-$name.rpt
 report_clocks -file clock-clocks-$name.rpt
 report_ucp -file clock-ucp-$name.rpt
 delete_timing_netlist
}
project_close
