`timescale 1ns/1ps
`default_nettype none
module tb_r_memory_control;
 localparam [201:0] SEED=(202'h1<<143)|(202'h1<<144)|202'h128|
   (202'h1<<66)|(202'h1<<67)|(202'h7fff<<50)|(202'h1<<177)|(202'h1<<178)|
   (202'h1<<186)|(202'h1<<187)|(202'h1<<196)|(202'h1<<197);
 reg [635:0] q=0,fixture=0;
 reg cb=1,ca=1,load=0,root=1,monitor=0;
 reg [201:0] pb=SEED,pa=SEED,rp=SEED;
 reg host_clk=0,advance=1;
 reg [9215:0] fixture_memory=0;
 wire [9215:0] reference_memory;
 wire [15:0] raw_data,ref_raw_data;
 wire [1:0] raw_parity,ref_raw_parity,generated_parity,rwrite;
 wire [31:0] port_address;
 wire [3:0] port_select;
 wire [1:0] ref_rwrite={original.l.j05.p13,original.h.j05.p13};
 wire [201:0] reference_pins={rp[201:145],ref_raw_parity,ref_raw_data,rp[126:0]};
 wire [635:0] n,reference;
 wire [44:0] events,repeated,clocks;
 wire unsettled;
 wire [1:0] wn,ln,tln,bp,rr,rv,rf_n,forwarded;
 wire [3:0] ok,fault,rf,select_n;
 wire [31:0] address;
 wire [1:0] rwn,rln,rtln,rbp,rrr,rrv,rrf_n,rforwarded,hold_clocks,parity_clocks;
 wire [3:0] rok,rfault,rrf,rselect,next_raw;
 wire [31:0] raddress;
 wire [8:0] flags;
 dorado_r_memory_step dut(host_clk,advance,q,cb,ca,pb,pa,n,events,repeated,unsettled,
   wn,ln,tln,bp,ok,fault,rr,rv,rf,rf_n,address,select_n,forwarded,rwrite,
   port_address,port_select,raw_data,raw_parity);
 r_address_reference original(load,fixture,root,reference_pins,reference,clocks,flags,next_raw,
   rwn,rln,hold_clocks,rtln,rbp,parity_clocks,rok,rfault,rrr,rrv,rrf,rrf_n,
   raddress,rselect,rforwarded);
 r_file_ports_reference original_files(load,fixture_memory,1'b1,ref_rwrite,
   raddress,rselect,reference[555:540],ref_raw_data,ref_raw_parity,reference_memory,generated_parity);
 function automatic [9215:0] memory_image();
   reg [9215:0] image;
   begin
     for(integer i=0;i<256;i=i+1) begin
       image[4*i+:4]=dut.files.rm_h[i][3:0];image[1024+4*i+:4]=dut.files.rm_h[i][7:4];
       image[2048+4*i+:4]=dut.files.stk_h[i][3:0];image[3072+4*i+:4]=dut.files.stk_h[i][7:4];
       image[4096+i]=dut.files.rm_h[i][8];image[4352+i]=dut.files.stk_h[i][8];
       image[4608+4*i+:4]=dut.files.rm_l[i][3:0];image[5632+4*i+:4]=dut.files.rm_l[i][7:4];
       image[6656+4*i+:4]=dut.files.stk_l[i][3:0];image[7680+4*i+:4]=dut.files.stk_l[i][7:4];
       image[8704+i]=dut.files.rm_l[i][8];image[8960+i]=dut.files.stk_l[i][8];
     end
     memory_image=image;
   end
 endfunction
 integer writes=0,reads=0,capture_epoch_changes=0;
 integer write_windows[0:1],write_address_changes[0:1],write_select_changes[0:1];
 reg [1:0] write_open=0;
 reg [15:0] write_address[0:1];
 reg [1:0] write_select[0:1];
 for(genvar half=0;half<2;half=half+1) begin: monitor_write_arrival
   initial begin write_windows[half]=0;write_address_changes[half]=0;write_select_changes[half]=0;end
   always @(ref_rwrite[half] or raddress[16*half+:16] or rselect[2*half+:2]) begin
     if(!monitor) write_open[half]=0;
     else if(!ref_rwrite[half]) begin
       if(write_open[half] && write_address[half]!=raddress[16*half+:16]) write_address_changes[half]=write_address_changes[half]+1;
       if(write_open[half] && write_select[half]!=rselect[2*half+:2]) write_select_changes[half]=write_select_changes[half]+1;
       if(!write_open[half]) write_windows[half]=write_windows[half]+1;
       write_open[half]=1;write_address[half]=raddress[16*half+:16];write_select[half]=rselect[2*half+:2];
     end else write_open[half]=0;
   end
 end
 integer counts[0:44],totals[0:44];
 realtime data_changed[0:7],clock_arrived[0:7];
 realtime minimum_setup=1.0e9,minimum_hold=1.0e9;
 integer setup_samples=0,hold_samples=0;
 reg [7:0] data_valid=0,clock_valid=0;
 wire [7:0] capture_data={original.l.g16.p11,original.l.g16.p10,original.l.g16.p9,original.l.g16.p7,
                          original.h.g16.p11,original.h.g16.p10,original.h.g16.p9,original.h.g16.p7};
 for(genvar input_bit=0;input_bit<8;input_bit=input_bit+1) begin: check_g16_arrivals
   always @(capture_data[input_bit]) begin
     if(monitor && clock_valid[input_bit]) begin
       if($realtime-clock_arrived[input_bit]<minimum_hold) minimum_hold=$realtime-clock_arrived[input_bit];
       hold_samples=hold_samples+1;
`ifdef PARC_PARITY_TIMING
       if($realtime-clock_arrived[input_bit]<1.1-0.0001) $fatal(1,"PARC g16 hold violation pin=%0d margin=%0.3f",input_bit,$realtime-clock_arrived[input_bit]);
`endif
     end
     data_changed[input_bit]=$realtime;data_valid[input_bit]=1;
   end
   always @(posedge parity_clocks[input_bit/4]) begin
     if(monitor && data_valid[input_bit]) begin
       if($realtime-data_changed[input_bit]<minimum_setup) minimum_setup=$realtime-data_changed[input_bit];
       setup_samples=setup_samples+1;
`ifdef PARC_PARITY_TIMING
       if($realtime-data_changed[input_bit]<1.7-0.0001) $fatal(1,"PARC g16 setup violation pin=%0d margin=%0.3f",input_bit,$realtime-data_changed[input_bit]);
`endif
     end
     clock_arrived[input_bit]=$realtime;clock_valid[input_bit]=1;
   end
 end
 for(genvar i=0;i<45;i=i+1) begin: count_edges
   initial begin counts[i]=0;totals[i]=0;end
   always @(posedge clocks[i]) if(monitor) counts[i]=counts[i]+1;
 end
 integer checks=0,adr_moves=0,select_moves=0,forward_moves=0,transparent=0;
 reg [255:0] seen_h=0,seen_l=0,seen_hs=0,seen_ls=0;
 reg [15:0] select_seen=0;
 reg [7:0] lc_seen=0;
 reg [3:0] drivers_seen=0;
 reg [31:0] dut_address_before=0;
 reg [3:0] dut_select_before=0;
 reg [1:0] dut_forward_before=0;
 task automatic event_step(input next_root,input [201:0] pins);
   reg [635:0] expected;
   reg [44:0] predicted;
   reg [31:0] ea;
   reg [3:0] es;
   reg [1:0] ef;
   reg [19:0] eo;reg [1:0] erw;reg [9215:0] old_memory,actual_memory;
   integer previous[0:44];
   begin
     ca=next_root;pa=pins;
     #100;
     expected=n;predicted=events;ea=address;es=select_n;ef=forwarded;
     eo={wn,ln,tln,bp,ok,fault,rr,rv};erw=rwrite;
     if((rwrite|rr)!=2'b11) $fatal(1,"R memory write/read windows overlap");
     if((predicted[13]&&!rwrite[0])||(predicted[18]&&!rwrite[1]))
       $fatal(1,"R memory capture epoch overlaps write");
     if((predicted[13]&&port_address[15:0]!=address[15:0])||
        (predicted[18]&&port_address[31:16]!=address[31:16])) capture_epoch_changes=capture_epoch_changes+1;
     if((predicted[13]&&raw_parity[0]!==ref_raw_parity[0])||
        (predicted[18]&&raw_parity[1]!==ref_raw_parity[1]))
       $fatal(1,"R memory capture port lost old parity epoch");
     if(unsettled||repeated) $fatal(1,"R memory solver unsettled/repeated");
     for(integer i=0;i<45;i=i+1) previous[i]=counts[i];
     {root,rp}={next_root,pins};
     #100;
     if(ref_rwrite!==erw) $fatal(1,"R memory write gate mismatch");
     if(reference!==expected) begin
       for(integer i=0;i<636;i=i+1) if(reference[i]!==expected[i])
         $display("R_MEMORY_DIFF bit=%0d old=%b expected=%b original=%b",i,q[i],expected[i],reference[i]);
       $fatal(1,"R memory state mismatch check=%0d roots=%b->%b pins=%h q=%h expected=%h original=%h",checks,cb,ca,pins,q,expected,reference);
     end
     if(raddress!==ea||rselect!==es||rforwarded!==ef)
       $fatal(1,"R memory output mismatch check=%0d address=%h/%h selects=%h/%h bypass=%b/%b",checks,ea,raddress,es,rselect,ef,rforwarded);
     if({rwn,rln,rtln,rbp,rok,rfault,rrr,rrv}!==eo || rrf!==rf || rrf_n!==rf_n)
       $fatal(1,"R memory operand output mismatch check=%0d",checks);
     for(integer i=0;i<45;i=i+1) begin
       if(counts[i]-previous[i]!=int'(predicted[i]))
         $fatal(1,"R memory clock mismatch check=%0d channel=%0d actual=%0d expected=%0d",checks,i,counts[i]-previous[i],predicted[i]);
       totals[i]=totals[i]+counts[i]-previous[i];
     end
     if(q[635:632]!=expected[635:632]) transparent=transparent+1;
     if(ea!=raddress) $fatal(1,"R memory unstable settled output");
     if(ea!=dut_address_before) adr_moves=adr_moves+1;
     if(es!=dut_select_before) select_moves=select_moves+1;
     if(ef!=dut_forward_before) forward_moves=forward_moves+1;
     dut_address_before=ea;dut_select_before=es;dut_forward_before=ef;
     seen_h[ea[7:0]]=1;seen_hs[ea[15:8]]=1;
     seen_l[ea[23:16]]=1;seen_ls[ea[31:24]]=1;select_seen[es]=1;
     lc_seen[pins[11:9]]=1;
     drivers_seen=drivers_seen|{original.l.i19.p3,original.l.i11.p14|original.l.i11.p15,
                                |{original.l.h13.p1,original.l.h13.p2,original.l.h13.p14,original.l.h13.p15},
                                |{original.l.h12.p1,original.l.h12.p2,original.l.h12.p14,original.l.h12.p15}};
     // The reference writes throughout the original level-sensitive window.
     // A closed read window makes the candidate's end-of-window RAM commit
     // unobservable to the already captured processor state.
     old_memory=memory_image();advance=0;host_clk=1;#100;host_clk=0;#100;
     if(memory_image()!==old_memory) $fatal(1,"R memory advance hold changed RAM");
     advance=1;host_clk=1;#100;host_clk=0;#100;
     actual_memory=memory_image();
     if(actual_memory!==reference_memory) begin
       for(integer bit_no=0;bit_no<9216;bit_no=bit_no+1) if(actual_memory[bit_no]!==reference_memory[bit_no])
         $display("R_MEMORY_RAM_DIFF bit=%0d actual=%b original=%b",bit_no,actual_memory[bit_no],reference_memory[bit_no]);
       $fatal(1,"R memory storage mismatch check=%0d root=%b->%b address=%h port=%h select=%h port_select=%h write_n=%b",checks,cb,ca,address,port_address,select_n,port_select,rwrite);
     end
     if(n!==expected) $fatal(1,"R memory commit changed sampled source epoch");
     for(integer half=0;half<2;half=half+1) begin
       if(!rwrite[half]) writes=writes+1;
       if(!rr[half]) reads=reads+1;
     end
     q=expected;cb=next_root;pb=pins;#100;
     if(n!==expected) $fatal(1,"R memory state commit changed settled Q check=%0d",checks);
     if({raw_parity,raw_data}!=={ref_raw_parity,ref_raw_data}) $fatal(1,"R memory settled port mismatch");
     checks=checks+1;
   end
 endtask
 reg [31:0] rng=32'hd04ad042;
 function automatic [31:0] random_next(input [31:0] v);
   reg [31:0] x;
   begin x=v^(v<<13);x=x^(x>>17);random_next=x^(x<<5);end
 endfunction
 reg [201:0] p;
 reg [8:0] word0,word1,word2,word3;
 integer iterations=4096;
 initial begin
   if($value$plusargs("iterations=%d",iterations)) $display("R_MEMORY_ITERATIONS %0d",iterations);
   for(integer i=0;i<256;i=i+1) begin
     word0={1'b0,8'(i*23+11)};word0[8]=~^word0[7:0];
     word1={1'b0,8'(i*37+47)};word1[8]=~^word1[7:0];
     word2={1'b0,8'(i*17+71)};word2[8]=~^word2[7:0];
     word3={1'b0,8'(i*43+99)};word3[8]=~^word3[7:0];
     dut.files.rm_h[i]=word0;dut.files.stk_h[i]=word1;
     dut.files.rm_l[i]=word2;dut.files.stk_l[i]=word3;
   end
   fixture_memory=memory_image();
   #100;load=1;#100;load=0;#100;
   fixture=7|(636'h1<<38)|(636'h1<<54)|(636'h1<<75)|(636'h1<<93)|(636'h1<<99);
   fixture[43:40]=15;fixture[47:44]=15;fixture[59:56]=15;fixture[63:60]=15;
   fixture[83:80]=15;fixture[87:84]=15;fixture[30]=1;fixture[29]=1;
   load=1;#100;load=0;#100;load=1;#100;load=0;#100;
   if(reference!==fixture) $fatal(1,"R memory fixture mismatch");
   q=fixture;monitor=1;p=SEED;p[19:0]=20'h178;
   for(integer bit_no=0;bit_no<8;bit_no=bit_no+1) data_changed[bit_no]=$realtime;
   data_valid=8'hff;clock_valid=0;
   for(integer i=0;i<64;i=i+1) event_step(!cb,p);

   // Exercise the original reset, task maintenance, masked StopTasks and
   // separate processor/memory Hold seams. Each producer settles HIGH.
   for(integer round_no=0;round_no<8;round_no=round_no+1) begin
     if(!cb) event_step(1,p);
     p[8:0]=9'h178;p[0]=1;p[7]=1;p[70]=1;p[74:71]=0;
     p[68]=0;p[69]=0;p[65]=0;
     event_step(1,p);
     for(integer edge_no=0;edge_no<16;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[7]=0;event_step(1,p);
     for(integer edge_no=0;edge_no<16;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[70]=0;p[74:71]=4'(round_no);event_step(1,p);
     p[74:71]=0;event_step(1,p);
     p[0]=0;event_step(1,p);
     for(integer edge_no=0;edge_no<64;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[65]=1;event_step(1,p);
     for(integer edge_no=0;edge_no<16;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[65]=0;event_step(1,p);
     p[68]=1;p[69]=1;p[34:20]=15'h1<<round_no;event_step(1,p);
     for(integer edge_no=0;edge_no<32;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[69]=0;event_step(1,p);
     for(integer edge_no=0;edge_no<16;edge_no=edge_no+1) event_step(!cb,p);
     if(!cb) event_step(1,p);
     p[68]=0;event_step(1,p);
     for(integer edge_no=0;edge_no<32;edge_no=edge_no+1) event_step(!cb,p);
   end
   iterations=0;

   $display("R_MEMORY_CONTROL PASS checks=%0d writes=%0d reads=%0d old_epoch_changes=%0d",checks,writes,reads,capture_epoch_changes);
   $finish;
 end
endmodule
`default_nettype wire
