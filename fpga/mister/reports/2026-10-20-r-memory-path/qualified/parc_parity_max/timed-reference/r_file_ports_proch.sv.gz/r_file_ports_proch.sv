`timescale 1ns/1ps
`default_nettype none
module r_file_ports_proch(input wire fixture_load,input wire [4607:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [4607:0] state_q,output wire [1:0] clocks,
 output wire [9:0] flags);
 wire n0; // ProcH03.sil+1
 wire n1; // ProcH04.sil+1
 wire n2; // ProcH05.sil+1
 wire n3; // ProcH06.sil+1
 wire n4; // ProcH07.sil+1
 wire n5; // ProcH08.sil+1
 wire n6; // ProcH09.sil+1
 wire n7; // ProcH27.sil+1
 wire n8; // ProcH27.sil+2
 wire n9; // RbAdr.0
 wire n10; // RbAdr.1
 wire n11; // RbAdr.2
 wire n12; // RbAdr.3
 wire n13; // RbAdr.4'
 wire n14; // RbAdr.5'
 wire n15; // RbAdr.6'
 wire n16; // RbAdr.7'
 wire n17; // RbWrite'a
 wire n18; // RbWrite'b
 wire n19; // RbWrite'c
 wire n20; // SelectRm'a
 wire n21; // SelectStk'a
 wire n22; // StkAdr.0a
 wire n23; // StkAdr.1a
 wire n24; // StkAdr.2a
 wire n25; // StkAdr.3a
 wire n26; // StkAdr.4a
 wire n27; // StkAdr.5a
 wire n28; // StkAdr.6a
 wire n29; // StkAdr.7a
 wire n30; // TrueA
 wire n31; // VEE176
 wire n32; // VEE200
 wire n33; // VEE224
 wire n34; // VEE248
 wire n35; // dRm.00
 wire n36; // dRm.01
 wire n37; // dRm.02
 wire n38; // dRm.03
 wire n39; // dRm.04
 wire n40; // dRm.05
 wire n41; // dRm.06
 wire n42; // dRm.07
 wire n43; // ddR.00
 assign n9=pins[7];
 assign n10=pins[6];
 assign n11=pins[5];
 assign n12=pins[4];
 assign n13=pins[3];
 assign n14=pins[2];
 assign n15=pins[1];
 assign n16=pins[0];
 assign n17=pins[26];
 assign n18=pins[26];
 assign n19=pins[26];
 assign n20=pins[16];
 assign n21=pins[17];
 assign n22=pins[15];
 assign n23=pins[14];
 assign n24=pins[13];
 assign n25=pins[12];
 assign n26=pins[11];
 assign n27=pins[10];
 assign n28=pins[9];
 assign n29=pins[8];
 assign n30=1'b1;
 assign n31=1'b0;
 assign n32=1'b0;
 assign n33=1'b0;
 assign n34=1'b0;
 assign n35=pins[18];
 assign n36=pins[19];
 assign n37=pins[20];
 assign n38=pins[21];
 assign n39=pins[22];
 assign n40=pins[23];
 assign n41=pins[24];
 assign n42=pins[25];
 wire n0_h06_22;
 wire n0_i06_22;
 assign n0=n0_h06_22 | n0_i06_22;
 wire n1_h06_21;
 wire n1_i06_21;
 assign n1=n1_h06_21 | n1_i06_21;
 wire n2_h06_20;
 wire n2_i06_20;
 assign n2=n2_h06_20 | n2_i06_20;
 wire n3_j06_23;
 wire n3_k06_23;
 assign n3=n3_j06_23 | n3_k06_23;
 wire n4_j06_22;
 wire n4_k06_22;
 assign n4=n4_j06_22 | n4_k06_22;
 wire n5_j06_21;
 wire n5_k06_21;
 assign n5=n5_j06_21 | n5_k06_21;
 wire n6_j06_20;
 wire n6_k06_20;
 assign n6=n6_j06_20 | n6_k06_20;
 wire n7_j08_15;
 wire n7_i08_15;
 assign n7=n7_j08_15 | n7_i08_15;
 wire n8_k03_2;
 assign n8=n8_k03_2;
 wire n43_h06_23;
 wire n43_i06_23;
 assign n43=n43_h06_23 | n43_i06_23;
 original_MB7071H h06(.p2(n17),.p3(n20),.p4(n20),.p5(n20),.p6(n20),.p7(n9),.p8(n10),.p9(n11),.p10(n12),.p11(n13),.p12(n14),.p13(n15),.p14(n16),.p15(n31),.p16(n38),.p17(n37),.p18(n36),.p19(n35),.p20(n2_h06_20),.p21(n1_h06_21),.p22(n0_h06_22),.p23(n43_h06_23),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:1024]),.state_q(state_q[0+:1024]));
 original_MB7071H i06(.p2(n17),.p3(n21),.p4(n21),.p5(n21),.p6(n21),.p7(n22),.p8(n23),.p9(n24),.p10(n25),.p11(n26),.p12(n27),.p13(n28),.p14(n29),.p15(n32),.p16(n38),.p17(n37),.p18(n36),.p19(n35),.p20(n2_i06_20),.p21(n1_i06_21),.p22(n0_i06_22),.p23(n43_i06_23),.fixture_load(fixture_load),.fixture_state(fixture_state[2048+:1024]),.state_q(state_q[2048+:1024]));
 original_F10414 i08(.p1(n22),.p2(n23),.p3(n24),.p4(n25),.p7(n21),.p9(n26),.p10(n27),.p11(n28),.p12(n29),.p13(n8),.p14(n19),.p15(n7_i08_15),.fixture_load(fixture_load),.fixture_state(fixture_state[4352+:256]),.state_q(state_q[4352+:256]));
 original_MB7071H j06(.p2(n18),.p3(n20),.p4(n20),.p5(n20),.p6(n20),.p7(n9),.p8(n10),.p9(n11),.p10(n12),.p11(n13),.p12(n14),.p13(n15),.p14(n16),.p15(n33),.p16(n42),.p17(n41),.p18(n40),.p19(n39),.p20(n6_j06_20),.p21(n5_j06_21),.p22(n4_j06_22),.p23(n3_j06_23),.fixture_load(fixture_load),.fixture_state(fixture_state[1024+:1024]),.state_q(state_q[1024+:1024]));
 original_F10414 j08(.p1(n9),.p2(n10),.p3(n11),.p4(n12),.p7(n20),.p9(n13),.p10(n14),.p11(n15),.p12(n16),.p13(n8),.p14(n19),.p15(n7_j08_15),.fixture_load(fixture_load),.fixture_state(fixture_state[4096+:256]),.state_q(state_q[4096+:256]));
 cell_MC10170 k03(.p1(1'b0),.p2(n8_k03_2),.p3(n30),.p4(n42),.p5(n41),.p6(n40),.p7(n39),.p8(1'b0),.p9(n38),.p10(n37),.p11(n36),.p12(n35),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 original_MB7071H k06(.p2(n18),.p3(n21),.p4(n21),.p5(n21),.p6(n21),.p7(n22),.p8(n23),.p9(n24),.p10(n25),.p11(n26),.p12(n27),.p13(n28),.p14(n29),.p15(n34),.p16(n42),.p17(n41),.p18(n40),.p19(n39),.p20(n6_k06_20),.p21(n5_k06_21),.p22(n4_k06_22),.p23(n3_k06_23),.fixture_load(fixture_load),.fixture_state(fixture_state[3072+:1024]),.state_q(state_q[3072+:1024]));
 assign clocks[0]=h06.p2;
 assign clocks[1]=i06.p2;
 assign flags[0]=n43;
 assign flags[1]=n0;
 assign flags[2]=n1;
 assign flags[3]=n2;
 assign flags[4]=n3;
 assign flags[5]=n4;
 assign flags[6]=n5;
 assign flags[7]=n6;
 assign flags[8]=n7;
 assign flags[9]=n8;
endmodule
`default_nettype wire
