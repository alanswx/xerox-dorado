`timescale 1ns/1ps
`default_nettype none
module r_operand_proch(input wire fixture_load,input wire [271:0] fixture_state,
 input wire base,start_a,en,input wire [151:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,
 output wire [271:0] state_q,output wire [11:0] clocks,
 output wire [11:0] flags);
 wire n0; // ALUCarry
 wire n1; // BCWriteEn'
 wire n2; // BNTGtCT
 wire n3; // BNTGtCT'a
 wire n4; // BSEL.0'
 wire n5; // BSEL.1'
 wire n6; // BSEL.2'
 wire n7; // BSel.0'a
 wire n8; // BSel.0a
 wire n9; // BSel.1'a
 wire n10; // BSel.1a
 wire n11; // BSel.2'a
 wire n12; // BSel.2a
 wire n13; // BSel=2/6
 wire n14; // B_Ext
 wire n15; // B_Ext'
 wire n16; // CLK.ph'
 wire n17; // CLKEnable'c
 wire n18; // Clock0'Da
 wire n19; // Clock0'Dc
 wire n20; // Clock0'Dd
 wire n21; // Clock0En'
 wire n22; // Clock1'Ba
 wire n23; // Clock1'Bb
 wire n24; // Clock1'Ca
 wire n25; // Clock1'Cb
 wire n26; // Clock1'Cd
 wire n27; // Clock1'Da
 wire n28; // Clock1'Dc
 wire n29; // Clock1Bd
 wire n30; // Curr.0'
 wire n31; // Curr.1'
 wire n32; // Curr.2'
 wire n33; // Curr.3'
 wire n34; // Curr=Next'
 wire n35; // CurrLast.0'
 wire n36; // CurrLast.1'
 wire n37; // CurrLast.2'
 wire n38; // CurrLast.3'
 wire n39; // DMData
 wire n40; // DMuxData
 wire n41; // DblClock'Da
 wire n42; // DsMd
 wire n43; // DsPd
 wire n44; // DsRd
 wire n45; // FA=0'b
 wire n46; // FA=1'a
 wire n47; // FA=3'
 wire n48; // FB=3'
 wire n49; // FB=7'
 wire n50; // FC=5'
 wire n51; // FC=6'
 wire n52; // FC=7'
 wire n53; // FF.2'a
 wire n54; // FF.2a
 wire n55; // FF.3'a
 wire n56; // Freeze
 wire n57; // GND132
 wire n58; // GND264
 wire n59; // GND266
 wire n60; // GND312
 wire n61; // GND314
 wire n62; // GND394
 wire n63; // GND40
 wire n64; // GND420
 wire n65; // GND442
 wire n66; // GND468
 wire n67; // GND530
 wire n68; // GND544
 wire n69; // GND546
 wire n70; // Hold
 wire n71; // Hold'
 wire n72; // HoldDly
 wire n73; // Holda
 wire n74; // IOB.Perr'
 wire n75; // IOBout
 wire n76; // LC.0
 wire n77; // LC.1
 wire n78; // LC.1'a
 wire n79; // LC.1a
 wire n80; // LC.2
 wire n81; // Last.0'
 wire n82; // Last.1'
 wire n83; // Last.2'
 wire n84; // Last.3'
 wire n85; // Last=Curr'
 wire n86; // LastNext.0'
 wire n87; // LastNext.1'
 wire n88; // LastNext.2'
 wire n89; // LastNext.3'
 wire n90; // MBBypass
 wire n91; // MBWriteEn'
 wire n92; // Next.0
 wire n93; // Next.0'
 wire n94; // Next.1
 wire n95; // Next.1'
 wire n96; // Next.2
 wire n97; // Next.2'
 wire n98; // Next.3
 wire n99; // Next.3'
 wire n100; // Overflow'
 wire n101; // PRhold
 wire n102; // Pdata.00
 wire n103; // Pdata.01
 wire n104; // Pdata.02
 wire n105; // Pdata.03
 wire n106; // Pdata.04
 wire n107; // Pdata.05
 wire n108; // Pdata.06
 wire n109; // Pdata.07
 wire n110; // PreClock0'A
 wire n111; // PreClock0'B
 wire n112; // PreClock0'C
 wire n113; // PreClock0'D
 wire n114; // PreClock1'A
 wire n115; // PreClock1'B
 wire n116; // PreClock1'C
 wire n117; // PreClock1'D
 wire n118; // PreClock1B
 wire n119; // PreDblClock'D
 wire n120; // PreSHCP'A
 wire n121; // PreSHCP'B
 wire n122; // PreSHCP'C
 wire n123; // PreSHCP'Shc
 wire n124; // PreSHSelect'D
 wire n125; // ProcH02.sil+4
 wire n126; // ProcH03.sil+1
 wire n127; // ProcH03.sil+5
 wire n128; // ProcH04.sil+1
 wire n129; // ProcH04.sil+5
 wire n130; // ProcH05.sil+1
 wire n131; // ProcH05.sil+5
 wire n132; // ProcH06.sil+1
 wire n133; // ProcH06.sil+5
 wire n134; // ProcH07.sil+1
 wire n135; // ProcH07.sil+5
 wire n136; // ProcH08.sil+1
 wire n137; // ProcH08.sil+5
 wire n138; // ProcH09.sil+1
 wire n139; // ProcH09.sil+5
 wire n140; // ProcH10.sil+1
 wire n141; // ProcH10.sil+2
 wire n142; // ProcH10.sil+3
 wire n143; // ProcH11.sil+1
 wire n144; // ProcH11.sil+12
 wire n145; // ProcH11.sil+13
 wire n146; // ProcH11.sil+14
 wire n147; // ProcH12.sil+1
 wire n148; // ProcH12.sil+2
 wire n149; // ProcH12.sil+3
 wire n150; // ProcH12.sil+4
 wire n151; // ProcH12.sil+5
 wire n152; // ProcH15.sil+1
 wire n153; // ProcH20.sil+1
 wire n154; // ProcH20.sil+2
 wire n155; // ProcH20.sil+3
 wire n156; // ProcH20.sil+4
 wire n157; // ProcH20.sil+5
 wire n158; // ProcH20.sil+6
 wire n159; // ProcH24.sil+1
 wire n160; // ProcH24.sil+2
 wire n161; // ProcH24.sil+4
 wire n162; // ProcH25.sil+1
 wire n163; // ProcH25.sil+18
 wire n164; // ProcH25.sil+7
 wire n165; // ProcH26.sil+1
 wire n166; // ProcH26.sil+3
 wire n167; // ProcH27.sil+1
 wire n168; // ProcH27.sil+10
 wire n169; // ProcH27.sil+12
 wire n170; // ProcH27.sil+7
 wire n171; // ProcH27.sil+8
 wire n172; // ProcH27.sil+9
 wire n173; // ProcH30.sil+1
 wire n174; // R.00
 wire n175; // R.01
 wire n176; // R.02
 wire n177; // R.03
 wire n178; // R.04
 wire n179; // R.05
 wire n180; // R.06
 wire n181; // R.07
 wire n182; // R.Perr'
 wire n183; // RbBypass
 wire n184; // RbBypass'
 wire n185; // RbBypassDly
 wire n186; // RbSelMd
 wire n187; // RbSelMd'
 wire n188; // RbWrite'a
 wire n189; // RbWrite'b
 wire n190; // RbWrite'c
 wire n191; // RbWriteEn'
 wire n192; // RepeatCurrB
 wire n193; // RepeatCurrC
 wire n194; // RepeatCurrD
 wire n195; // RisIFdata
 wire n196; // RmLtZero'
 wire n197; // Rparity
 wire n198; // SHCP'C
 wire n199; // ShiftBitsEn'
 wire n200; // SignIfuData
 wire n201; // StartCycle'a
 wire n202; // T.00
 wire n203; // T.01
 wire n204; // T.02
 wire n205; // T.03
 wire n206; // T.04
 wire n207; // T.05
 wire n208; // T.06
 wire n209; // T.07
 wire n210; // T.Perr'
 wire n211; // TIOAWrite'
 wire n212; // TIOAWriteEn'
 wire n213; // TbBypass
 wire n214; // TbSelMd
 wire n215; // TbWrite'a
 wire n216; // TbWrite'b
 wire n217; // TbWriteEn'
 wire n218; // TisIFdata
 wire n219; // Tparity
 wire n220; // TrueA
 wire n221; // dMD.00
 wire n222; // dMD.01
 wire n223; // dMD.02
 wire n224; // dMD.03
 wire n225; // dMD.04
 wire n226; // dMD.05
 wire n227; // dMD.06
 wire n228; // dMD.07
 wire n229; // dR.00
 wire n230; // dR.01
 wire n231; // dR.02
 wire n232; // dR.03
 wire n233; // dR.04
 wire n234; // dR.05
 wire n235; // dR.06
 wire n236; // dR.07
 wire n237; // dRm.00
 wire n238; // dRm.01
 wire n239; // dRm.02
 wire n240; // dRm.03
 wire n241; // dRm.04
 wire n242; // dRm.05
 wire n243; // dRm.06
 wire n244; // dRm.07
 wire n245; // dT.00
 wire n246; // dT.01
 wire n247; // dT.02
 wire n248; // dT.03
 wire n249; // dT.04
 wire n250; // dT.05
 wire n251; // dT.06
 wire n252; // dT.07
 wire n253; // dTm.00
 wire n254; // dTm.01
 wire n255; // dTm.02
 wire n256; // dTm.03
 wire n257; // dTm.04
 wire n258; // dTm.05
 wire n259; // dTm.06
 wire n260; // dTm.07
 wire n261; // ddR.00
 wire n262; // pClock1En'
 wire n263; // ppClk'a
 wire n264; // ppClk'b
 wire n265; // ppClk'c
 assign n57=1'b0;
 assign n58=1'b0;
 assign n59=1'b0;
 assign n60=1'b0;
 assign n61=1'b0;
 assign n62=1'b0;
 assign n63=1'b0;
 assign n64=1'b0;
 assign n65=1'b0;
 assign n66=1'b0;
 assign n67=1'b0;
 assign n68=1'b0;
 assign n69=1'b0;
 assign n0=pins[110];
 assign n3=priority_n;
 assign n4=1'b0;
 assign n5=1'b0;
 assign n6=1'b0;
 assign n16=base;
 assign n17=en;
 assign n40=1'b0;
 assign n45=(pins[19:18]!=2'd0);
 assign n46=(pins[19:18]!=2'd1);
 assign n47=(pins[19:18]!=2'd3);
 assign n48=(pins[17:15]!=3'd3);
 assign n49=(pins[17:15]!=3'd7);
 assign n50=(pins[14:12]!=3'd5);
 assign n51=(pins[14:12]!=3'd6);
 assign n52=(pins[14:12]!=3'd7);
 assign n53=~pins[17];
 assign n54=pins[17];
 assign n55=~pins[16];
 assign n56=freeze;
 assign n73=pins[68];
 assign n75=1'b0;
 assign n76=pins[11];
 assign n77=pins[10];
 assign n80=pins[9];
 assign n90=1'b0;
 assign n92=next_raw[0];
 assign n94=next_raw[1];
 assign n96=next_raw[2];
 assign n98=next_raw[3];
 assign n100=pins[111];
 assign n101=pins[68];
 assign n102=pins[76];
 assign n103=pins[77];
 assign n104=pins[78];
 assign n105=pins[79];
 assign n106=pins[80];
 assign n107=pins[81];
 assign n108=pins[82];
 assign n109=pins[83];
 assign n126=pins[128];
 assign n128=pins[129];
 assign n130=pins[130];
 assign n132=pins[131];
 assign n134=pins[132];
 assign n136=pins[133];
 assign n138=pins[134];
 assign n146=pins[145];
 assign n161=pins[109];
 assign n162=1'b0;
 assign n163=1'b0;
 assign n166=1'b0;
 assign n167=pins[143];
 assign n169=1'b0;
 assign n183=pins[148];
 assign n184=~pins[148];
 assign n195=pins[149];
 assign n200=pins[118];
 assign n201=start_a;
 assign n212=1'b1;
 assign n218=pins[117];
 assign n221=pins[92];
 assign n222=pins[93];
 assign n223=pins[94];
 assign n224=pins[95];
 assign n225=pins[96];
 assign n226=pins[97];
 assign n227=pins[98];
 assign n228=pins[99];
 assign n261=pins[127];
 wire n1_g18_2;
 assign n1=n1_g18_2;
 wire n2_a01_2;
 assign n2=n2_a01_2;
 wire n7_h24_5;
 assign n7=n7_h24_5;
 wire n8_h24_2;
 assign n8=n8_h24_2;
 wire n9_h24_6;
 assign n9=n9_h24_6;
 wire n10_h24_3;
 assign n10=n10_h24_3;
 wire n11_h24_11;
 assign n11=n11_h24_11;
 wire n12_h24_14;
 assign n12=n12_h24_14;
 wire n13_f18_15;
 assign n13=n13_f18_15;
 wire n14_f19_3;
 assign n14=n14_f19_3;
 wire n15_f19_2;
 assign n15=n15_f19_2;
 wire n18_i18_3;
 assign n18=n18_i18_3;
 wire n19_i18_2;
 assign n19=n19_i18_2;
 wire n20_i18_4;
 assign n20=n20_i18_4;
 wire n21_l01_4;
 assign n21=n21_l01_4;
 wire n22_i05_3;
 assign n22=n22_i05_3;
 wire n23_i05_4;
 assign n23=n23_i05_4;
 wire n24_c18_3;
 assign n24=n24_c18_3;
 wire n25_c18_2;
 assign n25=n25_c18_2;
 wire n26_c18_4;
 assign n26=n26_c18_4;
 wire n27_i18_13;
 assign n27=n27_i18_13;
 wire n28_i18_12;
 assign n28=n28_i18_12;
 wire n29_i05_2;
 assign n29=n29_i05_2;
 wire n30_a21_14;
 assign n30=n30_a21_14;
 wire n31_a21_15;
 assign n31=n31_a21_15;
 wire n32_a21_2;
 assign n32=n32_a21_2;
 wire n33_a21_3;
 assign n33=n33_a21_3;
 wire n34_a22_3;
 wire n34_a22_2;
 wire n34_a22_15;
 wire n34_a22_14;
 assign n34=n34_a22_3 | n34_a22_2 | n34_a22_15 | n34_a22_14;
 wire n35_i12_14;
 assign n35=n35_i12_14;
 wire n36_i12_15;
 assign n36=n36_i12_15;
 wire n37_i12_2;
 assign n37=n37_i12_2;
 wire n38_i12_3;
 assign n38=n38_i12_3;
 wire n39_h17_2;
 assign n39=n39_h17_2;
 wire n41_j18_2;
 assign n41=n41_j18_2;
 wire n42_l09_2;
 wire n42_l08_3;
 assign n42=n42_l09_2 | n42_l08_3;
 wire n43_l08_12;
 wire n43_l08_2;
 assign n43=n43_l08_12 | n43_l08_2;
 wire n44_l09_3;
 wire n44_l08_13;
 assign n44=n44_l09_3 | n44_l08_13;
 wire n70_f19_15;
 assign n70=n70_f19_15;
 wire n71_f19_14;
 assign n71=n71_f19_14;
 wire n72_g18_15;
 assign n72=n72_g18_15;
 wire n74_h23_15;
 assign n74=n74_h23_15;
 wire n78_h24_15;
 assign n78=n78_h24_15;
 wire n79_h24_9;
 assign n79=n79_h24_9;
 wire n81_a20_14;
 assign n81=n81_a20_14;
 wire n82_a20_15;
 assign n82=n82_a20_15;
 wire n83_a20_2;
 assign n83=n83_a20_2;
 wire n84_a20_3;
 assign n84=n84_a20_3;
 wire n85_h22_15;
 assign n85=n85_h22_15;
 wire n86_a19_1;
 assign n86=n86_a19_1;
 wire n87_a19_2;
 assign n87=n87_a19_2;
 wire n88_a19_15;
 assign n88=n88_a19_15;
 wire n89_a19_14;
 assign n89=n89_a19_14;
 wire n91_g18_3;
 assign n91=n91_g18_3;
 wire n93_a24_15;
 assign n93=n93_a24_15;
 wire n95_a24_14;
 assign n95=n95_a24_14;
 wire n97_a24_3;
 assign n97=n97_a24_3;
 wire n99_a24_2;
 assign n99=n99_a24_2;
 wire n110_f13_13;
 assign n110=n110_f13_13;
 wire n111_f13_12;
 assign n111=n111_f13_12;
 wire n112_f13_14;
 assign n112=n112_f13_14;
 wire n113_g13_3;
 assign n113=n113_g13_3;
 wire n114_f12_14;
 assign n114=n114_f12_14;
 wire n115_f13_2;
 assign n115=n115_f13_2;
 wire n116_f13_4;
 assign n116=n116_f13_4;
 wire n117_f13_3;
 assign n117=n117_f13_3;
 wire n118_f12_13;
 assign n118=n118_f12_13;
 wire n119_g13_13;
 assign n119=n119_g13_13;
 wire n120_g12_3;
 assign n120=n120_g12_3;
 wire n121_g12_2;
 assign n121=n121_g12_2;
 wire n122_g12_4;
 assign n122=n122_g12_4;
 wire n123_f12_4;
 assign n123=n123_f12_4;
 wire n124_f12_3;
 assign n124=n124_f12_3;
 wire n125_l03_2;
 assign n125=n125_l03_2;
 wire n127_l03_1;
 assign n127=n127_l03_1;
 wire n129_l03_15;
 assign n129=n129_l03_15;
 wire n131_l03_14;
 assign n131=n131_l03_14;
 wire n133_l04_2;
 assign n133=n133_l04_2;
 wire n135_l04_1;
 assign n135=n135_l04_1;
 wire n137_l04_15;
 assign n137=n137_l04_15;
 wire n139_l04_14;
 assign n139=n139_l04_14;
 wire n140_l08_14;
 assign n140=n140_l08_14;
 wire n141_l09_4;
 assign n141=n141_l09_4;
 wire n142_l08_4;
 assign n142=n142_l08_4;
 wire n143_f20_2;
 wire n143_h17_15;
 assign n143=n143_f20_2 | n143_h17_15;
 wire n144_g18_14;
 assign n144=n144_g18_14;
 wire n145_g18_13;
 assign n145=n145_g18_13;
 wire n147_a24_9;
 wire n147_a24_11;
 wire n147_a24_6;
 wire n147_a24_5;
 assign n147=n147_a24_9 | n147_a24_11 | n147_a24_6 | n147_a24_5;
 wire n148_a18_2;
 assign n148=n148_a18_2;
 wire n149_a18_1;
 assign n149=n149_a18_1;
 wire n150_a18_15;
 assign n150=n150_a18_15;
 wire n151_a18_14;
 assign n151=n151_a18_14;
 wire n152_f20_14;
 assign n152=n152_f20_14;
 wire n153_f20_15;
 wire n153_f18_3;
 assign n153=n153_f20_15 | n153_f18_3;
 wire n154_h23_2;
 assign n154=n154_h23_2;
 wire n155_h23_3;
 assign n155=n155_h23_3;
 wire n156_h23_14;
 assign n156=n156_h23_14;
 wire n157_f18_2;
 assign n157=n157_f18_2;
 wire n158_l09_12;
 assign n158=n158_l09_12;
 wire n159_f18_14;
 assign n159=n159_f18_14;
 wire n160_f20_3;
 assign n160=n160_f20_3;
 wire n164_h17_14;
 assign n164=n164_h17_14;
 wire n165_a01_3;
 assign n165=n165_a01_3;
 wire n168_g21_15;
 assign n168=n168_g21_15;
 wire n170_i11_2;
 assign n170=n170_i11_2;
 wire n171_k04_2;
 assign n171=n171_k04_2;
 wire n172_g21_2;
 assign n172=n172_g21_2;
 wire n173_f12_2;
 assign n173=n173_f12_2;
 wire n174_g06_1;
 assign n174=n174_g06_1;
 wire n175_g06_2;
 assign n175=n175_g06_2;
 wire n176_g06_15;
 assign n176=n176_g06_15;
 wire n177_g06_14;
 assign n177=n177_g06_14;
 wire n178_g07_1;
 assign n178=n178_g07_1;
 wire n179_g07_2;
 assign n179=n179_g07_2;
 wire n180_g07_15;
 assign n180=n180_g07_15;
 wire n181_g07_14;
 assign n181=n181_g07_14;
 wire n182_c06_2;
 assign n182=n182_c06_2;
 wire n185_l07_15;
 assign n185=n185_l07_15;
 wire n186_h22_2;
 assign n186=n186_h22_2;
 wire n187_h22_3;
 assign n187=n187_h22_3;
 wire n188_j05_13;
 assign n188=n188_j05_13;
 wire n189_j05_12;
 assign n189=n189_j05_12;
 wire n190_j05_14;
 assign n190=n190_j05_14;
 wire n191_h22_13;
 assign n191=n191_h22_13;
 wire n192_g12_13;
 assign n192=n192_g12_13;
 wire n193_g12_12;
 assign n193=n193_g12_12;
 wire n194_g12_14;
 assign n194=n194_g12_14;
 wire n196_l07_3;
 assign n196=n196_l07_3;
 wire n197_g16_14;
 assign n197=n197_g16_14;
 wire n198_c18_12;
 assign n198=n198_c18_12;
 wire n199_g16_2;
 assign n199=n199_g16_2;
 wire n202_i03_1;
 assign n202=n202_i03_1;
 wire n203_i03_2;
 assign n203=n203_i03_2;
 wire n204_i03_15;
 assign n204=n204_i03_15;
 wire n205_i03_14;
 assign n205=n205_i03_14;
 wire n206_i04_1;
 assign n206=n206_i04_1;
 wire n207_i04_2;
 assign n207=n207_i04_2;
 wire n208_i04_15;
 assign n208=n208_i04_15;
 wire n209_i04_14;
 assign n209=n209_i04_14;
 wire n210_d06_2;
 assign n210=n210_d06_2;
 wire n211_j18_12;
 assign n211=n211_j18_12;
 wire n213_g21_3;
 assign n213=n213_g21_3;
 wire n214_h22_4;
 assign n214=n214_h22_4;
 wire n215_j05_3;
 assign n215=n215_j05_3;
 wire n216_j05_2;
 assign n216=n216_j05_2;
 wire n217_h22_14;
 assign n217=n217_h22_14;
 wire n219_g16_15;
 assign n219=n219_g16_15;
 wire n220_a01_14;
 assign n220=n220_a01_14;
 wire n229_g05_1;
 assign n229=n229_g05_1;
 wire n230_g05_2;
 assign n230=n230_g05_2;
 wire n231_g05_15;
 assign n231=n231_g05_15;
 wire n232_g05_14;
 assign n232=n232_g05_14;
 wire n233_h05_1;
 assign n233=n233_h05_1;
 wire n234_h05_2;
 assign n234=n234_h05_2;
 wire n235_h05_15;
 assign n235=n235_h05_15;
 wire n236_h05_14;
 assign n236=n236_h05_14;
 wire n237_j01_1;
 assign n237=n237_j01_1;
 wire n238_j01_2;
 assign n238=n238_j01_2;
 wire n239_j01_15;
 assign n239=n239_j01_15;
 wire n240_j01_14;
 assign n240=n240_j01_14;
 wire n241_j02_1;
 assign n241=n241_j02_1;
 wire n242_j02_2;
 assign n242=n242_j02_2;
 wire n243_j02_15;
 assign n243=n243_j02_15;
 wire n244_j02_14;
 assign n244=n244_j02_14;
 wire n245_j03_1;
 assign n245=n245_j03_1;
 wire n246_j03_2;
 assign n246=n246_j03_2;
 wire n247_j03_15;
 assign n247=n247_j03_15;
 wire n248_j03_14;
 assign n248=n248_j03_14;
 wire n249_j04_1;
 assign n249=n249_j04_1;
 wire n250_j04_2;
 assign n250=n250_j04_2;
 wire n251_j04_15;
 assign n251=n251_j04_15;
 wire n252_j04_14;
 assign n252=n252_j04_14;
 wire n253_k01_1;
 assign n253=n253_k01_1;
 wire n254_k01_2;
 assign n254=n254_k01_2;
 wire n255_k01_15;
 assign n255=n255_k01_15;
 wire n256_k01_14;
 assign n256=n256_k01_14;
 wire n257_k02_1;
 assign n257=n257_k02_1;
 wire n258_k02_2;
 assign n258=n258_k02_2;
 wire n259_k02_15;
 assign n259=n259_k02_15;
 wire n260_k02_14;
 assign n260=n260_k02_14;
 wire n262_l02_2;
 assign n262=n262_l02_2;
 wire n263_l01_13;
 assign n263=n263_l01_13;
 wire n264_l01_12;
 assign n264=n264_l01_12;
 wire n265_l01_14;
 assign n265=n265_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n2_a01_2),.p3(n165_a01_3),.p4(n3),.p5(1'b0),.p6(n166),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n220_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n149_a18_1),.p2(n148_a18_2),.p3(n87),.p4(n31),.p5(n86),.p6(n30),.p9(n193),.p10(n89),.p11(n33),.p12(n88),.p13(n32),.p14(n151_a18_14),.p15(n150_a18_15));
 cell_MC10158 a19(.p1(n86_a19_1),.p2(n87_a19_2),.p3(n95),.p4(n82),.p5(n93),.p6(n81),.p9(n122),.p10(n99),.p11(n84),.p12(n97),.p13(n83),.p14(n89_a19_14),.p15(n88_a19_15));
 original_MC10141 a20(.p1(n63),.p2(n83_a20_2),.p3(n84_a20_3),.p4(n24),.p5(1'b0),.p6(n33),.p7(1'b0),.p8(1'b0),.p9(n32),.p10(1'b0),.p11(n31),.p12(n30),.p13(1'b0),.p14(n81_a20_14),.p15(n82_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n32_a21_2),.p3(n33_a21_3),.p4(n198),.p5(1'b0),.p6(n99),.p7(n193),.p8(1'b0),.p9(n97),.p10(n193),.p11(n95),.p12(n93),.p13(1'b0),.p14(n30_a21_14),.p15(n31_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n34_a22_2),.p3(n34_a22_3),.p4(n33),.p5(n99),.p6(n97),.p7(n32),.p9(1'b0),.p10(n95),.p11(n31),.p12(n93),.p13(n30),.p14(n34_a22_14),.p15(n34_a22_15));
 cell_MC10101 a24(.p2(n99_a24_2),.p3(n97_a24_3),.p4(n98),.p5(n147_a24_5),.p6(n147_a24_6),.p7(n96),.p9(n147_a24_9),.p10(n94),.p11(n147_a24_11),.p12(1'b0),.p13(n92),.p14(n95_a24_14),.p15(n93_a24_15));
 cell_MC10170 c06(.p1(1'b0),.p2(n182_c06_2),.p3(n197),.p4(n181),.p5(n180),.p6(n179),.p7(n178),.p8(1'b0),.p9(n177),.p10(n176),.p11(n175),.p12(n174),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 c18(.p2(n25_c18_2),.p3(n24_c18_3),.p4(n26_c18_4),.p5(n116),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n122),.p10(1'b0),.p11(1'b0),.p12(n198_c18_12),.p15(n57),.p16(1'b0));
 cell_MC10170 d06(.p1(1'b0),.p2(n210_d06_2),.p3(n219),.p4(n209),.p5(n208),.p6(n207),.p7(n206),.p8(1'b0),.p9(n205),.p10(n204),.p11(n203),.p12(n202),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10212 f12(.p1(1'b0),.p2(n173_f12_2),.p3(n124_f12_3),.p4(n123_f12_4),.p5(n262),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n173),.p10(1'b0),.p11(n263),.p13(n118_f12_13),.p14(n114_f12_14),.p15(n58),.p16(1'b0));
 cell_SE10210 f13(.p2(n115_f13_2),.p3(n117_f13_3),.p4(n116_f13_4),.p5(n264),.p6(1'b0),.p7(n173),.p8(1'b0),.p9(n264),.p10(n21),.p11(1'b0),.p12(n111_f13_12),.p13(n110_f13_13),.p14(n112_f13_14),.p15(n59),.p16(1'b0));
 cell_MC10102 f18(.p1(1'b0),.p2(n157_f18_2),.p3(n153_f18_3),.p4(n80),.p5(n155),.p6(n76),.p7(n78),.p10(n54),.p11(n47),.p12(n12),.p13(n9),.p14(n159_f18_14),.p15(n13_f18_15),.p16(1'b0));
 cell_MC1660 f19(.p2(n15_f19_2),.p3(n14_f19_3),.p4(1'b0),.p5(n46),.p6(n55),.p7(n53),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n101),.p14(n71_f19_14),.p15(n70_f19_15));
 cell_MC10100 f20(.p2(n143_f20_2),.p3(n160_f20_3),.p4(n51),.p5(n49),.p6(n52),.p7(n48),.p9(n45),.p10(n51),.p11(n48),.p12(n50),.p13(n49),.p14(n152_f20_14),.p15(n153_f20_15));
 original_MC10173 g05(.p1(n229_g05_1),.p2(n230_g05_2),.p3(n126),.p4(n200),.p5(n261),.p6(n200),.p7(n23),.p9(n195),.p10(n130),.p11(n200),.p12(n128),.p13(n200),.p14(n232_g05_14),.p15(n231_g05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[254+:4]),.state_q(state_q[254+:4]));
 original_MC10173 g06(.p1(n174_g06_1),.p2(n175_g06_2),.p3(n230),.p4(n238),.p5(n229),.p6(n237),.p7(n121),.p9(n185),.p10(n232),.p11(n240),.p12(n231),.p13(n239),.p14(n177_g06_14),.p15(n176_g06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[262+:4]),.state_q(state_q[262+:4]));
 original_MC10173 g07(.p1(n178_g07_1),.p2(n179_g07_2),.p3(n234),.p4(n242),.p5(n233),.p6(n241),.p7(n121),.p9(n185),.p10(n236),.p11(n244),.p12(n235),.p13(n243),.p14(n181_g07_14),.p15(n180_g07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[266+:4]),.state_q(state_q[266+:4]));
 cell_SE10211 g12(.p2(n121_g12_2),.p3(n120_g12_3),.p4(n122_g12_4),.p5(1'b0),.p6(n262),.p7(1'b0),.p9(n2),.p10(n71),.p11(1'b0),.p12(n193_g12_12),.p13(n192_g12_13),.p14(n194_g12_14),.p15(n60),.p16(1'b0));
 cell_SE10210 g13(.p3(n113_g13_3),.p5(n265),.p6(n21),.p7(1'b0),.p8(1'b0),.p9(n265),.p10(1'b0),.p11(1'b0),.p13(n119_g13_13),.p15(n61),.p16(1'b0));
 original_F10000 g16(.p2(n199_g16_2),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n146),.p10(n170),.p11(n167),.p12(1'b0),.p13(n27),.p14(n197_g16_14),.p15(n219_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 original_MC10176 g18(.p1(1'b0),.p2(n1_g18_2),.p3(n91_g18_3),.p5(n143),.p6(n161),.p7(1'b0),.p8(1'b0),.p9(n18),.p10(n0),.p11(n100),.p12(n73),.p13(n145_g18_13),.p14(n144_g18_14),.p15(n72_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10106 g21(.p2(n172_g21_2),.p3(n213_g21_3),.p4(n72),.p5(n85),.p6(n217),.p7(n218),.p9(n185),.p10(n195),.p11(n182),.p12(n213),.p13(n218),.p14(n210),.p15(n168_g21_15));
 original_MC10173 h05(.p1(n233_h05_1),.p2(n234_h05_2),.p3(n134),.p4(n200),.p5(n132),.p6(n200),.p7(n23),.p9(n195),.p10(n138),.p11(n200),.p12(n136),.p13(n200),.p14(n236_h05_14),.p15(n235_h05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[258+:4]),.state_q(state_q[258+:4]));
 cell_MC10158 h17(.p2(n39_h17_2),.p3(n40),.p4(n40),.p5(1'b0),.p6(1'b0),.p9(n90),.p10(n163),.p11(n162),.p12(n56),.p13(n56),.p14(n164_h17_14),.p15(n143_h17_15));
 original_MC10176 h22(.p1(1'b0),.p2(n186_h22_2),.p3(n187_h22_3),.p4(n214_h22_4),.p5(n78),.p6(n79),.p7(n153),.p8(1'b0),.p9(n18),.p10(n156),.p11(n157),.p12(n34),.p13(n191_h22_13),.p14(n217_h22_14),.p15(n85_h22_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_MC10102 h23(.p1(1'b0),.p2(n154_h23_2),.p3(n155_h23_3),.p4(n78),.p5(n80),.p6(n76),.p7(n78),.p10(n76),.p11(n154),.p12(n75),.p13(n169),.p14(n156_h23_14),.p15(n74_h23_15),.p16(1'b0));
 cell_MC10101 h24(.p2(n8_h24_2),.p3(n10_h24_3),.p4(n4),.p5(n7_h24_5),.p6(n9_h24_6),.p7(n5),.p9(n79_h24_9),.p10(n6),.p11(n11_h24_11),.p12(1'b0),.p13(n77),.p14(n12_h24_14),.p15(n78_h24_15));
 original_MC10173 i03(.p1(n202_i03_1),.p2(n203_i03_2),.p3(n246),.p4(n254),.p5(n245),.p6(n253),.p7(n121),.p9(n213),.p10(n248),.p11(n256),.p12(n247),.p13(n255),.p14(n205_i03_14),.p15(n204_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 original_MC10173 i04(.p1(n206_i04_1),.p2(n207_i04_2),.p3(n250),.p4(n258),.p5(n249),.p6(n257),.p7(n121),.p9(n213),.p10(n252),.p11(n260),.p12(n251),.p13(n259),.p14(n209_i04_14),.p15(n208_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 cell_SE10212 i05(.p1(1'b0),.p2(n29_i05_2),.p3(n22_i05_3),.p4(n23_i05_4),.p5(1'b0),.p6(1'b0),.p7(n118),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n62),.p16(1'b0));
 original_F10145A i11(.p2(n170_i11_2),.p3(1'b0),.p4(1'b0),.p5(n171),.p6(n38),.p7(n37),.p8(1'b0),.p9(n36),.p10(n35),.p11(1'b0),.p12(1'b0),.p13(n216),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 original_MC10141 i12(.p1(1'b0),.p2(n37_i12_2),.p3(n38_i12_3),.p4(n41),.p5(1'b0),.p6(n151),.p7(1'b0),.p8(1'b0),.p9(n150),.p10(1'b0),.p11(n148),.p12(n149),.p13(1'b0),.p14(n35_i12_14),.p15(n36_i12_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_SE10210 i18(.p2(n19_i18_2),.p3(n18_i18_3),.p4(n20_i18_4),.p5(n113),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n117),.p10(1'b0),.p11(1'b0),.p12(n28_i18_12),.p13(n27_i18_13),.p15(n64),.p16(1'b0));
 original_MC10173 j01(.p1(n237_j01_1),.p2(n238_j01_2),.p3(n103),.p4(n222),.p5(n102),.p6(n221),.p7(n22),.p9(n186),.p10(n105),.p11(n224),.p12(n104),.p13(n223),.p14(n240_j01_14),.p15(n239_j01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[246+:4]),.state_q(state_q[246+:4]));
 original_MC10173 j02(.p1(n241_j02_1),.p2(n242_j02_2),.p3(n107),.p4(n226),.p5(n106),.p6(n225),.p7(n23),.p9(n186),.p10(n109),.p11(n228),.p12(n108),.p13(n227),.p14(n244_j02_14),.p15(n243_j02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[250+:4]),.state_q(state_q[250+:4]));
 original_MC10173 j03(.p1(n245_j03_1),.p2(n246_j03_2),.p3(n127),.p4(n200),.p5(n125),.p6(n200),.p7(n23),.p9(n218),.p10(n131),.p11(n200),.p12(n129),.p13(n200),.p14(n248_j03_14),.p15(n247_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 original_MC10173 j04(.p1(n249_j04_1),.p2(n250_j04_2),.p3(n135),.p4(n200),.p5(n133),.p6(n200),.p7(n23),.p9(n218),.p10(n139),.p11(n200),.p12(n137),.p13(n200),.p14(n252_j04_14),.p15(n251_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 cell_SE10210 j05(.p2(n216_j05_2),.p3(n215_j05_3),.p5(n111),.p6(n72),.p7(n217),.p8(1'b0),.p9(n111),.p10(n72),.p11(n191),.p12(n189_j05_12),.p13(n188_j05_13),.p14(n190_j05_14),.p15(n65),.p16(1'b0));
 cell_SE10210 j18(.p2(n41_j18_2),.p5(n119),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n117),.p10(n73),.p11(n212),.p12(n211_j18_12),.p15(n66),.p16(1'b0));
 original_MC10173 k01(.p1(n253_k01_1),.p2(n254_k01_2),.p3(n103),.p4(n222),.p5(n102),.p6(n221),.p7(n22),.p9(n214),.p10(n105),.p11(n224),.p12(n104),.p13(n223),.p14(n256_k01_14),.p15(n255_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n257_k02_1),.p2(n258_k02_2),.p3(n107),.p4(n226),.p5(n106),.p6(n225),.p7(n22),.p9(n214),.p10(n109),.p11(n228),.p12(n108),.p13(n227),.p14(n260_k02_14),.p15(n259_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_MC10170 k04(.p1(1'b0),.p2(n171_k04_2),.p3(n220),.p4(n260),.p5(n259),.p6(n258),.p7(n257),.p8(1'b0),.p9(n256),.p10(n255),.p11(n254),.p12(n253),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 l01(.p4(n21_l01_4),.p5(1'b0),.p6(n201),.p7(1'b0),.p8(1'b0),.p9(n17),.p10(1'b0),.p11(n16),.p12(n264_l01_12),.p13(n263_l01_13),.p14(n265_l01_14),.p15(n67),.p16(1'b0));
 original_SE10231 l02(.p2(n262_l02_2),.p6(n17),.p7(n21),.p9(n16),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n127_l03_1),.p2(n125_l03_2),.p3(1'b0),.p4(n254),.p5(n253),.p6(n38),.p7(n37),.p8(1'b0),.p9(n36),.p10(n35),.p11(n255),.p12(n256),.p13(n215),.p14(n131_l03_14),.p15(n129_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n135_l04_1),.p2(n133_l04_2),.p3(1'b0),.p4(n258),.p5(n257),.p6(n38),.p7(n37),.p8(1'b0),.p9(n36),.p10(n35),.p11(n259),.p12(n260),.p13(n215),.p14(n139_l04_14),.p15(n137_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 original_MC1668 l07(.p3(n196_l07_3),.p4(1'b0),.p5(n44),.p6(n261),.p7(n142),.p9(n29),.p11(n158),.p12(1'b0),.p13(1'b0),.p15(n185_l07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[270+:2]),.state_q(state_q[270+:2]));
 cell_SE10211 l08(.p2(n43_l08_2),.p3(n42_l08_3),.p4(n142_l08_4),.p5(n183),.p6(n115),.p7(1'b0),.p9(n187),.p10(n115),.p11(n184),.p12(n43_l08_12),.p13(n44_l08_13),.p14(n140_l08_14),.p15(n68),.p16(1'b0));
 cell_SE10211 l09(.p2(n42_l09_2),.p3(n44_l09_3),.p4(n141_l09_4),.p5(n186),.p6(n115),.p7(n184),.p9(n184),.p10(1'b0),.p11(n195),.p12(n158_l09_12),.p15(n69),.p16(1'b0));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n198;
 assign clocks[3]=n18;
 assign clocks[4]=n24;
 assign clocks[5]=n41;
 assign clocks[6]=n22;
 assign clocks[7]=n215;
 assign clocks[8]=n18;
 assign clocks[9]=n27;
 assign clocks[10]=l07.p7;
 assign clocks[11]=l07.p9;
 assign flags[0]=n193;
 assign flags[1]=n70;
 assign flags[2]=n34;
 assign flags[3]=n121;
 assign flags[4]=n213;
 assign flags[5]=n210;
 assign flags[6]=n182;
 assign flags[7]=n168;
 assign flags[8]=n172;
 assign flags[9]=n23;
 assign flags[10]=l07.state_q[0];
 assign flags[11]=n185;
endmodule
`default_nettype wire
