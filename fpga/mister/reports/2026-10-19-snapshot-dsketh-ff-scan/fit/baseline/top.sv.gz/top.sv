module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [91:0] stimulus,
 input wire freeze,held,request,write,input wire [12:0] index,
 input wire [17:0] state_data,output reg [114:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both DskEth neighbors sample on positive host edges; full20ns budgets.
 reg [128:0] launch;
 reg [128:0] input_stage;
 always @(negedge host_clk)
  input_stage<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 always @(posedge host_clk) launch<=input_stage;
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [91:0] stimulus_r;wire [12:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [114:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire [31:0] bank_receive_debug;
wire bank_ClockM0__drv;
wire bank_ClockM1__drv;
wire bank_ClockM2__drv;
wire bank_ClockM3__drv;
wire bank_ClockP0__drv;
wire bank_ClockP1__drv;
wire bank_ClockP2__drv;
wire bank_ClockP3__drv;
wire bank_ContTag_p___drv;
wire bank_CylinderTag_p___drv;
wire bank_DMuxData__drv;
wire bank_DataM0__drv;
wire bank_DataM1__drv;
wire bank_DataM2__drv;
wire bank_DataM3__drv;
wire bank_DataP0__drv;
wire bank_DataP1__drv;
wire bank_DataP2__drv;
wire bank_DataP3__drv;
wire bank_DriveTag_p___drv;
wire bank_HeadTag_p___drv;
wire bank_IOB_00__drv;
wire bank_IOB_01__drv;
wire bank_IOB_02__drv;
wire bank_IOB_03__drv;
wire bank_IOB_04__drv;
wire bank_IOB_05__drv;
wire bank_IOB_06__drv;
wire bank_IOB_07__drv;
wire bank_IOB_08__drv;
wire bank_IOB_09__drv;
wire bank_IOB_10__drv;
wire bank_IOB_11__drv;
wire bank_IOB_12__drv;
wire bank_IOB_13__drv;
wire bank_IOB_14__drv;
wire bank_IOB_15__drv;
wire bank_IOB_16__drv;
wire bank_IOB_17__drv;
wire bank_IOatt__drv;
wire bank_OKToSelect__drv;
wire bank_OS0__drv;
wire bank_OS1__drv;
wire bank_OS2__drv;
wire bank_OS3__drv;
wire bank_SecIndx0_p___drv;
wire bank_SecIndx1_p___drv;
wire bank_SecIndx2_p___drv;
wire bank_SecIndx3_p___drv;
wire bank_Select0_p___drv;
wire bank_Select1_p___drv;
wire bank_Select2_p___drv;
wire bank_Select3_p___drv;
wire bank_Selected0_p___drv;
wire bank_Selected1_p___drv;
wire bank_Selected2_p___drv;
wire bank_Selected3_p___drv;
wire bank_TWReq_06__drv;
wire bank_TWReq_07__drv;
wire bank_TWReq_12__drv;
wire bank_TagBus_0_p___drv;
wire bank_TagBus_00_p___drv;
wire bank_TagBus_000_p___drv;
wire bank_TagBus_1_p___drv;
wire bank_TagBus_2_p___drv;
wire bank_TagBus_3_p___drv;
wire bank_TagBus_4_p___drv;
wire bank_TagBus_5_p___drv;
wire bank_TagBus_6_p___drv;
wire bank_TagBus_7_p___drv;
wire bank_TagBus_8_p___drv;
wire bank_TagBus_9_p___drv;
wire bank_TtlDeviceCk_p___drv;
wire bank_TtlEndOfCyl_p___drv;
wire bank_TtlIndex_p___drv;
wire bank_TtlOffSet_p___drv;
wire bank_TtlOnLine_p___drv;
wire bank_TtlReadOnly_p___drv;
wire bank_TtlReady_p___drv;
wire bank_TtlSector_p___drv;
wire bank_TtlSeekInc_p___drv;
wire bank_TtlTerm_p___drv;
wire bank_XmtData_p___drv;
assign bank_q={bank_XmtData_p___drv,bank_TtlTerm_p___drv,bank_TtlSeekInc_p___drv,bank_TtlSector_p___drv,bank_TtlReady_p___drv,bank_TtlReadOnly_p___drv,bank_TtlOnLine_p___drv,bank_TtlOffSet_p___drv,bank_TtlIndex_p___drv,bank_TtlEndOfCyl_p___drv,bank_TtlDeviceCk_p___drv,bank_TagBus_9_p___drv,bank_TagBus_8_p___drv,bank_TagBus_7_p___drv,bank_TagBus_6_p___drv,bank_TagBus_5_p___drv,bank_TagBus_4_p___drv,bank_TagBus_3_p___drv,bank_TagBus_2_p___drv,bank_TagBus_1_p___drv,bank_TagBus_000_p___drv,bank_TagBus_00_p___drv,bank_TagBus_0_p___drv,bank_TWReq_12__drv,bank_TWReq_07__drv,bank_TWReq_06__drv,bank_Selected3_p___drv,bank_Selected2_p___drv,bank_Selected1_p___drv,bank_Selected0_p___drv,bank_Select3_p___drv,bank_Select2_p___drv,bank_Select1_p___drv,bank_Select0_p___drv,bank_SecIndx3_p___drv,bank_SecIndx2_p___drv,bank_SecIndx1_p___drv,bank_SecIndx0_p___drv,bank_OS3__drv,bank_OS2__drv,bank_OS1__drv,bank_OS0__drv,bank_OKToSelect__drv,bank_IOatt__drv,bank_IOB_17__drv,bank_IOB_16__drv,bank_IOB_15__drv,bank_IOB_14__drv,bank_IOB_13__drv,bank_IOB_12__drv,bank_IOB_11__drv,bank_IOB_10__drv,bank_IOB_09__drv,bank_IOB_08__drv,bank_IOB_07__drv,bank_IOB_06__drv,bank_IOB_05__drv,bank_IOB_04__drv,bank_IOB_03__drv,bank_IOB_02__drv,bank_IOB_01__drv,bank_IOB_00__drv,bank_HeadTag_p___drv,bank_DriveTag_p___drv,bank_DataP3__drv,bank_DataP2__drv,bank_DataP1__drv,bank_DataP0__drv,bank_DataM3__drv,bank_DataM2__drv,bank_DataM1__drv,bank_DataM0__drv,bank_DMuxData__drv,bank_CylinderTag_p___drv,bank_ContTag_p___drv,bank_ClockP3__drv,bank_ClockP2__drv,bank_ClockP1__drv,bank_ClockP0__drv,bank_ClockM3__drv,bank_ClockM2__drv,bank_ClockM1__drv,bank_ClockM0__drv,bank_receive_debug};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 DskEth_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 DskEth_m_Rev_m_Cf_rxmonitor #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.BNTGtCT_p_b(stimulus_r[0]),
.Block(stimulus_r[1]),
.CLK_disk_p_(stimulus_r[2]),
.CLKEnable_p_a(stimulus_r[3]),
.ClockM0(stimulus_r[4] | bank_ClockM0__drv),
.ClockM1(stimulus_r[5] | bank_ClockM1__drv),
.ClockM2(stimulus_r[6] | bank_ClockM2__drv),
.ClockM3(stimulus_r[7] | bank_ClockM3__drv),
.ClockP0(stimulus_r[8] | bank_ClockP0__drv),
.ClockP1(stimulus_r[9] | bank_ClockP1__drv),
.ClockP2(stimulus_r[10] | bank_ClockP2__drv),
.ClockP3(stimulus_r[11] | bank_ClockP3__drv),
.Collision(stimulus_r[12]),
.DMuxClk(stimulus_r[13]),
.DMuxData(stimulus_r[14] | bank_DMuxData__drv),
.DataM0(stimulus_r[15] | bank_DataM0__drv),
.DataM1(stimulus_r[16] | bank_DataM1__drv),
.DataM2(stimulus_r[17] | bank_DataM2__drv),
.DataM3(stimulus_r[18] | bank_DataM3__drv),
.DataP0(stimulus_r[19] | bank_DataP0__drv),
.DataP1(stimulus_r[20] | bank_DataP1__drv),
.DataP2(stimulus_r[21] | bank_DataP2__drv),
.DataP3(stimulus_r[22] | bank_DataP3__drv),
.Host_0(stimulus_r[23]),
.Host_1(stimulus_r[24]),
.Host_2(stimulus_r[25]),
.Host_3(stimulus_r[26]),
.Host_4(stimulus_r[27]),
.Host_5(stimulus_r[28]),
.Host_6(stimulus_r[29]),
.Host_7(stimulus_r[30]),
.IOB_00(stimulus_r[31] | bank_IOB_00__drv),
.IOB_01(stimulus_r[32] | bank_IOB_01__drv),
.IOB_02(stimulus_r[33] | bank_IOB_02__drv),
.IOB_03(stimulus_r[34] | bank_IOB_03__drv),
.IOB_04(stimulus_r[35] | bank_IOB_04__drv),
.IOB_05(stimulus_r[36] | bank_IOB_05__drv),
.IOB_06(stimulus_r[37] | bank_IOB_06__drv),
.IOB_07(stimulus_r[38] | bank_IOB_07__drv),
.IOB_08(stimulus_r[39] | bank_IOB_08__drv),
.IOB_09(stimulus_r[40] | bank_IOB_09__drv),
.IOB_10(stimulus_r[41] | bank_IOB_10__drv),
.IOB_11(stimulus_r[42] | bank_IOB_11__drv),
.IOB_12(stimulus_r[43] | bank_IOB_12__drv),
.IOB_13(stimulus_r[44] | bank_IOB_13__drv),
.IOB_14(stimulus_r[45] | bank_IOB_14__drv),
.IOB_15(stimulus_r[46] | bank_IOB_15__drv),
.IOB_16(stimulus_r[47] | bank_IOB_16__drv),
.IOB_17(stimulus_r[48] | bank_IOB_17__drv),
.IOHold(stimulus_r[49]),
.IOReset(stimulus_r[50]),
.IOin_p_(stimulus_r[51]),
.IOout_p_(stimulus_r[52]),
.MemSH_p_(stimulus_r[53]),
.Next_0(stimulus_r[54]),
.Next_1(stimulus_r[55]),
.Next_2(stimulus_r[56]),
.Next_3(stimulus_r[57]),
.OKToSelect(stimulus_r[58] | bank_OKToSelect__drv),
.OS0(stimulus_r[59] | bank_OS0__drv),
.OS1(stimulus_r[60] | bank_OS1__drv),
.OS2(stimulus_r[61] | bank_OS2__drv),
.OS3(stimulus_r[62] | bank_OS3__drv),
.Pendulum(stimulus_r[63]),
.RcvData(stimulus_r[64]),
.SecIndx0_p_(stimulus_r[65] | bank_SecIndx0_p___drv),
.SecIndx1_p_(stimulus_r[66] | bank_SecIndx1_p___drv),
.SecIndx2_p_(stimulus_r[67] | bank_SecIndx2_p___drv),
.SecIndx3_p_(stimulus_r[68] | bank_SecIndx3_p___drv),
.Selected0_p_(stimulus_r[69] | bank_Selected0_p___drv),
.Selected1_p_(stimulus_r[70] | bank_Selected1_p___drv),
.Selected2_p_(stimulus_r[71] | bank_Selected2_p___drv),
.Selected3_p_(stimulus_r[72] | bank_Selected3_p___drv),
.TIOA_0(stimulus_r[73]),
.TIOA_1(stimulus_r[74]),
.TIOA_2(stimulus_r[75]),
.TIOA_3(stimulus_r[76]),
.TIOA_4(stimulus_r[77]),
.TIOA_5(stimulus_r[78]),
.TIOA_6(stimulus_r[79]),
.TIOA_7(stimulus_r[80]),
.TempRef(stimulus_r[81]),
.TtlDeviceCk_p_(stimulus_r[82] | bank_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p_(stimulus_r[83] | bank_TtlEndOfCyl_p___drv),
.TtlIndex_p_(stimulus_r[84] | bank_TtlIndex_p___drv),
.TtlOffSet_p_(stimulus_r[85] | bank_TtlOffSet_p___drv),
.TtlOnLine_p_(stimulus_r[86] | bank_TtlOnLine_p___drv),
.TtlReadOnly_p_(stimulus_r[87] | bank_TtlReadOnly_p___drv),
.TtlReady_p_(stimulus_r[88] | bank_TtlReady_p___drv),
.TtlSector_p_(stimulus_r[89] | bank_TtlSector_p___drv),
.TtlSeekInc_p_(stimulus_r[90] | bank_TtlSeekInc_p___drv),
.TtlTerm_p_(stimulus_r[91] | bank_TtlTerm_p___drv),
.receive_debug(bank_receive_debug),
.ClockM0__drv(bank_ClockM0__drv),
.ClockM1__drv(bank_ClockM1__drv),
.ClockM2__drv(bank_ClockM2__drv),
.ClockM3__drv(bank_ClockM3__drv),
.ClockP0__drv(bank_ClockP0__drv),
.ClockP1__drv(bank_ClockP1__drv),
.ClockP2__drv(bank_ClockP2__drv),
.ClockP3__drv(bank_ClockP3__drv),
.ContTag_p___drv(bank_ContTag_p___drv),
.CylinderTag_p___drv(bank_CylinderTag_p___drv),
.DMuxData__drv(bank_DMuxData__drv),
.DataM0__drv(bank_DataM0__drv),
.DataM1__drv(bank_DataM1__drv),
.DataM2__drv(bank_DataM2__drv),
.DataM3__drv(bank_DataM3__drv),
.DataP0__drv(bank_DataP0__drv),
.DataP1__drv(bank_DataP1__drv),
.DataP2__drv(bank_DataP2__drv),
.DataP3__drv(bank_DataP3__drv),
.DriveTag_p___drv(bank_DriveTag_p___drv),
.HeadTag_p___drv(bank_HeadTag_p___drv),
.IOB_00__drv(bank_IOB_00__drv),
.IOB_01__drv(bank_IOB_01__drv),
.IOB_02__drv(bank_IOB_02__drv),
.IOB_03__drv(bank_IOB_03__drv),
.IOB_04__drv(bank_IOB_04__drv),
.IOB_05__drv(bank_IOB_05__drv),
.IOB_06__drv(bank_IOB_06__drv),
.IOB_07__drv(bank_IOB_07__drv),
.IOB_08__drv(bank_IOB_08__drv),
.IOB_09__drv(bank_IOB_09__drv),
.IOB_10__drv(bank_IOB_10__drv),
.IOB_11__drv(bank_IOB_11__drv),
.IOB_12__drv(bank_IOB_12__drv),
.IOB_13__drv(bank_IOB_13__drv),
.IOB_14__drv(bank_IOB_14__drv),
.IOB_15__drv(bank_IOB_15__drv),
.IOB_16__drv(bank_IOB_16__drv),
.IOB_17__drv(bank_IOB_17__drv),
.IOatt__drv(bank_IOatt__drv),
.OKToSelect__drv(bank_OKToSelect__drv),
.OS0__drv(bank_OS0__drv),
.OS1__drv(bank_OS1__drv),
.OS2__drv(bank_OS2__drv),
.OS3__drv(bank_OS3__drv),
.SecIndx0_p___drv(bank_SecIndx0_p___drv),
.SecIndx1_p___drv(bank_SecIndx1_p___drv),
.SecIndx2_p___drv(bank_SecIndx2_p___drv),
.SecIndx3_p___drv(bank_SecIndx3_p___drv),
.Select0_p___drv(bank_Select0_p___drv),
.Select1_p___drv(bank_Select1_p___drv),
.Select2_p___drv(bank_Select2_p___drv),
.Select3_p___drv(bank_Select3_p___drv),
.Selected0_p___drv(bank_Selected0_p___drv),
.Selected1_p___drv(bank_Selected1_p___drv),
.Selected2_p___drv(bank_Selected2_p___drv),
.Selected3_p___drv(bank_Selected3_p___drv),
.TWReq_06__drv(bank_TWReq_06__drv),
.TWReq_07__drv(bank_TWReq_07__drv),
.TWReq_12__drv(bank_TWReq_12__drv),
.TagBus_0_p___drv(bank_TagBus_0_p___drv),
.TagBus_00_p___drv(bank_TagBus_00_p___drv),
.TagBus_000_p___drv(bank_TagBus_000_p___drv),
.TagBus_1_p___drv(bank_TagBus_1_p___drv),
.TagBus_2_p___drv(bank_TagBus_2_p___drv),
.TagBus_3_p___drv(bank_TagBus_3_p___drv),
.TagBus_4_p___drv(bank_TagBus_4_p___drv),
.TagBus_5_p___drv(bank_TagBus_5_p___drv),
.TagBus_6_p___drv(bank_TagBus_6_p___drv),
.TagBus_7_p___drv(bank_TagBus_7_p___drv),
.TagBus_8_p___drv(bank_TagBus_8_p___drv),
.TagBus_9_p___drv(bank_TagBus_9_p___drv),
.TtlDeviceCk_p___drv(bank_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p___drv(bank_TtlEndOfCyl_p___drv),
.TtlIndex_p___drv(bank_TtlIndex_p___drv),
.TtlOffSet_p___drv(bank_TtlOffSet_p___drv),
.TtlOnLine_p___drv(bank_TtlOnLine_p___drv),
.TtlReadOnly_p___drv(bank_TtlReadOnly_p___drv),
.TtlReady_p___drv(bank_TtlReady_p___drv),
.TtlSector_p___drv(bank_TtlSector_p___drv),
.TtlSeekInc_p___drv(bank_TtlSeekInc_p___drv),
.TtlTerm_p___drv(bank_TtlTerm_p___drv),
.XmtData_p___drv(bank_XmtData_p___drv)
);
endmodule
