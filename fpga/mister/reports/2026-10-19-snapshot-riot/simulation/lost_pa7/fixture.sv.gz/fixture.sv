module riot_fixture(
 input host_clk,ref_clk,advance,freeze,held,request,write,
 input [7:0] index,input [17:0] data,input [36:0] pins,
 output frozen,done,error,output [17:0] result,
 output [1096:0] physical,original_state,
 output [25:0] outputs,original_outputs);
 M6532_snapshot #(.init_7800(0)) candidate(
 .state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request),.state_write(write),.state_index(index),.state_data(data),
 .state_frozen(frozen),.state_done(done),.state_error(error),.state_result(result),
 .clk(ref_clk),.ce(pins[0]),.res_n(pins[1]),.addr(pins[8:2]),.RW_n(pins[9]),.d_in(pins[17:10]),.RS_n(pins[18]),.CS1(pins[19]),.CS2_n(pins[20]),.PA_in(pins[28:21]),.PB_in(pins[36:29]),.d_out(outputs[7:0]),.PA_out(outputs[15:8]),.PB_out(outputs[23:16]),.IRQ_n(outputs[24]),.oe(outputs[25]));
 M6532 #(.init_7800(0)) original(.clk(ref_clk),.ce(pins[0]),.res_n(pins[1]),.addr(pins[8:2]),.RW_n(pins[9]),.d_in(pins[17:10]),.RS_n(pins[18]),.CS1(pins[19]),.CS2_n(pins[20]),.PA_in(pins[28:21]),.PB_in(pins[36:29]),.d_out(original_outputs[7:0]),.PA_out(original_outputs[15:8]),.PB_out(original_outputs[23:16]),.IRQ_n(original_outputs[24]),.oe(original_outputs[25]));
 genvar i;generate for(i=0;i<128;i=i+1)begin:ram
  assign physical[8*i+:8]=candidate.riot_ram[i];
  assign original_state[8*i+:8]=original.riot_ram[i];
 end endgenerate
 assign physical[1096:1024]={candidate.old_pa7,candidate.rollover,candidate.edge_detect,candidate.irq_en,candidate.incr,candidate.prescaler,candidate.timer,candidate.interrupt,candidate.dir_b,candidate.dir_a,candidate.out_b,candidate.out_a,candidate.d_out};
 assign original_state[1096:1024]={original.riot_stuff.old_pa7,original.rollover,original.edge_detect,original.irq_en,original.incr,original.prescaler,original.timer,original.interrupt,original.dir_b,original.dir_a,original.out_b,original.out_a,original.d_out};
 endmodule
