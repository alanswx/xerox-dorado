from pathlib import Path
import hashlib,json,subprocess,tarfile
packet=Path('/home/alans/mister/dorado-serial70-memory-fanout-20261020.tar.gz')
assert hashlib.sha256(packet.read_bytes()).hexdigest()=='44f2fab19f72c114d57b3891abaf45ca44af98cd1e67a1d18f8cce038a115dd7'
project=Path('/home/alans/mister/Dorado_Serial70MemoryFanout_20261020')
assert not project.exists(),'Observe existing job; do not restart'
project.mkdir()
with tarfile.open(packet)as archive:archive.extractall(project,filter='data')
r=json.loads((project/'fanout-integration.json').read_text())
assert r['project']==str(project)and len(r['source_hashes'])==660 and r['native_memory_pause']and r['max_fanout']==256 and not r['assembly_permitted']
for n,d in r['source_hashes'].items():assert hashlib.sha256((project/n).read_bytes()).hexdigest()==d,n
(project/'remote-preflight.json').write_text(json.dumps(dict(status='PASS',packet_sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),prepared_inputs=660,no_assembly=True),indent=2)+'\n')
with(project/'driver.log').open('w')as log:
 p=subprocess.Popen(['python3',str(project/'tools/fpga/mister/snapshot/build_serial_fanout.py'),'--run',str(project)],cwd=project,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(project/'driver.pid').write_text(str(p.pid)+'\n')
print(json.dumps(dict(pid=p.pid,project=str(project))))
