from pathlib import Path
import hashlib,json,time
root=Path('/home/alans/mister/Dorado_Serial70MemoryFanout_20261020');pid=2602043
assert Path('/proc/'+str(pid)).exists(),'Builder no longer live: inspect terminal state'
record=json.loads((root/'fanout-integration.json').read_text())
changed=[n for n,d in record['source_hashes'].items()if hashlib.sha256((root/n).read_bytes()).hexdigest()!=d]
children=(Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()
processes={p:(Path('/proc')/p/'cmdline').read_bytes().replace(b'\0',b' ').decode()for p in [str(pid),*children]}
assert len(record['source_hashes'])==660 and not changed
result=dict(status='LIVE_SOURCE_STABILITY',builder_pid=pid,processes=processes,prepared_inputs=660,prepared_inputs_changed=changed,observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),assembly_permitted=False)
(root/'post-map-source-stability.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
