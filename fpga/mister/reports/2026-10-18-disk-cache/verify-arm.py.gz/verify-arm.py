import json,os,subprocess
from pathlib import Path
image=Path('/tmp/dorado-disk-adapter-v2-termination.pack')
assert not image.exists()
env=dict(os.environ,DORADO_DISK_TRACE='/tmp/dorado-disk-adapter-v2-termination.jsonl')
r=subprocess.run(['/tmp/dorado-disk-adapter-arm-v2','term',str(image)],env=env,timeout=30)
assert r.returncode==143,r
assert image.read_bytes()==Path(str(image)+'.expected').read_bytes()
print('DISK-ADAPTER ARM TERMINATION PASS: SIGTERM during slow write preserves all accepted data')
summary={}
for name in ('normal','error','termination'):
 rows=[json.loads(x) for x in Path('/tmp/dorado-disk-adapter-v2-'+name+'.jsonl').read_text().splitlines()]
 assert not any(x['event']=='trace_dropped' for x in rows),name
 start=next(x for x in rows if x['event']=='pwrite_begin'); end=next(x for x in rows if x['event']=='pwrite_end')
 assert end['duration_ns']>=4100000000,(name,end)
 active=[x for x in rows if start['ns']<x['ns']<end['ns']]
 counts={kind:sum(x['event']==kind for x in active) for kind in ('read_ack','write_ack','poll')}
 assert counts['read_ack']>100 and counts['write_ack']>100 and counts['poll']>=2,(name,counts)
 if name=='error': assert any(x['event']=='pwrite_error' and x['result']==28 for x in rows) and any(x['event']=='barrier_error' for x in rows)
 else: assert any(x['event']=='barrier_end' for x in rows)
 summary[name]={'trace_events':len(rows),'first_pwrite_ns':end['duration_ns'],'progress_during_write':counts,'max_recorded_poll_gap_ns':max([x['duration_ns'] for x in rows if x['event']=='poll_gap']+[0])}
print('DISK-ADAPTER ARM TRACE PASS',json.dumps(summary,sort_keys=True))
Path('/tmp/dorado-disk-adapter-v2-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
