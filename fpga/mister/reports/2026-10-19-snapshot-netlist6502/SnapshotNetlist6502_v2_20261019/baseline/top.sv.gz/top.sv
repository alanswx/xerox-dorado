module snapshot_fit(
 input wire host_clk,advance,freeze,held,request,write,
 input wire [6:0] index,input wire [17:0] data,input wire [13:0] pins,
 output reg [17:0] result,output reg [25:0] outputs,output reg frozen,done,error);
 reg [43:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,request,write,index,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;wire [6:0] index_r;wire [17:0] data_r;wire [13:0] pins_r;
 assign {step_r,freeze_r,held_r,request_r,write_r,index_r,data_r,pins_r}=launch;
 wire [17:0] result_w;wire [25:0] outputs_w;wire frozen_w,done_w,error_w;
 always @(posedge host_clk){result,outputs,frozen,done,error}<={result_w,outputs_w,frozen_w,done_w,error_w};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 chip_6502_snapshot cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w),.state_done(done_w),.state_error(error_w),.state_result(result_w),
`else
 assign {frozen_w,done_w,error_w,result_w}=21'b0;
 chip_6502 cell_inst(
`endif
 .clk(host_clk),.phi(pins_r[0]),.res(pins_r[1]),.so(pins_r[2]),.rdy(pins_r[3]),
 .nmi(pins_r[4]),.irq(pins_r[5]),.dbi(pins_r[13:6]),.dbo(outputs_w[7:0]),
 .rw(outputs_w[8]),.sync(outputs_w[9]),.ab(outputs_w[25:10]));
endmodule
