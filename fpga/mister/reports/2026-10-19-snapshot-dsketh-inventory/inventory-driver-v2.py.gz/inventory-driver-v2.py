from pathlib import Path
import collections,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
root=Path('/Users/alans/dev2/Dorado');sys.path.insert(0,str(root/'tools'));from sil_state_inventory import inventory,constant
src=root/'build/rtl-executive/native57-dispy-baseline-src';out=root/'build/rtl-executive/snapshot-dsketh-inventory-v2-20261019';out.mkdir(exist_ok=False)
source=src/'verilog/generated/DskEth-Rev-Cf.v';monitor=src/'fpga/mister/dorado_receive_monitor.sv';cells=sorted((src/'verilog/cells').glob('*.v'))
cmd=['verilator','--xml-only','--top-module','DskEth_m_Rev_m_Cf_rxmonitor','-GSYSPER=4','-Wno-fatal','-DDORADO_F10145_LOGIC','-DDORADO_F10415_M10K','--xml-output',str(out/'dsketh.xml'),str(source),str(monitor),*map(str,cells)]
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with(out/'elaborate.log').open('w')as f:subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT,check=True)
r=inventory((out/'dsketh.xml').read_bytes());(out/'inventory.json').write_text(json.dumps(r,indent=2)+'\n')
by=collections.defaultdict(lambda:dict(entries=0,bits=0,fields={},packages=set()))
for row in r['candidates']:
 if row['category']!='sequential':continue
 q=by[row['module']];q['entries']+=1;q['bits']+=row['bits'];q['fields'][row['name']]=row['bits'];q['packages'].add(row['path'].rsplit('.',1)[0])
for q in by.values():q['packages']=sorted(q['packages'])
x=ET.fromstring((out/'dsketh.xml').read_bytes());bindings=[]
for mod in x.findall('.//module'):
 if mod.get('origName')not in('cell_K1115A','cell_SN74123','cell_F9401','DskEth_m_Rev_m_Cf_rxmonitor'):continue
 params={v.get('name'):constant(v.find('const').get('name'))for v in mod.findall('var')if (v.get('param')=='true'or v.get('localparam')=='true')and v.find('const')is not None}
 bindings.append(dict(module=mod.get('name'),parameters=params))
(out/'sequential-review.json').write_text(json.dumps(dict(status='REVIEW ONLY',sequential=by,bindings=bindings,scope='Frozen actual57 DskEth rxmonitor with explicit SYSPER4 and actual receive-monitor module; external backend/ARM state excluded'),indent=2)+'\n')
(out/'provenance.json').write_text(json.dumps(dict(source_hashes={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [source,monitor,*cells]},tool_sha256=hashlib.sha256((root/'tools/sil_state_inventory.py').read_bytes()).hexdigest()),indent=2)+'\n')
print('DskEth sequential bits',sum(q['bits']for q in by.values()));print(bindings)
