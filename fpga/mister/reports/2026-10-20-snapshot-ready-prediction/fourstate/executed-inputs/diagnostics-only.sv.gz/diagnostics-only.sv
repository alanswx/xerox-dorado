    // synthesis translate_off
    always @(posedge host_clk)if(!state_hold && state_guest_advance)begin
        if(!ready)$fatal(1,"Dorado clock advanced while compact storage stalled");
        if(write_pending && (cas_d || we_d))$fatal(1,"Pending storage write has inconsistent DRAM controls");
        if(!ras_n && !cas_n && !we_n && (cas_d || we_d) && req_valid)
            $fatal(1,"Storage write_data changed while request was enabled");
    end
    // synthesis translate_on
