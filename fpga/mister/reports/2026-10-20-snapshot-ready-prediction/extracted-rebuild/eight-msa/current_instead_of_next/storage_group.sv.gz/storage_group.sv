// Experimental compact frontend. Original DRAM guest pipeline retained.
`default_nettype none
module dorado_serial_MSA__dorado_storage_group_snapshot #(
    parameter integer ADDR_BITS=16, WIDTH=8
) (
    input wire state_guest_advance,state_hold,state_scan_step,state_serial_in,
    output wire state_serial_out,state_drain_ready,state_flags_ready_next,
    output reg state_frozen=1'b0,
    input wire host_clk,machine_clk,reset,
    input wire ras_n,cas_n,we_n,addr_will_change,
    input wire [ADDR_BITS-1:0] addr,
    input wire [WIDTH-1:0] data_in,
    output reg [WIDTH-1:0] data_out=0,
    output wire ready,req_valid,
    input wire req_ready,
    output wire req_write,
    output wire [ADDR_BITS-1:0] req_addr,
    output wire [15:0] req_data,
    input wire rsp_valid,
    output wire rsp_ready,
    input wire [15:0] rsp_data
);
    reg cas_d=0,we_d=0,write_pending=0;
    reg [WIDTH-1:0] write_data=0,read_pipe=0;
    reg cache_valid=0,write_done=0,waiting=0;
    reg [WIDTH-1:0] cache_data=0;
    wire normal_ready=!reset && !waiting && cache_valid && (!write_pending || write_done);
    wire normal_req_valid=!reset && !waiting && (!cache_valid || (write_pending && !write_done));
    assign ready=normal_ready && !state_hold;
    assign req_valid=normal_req_valid && !state_hold;
    assign rsp_ready=waiting && !state_hold;
    assign state_drain_ready=normal_ready && !normal_req_valid;
    assign req_write=cache_valid && write_pending && !write_done;
    assign req_addr=addr;
    assign req_data={{(16-WIDTH){1'b0}},write_data};
    wire [15:0] read_value=cache_data;
    localparam integer STATE_BITS=6+4*WIDTH;
    wire [STATE_BITS-1:0] state_bits={cache_data,waiting,write_done,cache_valid,data_out,read_pipe,write_data,write_pending,we_d,cas_d};
    assign state_serial_out=state_bits[0];
    // Pure prediction of the original four post-edge readiness flags.
    // Automatic locals carry no history; all original clocked writes remain.
    function automatic [3:0] ready_flags_after_edge(
        input [3:0] current_flags,scan_flags,
        input held,scan,advance,reset_now,write_start,address_change,
        input accepted,response,write_kind
    );
        reg [3:0] next_flags;
        begin
            next_flags=current_flags;
            if(held)begin
                if(scan)next_flags=scan_flags;
            end else begin
                if(advance)next_flags[0]=write_start;
                if(reset_now)next_flags[3:1]=3'b000;
                else begin
                    if(!current_flags[0])next_flags[2]=0;
                    if(advance)begin
                        if(address_change)next_flags[1]=0;
                    end
                    if(accepted)next_flags[3]=1;
                    if(response)begin
                        next_flags[3]=0;next_flags[1]=1;
                        if(write_kind)next_flags[2]=1;
                    end
                end
            end
            ready_flags_after_edge=next_flags;
        end
    endfunction
    wire [3:0] ready_flags_next=ready_flags_after_edge(
        {waiting,write_done,cache_valid,write_pending},
        {state_bits[6+3*WIDTH],state_bits[5+3*WIDTH],state_bits[4+3*WIDTH],state_bits[3]},
        state_hold,state_scan_step,state_guest_advance,reset,
        !ras_n && !cas_n && !we_n && (cas_d || we_d),addr_will_change,
        req_valid && req_ready,waiting && rsp_valid,req_write);
    // A live reset is intentionally excluded. Higher-level reset and storage
    // initialization still mask the registered aggregate before any advance.
    assign state_flags_ready_next=!waiting && cache_valid && (!write_pending || write_done);
    always @(posedge host_clk)state_frozen<=state_hold;
    always @(posedge host_clk)begin
        if(state_hold)begin
            if(state_scan_step){cache_data,waiting,write_done,cache_valid,data_out,read_pipe,write_data,write_pending,we_d,cas_d}<={state_serial_in,state_bits[STATE_BITS-1:1]};
        end else begin
            if(state_guest_advance)begin
        cas_d<=cas_n;we_d<=we_n;
        write_pending<=!ras_n && !cas_n && !we_n && (cas_d || we_d);
        if(!ras_n && !cas_n && !we_n && (cas_d || we_d))write_data<=data_in;
        read_pipe<=read_value[WIDTH-1:0];
        if(!ras_n && !cas_n && we_n)data_out<=read_pipe;
            end
            if(reset)begin
                cache_valid<=0;write_done<=0;waiting<=0;
                if(write_pending && write_done)cache_data<=req_data[WIDTH-1:0];
            end else begin
                if(!write_pending)write_done<=0;
                if(state_guest_advance)begin
                    if(addr_will_change)cache_valid<=0;
                    if(write_pending && write_done)cache_data<=req_data[WIDTH-1:0];
                end
                if(req_valid && req_ready)waiting<=1;
                if(waiting && rsp_valid)begin
                    waiting<=0;cache_valid<=1;
                    if(req_write)write_done<=1;
                    else cache_data<=rsp_data[WIDTH-1:0];
                end
            end
        end
    end
    generate if(ADDR_BITS!=16 || (WIDTH!=8 && WIDTH!=12))begin:unqualified_geometry
        initial $fatal(1,"Compact frontend requires address16/width8-or-12");
    end endgenerate
    // synthesis translate_off
    always @(posedge host_clk)if(!state_hold && state_guest_advance)begin
        if(!ready)$fatal(1,"Dorado clock advanced while compact storage stalled");
        if(write_pending && (cas_d || we_d))$fatal(1,"Pending storage write has inconsistent DRAM controls");
        if(!ras_n && !cas_n && !we_n && (cas_d || we_d) && req_valid)
            $fatal(1,"Storage write_data changed while request was enabled");
    end
    // synthesis translate_on
endmodule
`default_nettype wire
