`timescale 1ns/1ps
module processor_capture_reference(input wire fixture_load,input wire [63:0] fixture_state,
 input wire base,input wire [27:0] pins,output wire [63:0] state_q,
 output wire [21:0] clocks,output wire [8:0] flags);
 wire [2:0] bases;
 cell_MC10210 base_fanout(.p7(base),.p11(base),.p5(1'b0),.p6(1'b0),.p9(1'b0),.p10(1'b0),
   .p2(bases[2]),.p12(bases[1]),.p13(bases[0]));
 wire [11:0] cc;wire [4:0] ch,cl;wire [5:0] fc;wire [2:0] fh,fl;
 wire en_h=fc[3],en_l=fc[4],start_a=fc[5];
 capture_conta c(fixture_load,fixture_state[31:0],bases[2],1'b0,1'b0,pins,state_q[31:0],cc,fc);
 capture_proch h(fixture_load,fixture_state[47:32],bases[1],start_a,en_h,pins,state_q[47:32],ch,fh);
 capture_procl l(fixture_load,fixture_state[63:48],bases[0],start_a,en_l,pins,state_q[63:48],cl,fl);
 assign clocks={cc[11:9],cl,ch,cc[8:0]};assign flags={fl,fh,fc[2:0]};
endmodule
