`timescale 1ns/1ps
`default_nettype none
module t_file_procl(input wire fixture_load,input wire [161:0] fixture_state,
 input wire base,start_a,en,input wire [116:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,
 output wire [161:0] state_q,output wire [8:0] clocks,
 output wire [2:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock0'Bd
 wire n15; // Clock0'Da
 wire n16; // Clock0'Db
 wire n17; // Clock0'Dc
 wire n18; // Clock1'Ba
 wire n19; // Clock1'Bb
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Da
 wire n23; // Clock1'Db
 wire n24; // Clock1'Dc
 wire n25; // Clock1Bd
 wire n26; // Curr.0'
 wire n27; // Curr.1'
 wire n28; // Curr.2'
 wire n29; // Curr.3'
 wire n30; // Curr=Next'
 wire n31; // CurrLast.0'
 wire n32; // CurrLast.1'
 wire n33; // CurrLast.2'
 wire n34; // CurrLast.3'
 wire n35; // DblClock'Ba
 wire n36; // DblClock'Bc
 wire n37; // FA=0'b
 wire n38; // FB=2'
 wire n39; // FB=3'
 wire n40; // FB=7'
 wire n41; // FC=4/5'
 wire n42; // FC=5'
 wire n43; // FC=6'
 wire n44; // GND132
 wire n45; // GND264
 wire n46; // GND266
 wire n47; // GND312
 wire n48; // GND314
 wire n49; // GND394
 wire n50; // GND40
 wire n51; // GND442
 wire n52; // GND468
 wire n53; // GND500
 wire n54; // GND530
 wire n55; // Hold
 wire n56; // Hold'
 wire n57; // HoldDly
 wire n58; // Holda
 wire n59; // IOB.Perr'
 wire n60; // IOBin'
 wire n61; // IOBout
 wire n62; // IOin'
 wire n63; // LC.0
 wire n64; // LC.1
 wire n65; // LC.1'a
 wire n66; // LC.1a
 wire n67; // LC.2
 wire n68; // LScopeFH
 wire n69; // Last.0'
 wire n70; // Last.1'
 wire n71; // Last.2'
 wire n72; // Last.3'
 wire n73; // Last=Curr'
 wire n74; // LastNext.0'
 wire n75; // LastNext.1'
 wire n76; // LastNext.2'
 wire n77; // LastNext.3'
 wire n78; // Next.0
 wire n79; // Next.0'
 wire n80; // Next.1
 wire n81; // Next.1'
 wire n82; // Next.2
 wire n83; // Next.2'
 wire n84; // Next.3
 wire n85; // Next.3'
 wire n86; // PRhold
 wire n87; // Pdata.08
 wire n88; // Pdata.09
 wire n89; // Pdata.10
 wire n90; // Pdata.11
 wire n91; // Pdata.12
 wire n92; // Pdata.13
 wire n93; // Pdata.14
 wire n94; // Pdata.15
 wire n95; // PreClock0'A
 wire n96; // PreClock0'B
 wire n97; // PreClock0'C
 wire n98; // PreClock0'D
 wire n99; // PreClock1'A
 wire n100; // PreClock1'B
 wire n101; // PreClock1'C
 wire n102; // PreClock1'D
 wire n103; // PreClock1B
 wire n104; // PreDblClock'B
 wire n105; // PreSHCP'A
 wire n106; // PreSHCP'B
 wire n107; // PreSHCP'C
 wire n108; // PreSHCP'Shc
 wire n109; // PreSHSelect'D
 wire n110; // ProcL02.sil+5
 wire n111; // ProcL03.sil+5
 wire n112; // ProcL04.sil+5
 wire n113; // ProcL05.sil+5
 wire n114; // ProcL06.sil+5
 wire n115; // ProcL07.sil+5
 wire n116; // ProcL08.sil+5
 wire n117; // ProcL09.sil+4
 wire n118; // ProcL10.sil+1
 wire n119; // ProcL11.sil+7
 wire n120; // ProcL12.sil+1
 wire n121; // ProcL12.sil+3
 wire n122; // ProcL12.sil+4
 wire n123; // ProcL12.sil+5
 wire n124; // ProcL12.sil+6
 wire n125; // ProcL15.sil+1
 wire n126; // ProcL20.sil+1
 wire n127; // ProcL20.sil+3
 wire n128; // ProcL20.sil+4
 wire n129; // ProcL20.sil+5
 wire n130; // ProcL20.sil+6
 wire n131; // ProcL20.sil+7
 wire n132; // ProcL24.sil+14
 wire n133; // ProcL26.sil+1
 wire n134; // ProcL27.sil+10
 wire n135; // ProcL27.sil+11
 wire n136; // ProcL27.sil+3
 wire n137; // ProcL27.sil+4
 wire n138; // ProcL27.sil+5
 wire n139; // ProcL27.sil+8
 wire n140; // ProcL27.sil+9
 wire n141; // ProcL30.sil+1
 wire n142; // RbSelMd
 wire n143; // RbSelMd'
 wire n144; // RbWrite'a
 wire n145; // RbWrite'b
 wire n146; // RbWrite'c
 wire n147; // RbWriteEn'
 wire n148; // RepeatCurrB
 wire n149; // RepeatCurrC
 wire n150; // RepeatCurrD
 wire n151; // SHCP'C
 wire n152; // SHSelect'C
 wire n153; // SimHoldReq'
 wire n154; // StartCycle'a
 wire n155; // StkWSel'
 wire n156; // TbBypass
 wire n157; // TbSelMd
 wire n158; // TbWrite'a
 wire n159; // TbWrite'b
 wire n160; // TbWriteEn'
 wire n161; // TisIFdata
 wire n162; // TrueA
 wire n163; // _MDSaved
 wire n164; // dMD.08
 wire n165; // dMD.09
 wire n166; // dMD.10
 wire n167; // dMD.11
 wire n168; // dMD.12
 wire n169; // dMD.13
 wire n170; // dMD.14
 wire n171; // dMD.15
 wire n172; // dTm.08
 wire n173; // dTm.09
 wire n174; // dTm.10
 wire n175; // dTm.11
 wire n176; // dTm.12
 wire n177; // dTm.13
 wire n178; // dTm.14
 wire n179; // dTm.15
 wire n180; // pClk1En'
 wire n181; // ppClk'a
 wire n182; // ppClk'b
 wire n183; // ppClk'c
 assign n44=1'b0;
 assign n45=1'b0;
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n49=1'b0;
 assign n50=1'b0;
 assign n51=1'b0;
 assign n52=1'b0;
 assign n53=1'b0;
 assign n54=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n37=(pins[19:18]!=2'd0);
 assign n38=(pins[17:15]!=3'd2);
 assign n39=(pins[17:15]!=3'd3);
 assign n40=(pins[17:15]!=3'd7);
 assign n41=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n42=(pins[14:12]!=3'd5);
 assign n43=(pins[14:12]!=3'd6);
 assign n58=pins[68];
 assign n60=1'b0;
 assign n61=1'b0;
 assign n63=pins[11];
 assign n64=pins[10];
 assign n67=pins[9];
 assign n78=next_raw[0];
 assign n80=next_raw[1];
 assign n82=next_raw[2];
 assign n84=next_raw[3];
 assign n86=pins[68];
 assign n87=pins[84];
 assign n88=pins[85];
 assign n89=pins[86];
 assign n90=pins[87];
 assign n91=pins[88];
 assign n92=pins[89];
 assign n93=pins[90];
 assign n94=pins[91];
 assign n131=pins[116];
 assign n132=pins[115];
 assign n133=1'b0;
 assign n134=pins[112];
 assign n135=1'b0;
 assign n139=pins[113];
 assign n140=pins[114];
 assign n154=start_a;
 assign n161=1'b0;
 assign n164=pins[100];
 assign n165=pins[101];
 assign n166=pins[102];
 assign n167=pins[103];
 assign n168=pins[104];
 assign n169=pins[105];
 assign n170=pins[106];
 assign n171=pins[107];
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_k10_3;
 assign n14=n14_k10_3;
 wire n15_j18_3;
 assign n15=n15_j18_3;
 wire n16_j18_2;
 assign n16=n16_j18_2;
 wire n17_j18_4;
 assign n17=n17_j18_4;
 wire n18_i05_3;
 assign n18=n18_i05_3;
 wire n19_i05_4;
 assign n19=n19_i05_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_j18_13;
 assign n22=n22_j18_13;
 wire n23_j18_14;
 assign n23=n23_j18_14;
 wire n24_j18_12;
 assign n24=n24_j18_12;
 wire n25_i05_2;
 assign n25=n25_i05_2;
 wire n26_a21_14;
 assign n26=n26_a21_14;
 wire n27_a21_15;
 assign n27=n27_a21_15;
 wire n28_a21_2;
 assign n28=n28_a21_2;
 wire n29_a21_3;
 assign n29=n29_a21_3;
 wire n30_a22_2;
 wire n30_a22_3;
 wire n30_a22_15;
 wire n30_a22_14;
 assign n30=n30_a22_2 | n30_a22_3 | n30_a22_15 | n30_a22_14;
 wire n31_i14_14;
 assign n31=n31_i14_14;
 wire n32_i14_15;
 assign n32=n32_i14_15;
 wire n33_i14_2;
 assign n33=n33_i14_2;
 wire n34_i14_3;
 assign n34=n34_i14_3;
 wire n35_k10_13;
 assign n35=n35_k10_13;
 wire n36_k10_14;
 assign n36=n36_k10_14;
 wire n55_f19_15;
 assign n55=n55_f19_15;
 wire n56_f19_14;
 assign n56=n56_f19_14;
 wire n57_g18_15;
 assign n57=n57_g18_15;
 wire n59_g23_14;
 assign n59=n59_g23_14;
 wire n62_g23_9;
 assign n62=n62_g23_9;
 wire n65_h24_15;
 assign n65=n65_h24_15;
 wire n66_h24_9;
 assign n66=n66_h24_9;
 wire n68_c18_14;
 assign n68=n68_c18_14;
 wire n69_a20_14;
 assign n69=n69_a20_14;
 wire n70_a20_15;
 assign n70=n70_a20_15;
 wire n71_a20_2;
 assign n71=n71_a20_2;
 wire n72_a20_3;
 assign n72=n72_a20_3;
 wire n73_d17_15;
 assign n73=n73_d17_15;
 wire n74_a19_1;
 assign n74=n74_a19_1;
 wire n75_a19_2;
 assign n75=n75_a19_2;
 wire n76_a19_15;
 assign n76=n76_a19_15;
 wire n77_a19_14;
 assign n77=n77_a19_14;
 wire n79_a24_15;
 assign n79=n79_a24_15;
 wire n81_a24_14;
 assign n81=n81_a24_14;
 wire n83_a24_3;
 assign n83=n83_a24_3;
 wire n85_a24_2;
 assign n85=n85_a24_2;
 wire n95_f13_13;
 assign n95=n95_f13_13;
 wire n96_f13_12;
 assign n96=n96_f13_12;
 wire n97_f13_14;
 assign n97=n97_f13_14;
 wire n98_g13_3;
 assign n98=n98_g13_3;
 wire n99_f12_14;
 assign n99=n99_f12_14;
 wire n100_f13_2;
 assign n100=n100_f13_2;
 wire n101_f13_4;
 assign n101=n101_f13_4;
 wire n102_f13_3;
 assign n102=n102_f13_3;
 wire n103_f12_13;
 assign n103=n103_f12_13;
 wire n104_g13_13;
 assign n104=n104_g13_13;
 wire n105_g12_3;
 assign n105=n105_g12_3;
 wire n106_g12_2;
 assign n106=n106_g12_2;
 wire n107_g12_4;
 assign n107=n107_g12_4;
 wire n108_f12_4;
 assign n108=n108_f12_4;
 wire n109_f12_3;
 assign n109=n109_f12_3;
 wire n110_l03_2;
 assign n110=n110_l03_2;
 wire n111_l03_1;
 assign n111=n111_l03_1;
 wire n112_l03_15;
 assign n112=n112_l03_15;
 wire n113_l03_14;
 assign n113=n113_l03_14;
 wire n114_l04_2;
 assign n114=n114_l04_2;
 wire n115_l04_1;
 assign n115=n115_l04_1;
 wire n116_l04_15;
 assign n116=n116_l04_15;
 wire n117_l04_14;
 assign n117=n117_l04_14;
 wire n118_f20_2;
 assign n118=n118_f20_2;
 wire n119_f20_3;
 assign n119=n119_f20_3;
 wire n120_a24_9;
 wire n120_a24_11;
 wire n120_a24_6;
 wire n120_a24_5;
 assign n120=n120_a24_9 | n120_a24_11 | n120_a24_6 | n120_a24_5;
 wire n121_a18_2;
 assign n121=n121_a18_2;
 wire n122_a18_1;
 assign n122=n122_a18_1;
 wire n123_a18_15;
 assign n123=n123_a18_15;
 wire n124_a18_14;
 assign n124=n124_a18_14;
 wire n125_f20_14;
 assign n125=n125_f20_14;
 wire n126_f20_15;
 wire n126_g23_3;
 assign n126=n126_f20_15 | n126_g23_3;
 wire n127_h23_2;
 assign n127=n127_h23_2;
 wire n128_h23_3;
 assign n128=n128_h23_3;
 wire n129_h23_14;
 assign n129=n129_h23_14;
 wire n130_g23_2;
 assign n130=n130_g23_2;
 wire n136_g18_3;
 assign n136=n136_g18_3;
 wire n137_g18_4;
 assign n137=n137_g18_4;
 wire n138_g18_2;
 assign n138=n138_g18_2;
 wire n141_f12_2;
 assign n141=n141_f12_2;
 wire n142_d17_3;
 assign n142=n142_d17_3;
 wire n143_d17_2;
 assign n143=n143_d17_2;
 wire n144_j05_13;
 assign n144=n144_j05_13;
 wire n145_j05_12;
 assign n145=n145_j05_12;
 wire n146_j05_14;
 assign n146=n146_j05_14;
 wire n147_d17_13;
 assign n147=n147_d17_13;
 wire n148_g12_13;
 assign n148=n148_g12_13;
 wire n149_g12_12;
 assign n149=n149_g12_12;
 wire n150_g12_14;
 assign n150=n150_g12_14;
 wire n151_c18_13;
 assign n151=n151_c18_13;
 wire n152_c18_12;
 assign n152=n152_c18_12;
 wire n153_a01_3;
 assign n153=n153_a01_3;
 wire n155_g18_13;
 assign n155=n155_g18_13;
 wire n156_f19_3;
 assign n156=n156_f19_3;
 wire n157_d17_4;
 assign n157=n157_d17_4;
 wire n158_j05_3;
 assign n158=n158_j05_3;
 wire n159_j05_2;
 assign n159=n159_j05_2;
 wire n160_d17_14;
 assign n160=n160_d17_14;
 wire n162_a01_14;
 assign n162=n162_a01_14;
 wire n163_g18_14;
 assign n163=n163_g18_14;
 wire n172_k01_1;
 assign n172=n172_k01_1;
 wire n173_k01_2;
 assign n173=n173_k01_2;
 wire n174_k01_15;
 assign n174=n174_k01_15;
 wire n175_k01_14;
 assign n175=n175_k01_14;
 wire n176_k02_1;
 assign n176=n176_k02_1;
 wire n177_k02_2;
 assign n177=n177_k02_2;
 wire n178_k02_15;
 assign n178=n178_k02_15;
 wire n179_k02_14;
 assign n179=n179_k02_14;
 wire n180_l02_2;
 assign n180=n180_l02_2;
 wire n181_l01_13;
 assign n181=n181_l01_13;
 wire n182_l01_12;
 assign n182=n182_l01_12;
 wire n183_l01_14;
 assign n183=n183_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n153_a01_3),.p4(n1),.p5(1'b0),.p6(n133),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n162_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n122_a18_1),.p2(n121_a18_2),.p3(n75),.p4(n27),.p5(n74),.p6(n26),.p9(n149),.p10(n77),.p11(n29),.p12(n76),.p13(n28),.p14(n124_a18_14),.p15(n123_a18_15));
 cell_MC10158 a19(.p1(n74_a19_1),.p2(n75_a19_2),.p3(n81),.p4(n70),.p5(n79),.p6(n69),.p9(n107),.p10(n85),.p11(n72),.p12(n83),.p13(n71),.p14(n77_a19_14),.p15(n76_a19_15));
 original_MC10141 a20(.p1(n50),.p2(n71_a20_2),.p3(n72_a20_3),.p4(n20),.p5(1'b0),.p6(n29),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n26),.p13(1'b0),.p14(n69_a20_14),.p15(n70_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n28_a21_2),.p3(n29_a21_3),.p4(n151),.p5(1'b0),.p6(n85),.p7(n149),.p8(1'b0),.p9(n83),.p10(n149),.p11(n81),.p12(n79),.p13(1'b0),.p14(n26_a21_14),.p15(n27_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n30_a22_2),.p3(n30_a22_3),.p4(n29),.p5(n85),.p6(n83),.p7(n28),.p9(1'b0),.p10(n81),.p11(n27),.p12(n79),.p13(n26),.p14(n30_a22_14),.p15(n30_a22_15));
 cell_MC10101 a24(.p2(n85_a24_2),.p3(n83_a24_3),.p4(n84),.p5(n120_a24_5),.p6(n120_a24_6),.p7(n82),.p9(n120_a24_9),.p10(n80),.p11(n120_a24_11),.p12(1'b0),.p13(n78),.p14(n81_a24_14),.p15(n79_a24_15));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p5(n101),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n107),.p10(1'b0),.p11(1'b0),.p12(n152_c18_12),.p13(n151_c18_13),.p14(n68_c18_14),.p15(n44),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n143_d17_2),.p3(n142_d17_3),.p4(n157_d17_4),.p5(n66),.p6(n65),.p7(n126),.p8(1'b0),.p9(n151),.p10(n129),.p11(n130),.p12(n30),.p13(n147_d17_13),.p14(n160_d17_14),.p15(n73_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n141_f12_2),.p3(n109_f12_3),.p4(n108_f12_4),.p5(n180),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n141),.p10(1'b0),.p11(n181),.p13(n103_f12_13),.p14(n99_f12_14),.p15(n45),.p16(1'b0));
 cell_SE10210 f13(.p2(n100_f13_2),.p3(n102_f13_3),.p4(n101_f13_4),.p5(n182),.p6(1'b0),.p7(n141),.p8(1'b0),.p9(n182),.p10(n13),.p11(1'b0),.p12(n96_f13_12),.p13(n95_f13_13),.p14(n97_f13_14),.p15(n46),.p16(1'b0));
 cell_MC1660 f19(.p3(n156_f19_3),.p4(n57),.p5(n73),.p6(n160),.p7(n161),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n86),.p14(n56_f19_14),.p15(n55_f19_15));
 cell_MC10100 f20(.p2(n118_f20_2),.p3(n119_f20_3),.p4(n43),.p5(n38),.p6(n41),.p7(n38),.p9(n37),.p10(n43),.p11(n39),.p12(n42),.p13(n40),.p14(n125_f20_14),.p15(n126_f20_15));
 cell_SE10211 g12(.p2(n106_g12_2),.p3(n105_g12_3),.p4(n107_g12_4),.p5(1'b0),.p6(n180),.p7(1'b0),.p9(n0),.p10(n56),.p11(1'b0),.p12(n149_g12_12),.p13(n148_g12_13),.p14(n150_g12_14),.p15(n47),.p16(1'b0));
 cell_SE10210 g13(.p3(n98_g13_3),.p5(n183),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n183),.p10(1'b0),.p11(1'b0),.p13(n104_g13_13),.p15(n48),.p16(1'b0));
 original_MC10176 g18(.p1(1'b0),.p2(n138_g18_2),.p3(n136_g18_3),.p4(n137_g18_4),.p5(n134),.p6(n139),.p7(n140),.p8(1'b0),.p9(n16),.p10(n132),.p11(n131),.p12(n58),.p13(n155_g18_13),.p14(n163_g18_14),.p15(n57_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10102 g23(.p1(1'b0),.p2(n130_g23_2),.p3(n126_g23_3),.p4(n67),.p5(n128),.p6(n63),.p7(n65),.p9(n62_g23_9),.p10(n61),.p11(n135),.p12(n55),.p13(n60),.p14(n59_g23_14),.p16(1'b0));
 cell_MC10102 h23(.p1(1'b0),.p2(n127_h23_2),.p3(n128_h23_3),.p4(n65),.p5(n67),.p6(n63),.p7(n65),.p9(n10_h23_9),.p10(n63),.p11(n127),.p12(n6),.p13(n9),.p14(n129_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n66_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n64),.p14(n9_h24_14),.p15(n65_h24_15));
 cell_SE10212 i05(.p1(1'b0),.p2(n25_i05_2),.p3(n18_i05_3),.p4(n19_i05_4),.p5(1'b0),.p6(1'b0),.p7(n103),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n49),.p16(1'b0));
 original_MC10141 i14(.p1(1'b0),.p2(n33_i14_2),.p3(n34_i14_3),.p4(n36),.p5(1'b0),.p6(n124),.p7(1'b0),.p8(1'b0),.p9(n123),.p10(1'b0),.p11(n121),.p12(n122),.p13(1'b0),.p14(n31_i14_14),.p15(n32_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_SE10210 j05(.p2(n159_j05_2),.p3(n158_j05_3),.p5(n96),.p6(n57),.p7(n160),.p8(1'b0),.p9(n96),.p10(n57),.p11(n147),.p12(n145_j05_12),.p13(n144_j05_13),.p14(n146_j05_14),.p15(n51),.p16(1'b0));
 cell_SE10210 j18(.p2(n16_j18_2),.p3(n15_j18_3),.p4(n17_j18_4),.p5(n98),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n102),.p10(1'b0),.p11(1'b0),.p12(n24_j18_12),.p13(n22_j18_13),.p14(n23_j18_14),.p15(n52),.p16(1'b0));
 original_MC10173 k01(.p1(n172_k01_1),.p2(n173_k01_2),.p3(n88),.p4(n165),.p5(n87),.p6(n164),.p7(n18),.p9(n157),.p10(n90),.p11(n167),.p12(n89),.p13(n166),.p14(n175_k01_14),.p15(n174_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n176_k02_1),.p2(n177_k02_2),.p3(n92),.p4(n169),.p5(n91),.p6(n168),.p7(n18),.p9(n157),.p10(n94),.p11(n171),.p12(n93),.p13(n170),.p14(n179_k02_14),.p15(n178_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_SE10210 k10(.p3(n14_k10_3),.p5(n96),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n104),.p13(n35_k10_13),.p14(n36_k10_14),.p15(n53),.p16(1'b0));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n154),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n182_l01_12),.p13(n181_l01_13),.p14(n183_l01_14),.p15(n54),.p16(1'b0));
 original_SE10231 l02(.p2(n180_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n111_l03_1),.p2(n110_l03_2),.p3(1'b0),.p4(n173),.p5(n172),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n174),.p12(n175),.p13(n158),.p14(n113_l03_14),.p15(n112_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n115_l04_1),.p2(n114_l04_2),.p3(1'b0),.p4(n177),.p5(n176),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n178),.p12(n179),.p13(n158),.p14(n117_l04_14),.p15(n116_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n151;
 assign clocks[3]=n96;
 assign clocks[4]=n20;
 assign clocks[5]=n36;
 assign clocks[6]=n18;
 assign clocks[7]=n158;
 assign clocks[8]=n16;
 assign flags[0]=n149;
 assign flags[1]=n55;
 assign flags[2]=n30;
endmodule
`default_nettype wire
