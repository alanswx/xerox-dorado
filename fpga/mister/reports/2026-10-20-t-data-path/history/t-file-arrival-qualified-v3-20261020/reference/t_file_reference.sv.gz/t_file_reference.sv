`timescale 1ns/1ps
module t_file_reference(input wire fixture_load,input wire [371:0] fixture_state,
 input wire base,input wire [116:0] pins,output wire [371:0] state_q,
 output wire [24:0] clocks,output wire [8:0] flags,output wire [3:0] next_raw,
 output wire [1:0] write_n,latch_n,output wire [1:0] hold_clocks);
 wire [2:0] bases;
 cell_MC10210 base_fanout(.p7(base),.p11(base),.p5(1'b0),.p6(1'b0),.p9(1'b0),.p10(1'b0),
   .p2(bases[2]),.p12(bases[1]),.p13(bases[0]));
 wire [12:0] cc;wire [8:0] ch,cl;wire [13:0] fc;wire [2:0] fh,fl;
 wire en_h=fc[3],en_l=fc[4],start_a=fc[5],priority_n=fc[10];
 wire freeze=fc[13];
 wire [161:0] sh,sl,ih,il;
 assign ih[19:0]={fixture_state[83:80],fixture_state[47:32]};
 assign il[19:0]={fixture_state[87:84],fixture_state[63:48]};
 assign ih[33:20]={fixture_state[107:100],fixture_state[93:88]};
 assign il[33:20]={fixture_state[115:108],fixture_state[99:94]};
 assign {state_q[83:80],state_q[47:32]}=sh[19:0];
 assign {state_q[87:84],state_q[63:48]}=sl[19:0];
 assign {state_q[107:100],state_q[93:88]}=sh[33:20];
 assign {state_q[115:108],state_q[99:94]}=sl[33:20];
 for(genvar i=0;i<16;i=i+1) begin: map_t_file
   assign ih[34+4*i+:4]=fixture_state[116+16*i+:4];
   assign ih[98+4*i+:4]=fixture_state[120+16*i+:4];
   assign il[34+4*i+:4]=fixture_state[124+16*i+:4];
   assign il[98+4*i+:4]=fixture_state[128+16*i+:4];
   assign state_q[116+16*i+:4]=sh[34+4*i+:4];
   assign state_q[120+16*i+:4]=sh[98+4*i+:4];
   assign state_q[124+16*i+:4]=sl[34+4*i+:4];
   assign state_q[128+16*i+:4]=sl[98+4*i+:4];
 end
 t_file_conta c(fixture_load,{fixture_state[79:64],fixture_state[31:0]},bases[2],1'b0,1'b0,
   pins,next_raw,priority_n,freeze,{state_q[79:64],state_q[31:0]},cc,fc);
 t_file_proch h(fixture_load,ih,bases[1],start_a,en_h,pins,next_raw,priority_n,freeze,sh,ch,fh);
 t_file_procl l(fixture_load,il,bases[0],start_a,en_l,pins,next_raw,priority_n,freeze,sl,cl,fl);
 assign next_raw=fc[9:6];
 assign clocks={cl[5],ch[5],cc[12],cc[11:9],cl[4:0],ch[4:0],cc[8:0]};
 assign flags={fl,fh,fc[2:0]};
 assign latch_n={cl[6],ch[6]};assign write_n={cl[7],ch[7]};assign hold_clocks={cl[8],ch[8]};
endmodule
