`timescale 1ns/1ps
`default_nettype none
module capture_proch(input wire fixture_load,input wire [15:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [15:0] state_q,output wire [4:0] clocks,
 output wire [2:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.1a
 wire n9; // BSel.2'a
 wire n10; // BSel.2a
 wire n11; // BSel=2/6
 wire n12; // B_Ext
 wire n13; // B_Ext'
 wire n14; // CLK.ph'
 wire n15; // CLKEnable'c
 wire n16; // Clock0'Da
 wire n17; // Clock0'Dc
 wire n18; // Clock0'Dd
 wire n19; // Clock0En'
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Cd
 wire n23; // Clock1'Da
 wire n24; // Clock1'Dc
 wire n25; // Curr.0'
 wire n26; // Curr.1'
 wire n27; // Curr.2'
 wire n28; // Curr.3'
 wire n29; // Curr=Next'
 wire n30; // FA=0'b
 wire n31; // FA=1'a
 wire n32; // FA=3'
 wire n33; // FB=3'
 wire n34; // FB=7'
 wire n35; // FC=5'
 wire n36; // FC=6'
 wire n37; // FC=7'
 wire n38; // FF.2'a
 wire n39; // FF.2a
 wire n40; // FF.3'a
 wire n41; // GND132
 wire n42; // GND264
 wire n43; // GND266
 wire n44; // GND312
 wire n45; // GND314
 wire n46; // GND40
 wire n47; // GND420
 wire n48; // GND530
 wire n49; // Hold
 wire n50; // Hold'
 wire n51; // IOB.Perr'
 wire n52; // IOBout
 wire n53; // LC.0
 wire n54; // LC.1
 wire n55; // LC.1'a
 wire n56; // LC.1a
 wire n57; // LC.2
 wire n58; // Last.0'
 wire n59; // Last.1'
 wire n60; // Last.2'
 wire n61; // Last.3'
 wire n62; // Last=Curr'
 wire n63; // Next.0
 wire n64; // Next.0'
 wire n65; // Next.1
 wire n66; // Next.1'
 wire n67; // Next.2
 wire n68; // Next.2'
 wire n69; // Next.3
 wire n70; // Next.3'
 wire n71; // PRhold
 wire n72; // PreClock0'A
 wire n73; // PreClock0'B
 wire n74; // PreClock0'C
 wire n75; // PreClock0'D
 wire n76; // PreClock1'A
 wire n77; // PreClock1'B
 wire n78; // PreClock1'C
 wire n79; // PreClock1'D
 wire n80; // PreClock1B
 wire n81; // PreDblClock'D
 wire n82; // PreSHCP'A
 wire n83; // PreSHCP'B
 wire n84; // PreSHCP'C
 wire n85; // PreSHCP'Shc
 wire n86; // PreSHSelect'D
 wire n87; // ProcH11.sil+1
 wire n88; // ProcH12.sil+1
 wire n89; // ProcH15.sil+1
 wire n90; // ProcH20.sil+1
 wire n91; // ProcH20.sil+2
 wire n92; // ProcH20.sil+3
 wire n93; // ProcH20.sil+4
 wire n94; // ProcH20.sil+5
 wire n95; // ProcH24.sil+1
 wire n96; // ProcH24.sil+2
 wire n97; // ProcH26.sil+1
 wire n98; // ProcH26.sil+3
 wire n99; // ProcH27.sil+12
 wire n100; // ProcH30.sil+1
 wire n101; // RbSelMd
 wire n102; // RbSelMd'
 wire n103; // RbWriteEn'
 wire n104; // RepeatCurrB
 wire n105; // RepeatCurrC
 wire n106; // RepeatCurrD
 wire n107; // SHCP'C
 wire n108; // StartCycle'a
 wire n109; // TbSelMd
 wire n110; // TbWriteEn'
 wire n111; // TrueA
 wire n112; // pClock1En'
 wire n113; // ppClk'a
 wire n114; // ppClk'b
 wire n115; // ppClk'c
 assign n41=1'b0;
 assign n42=1'b0;
 assign n43=1'b0;
 assign n44=1'b0;
 assign n45=1'b0;
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n1=pins[24];
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n14=base;
 assign n15=en;
 assign n30=(pins[19:18]!=2'd0);
 assign n31=(pins[19:18]!=2'd1);
 assign n32=(pins[19:18]!=2'd3);
 assign n33=(pins[17:15]!=3'd3);
 assign n34=(pins[17:15]!=3'd7);
 assign n35=(pins[14:12]!=3'd5);
 assign n36=(pins[14:12]!=3'd6);
 assign n37=(pins[14:12]!=3'd7);
 assign n38=~pins[17];
 assign n39=pins[17];
 assign n40=~pins[16];
 assign n52=1'b0;
 assign n53=pins[11];
 assign n54=pins[10];
 assign n57=pins[9];
 assign n63=pins[20];
 assign n65=pins[21];
 assign n67=pins[22];
 assign n69=pins[23];
 assign n71=pins[25];
 assign n98=1'b0;
 assign n99=1'b0;
 assign n108=start_a;
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_3;
 assign n8=n8_h24_3;
 wire n9_h24_11;
 assign n9=n9_h24_11;
 wire n10_h24_14;
 assign n10=n10_h24_14;
 wire n11_f18_15;
 assign n11=n11_f18_15;
 wire n12_f19_3;
 assign n12=n12_f19_3;
 wire n13_f19_2;
 assign n13=n13_f19_2;
 wire n16_i18_3;
 assign n16=n16_i18_3;
 wire n17_i18_2;
 assign n17=n17_i18_2;
 wire n18_i18_4;
 assign n18=n18_i18_4;
 wire n19_l01_4;
 assign n19=n19_l01_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_c18_4;
 assign n22=n22_c18_4;
 wire n23_i18_13;
 assign n23=n23_i18_13;
 wire n24_i18_12;
 assign n24=n24_i18_12;
 wire n25_a21_14;
 assign n25=n25_a21_14;
 wire n26_a21_15;
 assign n26=n26_a21_15;
 wire n27_a21_2;
 assign n27=n27_a21_2;
 wire n28_a21_3;
 assign n28=n28_a21_3;
 wire n29_a22_3;
 wire n29_a22_2;
 wire n29_a22_15;
 wire n29_a22_14;
 assign n29=n29_a22_3 | n29_a22_2 | n29_a22_15 | n29_a22_14;
 wire n49_f19_15;
 assign n49=n49_f19_15;
 wire n50_f19_14;
 assign n50=n50_f19_14;
 wire n51_h23_15;
 assign n51=n51_h23_15;
 wire n55_h24_15;
 assign n55=n55_h24_15;
 wire n56_h24_9;
 assign n56=n56_h24_9;
 wire n58_a20_14;
 assign n58=n58_a20_14;
 wire n59_a20_15;
 assign n59=n59_a20_15;
 wire n60_a20_2;
 assign n60=n60_a20_2;
 wire n61_a20_3;
 assign n61=n61_a20_3;
 wire n62_h22_15;
 assign n62=n62_h22_15;
 wire n64_a24_15;
 assign n64=n64_a24_15;
 wire n66_a24_14;
 assign n66=n66_a24_14;
 wire n68_a24_3;
 assign n68=n68_a24_3;
 wire n70_a24_2;
 assign n70=n70_a24_2;
 wire n72_f13_13;
 assign n72=n72_f13_13;
 wire n73_f13_12;
 assign n73=n73_f13_12;
 wire n74_f13_14;
 assign n74=n74_f13_14;
 wire n75_g13_3;
 assign n75=n75_g13_3;
 wire n76_f12_14;
 assign n76=n76_f12_14;
 wire n77_f13_2;
 assign n77=n77_f13_2;
 wire n78_f13_4;
 assign n78=n78_f13_4;
 wire n79_f13_3;
 assign n79=n79_f13_3;
 wire n80_f12_13;
 assign n80=n80_f12_13;
 wire n81_g13_13;
 assign n81=n81_g13_13;
 wire n82_g12_3;
 assign n82=n82_g12_3;
 wire n83_g12_2;
 assign n83=n83_g12_2;
 wire n84_g12_4;
 assign n84=n84_g12_4;
 wire n85_f12_4;
 assign n85=n85_f12_4;
 wire n86_f12_3;
 assign n86=n86_f12_3;
 wire n87_f20_2;
 assign n87=n87_f20_2;
 wire n88_a24_9;
 wire n88_a24_11;
 wire n88_a24_6;
 wire n88_a24_5;
 assign n88=n88_a24_9 | n88_a24_11 | n88_a24_6 | n88_a24_5;
 wire n89_f20_14;
 assign n89=n89_f20_14;
 wire n90_f20_15;
 wire n90_f18_3;
 assign n90=n90_f20_15 | n90_f18_3;
 wire n91_h23_2;
 assign n91=n91_h23_2;
 wire n92_h23_3;
 assign n92=n92_h23_3;
 wire n93_h23_14;
 assign n93=n93_h23_14;
 wire n94_f18_2;
 assign n94=n94_f18_2;
 wire n95_f18_14;
 assign n95=n95_f18_14;
 wire n96_f20_3;
 assign n96=n96_f20_3;
 wire n97_a01_3;
 assign n97=n97_a01_3;
 wire n100_f12_2;
 assign n100=n100_f12_2;
 wire n101_h22_2;
 assign n101=n101_h22_2;
 wire n102_h22_3;
 assign n102=n102_h22_3;
 wire n103_h22_13;
 assign n103=n103_h22_13;
 wire n104_g12_13;
 assign n104=n104_g12_13;
 wire n105_g12_12;
 assign n105=n105_g12_12;
 wire n106_g12_14;
 assign n106=n106_g12_14;
 wire n107_c18_12;
 assign n107=n107_c18_12;
 wire n109_h22_4;
 assign n109=n109_h22_4;
 wire n110_h22_14;
 assign n110=n110_h22_14;
 wire n111_a01_14;
 assign n111=n111_a01_14;
 wire n112_l02_2;
 assign n112=n112_l02_2;
 wire n113_l01_13;
 assign n113=n113_l01_13;
 wire n114_l01_12;
 assign n114=n114_l01_12;
 wire n115_l01_14;
 assign n115=n115_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n97_a01_3),.p4(n1),.p5(1'b0),.p6(n98),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n111_a01_14),.p16(1'b0));
 original_MC10141 a20(.p1(n46),.p2(n60_a20_2),.p3(n61_a20_3),.p4(n20),.p5(1'b0),.p6(n28),.p7(1'b0),.p8(1'b0),.p9(n27),.p10(1'b0),.p11(n26),.p12(n25),.p13(1'b0),.p14(n58_a20_14),.p15(n59_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n27_a21_2),.p3(n28_a21_3),.p4(n107),.p5(1'b0),.p6(n70),.p7(n105),.p8(1'b0),.p9(n68),.p10(n105),.p11(n66),.p12(n64),.p13(1'b0),.p14(n25_a21_14),.p15(n26_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n29_a22_2),.p3(n29_a22_3),.p4(n28),.p5(n70),.p6(n68),.p7(n27),.p9(1'b0),.p10(n66),.p11(n26),.p12(n64),.p13(n25),.p14(n29_a22_14),.p15(n29_a22_15));
 cell_MC10101 a24(.p2(n70_a24_2),.p3(n68_a24_3),.p4(n69),.p5(n88_a24_5),.p6(n88_a24_6),.p7(n67),.p9(n88_a24_9),.p10(n65),.p11(n88_a24_11),.p12(1'b0),.p13(n63),.p14(n66_a24_14),.p15(n64_a24_15));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p4(n22_c18_4),.p5(n78),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n84),.p10(1'b0),.p11(1'b0),.p12(n107_c18_12),.p15(n41),.p16(1'b0));
 cell_SE10212 f12(.p1(1'b0),.p2(n100_f12_2),.p3(n86_f12_3),.p4(n85_f12_4),.p5(n112),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n100),.p10(1'b0),.p11(n113),.p13(n80_f12_13),.p14(n76_f12_14),.p15(n42),.p16(1'b0));
 cell_SE10210 f13(.p2(n77_f13_2),.p3(n79_f13_3),.p4(n78_f13_4),.p5(n114),.p6(1'b0),.p7(n100),.p8(1'b0),.p9(n114),.p10(n19),.p11(1'b0),.p12(n73_f13_12),.p13(n72_f13_13),.p14(n74_f13_14),.p15(n43),.p16(1'b0));
 cell_MC10102 f18(.p1(1'b0),.p2(n94_f18_2),.p3(n90_f18_3),.p4(n57),.p5(n92),.p6(n53),.p7(n55),.p10(n39),.p11(n32),.p12(n10),.p13(n7),.p14(n95_f18_14),.p15(n11_f18_15),.p16(1'b0));
 cell_MC1660 f19(.p2(n13_f19_2),.p3(n12_f19_3),.p4(1'b0),.p5(n31),.p6(n40),.p7(n38),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n71),.p14(n50_f19_14),.p15(n49_f19_15));
 cell_MC10100 f20(.p2(n87_f20_2),.p3(n96_f20_3),.p4(n36),.p5(n34),.p6(n37),.p7(n33),.p9(n30),.p10(n36),.p11(n33),.p12(n35),.p13(n34),.p14(n89_f20_14),.p15(n90_f20_15));
 cell_SE10211 g12(.p2(n83_g12_2),.p3(n82_g12_3),.p4(n84_g12_4),.p5(1'b0),.p6(n112),.p7(1'b0),.p9(n0),.p10(n50),.p11(1'b0),.p12(n105_g12_12),.p13(n104_g12_13),.p14(n106_g12_14),.p15(n44),.p16(1'b0));
 cell_SE10210 g13(.p3(n75_g13_3),.p5(n115),.p6(n19),.p7(1'b0),.p8(1'b0),.p9(n115),.p10(1'b0),.p11(1'b0),.p13(n81_g13_13),.p15(n45),.p16(1'b0));
 original_MC10176 h22(.p1(1'b0),.p2(n101_h22_2),.p3(n102_h22_3),.p4(n109_h22_4),.p5(n55),.p6(n56),.p7(n90),.p8(1'b0),.p9(n16),.p10(n93),.p11(n94),.p12(n29),.p13(n103_h22_13),.p14(n110_h22_14),.p15(n62_h22_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_MC10102 h23(.p1(1'b0),.p2(n91_h23_2),.p3(n92_h23_3),.p4(n55),.p5(n57),.p6(n53),.p7(n55),.p10(n53),.p11(n91),.p12(n52),.p13(n99),.p14(n93_h23_14),.p15(n51_h23_15),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n8_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n56_h24_9),.p10(n4),.p11(n9_h24_11),.p12(1'b0),.p13(n54),.p14(n10_h24_14),.p15(n55_h24_15));
 cell_SE10210 i18(.p2(n17_i18_2),.p3(n16_i18_3),.p4(n18_i18_4),.p5(n75),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n79),.p10(1'b0),.p11(1'b0),.p12(n24_i18_12),.p13(n23_i18_13),.p15(n47),.p16(1'b0));
 cell_SE10210 l01(.p4(n19_l01_4),.p5(1'b0),.p6(n108),.p7(1'b0),.p8(1'b0),.p9(n15),.p10(1'b0),.p11(n14),.p12(n114_l01_12),.p13(n113_l01_13),.p14(n115_l01_14),.p15(n48),.p16(1'b0));
 original_SE10231 l02(.p2(n112_l02_2),.p6(n15),.p7(n19),.p9(n14),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n107;
 assign clocks[3]=n16;
 assign clocks[4]=n20;
 assign flags[0]=n105;
 assign flags[1]=n49;
 assign flags[2]=n29;
endmodule
`default_nettype wire
