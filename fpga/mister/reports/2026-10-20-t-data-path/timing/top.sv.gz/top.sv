module clock_fit(input wire host_clk,input wire [659:0] pins,
 output reg [462:0] result);
 // Fixture input staging avoids treating a virtual package pin as the
 // evaluator's launch register. The evaluator still has a full 15ns path
 // from launch to result; the new staging path has a stricter half period.
 reg [659:0] input_stage;
 reg [659:0] launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [403:0] q,next_q;
 wire before_clock,after_clock;
 wire [126:0] before_controls,after_controls;
 wire [24:0] events,repeated;
 wire [1:0] write_n,latch_n,t_latch_n,bypass;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls}=launch;
 dorado_t_file_step evaluator(q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass};
endmodule
