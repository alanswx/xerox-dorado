module msa_stack_state_fixture(
 input wire clk,system_reset,transport_reset,local_held,input wire [4:0] services_held,
 input wire [10:0] main_frozen,main_done,main_error,main_hold,main_fault,input wire [197:0] main_result,
 inout wire [35:0] state_bus,output wire hold,scan_abort,output wire [10:0] main_request);
 wire command_hold,hold_update,hold_value,control_error;
 wire u_request,u_write,port_ready,port_done,port_fault,busy,complete;
 wire [3:0] u_board;wire [23:0] u_index;wire [17:0] u_data,port_result;
 wire [2:0] port_error;wire [31:0] txn_sequence,control_errors;
 wire msa_frozen,msa_done,msa_error,msa_hold,msa_fault;wire [17:0] msa_result;
 wire [11:0] board_frozen={msa_frozen,main_frozen},board_done={msa_done,main_done},board_error={msa_error,main_error};
 wire [11:0] board_holds={msa_hold,main_hold},board_faults={msa_fault,main_fault},board_request;
 wire [215:0] board_result={msa_result,main_result};
 wire request=u_request,wr=u_write,update_hold=hold_update,value_hold=hold_value;
 wire [3:0] selected=u_board;wire [23:0] index=u_index;wire [17:0] data=u_data;
 assign main_request=board_request[10:0];
 localparam [63:0] SCHEMA=64'hb80a00977d7e7992;
 dorado_board_state_uio_msa #(.SCHEMA_ID(SCHEMA)) uio(
  .clk(clk),.system_reset(system_reset),.transport_reset(transport_reset),.bus(state_bus),
  .hold_update(hold_update),.hold_value(hold_value),.hold(hold),.command_hold(command_hold),
  .local_held(local_held),.services_held(services_held),.control_error(control_error),.board_frozen(board_frozen),
  .request(u_request),.write(u_write),.board(u_board),.index(u_index),.data(u_data),
  .ready(port_ready),.done(port_done),.error(port_error),.result(port_result),.fault(port_fault),
  .busy(busy),.complete(complete),.txn_sequence(txn_sequence),.control_errors(control_errors));
 dorado_board_state_fabric_msa fabric(
  .clk(clk),.system_reset(system_reset),.transport_reset(transport_reset),
  .hold_update(update_hold),.hold_value(value_hold),.local_held(local_held),.services_held(services_held),
  .hold(hold),.scan_abort(scan_abort),.command_hold(command_hold),.control_error(control_error),
  .request(request),.write(wr),.board(selected),.index(index),.data(data),
  .ready(port_ready),.done(port_done),.error(port_error),.result(port_result),.fault(port_fault),
  .board_frozen(board_frozen),.board_done(board_done),.board_error(board_error),
  .board_hold_required(board_holds),.board_fault(board_faults),.board_result(board_result),.board_request(board_request));
 wire [7:0] msa_request,msa_unit_frozen,msa_unit_done,msa_unit_error,msa_unit_hold,msa_unit_fault;
 wire [143:0] msa_unit_result;wire [23:0] msa_unit_index;wire msa_unit_write;wire [17:0] msa_unit_data;
 wire [2689:0] msa_physical[0:7];
 dorado_msa_state_group msa_group(.clk(clk),.system_reset(system_reset),.transport_reset(transport_reset),.scan_abort(scan_abort),
 .request(board_request[11]),.write(wr),.index(index),.data(data),
 .unit_frozen(msa_unit_frozen),.unit_done(msa_unit_done),.unit_error(msa_unit_error),
 .unit_hold_required(msa_unit_hold),.unit_fault(msa_unit_fault),.unit_result(msa_unit_result),
 .frozen(msa_frozen),.hold_required(msa_hold),.fault(msa_fault),.done(msa_done),.error(msa_error),.result(msa_result),
 .unit_request(msa_request),.unit_index(msa_unit_index),.unit_write(msa_unit_write),.unit_data(msa_unit_data));
 genvar u;
 generate for(u=0;u<8;u=u+1)begin:members
dorado_serial_MSA #(.SYSPER(4)) member(
.sys_clk(1'b0),
.storage_clk(clk),
.storage_reset(1'b0),
.storage_ready(),
.storage_req_ready(16'b0),
.storage_rsp_valid(16'b0),
.storage_rsp_data(256'b0),
.CLK_ms0Even_p_(1'b0),
.ChipsAre16k(1'b0),
.ChipsAre4k(1'b0),
.ChipsAre64K(1'b0),
.EcOut_0(1'b0),
.EcOut_1(1'b0),
.EcOut_4(1'b0),
.EcOut_5(1'b0),
.LoadEcOut_p_(1'b0),
.LoadSinE(1'b0),
.LoadSoutE_p_(1'b0),
.Mb0(1'b0),
.MemAd_1(1'b0),
.MemAd_2(1'b0),
.MemAd_3(1'b0),
.MemAd_4(1'b0),
.MemAd_5(1'b0),
.MemAd_6(1'b0),
.MemAd_7(1'b0),
.MemAd_8(1'b0),
.MemCASa(1'b0),
.MemCASb(1'b0),
.MemRASa(1'b0),
.MemRASb(1'b0),
.MemWEa(1'b0),
.MemWEb(1'b0),
.Mod0SinEn_p_(1'b0),
.Mod0StrEn_p_(1'b0),
.ShiftEcOut(1'b0),
.ShiftSinE(1'b0),
.ShiftSoutE(1'b0),
.Sout_00(1'b0),
.Sout_01(1'b0),
.Sout_02(1'b0),
.Sout_03(1'b0),
.Sout_04(1'b0),
.Sout_05(1'b0),
.Sout_06(1'b0),
.Sout_07(1'b0),
.Sout_08(1'b0),
.Sout_09(1'b0),
.Sout_10(1'b0),
.Sout_11(1'b0),
.Sout_12(1'b0),
.Sout_13(1'b0),
.Sout_14(1'b0),
.Sout_15(1'b0),
.EcIn_0__drv(),
.EcIn_1__drv(),
.M0__drv(),
.Sin_00__drv(),
.Sin_01__drv(),
.Sin_02__drv(),
.Sin_03__drv(),
.Sin_04__drv(),
.Sin_05__drv(),
.Sin_06__drv(),
.Sin_07__drv(),
.Sin_08__drv(),
.Sin_09__drv(),
.Sin_10__drv(),
.Sin_11__drv(),
.Sin_12__drv(),
.Sin_13__drv(),
.Sin_14__drv(),
.Sin_15__drv(),
.storage_req_valid(),
.storage_req_write(),
.storage_req_addr(),
.storage_req_data(),
.storage_rsp_ready(),
.state_guest_advance(1'b0),
.state_freeze(hold),
.state_guest_held(local_held),
.state_global_hold(hold),
.state_global_abort(scan_abort),
.state_system_reset(system_reset),
.state_request(msa_request[u]),
.state_write(msa_unit_write),
.state_index(msa_unit_index),
.state_data(msa_unit_data),
.state_ready(),
.state_frozen(msa_unit_frozen[u]),
.state_done(msa_unit_done[u]),
.state_error(msa_unit_error[u]),
.state_scan_hold_required(msa_unit_hold[u]),
.state_scan_fault(msa_unit_fault[u]),
.state_memory_drained(),
.state_result(msa_unit_result[u*18+:18])
);
assign msa_physical[u]={member.u_storage_15.state_bits,member.u_storage_14.state_bits,member.u_storage_13.state_bits,member.u_storage_12.state_bits,member.u_storage_11.state_bits,member.u_storage_10.state_bits,member.u_storage_9.state_bits,member.u_storage_8.state_bits,member.u_storage_7.state_bits,member.u_storage_6.state_bits,member.u_storage_5.state_bits,member.u_storage_4.state_bits,member.u_storage_3.state_bits,member.u_storage_2.state_bits,member.u_storage_1.state_bits,member.u_storage_0.state_bits,member.ff_scan_bits};
end endgenerate
always @(posedge clk)begin
 if((msa_request&(msa_request-1))!=0)$fatal(1,"nononehot MSA request");
 if((|msa_request)&&msa_group.pending)$fatal(1,"busy MSA rerouted");
 if((|msa_request)&&(!hold||!local_held||msa_unit_frozen!==8'hff))$fatal(1,"MSA request before complete boundary");
 end
endmodule
