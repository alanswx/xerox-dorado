from pathlib import Path
import hashlib,json,os,shutil,time

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def closed(p):
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for fd in(proc/'fd').iterdir():
    try:target=os.readlink(fd)
    except OSError:continue
    assert target!=str(p),(proc.name,fd.name,str(p))
  except(FileNotFoundError,PermissionError):pass

def identity(p):
 s=p.stat();return(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)

out=Path('/media/fat/games/DoradoRTL/ClosedTmpLogs_20261021_RVisible4')
out.mkdir(exist_ok=False)
record=dict(started=time.time(),scope='Closed historical log duplicates only; all bytes retained on SD',files=[])
def save():(out/'preservation.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for name in ['dorado49b-disk.jsonl','dorado55-disk.jsonl']:
 p=Path('/tmp')/name;closed(p);before=identity(p)
 with p.open('rb')as stream:
  stream.seek(max(0,before[2]-4096));last=json.loads(stream.read().splitlines()[-1])
 assert last['event']=='barrier_end'
 q=out/name;shutil.copyfile(p,q)
 with q.open('rb')as stream:os.fsync(stream.fileno())
 key=sha(p);assert key==sha(q)and identity(p)==before
 closed(p)
 entry=dict(source=str(p),preserved=str(q),bytes=before[2],sha256=key,last_event='barrier_end',no_open_descriptors=True,removed_tmp_duplicate=False)
 record['files'].append(entry);save()
 p.unlink();entry['removed_tmp_duplicate']=True;save()
record.update(finished=time.time(),reclaimed_tmp_bytes=sum(r['bytes']for r in record['files']))
save();print(json.dumps(record),flush=True)
