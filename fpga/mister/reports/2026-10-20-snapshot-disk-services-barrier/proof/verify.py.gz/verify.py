from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
q=load(root/'payload/qualification.json');assert q['status']=='PASS'and q['real_pause_coordinators']and q['observed_bits']==131823 and q['new_required_wrapper_bits']==7
assert q['geometry']=={'original':{'fields':55,'bits':131816},'candidate':{'fields':57,'bits':131818}}
assert len(q['cases'])==5 and q['sequential_exclusions']==[]
for n,h in q['inputs'].items():assert sha(root/'payload/executed-inputs'/n)==h,n
for c in q['cases']:
 log=root/'payload'/c['case']/'test.log';text=log.read_text();assert sha(log)==c['log_sha256']
 if c['expected_failure']:assert c['returncode']==23 and c['expected_failure']in text
 else:
  assert c['returncode']==0 and'PILOT-PACK PASS'in text and'PACK-FAULT PASS'in text
  assert'DISK SNAPSHOT PASS holds=9 observed_bits=131823'in text
co=load(root/'coordinator/results.json');assert co['status']=='PASS'and co['new_required_disk_coordinator_bits']==3 and len(co['cases'])==8
for n,h in co['inputs'].items():assert sha(root/'coordinator/executed-inputs'/n)==h,n
for c in co['cases']:
 for n,h in c['inputs'].items():assert sha(root/'coordinator'/c['case']/n)==h,n
 text=(root/'coordinator'/c['case']/'test.log').read_text()
 if c['expected_failure']:assert c['returncode']and c['expected_failure']in text
 elif c['case']=='candidate':assert'checks=65826 drain_cases=64 ready_cases=16384 state_bits=3'in text
 else:assert'SERVICES CHAIN PASS checks=104 coordinator_bits=10'in text
status=load(root/'status/qualification.json');assert status['status']=='PASS'and status['original_fields']==29 and status['original_bits']==348 and status['new_required_top_bits']==5
assert len(status['cases'])==6 and len(status['client_failure_controls'])==9 and status['sequential_exclusions']==[]
for n,h in status['inputs'].items():assert sha(root/'status/executed-inputs'/n)==h,n
for c in status['cases']:
 log=root/'status'/c['case']/'test.log';text=log.read_text();assert sha(log)==c['log_sha256']and sha(root/'status'/c['case']/'candidate.sv')==c['rtl_sha256']
 if c['expected_failure']:assert c['returncode']and c['expected_failure']in text
 else:assert'LOCAL SERVICE STATUS PASS'in text
first=status['parsed_status'][0];assert first['local_services_held']&2 and not first['services_held']&2 and not first['ready']
for n,h in load(root/'proof-source/source-hashes.json').items():assert sha(root/'proof-source'/n)==h,n
assert sha(root/'proof-source/fpga/mister/dorado_pack_hps.sv')==q['inputs']['medium.sv']
assert sha(root/'proof-source/fpga/mister/snapshot/board_state_uio_msa.sv')==status['inputs']['candidate.sv']
assert q['inputs']['disk_pause_barrier.sv']==co['inputs']['disk_pause_barrier.sv']
fresh=load(root/'archive-rebuild-payload/qualification.json');assert fresh['status']=='PASS'and fresh['inputs']==q['inputs']and fresh['cases']==q['cases']
for n,h in fresh['inputs'].items():assert sha(root/'archive-rebuild-payload/executed-inputs'/n)==h,n
for c in fresh['cases']:assert sha(root/'archive-rebuild-payload'/c['case']/'test.log')==c['log_sha256']
fresh=load(root/'archive-rebuild-coordinator/results.json');assert fresh['status']=='PASS'and fresh['inputs']==co['inputs']and fresh['cases']==co['cases']
for c in fresh['cases']:
 for n,h in c['inputs'].items():assert sha(root/'archive-rebuild-coordinator'/c['case']/n)==h,n
fresh=load(root/'archive-rebuild-status/qualification.json');assert fresh['status']=='PASS'and fresh['inputs']==status['inputs']and fresh['status_words']==status['status_words']and fresh['parsed_status']==status['parsed_status']
for c in fresh['cases']:
 assert sha(root/'archive-rebuild-status'/c['case']/'test.log')==c['log_sha256']
 original=next(x for x in status['cases']if x['case']==c['case']);a=dict(original);b=dict(c);a.pop('log_sha256');b.pop('log_sha256');assert a==b
legacy=load(root/'legacy-regression/qualification.json');assert legacy['status']=='PASS'and not legacy['real_pause_coordinators']and legacy['observed_bits']==131818 and len(legacy['cases'])==5
assert legacy['inputs']['medium.sv']==q['inputs']['medium.sv']
for n,h in legacy['inputs'].items():assert sha(root/'legacy-regression/executed-inputs'/n)==h,n
for c in legacy['cases']:assert sha(root/'legacy-regression'/c['case']/'test.log')==c['log_sha256']
print(json.dumps(dict(status='PASS',observed_disk_and_coordinator_bits=131823,disk_medium_bits=131818,original_UIO_bits=348,new_local_status_bits=5,new_disk_coordinator_bits=3,three_domain_checks=104,unknown_ready_combinations=16384,local_ACK_does_not_bypass_permission=True,limits='Component coordination and raw status only. Main/input/video/physical-DDR fence, native timing, state access and complete restore remain open.'),indent=2))
