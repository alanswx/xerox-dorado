`line 1 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 1
 

`line 3 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
 
 

`line 6 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
 
 
 
 
 
 
 
 
 

`line 16 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
 
 
 

`line 20 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
 
 
 
 
 
 
 

`line 28 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
`default_nettype none

`line 30 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
module cell_F10145A_snapshot (
    input wire state_host_clk, state_advance, state_freeze, state_guest_held,
    input wire state_request, state_write,
    input wire [4:0] state_index,
    input wire [9:0] state_data,
    output reg state_frozen = 1'b0,
    output reg state_done = 1'b0, state_error = 1'b0,
    output reg [9:0] state_result,
    input  wire sys_clk,
    input  wire p10,
    input  wire p9,
    input  wire p7,
    input  wire p6,
    input  wire p5,
    input  wire p4,
    input  wire p11,
    input  wire p12,
    input  wire p3,
    input  wire p13,
    output wire p2,
    output wire p1,
    output wire p15,
    output wire p14,
    input  wire p8
);

`line 56 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
   
   
   
   
   
   
   
 
  (* ramstyle = "logic" *) reg [3:0] mem [0:15];

`line 66 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
          

`line 68 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
  
   
   
   
   
   
   
   
  wire [3:0] a = {p10, p9, p7, p6};    
   
  
   
   
   
   
   
   
   
   
   
  
   
   
   
   
   
   
   
   
   
   
  reg we_d;
  reg [3:0] a_lat, d_lat;
  reg       ce_lat;
   
   
   
  wire state_hold = state_freeze && state_guest_held;
  wire state_accept = state_hold && state_frozen && state_request;
  wire state_valid = state_index <= 5'd16;
  wire [9:0] state_window = {ce_lat,d_lat,a_lat,we_d};
  wire ram_restore = state_accept && state_write && state_valid && state_index < 5'd16;
  wire ram_guest_write = !state_hold && state_advance && p13 && !we_d && ce_lat;
  wire [3:0] ram_write_address = state_hold ? state_index[3:0] : a_lat;
  wire [3:0] ram_write_data = state_hold ? state_data[3:0] : d_lat;
  always @(posedge state_host_clk) begin
    if (ram_restore || ram_guest_write) mem[ram_write_address] <= ram_write_data;
    state_frozen <= state_hold;
    state_done <= state_accept;
    state_error <= state_accept && !state_valid;
    if (state_accept) begin
      state_result <= state_write ? 10'b0 : state_index == 5'd16 ? state_window :
                      (state_index < 5'd16 ? {6'b0,mem[state_index[3:0]]} : 10'b0);
      if (state_write && state_valid) begin
        if (state_index == 5'd16) {ce_lat,d_lat,a_lat,we_d} <= state_data;
        else begin end  
      end
    end
    if (!state_hold && state_advance) begin
    we_d <= p13;
    if (!p13) begin                           
      a_lat  <= a;
      d_lat  <= {p12, p11, p4, p5};
      ce_lat <= ~p3;
    end
     
    end
  end
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
  wire [3:0] q = mem[a];
  assign {p14, p15, p1, p2} = (!p3) ? q : 4'b0000;           


`line 156 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
   
  wire _unused_pins = &{1'b0, p8, 1'b0};

`line 159 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
endmodule

`line 161 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
`default_nettype wire

`line 163 "/Users/alans/dev2/Dorado/build/rtl-executive/f10145-zero-write-mlab-fit-20261019/baseline/cell_F10145A_snapshot.sv" 0
