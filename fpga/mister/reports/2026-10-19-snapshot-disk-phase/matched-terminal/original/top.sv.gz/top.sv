module snapshot_fit(
 input wire extra_ready,
 input wire clk_sys,
 input wire reset,
 input wire attached,
 input wire readonly,
 input wire remounted,
 input wire [11:0] tagbus_n,
 input wire cyltag_n,
 input wire headtag_n,
 input wire drivetag_n,
 input wire conttag_n,
 input wire selected,
 input wire data_adv,
 input wire [15:0] pulse,
 input wire write_data_p,
 input wire write_data_m,
 output wire data_bit,
 output wire write_gate,
 output wire endofcyl_n,
 output wire ready,
 output wire dirty,
 output wire fault,
 output wire [2:0] host_phase,
 output wire [31:0] fault_debug,
 output wire [31:0] fault_extra,
 output wire [31:0] sd_lba,
 output wire [5:0] sd_blk_cnt,
 output wire sd_rd,
 output wire sd_wr,
 input wire sd_ack,
 input wire [12:0] sd_buff_addr,
 input wire [15:0] sd_buff_dout,
 input wire sd_buff_wr,
 output wire [15:0] sd_buff_din,
 output wire [31:0] reads,
 output wire [31:0] writes);
 reg extra_ready_stage,extra_ready_launch;
 always @(negedge clk_sys)extra_ready_stage<=extra_ready;
 always @(posedge clk_sys)extra_ready_launch<=extra_ready_stage;
 reg reset_stage,reset_launch;
 always @(negedge clk_sys)reset_stage<=reset;
 always @(posedge clk_sys)reset_launch<=reset_stage;
 reg attached_stage,attached_launch;
 always @(negedge clk_sys)attached_stage<=attached;
 always @(posedge clk_sys)attached_launch<=attached_stage;
 reg readonly_stage,readonly_launch;
 always @(negedge clk_sys)readonly_stage<=readonly;
 always @(posedge clk_sys)readonly_launch<=readonly_stage;
 reg remounted_stage,remounted_launch;
 always @(negedge clk_sys)remounted_stage<=remounted;
 always @(posedge clk_sys)remounted_launch<=remounted_stage;
 reg [11:0] tagbus_n_stage,tagbus_n_launch;
 always @(negedge clk_sys)tagbus_n_stage<=tagbus_n;
 always @(posedge clk_sys)tagbus_n_launch<=tagbus_n_stage;
 reg cyltag_n_stage,cyltag_n_launch;
 always @(negedge clk_sys)cyltag_n_stage<=cyltag_n;
 always @(posedge clk_sys)cyltag_n_launch<=cyltag_n_stage;
 reg headtag_n_stage,headtag_n_launch;
 always @(negedge clk_sys)headtag_n_stage<=headtag_n;
 always @(posedge clk_sys)headtag_n_launch<=headtag_n_stage;
 reg drivetag_n_stage,drivetag_n_launch;
 always @(negedge clk_sys)drivetag_n_stage<=drivetag_n;
 always @(posedge clk_sys)drivetag_n_launch<=drivetag_n_stage;
 reg conttag_n_stage,conttag_n_launch;
 always @(negedge clk_sys)conttag_n_stage<=conttag_n;
 always @(posedge clk_sys)conttag_n_launch<=conttag_n_stage;
 reg selected_stage,selected_launch;
 always @(negedge clk_sys)selected_stage<=selected;
 always @(posedge clk_sys)selected_launch<=selected_stage;
 reg data_adv_stage,data_adv_launch;
 always @(negedge clk_sys)data_adv_stage<=data_adv;
 always @(posedge clk_sys)data_adv_launch<=data_adv_stage;
 reg [15:0] pulse_stage,pulse_launch;
 always @(negedge clk_sys)pulse_stage<=pulse;
 always @(posedge clk_sys)pulse_launch<=pulse_stage;
 reg write_data_p_stage,write_data_p_launch;
 always @(negedge clk_sys)write_data_p_stage<=write_data_p;
 always @(posedge clk_sys)write_data_p_launch<=write_data_p_stage;
 reg write_data_m_stage,write_data_m_launch;
 always @(negedge clk_sys)write_data_m_stage<=write_data_m;
 always @(posedge clk_sys)write_data_m_launch<=write_data_m_stage;
 wire data_bit_raw;
 reg data_bit_capture;
 always @(posedge clk_sys)data_bit_capture<=data_bit_raw;
 assign data_bit=data_bit_capture;
 wire write_gate_raw;
 reg write_gate_capture;
 always @(posedge clk_sys)write_gate_capture<=write_gate_raw;
 assign write_gate=write_gate_capture;
 wire endofcyl_n_raw;
 reg endofcyl_n_capture;
 always @(posedge clk_sys)endofcyl_n_capture<=endofcyl_n_raw;
 assign endofcyl_n=endofcyl_n_capture;
 wire ready_raw;
 reg ready_capture;
 always @(posedge clk_sys)ready_capture<=ready_raw;
 assign ready=ready_capture;
 wire dirty_raw;
 reg dirty_capture;
 always @(posedge clk_sys)dirty_capture<=dirty_raw;
 assign dirty=dirty_capture;
 wire fault_raw;
 reg fault_capture;
 always @(posedge clk_sys)fault_capture<=fault_raw;
 assign fault=fault_capture;
 wire [2:0] host_phase_raw;
 reg [2:0] host_phase_capture;
 always @(posedge clk_sys)host_phase_capture<=host_phase_raw;
 assign host_phase=host_phase_capture;
 wire [31:0] fault_debug_raw;
 reg [31:0] fault_debug_capture;
 always @(posedge clk_sys)fault_debug_capture<=fault_debug_raw;
 assign fault_debug=fault_debug_capture;
 wire [31:0] fault_extra_raw;
 reg [31:0] fault_extra_capture;
 always @(posedge clk_sys)fault_extra_capture<=fault_extra_raw;
 assign fault_extra=fault_extra_capture;
 wire [31:0] sd_lba_raw;
 reg [31:0] sd_lba_capture;
 always @(posedge clk_sys)sd_lba_capture<=sd_lba_raw;
 assign sd_lba=sd_lba_capture;
 wire [5:0] sd_blk_cnt_raw;
 reg [5:0] sd_blk_cnt_capture;
 always @(posedge clk_sys)sd_blk_cnt_capture<=sd_blk_cnt_raw;
 assign sd_blk_cnt=sd_blk_cnt_capture;
 wire sd_rd_raw;
 reg sd_rd_capture;
 always @(posedge clk_sys)sd_rd_capture<=sd_rd_raw;
 assign sd_rd=sd_rd_capture;
 wire sd_wr_raw;
 reg sd_wr_capture;
 always @(posedge clk_sys)sd_wr_capture<=sd_wr_raw;
 assign sd_wr=sd_wr_capture;
 reg sd_ack_stage,sd_ack_launch;
 always @(negedge clk_sys)sd_ack_stage<=sd_ack;
 always @(posedge clk_sys)sd_ack_launch<=sd_ack_stage;
 reg [12:0] sd_buff_addr_stage,sd_buff_addr_launch;
 always @(negedge clk_sys)sd_buff_addr_stage<=sd_buff_addr;
 always @(posedge clk_sys)sd_buff_addr_launch<=sd_buff_addr_stage;
 reg [15:0] sd_buff_dout_stage,sd_buff_dout_launch;
 always @(negedge clk_sys)sd_buff_dout_stage<=sd_buff_dout;
 always @(posedge clk_sys)sd_buff_dout_launch<=sd_buff_dout_stage;
 reg sd_buff_wr_stage,sd_buff_wr_launch;
 always @(negedge clk_sys)sd_buff_wr_stage<=sd_buff_wr;
 always @(posedge clk_sys)sd_buff_wr_launch<=sd_buff_wr_stage;
 wire [15:0] sd_buff_din_raw;
 reg [15:0] sd_buff_din_capture;
 always @(posedge clk_sys)sd_buff_din_capture<=sd_buff_din_raw;
 assign sd_buff_din=sd_buff_din_capture;
 wire [31:0] reads_raw;
 reg [31:0] reads_capture;
 always @(posedge clk_sys)reads_capture<=reads_raw;
 assign reads=reads_capture;
 wire [31:0] writes_raw;
 reg [31:0] writes_capture;
 always @(posedge clk_sys)writes_capture<=writes_raw;
 assign writes=writes_capture;
 wire guest_clock;
 altclkctrl #(.clock_type("Global Clock"),.ena_register_mode("falling edge"),.intended_device_family("Cyclone V")) machine_clock(
 .inclk({3'b000,clk_sys}),.clkselect(2'b00),.ena(!reset_launch && ready_raw && extra_ready_launch),.outclk(guest_clock));
 dorado_pack_hps #(.LABEL_WORDS(10),.HOST_CLOCK_HZ(50000000)) u_medium(
.clk_sys(clk_sys),
.machine_clk(guest_clock),
.reset(reset_launch),
.attached(attached_launch),
.readonly(readonly_launch),
.remounted(remounted_launch),
.tagbus_n(tagbus_n_launch),
.cyltag_n(cyltag_n_launch),
.headtag_n(headtag_n_launch),
.drivetag_n(drivetag_n_launch),
.conttag_n(conttag_n_launch),
.selected(selected_launch),
.data_adv(data_adv_launch),
.pulse(pulse_launch),
.write_data_p(write_data_p_launch),
.write_data_m(write_data_m_launch),
.data_bit(data_bit_raw),
.write_gate(write_gate_raw),
.endofcyl_n(endofcyl_n_raw),
.ready(ready_raw),
.dirty(dirty_raw),
.fault(fault_raw),
.host_phase(host_phase_raw),
.fault_debug(fault_debug_raw),
.fault_extra(fault_extra_raw),
.sd_lba(sd_lba_raw),
.sd_blk_cnt(sd_blk_cnt_raw),
.sd_rd(sd_rd_raw),
.sd_wr(sd_wr_raw),
.sd_ack(sd_ack_launch),
.sd_buff_addr(sd_buff_addr_launch),
.sd_buff_dout(sd_buff_dout_launch),
.sd_buff_wr(sd_buff_wr_launch),
.sd_buff_din(sd_buff_din_raw),
.reads(reads_raw),
.writes(writes_raw));
endmodule
