module altclkctrl #(
 parameter clock_type="Global Clock",ena_register_mode="falling edge",intended_device_family="Cyclone V")(
 input wire [3:0] inclk,input wire [1:0] clkselect,input wire ena,output wire outclk);
 assign outclk=inclk[0];endmodule
