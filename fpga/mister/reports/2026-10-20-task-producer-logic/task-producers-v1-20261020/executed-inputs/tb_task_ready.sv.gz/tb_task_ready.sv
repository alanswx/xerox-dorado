`timescale 1ps/1ps
module tb_task_ready;
 reg load=0;reg [15:0] fixture=0,state=0;
 reg [23:0] pins=22'h047000,before_pins=22'h047000;
 wire [15:0] original_q,next_q;wire [1:0] clocks,events,after_clocks;
 wire [29:0] flags;wire [14:0] next_n,ready;
 task_ready_reference original(load,fixture,1'b0,1'b0,1'b0,{4'b0,pins},original_q,clocks,flags);
 dorado_task_ready_step dut(state,before_pins,pins,next_q,events,after_clocks,next_n,ready);
 integer checks=0,captures=0,clears=0,held=0;reg [1:0] observed=0;
 reg [15:0] changed=0;reg [14:0] seen_ready=0,seen_selected=0;
 always @(posedge clocks[0]) observed[0]=1;
 always @(posedge clocks[1]) observed[1]=1;
 function automatic [3:0] raw_task(input integer n);raw_task={n[0],n[1],n[2],n[3]};endfunction
 task event_pins(input [23:0] value);
  reg [15:0] old;
  begin
   old=state;observed=0;before_pins=pins;pins=value;#20000;
   if(original_q!==next_q || clocks!==after_clocks || observed!==events || flags!=={ready,next_n})begin
    $display("READY_FAIL check=%0d before=%h after=%h old=%h expected=%h actual=%h flags=%h/%h events=%b/%b",checks,before_pins,pins,state,original_q,next_q,flags,{ready,next_n},observed,events);
    $fatal(1,"Ready producer mismatch");
   end
   captures=captures+events[0];clears=clears+pins[15];held=held+((pins[17]||pins[20])&&!events[0]);
   changed=changed|(old^next_q);seen_ready=seen_ready|ready;seen_selected=seen_selected|~next_n;
   state=next_q;checks=checks+1;#100;
  end
 endtask
 reg [23:0] selected;
 initial begin
  #20000;fixture=16'hffff;load=1;#20000;load=0;state=fixture;#20000;
  selected=pins;
  // Clear with no capture edge. Then exercise every combination of BNT,
  // current task, notify operand and the three decode enable bits.
  selected[15]=1;event_pins(selected);selected[15]=0;event_pins(selected);
  for(integer enable=0;enable<8;enable=enable+1)
   for(integer nt=0;nt<16;nt=nt+1)
    for(integer ct=0;ct<16;ct=ct+1)
     for(integer ff=0;ff<16;ff=ff+1)begin
      selected[18]=1;selected[14:12]=3'(enable);
      selected[23:22]=2'(ct);selected[3:0]=raw_task(nt);selected[7:4]=raw_task(ct);selected[11:8]=raw_task(ff);event_pins(selected);
      selected[18]=0;event_pins(selected);selected[18]=1;event_pins(selected);
     end
  // Independent Freeze/Repeat gating and asynchronous reset while held.
  for(integer gate_no=0;gate_no<2;gate_no=gate_no+1)begin
   for(integer task_no=1;task_no<16;task_no=task_no+1)begin
    selected[18]=1;selected[14]=0;selected[11:8]=raw_task(task_no);event_pins(selected);
    selected[gate_no==0?17:20]=1;event_pins(selected);
    selected[18]=0;event_pins(selected);
    selected[15]=1;event_pins(selected);selected[15]=0;event_pins(selected);
    selected[gate_no==0?17:20]=0;event_pins(selected);
    selected[18]=1;event_pins(selected);
   end
  end
  if(changed!=16'hffff||seen_ready!=15'h7fff||seen_selected!=15'h7fff||clears<31||held<60)
   $fatal(1,"Ready coverage missing changed=%h ready=%h selected=%h clear=%0d held=%0d",changed,seen_ready,seen_selected,clears,held);
  $display("TASK_READY PASS checks=%0d captures=%0d clear_checks=%0d held=%0d changed=%h ready=%h selected=%h",checks,captures,clears,held,changed,seen_ready,seen_selected);
  $finish;
 end
endmodule
