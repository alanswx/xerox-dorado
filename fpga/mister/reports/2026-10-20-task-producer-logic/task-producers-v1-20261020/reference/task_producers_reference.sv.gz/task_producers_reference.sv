`timescale 1ns/1ps
`default_nettype none
module task_producers_reference(input wire fixture_load,input wire [27:0] fixture_state,
 input wire base,start_a,en,input wire [34:0] pins,
 output wire [27:0] state_q,output wire [3:0] clocks,
 output wire [29:0] flags);
 wire n0; // BNT.0
 wire n1; // BNT.0'
 wire n2; // BNT.1
 wire n3; // BNT.1'
 wire n4; // BNT.2
 wire n5; // BNT.2'
 wire n6; // BNT.3
 wire n7; // BNT.3'
 wire n8; // CAHold
 wire n9; // CP=UseCPReg
 wire n10; // CPAddr.0'
 wire n11; // CPAddr.1'
 wire n12; // CPAddr.2'
 wire n13; // CPOut.1
 wire n14; // CPOut.2
 wire n15; // CPOut.3
 wire n16; // CPOut.4
 wire n17; // CPOut.5
 wire n18; // CPOut.6
 wire n19; // CPOut.7
 wire n20; // CPStrb'
 wire n21; // CPStrb0'
 wire n22; // CPStrb1'
 wire n23; // CPStrb2'
 wire n24; // CPStrb3'
 wire n25; // CTask.0
 wire n26; // CTask.0'
 wire n27; // CTask.1
 wire n28; // CTask.2
 wire n29; // CTask.3
 wire n30; // Call14'
 wire n31; // ClrReady
 wire n32; // ContA18.sil+3
 wire n33; // ContA18.sil+4
 wire n34; // FF=Notify'
 wire n35; // FreezeAC
 wire n36; // GND158
 wire n37; // GetTLink
 wire n38; // IsNext.01'
 wire n39; // IsNext.02'
 wire n40; // IsNext.03'
 wire n41; // IsNext.04'
 wire n42; // IsNext.05'
 wire n43; // IsNext.06'
 wire n44; // IsNext.07'
 wire n45; // IsNext.08'
 wire n46; // IsNext.09'
 wire n47; // IsNext.10'
 wire n48; // IsNext.11'
 wire n49; // IsNext.12'
 wire n50; // IsNext.13'
 wire n51; // IsNext.14'
 wire n52; // IsNext.15'
 wire n53; // Jam
 wire n54; // NoDispatch
 wire n55; // PreEmpting'
 wire n56; // Ready.01
 wire n57; // Ready.02
 wire n58; // Ready.03
 wire n59; // Ready.04
 wire n60; // Ready.05
 wire n61; // Ready.06
 wire n62; // Ready.07
 wire n63; // Ready.08
 wire n64; // Ready.09
 wire n65; // Ready.10
 wire n66; // Ready.11
 wire n67; // Ready.12
 wire n68; // Ready.13
 wire n69; // Ready.14
 wire n70; // Ready.15
 wire n71; // RepeatCur
 wire n72; // SCorFreezeb
 wire n73; // SetReady.01
 wire n74; // SetReady.02
 wire n75; // SetReady.03
 wire n76; // SetReady.04
 wire n77; // SetReady.05
 wire n78; // SetReady.06
 wire n79; // SetReady.07
 wire n80; // SetReady.08
 wire n81; // SetReady.09
 wire n82; // SetReady.10
 wire n83; // SetReady.11
 wire n84; // SetReady.12
 wire n85; // SetReady.13
 wire n86; // SetReady.14
 wire n87; // SetReady.15
 wire n88; // StopAtT1
 wire n89; // Switch'b
 wire n90; // bFF.4
 wire n91; // bFF.4'
 wire n92; // bFF.5
 wire n93; // bFF.6
 wire n94; // bFF.7
 wire n95; // fhWriteTLinkX'
 wire n96; // h*fclk0'Aa
 wire n97; // h*fclk0'Ab
 wire n98; // h*fclk0'Ac
 wire n99; // preclk0'Aa
 wire n100; // preclk2'Aa
 wire n101; // rCT
 wire n102; // rMIRa
 wire n103; // rStop
 assign n36=1'b0;
 assign n0=pins[0];
 assign n1=~pins[0];
 assign n2=pins[1];
 assign n3=~pins[1];
 assign n4=pins[2];
 assign n5=~pins[2];
 assign n6=pins[3];
 assign n7=~pins[3];
 assign n8=pins[16];
 assign n10=pins[33];
 assign n11=pins[32];
 assign n12=pins[31];
 assign n13=pins[24];
 assign n14=pins[25];
 assign n15=pins[26];
 assign n16=pins[27];
 assign n17=pins[28];
 assign n18=pins[29];
 assign n19=pins[30];
 assign n20=pins[34];
 assign n25=pins[4];
 assign n26=~pins[4];
 assign n27=pins[5];
 assign n28=pins[6];
 assign n29=pins[7];
 assign n32=pins[22];
 assign n33=pins[23];
 assign n34=pins[14];
 assign n35=pins[17];
 assign n55=pins[13];
 assign n71=pins[20];
 assign n72=pins[21];
 assign n89=pins[12];
 assign n90=pins[8];
 assign n91=~pins[8];
 assign n92=pins[9];
 assign n93=pins[10];
 assign n94=pins[11];
 assign n99=pins[18];
 assign n100=pins[19];
 wire n9_i02_3;
 assign n9=n9_i02_3;
 wire n21_a01_10;
 assign n21=n21_a01_10;
 wire n22_a01_11;
 assign n22=n22_a01_11;
 wire n23_a01_12;
 assign n23=n23_a01_12;
 wire n24_a01_13;
 assign n24=n24_a01_13;
 wire n30_d08_9;
 assign n30=n30_d08_9;
 wire n31_i02_13;
 assign n31=n31_i02_13;
 wire n37_i02_2;
 assign n37=n37_i02_2;
 wire n38_f08_5;
 assign n38=n38_f08_5;
 wire n39_f08_4;
 assign n39=n39_f08_4;
 wire n40_f08_3;
 assign n40=n40_f08_3;
 wire n41_f08_13;
 assign n41=n41_f08_13;
 wire n42_f08_12;
 assign n42=n42_f08_12;
 wire n43_f08_11;
 assign n43=n43_f08_11;
 wire n44_f08_10;
 assign n44=n44_f08_10;
 wire n45_f09_10;
 assign n45=n45_f09_10;
 wire n46_f09_11;
 assign n46=n46_f09_11;
 wire n47_f09_12;
 assign n47=n47_f09_12;
 wire n48_f09_13;
 assign n48=n48_f09_13;
 wire n49_f09_3;
 assign n49=n49_f09_3;
 wire n50_f09_4;
 assign n50=n50_f09_4;
 wire n51_f09_5;
 assign n51=n51_f09_5;
 wire n52_f09_6;
 assign n52=n52_f09_6;
 wire n53_j02_4;
 assign n53=n53_j02_4;
 wire n54_j02_15;
 assign n54=n54_j02_15;
 wire n56_a09_14;
 assign n56=n56_a09_14;
 wire n57_a09_15;
 assign n57=n57_a09_15;
 wire n58_a09_2;
 assign n58=n58_a09_2;
 wire n59_a09_3;
 assign n59=n59_a09_3;
 wire n60_b09_14;
 assign n60=n60_b09_14;
 wire n61_b09_15;
 assign n61=n61_b09_15;
 wire n62_b09_2;
 assign n62=n62_b09_2;
 wire n63_b09_3;
 assign n63=n63_b09_3;
 wire n64_c09_14;
 assign n64=n64_c09_14;
 wire n65_c09_15;
 assign n65=n65_c09_15;
 wire n66_c09_2;
 assign n66=n66_c09_2;
 wire n67_c09_3;
 assign n67=n67_c09_3;
 wire n68_d09_14;
 assign n68=n68_d09_14;
 wire n69_d09_15;
 assign n69=n69_d09_15;
 wire n70_d09_2;
 assign n70=n70_d09_2;
 wire n73_b06_5;
 wire n73_b07_5;
 wire n73_a08_2;
 assign n73=n73_b06_5 | n73_b07_5 | n73_a08_2;
 wire n74_b06_4;
 wire n74_b07_4;
 wire n74_a08_3;
 assign n74=n74_b06_4 | n74_b07_4 | n74_a08_3;
 wire n75_b06_3;
 wire n75_b07_3;
 wire n75_a08_14;
 assign n75=n75_b06_3 | n75_b07_3 | n75_a08_14;
 wire n76_b06_13;
 wire n76_b07_13;
 wire n76_a08_15;
 assign n76=n76_b06_13 | n76_b07_13 | n76_a08_15;
 wire n77_b06_12;
 wire n77_b07_12;
 wire n77_b08_2;
 assign n77=n77_b06_12 | n77_b07_12 | n77_b08_2;
 wire n78_b06_11;
 wire n78_b07_11;
 wire n78_b08_3;
 assign n78=n78_b06_11 | n78_b07_11 | n78_b08_3;
 wire n79_b06_10;
 wire n79_b07_10;
 wire n79_b08_14;
 assign n79=n79_b06_10 | n79_b07_10 | n79_b08_14;
 wire n80_c06_6;
 wire n80_c07_6;
 wire n80_b08_15;
 assign n80=n80_c06_6 | n80_c07_6 | n80_b08_15;
 wire n81_c06_5;
 wire n81_c07_5;
 wire n81_c08_2;
 assign n81=n81_c06_5 | n81_c07_5 | n81_c08_2;
 wire n82_c06_4;
 wire n82_c07_4;
 wire n82_c08_3;
 assign n82=n82_c06_4 | n82_c07_4 | n82_c08_3;
 wire n83_c06_3;
 wire n83_c07_3;
 wire n83_c08_14;
 assign n83=n83_c06_3 | n83_c07_3 | n83_c08_14;
 wire n84_c06_13;
 wire n84_c07_13;
 wire n84_c08_15;
 assign n84=n84_c06_13 | n84_c07_13 | n84_c08_15;
 wire n85_c06_12;
 wire n85_c07_12;
 wire n85_d08_2;
 assign n85=n85_c06_12 | n85_c07_12 | n85_d08_2;
 wire n86_c06_11;
 wire n86_c07_11;
 wire n86_d08_3;
 assign n86=n86_c06_11 | n86_c07_11 | n86_d08_3;
 wire n87_c06_10;
 wire n87_c07_10;
 wire n87_d08_14;
 assign n87=n87_c06_10 | n87_c07_10 | n87_d08_14;
 wire n88_j02_3;
 assign n88=n88_j02_3;
 wire n95_d07_3;
 assign n95=n95_d07_3;
 wire n96_d07_13;
 assign n96=n96_d07_13;
 wire n97_d07_12;
 assign n97=n97_d07_12;
 wire n98_d07_14;
 assign n98=n98_d07_14;
 wire n101_j02_13;
 assign n101=n101_j02_13;
 wire n102_j02_14;
 assign n102=n102_j02_14;
 wire n103_j02_2;
 assign n103=n103_j02_2;
 cell_MC10161 a01(.p2(n20),.p7(n12),.p9(n11),.p10(n21_a01_10),.p11(n22_a01_11),.p12(n23_a01_12),.p13(n24_a01_13),.p14(n10),.p15(1'b0));
 cell_MC10104 a08(.p2(n73_a08_2),.p3(n74_a08_3),.p4(n56),.p5(n38),.p6(n39),.p7(n57),.p10(n58),.p11(n40),.p12(n41),.p13(n59),.p14(n75_a08_14),.p15(n76_a08_15),.p16(1'b0));
 original_F10000 a09(.p2(n58_a09_2),.p3(n59_a09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n76),.p9(n75),.p10(n74),.p11(n73),.p12(n31),.p13(n97),.p14(n56_a09_14),.p15(n57_a09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:4]),.state_q(state_q[0+:4]));
 cell_MC10162 b06(.p2(n34),.p3(n75_b06_3),.p4(n74_b06_4),.p5(n73_b06_5),.p7(n94),.p9(n93),.p10(n79_b06_10),.p11(n78_b06_11),.p12(n77_b06_12),.p13(n76_b06_13),.p14(n92),.p15(n90));
 cell_MC10162 b07(.p2(n55),.p3(n75_b07_3),.p4(n74_b07_4),.p5(n73_b07_5),.p7(n29),.p9(n28),.p10(n79_b07_10),.p11(n78_b07_11),.p12(n77_b07_12),.p13(n76_b07_13),.p14(n27),.p15(n25));
 cell_MC10104 b08(.p2(n77_b08_2),.p3(n78_b08_3),.p4(n60),.p5(n42),.p6(n43),.p7(n61),.p10(n62),.p11(n44),.p12(n45),.p13(n63),.p14(n79_b08_14),.p15(n80_b08_15),.p16(1'b0));
 original_F10000 b09(.p2(n62_b09_2),.p3(n63_b09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n80),.p9(n79),.p10(n78),.p11(n77),.p12(n31),.p13(n97),.p14(n60_b09_14),.p15(n61_b09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[4+:4]),.state_q(state_q[4+:4]));
 cell_MC10162 c06(.p2(n34),.p3(n83_c06_3),.p4(n82_c06_4),.p5(n81_c06_5),.p6(n80_c06_6),.p7(n94),.p9(n93),.p10(n87_c06_10),.p11(n86_c06_11),.p12(n85_c06_12),.p13(n84_c06_13),.p14(n92),.p15(n91));
 cell_MC10162 c07(.p2(n55),.p3(n83_c07_3),.p4(n82_c07_4),.p5(n81_c07_5),.p6(n80_c07_6),.p7(n29),.p9(n28),.p10(n87_c07_10),.p11(n86_c07_11),.p12(n85_c07_12),.p13(n84_c07_13),.p14(n27),.p15(n26));
 cell_MC10104 c08(.p2(n81_c08_2),.p3(n82_c08_3),.p4(n64),.p5(n46),.p6(n47),.p7(n65),.p10(n66),.p11(n48),.p12(n49),.p13(n67),.p14(n83_c08_14),.p15(n84_c08_15),.p16(1'b0));
 original_F10000 c09(.p2(n66_c09_2),.p3(n67_c09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n84),.p9(n83),.p10(n82),.p11(n81),.p12(n31),.p13(n98),.p14(n64_c09_14),.p15(n65_c09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_SE10210 d07(.p3(n95_d07_3),.p5(n8),.p6(n100),.p7(n72),.p8(1'b0),.p9(n71),.p10(n99),.p11(n35),.p12(n97_d07_12),.p13(n96_d07_13),.p14(n98_d07_14),.p15(n36),.p16(1'b0));
 cell_MC10104 d08(.p2(n85_d08_2),.p3(n86_d08_3),.p4(n68),.p5(n50),.p6(n51),.p7(n69),.p9(n30_d08_9),.p10(n70),.p11(n52),.p12(n33),.p13(n32),.p14(n87_d08_14),.p16(1'b0));
 original_F10000 d09(.p2(n70_d09_2),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n87),.p10(n86),.p11(n85),.p12(n31),.p13(n98),.p14(n68_d09_14),.p15(n69_d09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 cell_MC10161 f08(.p2(n0),.p3(n40_f08_3),.p4(n39_f08_4),.p5(n38_f08_5),.p7(n6),.p9(n4),.p10(n44_f08_10),.p11(n43_f08_11),.p12(n42_f08_12),.p13(n41_f08_13),.p14(n2),.p15(n89));
 cell_MC10161 f09(.p2(n1),.p3(n49_f09_3),.p4(n50_f09_4),.p5(n51_f09_5),.p6(n52_f09_6),.p7(n7),.p9(n5),.p10(n45_f09_10),.p11(n46_f09_11),.p12(n47_f09_12),.p13(n48_f09_13),.p14(n3),.p15(n89));
 original_MC10176 i02(.p1(1'b0),.p2(n37_i02_2),.p3(n9_i02_3),.p5(n15),.p6(n16),.p7(n14),.p8(1'b0),.p9(n22),.p10(n19),.p11(1'b0),.p12(1'b0),.p13(n31_i02_13),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[22+:6]),.state_q(state_q[22+:6]));
 original_MC10176 j02(.p1(1'b0),.p2(n103_j02_2),.p3(n88_j02_3),.p4(n53_j02_4),.p5(n13),.p6(n14),.p7(n15),.p8(1'b0),.p9(n21),.p10(n18),.p11(n17),.p12(n16),.p13(n101_j02_13),.p14(n102_j02_14),.p15(n54_j02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:6]),.state_q(state_q[16+:6]));
 assign clocks[0]=n97;
 assign clocks[1]=n98;
 assign clocks[2]=n21;
 assign clocks[3]=n22;
 assign flags[0]=n38;
 assign flags[1]=n39;
 assign flags[2]=n40;
 assign flags[3]=n41;
 assign flags[4]=n42;
 assign flags[5]=n43;
 assign flags[6]=n44;
 assign flags[7]=n45;
 assign flags[8]=n46;
 assign flags[9]=n47;
 assign flags[10]=n48;
 assign flags[11]=n49;
 assign flags[12]=n50;
 assign flags[13]=n51;
 assign flags[14]=n52;
 assign flags[15]=n56;
 assign flags[16]=n57;
 assign flags[17]=n58;
 assign flags[18]=n59;
 assign flags[19]=n60;
 assign flags[20]=n61;
 assign flags[21]=n62;
 assign flags[22]=n63;
 assign flags[23]=n64;
 assign flags[24]=n65;
 assign flags[25]=n66;
 assign flags[26]=n67;
 assign flags[27]=n68;
 assign flags[28]=n69;
 assign flags[29]=n70;
endmodule
`default_nettype wire
