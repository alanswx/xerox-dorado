`timescale 1ps/1ps
module original_F10000 #(parameter integer DELAY_PS=1000)(
 input wire p4,p13,p11,p10,p9,p7,p6,p12,p5,
 output wire p14,p15,p2,p3,input wire fixture_load,
 input wire [3:0] fixture_state,output reg [3:0] state_q);
 wire clk=p4|p13;
 always @(posedge clk or posedge p12 or posedge fixture_load) begin
  if(fixture_load)state_q<=fixture_state;
  else if(p12)state_q<=#(DELAY_PS) 0;
  else begin
   if(p4 || p5 || p6)$fatal(1,"Ready reference used outside original parallel-load wiring");
   state_q<=#(DELAY_PS) {p11,p10,p9,p7};
  end
 end
 assign {p14,p15,p2,p3}=state_q;
endmodule
