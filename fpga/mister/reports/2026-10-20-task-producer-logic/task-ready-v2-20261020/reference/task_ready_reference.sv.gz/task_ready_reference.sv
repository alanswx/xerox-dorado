`timescale 1ns/1ps
`default_nettype none
module task_ready_reference(input wire fixture_load,input wire [15:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [15:0] state_q,output wire [1:0] clocks,
 output wire [29:0] flags);
 wire n0; // BNT.0
 wire n1; // BNT.0'
 wire n2; // BNT.1
 wire n3; // BNT.1'
 wire n4; // BNT.2
 wire n5; // BNT.2'
 wire n6; // BNT.3
 wire n7; // BNT.3'
 wire n8; // CAHold
 wire n9; // CTask.0
 wire n10; // CTask.0'
 wire n11; // CTask.1
 wire n12; // CTask.2
 wire n13; // CTask.3
 wire n14; // Call14'
 wire n15; // ClrReady
 wire n16; // ContA18.sil+3
 wire n17; // ContA18.sil+4
 wire n18; // FF=Notify'
 wire n19; // FreezeAC
 wire n20; // GND158
 wire n21; // IsNext.01'
 wire n22; // IsNext.02'
 wire n23; // IsNext.03'
 wire n24; // IsNext.04'
 wire n25; // IsNext.05'
 wire n26; // IsNext.06'
 wire n27; // IsNext.07'
 wire n28; // IsNext.08'
 wire n29; // IsNext.09'
 wire n30; // IsNext.10'
 wire n31; // IsNext.11'
 wire n32; // IsNext.12'
 wire n33; // IsNext.13'
 wire n34; // IsNext.14'
 wire n35; // IsNext.15'
 wire n36; // PreEmpting'
 wire n37; // Ready.01
 wire n38; // Ready.02
 wire n39; // Ready.03
 wire n40; // Ready.04
 wire n41; // Ready.05
 wire n42; // Ready.06
 wire n43; // Ready.07
 wire n44; // Ready.08
 wire n45; // Ready.09
 wire n46; // Ready.10
 wire n47; // Ready.11
 wire n48; // Ready.12
 wire n49; // Ready.13
 wire n50; // Ready.14
 wire n51; // Ready.15
 wire n52; // RepeatCur
 wire n53; // SCorFreezeb
 wire n54; // SetReady.01
 wire n55; // SetReady.02
 wire n56; // SetReady.03
 wire n57; // SetReady.04
 wire n58; // SetReady.05
 wire n59; // SetReady.06
 wire n60; // SetReady.07
 wire n61; // SetReady.08
 wire n62; // SetReady.09
 wire n63; // SetReady.10
 wire n64; // SetReady.11
 wire n65; // SetReady.12
 wire n66; // SetReady.13
 wire n67; // SetReady.14
 wire n68; // SetReady.15
 wire n69; // Switch'b
 wire n70; // bFF.4
 wire n71; // bFF.4'
 wire n72; // bFF.5
 wire n73; // bFF.6
 wire n74; // bFF.7
 wire n75; // fhWriteTLinkX'
 wire n76; // h*fclk0'Aa
 wire n77; // h*fclk0'Ab
 wire n78; // h*fclk0'Ac
 wire n79; // preclk0'Aa
 wire n80; // preclk2'Aa
 assign n20=1'b0;
 assign n0=pins[0];
 assign n1=~pins[0];
 assign n2=pins[1];
 assign n3=~pins[1];
 assign n4=pins[2];
 assign n5=~pins[2];
 assign n6=pins[3];
 assign n7=~pins[3];
 assign n8=pins[16];
 assign n9=pins[4];
 assign n10=~pins[4];
 assign n11=pins[5];
 assign n12=pins[6];
 assign n13=pins[7];
 assign n15=pins[15];
 assign n16=pins[22];
 assign n17=pins[23];
 assign n18=pins[14];
 assign n19=pins[17];
 assign n36=pins[13];
 assign n52=pins[20];
 assign n53=pins[21];
 assign n69=pins[12];
 assign n70=pins[8];
 assign n71=~pins[8];
 assign n72=pins[9];
 assign n73=pins[10];
 assign n74=pins[11];
 assign n79=pins[18];
 assign n80=pins[19];
 wire n14_d08_9;
 assign n14=n14_d08_9;
 wire n21_f08_5;
 assign n21=n21_f08_5;
 wire n22_f08_4;
 assign n22=n22_f08_4;
 wire n23_f08_3;
 assign n23=n23_f08_3;
 wire n24_f08_13;
 assign n24=n24_f08_13;
 wire n25_f08_12;
 assign n25=n25_f08_12;
 wire n26_f08_11;
 assign n26=n26_f08_11;
 wire n27_f08_10;
 assign n27=n27_f08_10;
 wire n28_f09_10;
 assign n28=n28_f09_10;
 wire n29_f09_11;
 assign n29=n29_f09_11;
 wire n30_f09_12;
 assign n30=n30_f09_12;
 wire n31_f09_13;
 assign n31=n31_f09_13;
 wire n32_f09_3;
 assign n32=n32_f09_3;
 wire n33_f09_4;
 assign n33=n33_f09_4;
 wire n34_f09_5;
 assign n34=n34_f09_5;
 wire n35_f09_6;
 assign n35=n35_f09_6;
 wire n37_a09_14;
 assign n37=n37_a09_14;
 wire n38_a09_15;
 assign n38=n38_a09_15;
 wire n39_a09_2;
 assign n39=n39_a09_2;
 wire n40_a09_3;
 assign n40=n40_a09_3;
 wire n41_b09_14;
 assign n41=n41_b09_14;
 wire n42_b09_15;
 assign n42=n42_b09_15;
 wire n43_b09_2;
 assign n43=n43_b09_2;
 wire n44_b09_3;
 assign n44=n44_b09_3;
 wire n45_c09_14;
 assign n45=n45_c09_14;
 wire n46_c09_15;
 assign n46=n46_c09_15;
 wire n47_c09_2;
 assign n47=n47_c09_2;
 wire n48_c09_3;
 assign n48=n48_c09_3;
 wire n49_d09_14;
 assign n49=n49_d09_14;
 wire n50_d09_15;
 assign n50=n50_d09_15;
 wire n51_d09_2;
 assign n51=n51_d09_2;
 wire n54_b06_5;
 wire n54_b07_5;
 wire n54_a08_2;
 assign n54=n54_b06_5 | n54_b07_5 | n54_a08_2;
 wire n55_b06_4;
 wire n55_b07_4;
 wire n55_a08_3;
 assign n55=n55_b06_4 | n55_b07_4 | n55_a08_3;
 wire n56_b06_3;
 wire n56_b07_3;
 wire n56_a08_14;
 assign n56=n56_b06_3 | n56_b07_3 | n56_a08_14;
 wire n57_b06_13;
 wire n57_b07_13;
 wire n57_a08_15;
 assign n57=n57_b06_13 | n57_b07_13 | n57_a08_15;
 wire n58_b06_12;
 wire n58_b07_12;
 wire n58_b08_2;
 assign n58=n58_b06_12 | n58_b07_12 | n58_b08_2;
 wire n59_b06_11;
 wire n59_b07_11;
 wire n59_b08_3;
 assign n59=n59_b06_11 | n59_b07_11 | n59_b08_3;
 wire n60_b06_10;
 wire n60_b07_10;
 wire n60_b08_14;
 assign n60=n60_b06_10 | n60_b07_10 | n60_b08_14;
 wire n61_c06_6;
 wire n61_c07_6;
 wire n61_b08_15;
 assign n61=n61_c06_6 | n61_c07_6 | n61_b08_15;
 wire n62_c06_5;
 wire n62_c07_5;
 wire n62_c08_2;
 assign n62=n62_c06_5 | n62_c07_5 | n62_c08_2;
 wire n63_c06_4;
 wire n63_c07_4;
 wire n63_c08_3;
 assign n63=n63_c06_4 | n63_c07_4 | n63_c08_3;
 wire n64_c06_3;
 wire n64_c07_3;
 wire n64_c08_14;
 assign n64=n64_c06_3 | n64_c07_3 | n64_c08_14;
 wire n65_c06_13;
 wire n65_c07_13;
 wire n65_c08_15;
 assign n65=n65_c06_13 | n65_c07_13 | n65_c08_15;
 wire n66_c06_12;
 wire n66_c07_12;
 wire n66_d08_2;
 assign n66=n66_c06_12 | n66_c07_12 | n66_d08_2;
 wire n67_c06_11;
 wire n67_c07_11;
 wire n67_d08_3;
 assign n67=n67_c06_11 | n67_c07_11 | n67_d08_3;
 wire n68_c06_10;
 wire n68_c07_10;
 wire n68_d08_14;
 assign n68=n68_c06_10 | n68_c07_10 | n68_d08_14;
 wire n75_d07_3;
 assign n75=n75_d07_3;
 wire n76_d07_13;
 assign n76=n76_d07_13;
 wire n77_d07_12;
 assign n77=n77_d07_12;
 wire n78_d07_14;
 assign n78=n78_d07_14;
 cell_MC10104 a08(.p2(n54_a08_2),.p3(n55_a08_3),.p4(n37),.p5(n21),.p6(n22),.p7(n38),.p10(n39),.p11(n23),.p12(n24),.p13(n40),.p14(n56_a08_14),.p15(n57_a08_15),.p16(1'b0));
 original_F10000 a09(.p2(n39_a09_2),.p3(n40_a09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n57),.p9(n56),.p10(n55),.p11(n54),.p12(n15),.p13(n77),.p14(n37_a09_14),.p15(n38_a09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:4]),.state_q(state_q[0+:4]));
 cell_MC10162 b06(.p2(n18),.p3(n56_b06_3),.p4(n55_b06_4),.p5(n54_b06_5),.p7(n74),.p9(n73),.p10(n60_b06_10),.p11(n59_b06_11),.p12(n58_b06_12),.p13(n57_b06_13),.p14(n72),.p15(n70));
 cell_MC10162 b07(.p2(n36),.p3(n56_b07_3),.p4(n55_b07_4),.p5(n54_b07_5),.p7(n13),.p9(n12),.p10(n60_b07_10),.p11(n59_b07_11),.p12(n58_b07_12),.p13(n57_b07_13),.p14(n11),.p15(n9));
 cell_MC10104 b08(.p2(n58_b08_2),.p3(n59_b08_3),.p4(n41),.p5(n25),.p6(n26),.p7(n42),.p10(n43),.p11(n27),.p12(n28),.p13(n44),.p14(n60_b08_14),.p15(n61_b08_15),.p16(1'b0));
 original_F10000 b09(.p2(n43_b09_2),.p3(n44_b09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n61),.p9(n60),.p10(n59),.p11(n58),.p12(n15),.p13(n77),.p14(n41_b09_14),.p15(n42_b09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[4+:4]),.state_q(state_q[4+:4]));
 cell_MC10162 c06(.p2(n18),.p3(n64_c06_3),.p4(n63_c06_4),.p5(n62_c06_5),.p6(n61_c06_6),.p7(n74),.p9(n73),.p10(n68_c06_10),.p11(n67_c06_11),.p12(n66_c06_12),.p13(n65_c06_13),.p14(n72),.p15(n71));
 cell_MC10162 c07(.p2(n36),.p3(n64_c07_3),.p4(n63_c07_4),.p5(n62_c07_5),.p6(n61_c07_6),.p7(n13),.p9(n12),.p10(n68_c07_10),.p11(n67_c07_11),.p12(n66_c07_12),.p13(n65_c07_13),.p14(n11),.p15(n10));
 cell_MC10104 c08(.p2(n62_c08_2),.p3(n63_c08_3),.p4(n45),.p5(n29),.p6(n30),.p7(n46),.p10(n47),.p11(n31),.p12(n32),.p13(n48),.p14(n64_c08_14),.p15(n65_c08_15),.p16(1'b0));
 original_F10000 c09(.p2(n47_c09_2),.p3(n48_c09_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n65),.p9(n64),.p10(n63),.p11(n62),.p12(n15),.p13(n78),.p14(n45_c09_14),.p15(n46_c09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_SE10210 d07(.p3(n75_d07_3),.p5(n8),.p6(n80),.p7(n53),.p8(1'b0),.p9(n52),.p10(n79),.p11(n19),.p12(n77_d07_12),.p13(n76_d07_13),.p14(n78_d07_14),.p15(n20),.p16(1'b0));
 cell_MC10104 d08(.p2(n66_d08_2),.p3(n67_d08_3),.p4(n49),.p5(n33),.p6(n34),.p7(n50),.p9(n14_d08_9),.p10(n51),.p11(n35),.p12(n17),.p13(n16),.p14(n68_d08_14),.p16(1'b0));
 original_F10000 d09(.p2(n51_d09_2),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n68),.p10(n67),.p11(n66),.p12(n15),.p13(n78),.p14(n49_d09_14),.p15(n50_d09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 cell_MC10161 f08(.p2(n0),.p3(n23_f08_3),.p4(n22_f08_4),.p5(n21_f08_5),.p7(n6),.p9(n4),.p10(n27_f08_10),.p11(n26_f08_11),.p12(n25_f08_12),.p13(n24_f08_13),.p14(n2),.p15(n69));
 cell_MC10161 f09(.p2(n1),.p3(n32_f09_3),.p4(n33_f09_4),.p5(n34_f09_5),.p6(n35_f09_6),.p7(n7),.p9(n5),.p10(n28_f09_10),.p11(n29_f09_11),.p12(n30_f09_12),.p13(n31_f09_13),.p14(n3),.p15(n69));
 assign clocks[0]=n77;
 assign clocks[1]=n78;
 assign flags[0]=n21;
 assign flags[1]=n22;
 assign flags[2]=n23;
 assign flags[3]=n24;
 assign flags[4]=n25;
 assign flags[5]=n26;
 assign flags[6]=n27;
 assign flags[7]=n28;
 assign flags[8]=n29;
 assign flags[9]=n30;
 assign flags[10]=n31;
 assign flags[11]=n32;
 assign flags[12]=n33;
 assign flags[13]=n34;
 assign flags[14]=n35;
 assign flags[15]=n37;
 assign flags[16]=n38;
 assign flags[17]=n39;
 assign flags[18]=n40;
 assign flags[19]=n41;
 assign flags[20]=n42;
 assign flags[21]=n43;
 assign flags[22]=n44;
 assign flags[23]=n45;
 assign flags[24]=n46;
 assign flags[25]=n47;
 assign flags[26]=n48;
 assign flags[27]=n49;
 assign flags[28]=n50;
 assign flags[29]=n51;
endmodule
`default_nettype wire
