`timescale 1ps/1ps
module tb_cp_control;
 reg load=0;reg [11:0] fixture=0,state=0;
 reg [10:0] pins=11'h780,before_pins=11'h780;
 wire [11:0] original_q,next_q;wire [1:0] clocks,events,after_clocks;
 wire [11:0] unused_flags;
 cp_control_reference original(load,fixture,1'b0,1'b0,1'b0,{17'b0,pins},original_q,clocks,unused_flags);
 dorado_cp_control_step dut(state,before_pins,pins,next_q,events,after_clocks);
 integer checks=0,count0=0,count1=0;reg [1:0] observed=0;
 reg [11:0] changed=0;reg [7:0] addresses=0;
 always @(posedge clocks[0]) observed[0]=1;
 always @(posedge clocks[1]) observed[1]=1;
 task event_pins(input [10:0] value);
  reg [11:0] old;reg [1:0] expected_events;
  begin
   old=state;observed=0;before_pins=pins;pins=value;
   #20000;
   if(original_q!==next_q || clocks!==after_clocks || observed!==events) begin
    $display("CP_FAIL check=%0d before=%h after=%h old=%h expected=%h actual=%h clocks=%b/%b events=%b/%b",checks,before_pins,pins,state,original_q,next_q,clocks,after_clocks,observed,events);
    $fatal(1,"CP producer mismatch");
   end
   expected_events=events;changed=changed|(old^next_q);state=next_q;
   count0=count0+expected_events[0];count1=count1+expected_events[1];checks=checks+1;
   #100;
  end
 endtask
 reg [10:0] selected;
 initial begin
  #20000;fixture=12'hfff;load=1;#20000;load=0;state=fixture;#20000;
  for(integer address=0;address<8;address=address+1) begin
   for(integer data=0;data<128;data=data+1) begin
    selected={1'b1,~3'(address),7'(data)};event_pins(selected);
    selected[10]=0;event_pins(selected);
    // No clock occurs on changing data in the active strobe window.
    selected[6:0]=~7'(data);event_pins(selected);
    selected[10]=1;event_pins(selected);
    addresses[address]=1;
   end
  end
  // Direct address changes during an asserted strobe must also obey the
  // decoder's actual outgoing-clock edge, rather than a software write API.
  for(integer address=0;address<8;address=address+1) begin
   selected={1'b0,~3'(address),7'(address)};event_pins(selected);
  end
  selected[10]=1;event_pins(selected);
  if(count0!=129 || count1!=129 || changed!=12'hfff || addresses!=8'hff)
   $fatal(1,"CP coverage incomplete clocks=%0d/%0d changed=%h addr=%h",count0,count1,changed,addresses);
  $display("CP_CONTROL PASS checks=%0d clock0=%0d clock1=%0d changed=%h addresses=%h",checks,count0,count1,changed,addresses);
  $finish;
 end
endmodule
