`timescale 1ns/1ps
`default_nettype none
module cp_control_reference(input wire fixture_load,input wire [11:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [11:0] state_q,output wire [1:0] clocks,
 output wire [11:0] flags);
 wire n0; // CP=UseCPReg
 wire n1; // CPAddr.0'
 wire n2; // CPAddr.1'
 wire n3; // CPAddr.2'
 wire n4; // CPOut.1
 wire n5; // CPOut.2
 wire n6; // CPOut.3
 wire n7; // CPOut.4
 wire n8; // CPOut.5
 wire n9; // CPOut.6
 wire n10; // CPOut.7
 wire n11; // CPStrb'
 wire n12; // CPStrb0'
 wire n13; // CPStrb1'
 wire n14; // CPStrb2'
 wire n15; // CPStrb3'
 wire n16; // ClrReady
 wire n17; // GetTLink
 wire n18; // Jam
 wire n19; // NoDispatch
 wire n20; // StopAtT1
 wire n21; // rCT
 wire n22; // rMIRa
 wire n23; // rStop
 assign n1=pins[9];
 assign n2=pins[8];
 assign n3=pins[7];
 assign n4=pins[0];
 assign n5=pins[1];
 assign n6=pins[2];
 assign n7=pins[3];
 assign n8=pins[4];
 assign n9=pins[5];
 assign n10=pins[6];
 assign n11=pins[10];
 wire n0_i02_3;
 assign n0=n0_i02_3;
 wire n12_a01_10;
 assign n12=n12_a01_10;
 wire n13_a01_11;
 assign n13=n13_a01_11;
 wire n14_a01_12;
 assign n14=n14_a01_12;
 wire n15_a01_13;
 assign n15=n15_a01_13;
 wire n16_i02_13;
 assign n16=n16_i02_13;
 wire n17_i02_2;
 assign n17=n17_i02_2;
 wire n18_j02_4;
 assign n18=n18_j02_4;
 wire n19_j02_15;
 assign n19=n19_j02_15;
 wire n20_j02_3;
 assign n20=n20_j02_3;
 wire n21_j02_13;
 assign n21=n21_j02_13;
 wire n22_j02_14;
 assign n22=n22_j02_14;
 wire n23_j02_2;
 assign n23=n23_j02_2;
 cell_MC10161 a01(.p2(n11),.p7(n3),.p9(n2),.p10(n12_a01_10),.p11(n13_a01_11),.p12(n14_a01_12),.p13(n15_a01_13),.p14(n1),.p15(1'b0));
 original_MC10176 i02(.p1(1'b0),.p2(n17_i02_2),.p3(n0_i02_3),.p5(n6),.p6(n7),.p7(n5),.p8(1'b0),.p9(n13),.p10(n10),.p11(1'b0),.p12(1'b0),.p13(n16_i02_13),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:6]),.state_q(state_q[6+:6]));
 original_MC10176 j02(.p1(1'b0),.p2(n23_j02_2),.p3(n20_j02_3),.p4(n18_j02_4),.p5(n4),.p6(n5),.p7(n6),.p8(1'b0),.p9(n12),.p10(n9),.p11(n8),.p12(n7),.p13(n21_j02_13),.p14(n22_j02_14),.p15(n19_j02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 assign clocks[0]=n12;
 assign clocks[1]=n13;
 assign flags[0]=j02.state_q[0];
 assign flags[1]=j02.state_q[1];
 assign flags[2]=j02.state_q[2];
 assign flags[3]=j02.state_q[3];
 assign flags[4]=j02.state_q[4];
 assign flags[5]=j02.state_q[5];
 assign flags[6]=i02.state_q[0];
 assign flags[7]=i02.state_q[1];
 assign flags[8]=i02.state_q[2];
 assign flags[9]=i02.state_q[3];
 assign flags[10]=i02.state_q[4];
 assign flags[11]=i02.state_q[5];
endmodule
`default_nettype wire
