module clock_fit(input wire host_clk,input wire [97:0] pins,
 output reg [65:0] result);
 reg [97:0] input_stage,launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [27:0] q,next_q;
 wire [34:0] before_controls,after_controls;
 wire [3:0] events,clocks;
 wire [14:0] is_next_n,ready;
 assign {q,before_controls,after_controls}=launch;
 dorado_task_producers_step evaluator(q,before_controls,after_controls,
   next_q,events,clocks,is_next_n,ready);
 always @(posedge host_clk) result<={next_q,events,clocks,is_next_n,ready};
endmodule
