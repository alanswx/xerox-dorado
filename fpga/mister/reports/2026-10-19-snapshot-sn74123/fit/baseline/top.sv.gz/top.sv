module snapshot_fit(
 input wire host_clk,advance,freeze,held,request,write,
 input wire [2:0] index,input wire [17:0] data,input wire [5:0] pins,
 output reg [107:0] result,output reg [11:0] outputs,output reg [5:0] frozen,done,error);
 reg [31:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,request,write,index,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;wire [2:0] index_r;wire [17:0] data_r;wire [5:0] pins_r;
 assign {step_r,freeze_r,held_r,request_r,write_r,index_r,data_r,pins_r}=launch;
 wire [107:0] result_w;wire [11:0] outputs_w;wire [5:0] frozen_w,done_w,error_w;
 always @(posedge host_clk){result,outputs,frozen,done,error}<={result_w,outputs_w,frozen_w,done_w,error_w};
 genvar i;
 generate for(i=0;i<6;i=i+1)begin:cases
 localparam integer SP=i<2?1:i==2?2:i==3?4:i==4?8:16;
 localparam integer NS=i==0?0:i==1?30:3000;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_SN74123_snapshot #(.SYSPER(SP),.TW_NS(NS)) cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w[i]),.state_done(done_w[i]),.state_error(error_w[i]),.state_result(result_w[18*i+:18]),
`else
 assign {frozen_w[i],done_w[i],error_w[i],result_w[18*i+:18]}=21'b0;
 cell_SN74123 #(.SYSPER(SP),.TW_NS(NS)) cell_inst(
`endif
 .sys_clk(host_clk),.p1(pins_r[0]),.p2(pins_r[1]),.p3(pins_r[2]),.p9(pins_r[3]),
 .p10(pins_r[4]),.p11(pins_r[5]),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p14(1'b0),.p15(1'b0),.p16(1'b1),
 .p13(outputs_w[2*i]),.p5(outputs_w[2*i+1]));
 end endgenerate
endmodule
