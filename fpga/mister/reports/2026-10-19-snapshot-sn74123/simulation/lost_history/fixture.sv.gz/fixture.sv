module sn74123_fixture(
input wire host_clk,ref_clk,advance,freeze,held,request,write,individual,
input wire [5:0] pins,input wire [2:0] index,input wire [17:0] data,restore_data[6],
output wire [17:0] result[6],output wire [69:0] physical[6],original_state[6],
output wire [5:0] frozen,done,error,output wire [11:0] outputs,original_outputs);
genvar i;generate for(i=0;i<6;i=i+1)begin:cells
localparam integer SP=i<2?1:i==2?2:i==3?4:i==4?8:16;
localparam integer NS=i==0?0:i==1?30:3000;
cell_SN74123_snapshot #(.SYSPER(SP),.TW_NS(NS)) candidate(.state_host_clk(host_clk),.state_advance(advance),
.state_freeze(freeze),.state_guest_held(held),.state_request(request),.state_write(write),
.state_index(index),.state_data(individual?restore_data[i]:data),.state_frozen(frozen[i]),.state_done(done[i]),.state_error(error[i]),.state_result(result[i]),.sys_clk(ref_clk),.p1(pins[0]),.p2(pins[1]),.p3(pins[2]),.p9(pins[3]),.p10(pins[4]),.p11(pins[5]),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p14(1'b0),.p15(1'b0),.p16(1'b1),.p13(outputs[2*i]),.p5(outputs[2*i+1]));
cell_SN74123 #(.SYSPER(SP),.TW_NS(NS)) original(.sys_clk(ref_clk),.p1(pins[0]),.p2(pins[1]),.p3(pins[2]),.p9(pins[3]),.p10(pins[4]),.p11(pins[5]),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p14(1'b0),.p15(1'b0),.p16(1'b1),.p13(original_outputs[2*i]),.p5(original_outputs[2*i+1]));
assign physical[i]={candidate.c2_d,candidate.b2_d,candidate.a2_d,candidate.c1_d,candidate.b1_d,candidate.a1_d,candidate.t2,candidate.t1};
assign original_state[i]={original.c2_d,original.b2_d,original.a2_d,original.c1_d,original.b1_d,original.a1_d,original.t2,original.t1};
end endgenerate endmodule
