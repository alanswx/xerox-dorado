#pragma once
constexpr unsigned INPUTS=124,OUTPUTS=113,AUX_BITS=2056,WORDS=287,MAPS=21,SMALLS=10,MAP_AUX_START=245,INDEX_COUNT=16777216,STATE_BITS=1378312;
struct StateWord{unsigned word,width,offset;};
constexpr StateWord state_words[]={
{0,11,0},
{131072,11,11},
{262144,13,22},
{393216,11,35},
{524288,11,46},
{655360,5,57},
{786432,13,62},
{917504,11,75},
{1048576,6,86},
{1179648,13,92},
{1310720,11,105},
{1441792,5,116},
{1572864,13,121},
{1703936,13,134},
{1835008,11,147},
{1966080,13,158},
{2097152,11,171},
{2228224,13,182},
{2359296,6,195},
{2490368,5,201},
{2621440,11,206},
{2752512,11,217},
{2883584,11,228},
{3014656,11,239},
{3145728,5,250},
{3276800,11,255},
{3407872,11,266},
{3538944,11,277},
{3670016,4,288},
{3801088,4,292},
{3932160,13,296},
{4063232,13,309},
{4194304,13,322},
{4325376,9,335},
{4456448,13,344},
{4587520,11,357},
{4718592,13,368},
{4849664,11,381},
{4980736,13,392},
{5111808,13,405},
{5242880,13,418},
{5373952,13,431},
{5505024,13,444},
{5636096,13,457},
{5767168,11,470},
{5898240,13,481},
{6029312,13,494},
{6160384,11,507},
{6291456,13,518},
{6422528,7,531},
{6553600,13,538},
{6684672,11,551},
{6815744,11,562},
{6946816,13,573},
{7077888,11,586},
{7208960,11,597},
{7340032,13,608},
{7471104,11,621},
{7602176,11,632},
{7733248,11,643},
{7864320,11,654},
{7995392,13,665},
{8126464,13,678},
{8257536,11,691},
{8388608,13,702},
{8519680,11,715},
{8650752,6,726},
{8781824,13,732},
{8912896,13,745},
{9043968,11,758},
{9175040,11,769},
{9306112,13,780},
{9437184,13,793},
{9568256,13,806},
{9699328,4,819},
{9699329,4,823},
{9699330,4,827},
{9699331,4,831},
{9699332,4,835},
{9699333,4,839},
{9699334,4,843},
{9699335,4,847},
{9699336,4,851},
{9699337,4,855},
{9699338,4,859},
{9699339,4,863},
{9699340,4,867},
{9699341,4,871},
{9699342,4,875},
{9699343,4,879},
{9699344,10,883},
{9830400,4,893},
{9830401,4,897},
{9830402,4,901},
{9830403,4,905},
{9830404,4,909},
{9830405,4,913},
{9830406,4,917},
{9830407,4,921},
{9830408,4,925},
{9830409,4,929},
{9830410,4,933},
{9830411,4,937},
{9830412,4,941},
{9830413,4,945},
{9830414,4,949},
{9830415,4,953},
{9830416,10,957},
{9961472,4,967},
{9961473,4,971},
{9961474,4,975},
{9961475,4,979},
{9961476,4,983},
{9961477,4,987},
{9961478,4,991},
{9961479,4,995},
{9961480,4,999},
{9961481,4,1003},
{9961482,4,1007},
{9961483,4,1011},
{9961484,4,1015},
{9961485,4,1019},
{9961486,4,1023},
{9961487,4,1027},
{9961488,10,1031},
{10092544,4,1041},
{10092545,4,1045},
{10092546,4,1049},
{10092547,4,1053},
{10092548,4,1057},
{10092549,4,1061},
{10092550,4,1065},
{10092551,4,1069},
{10092552,4,1073},
{10092553,4,1077},
{10092554,4,1081},
{10092555,4,1085},
{10092556,4,1089},
{10092557,4,1093},
{10092558,4,1097},
{10092559,4,1101},
{10092560,10,1105},
{10223616,4,1115},
{10223617,4,1119},
{10223618,4,1123},
{10223619,4,1127},
{10223620,4,1131},
{10223621,4,1135},
{10223622,4,1139},
{10223623,4,1143},
{10223624,4,1147},
{10223625,4,1151},
{10223626,4,1155},
{10223627,4,1159},
{10223628,4,1163},
{10223629,4,1167},
{10223630,4,1171},
{10223631,4,1175},
{10223632,10,1179},
{10354688,4,1189},
{10354689,4,1193},
{10354690,4,1197},
{10354691,4,1201},
{10354692,4,1205},
{10354693,4,1209},
{10354694,4,1213},
{10354695,4,1217},
{10354696,4,1221},
{10354697,4,1225},
{10354698,4,1229},
{10354699,4,1233},
{10354700,4,1237},
{10354701,4,1241},
{10354702,4,1245},
{10354703,4,1249},
{10354704,10,1253},
{10485760,4,1263},
{10485761,4,1267},
{10485762,4,1271},
{10485763,4,1275},
{10485764,4,1279},
{10485765,4,1283},
{10485766,4,1287},
{10485767,4,1291},
{10485768,4,1295},
{10485769,4,1299},
{10485770,4,1303},
{10485771,4,1307},
{10485772,4,1311},
{10485773,4,1315},
{10485774,4,1319},
{10485775,4,1323},
{10485776,10,1327},
{10616832,4,1337},
{10616833,4,1341},
{10616834,4,1345},
{10616835,4,1349},
{10616836,4,1353},
{10616837,4,1357},
{10616838,4,1361},
{10616839,4,1365},
{10616840,4,1369},
{10616841,4,1373},
{10616842,4,1377},
{10616843,4,1381},
{10616844,4,1385},
{10616845,4,1389},
{10616846,4,1393},
{10616847,4,1397},
{10616848,10,1401},
{10747904,4,1411},
{10747905,4,1415},
{10747906,4,1419},
{10747907,4,1423},
{10747908,4,1427},
{10747909,4,1431},
{10747910,4,1435},
{10747911,4,1439},
{10747912,4,1443},
{10747913,4,1447},
{10747914,4,1451},
{10747915,4,1455},
{10747916,4,1459},
{10747917,4,1463},
{10747918,4,1467},
{10747919,4,1471},
{10747920,10,1475},
{10878976,4,1485},
{10878977,4,1489},
{10878978,4,1493},
{10878979,4,1497},
{10878980,4,1501},
{10878981,4,1505},
{10878982,4,1509},
{10878983,4,1513},
{10878984,4,1517},
{10878985,4,1521},
{10878986,4,1525},
{10878987,4,1529},
{10878988,4,1533},
{10878989,4,1537},
{10878990,4,1541},
{10878991,4,1545},
{10878992,10,1549},
{13762560,14,1559},
{11075584,18,1573},
{11075585,5,1591},
{11206656,18,1596},
{11206657,5,1614},
{11337728,18,1619},
{11337729,5,1637},
{11468800,18,1642},
{11468801,5,1660},
{11599872,18,1665},
{11599873,5,1683},
{11730944,18,1688},
{11730945,5,1706},
{11862016,18,1711},
{11862017,5,1729},
{11993088,18,1734},
{11993089,5,1752},
{12124160,18,1757},
{12124161,5,1775},
{12255232,18,1780},
{12255233,5,1798},
{12386304,18,1803},
{12386305,5,1821},
{12517376,18,1826},
{12517377,5,1844},
{12648448,18,1849},
{12648449,5,1867},
{12779520,18,1872},
{12779521,5,1890},
{12910592,18,1895},
{12910593,5,1913},
{13041664,18,1918},
{13041665,5,1936},
{13172736,18,1941},
{13172737,5,1959},
{13303808,18,1964},
{13303809,5,1982},
{13434880,18,1987},
{13434881,5,2005},
{13565952,18,2010},
{13565953,5,2028},
{13697024,18,2033},
{13697025,5,2051}};
constexpr unsigned MAP_PACKAGES[]={84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104};
constexpr unsigned PIN_AfreeOrEc_p_b=0;
constexpr unsigned PIN_At_eq_Curt_p_=1;
constexpr unsigned PIN_AwantsDifHit_p_=2;
constexpr unsigned PIN_BMux_00=3;
constexpr unsigned PIN_BMux_01=4;
constexpr unsigned PIN_BMux_02=5;
constexpr unsigned PIN_BMux_03=6;
constexpr unsigned PIN_BMux_04=7;
constexpr unsigned PIN_BMux_05=8;
constexpr unsigned PIN_BMux_06=9;
constexpr unsigned PIN_BMux_07=10;
constexpr unsigned PIN_BMux_08=11;
constexpr unsigned PIN_BMux_09=12;
constexpr unsigned PIN_BMux_10=13;
constexpr unsigned PIN_BMux_11=14;
constexpr unsigned PIN_BMux_12=15;
constexpr unsigned PIN_BMux_13=16;
constexpr unsigned PIN_BMux_14=17;
constexpr unsigned PIN_BMux_15=18;
constexpr unsigned PIN_BMux_16=19;
constexpr unsigned PIN_BMux_17=20;
constexpr unsigned PIN_BNTGtCT_p_a=21;
constexpr unsigned PIN_CLK_mx_p_=22;
constexpr unsigned PIN_CacheRef_p_=23;
constexpr unsigned PIN_CacheRefInEc1=24;
constexpr unsigned PIN_ChipsAre256_s_16K=25;
constexpr unsigned PIN_ChipsAre64K=26;
constexpr unsigned PIN_ClkEnable_p_a=27;
constexpr unsigned PIN_CountMiss=28;
constexpr unsigned PIN_DMuxClk=29;
constexpr unsigned PIN_DMuxData=30;
constexpr unsigned PIN_DdataGood_p_=31;
constexpr unsigned PIN_DirtyIoFetchInA_p_=32;
constexpr unsigned PIN_DisHold=33;
constexpr unsigned PIN_ECFault=34;
constexpr unsigned PIN_EcDcomingForCt_p_=35;
constexpr unsigned PIN_EcKeepsAbusy=36;
constexpr unsigned PIN_EcWantsA=37;
constexpr unsigned PIN_ErrorsFromEc2=38;
constexpr unsigned PIN_FinNext=39;
constexpr unsigned PIN_FoutNext=40;
constexpr unsigned PIN_Hita=41;
constexpr unsigned PIN_HoldMapBuf=42;
constexpr unsigned PIN_IfuRefInEc1=43;
constexpr unsigned PIN_IoFetchInA_p_=44;
constexpr unsigned PIN_IoStoreInA=45;
constexpr unsigned PIN_LoadSinE=46;
constexpr unsigned PIN_LoadSinO=47;
constexpr unsigned PIN_M0=48;
constexpr unsigned PIN_M1=49;
constexpr unsigned PIN_M2=50;
constexpr unsigned PIN_M3=51;
constexpr unsigned PIN_MDMtag_p_=52;
constexpr unsigned PIN_MXHold=53;
constexpr unsigned PIN_MakeD_u_CD=54;
constexpr unsigned PIN_MakeD_u_Dbuf=55;
constexpr unsigned PIN_MakeF_u_D=56;
constexpr unsigned PIN_MakeFout_u_D=57;
constexpr unsigned PIN_MakeMDM_u_D_p_=58;
constexpr unsigned PIN_MakeSout_u_D=59;
constexpr unsigned PIN_MapAd_0=60;
constexpr unsigned PIN_MapAd_1=61;
constexpr unsigned PIN_MapAd_2=62;
constexpr unsigned PIN_MapAd_3=63;
constexpr unsigned PIN_MapAd_4=64;
constexpr unsigned PIN_MapAd_5=65;
constexpr unsigned PIN_MapAd_6=66;
constexpr unsigned PIN_MapAd_7=67;
constexpr unsigned PIN_MapAd_8=68;
constexpr unsigned PIN_MapRfsh_p_=69;
constexpr unsigned PIN_MapTroubleInEc1=70;
constexpr unsigned PIN_MapWait_m_D=71;
constexpr unsigned PIN_Map_u_InPair_p_=72;
constexpr unsigned PIN_Mcr_u__p_=73;
constexpr unsigned PIN_MemClkEnable_p_c=74;
constexpr unsigned PIN_MemError=75;
constexpr unsigned PIN_MemPE=76;
constexpr unsigned PIN_MemRfsh=77;
constexpr unsigned PIN_MemSH=78;
constexpr unsigned PIN_Next_0=79;
constexpr unsigned PIN_Next_1=80;
constexpr unsigned PIN_Next_2=81;
constexpr unsigned PIN_Next_3=82;
constexpr unsigned PIN_PairFull_p_=83;
constexpr unsigned PIN_PrivRefInPair=84;
constexpr unsigned PIN_ProcSrn_u__p_=85;
constexpr unsigned PIN_ProcTag=86;
constexpr unsigned PIN_ProcTagInA=87;
constexpr unsigned PIN_ReadInA_p_=88;
constexpr unsigned PIN_RfshPeriod=89;
constexpr unsigned PIN_STfree_p_=90;
constexpr unsigned PIN_SW=91;
constexpr unsigned PIN_StartMap_p_=92;
constexpr unsigned PIN_StkError=93;
constexpr unsigned PIN_Store_u_InA_p_=94;
constexpr unsigned PIN_Store_u_InEc1_p_=95;
constexpr unsigned PIN_SubTask_0=96;
constexpr unsigned PIN_SubTask_1=97;
constexpr unsigned PIN_TIOA_0=98;
constexpr unsigned PIN_TIOA_1=99;
constexpr unsigned PIN_TagInEc1=100;
constexpr unsigned PIN_UseAsrn=101;
constexpr unsigned PIN_VicIfMiss_p_=102;
constexpr unsigned PIN_VicInPair_p_=103;
constexpr unsigned PIN_VicOrFS1C=104;
constexpr unsigned PIN_WPinEc1=105;
constexpr unsigned PIN__u_Config=106;
constexpr unsigned PIN__u_FaultInfo=107;
constexpr unsigned PIN__u_MD=108;
constexpr unsigned PIN__u_MDdly_p_=109;
constexpr unsigned PIN__u_Map=110;
constexpr unsigned PIN__u_Pipe2=111;
constexpr unsigned PIN__u_Pipe3=112;
constexpr unsigned PIN__u_Pipe4=113;
constexpr unsigned PIN_dHitPerr=114;
constexpr unsigned PIN_dPipe02Ad_0=115;
constexpr unsigned PIN_dPipe02Ad_1=116;
constexpr unsigned PIN_dPipe02Ad_2=117;
constexpr unsigned PIN_dPipe02Ad_3=118;
constexpr unsigned PIN_dPipe34Ad_0=119;
constexpr unsigned PIN_dPipe34Ad_1=120;
constexpr unsigned PIN_dPipe34Ad_2=121;
constexpr unsigned PIN_dPipe34Ad_3=122;
constexpr unsigned PIN_dSTPerr=123;
