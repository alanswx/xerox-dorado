module snapshot_fit(
 input wire host_clk,advance,input wire [123:0] stimulus,
 input wire freeze,held,request,write,input wire [23:0] index,
 input wire [17:0] state_data,output reg [112:0] q,
 output reg frozen,done,error,output reg [17:0] result);
 // Both MemX neighbors sample on positive host edges; full20ns budgets.
 reg [170:0] launch;
 reg [170:0] input_stage;
 always @(negedge host_clk)
  input_stage<={advance,stimulus,freeze,held,request,write,index,state_data};
 always @(posedge host_clk) launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;
 wire [123:0] stimulus_r;wire [23:0] index_r;wire [17:0] state_r;
 assign {step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [112:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result}<={bank_q,bank_frozen,bank_done,bank_error,bank_result};

wire bank_AcanhaveMap_p___drv;
wire bank_At_eq_Curt_p___drv;
wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_CountMiss__drv;
wire bank_DMuxData__drv;
wire bank_DdataGood_p___drv;
wire bank_EcDcomingForCt_p___drv;
wire bank_EcWantsA__drv;
wire bank_EmuOrFT_p___drv;
wire bank_ErrorsFromEc2__drv;
wire bank_FinNext__drv;
wire bank_FinSubtask_0__drv;
wire bank_FinSubtask_1__drv;
wire bank_FinTask_0__drv;
wire bank_FinTask_1__drv;
wire bank_FinTask_2__drv;
wire bank_FinTask_3__drv;
wire bank_Fout_flt__drv;
wire bank_FoutNext__drv;
wire bank_FoutSubTask_0__drv;
wire bank_FoutSubtask_1__drv;
wire bank_FoutTask_0__drv;
wire bank_FoutTask_1__drv;
wire bank_FoutTask_2__drv;
wire bank_FoutTask_3__drv;
wire bank_HoldMapBuf__drv;
wire bank_IfuFaultInEc2__drv;
wire bank_LargeHold__drv;
wire bank_LdPipeVAdly_p___drv;
wire bank_LoadEcOut_p___drv;
wire bank_LoadSinE__drv;
wire bank_LoadSinO__drv;
wire bank_LoadSoutE_p___drv;
wire bank_LoadSoutO_p___drv;
wire bank_MDMtag_p___drv;
wire bank_MakeD_u_CD__drv;
wire bank_MakeD_u_Dbuf__drv;
wire bank_MakeF_u_D__drv;
wire bank_MakeFout_u_D__drv;
wire bank_MakeMDM_u_D_p___drv;
wire bank_MakeMD_u_D_p___drv;
wire bank_MakeSout_u_D__drv;
wire bank_MapRfsh_p___drv;
wire bank_MapTroubleInEc1__drv;
wire bank_MapWait_m_D__drv;
wire bank_MemAd_0__drv;
wire bank_MemAd_1__drv;
wire bank_MemAd_2__drv;
wire bank_MemAd_3__drv;
wire bank_MemAd_4__drv;
wire bank_MemAd_5__drv;
wire bank_MemAd_6__drv;
wire bank_MemAd_7__drv;
wire bank_MemAd_8__drv;
wire bank_MemCASa__drv;
wire bank_MemCASb__drv;
wire bank_MemError__drv;
wire bank_MemPE__drv;
wire bank_MemRASa__drv;
wire bank_MemRASb__drv;
wire bank_MemRfsh__drv;
wire bank_MemWEa__drv;
wire bank_MemWEb__drv;
wire bank_Mod0SinEn_p___drv;
wire bank_Mod0StrEn_p___drv;
wire bank_Mod1SinEn_p___drv;
wire bank_Mod1StrEn_p___drv;
wire bank_Mod2SinEn_p___drv;
wire bank_Mod2StrEn_p___drv;
wire bank_Mod3SinEn_p___drv;
wire bank_Mod3StrEn_p___drv;
wire bank_ProcTag__drv;
wire bank_ProcTagInA__drv;
wire bank_STfree_p___drv;
wire bank_ShiftEcOut__drv;
wire bank_ShiftSinE__drv;
wire bank_ShiftSinO__drv;
wire bank_ShiftSoutE__drv;
wire bank_ShiftSoutO__drv;
wire bank_StartEcChk_p___drv;
wire bank_StartEcGen_p___drv;
wire bank_TWReq_15__drv;
wire bank_Transport_p___drv;
wire bank_WPinEc1__drv;
wire bank_XWantsPipe__drv;
wire bank_dMDMad_0_p___drv;
wire bank_dMDMad_1_p___drv;
wire bank_dMDMad_2_p___drv;
wire bank_dMDMad_3_p___drv;
wire bank_dPipe02Ad_0__drv;
wire bank_dPipe02Ad_1__drv;
wire bank_dPipe02Ad_2__drv;
wire bank_dPipe02Ad_3__drv;
wire bank_dPipe34Ad_0__drv;
wire bank_dPipe34Ad_1__drv;
wire bank_dPipe34Ad_2__drv;
wire bank_dPipe34Ad_3__drv;
wire bank_preMCSb__drv;
assign bank_q={bank_preMCSb__drv,bank_dPipe34Ad_3__drv,bank_dPipe34Ad_2__drv,bank_dPipe34Ad_1__drv,bank_dPipe34Ad_0__drv,bank_dPipe02Ad_3__drv,bank_dPipe02Ad_2__drv,bank_dPipe02Ad_1__drv,bank_dPipe02Ad_0__drv,bank_dMDMad_3_p___drv,bank_dMDMad_2_p___drv,bank_dMDMad_1_p___drv,bank_dMDMad_0_p___drv,bank_XWantsPipe__drv,bank_WPinEc1__drv,bank_Transport_p___drv,bank_TWReq_15__drv,bank_StartEcGen_p___drv,bank_StartEcChk_p___drv,bank_ShiftSoutO__drv,bank_ShiftSoutE__drv,bank_ShiftSinO__drv,bank_ShiftSinE__drv,bank_ShiftEcOut__drv,bank_STfree_p___drv,bank_ProcTagInA__drv,bank_ProcTag__drv,bank_Mod3StrEn_p___drv,bank_Mod3SinEn_p___drv,bank_Mod2StrEn_p___drv,bank_Mod2SinEn_p___drv,bank_Mod1StrEn_p___drv,bank_Mod1SinEn_p___drv,bank_Mod0StrEn_p___drv,bank_Mod0SinEn_p___drv,bank_MemWEb__drv,bank_MemWEa__drv,bank_MemRfsh__drv,bank_MemRASb__drv,bank_MemRASa__drv,bank_MemPE__drv,bank_MemError__drv,bank_MemCASb__drv,bank_MemCASa__drv,bank_MemAd_8__drv,bank_MemAd_7__drv,bank_MemAd_6__drv,bank_MemAd_5__drv,bank_MemAd_4__drv,bank_MemAd_3__drv,bank_MemAd_2__drv,bank_MemAd_1__drv,bank_MemAd_0__drv,bank_MapWait_m_D__drv,bank_MapTroubleInEc1__drv,bank_MapRfsh_p___drv,bank_MakeSout_u_D__drv,bank_MakeMD_u_D_p___drv,bank_MakeMDM_u_D_p___drv,bank_MakeFout_u_D__drv,bank_MakeF_u_D__drv,bank_MakeD_u_Dbuf__drv,bank_MakeD_u_CD__drv,bank_MDMtag_p___drv,bank_LoadSoutO_p___drv,bank_LoadSoutE_p___drv,bank_LoadSinO__drv,bank_LoadSinE__drv,bank_LoadEcOut_p___drv,bank_LdPipeVAdly_p___drv,bank_LargeHold__drv,bank_IfuFaultInEc2__drv,bank_HoldMapBuf__drv,bank_FoutTask_3__drv,bank_FoutTask_2__drv,bank_FoutTask_1__drv,bank_FoutTask_0__drv,bank_FoutSubtask_1__drv,bank_FoutSubTask_0__drv,bank_FoutNext__drv,bank_Fout_flt__drv,bank_FinTask_3__drv,bank_FinTask_2__drv,bank_FinTask_1__drv,bank_FinTask_0__drv,bank_FinSubtask_1__drv,bank_FinSubtask_0__drv,bank_FinNext__drv,bank_ErrorsFromEc2__drv,bank_EmuOrFT_p___drv,bank_EcWantsA__drv,bank_EcDcomingForCt_p___drv,bank_DdataGood_p___drv,bank_DMuxData__drv,bank_CountMiss__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv,bank_At_eq_Curt_p___drv,bank_AcanhaveMap_p___drv};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 MemX_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 MemX_m_Rev_m_Ch #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.AfreeOrEc_p_b(stimulus_r[0]),
.At_eq_Curt_p_(stimulus_r[1] | bank_At_eq_Curt_p___drv),
.AwantsDifHit_p_(stimulus_r[2]),
.BMux_00(stimulus_r[3] | bank_BMux_00__drv),
.BMux_01(stimulus_r[4] | bank_BMux_01__drv),
.BMux_02(stimulus_r[5] | bank_BMux_02__drv),
.BMux_03(stimulus_r[6] | bank_BMux_03__drv),
.BMux_04(stimulus_r[7] | bank_BMux_04__drv),
.BMux_05(stimulus_r[8] | bank_BMux_05__drv),
.BMux_06(stimulus_r[9] | bank_BMux_06__drv),
.BMux_07(stimulus_r[10] | bank_BMux_07__drv),
.BMux_08(stimulus_r[11] | bank_BMux_08__drv),
.BMux_09(stimulus_r[12] | bank_BMux_09__drv),
.BMux_10(stimulus_r[13] | bank_BMux_10__drv),
.BMux_11(stimulus_r[14] | bank_BMux_11__drv),
.BMux_12(stimulus_r[15] | bank_BMux_12__drv),
.BMux_13(stimulus_r[16] | bank_BMux_13__drv),
.BMux_14(stimulus_r[17] | bank_BMux_14__drv),
.BMux_15(stimulus_r[18] | bank_BMux_15__drv),
.BMux_16(stimulus_r[19]),
.BMux_17(stimulus_r[20]),
.BNTGtCT_p_a(stimulus_r[21]),
.CLK_mx_p_(stimulus_r[22]),
.CacheRef_p_(stimulus_r[23]),
.CacheRefInEc1(stimulus_r[24]),
.ChipsAre256_s_16K(stimulus_r[25]),
.ChipsAre64K(stimulus_r[26]),
.ClkEnable_p_a(stimulus_r[27]),
.CountMiss(stimulus_r[28] | bank_CountMiss__drv),
.DMuxClk(stimulus_r[29]),
.DMuxData(stimulus_r[30] | bank_DMuxData__drv),
.DdataGood_p_(stimulus_r[31] | bank_DdataGood_p___drv),
.DirtyIoFetchInA_p_(stimulus_r[32]),
.DisHold(stimulus_r[33]),
.ECFault(stimulus_r[34]),
.EcDcomingForCt_p_(stimulus_r[35] | bank_EcDcomingForCt_p___drv),
.EcKeepsAbusy(stimulus_r[36]),
.EcWantsA(stimulus_r[37] | bank_EcWantsA__drv),
.ErrorsFromEc2(stimulus_r[38] | bank_ErrorsFromEc2__drv),
.FinNext(stimulus_r[39] | bank_FinNext__drv),
.FoutNext(stimulus_r[40] | bank_FoutNext__drv),
.Hita(stimulus_r[41]),
.HoldMapBuf(stimulus_r[42] | bank_HoldMapBuf__drv),
.IfuRefInEc1(stimulus_r[43]),
.IoFetchInA_p_(stimulus_r[44]),
.IoStoreInA(stimulus_r[45]),
.LoadSinE(stimulus_r[46] | bank_LoadSinE__drv),
.LoadSinO(stimulus_r[47] | bank_LoadSinO__drv),
.M0(stimulus_r[48]),
.M1(stimulus_r[49]),
.M2(stimulus_r[50]),
.M3(stimulus_r[51]),
.MDMtag_p_(stimulus_r[52] | bank_MDMtag_p___drv),
.MXHold(stimulus_r[53]),
.MakeD_u_CD(stimulus_r[54] | bank_MakeD_u_CD__drv),
.MakeD_u_Dbuf(stimulus_r[55] | bank_MakeD_u_Dbuf__drv),
.MakeF_u_D(stimulus_r[56] | bank_MakeF_u_D__drv),
.MakeFout_u_D(stimulus_r[57] | bank_MakeFout_u_D__drv),
.MakeMDM_u_D_p_(stimulus_r[58] | bank_MakeMDM_u_D_p___drv),
.MakeSout_u_D(stimulus_r[59] | bank_MakeSout_u_D__drv),
.MapAd_0(stimulus_r[60]),
.MapAd_1(stimulus_r[61]),
.MapAd_2(stimulus_r[62]),
.MapAd_3(stimulus_r[63]),
.MapAd_4(stimulus_r[64]),
.MapAd_5(stimulus_r[65]),
.MapAd_6(stimulus_r[66]),
.MapAd_7(stimulus_r[67]),
.MapAd_8(stimulus_r[68]),
.MapRfsh_p_(stimulus_r[69] | bank_MapRfsh_p___drv),
.MapTroubleInEc1(stimulus_r[70] | bank_MapTroubleInEc1__drv),
.MapWait_m_D(stimulus_r[71] | bank_MapWait_m_D__drv),
.Map_u_InPair_p_(stimulus_r[72]),
.Mcr_u__p_(stimulus_r[73]),
.MemClkEnable_p_c(stimulus_r[74]),
.MemError(stimulus_r[75] | bank_MemError__drv),
.MemPE(stimulus_r[76] | bank_MemPE__drv),
.MemRfsh(stimulus_r[77] | bank_MemRfsh__drv),
.MemSH(stimulus_r[78]),
.Next_0(stimulus_r[79]),
.Next_1(stimulus_r[80]),
.Next_2(stimulus_r[81]),
.Next_3(stimulus_r[82]),
.PairFull_p_(stimulus_r[83]),
.PrivRefInPair(stimulus_r[84]),
.ProcSrn_u__p_(stimulus_r[85]),
.ProcTag(stimulus_r[86] | bank_ProcTag__drv),
.ProcTagInA(stimulus_r[87] | bank_ProcTagInA__drv),
.ReadInA_p_(stimulus_r[88]),
.RfshPeriod(stimulus_r[89]),
.STfree_p_(stimulus_r[90] | bank_STfree_p___drv),
.SW(stimulus_r[91]),
.StartMap_p_(stimulus_r[92]),
.StkError(stimulus_r[93]),
.Store_u_InA_p_(stimulus_r[94]),
.Store_u_InEc1_p_(stimulus_r[95]),
.SubTask_0(stimulus_r[96]),
.SubTask_1(stimulus_r[97]),
.TIOA_0(stimulus_r[98]),
.TIOA_1(stimulus_r[99]),
.TagInEc1(stimulus_r[100]),
.UseAsrn(stimulus_r[101]),
.VicIfMiss_p_(stimulus_r[102]),
.VicInPair_p_(stimulus_r[103]),
.VicOrFS1C(stimulus_r[104]),
.WPinEc1(stimulus_r[105] | bank_WPinEc1__drv),
._u_Config(stimulus_r[106]),
._u_FaultInfo(stimulus_r[107]),
._u_MD(stimulus_r[108]),
._u_MDdly_p_(stimulus_r[109]),
._u_Map(stimulus_r[110]),
._u_Pipe2(stimulus_r[111]),
._u_Pipe3(stimulus_r[112]),
._u_Pipe4(stimulus_r[113]),
.dHitPerr(stimulus_r[114]),
.dPipe02Ad_0(stimulus_r[115] | bank_dPipe02Ad_0__drv),
.dPipe02Ad_1(stimulus_r[116] | bank_dPipe02Ad_1__drv),
.dPipe02Ad_2(stimulus_r[117] | bank_dPipe02Ad_2__drv),
.dPipe02Ad_3(stimulus_r[118] | bank_dPipe02Ad_3__drv),
.dPipe34Ad_0(stimulus_r[119] | bank_dPipe34Ad_0__drv),
.dPipe34Ad_1(stimulus_r[120] | bank_dPipe34Ad_1__drv),
.dPipe34Ad_2(stimulus_r[121] | bank_dPipe34Ad_2__drv),
.dPipe34Ad_3(stimulus_r[122] | bank_dPipe34Ad_3__drv),
.dSTPerr(stimulus_r[123]),
.AcanhaveMap_p___drv(bank_AcanhaveMap_p___drv),
.At_eq_Curt_p___drv(bank_At_eq_Curt_p___drv),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.CountMiss__drv(bank_CountMiss__drv),
.DMuxData__drv(bank_DMuxData__drv),
.DdataGood_p___drv(bank_DdataGood_p___drv),
.EcDcomingForCt_p___drv(bank_EcDcomingForCt_p___drv),
.EcWantsA__drv(bank_EcWantsA__drv),
.EmuOrFT_p___drv(bank_EmuOrFT_p___drv),
.ErrorsFromEc2__drv(bank_ErrorsFromEc2__drv),
.FinNext__drv(bank_FinNext__drv),
.FinSubtask_0__drv(bank_FinSubtask_0__drv),
.FinSubtask_1__drv(bank_FinSubtask_1__drv),
.FinTask_0__drv(bank_FinTask_0__drv),
.FinTask_1__drv(bank_FinTask_1__drv),
.FinTask_2__drv(bank_FinTask_2__drv),
.FinTask_3__drv(bank_FinTask_3__drv),
.Fout_flt__drv(bank_Fout_flt__drv),
.FoutNext__drv(bank_FoutNext__drv),
.FoutSubTask_0__drv(bank_FoutSubTask_0__drv),
.FoutSubtask_1__drv(bank_FoutSubtask_1__drv),
.FoutTask_0__drv(bank_FoutTask_0__drv),
.FoutTask_1__drv(bank_FoutTask_1__drv),
.FoutTask_2__drv(bank_FoutTask_2__drv),
.FoutTask_3__drv(bank_FoutTask_3__drv),
.HoldMapBuf__drv(bank_HoldMapBuf__drv),
.IfuFaultInEc2__drv(bank_IfuFaultInEc2__drv),
.LargeHold__drv(bank_LargeHold__drv),
.LdPipeVAdly_p___drv(bank_LdPipeVAdly_p___drv),
.LoadEcOut_p___drv(bank_LoadEcOut_p___drv),
.LoadSinE__drv(bank_LoadSinE__drv),
.LoadSinO__drv(bank_LoadSinO__drv),
.LoadSoutE_p___drv(bank_LoadSoutE_p___drv),
.LoadSoutO_p___drv(bank_LoadSoutO_p___drv),
.MDMtag_p___drv(bank_MDMtag_p___drv),
.MakeD_u_CD__drv(bank_MakeD_u_CD__drv),
.MakeD_u_Dbuf__drv(bank_MakeD_u_Dbuf__drv),
.MakeF_u_D__drv(bank_MakeF_u_D__drv),
.MakeFout_u_D__drv(bank_MakeFout_u_D__drv),
.MakeMDM_u_D_p___drv(bank_MakeMDM_u_D_p___drv),
.MakeMD_u_D_p___drv(bank_MakeMD_u_D_p___drv),
.MakeSout_u_D__drv(bank_MakeSout_u_D__drv),
.MapRfsh_p___drv(bank_MapRfsh_p___drv),
.MapTroubleInEc1__drv(bank_MapTroubleInEc1__drv),
.MapWait_m_D__drv(bank_MapWait_m_D__drv),
.MemAd_0__drv(bank_MemAd_0__drv),
.MemAd_1__drv(bank_MemAd_1__drv),
.MemAd_2__drv(bank_MemAd_2__drv),
.MemAd_3__drv(bank_MemAd_3__drv),
.MemAd_4__drv(bank_MemAd_4__drv),
.MemAd_5__drv(bank_MemAd_5__drv),
.MemAd_6__drv(bank_MemAd_6__drv),
.MemAd_7__drv(bank_MemAd_7__drv),
.MemAd_8__drv(bank_MemAd_8__drv),
.MemCASa__drv(bank_MemCASa__drv),
.MemCASb__drv(bank_MemCASb__drv),
.MemError__drv(bank_MemError__drv),
.MemPE__drv(bank_MemPE__drv),
.MemRASa__drv(bank_MemRASa__drv),
.MemRASb__drv(bank_MemRASb__drv),
.MemRfsh__drv(bank_MemRfsh__drv),
.MemWEa__drv(bank_MemWEa__drv),
.MemWEb__drv(bank_MemWEb__drv),
.Mod0SinEn_p___drv(bank_Mod0SinEn_p___drv),
.Mod0StrEn_p___drv(bank_Mod0StrEn_p___drv),
.Mod1SinEn_p___drv(bank_Mod1SinEn_p___drv),
.Mod1StrEn_p___drv(bank_Mod1StrEn_p___drv),
.Mod2SinEn_p___drv(bank_Mod2SinEn_p___drv),
.Mod2StrEn_p___drv(bank_Mod2StrEn_p___drv),
.Mod3SinEn_p___drv(bank_Mod3SinEn_p___drv),
.Mod3StrEn_p___drv(bank_Mod3StrEn_p___drv),
.ProcTag__drv(bank_ProcTag__drv),
.ProcTagInA__drv(bank_ProcTagInA__drv),
.STfree_p___drv(bank_STfree_p___drv),
.ShiftEcOut__drv(bank_ShiftEcOut__drv),
.ShiftSinE__drv(bank_ShiftSinE__drv),
.ShiftSinO__drv(bank_ShiftSinO__drv),
.ShiftSoutE__drv(bank_ShiftSoutE__drv),
.ShiftSoutO__drv(bank_ShiftSoutO__drv),
.StartEcChk_p___drv(bank_StartEcChk_p___drv),
.StartEcGen_p___drv(bank_StartEcGen_p___drv),
.TWReq_15__drv(bank_TWReq_15__drv),
.Transport_p___drv(bank_Transport_p___drv),
.WPinEc1__drv(bank_WPinEc1__drv),
.XWantsPipe__drv(bank_XWantsPipe__drv),
.dMDMad_0_p___drv(bank_dMDMad_0_p___drv),
.dMDMad_1_p___drv(bank_dMDMad_1_p___drv),
.dMDMad_2_p___drv(bank_dMDMad_2_p___drv),
.dMDMad_3_p___drv(bank_dMDMad_3_p___drv),
.dPipe02Ad_0__drv(bank_dPipe02Ad_0__drv),
.dPipe02Ad_1__drv(bank_dPipe02Ad_1__drv),
.dPipe02Ad_2__drv(bank_dPipe02Ad_2__drv),
.dPipe02Ad_3__drv(bank_dPipe02Ad_3__drv),
.dPipe34Ad_0__drv(bank_dPipe34Ad_0__drv),
.dPipe34Ad_1__drv(bank_dPipe34Ad_1__drv),
.dPipe34Ad_2__drv(bank_dPipe34Ad_2__drv),
.dPipe34Ad_3__drv(bank_dPipe34Ad_3__drv),
.preMCSb__drv(bank_preMCSb__drv)
);
endmodule
