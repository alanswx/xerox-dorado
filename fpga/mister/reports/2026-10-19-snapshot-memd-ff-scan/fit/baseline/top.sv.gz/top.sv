module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [105:0] stimulus,
 input wire freeze,held,request,write,input wire [19:0] index,
 input wire [17:0] state_data,output reg [88:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both MemD neighbors sample on positive host edges; full20ns budgets.
 reg [149:0] launch;
 reg [149:0] input_stage;
 always @(negedge host_clk)
  input_stage<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 always @(posedge host_clk) launch<=input_stage;
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [105:0] stimulus_r;wire [19:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [88:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_DMuxData__drv;
wire bank_ECFault__drv;
wire bank_EcOut_0__drv;
wire bank_EcOut_1__drv;
wire bank_EcOut_2__drv;
wire bank_EcOut_3__drv;
wire bank_EcOut_4__drv;
wire bank_EcOut_5__drv;
wire bank_EcOut_6__drv;
wire bank_EcOut_7_p___drv;
wire bank_FG_0__drv;
wire bank_FG_1__drv;
wire bank_FG_2__drv;
wire bank_FG_3__drv;
wire bank_FG_4__drv;
wire bank_FG_5__drv;
wire bank_FG_6__drv;
wire bank_FG_7__drv;
wire bank_FG_8__drv;
wire bank_Fout_00__drv;
wire bank_Fout_01__drv;
wire bank_Fout_02__drv;
wire bank_Fout_03__drv;
wire bank_Fout_04__drv;
wire bank_Fout_05__drv;
wire bank_Fout_06__drv;
wire bank_Fout_07__drv;
wire bank_Fout_08__drv;
wire bank_Fout_09__drv;
wire bank_Fout_10__drv;
wire bank_Fout_11__drv;
wire bank_Fout_12__drv;
wire bank_Fout_13__drv;
wire bank_Fout_14__drv;
wire bank_Fout_15__drv;
wire bank_Fout_16__drv;
wire bank_Fout_17__drv;
wire bank_MemError__drv;
wire bank_Sout_00__drv;
wire bank_Sout_01__drv;
wire bank_Sout_02__drv;
wire bank_Sout_03__drv;
wire bank_Sout_04__drv;
wire bank_Sout_05__drv;
wire bank_Sout_06__drv;
wire bank_Sout_07__drv;
wire bank_Sout_08__drv;
wire bank_Sout_09__drv;
wire bank_Sout_10__drv;
wire bank_Sout_11__drv;
wire bank_Sout_12__drv;
wire bank_Sout_13__drv;
wire bank_Sout_14__drv;
wire bank_Sout_15__drv;
wire bank_dMD_00__drv;
wire bank_dMD_01__drv;
wire bank_dMD_02__drv;
wire bank_dMD_03__drv;
wire bank_dMD_04__drv;
wire bank_dMD_05__drv;
wire bank_dMD_06__drv;
wire bank_dMD_07__drv;
wire bank_dMD_08__drv;
wire bank_dMD_09__drv;
wire bank_dMD_10__drv;
wire bank_dMD_11__drv;
wire bank_dMD_12__drv;
wire bank_dMD_13__drv;
wire bank_dMD_14__drv;
wire bank_dMD_15__drv;
wire bank_dMD_16__drv;
wire bank_dMD_17__drv;
wire bank_dSTPerr__drv;
assign bank_q={bank_dSTPerr__drv,bank_dMD_17__drv,bank_dMD_16__drv,bank_dMD_15__drv,bank_dMD_14__drv,bank_dMD_13__drv,bank_dMD_12__drv,bank_dMD_11__drv,bank_dMD_10__drv,bank_dMD_09__drv,bank_dMD_08__drv,bank_dMD_07__drv,bank_dMD_06__drv,bank_dMD_05__drv,bank_dMD_04__drv,bank_dMD_03__drv,bank_dMD_02__drv,bank_dMD_01__drv,bank_dMD_00__drv,bank_Sout_15__drv,bank_Sout_14__drv,bank_Sout_13__drv,bank_Sout_12__drv,bank_Sout_11__drv,bank_Sout_10__drv,bank_Sout_09__drv,bank_Sout_08__drv,bank_Sout_07__drv,bank_Sout_06__drv,bank_Sout_05__drv,bank_Sout_04__drv,bank_Sout_03__drv,bank_Sout_02__drv,bank_Sout_01__drv,bank_Sout_00__drv,bank_MemError__drv,bank_Fout_17__drv,bank_Fout_16__drv,bank_Fout_15__drv,bank_Fout_14__drv,bank_Fout_13__drv,bank_Fout_12__drv,bank_Fout_11__drv,bank_Fout_10__drv,bank_Fout_09__drv,bank_Fout_08__drv,bank_Fout_07__drv,bank_Fout_06__drv,bank_Fout_05__drv,bank_Fout_04__drv,bank_Fout_03__drv,bank_Fout_02__drv,bank_Fout_01__drv,bank_Fout_00__drv,bank_FG_8__drv,bank_FG_7__drv,bank_FG_6__drv,bank_FG_5__drv,bank_FG_4__drv,bank_FG_3__drv,bank_FG_2__drv,bank_FG_1__drv,bank_FG_0__drv,bank_EcOut_7_p___drv,bank_EcOut_6__drv,bank_EcOut_5__drv,bank_EcOut_4__drv,bank_EcOut_3__drv,bank_EcOut_2__drv,bank_EcOut_1__drv,bank_EcOut_0__drv,bank_ECFault__drv,bank_DMuxData__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 MemD_full_snapshot_experiment #(.SYSPER(4),.STORAGE_INPUT_DELAY(2)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 MemD_m_Rev_m_Ca #(.SYSPER(4),.STORAGE_INPUT_DELAY(2)) bank(
`endif
.sys_clk(host_clk),
.BMux_00(stimulus_r[0] | bank_BMux_00__drv),
.BMux_01(stimulus_r[1] | bank_BMux_01__drv),
.BMux_02(stimulus_r[2] | bank_BMux_02__drv),
.BMux_03(stimulus_r[3] | bank_BMux_03__drv),
.BMux_04(stimulus_r[4] | bank_BMux_04__drv),
.BMux_05(stimulus_r[5] | bank_BMux_05__drv),
.BMux_06(stimulus_r[6] | bank_BMux_06__drv),
.BMux_07(stimulus_r[7] | bank_BMux_07__drv),
.BMux_08(stimulus_r[8] | bank_BMux_08__drv),
.BMux_09(stimulus_r[9] | bank_BMux_09__drv),
.BMux_10(stimulus_r[10] | bank_BMux_10__drv),
.BMux_11(stimulus_r[11] | bank_BMux_11__drv),
.BMux_12(stimulus_r[12] | bank_BMux_12__drv),
.BMux_13(stimulus_r[13] | bank_BMux_13__drv),
.BMux_14(stimulus_r[14] | bank_BMux_14__drv),
.BMux_15(stimulus_r[15] | bank_BMux_15__drv),
.BMux_16(stimulus_r[16]),
.BMux_17(stimulus_r[17]),
.CLK_md_p_(stimulus_r[18]),
.DMuxClk(stimulus_r[19]),
.DMuxData(stimulus_r[20] | bank_DMuxData__drv),
.Dad_00(stimulus_r[21]),
.Dad_01(stimulus_r[22]),
.Dbuf_u__p_(stimulus_r[23]),
.ECFault(stimulus_r[24] | bank_ECFault__drv),
.EcIn_0(stimulus_r[25]),
.EcIn_1(stimulus_r[26]),
.EnableFG_p_(stimulus_r[27]),
.ErrorsFromEc2(stimulus_r[28]),
.FastD_u_Dbuf(stimulus_r[29]),
.Fin_00(stimulus_r[30]),
.Fin_01(stimulus_r[31]),
.Fin_02(stimulus_r[32]),
.Fin_03(stimulus_r[33]),
.Fin_04(stimulus_r[34]),
.Fin_05(stimulus_r[35]),
.Fin_06(stimulus_r[36]),
.Fin_07(stimulus_r[37]),
.Fin_08(stimulus_r[38]),
.Fin_09(stimulus_r[39]),
.Fin_10(stimulus_r[40]),
.Fin_11(stimulus_r[41]),
.Fin_12(stimulus_r[42]),
.Fin_13(stimulus_r[43]),
.Fin_14(stimulus_r[44]),
.Fin_15(stimulus_r[45]),
.Fin_16(stimulus_r[46]),
.Fin_17(stimulus_r[47]),
.Fout_00(stimulus_r[48] | bank_Fout_00__drv),
.GDv_p_(stimulus_r[49]),
.GLd_p_(stimulus_r[50]),
.MakeD_u_CD(stimulus_r[51]),
.MakeD_u_Dbuf(stimulus_r[52]),
.MakeF_u_D(stimulus_r[53]),
.MakeFout_u_D(stimulus_r[54]),
.MakeMDM_u_D_p_(stimulus_r[55]),
.MakeMD_u_D_p_(stimulus_r[56]),
.MakeSout_u_D(stimulus_r[57]),
.McrD_u__p_(stimulus_r[58]),
.MemClkEnable_p_a(stimulus_r[59]),
.MemError(stimulus_r[60] | bank_MemError__drv),
.MemSH(stimulus_r[61]),
.PcFG_15(stimulus_r[62]),
.Sin_00(stimulus_r[63]),
.Sin_01(stimulus_r[64]),
.Sin_02(stimulus_r[65]),
.Sin_03(stimulus_r[66]),
.Sin_04(stimulus_r[67]),
.Sin_05(stimulus_r[68]),
.Sin_06(stimulus_r[69]),
.Sin_07(stimulus_r[70]),
.Sin_08(stimulus_r[71]),
.Sin_09(stimulus_r[72]),
.Sin_10(stimulus_r[73]),
.Sin_11(stimulus_r[74]),
.Sin_12(stimulus_r[75]),
.Sin_13(stimulus_r[76]),
.Sin_14(stimulus_r[77]),
.Sin_15(stimulus_r[78]),
.StartEcChk_p_(stimulus_r[79]),
.StartEcGen_p_(stimulus_r[80]),
.TempRef(stimulus_r[81]),
.Transport_p_(stimulus_r[82]),
._u_Dbuf(stimulus_r[83]),
._u_Pipe4(stimulus_r[84]),
.dDad_02(stimulus_r[85]),
.dDad_03(stimulus_r[86]),
.dDad_04(stimulus_r[87]),
.dDad_05(stimulus_r[88]),
.dDad_06(stimulus_r[89]),
.dDad_07(stimulus_r[90]),
.dDad_08(stimulus_r[91]),
.dDad_09(stimulus_r[92]),
.dDad_10(stimulus_r[93]),
.dDad_11(stimulus_r[94]),
.dDad_12(stimulus_r[95]),
.dDad_13(stimulus_r[96]),
.dMD_00(stimulus_r[97] | bank_dMD_00__drv),
.dMDMad_0_p_(stimulus_r[98]),
.dMDMad_1_p_(stimulus_r[99]),
.dMDMad_2_p_(stimulus_r[100]),
.dMDMad_3_p_(stimulus_r[101]),
.dPipe34Ad_0(stimulus_r[102]),
.dPipe34Ad_1(stimulus_r[103]),
.dPipe34Ad_2(stimulus_r[104]),
.dPipe34Ad_3(stimulus_r[105]),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.DMuxData__drv(bank_DMuxData__drv),
.ECFault__drv(bank_ECFault__drv),
.EcOut_0__drv(bank_EcOut_0__drv),
.EcOut_1__drv(bank_EcOut_1__drv),
.EcOut_2__drv(bank_EcOut_2__drv),
.EcOut_3__drv(bank_EcOut_3__drv),
.EcOut_4__drv(bank_EcOut_4__drv),
.EcOut_5__drv(bank_EcOut_5__drv),
.EcOut_6__drv(bank_EcOut_6__drv),
.EcOut_7_p___drv(bank_EcOut_7_p___drv),
.FG_0__drv(bank_FG_0__drv),
.FG_1__drv(bank_FG_1__drv),
.FG_2__drv(bank_FG_2__drv),
.FG_3__drv(bank_FG_3__drv),
.FG_4__drv(bank_FG_4__drv),
.FG_5__drv(bank_FG_5__drv),
.FG_6__drv(bank_FG_6__drv),
.FG_7__drv(bank_FG_7__drv),
.FG_8__drv(bank_FG_8__drv),
.Fout_00__drv(bank_Fout_00__drv),
.Fout_01__drv(bank_Fout_01__drv),
.Fout_02__drv(bank_Fout_02__drv),
.Fout_03__drv(bank_Fout_03__drv),
.Fout_04__drv(bank_Fout_04__drv),
.Fout_05__drv(bank_Fout_05__drv),
.Fout_06__drv(bank_Fout_06__drv),
.Fout_07__drv(bank_Fout_07__drv),
.Fout_08__drv(bank_Fout_08__drv),
.Fout_09__drv(bank_Fout_09__drv),
.Fout_10__drv(bank_Fout_10__drv),
.Fout_11__drv(bank_Fout_11__drv),
.Fout_12__drv(bank_Fout_12__drv),
.Fout_13__drv(bank_Fout_13__drv),
.Fout_14__drv(bank_Fout_14__drv),
.Fout_15__drv(bank_Fout_15__drv),
.Fout_16__drv(bank_Fout_16__drv),
.Fout_17__drv(bank_Fout_17__drv),
.MemError__drv(bank_MemError__drv),
.Sout_00__drv(bank_Sout_00__drv),
.Sout_01__drv(bank_Sout_01__drv),
.Sout_02__drv(bank_Sout_02__drv),
.Sout_03__drv(bank_Sout_03__drv),
.Sout_04__drv(bank_Sout_04__drv),
.Sout_05__drv(bank_Sout_05__drv),
.Sout_06__drv(bank_Sout_06__drv),
.Sout_07__drv(bank_Sout_07__drv),
.Sout_08__drv(bank_Sout_08__drv),
.Sout_09__drv(bank_Sout_09__drv),
.Sout_10__drv(bank_Sout_10__drv),
.Sout_11__drv(bank_Sout_11__drv),
.Sout_12__drv(bank_Sout_12__drv),
.Sout_13__drv(bank_Sout_13__drv),
.Sout_14__drv(bank_Sout_14__drv),
.Sout_15__drv(bank_Sout_15__drv),
.dMD_00__drv(bank_dMD_00__drv),
.dMD_01__drv(bank_dMD_01__drv),
.dMD_02__drv(bank_dMD_02__drv),
.dMD_03__drv(bank_dMD_03__drv),
.dMD_04__drv(bank_dMD_04__drv),
.dMD_05__drv(bank_dMD_05__drv),
.dMD_06__drv(bank_dMD_06__drv),
.dMD_07__drv(bank_dMD_07__drv),
.dMD_08__drv(bank_dMD_08__drv),
.dMD_09__drv(bank_dMD_09__drv),
.dMD_10__drv(bank_dMD_10__drv),
.dMD_11__drv(bank_dMD_11__drv),
.dMD_12__drv(bank_dMD_12__drv),
.dMD_13__drv(bank_dMD_13__drv),
.dMD_14__drv(bank_dMD_14__drv),
.dMD_15__drv(bank_dMD_15__drv),
.dMD_16__drv(bank_dMD_16__drv),
.dMD_17__drv(bank_dMD_17__drv),
.dSTPerr__drv(bank_dSTPerr__drv)
);
endmodule
