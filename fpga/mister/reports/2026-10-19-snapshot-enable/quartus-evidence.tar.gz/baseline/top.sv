module snapshot_fit(
 input wire host_clk,guest_advance,input wire [9:0] address,
 input wire [17:0] data,input wire ce_n,we_n,
 output reg [17:0] q,
 input wire freeze,guest_held,request,write,
 input wire [10:0] word_index,input wire [17:0] state_data,
 output reg frozen,done,error,output reg [17:0] result);
 // A real launch/capture shell models an embedded bank. The opposite edge
 // gives BOTH variants10ns register-to-bank and bank-to-register budgets;
 // external virtual I/O retains the same2ns/0ns delay contract. Resource
 // counts include this shell; unused baseline admin registers may be pruned.
 reg [63:0] launch;
 always @(negedge host_clk)
   launch <= {guest_advance,address,data,ce_n,we_n,freeze,guest_held,
              request,write,word_index,state_data};
 wire step_r,ce_r,we_r,freeze_r,held_r,request_r,write_r;
 wire [9:0] address_r;wire [17:0] data_r,state_r;wire [10:0] word_r;
 assign {step_r,address_r,data_r,ce_r,we_r,freeze_r,held_r,
         request_r,write_r,word_r,state_r}=launch;
 wire [17:0] bank_q,bank_result;wire bank_frozen,bank_done,bank_error;
 always @(negedge host_clk)
   {q,frozen,done,error,result} <= {bank_q,bank_frozen,bank_done,bank_error,bank_result};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_enable_bank bank(host_clk,step_r,address_r,data_r,
   ce_r,we_r,bank_q,freeze_r,held_r,bank_frozen,request_r,write_r,word_r,state_r,
   bank_done,bank_error,bank_result);
`else
 assign bank_frozen=0;assign bank_done=0;assign bank_error=0;assign bank_result=0;
 genvar i;
 generate for(i=0;i<18;i=i+1)begin: original
   cell_F10415A bit_cell(host_clk,address_r[9],address_r[8],address_r[7],address_r[6],
     address_r[5],address_r[4],address_r[3],address_r[2],address_r[1],address_r[0],
     data_r[i],ce_r,we_r,bank_q[i]);
 end endgenerate
`endif
endmodule
