from pathlib import Path
import hashlib,json,os,subprocess,tarfile
packet=Path('/home/alans/mister/dorado-serial71-network-pause-20261020.tar.gz')
assert hashlib.sha256(packet.read_bytes()).hexdigest()=='faeba8e8e591be64073dae4647a45d0203b50fef393becfab68ef52fd544e009'
project=Path('/home/alans/mister/Dorado_Serial71NetworkPause_20261020')
assert not project.exists(),'Observe existing job; never restart on a timeout'
rows=subprocess.check_output(['ps','-eo','pid,ppid,etimes,comm,args'],text=True).splitlines()
live=[r for r in rows[1:]if any(n in r.split()[3]for n in('quartus_map','quartus_fit','quartus_sta'))]
assert not live,live
project.mkdir()
with tarfile.open(packet)as t:t.extractall(project,filter='data')
r=json.loads((project/'network-pause-integration.json').read_text())
assert r['project']==str(project)and len(r['source_hashes'])==661 and not r['assembly_permitted']
for n,h in r['source_hashes'].items():assert hashlib.sha256((project/n).read_bytes()).hexdigest()==h,n
proof=json.loads((project/'source-audit.json').read_text())
assert proof['status']=='PASS_NATIVE_NETWORK_PAUSE_SOURCE_ONLY'and len(proof['failure_controls'])==12
state=json.loads((project/'state-access-review.json').read_text())
assert state['status']=='PASS_NATIVE_MEMORY_PAUSE_STATE_ACCESS_PENDING'
(project/'remote-preflight.json').write_text(json.dumps(dict(status='PASS',packet_sha256='faeba8e8e591be64073dae4647a45d0203b50fef393becfab68ef52fd544e009',prepared_inputs=661,no_assembly=True,other_quartus_processes=live),indent=2)+'\n')
with(project/'driver.log').open('w')as log:
 p=subprocess.Popen(['python3',str(project/'tools/fpga/mister/snapshot/build_native_network_pause.py'),'--run',str(project)],cwd=project,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(project/'driver.pid').write_text(str(p.pid)+'\n')
print(json.dumps(dict(pid=p.pid,project=str(project))))
