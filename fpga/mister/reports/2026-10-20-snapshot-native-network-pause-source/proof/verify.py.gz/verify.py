from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=root/'staged-source';q=load(p/'network-pause-integration.json')
assert len(q['source_hashes'])==661 and not q['assembly_permitted']and q['capacity_only']and not q['real_pause_barriers']
for n,h in q['source_hashes'].items():assert sha(p/n)==h,n
for n,h in load(p/'tools/frozen-tools.json').items():assert sha(p/'tools'/n)==h,n
assert q['builder_sha256']==sha(p/'tools/fpga/mister/snapshot/build_native_network_pause.py')
assert q['generator_sha256']==sha(p/'tools/fpga/mister/snapshot/generate_native_network_pause.py')
for name in ('source-audit.json','source-audit-frozen.json'):
 r=load(root/name);assert r['status']=='PASS_NATIVE_NETWORK_PAUSE_SOURCE_ONLY'
 assert r['actual_inputs']==661 and r['original_pin_connections']==2761 and len(r['failure_controls'])==12
 assert r['new_top_state_bits']==6 and r['constraints_unchanged']
r=load(root/'inventory/classification.json');assert r['status']=='PASS_NATIVE_MEMORY_PAUSE_STATE_ACCESS_PENDING'
assert r['totals']=={'WRAPPER ACCESS PENDING':132606,'PRIVATE BOARD':4578,'PHYSICAL BOARD':1957048,'PRIVATE TRANSPORT':69}
assert len(r['failure_controls'])==15
provenance=load(root/'inventory/provenance.json')
for n,h in provenance['source_hashes'].items():assert sha(p/n)==h,n
assert sha(p/'core/Dorado.qsf')==provenance['qsf_sha256']
assert 'UNOPTFLAT'not in(root/'inventory/elaborate.log').read_text()
fresh=load(root/'archive-rebuild-inventory/classification.json')
left=dict(r);right=dict(fresh)
for key in ('xml_sha256','normalized_xml_sha256'):left.pop(key);right.pop(key)
assert left==right
assert provenance==load(root/'archive-rebuild-inventory/provenance.json')
for label in ('inventory','archive-rebuild-inventory'):
 c=load(root/label/'classification.json')
 assert c['xml_sha256']==sha(root/label/'native.xml')
 assert c['normalized_xml_sha256']==sha(root/label/'native-normalized.xml')
a=load(root/'archive-rebuild-source-audit.json');assert a==load(root/'source-audit-frozen.json')
for label in ('network-extracted-wire','network-extracted-fourstate'):
 q=load(root/label/('qualification.json'if label.endswith('wire')else'results.json'))
 assert q['status']=='PASS'and len(q['cases'])==8
 for c in q['cases']:
  if label.endswith('wire'):
   assert sha(root/label/c['case']/'test.log')==c['log_sha256']
   for n,h in q['inputs'].items():assert sha(root/label/'executed-inputs'/n)==h,n
  else:
   for n,h in c['inputs'].items():assert sha(root/label/c['case']/n)==h,n
print(json.dumps(dict(status='PASS',prepared_inputs=661,original_pins=2761,new_top_state_bits=6,native_required_bits=2094301,wrapper_access_pending_bits=132606,source_failure_controls=12,state_failure_controls=15,limits='Source/native inventory only. Real network boundaries qualified separately; full top state access, complete snapshots, capacity, timing and FPGA qualification remain required.'),indent=2))
