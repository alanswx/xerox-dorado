from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'candidate','ungated_guest','uio_unheld','uio_early','uio_release','early_ready','early_guest_release','nonsticky_fault'}
wire_inputs=[]
for label in ('wire','rebuild-wire'):
 p=root/label;q=load(p/'qualification.json')
 assert q['status']=='PASS'and q['real_network_pause_barrier']and q['new_required_state_bits']==6
 assert q['state_review']['observed_bits']==34344 and q['state_review']['packet_ram_bits']==32768
 assert q['state_review']['sequential_exclusions']==[]and {c['case']for c in q['cases']}==expected
 for n,h in q['inputs'].items():assert sha(p/'executed-inputs'/n)==h,n
 for c in q['cases']:
  log=p/c['case']/'test.log';assert sha(log)==c['log_sha256']
  if c['expected_failure']:assert c['returncode']==23 and c['expected_failure']in log.read_text()
  else:
   assert c['returncode']==0
   for token in('NETWORK WIRE QUARANTINE PASS','NETWORK WIRE CANCEL PASS','NETWORK WIRE RX PASS','NETWORK WIRE PHASE PASS','NETWORK WIRE TX PASS','NETWORK WIRE CAPTURE PASS','DDR WIRE PASS'):
    assert token in log.read_text(),token
 wire_inputs.append(q['inputs'])
assert wire_inputs[0]==wire_inputs[1]
for label in ('fourstate','rebuild-fourstate'):
 p=root/label;q=load(p/'results.json');assert q['status']=='PASS'and len(q['cases'])==8
 assert q['inputs']['network_pause_barrier.sv']==wire_inputs[0]['network_pause_barrier.sv']
 for c in q['cases']:
  for n,h in c['inputs'].items():assert sha(p/c['case']/n)==h,n
  text=(p/c['case']/'test.log').read_text()
  if c['case']=='candidate':assert c['returncode']==0 and'checks=394272 drain_cases=256 ready_cases=65536 state_bits=5'in text
  elif c['case']=='memory_chain':assert c['returncode']==0 and'NETWORK MEMORY CHAIN PASS checks=79 coordinator_bits=7 real_memory_devices=0'in text
  else:assert c['returncode']and'FATAL'in text
q=load(root/'legacy-held-port/qualification.json');assert q['status']=='PASS'and not q['real_network_pause_barrier']
assert q['state_review']['observed_bits']==34339 and len(q['cases'])==5
for c in q['cases']:
 log=root/'legacy-held-port'/c['case']/'test.log';assert sha(log)==c['log_sha256']
for n,h in load(root/'proof-source/source-hashes.json').items():assert sha(root/'proof-source'/n)==h,n
print(json.dumps(dict(status='PASS',observed_network_bits=34344,packet_ram_bits=32768,new_top_bits=6,
 wire_cases=8,fourstate_cases=65536,drain_cases=256,coordinator_chain_checks=79,legacy_cases=5,
 frozen_rebuild_identical_inputs=True,limits='Actual network/controlled-memory-coordinator tests only. No native fit, physical DDR fence, Main coordinator, complete snapshot/import or hardware deployment.'),indent=2))
