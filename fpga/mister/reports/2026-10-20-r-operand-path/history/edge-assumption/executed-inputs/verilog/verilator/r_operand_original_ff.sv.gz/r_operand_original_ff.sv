// Original physical-pin MC1668 reference, including independent asynchronous
// set/reset. Observation fixture only; no fabric edge detector or PRECAP.
`timescale 1ps/1ps
`default_nettype none
module original_MC1668 #(parameter integer DELAY_PS=1000)(
 input wire p4,p5,p6,p7,p9,p11,p12,p13,
 output wire p2,p3,p14,p15,input wire fixture_load,
 input wire [1:0] fixture_state,output reg [1:0] state_q);
 always @(posedge p7 or posedge p4 or posedge p5 or posedge fixture_load)
   if(fixture_load) state_q[0]<=fixture_state[0];
   else if(p5) state_q[0]<=#(DELAY_PS) 1'b1;
   else if(p4) state_q[0]<=#(DELAY_PS) 1'b0;
   else state_q[0]<=#(DELAY_PS) p6;
 always @(posedge p9 or posedge p12 or posedge p13 or posedge fixture_load)
   if(fixture_load) state_q[1]<=fixture_state[1];
   else if(p12) state_q[1]<=#(DELAY_PS) 1'b1;
   else if(p13) state_q[1]<=#(DELAY_PS) 1'b0;
   else state_q[1]<=#(DELAY_PS) p11;
 assign p2=state_q[0];assign p3=~state_q[0];
 assign p15=state_q[1];assign p14=~state_q[1];
endmodule
`default_nettype wire
