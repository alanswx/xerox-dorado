`timescale 1ns/1ps
`default_nettype none
module capture_procl(input wire fixture_load,input wire [15:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [15:0] state_q,output wire [4:0] clocks,
 output wire [2:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock1'Ca
 wire n15; // Clock1'Cb
 wire n16; // Curr.0'
 wire n17; // Curr.1'
 wire n18; // Curr.2'
 wire n19; // Curr.3'
 wire n20; // Curr=Next'
 wire n21; // FA=0'b
 wire n22; // FB=2'
 wire n23; // FB=3'
 wire n24; // FB=7'
 wire n25; // FC=4/5'
 wire n26; // FC=5'
 wire n27; // FC=6'
 wire n28; // GND132
 wire n29; // GND264
 wire n30; // GND266
 wire n31; // GND312
 wire n32; // GND314
 wire n33; // GND40
 wire n34; // GND530
 wire n35; // Hold
 wire n36; // Hold'
 wire n37; // HoldDly
 wire n38; // IOB.Perr'
 wire n39; // IOBin'
 wire n40; // IOBout
 wire n41; // IOin'
 wire n42; // LC.0
 wire n43; // LC.1
 wire n44; // LC.1'a
 wire n45; // LC.1a
 wire n46; // LC.2
 wire n47; // LScopeFH
 wire n48; // Last.0'
 wire n49; // Last.1'
 wire n50; // Last.2'
 wire n51; // Last.3'
 wire n52; // Last=Curr'
 wire n53; // Next.0
 wire n54; // Next.0'
 wire n55; // Next.1
 wire n56; // Next.1'
 wire n57; // Next.2
 wire n58; // Next.2'
 wire n59; // Next.3
 wire n60; // Next.3'
 wire n61; // PRhold
 wire n62; // PreClock0'A
 wire n63; // PreClock0'B
 wire n64; // PreClock0'C
 wire n65; // PreClock0'D
 wire n66; // PreClock1'A
 wire n67; // PreClock1'B
 wire n68; // PreClock1'C
 wire n69; // PreClock1'D
 wire n70; // PreClock1B
 wire n71; // PreDblClock'B
 wire n72; // PreSHCP'A
 wire n73; // PreSHCP'B
 wire n74; // PreSHCP'C
 wire n75; // PreSHCP'Shc
 wire n76; // PreSHSelect'D
 wire n77; // ProcL10.sil+1
 wire n78; // ProcL11.sil+7
 wire n79; // ProcL12.sil+1
 wire n80; // ProcL15.sil+1
 wire n81; // ProcL20.sil+1
 wire n82; // ProcL20.sil+3
 wire n83; // ProcL20.sil+4
 wire n84; // ProcL20.sil+5
 wire n85; // ProcL20.sil+6
 wire n86; // ProcL26.sil+1
 wire n87; // ProcL27.sil+11
 wire n88; // ProcL30.sil+1
 wire n89; // RbSelMd
 wire n90; // RbSelMd'
 wire n91; // RbWriteEn'
 wire n92; // RepeatCurrB
 wire n93; // RepeatCurrC
 wire n94; // RepeatCurrD
 wire n95; // SHCP'C
 wire n96; // SHSelect'C
 wire n97; // SimHoldReq'
 wire n98; // StartCycle'a
 wire n99; // TbBypass
 wire n100; // TbSelMd
 wire n101; // TbWriteEn'
 wire n102; // TisIFdata
 wire n103; // TrueA
 wire n104; // pClk1En'
 wire n105; // ppClk'a
 wire n106; // ppClk'b
 wire n107; // ppClk'c
 assign n28=1'b0;
 assign n29=1'b0;
 assign n30=1'b0;
 assign n31=1'b0;
 assign n32=1'b0;
 assign n33=1'b0;
 assign n34=1'b0;
 assign n1=pins[24];
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n21=(pins[19:18]!=2'd0);
 assign n22=(pins[17:15]!=3'd2);
 assign n23=(pins[17:15]!=3'd3);
 assign n24=(pins[17:15]!=3'd7);
 assign n25=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n26=(pins[14:12]!=3'd5);
 assign n27=(pins[14:12]!=3'd6);
 assign n37=1'b0;
 assign n39=1'b0;
 assign n40=1'b0;
 assign n42=pins[11];
 assign n43=pins[10];
 assign n46=pins[9];
 assign n53=pins[20];
 assign n55=pins[21];
 assign n57=pins[22];
 assign n59=pins[23];
 assign n61=pins[25];
 assign n86=1'b0;
 assign n87=1'b0;
 assign n98=start_a;
 assign n102=1'b0;
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_c18_3;
 assign n14=n14_c18_3;
 wire n15_c18_2;
 assign n15=n15_c18_2;
 wire n16_a21_14;
 assign n16=n16_a21_14;
 wire n17_a21_15;
 assign n17=n17_a21_15;
 wire n18_a21_2;
 assign n18=n18_a21_2;
 wire n19_a21_3;
 assign n19=n19_a21_3;
 wire n20_a22_2;
 wire n20_a22_3;
 wire n20_a22_15;
 wire n20_a22_14;
 assign n20=n20_a22_2 | n20_a22_3 | n20_a22_15 | n20_a22_14;
 wire n35_f19_15;
 assign n35=n35_f19_15;
 wire n36_f19_14;
 assign n36=n36_f19_14;
 wire n38_g23_14;
 assign n38=n38_g23_14;
 wire n41_g23_9;
 assign n41=n41_g23_9;
 wire n44_h24_15;
 assign n44=n44_h24_15;
 wire n45_h24_9;
 assign n45=n45_h24_9;
 wire n47_c18_14;
 assign n47=n47_c18_14;
 wire n48_a20_14;
 assign n48=n48_a20_14;
 wire n49_a20_15;
 assign n49=n49_a20_15;
 wire n50_a20_2;
 assign n50=n50_a20_2;
 wire n51_a20_3;
 assign n51=n51_a20_3;
 wire n52_d17_15;
 assign n52=n52_d17_15;
 wire n54_a24_15;
 assign n54=n54_a24_15;
 wire n56_a24_14;
 assign n56=n56_a24_14;
 wire n58_a24_3;
 assign n58=n58_a24_3;
 wire n60_a24_2;
 assign n60=n60_a24_2;
 wire n62_f13_13;
 assign n62=n62_f13_13;
 wire n63_f13_12;
 assign n63=n63_f13_12;
 wire n64_f13_14;
 assign n64=n64_f13_14;
 wire n65_g13_3;
 assign n65=n65_g13_3;
 wire n66_f12_14;
 assign n66=n66_f12_14;
 wire n67_f13_2;
 assign n67=n67_f13_2;
 wire n68_f13_4;
 assign n68=n68_f13_4;
 wire n69_f13_3;
 assign n69=n69_f13_3;
 wire n70_f12_13;
 assign n70=n70_f12_13;
 wire n71_g13_13;
 assign n71=n71_g13_13;
 wire n72_g12_3;
 assign n72=n72_g12_3;
 wire n73_g12_2;
 assign n73=n73_g12_2;
 wire n74_g12_4;
 assign n74=n74_g12_4;
 wire n75_f12_4;
 assign n75=n75_f12_4;
 wire n76_f12_3;
 assign n76=n76_f12_3;
 wire n77_f20_2;
 assign n77=n77_f20_2;
 wire n78_f20_3;
 assign n78=n78_f20_3;
 wire n79_a24_9;
 wire n79_a24_11;
 wire n79_a24_6;
 wire n79_a24_5;
 assign n79=n79_a24_9 | n79_a24_11 | n79_a24_6 | n79_a24_5;
 wire n80_f20_14;
 assign n80=n80_f20_14;
 wire n81_f20_15;
 wire n81_g23_3;
 assign n81=n81_f20_15 | n81_g23_3;
 wire n82_h23_2;
 assign n82=n82_h23_2;
 wire n83_h23_3;
 assign n83=n83_h23_3;
 wire n84_h23_14;
 assign n84=n84_h23_14;
 wire n85_g23_2;
 assign n85=n85_g23_2;
 wire n88_f12_2;
 assign n88=n88_f12_2;
 wire n89_d17_3;
 assign n89=n89_d17_3;
 wire n90_d17_2;
 assign n90=n90_d17_2;
 wire n91_d17_13;
 assign n91=n91_d17_13;
 wire n92_g12_13;
 assign n92=n92_g12_13;
 wire n93_g12_12;
 assign n93=n93_g12_12;
 wire n94_g12_14;
 assign n94=n94_g12_14;
 wire n95_c18_13;
 assign n95=n95_c18_13;
 wire n96_c18_12;
 assign n96=n96_c18_12;
 wire n97_a01_3;
 assign n97=n97_a01_3;
 wire n99_f19_3;
 assign n99=n99_f19_3;
 wire n100_d17_4;
 assign n100=n100_d17_4;
 wire n101_d17_14;
 assign n101=n101_d17_14;
 wire n103_a01_14;
 assign n103=n103_a01_14;
 wire n104_l02_2;
 assign n104=n104_l02_2;
 wire n105_l01_13;
 assign n105=n105_l01_13;
 wire n106_l01_12;
 assign n106=n106_l01_12;
 wire n107_l01_14;
 assign n107=n107_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n97_a01_3),.p4(n1),.p5(1'b0),.p6(n86),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n103_a01_14),.p16(1'b0));
 original_MC10141 a20(.p1(n33),.p2(n50_a20_2),.p3(n51_a20_3),.p4(n14),.p5(1'b0),.p6(n19),.p7(1'b0),.p8(1'b0),.p9(n18),.p10(1'b0),.p11(n17),.p12(n16),.p13(1'b0),.p14(n48_a20_14),.p15(n49_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n18_a21_2),.p3(n19_a21_3),.p4(n95),.p5(1'b0),.p6(n60),.p7(n93),.p8(1'b0),.p9(n58),.p10(n93),.p11(n56),.p12(n54),.p13(1'b0),.p14(n16_a21_14),.p15(n17_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n20_a22_2),.p3(n20_a22_3),.p4(n19),.p5(n60),.p6(n58),.p7(n18),.p9(1'b0),.p10(n56),.p11(n17),.p12(n54),.p13(n16),.p14(n20_a22_14),.p15(n20_a22_15));
 cell_MC10101 a24(.p2(n60_a24_2),.p3(n58_a24_3),.p4(n59),.p5(n79_a24_5),.p6(n79_a24_6),.p7(n57),.p9(n79_a24_9),.p10(n55),.p11(n79_a24_11),.p12(1'b0),.p13(n53),.p14(n56_a24_14),.p15(n54_a24_15));
 cell_SE10210 c18(.p2(n15_c18_2),.p3(n14_c18_3),.p5(n68),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n74),.p10(1'b0),.p11(1'b0),.p12(n96_c18_12),.p13(n95_c18_13),.p14(n47_c18_14),.p15(n28),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n90_d17_2),.p3(n89_d17_3),.p4(n100_d17_4),.p5(n45),.p6(n44),.p7(n81),.p8(1'b0),.p9(n95),.p10(n84),.p11(n85),.p12(n20),.p13(n91_d17_13),.p14(n101_d17_14),.p15(n52_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n88_f12_2),.p3(n76_f12_3),.p4(n75_f12_4),.p5(n104),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n88),.p10(1'b0),.p11(n105),.p13(n70_f12_13),.p14(n66_f12_14),.p15(n29),.p16(1'b0));
 cell_SE10210 f13(.p2(n67_f13_2),.p3(n69_f13_3),.p4(n68_f13_4),.p5(n106),.p6(1'b0),.p7(n88),.p8(1'b0),.p9(n106),.p10(n13),.p11(1'b0),.p12(n63_f13_12),.p13(n62_f13_13),.p14(n64_f13_14),.p15(n30),.p16(1'b0));
 cell_MC1660 f19(.p3(n99_f19_3),.p4(n37),.p5(n52),.p6(n101),.p7(n102),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n61),.p14(n36_f19_14),.p15(n35_f19_15));
 cell_MC10100 f20(.p2(n77_f20_2),.p3(n78_f20_3),.p4(n27),.p5(n22),.p6(n25),.p7(n22),.p9(n21),.p10(n27),.p11(n23),.p12(n26),.p13(n24),.p14(n80_f20_14),.p15(n81_f20_15));
 cell_SE10211 g12(.p2(n73_g12_2),.p3(n72_g12_3),.p4(n74_g12_4),.p5(1'b0),.p6(n104),.p7(1'b0),.p9(n0),.p10(n36),.p11(1'b0),.p12(n93_g12_12),.p13(n92_g12_13),.p14(n94_g12_14),.p15(n31),.p16(1'b0));
 cell_SE10210 g13(.p3(n65_g13_3),.p5(n107),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n107),.p10(1'b0),.p11(1'b0),.p13(n71_g13_13),.p15(n32),.p16(1'b0));
 cell_MC10102 g23(.p1(1'b0),.p2(n85_g23_2),.p3(n81_g23_3),.p4(n46),.p5(n83),.p6(n42),.p7(n44),.p9(n41_g23_9),.p10(n40),.p11(n87),.p12(n35),.p13(n39),.p14(n38_g23_14),.p16(1'b0));
 cell_MC10102 h23(.p1(1'b0),.p2(n82_h23_2),.p3(n83_h23_3),.p4(n44),.p5(n46),.p6(n42),.p7(n44),.p9(n10_h23_9),.p10(n42),.p11(n82),.p12(n6),.p13(n9),.p14(n84_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n45_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n43),.p14(n9_h24_14),.p15(n44_h24_15));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n98),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n106_l01_12),.p13(n105_l01_13),.p14(n107_l01_14),.p15(n34),.p16(1'b0));
 original_SE10231 l02(.p2(n104_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n95;
 assign clocks[3]=n63;
 assign clocks[4]=n14;
 assign flags[0]=n93;
 assign flags[1]=n35;
 assign flags[2]=n20;
endmodule
`default_nettype wire
