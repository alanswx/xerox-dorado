// cell_MC10231 -- High-Speed Dual Type D Master-Slave Flip-Flop
//
// Pin numbers/names: PARC's EclDict.Analyze (what ANALYZE used to check the
// boards). Function: Motorola MECL Pocket Book -- see cells/PARTS.md.
// Used in 152 package position(s) across the sixteen Dorado boards.
//
// MECL is positive logic. Unused inputs have on-chip pulldowns (they read
// LOW), which is why the boards leave so many pins unconnected; Verilator
// treats an unconnected input as 0, which matches.
//
// NOTE: the dictionary lists a common-clock pin CC (9) alongside the two
// per-flop clocks. The MECL part is documented as a plain dual D flip-flop,
// so CC is left unmodelled and explicitly marked unused rather than guessed
// at -- if a board drives it, that shows up as a real signal going nowhere.

`default_nettype none

module dorado_serial_DskEth__cell_MC10231_snapshot #(parameter PRECAP = 1) (
    input wire state_host_clk, state_advance, state_hold, state_write,
    input wire [17:0] state_data,
    output wire [17:0] state_result,
    input  wire sys_clk,
    input  wire p6,   // C  clock A,
    input  wire p7,   // D  data A,
    input  wire p4,   // R  reset A,
    input  wire p5,   // S  set A,
    output wire p2,   // Q  A,
    output wire p3,   // Q' A,
    input  wire p11,  // C  clock B,
    input  wire p10,  // D  data B,
    input  wire p13,  // R  reset B,
    input  wire p12,  // S  set B,
    output wire p15,  // Q  B,
    output wire p14,  // Q' B,
    input  wire p9,// CC common clock (dictionary marks it shared),
    // Pins the boards wire that the dictionary does not name --
    // power (VEE/VCC on a 16-pin MECL package) and the like,
    // declared so every board connection lands somewhere.
    input  wire p1,
    input  wire p8,
    input  wire p16
);

  // Dual type-D master-slave flip-flop with asynchronous Set and Reset.
  // MECL S/R are ACTIVE HIGH and dominate the clock.

  // FPGA: ONE CLOCK, and the ECL clock net becomes an ENABLE.
  //
  // The Dorado clocks this part from a distributed ECL clock net (CLK.ph'
  // and friends, fanned out by the BaseBoard). Taking that literally gives
  // the fabric a gated clock off combinational logic -- 1,201 packages across
  // the machine do it -- which no FPGA can route. So every flip-flop here
  // runs on `sys_clk` and transfers on the sys_clk edge FOLLOWING an edge of
  // the modelled clock net. That is the usual oversampling transform, and it
  // matches the part as long as sys_clk is faster than the clock net, which
  // dorado_machine guarantees by dividing.
  //
  // Asynchronous inputs (MR, S/R, CL') are LEVEL-tested every sys_clk edge --
  // the same treatment, and it keeps them out of the fabric's reset network.

  // THE COMMON CLOCK, pin 9 (CC), was ignored here until 2026-08-16 -- the
  // same class of bug Tim found on the combinational cells, and the reason
  // tools/sil_check_cells.py now reads the dictionary's [FF ...] entries too:
  //   MC231  [FF 10 ...>(14 15) : CLK (9 11) ...]   [FF 7 ...>(2 3) : CLK (9 6) ...]
  // Pin 9 is in BOTH clocks.
  //
  // The data book (DL122 rev 7, MC10231) says how the two combine: "Each
  // flip-flop may be clocked separately by holding the common clock in the
  // low state and using the enable inputs for the clocking function. If the
  // common clock is to be used to clock the flip-flop, the Clock Enable
  // inputs must be in the low state." Either can clock it while the other is
  // held low -- an OR.
  wire clka = p9 | p6;    // CC or this half's Clock Enable
  wire clkb = p9 | p11;

  reg cka_d, ckb_d;
  
  wire cka_en = clka & ~cka_d;
  wire ckb_en = clkb & ~ckb_d;

  reg qa, qb;
  // PRE-EDGE CAPTURE -- the real flip-flop's SETUP TIME, as cell_MC10176,
  // cell_MC10141 and cell_SE10231 have it: the edge is detected one sys_clk
  // after the modelled clock rises, and a D that moved ON that edge has by
  // then settled to its new value, so a same-edge register-to-register
  // transfer became a pass-through. Applied to this family (152 packages)
  // on 2026-09-05 after the MC10141 instance (ProcH a21, Curr <- Next on
  // SHCP'C) was measured loading the incoming task a cycle early.
  reg d_pre_a, d_pre_b;
  
  // PRECAP=0 selects same-edge (post) capture for a package whose clock has
  // been moved by the derived depth model, where pre-edge sampling would miss
  // data that arrives with the edge. MemC g17 -- the cache HIT flip-flop --
  // is the case this was added for (2026-09-07).
  wire d_a = PRECAP ? d_pre_a : p7;
  wire d_b = PRECAP ? d_pre_b : p10;

  
  
  assign p2 = qa, p3 = ~qa;
  assign p15 = qb, p14 = ~qb;

  wire _unused_pins = &{1'b0, p1, p8, p16, 1'b0};

  // Experimental full-state clock-enable adapter. No guest warm-up edge.
  assign state_result = {12'b0, {cka_d, ckb_d, d_pre_a, d_pre_b, qa, qb}};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {cka_d, ckb_d, d_pre_a, d_pre_b, qa, qb} <= state_data[5:0];
    end else if (state_advance) begin
      begin cka_d <= clka; ckb_d <= clkb; end
      begin d_pre_a <= p7; d_pre_b <= p10; end
      begin
    if (p5)          qa <= 1'b1;      // S
    else if (p4)     qa <= 1'b0;      // R
    else if (cka_en) qa <= d_a;       // D
  end
      begin
    if (p12)         qb <= 1'b1;
    else if (p13)    qb <= 1'b0;
    else if (ckb_en) qb <= d_b;
  end
    end
  end
endmodule

`default_nettype wire
