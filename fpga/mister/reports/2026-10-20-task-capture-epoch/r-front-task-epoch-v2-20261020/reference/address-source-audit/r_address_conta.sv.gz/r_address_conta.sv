`timescale 1ns/1ps
`default_nettype none
module r_address_conta(input wire fixture_load,input wire [47:0] fixture_state,
 input wire base,start_a,en,input wire [201:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,rb_forward,rb_forward_n,
 output wire [47:0] state_q,output wire [12:0] clocks,
 output wire [13:0] flags);
 wire n0; // 11or10'
 wire n1; // 15/14/11/10
 wire n2; // 15or14'
 wire n3; // 15to12'
 wire n4; // 15to8
 wire n5; // 1andNot3or2'
 wire n6; // 3or2'
 wire n7; // 7or6
 wire n8; // 7or6'
 wire n9; // 7to4
 wire n10; // 7to4'
 wire n11; // AlwaysSH
 wire n12; // BNT.0
 wire n13; // BNT.0'
 wire n14; // BNT.1
 wire n15; // BNT.1'
 wire n16; // BNT.2
 wire n17; // BNT.2'
 wire n18; // BNT.3
 wire n19; // BNT.3'
 wire n20; // BNTGtCT'a
 wire n21; // BNTGtCT'b
 wire n22; // BNextRegsEn'
 wire n23; // Block'
 wire n24; // CAHold
 wire n25; // CAHold'
 wire n26; // CAHoldB
 wire n27; // CAHoldD
 wire n28; // CLK.ca'
 wire n29; // CLKEnable'a
 wire n30; // CLKEnable'b
 wire n31; // CLKEnable'c
 wire n32; // CPAddr.0'
 wire n33; // CPStrb'
 wire n34; // CRamClock
 wire n35; // CTask.0
 wire n36; // CTask.0'
 wire n37; // CTask.1
 wire n38; // CTask.1'
 wire n39; // CTask.2
 wire n40; // CTask.2'
 wire n41; // CTask.3
 wire n42; // CTask.3'
 wire n43; // CTask=0
 wire n44; // ClearMemStop
 wire n45; // ContA02.sil+1
 wire n46; // ContA04.sil+1
 wire n47; // ContA05.sil+4
 wire n48; // ContA25.sil+1
 wire n49; // ContA25.sil+2
 wire n50; // ContA25.sil+3
 wire n51; // ContA25.sil+4
 wire n52; // ContA25.sil+5
 wire n53; // ContA27.sil+1
 wire n54; // ContA27.sil+2
 wire n55; // ContA28.sil+2
 wire n56; // ContA28.sil+3
 wire n57; // ContA28.sil+4
 wire n58; // ContA28.sil+7
 wire n59; // ContA30.sil+1
 wire n60; // ContA31.sil+1
 wire n61; // ContA31.sil+2
 wire n62; // ContA31.sil+3
 wire n63; // ContA31.sil+4
 wire n64; // ContA31.sil+5
 wire n65; // Error'
 wire n66; // FF=TOffIsOK
 wire n67; // FF=TaskingOff
 wire n68; // Freeze
 wire n69; // FreezeAC
 wire n70; // FreezeBD
 wire n71; // GND180
 wire n72; // GND264
 wire n73; // GND266
 wire n74; // GND278
 wire n75; // GND312
 wire n76; // GND314
 wire n77; // GND394
 wire n78; // GND396
 wire n79; // GND398
 wire n80; // GND4
 wire n81; // GND444
 wire n82; // GND446
 wire n83; // GND468
 wire n84; // GND530
 wire n85; // GND544
 wire n86; // GetTLink
 wire n87; // GetTLink'
 wire n88; // Hold
 wire n89; // IsNext.01'
 wire n90; // IsNext.02'
 wire n91; // IsNext.03'
 wire n92; // IsNext.04'
 wire n93; // IsNext.05'
 wire n94; // IsNext.06'
 wire n95; // IsNext.07'
 wire n96; // IsNext.08'
 wire n97; // IsNext.09'
 wire n98; // IsNext.10'
 wire n99; // IsNext.11'
 wire n100; // IsNext.12'
 wire n101; // IsNext.13'
 wire n102; // IsNext.14'
 wire n103; // IsNext.15'
 wire n104; // MemClkEnable'a
 wire n105; // MemClkEnable'b
 wire n106; // MemSH
 wire n107; // MemSH'
 wire n108; // MidasData'
 wire n109; // Next.0
 wire n110; // Next.1
 wire n111; // Next.2
 wire n112; // Next.3
 wire n113; // Next=0
 wire n114; // NoDispatch
 wire n115; // PEnc.0
 wire n116; // PEnc.1
 wire n117; // PEnc.2
 wire n118; // PEnc.3
 wire n119; // PEnc=CT'
 wire n120; // PEncGtTrueNext'
 wire n121; // PEncLtTrueNext'
 wire n122; // Phase0
 wire n123; // Phase0'
 wire n124; // Phase1
 wire n125; // Phase2
 wire n126; // Phase2'
 wire n127; // Phase3
 wire n128; // Phase3'
 wire n129; // Phase4
 wire n130; // Phase4'
 wire n131; // RWTPCorRWIM
 wire n132; // Ready.01
 wire n133; // Ready.02
 wire n134; // Ready.03
 wire n135; // Ready.04
 wire n136; // Ready.05
 wire n137; // Ready.06
 wire n138; // Ready.07
 wire n139; // Ready.08
 wire n140; // Ready.09
 wire n141; // Ready.10
 wire n142; // Ready.11
 wire n143; // Ready.12
 wire n144; // Ready.13
 wire n145; // Ready.14
 wire n146; // Ready.15
 wire n147; // RepeatCur
 wire n148; // RepeatCur'
 wire n149; // RepeatCurB
 wire n150; // RepeatCurC
 wire n151; // RepeatCurD
 wire n152; // Run'
 wire n153; // RunClk'a
 wire n154; // RunClk'b
 wire n155; // RunRefresh
 wire n156; // RunRefresh'
 wire n157; // SC&NoFreeze
 wire n158; // SC&NoFreeze'
 wire n159; // SCorFreezea
 wire n160; // SCorFreezeb
 wire n161; // SetRun
 wire n162; // SetRun'
 wire n163; // SetRunRfsh
 wire n164; // SetSS'
 wire n165; // StartCycle
 wire n166; // StartCycle'
 wire n167; // StartCycle'a
 wire n168; // Stop
 wire n169; // StopAtT1
 wire n170; // StopAtT1'
 wire n171; // StopRunClock
 wire n172; // StopTasks
 wire n173; // Switch'a
 wire n174; // Switch'b
 wire n175; // SwitchDown
 wire n176; // SwitchUp
 wire n177; // SwitchUp'
 wire n178; // Switcha
 wire n179; // Switchb
 wire n180; // TPCBypass
 wire n181; // TPCBypass'
 wire n182; // TPCIclk'a
 wire n183; // TPCIclk'b
 wire n184; // TPCIclk'c
 wire n185; // TWReq.01
 wire n186; // TWReq.02
 wire n187; // TWReq.03
 wire n188; // TWReq.04
 wire n189; // TWReq.05
 wire n190; // TWReq.06
 wire n191; // TWReq.07
 wire n192; // TWReq.08
 wire n193; // TWReq.09
 wire n194; // TWReq.10
 wire n195; // TWReq.11
 wire n196; // TWReq.12
 wire n197; // TWReq.13
 wire n198; // TWReq.14
 wire n199; // TWReq.15
 wire n200; // ToPE.01
 wire n201; // ToPE.02
 wire n202; // ToPE.03
 wire n203; // ToPE.03'
 wire n204; // ToPE.04
 wire n205; // ToPE.05
 wire n206; // ToPE.05'
 wire n207; // ToPE.06
 wire n208; // ToPE.07
 wire n209; // ToPE.07'
 wire n210; // ToPE.08
 wire n211; // ToPE.09
 wire n212; // ToPE.09'
 wire n213; // ToPE.10
 wire n214; // ToPE.11
 wire n215; // ToPE.11'
 wire n216; // ToPE.12
 wire n217; // ToPE.13
 wire n218; // ToPE.13'
 wire n219; // ToPE.14
 wire n220; // ToPE.15
 wire n221; // ToPE.15'
 wire n222; // TrueAC
 wire n223; // TrueBD
 wire n224; // UseDMD
 wire n225; // WIM'
 wire n226; // WTPC'
 wire n227; // WantRunRfsh
 wire n228; // bCLKEnable'a
 wire n229; // bCLKEnable'b
 wire n230; // bCLKEnable'c
 wire n231; // bCLKEnable'd
 wire n232; // bCLKEnable'e
 wire n233; // bCLKEnable'f
 wire n234; // bPEnc.0
 wire n235; // bPEnc.0'
 wire n236; // bPEnc.1
 wire n237; // bPEnc.1'
 wire n238; // bPEnc.2
 wire n239; // bPEnc.2'
 wire n240; // bPEnc.3
 wire n241; // bPEnc.3'
 wire n242; // bSwitchUp'
 wire n243; // bpreStartC'a
 wire n244; // bpreStartC'b
 wire n245; // bpreStartC'c
 wire n246; // brMIRa
 wire n247; // brMIRb
 wire n248; // brMIRc
 wire n249; // clk0'Ba
 wire n250; // clk0'Bb
 wire n251; // clk0'Ca
 wire n252; // clk0'Cb
 wire n253; // clk0'Cc
 wire n254; // clk0'Da
 wire n255; // clk0'Db
 wire n256; // clk0'Dc
 wire n257; // clk1'Ca
 wire n258; // clk1'Cb
 wire n259; // clk2'Ba
 wire n260; // clk2'Bb
 wire n261; // clk2'Bc
 wire n262; // clk2'Bd
 wire n263; // clk2'Be
 wire n264; // clk2'Bf
 wire n265; // dBlock'
 wire n266; // dMemRun
 wire n267; // dRun
 wire n268; // dStartCycle
 wire n269; // dStop
 wire n270; // dSwitch
 wire n271; // dSwitchUp'
 wire n272; // h*fclk0'Ba
 wire n273; // h*fclk0'Bb
 wire n274; // h*fclk0'Da
 wire n275; // h*fclk0'Db
 wire n276; // h*fclk0'Dc
 wire n277; // pNext.0
 wire n278; // pNext.1
 wire n279; // pNext.2
 wire n280; // pNext.3
 wire n281; // preCRamClock
 wire n282; // preFH'
 wire n283; // preRunClk'Ba
 wire n284; // preRunClk'Bb
 wire n285; // preRunClk'Bc
 wire n286; // preStartCyclea
 wire n287; // preclk0'Aa
 wire n288; // preclk0'Ba
 wire n289; // preclk0'Ca
 wire n290; // preclk0'Cb
 wire n291; // preclk0'Da
 wire n292; // preclk1'Aa
 wire n293; // preclk1'Ca
 wire n294; // preclk1'Da
 wire n295; // preclk2'Aa
 wire n296; // preclk2'Ba
 wire n297; // preclk2'Bb
 wire n298; // preclk2'Bc
 wire n299; // preclk2'Bd
 wire n300; // preclk2'Ca
 wire n301; // preclk2'Da
 wire n302; // prepreclk'a
 wire n303; // prepreclk'b
 wire n304; // prepreclk'c
 wire n305; // prepreclk'd
 wire n306; // prepreclk'e
 wire n307; // rCT
 wire n308; // rMIRa
 wire n309; // rStop
 wire n310; // sCTask.0
 wire n311; // sCTask.1
 wire n312; // sCTask.2
 wire n313; // sCTask.3
 wire n314; // sPhase0
 assign n71=1'b0;
 assign n72=1'b0;
 assign n73=1'b0;
 assign n74=1'b0;
 assign n75=1'b0;
 assign n76=1'b0;
 assign n77=1'b0;
 assign n78=1'b0;
 assign n79=1'b0;
 assign n80=1'b0;
 assign n81=1'b0;
 assign n82=1'b0;
 assign n83=1'b0;
 assign n84=1'b0;
 assign n85=1'b0;
 assign n23=pins[67];
 assign n28=base;
 assign n32=1'b1;
 assign n33=1'b1;
 assign n55=1'b0;
 assign n56=1'b0;
 assign n57=1'b0;
 assign n58=1'b0;
 assign n59=1'b0;
 assign n65=pins[3];
 assign n66=1'b0;
 assign n67=1'b0;
 assign n86=1'b0;
 assign n88=pins[69];
 assign n89=pins[50];
 assign n90=pins[51];
 assign n91=pins[52];
 assign n92=pins[53];
 assign n93=pins[54];
 assign n94=pins[55];
 assign n95=pins[56];
 assign n96=pins[57];
 assign n97=pins[58];
 assign n98=pins[59];
 assign n99=pins[60];
 assign n100=pins[61];
 assign n101=pins[62];
 assign n102=pins[63];
 assign n103=pins[64];
 assign n114=pins[0];
 assign n131=pins[1];
 assign n132=pins[35];
 assign n133=pins[36];
 assign n134=pins[37];
 assign n135=pins[38];
 assign n136=pins[39];
 assign n137=pins[40];
 assign n138=pins[41];
 assign n139=pins[42];
 assign n140=pins[43];
 assign n141=pins[44];
 assign n142=pins[45];
 assign n143=pins[46];
 assign n144=pins[47];
 assign n145=pins[48];
 assign n146=pins[49];
 assign n161=pins[6];
 assign n163=pins[4];
 assign n164=pins[5];
 assign n169=pins[2];
 assign n172=pins[65];
 assign n185=pins[20];
 assign n186=pins[21];
 assign n187=pins[22];
 assign n188=pins[23];
 assign n189=pins[24];
 assign n190=pins[25];
 assign n191=pins[26];
 assign n192=pins[27];
 assign n193=pins[28];
 assign n194=pins[29];
 assign n195=pins[30];
 assign n196=pins[31];
 assign n197=pins[32];
 assign n198=pins[33];
 assign n199=pins[34];
 assign n225=pins[8];
 assign n226=1'b1;
 assign n265=pins[66];
 assign n307=pins[70];
 assign n308=1'b0;
 assign n309=pins[7];
 assign n310=pins[71];
 assign n311=pins[72];
 assign n312=pins[73];
 assign n313=pins[74];
 wire n0_e13_15;
 assign n0=n0_e13_15;
 wire n1_e13_9;
 wire n1_d12_2;
 assign n1=n1_e13_9 | n1_d12_2;
 wire n2_d12_3;
 assign n2=n2_d12_3;
 wire n3_c12_3;
 assign n3=n3_c12_3;
 wire n4_c12_15;
 wire n4_c12_2;
 assign n4=n4_c12_15 | n4_c12_2;
 wire n5_d13_9;
 wire n5_d13_14;
 assign n5=n5_d13_9 | n5_d13_14;
 wire n6_d13_15;
 assign n6=n6_d13_15;
 wire n7_g11_9;
 assign n7=n7_g11_9;
 wire n8_g11_15;
 assign n8=n8_g11_15;
 wire n9_d12_15;
 assign n9=n9_d12_15;
 wire n10_d12_14;
 assign n10=n10_d12_14;
 wire n11_l05_3;
 assign n11=n11_l05_3;
 wire n12_h09_14;
 assign n12=n12_h09_14;
 wire n13_h08_14;
 assign n13=n13_h08_14;
 wire n14_h09_15;
 assign n14=n14_h09_15;
 wire n15_h08_15;
 assign n15=n15_h08_15;
 wire n16_h09_2;
 assign n16=n16_h09_2;
 wire n17_h08_2;
 assign n17=n17_h08_2;
 wire n18_h09_3;
 assign n18=n18_h09_3;
 wire n19_h08_3;
 assign n19=n19_h08_3;
 wire n20_a02_13;
 assign n20=n20_a02_13;
 wire n21_a02_12;
 assign n21=n21_a02_12;
 wire n22_h10_2;
 assign n22=n22_h10_2;
 wire n24_f20_15;
 assign n24=n24_f20_15;
 wire n25_f20_14;
 assign n25=n25_f20_14;
 wire n26_f19_2;
 assign n26=n26_f19_2;
 wire n27_f19_4;
 assign n27=n27_f19_4;
 wire n29_k02_15;
 wire n29_k01_14;
 assign n29=n29_k02_15 | n29_k01_14;
 wire n30_k02_2;
 wire n30_k01_3;
 assign n30=n30_k02_2 | n30_k01_3;
 wire n31_l02_14;
 wire n31_l02_2;
 assign n31=n31_l02_14 | n31_l02_2;
 wire n34_j01_3;
 assign n34=n34_j01_3;
 wire n35_j08_15;
 assign n35=n35_j08_15;
 wire n36_j08_14;
 assign n36=n36_j08_14;
 wire n37_j08_2;
 assign n37=n37_j08_2;
 wire n38_j08_3;
 assign n38=n38_j08_3;
 wire n39_j09_15;
 assign n39=n39_j09_15;
 wire n40_j09_14;
 assign n40=n40_j09_14;
 wire n41_j09_2;
 assign n41=n41_j09_2;
 wire n42_j09_3;
 assign n42=n42_j09_3;
 wire n43_j10_14;
 assign n43=n43_j10_14;
 wire n44_h03_3;
 assign n44=n44_h03_3;
 wire n45_h03_14;
 assign n45=n45_h03_14;
 wire n46_d11_15;
 assign n46=n46_d11_15;
 wire n47_g11_2;
 assign n47=n47_g11_2;
 wire n48_h11_3;
 assign n48=n48_h11_3;
 wire n49_i10_2;
 assign n49=n49_i10_2;
 wire n50_i10_3;
 assign n50=n50_i10_3;
 wire n51_h11_2;
 assign n51=n51_h11_2;
 wire n52_g15_2;
 assign n52=n52_g15_2;
 wire n53_j05_2;
 assign n53=n53_j05_2;
 wire n54_i04_3;
 assign n54=n54_i04_3;
 wire n60_i03_14;
 assign n60=n60_i03_14;
 wire n61_i03_13;
 assign n61=n61_i03_13;
 wire n62_i03_2;
 assign n62=n62_i03_2;
 wire n63_i03_3;
 assign n63=n63_i03_3;
 wire n64_i03_4;
 assign n64=n64_i03_4;
 wire n68_i07_14;
 assign n68=n68_i07_14;
 wire n69_i07_13;
 assign n69=n69_i07_13;
 wire n70_i07_12;
 assign n70=n70_i07_12;
 wire n87_g05_15;
 assign n87=n87_g05_15;
 wire n104_l04_15;
 wire n104_l03_14;
 assign n104=n104_l04_15 | n104_l03_14;
 wire n105_l04_2;
 wire n105_l03_3;
 assign n105=n105_l04_2 | n105_l03_3;
 wire n106_k03_3;
 assign n106=n106_k03_3;
 wire n107_k03_2;
 assign n107=n107_k03_2;
 wire n108_f16_14;
 assign n108=n108_f16_14;
 wire n109_h14_14;
 assign n109=n109_h14_14;
 wire n110_h14_15;
 assign n110=n110_h14_15;
 wire n111_h14_2;
 assign n111=n111_h14_2;
 wire n112_h14_1;
 assign n112=n112_h14_1;
 wire n113_j10_3;
 assign n113=n113_j10_3;
 wire n115_e12_11;
 assign n115=n115_e12_11;
 wire n116_g11_3;
 wire n116_g11_14;
 assign n116=n116_g11_3 | n116_g11_14;
 wire n117_g10_3;
 assign n117=n117_g10_3;
 wire n118_f10_3;
 wire n118_f11_3;
 assign n118=n118_f10_3 | n118_f11_3;
 wire n119_j11_3;
 wire n119_j11_2;
 wire n119_j11_15;
 wire n119_j11_14;
 assign n119=n119_j11_3 | n119_j11_2 | n119_j11_15 | n119_j11_14;
 wire n120_g15_14;
 assign n120=n120_g15_14;
 wire n121_g15_15;
 assign n121=n121_g15_15;
 wire n122_l07_15;
 assign n122=n122_l07_15;
 wire n123_l07_14;
 assign n123=n123_l07_14;
 wire n124_l07_2;
 assign n124=n124_l07_2;
 wire n125_k05_15;
 assign n125=n125_k05_15;
 wire n126_k05_14;
 assign n126=n126_k05_14;
 wire n127_k05_2;
 assign n127=n127_k05_2;
 wire n128_k05_3;
 assign n128=n128_k05_3;
 wire n129_j01_15;
 assign n129=n129_j01_15;
 wire n130_j01_14;
 assign n130=n130_j01_14;
 wire n147_f20_3;
 assign n147=n147_f20_3;
 wire n148_f20_2;
 assign n148=n148_f20_2;
 wire n149_f19_13;
 assign n149=n149_f19_13;
 wire n150_f19_12;
 assign n150=n150_f19_12;
 wire n151_f19_14;
 assign n151=n151_f19_14;
 wire n152_j04_14;
 assign n152=n152_j04_14;
 wire n153_i06_3;
 assign n153=n153_i06_3;
 wire n154_i06_2;
 assign n154=n154_i06_2;
 wire n155_l06_15;
 assign n155=n155_l06_15;
 wire n156_l06_14;
 assign n156=n156_l06_14;
 wire n157_k04_2;
 assign n157=n157_k04_2;
 wire n158_k04_3;
 assign n158=n158_k04_3;
 wire n159_i06_13;
 assign n159=n159_i06_13;
 wire n160_i06_12;
 assign n160=n160_i06_12;
 wire n162_g05_3;
 assign n162=n162_g05_3;
 wire n165_k04_15;
 assign n165=n165_k04_15;
 wire n166_k04_14;
 assign n166=n166_k04_14;
 wire n167_k03_14;
 assign n167=n167_k03_14;
 wire n168_j04_2;
 assign n168=n168_j04_2;
 wire n170_g05_2;
 assign n170=n170_g05_2;
 wire n171_l05_2;
 assign n171=n171_l05_2;
 wire n173_f14_14;
 assign n173=n173_f14_14;
 wire n174_f14_3;
 assign n174=n174_f14_3;
 wire n175_g15_3;
 assign n175=n175_g15_3;
 wire n176_f15_14;
 assign n176=n176_f15_14;
 wire n177_f15_15;
 assign n177=n177_f15_15;
 wire n178_f14_15;
 assign n178=n178_f14_15;
 wire n179_f14_2;
 assign n179=n179_f14_2;
 wire n180_f15_2;
 assign n180=n180_f15_2;
 wire n181_f15_3;
 assign n181=n181_f15_3;
 wire n182_j06_13;
 assign n182=n182_j06_13;
 wire n183_j06_12;
 assign n183=n183_j06_12;
 wire n184_j06_14;
 assign n184=n184_j06_14;
 wire n200_a10_2;
 wire n200_a11_2;
 assign n200=n200_a10_2 | n200_a11_2;
 wire n201_a10_3;
 wire n201_a11_3;
 assign n201=n201_a10_3 | n201_a11_3;
 wire n202_a10_14;
 wire n202_a11_14;
 assign n202=n202_a10_14 | n202_a11_14;
 wire n203_d13_2;
 assign n203=n203_d13_2;
 wire n204_a10_15;
 wire n204_a11_15;
 assign n204=n204_a10_15 | n204_a11_15;
 wire n205_b10_2;
 wire n205_b11_2;
 assign n205=n205_b10_2 | n205_b11_2;
 wire n206_d13_3;
 assign n206=n206_d13_3;
 wire n207_b10_3;
 wire n207_b11_3;
 assign n207=n207_b10_3 | n207_b11_3;
 wire n208_b10_14;
 wire n208_b11_14;
 assign n208=n208_b10_14 | n208_b11_14;
 wire n209_e12_2;
 assign n209=n209_e12_2;
 wire n210_b11_15;
 wire n210_b10_15;
 assign n210=n210_b11_15 | n210_b10_15;
 wire n211_c11_2;
 wire n211_c10_2;
 assign n211=n211_c11_2 | n211_c10_2;
 wire n212_e13_14;
 assign n212=n212_e13_14;
 wire n213_c11_3;
 wire n213_c10_3;
 assign n213=n213_c11_3 | n213_c10_3;
 wire n214_c10_14;
 wire n214_c11_14;
 assign n214=n214_c10_14 | n214_c11_14;
 wire n215_e13_3;
 assign n215=n215_e13_3;
 wire n216_c11_15;
 wire n216_c10_15;
 assign n216=n216_c11_15 | n216_c10_15;
 wire n217_d11_2;
 wire n217_d10_2;
 assign n217=n217_d11_2 | n217_d10_2;
 wire n218_e12_3;
 assign n218=n218_e12_3;
 wire n219_d11_3;
 wire n219_d10_3;
 assign n219=n219_d11_3 | n219_d10_3;
 wire n220_d11_14;
 wire n220_d10_14;
 assign n220=n220_d11_14 | n220_d10_14;
 wire n221_e13_2;
 assign n221=n221_e13_2;
 wire n222_g05_13;
 assign n222=n222_g05_13;
 wire n223_g05_4;
 assign n223=n223_g05_4;
 wire n224_i04_15;
 assign n224=n224_i04_15;
 wire n227_l05_15;
 assign n227=n227_l05_15;
 wire n228_i05_3;
 assign n228=n228_i05_3;
 wire n229_i05_2;
 assign n229=n229_i05_2;
 wire n230_i05_4;
 assign n230=n230_i05_4;
 wire n231_i05_13;
 assign n231=n231_i05_13;
 wire n232_i05_12;
 assign n232=n232_i05_12;
 wire n233_i05_14;
 assign n233=n233_i05_14;
 wire n234_i11_5;
 assign n234=n234_i11_5;
 wire n235_i11_2;
 assign n235=n235_i11_2;
 wire n236_i11_6;
 assign n236=n236_i11_6;
 wire n237_i11_3;
 assign n237=n237_i11_3;
 wire n238_i11_11;
 assign n238=n238_i11_11;
 wire n239_i11_14;
 assign n239=n239_i11_14;
 wire n240_i11_9;
 assign n240=n240_i11_9;
 wire n241_i11_15;
 assign n241=n241_i11_15;
 wire n242_a02_14;
 assign n242=n242_a02_14;
 wire n243_l08_3;
 assign n243=n243_l08_3;
 wire n244_l08_4;
 assign n244=n244_l08_4;
 wire n245_l08_2;
 assign n245=n245_l08_2;
 wire n246_a02_3;
 assign n246=n246_a02_3;
 wire n247_a02_2;
 assign n247=n247_a02_2;
 wire n248_a02_4;
 assign n248=n248_a02_4;
 wire n249_j07_13;
 assign n249=n249_j07_13;
 wire n250_j07_12;
 assign n250=n250_j07_12;
 wire n251_d18_3;
 assign n251=n251_d18_3;
 wire n252_d18_2;
 assign n252=n252_d18_2;
 wire n253_d18_4;
 assign n253=n253_d18_4;
 wire n254_j18_3;
 assign n254=n254_j18_3;
 wire n255_j18_2;
 assign n255=n255_j18_2;
 wire n256_j18_4;
 assign n256=n256_j18_4;
 wire n257_d18_13;
 assign n257=n257_d18_13;
 wire n258_d18_12;
 assign n258=n258_d18_12;
 wire n259_j06_3;
 assign n259=n259_j06_3;
 wire n260_j06_2;
 assign n260=n260_j06_2;
 wire n261_j06_4;
 assign n261=n261_j06_4;
 wire n262_i07_3;
 assign n262=n262_i07_3;
 wire n263_i07_2;
 assign n263=n263_i07_2;
 wire n264_i07_4;
 assign n264=n264_i07_4;
 wire n266_g04_15;
 wire n266_h03_2;
 assign n266=n266_g04_15 | n266_h03_2;
 wire n267_i03_15;
 assign n267=n267_i03_15;
 wire n268_j05_3;
 assign n268=n268_j05_3;
 wire n269_i04_2;
 wire n269_j05_14;
 assign n269=n269_i04_2 | n269_j05_14;
 wire n270_f17_14;
 wire n270_f17_3;
 wire n270_f16_3;
 assign n270=n270_f17_14 | n270_f17_3 | n270_f16_3;
 wire n271_f16_2;
 assign n271=n271_f16_2;
 wire n272_j07_3;
 assign n272=n272_j07_3;
 wire n273_j07_2;
 assign n273=n273_j07_2;
 wire n274_j18_13;
 assign n274=n274_j18_13;
 wire n275_j18_12;
 assign n275=n275_j18_12;
 wire n276_j18_14;
 assign n276=n276_j18_14;
 wire n277_h13_14;
 assign n277=n277_h13_14;
 wire n278_h13_15;
 assign n278=n278_h13_15;
 wire n279_h13_2;
 assign n279=n279_h13_2;
 wire n280_h13_1;
 assign n280=n280_h13_1;
 wire n281_g12_4;
 assign n281=n281_g12_4;
 wire n282_l06_3;
 assign n282=n282_l06_3;
 wire n283_f13_13;
 assign n283=n283_f13_13;
 wire n284_f13_12;
 assign n284=n284_f13_12;
 wire n285_f13_14;
 assign n285=n285_f13_14;
 wire n286_k03_15;
 assign n286=n286_k03_15;
 wire n287_g13_3;
 assign n287=n287_g13_3;
 wire n288_g13_2;
 assign n288=n288_g13_2;
 wire n289_g13_13;
 assign n289=n289_g13_13;
 wire n290_g13_12;
 assign n290=n290_g13_12;
 wire n291_g13_4;
 assign n291=n291_g13_4;
 wire n292_f13_3;
 assign n292=n292_f13_3;
 wire n293_f13_2;
 assign n293=n293_f13_2;
 wire n294_f13_4;
 assign n294=n294_f13_4;
 wire n295_f12_3;
 assign n295=n295_f12_3;
 wire n296_f12_13;
 assign n296=n296_f12_13;
 wire n297_f12_12;
 assign n297=n297_f12_12;
 wire n298_f12_14;
 assign n298=n298_f12_14;
 wire n299_g12_14;
 assign n299=n299_g12_14;
 wire n300_f12_2;
 assign n300=n300_f12_2;
 wire n301_f12_4;
 assign n301=n301_f12_4;
 wire n302_l01_13;
 assign n302=n302_l01_13;
 wire n303_l01_12;
 assign n303=n303_l01_12;
 wire n304_l01_14;
 assign n304=n304_l01_14;
 wire n305_l01_3;
 assign n305=n305_l01_3;
 wire n306_l01_2;
 assign n306=n306_l01_2;
 wire n314_i04_14;
 assign n314=n314_i04_14;
 cell_MC10210 a02(.p1(1'b0),.p2(n247_a02_2),.p3(n246_a02_3),.p4(n248_a02_4),.p5(n308),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n177),.p12(n21_a02_12),.p13(n20_a02_13),.p14(n242_a02_14),.p15(n80),.p16(1'b0));
 cell_MC1664 a10(.p2(n200_a10_2),.p3(n201_a10_3),.p4(1'b0),.p5(n185),.p6(1'b0),.p7(n186),.p10(1'b0),.p11(n187),.p12(1'b0),.p13(n188),.p14(n202_a10_14),.p15(n204_a10_15));
 cell_MC10104 a11(.p2(n200_a11_2),.p3(n201_a11_3),.p4(n132),.p5(n89),.p6(n90),.p7(n133),.p10(n134),.p11(n91),.p12(n92),.p13(n135),.p14(n202_a11_14),.p15(n204_a11_15),.p16(1'b0));
 cell_MC1664 b10(.p2(n205_b10_2),.p3(n207_b10_3),.p4(1'b0),.p5(n189),.p6(1'b0),.p7(n190),.p10(1'b0),.p11(n191),.p12(1'b0),.p13(n192),.p14(n208_b10_14),.p15(n210_b10_15));
 cell_MC10104 b11(.p2(n205_b11_2),.p3(n207_b11_3),.p4(n136),.p5(n93),.p6(n94),.p7(n137),.p10(n138),.p11(n95),.p12(n96),.p13(n139),.p14(n208_b11_14),.p15(n210_b11_15),.p16(1'b0));
 cell_MC1664 c10(.p2(n211_c10_2),.p3(n213_c10_3),.p4(1'b0),.p5(n193),.p6(1'b0),.p7(n194),.p10(1'b0),.p11(n195),.p12(1'b0),.p13(n196),.p14(n214_c10_14),.p15(n216_c10_15));
 cell_MC10104 c11(.p2(n211_c11_2),.p3(n213_c11_3),.p4(n140),.p5(n97),.p6(n98),.p7(n141),.p10(n142),.p11(n99),.p12(n100),.p13(n143),.p14(n214_c11_14),.p15(n216_c11_15),.p16(1'b0));
 cell_MC10109 c12(.p2(n4_c12_2),.p3(n3_c12_3),.p4(n216),.p5(n217),.p6(n219),.p7(n220),.p8(1'b0),.p9(n214),.p10(n213),.p11(n211),.p12(n210),.p13(1'b0),.p15(n4_c12_15));
 cell_MC1664 d10(.p2(n217_d10_2),.p3(n219_d10_3),.p4(1'b0),.p5(n197),.p6(1'b0),.p7(n198),.p10(1'b0),.p11(n199),.p12(1'b0),.p13(1'b0),.p14(n220_d10_14));
 cell_MC10104 d11(.p2(n217_d11_2),.p3(n219_d11_3),.p4(n144),.p5(n101),.p6(n102),.p7(n145),.p10(n146),.p11(n103),.p12(n66),.p13(n67),.p14(n220_d11_14),.p15(n46_d11_15),.p16(1'b0));
 cell_MC10109 d12(.p2(n1_d12_2),.p3(n2_d12_3),.p4(1'b0),.p5(n219),.p6(1'b0),.p7(n220),.p8(1'b0),.p9(n208),.p10(n207),.p11(n205),.p12(n204),.p13(1'b0),.p14(n10_d12_14),.p15(n9_d12_15));
 cell_MC10102 d13(.p1(1'b0),.p2(n203_d13_2),.p3(n206_d13_3),.p4(n202),.p5(1'b0),.p6(n205),.p7(1'b0),.p9(n5_d13_9),.p10(n200),.p11(1'b0),.p12(n201),.p13(n202),.p14(n5_d13_14),.p15(n6_d13_15),.p16(1'b0));
 cell_SE10210 d18(.p2(n252_d18_2),.p3(n251_d18_3),.p4(n253_d18_4),.p5(1'b0),.p6(1'b0),.p7(n289),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n293),.p12(n258_d18_12),.p13(n257_d18_13),.p15(n71),.p16(1'b0));
 cell_MC10101 e12(.p2(n209_e12_2),.p3(n218_e12_3),.p4(n208),.p7(n217),.p10(n4),.p11(n115_e12_11),.p12(1'b0),.p13(1'b0));
 cell_MC10102 e13(.p1(1'b0),.p2(n221_e13_2),.p3(n215_e13_3),.p4(n220),.p5(1'b0),.p6(n214),.p7(1'b0),.p9(n1_e13_9),.p10(n211),.p11(1'b0),.p12(n213),.p13(n214),.p14(n212_e13_14),.p15(n0_e13_15),.p16(1'b0));
 cell_MC10121 f10(.p3(n118_f10_3),.p4(n1),.p5(n216),.p6(n212),.p7(n203),.p9(n9),.p10(n4),.p11(n206),.p12(n7),.p13(n215),.p14(n219),.p15(n216));
 cell_MC10121 f11(.p3(n118_f11_3),.p4(n221),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n209),.p10(n4),.p11(n5),.p12(n9),.p13(1'b0),.p14(n218),.p15(n219));
 cell_SE10210 f12(.p2(n300_f12_2),.p3(n295_f12_3),.p4(n301_f12_4),.p5(n304),.p6(1'b0),.p7(n230),.p8(1'b0),.p9(n230),.p10(1'b0),.p11(n304),.p12(n297_f12_12),.p13(n296_f12_13),.p14(n298_f12_14),.p15(n72),.p16(1'b0));
 cell_SE10210 f13(.p2(n293_f13_2),.p3(n292_f13_3),.p4(n294_f13_4),.p5(n282),.p6(n302),.p7(n228),.p8(1'b0),.p9(1'b0),.p10(n171),.p11(n302),.p12(n284_f13_12),.p13(n283_f13_13),.p14(n285_f13_14),.p15(n73),.p16(1'b0));
 original_MC10231 f14(.p1(1'b0),.p2(n179_f14_2),.p3(n174_f14_3),.p4(n69),.p5(1'b0),.p6(n172),.p7(n270),.p8(1'b0),.p9(n251),.p10(n270),.p11(n172),.p12(1'b0),.p13(n69),.p14(n173_f14_14),.p15(n178_f14_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[40+:2]),.state_q(state_q[40+:2]));
 original_MC10231 f15(.p1(1'b0),.p2(n180_f15_2),.p3(n181_f15_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n52),.p8(1'b0),.p9(n252),.p10(n271),.p11(1'b0),.p12(n69),.p13(1'b0),.p14(n176_f15_14),.p15(n177_f15_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[42+:2]),.state_q(state_q[42+:2]));
 cell_MC1660 f16(.p2(n271_f16_2),.p3(n270_f16_3),.p4(1'b0),.p5(1'b0),.p6(n172),.p7(n120),.p8(1'b0),.p10(n55),.p11(n56),.p12(n57),.p13(1'b0),.p14(n108_f16_14));
 cell_MC1660 f17(.p3(n270_f17_3),.p4(n121),.p5(n149),.p6(n265),.p7(n113),.p8(1'b0),.p10(n43),.p11(n23),.p12(n148),.p13(n121),.p14(n270_f17_14));
 cell_SE10211 f19(.p2(n26_f19_2),.p4(n27_f19_4),.p5(1'b0),.p6(n25),.p7(1'b0),.p9(1'b0),.p10(n25),.p11(n176),.p12(n150_f19_12),.p13(n149_f19_13),.p14(n151_f19_14),.p15(n74),.p16(1'b0));
 cell_MC1660 f20(.p2(n148_f20_2),.p3(n147_f20_3),.p4(n25),.p5(1'b0),.p6(1'b0),.p7(n176),.p8(1'b0),.p10(n88),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n25_f20_14),.p15(n24_f20_15));
 cell_MC10104 g04(.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(n227),.p13(n156),.p15(n266_g04_15),.p16(1'b0));
 cell_MC10195 g05(.p2(n170_g05_2),.p3(n162_g05_3),.p4(n223_g05_4),.p5(n169),.p6(n161),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p12(n86),.p13(n222_g05_13),.p15(n87_g05_15));
 cell_MC10121 g10(.p3(n117_g10_3),.p4(n2),.p5(1'b0),.p6(1'b0),.p7(n6),.p9(n9),.p10(n4),.p11(1'b0),.p12(n8),.p13(n0),.p14(n216),.p15(n217));
 cell_MC10102 g11(.p1(1'b0),.p2(n47_g11_2),.p3(n116_g11_3),.p4(n128),.p5(n226),.p6(n4),.p7(n10),.p9(n7_g11_9),.p10(1'b0),.p11(n3),.p12(n207),.p13(n208),.p14(n116_g11_14),.p15(n8_g11_15),.p16(1'b0));
 cell_SE10212 g12(.p1(1'b0),.p4(n281_g12_4),.p5(n233),.p6(1'b0),.p7(n306),.p8(1'b0),.p9(n306),.p10(1'b0),.p11(n233),.p14(n299_g12_14),.p15(n75),.p16(1'b0));
 cell_SE10210 g13(.p2(n288_g13_2),.p3(n287_g13_3),.p4(n291_g13_4),.p5(n166),.p6(n303),.p7(n229),.p8(1'b0),.p9(n166),.p10(n303),.p11(n229),.p12(n290_g13_12),.p13(n289_g13_13),.p15(n76),.p16(1'b0));
 cell_MC1662 g15(.p2(n52_g15_2),.p3(n175_g15_3),.p4(n119),.p5(n23),.p6(n173),.p7(n176),.p10(n51),.p11(n49),.p12(n48),.p13(n50),.p14(n120_g15_14),.p15(n121_g15_15));
 cell_MC10103 h03(.p1(1'b0),.p2(n266_h03_2),.p3(n44_h03_3),.p4(n267),.p5(1'b0),.p6(n309),.p7(n155),.p10(n32),.p11(n33),.p12(1'b0),.p13(1'b0),.p14(n45_h03_14),.p16(1'b0));
 original_MC10141 h08(.p1(1'b0),.p2(n17_h08_2),.p3(n19_h08_3),.p4(n249),.p5(1'b0),.p6(n241),.p7(n22),.p8(1'b0),.p9(n239),.p10(n22),.p11(n237),.p12(n235),.p13(1'b0),.p14(n13_h08_14),.p15(n15_h08_15),.fixture_load(fixture_load),.fixture_state(fixture_state[32+:4]),.state_q(state_q[32+:4]));
 original_MC10141 h09(.p1(1'b0),.p2(n16_h09_2),.p3(n18_h09_3),.p4(n250),.p5(1'b0),.p6(n240),.p7(n22),.p8(1'b0),.p9(n238),.p10(n22),.p11(n236),.p12(n234),.p13(1'b0),.p14(n12_h09_14),.p15(n14_h09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[36+:4]),.state_q(state_q[36+:4]));
 cell_MC10166 h10(.p2(n22_h10_2),.p4(1'b0),.p5(1'b0),.p6(n18),.p7(n118),.p9(n12),.p10(n115),.p11(n116),.p12(n14),.p13(n16),.p14(n117),.p15(n148));
 cell_MC10166 h11(.p2(n51_h11_2),.p3(n48_h11_3),.p4(1'b0),.p5(1'b0),.p6(n118),.p7(n280),.p9(n115),.p10(n277),.p11(n278),.p12(n116),.p13(n117),.p14(n279),.p15(n147));
 cell_MC10159 h13(.p1(n280_h13_1),.p2(n279_h13_2),.p3(n40),.p4(n17),.p5(n42),.p6(n19),.p7(1'b0),.p9(n178),.p10(n36),.p11(n13),.p12(n38),.p13(n15),.p14(n277_h13_14),.p15(n278_h13_15));
 cell_MC10159 h14(.p1(n112_h14_1),.p2(n111_h14_2),.p3(n40),.p4(n17),.p5(n42),.p6(n19),.p7(1'b0),.p9(n178),.p10(n36),.p11(n13),.p12(n38),.p13(n15),.p14(n109_h14_14),.p15(n110_h14_15));
 original_MC10176 i03(.p1(1'b0),.p2(n62_i03_2),.p3(n63_i03_3),.p4(n64_i03_4),.p5(n164),.p6(n62),.p7(n63),.p8(1'b0),.p9(n154),.p10(n161),.p11(n61),.p12(n60),.p13(n61_i03_13),.p14(n60_i03_14),.p15(n267_i03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 cell_MC10104 i04(.p2(n269_i04_2),.p3(n54_i04_3),.p4(n122),.p5(n169),.p6(n53),.p7(n122),.p10(n170),.p11(n232),.p12(n58),.p13(n161),.p14(n314_i04_14),.p15(n224_i04_15),.p16(1'b0));
 cell_MC10210 i05(.p1(1'b0),.p2(n229_i05_2),.p3(n228_i05_3),.p4(n230_i05_4),.p5(n168),.p6(n152),.p7(1'b0),.p8(1'b0),.p9(n152),.p10(1'b0),.p11(n168),.p12(n232_i05_12),.p13(n231_i05_13),.p14(n233_i05_14),.p15(n77),.p16(1'b0));
 cell_SE10210 i06(.p2(n154_i06_2),.p3(n153_i06_3),.p5(1'b0),.p6(1'b0),.p7(n283),.p8(1'b0),.p9(1'b0),.p10(n70),.p11(n286),.p12(n160_i06_12),.p13(n159_i06_13),.p15(n78),.p16(1'b0));
 cell_SE10210 i07(.p2(n263_i07_2),.p3(n262_i07_3),.p4(n264_i07_4),.p5(1'b0),.p6(1'b0),.p7(n299),.p8(1'b0),.p9(n114),.p10(1'b0),.p11(1'b0),.p12(n70_i07_12),.p13(n69_i07_13),.p14(n68_i07_14),.p15(n79),.p16(1'b0));
 cell_MC10166 i10(.p2(n49_i10_2),.p3(n50_i10_3),.p4(1'b0),.p5(1'b0),.p6(n118),.p7(n41),.p9(n115),.p10(n35),.p11(n37),.p12(n116),.p13(n117),.p14(n39),.p15(n148));
 cell_MC10101 i11(.p2(n235_i11_2),.p3(n237_i11_3),.p4(n115),.p5(n234_i11_5),.p6(n236_i11_6),.p7(n116),.p9(n240_i11_9),.p10(n117),.p11(n238_i11_11),.p12(1'b0),.p13(n118),.p14(n239_i11_14),.p15(n241_i11_15));
 original_MC10231 j01(.p1(1'b0),.p3(n34_j01_3),.p4(1'b0),.p5(n225),.p6(n281),.p7(n126),.p8(1'b0),.p9(1'b0),.p10(n127),.p11(n261),.p12(1'b0),.p13(n314),.p14(n130_j01_14),.p15(n129_j01_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:2]),.state_q(state_q[30+:2]));
 original_MC10231 j04(.p1(1'b0),.p2(n168_j04_2),.p4(n309),.p5(1'b0),.p6(n261),.p7(n269),.p8(1'b0),.p9(1'b0),.p10(n267),.p11(n153),.p12(1'b0),.p13(1'b0),.p14(n152_j04_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:2]),.state_q(state_q[6+:2]));
 cell_MC10117 j05(.p2(n53_j05_2),.p3(n268_j05_3),.p4(n131),.p5(n123),.p6(1'b0),.p7(n130),.p9(1'b0),.p10(n244),.p11(n64),.p12(n244),.p13(n65),.p14(n269_j05_14));
 cell_SE10210 j06(.p2(n260_j06_2),.p3(n259_j06_3),.p4(n261_j06_4),.p5(1'b0),.p6(n296),.p7(1'b0),.p8(1'b0),.p9(n296),.p10(1'b0),.p11(n59),.p12(n183_j06_12),.p13(n182_j06_13),.p14(n184_j06_14),.p15(n81),.p16(1'b0));
 cell_SE10210 j07(.p2(n273_j07_2),.p3(n272_j07_3),.p5(n70),.p6(n147),.p7(n288),.p8(1'b0),.p9(n288),.p10(1'b0),.p11(1'b0),.p12(n250_j07_12),.p13(n249_j07_13),.p15(n82),.p16(1'b0));
 original_MC10231 j08(.p1(1'b0),.p2(n37_j08_2),.p3(n38_j08_3),.p4(n307),.p5(n311),.p6(1'b0),.p7(n278),.p8(1'b0),.p9(n272),.p10(n277),.p11(1'b0),.p12(n310),.p13(n307),.p14(n36_j08_14),.p15(n35_j08_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[44+:2]),.state_q(state_q[44+:2]));
 original_MC10231 j09(.p1(1'b0),.p2(n41_j09_2),.p3(n42_j09_3),.p4(n307),.p5(n313),.p6(1'b0),.p7(n280),.p8(1'b0),.p9(n273),.p10(n279),.p11(1'b0),.p12(n312),.p13(n307),.p14(n40_j09_14),.p15(n39_j09_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[46+:2]),.state_q(state_q[46+:2]));
 cell_MC10109 j10(.p3(n113_j10_3),.p4(n280),.p5(n279),.p6(n278),.p7(n277),.p8(1'b0),.p9(1'b0),.p10(n35),.p11(n37),.p12(n41),.p13(n39),.p14(n43_j10_14));
 cell_MC10113 j11(.p1(1'b0),.p2(n119_j11_2),.p3(n119_j11_3),.p4(n241),.p5(n42),.p6(n40),.p7(n239),.p9(1'b0),.p10(n38),.p11(n237),.p12(n36),.p13(n235),.p14(n119_j11_14),.p15(n119_j11_15));
 cell_SE10210 j18(.p2(n255_j18_2),.p3(n254_j18_3),.p4(n256_j18_4),.p5(1'b0),.p6(1'b0),.p7(n291),.p8(1'b0),.p9(n70),.p10(n151),.p11(n291),.p12(n275_j18_12),.p13(n274_j18_13),.p14(n276_j18_14),.p15(n83),.p16(1'b0));
 original_MC10231 k01(.p1(1'b0),.p3(n30_k01_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n267),.p8(1'b0),.p9(n284),.p10(n267),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n29_k01_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:2]),.state_q(state_q[8+:2]));
 original_MC10231 k02(.p1(1'b0),.p2(n30_k02_2),.p4(n309),.p5(1'b0),.p6(1'b0),.p7(n269),.p8(1'b0),.p9(n297),.p10(n269),.p11(1'b0),.p12(1'b0),.p13(n309),.p15(n29_k02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[10+:2]),.state_q(state_q[10+:2]));
 original_MC10231 k03(.p1(1'b0),.p2(n107_k03_2),.p3(n106_k03_3),.p4(1'b0),.p5(1'b0),.p6(n305),.p7(n11),.p8(1'b0),.p9(1'b0),.p10(n268),.p11(n297),.p12(1'b0),.p13(n314),.p14(n167_k03_14),.p15(n286_k03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[22+:2]),.state_q(state_q[22+:2]));
 original_MC10231 k04(.p1(1'b0),.p2(n157_k04_2),.p3(n158_k04_3),.p4(n314),.p5(1'b0),.p6(n70),.p7(n268),.p8(1'b0),.p9(n263),.p10(n268),.p11(1'b0),.p12(1'b0),.p13(n314),.p14(n166_k04_14),.p15(n165_k04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[24+:2]),.state_q(state_q[24+:2]));
 original_MC10231 k05(.p1(1'b0),.p2(n127_k05_2),.p3(n128_k05_3),.p4(n314),.p5(1'b0),.p6(1'b0),.p7(n125),.p8(1'b0),.p9(n263),.p10(n124),.p11(1'b0),.p12(1'b0),.p13(n314),.p14(n126_k05_14),.p15(n125_k05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:2]),.state_q(state_q[26+:2]));
 cell_SE10210 l01(.p2(n306_l01_2),.p3(n305_l01_3),.p5(1'b0),.p6(1'b0),.p7(n28),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n28),.p12(n303_l01_12),.p13(n302_l01_13),.p14(n304_l01_14),.p15(n84),.p16(1'b0));
 original_MC10231 l02(.p1(1'b0),.p2(n31_l02_2),.p4(n309),.p5(1'b0),.p6(n298),.p7(n269),.p8(1'b0),.p9(1'b0),.p10(n267),.p11(n285),.p12(1'b0),.p13(1'b0),.p14(n31_l02_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:2]),.state_q(state_q[12+:2]));
 original_MC10231 l03(.p1(1'b0),.p3(n105_l03_3),.p4(1'b0),.p5(n155),.p6(1'b0),.p7(n266),.p8(1'b0),.p9(n285),.p10(n266),.p11(1'b0),.p12(n155),.p13(1'b0),.p14(n104_l03_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[14+:2]),.state_q(state_q[14+:2]));
 original_MC10231 l04(.p1(1'b0),.p2(n105_l04_2),.p4(n44),.p5(1'b0),.p6(1'b0),.p7(n269),.p8(1'b0),.p9(n297),.p10(n269),.p11(1'b0),.p12(1'b0),.p13(n44),.p15(n104_l04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:2]),.state_q(state_q[16+:2]));
 original_MC10231 l05(.p1(1'b0),.p2(n171_l05_2),.p3(n11_l05_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n11),.p8(1'b0),.p9(n305),.p10(n163),.p11(n171),.p12(1'b0),.p13(1'b0),.p15(n227_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[18+:2]),.state_q(state_q[18+:2]));
 original_SE10231 l06(.p3(n282_l06_3),.p6(n231),.p7(n286),.p9(n305),.p10(n227),.p11(n171),.p13(1'b0),.p14(n156_l06_14),.p15(n155_l06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:2]),.state_q(state_q[20+:2]));
 original_MC10231 l07(.p1(1'b0),.p2(n124_l07_2),.p4(n314),.p5(1'b0),.p6(1'b0),.p7(n54),.p8(1'b0),.p9(n264),.p10(n165),.p11(1'b0),.p12(n314),.p13(1'b0),.p14(n123_l07_14),.p15(n122_l07_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[28+:2]),.state_q(state_q[28+:2]));
 cell_MC10211 l08(.p2(n245_l08_2),.p3(n243_l08_3),.p4(n244_l08_4),.p5(1'b0),.p6(n286),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n85),.p16(1'b0));
 assign clocks[0]=n305;
 assign clocks[1]=n171;
 assign clocks[2]=n285;
 assign clocks[3]=n153;
 assign clocks[4]=n297;
 assign clocks[5]=n261;
 assign clocks[6]=l06.ca;
 assign clocks[7]=k04.ca;
 assign clocks[8]=n281;
 assign clocks[9]=n249;
 assign clocks[10]=n272;
 assign clocks[11]=n274;
 assign clocks[12]=f14.ca;
 assign flags[0]=n24;
 assign flags[1]=n147;
 assign flags[2]=n70;
 assign flags[3]=n31;
 assign flags[4]=n30;
 assign flags[5]=n167;
 assign flags[6]=n109;
 assign flags[7]=n110;
 assign flags[8]=n111;
 assign flags[9]=n112;
 assign flags[10]=n20;
 assign flags[11]=n178;
 assign flags[12]=n176;
 assign flags[13]=n68;
endmodule
`default_nettype wire
