# Reporting only: nineteen boards, unchanged clock periods; named serial-mode hold proof and virtual IO are in SDC.
project_open Dorado
create_timing_netlist -model slow
set corners {}
foreach_in_collection op [get_available_operating_conditions] {
 lappend corners [get_operating_conditions_info $op -name]
}
delete_timing_netlist
if {[llength $corners]!=4} {error "Expected four operating conditions"}
foreach name $corners {
 create_timing_netlist
 set_operating_conditions $name
 read_sdc
 update_timing_netlist
 foreach {pattern label} {
  {*|dorado_serial_ContA:b_ContA|*} conta
  {*|dorado_serial_ContB:b_ContB|*} contb
  {*|dorado_serial_ProcH:b_ProcH|*} proch
  {*|dorado_serial_ProcL:b_ProcL|*} procl
  {*|dorado_serial_IFU:b_IFU|*} ifu
  {*|dorado_serial_MemC:b_MemC|*} memc
  {*|dorado_serial_MemD:b_MemD|*} memd
  {*|dorado_serial_MemX:b_MemX|*} memx
  {*|dorado_serial_DskEth:b_DskEth|*} dsketh
  {*|dorado_serial_DispY:b_DispY|*} dispy
  {*|dorado_serial_BaseBd:b_BaseBd|*} basebd
  {*|dorado_serial_MSA:b_msa|*} msa
  {*|dorado_serial_MSA:b_msaOdd|*} msaodd
  {*|dorado_serial_MSA:b_msa1|*} msa1
  {*|dorado_serial_MSA:b_msa1Odd|*} msa1odd
  {*|dorado_serial_MSA:b_msa2|*} msa2
  {*|dorado_serial_MSA:b_msa2Odd|*} msa2odd
  {*|dorado_serial_MSA:b_msa3|*} msa3
  {*|dorado_serial_MSA:b_msa3Odd|*} msa3odd
 } {
  set board [get_registers $pattern]
  set others [remove_from_collection [get_registers *] $board]
  set board_count [get_collection_size $board]
  set other_count [get_collection_size $others]
  if {$board_count==0 || $other_count==0} {error "Missing $label/core register coverage"}
  puts "ADAPTER_CROSSING_CORNER $name $label board=$board_count others=$other_count"
  foreach mode {setup hold} {
   report_timing -$mode -from $board -to $others -npaths 12 -detail full_path -file serial61-$label-out-$mode-$name.rpt
   report_timing -$mode -from $others -to $board -npaths 12 -detail full_path -file serial61-$label-in-$mode-$name.rpt
  }
 }
 delete_timing_netlist
}
project_close
