from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve();project=root/'staged-source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
r=load(project/'disk-pause-integration.json')
assert len(r['source_hashes'])==662 and r['capacity_only']and not r['quartus_permitted']and not r['assembly_permitted']and not r['real_pause_barriers']
for n,h in r['source_hashes'].items():assert sha(project/n)==h,n
for n,h in load(project/'tools/frozen-tools.json').items():assert sha(project/'tools'/n)==h,n
assert sha(project/'tools/fpga/mister/snapshot/build_native_disk_pause.py')==r['builder_sha256']
assert sha(project/'tools/fpga/mister/snapshot/generate_native_disk_pause.py')==r['generator_sha256']
a=load(root/'proof/source-audit.json');b=load(root/'proof/frozen-source-audit.json');assert a==b
assert a['status']=='PASS_NATIVE_DISK_PAUSE_SOURCE_ONLY'and a['original_pin_connections']==2761 and len(a['failure_controls'])==14
assert a['new_wrapper_state_bits']==a['new_top_state_bits']==5 and a['local_status_mask']==7 and a['constraints_unchanged']
c=load(root/'inventory/classification.json');assert c['status']=='PASS_NATIVE_DISK_PAUSE_STATE_ACCESS_PENDING'and len(c['failure_controls'])==18
assert c['totals']=={'PHYSICAL BOARD':1957048,'PRIVATE BOARD':4578,'PRIVATE TRANSPORT':69,'WRAPPER ACCESS PENDING':132611}
assert c['new_required_wrapper_bits']==5 and not c['sequential_exclusions']
assert c['subroutine_review']['required_bits']==120 and c['subroutine_review']['function_scratch_bits']==215
p=load(root/'inventory/provenance.json')
for n,h in p['source_hashes'].items():assert sha(project/n)==h,n
assert p['qsf_sha256']==sha(project/'core/Dorado.qsf')
assert 'UNOPTFLAT'not in(root/'inventory/elaborate.log').read_text()
assert c['xml_sha256']==sha(root/'inventory/native.xml')and c['normalized_xml_sha256']==sha(root/'inventory/native-normalized.xml')
assert load(root/'proof/extracted-source-audit.json')==a
assert load(root/'proof/actual-restaged-hashes.json')==r['source_hashes']
assert load(root/'proof/archive-replay.json')['status']=='PASS'
fresh=load(root/'archive-rebuild-inventory/classification.json');left=dict(c);right=dict(fresh)
for key in ('xml_sha256','normalized_xml_sha256'):left.pop(key);right.pop(key)
assert left==right
assert p==load(root/'archive-rebuild-inventory/provenance.json')
assert fresh['xml_sha256']==sha(root/'archive-rebuild-inventory/native.xml')
assert fresh['normalized_xml_sha256']==sha(root/'archive-rebuild-inventory/native-normalized.xml')
print(json.dumps(dict(status='PASS_NATIVE_DISK_SOURCE_RECEIPT',source_inputs=662,original_pins=2761,native_required_bits=2094306,wrapper_access_pending_bits=132611,source_controls=14,state_controls=18,new_top_status_bits=5,local_status_mask=7,limits='No new Quartus/assembly/RBF/hardware/speed result. Input/video, physical DDR visibility, Main coordinator and complete export/import remain required.'),indent=2))
