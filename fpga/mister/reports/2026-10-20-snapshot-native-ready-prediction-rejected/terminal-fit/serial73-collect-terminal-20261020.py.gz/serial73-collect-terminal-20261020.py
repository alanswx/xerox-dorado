from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile

root=Path('/home/alans/mister/Dorado_Serial73ReadyPrediction_20261020')
pid=2721605
packet=Path('/tmp/dorado-serial73-terminal-20261020.tar.gz')
record=json.loads((root/'ready-prediction-integration.json').read_text())
lines=subprocess.check_output(['ps','-eo','pid=,ppid=,stat=,etime=,args='],text=True).splitlines()
processes=[];builder_live=False
for line in lines:
 fields=line.strip().split(None,4)
 if len(fields)!=5:continue
 n,parent,stat,elapsed,args=fields;n=int(n)
 if n==pid:builder_live=not stat.startswith('Z')
 if stat.startswith('Z'):continue
 if any(t in args for t in('quartus_map','quartus_fit','quartus_sta','quartus_asm','build_native_ready_prediction.py')):
  try:cwd=Path('/proc/'+str(n)+'/cwd').resolve(strict=True)
  except(OSError,RuntimeError):cwd=None
  if n==pid or str(root)in args or(cwd is not None and cwd.is_relative_to(root)):
   processes.append(dict(pid=n,ppid=int(parent),state=stat,elapsed=elapsed,args=args,cwd=str(cwd)))
assert not builder_live and not processes,(builder_live,processes)
changed=[n for n,d in record['source_hashes'].items()if hashlib.sha256((root/n).read_bytes()).hexdigest()!=d]
assert len(record['source_hashes'])==662 and not changed,changed
rbfs=[str(p.relative_to(root))for p in root.rglob('*')if p.is_file()and p.suffix in('.rbf','.sof')]
assert not rbfs,rbfs
driver=(root/'builder.log').read_bytes();(root/'driver.log').write_bytes(driver)
map_summary=(root/'core/output_files/Dorado.map.summary').read_text()
fit_summary=(root/'core/output_files/Dorado.fit.summary').read_text()
assert'Analysis & Synthesis Status : Successful'in map_summary
if'Fitter Status : Successful'in fit_summary:
 assert b'Serial73 terminal; independent capacity/timing review required. No assembly.'in driver
 assert(root/'ready-path.log').is_file(),'run sequential readiness-path STA first'
 status='TERMINAL_DRIVER_COMPLETE'
else:
 assert'Fitter Status : Failed'in fit_summary and b'CalledProcessError'in driver
 status='TERMINAL_FAILED_FIT'
state=dict(status=status,builder_pid=pid,builder_live=False,project_processes=[],assembly_started=False,rbfs=[],
 sta_started=(root/'sta.log').exists(),observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 prepared_inputs=len(record['source_hashes']),prepared_inputs_changed=changed)
if(root/'ready-path.log').is_file():
 state['ready_path_tool_success']='Quartus Prime TimeQuest Timing Analyzer was successful'in(root/'ready-path.log').read_text(errors='replace')
(root/'terminal-state.json').write_text(json.dumps(state,indent=2)+'\n')
selected={root/n for n in record['source_hashes']}
skip={'db','incremental_db','obj','obj_xml','__pycache__'}
for p in root.rglob('*'):
 rel=p.relative_to(root)
 if not p.is_file()or p.is_symlink()or any(x in skip for x in rel.parts):continue
 if p.suffix in('.rpt','.summary','.log','.json','.tcl','.py','.txt','.xml','.pin','.html','.htm'):selected.add(p)
assert not packet.exists(),'existing packet: verify/read it instead of overwriting'
with tarfile.open(packet,'x:gz')as archive:
 for p in sorted(selected):
  assert p.resolve().is_relative_to(root)
  archive.add(p,arcname='serial73/'+str(p.relative_to(root)),recursive=False)
result=dict(project=str(root),builder_pid=pid,members=len(selected),bytes=packet.stat().st_size,
 sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),packet=str(packet),terminal_state=state)
print(json.dumps(result,indent=2))
