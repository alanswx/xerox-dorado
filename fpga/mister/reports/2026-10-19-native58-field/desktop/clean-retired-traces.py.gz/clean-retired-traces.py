from pathlib import Path
import hashlib,json,os,time
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert not any(Path('/proc/%d/exe'%pid).exists()for pid in (23403,23400,25287,25286,27171))
rows=[]
for run,next_run in [('56b','57'),('57','58')]:
 base=Path('/media/fat/games/DoradoRTL/Cedar'+run+'_20261019')
 for suffix,retained in [('disk.jsonl','disk-through-native'+next_run+'-load.jsonl'),('main.log','main-through-native'+next_run+'-loader.log')]:
  a=Path('/tmp/dorado'+run+'-'+suffix);b=base/retained
  assert a.is_file()and b.is_file(),(a,b)
  digest=sha(a);assert digest==sha(b),(a,b)
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:descriptors=list((proc/'fd').iterdir())
   except OSError:continue
   for fd in descriptors:
    try:target=os.readlink(fd)
    except OSError:continue
    assert target!=str(a),('temporary trace still open',proc,fd,target)
  rows.append(dict(temporary=str(a),retained=str(b),bytes=a.stat().st_size,sha256=digest))
for r in rows:Path(r['temporary']).unlink()
print(json.dumps(dict(utc=time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),retained_copies_verified=True,no_open_descriptors=True,bytes_freed=sum(r['bytes']for r in rows),files=rows),indent=2))
