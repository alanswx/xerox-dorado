"""Read-only Native58 deployment/ownership and retired57 barrier evidence."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile,tempfile,time
base=Path('/media/fat/games/DoradoRTL');run=base/'Cedar58_20261019';old=base/'Cedar57_20261019'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert sha('/proc/27199/exe')=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert sha('/proc/27195/exe')=='c59962490772f12d061ec61aa64e6a567144d26d7802a28349a8d9a044eda87e'
assert sha('/media/fat/_Computer/DoradoRTL_Cedar58_20261019/Dorado.rbf')=='eebc0e1fa669ba48ae35ebfe7ba93161afa48eca40247ff79cee9e9853293ae2'
assert not any(Path('/proc/%d/exe'%p).exists()for p in (25287,25286,27171))
maps={n:[s for s in Path('/proc/%d/maps'%p).read_text().splitlines()if '/dev/mem'in s or 'input-probe'in s]for n,p in [('main',27199),('server',27195)]}
assert not any('1ff00000'in s or 'input-probe'in s for s in maps['main'])
assert len(maps['server'])==1 and '1ff00000'in maps['server'][0]
proof=json.loads((old/'preservation.json').read_text());assert sha(proof['path'])==proof['sha256']
paths={'deployment.json':run/'deployment.json','reboot-resume.json':run/'reboot-resume.json','qualification.json':run/'qualification.json','retired57-preservation.json':old/'preservation.json','retired57-desktop-qualification.json':old/'desktop-qualification.json','retired57-normal-boot-qualification.json':old/'normal-boot-qualification.json','retired57-disk-through-load.jsonl':old/'disk-through-native58-load.jsonl','retired57-main-through-load.log':old/'main-through-native58-loader.log','main-through-deployment.log':Path('/tmp/dorado58-main.log'),'disk-through-deployment.jsonl':Path('/tmp/dorado58-disk.jsonl'),'server-through-deployment.log':run/'server.log'}
files={};records=0;last=None
out=run/'deployment-evidence.tar.gz';assert not out.exists(),'Inspect existing collection; never overwrite'
with tempfile.TemporaryDirectory(prefix='evidence-spool-',dir=str(run))as tmp:
 for name,p in paths.items():
  size=p.stat().st_size;left=size;h=hashlib.sha256();copy=Path(tmp)/name
  with p.open('rb')as inp,copy.open('wb')as dest:
   while left:
    b=inp.read(min(left,1048576));assert b,'Source shrank';dest.write(b);h.update(b);left-=len(b)
  files[name]=dict(source=str(p),bytes=size,sha256=h.hexdigest())
  if name=='retired57-disk-through-load.jsonl':
   with copy.open('rb')as inp:
    for raw in inp:
     last=json.loads(raw);records+=1
     assert 'error'not in last['event']and last['event']!='trace_dropped'
   assert last['event']=='barrier_end'
 meta=dict(utc=time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),main_pid=27199,server_pid=27195,maps=maps,retired_processes_absent=True,retired_disk_records=records,old_pack_hash_reverified=proof['sha256'],scope='Read-only startup prefixes and retired57 barrier evidence; no live pack copy, SPI, guest write or atomic snapshot. Native58 Cedar qualification pending.',files=files)
 (Path(tmp)/'deployment-collection.json').write_text(json.dumps(meta,indent=2)+'\n')
 with tarfile.open(out,'w:gz')as tar:
  for p in sorted(Path(tmp).iterdir()):
   if p.suffix in('.jsonl','.log'):
    z=p.with_name(p.name+'.gz')
    with p.open('rb')as src,gzip.open(z,'wb')as dest:
     for b in iter(lambda:src.read(1048576),b''):dest.write(b)
    tar.add(z,arcname=z.name)
   else:tar.add(p,arcname=p.name)
print(json.dumps(dict(archive=str(out),**meta),indent=2),flush=True)
