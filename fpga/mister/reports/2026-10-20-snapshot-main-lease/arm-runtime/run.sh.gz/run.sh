#!/bin/sh
set -eu
cd /tmp/dorado-main-snapshot-20261020
uname -a > platform.txt
sha256sum test > binary.sha256
printf '%s  %s\n' 'c0839c472f26367db4a189a44c21d87de0bec122f80bfa5692d33ebaf7e012d3' test | sha256sum -c - > binary-check.log
chmod 700 test
: > results.tsv
for mode in normal stale-ring eof core-change lost-pause timeout unexpected-pause; do
 if [ "$mode" = normal ]; then
  if timeout 25 ./test > "$mode.log" 2>&1; then result=0; else result=$?; fi
 else
  if timeout 25 ./test "$mode" > "$mode.log" 2>&1; then result=0; else result=$?; fi
 fi
 printf '%s\t%s\n' "$mode" "$result" >> results.tsv
 if [ "$result" != 0 ]; then cat "$mode.log"; exit "$result"; fi
 sed -n '/MAIN SNAPSHOT/p' "$mode.log"
done
printf 'PASS\n' > terminal.txt
