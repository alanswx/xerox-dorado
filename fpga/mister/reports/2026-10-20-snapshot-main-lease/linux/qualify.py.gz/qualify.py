from pathlib import Path
import subprocess,json,hashlib,os,platform,time
root=Path(__file__).resolve().parent;out=root/'results';out.mkdir(exist_ok=False)
feature=root/'source-feature/fpga/mister/main/tests';full=root/'source-full';steps=[]
commands=[('snapshot',['python3',str(feature/'test_ddr_snapshot.py'),'--main-source',str(root/'lifecycle'),'--output',str(out/'snapshot'),'--mutations'],{}),
 ('legacy-lifecycle',['python3',str(feature/'test_ddr_transport.py'),'--main-source',str(root/'lifecycle'),'--emit',str(out/'legacy-lifecycle')],{}),
 ('full-host',['python3',str(full/'fpga/mister/server/qualify_snapshot_pause.py'),'--root',str(full),'--output',str(out/'full-host')],{}),
 ('arm-build',['python3',str(feature/'test_ddr_snapshot.py'),'--main-source',str(root/'lifecycle'),'--output',str(out/'arm'),'--no-run','--static'],{'CC':'arm-linux-gnueabihf-gcc','CXX':'arm-linux-gnueabihf-g++'})]
for label,cmd,extra in commands:
 env={k:v for k,v in os.environ.items()if not k.startswith('DORADO_')};env.update(extra)
 (out/(label+'-command.json')).write_text(json.dumps(dict(command=cmd,environment=extra),indent=2)+'\n')
 with(out/(label+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=180)
 print(label+': rc='+str(r.returncode),flush=True)
 steps.append(dict(step=label,returncode=r.returncode,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()))
 assert not r.returncode,label
(out/'qualification.json').write_text(json.dumps(dict(status='PASS',platform=platform.platform(),steps=steps,arm_binary_sha256=hashlib.sha256((out/'arm/test').read_bytes()).hexdigest(),limits='Host/SPI spies and static ARM build; no physical FPGA service acknowledgement, deployed software or full restore.'),indent=2)+'\n')
