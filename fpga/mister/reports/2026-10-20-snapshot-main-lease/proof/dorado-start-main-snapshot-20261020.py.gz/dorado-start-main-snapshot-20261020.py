from pathlib import Path
import hashlib,json,tarfile,subprocess
packet=Path('/home/alans/mister/dorado-main-snapshot-source-20261020.tar.gz');assert hashlib.sha256(packet.read_bytes()).hexdigest()=='46963a54e452b08fb1b79dcfaf1fd19fd5b04b5ae34f5a1fcb8e3ae6833a30c2'
root=Path('/home/alans/mister/Dorado_MainSnapshotLease_20261020');assert not root.exists(),'Observe original job; no restarts'
root.mkdir()
with tarfile.open(packet)as t:t.extractall(root,filter='data')
with(root/'driver.log').open('w')as log:p=subprocess.Popen(['python3',str(root/'qualify.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid)+'\n');print(json.dumps(dict(pid=p.pid,root=str(root))))
