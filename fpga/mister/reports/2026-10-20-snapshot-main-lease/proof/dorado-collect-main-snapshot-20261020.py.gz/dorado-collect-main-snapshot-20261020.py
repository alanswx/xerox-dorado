from pathlib import Path
import hashlib,json,tarfile,time
root=Path('/home/alans/mister/Dorado_MainSnapshotLease_20261020');pid=2640443;live=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if(proc/'cwd').resolve(strict=True).is_relative_to(root):live.append(int(proc.name))
 except(OSError,RuntimeError):pass
assert not Path('/proc/'+str(pid)).exists()and not live,live
q=json.loads((root/'results/qualification.json').read_text());assert q['status']=='PASS'
(root/'terminal-state.json').write_text(json.dumps(dict(status='TERMINAL',builder_pid=pid,builder_live=False,project_processes=live,observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),indent=2)+'\n')
packet=Path('/home/alans/mister/dorado-main-snapshot-terminal-20261020.tar.gz');assert not packet.exists()
with tarfile.open(packet,'w:gz')as t:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file()or p.is_symlink()or any(x in('obj','obj_xml','db','incremental_db','__pycache__')for x in rel.parts)or p.suffix in('.o','.a','.so','.pyc'):continue
  if p.read_bytes().startswith((b'\x7fELF',b'\xcf\xfa\xed\xfe')):continue
  t.add(p,arcname=str(rel),recursive=False)
print(json.dumps(dict(packet=str(packet),sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),bytes=packet.stat().st_size)))
