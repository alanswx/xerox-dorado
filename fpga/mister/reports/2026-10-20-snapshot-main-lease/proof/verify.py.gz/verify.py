from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
expected={'normal','stale-ring','eof','core-change','lost-pause','timeout','unexpected-pause',
          'frozen_probe','lifecycle_bypass','early_continue','stale_epoch','lost_pause','unsolicited_pause'}
sources=[];summary={}
for label,folder in(('mac',root/'mac-snapshot'),('linux',root/'linux/results/snapshot')):
    q=load(folder/'qualification.json');assert q['status']=='PASS'
    assert {c['case']for c in q['cases']}==expected and len(q['cases'])==13
    for name,digest in q['inputs'].items():assert sha(folder/'executed-inputs'/name)==digest,name
    for case in q['cases']:
        if case.get('expected_failure'):
            log=folder/case['case']/'test.log';assert case['returncode']==23
            assert case['expected_failure']in log.read_text()
        else:
            log=folder/(case['case']+'.log');assert case['returncode']==0 and'MAIN SNAPSHOT'in log.read_text()
        assert sha(log)==case['log_sha256']
    commands=load(folder/'build-commands.json');assert'-DDORADO_TEST_LIFECYCLE'in commands[-1]
    hooks=(folder/'executed-inputs/lifecycle_hooks.inc').read_text()
    assert hooks.count('++lifecycle_mutations;')==4 and hooks.count('dorado_net_barrier(')==4
    text=(folder/'normal.log').read_text();maximum=float(re.search(r'max_call_ms=([0-9.]+)',text)[1]);assert maximum<100
    assert'queued_bytes=12 same_epoch=1 same_connection=1 sole_spi_owner=1'in text
    sources.append(q['inputs']);summary[label]=dict(cases=13,max_poll_call_ms=maximum)
arm_build=load(root/'linux/results/arm/qualification.json');assert arm_build['status']=='BUILD_ONLY'
assert sources[0]==sources[1]==arm_build['inputs']and len(sources[0])==21
for name,digest in arm_build['inputs'].items():assert sha(root/'linux/results/arm/executed-inputs'/name)==digest
full_inputs=[]
for folder in(root/'mac-full',root/'linux/results/full-host'):
    q=load(folder/'qualification.json');assert q['status']=='PASS'and len(q['steps'])==7
    for step in q['steps']:assert step['returncode']==0 and sha(folder/(step['step']+'.log'))==step['log_sha256']
    for name,digest in q['executed_inputs'].items():assert sha(folder/'executed-inputs'/name)==digest
    full_inputs.append(q['executed_inputs'])
assert full_inputs[0]==full_inputs[1]and len(full_inputs[0])==94
receipt=load(root/'linux/results/qualification.json');state=load(root/'linux/terminal-state.json')
assert receipt['status']=='PASS'and state['status']=='TERMINAL'and not state['builder_live']and not state['project_processes']
for step in receipt['steps']:assert step['returncode']==0 and sha(root/'linux/results'/(step['step']+'.log'))==step['log_sha256']
arm=root/'arm-runtime';assert(arm/'terminal.txt').read_text()=='PASS\n'
assert(arm/'binary.sha256').read_text().split()[0]==receipt['arm_binary_sha256']
assert'armv7l'in(arm/'platform.txt').read_text()
assert(arm/'results.tsv').read_text()==''.join(c+'\t0\n'for c in('normal','stale-ring','eof','core-change','lost-pause','timeout','unexpected-pause'))
for mode in('normal','stale-ring','eof','core-change','lost-pause','timeout','unexpected-pause'):
    assert'MAIN SNAPSHOT'in(arm/(mode+'.log')).read_text()
arm_call=float(re.search(r'max_call_ms=([0-9.]+)',(arm/'normal.log').read_text())[1]);assert arm_call<100
summary['arm']=dict(cases=7,max_poll_call_ms=arm_call,binary_sha256=receipt['arm_binary_sha256'])
proof=root/'proof';final=proof/'final-source';q=load(proof/'final-source-proof.json')
for name,digest in q['final_hashes'].items():assert sha(final/name)==digest
compiled=root/'mac-snapshot/executed-inputs'
for name in('dorado_ddr.cpp','dorado_net.cpp','test_ddr_snapshot.cpp','test_ddr_snapshot.py'):
    assert(final/name).read_bytes()==(compiled/name).read_bytes()
assert(final/'test_ddr_transport.cpp').read_bytes()==(compiled/'legacy-original.cpp').read_bytes()
assert(final/'dorado_ddr.h').read_text().replace(q['comment_only_header_addition'],'')==(compiled/'dorado_ddr.h').read_text()
provenance=load(root/'lifecycle-source/provenance.json');assert provenance['status']=='PASS_PATCHED_SOURCE'
for name,digest in provenance['original_inputs'].items():assert sha(proof/'pinned-original'/name)==digest
for name,digest in provenance['patched_inputs'].items():assert sha(root/'lifecycle-source'/name)==digest
assert'DDR MANAGER PASS'in(proof/'dorado-main-snapshot-lifecycle-qualified-v5-20261020.log').read_text()
print(json.dumps(dict(status='PASS',results=summary,identical_feature_inputs=21,identical_full_regression_inputs=94,
    full_regression_gates_per_host=7,limits='Main/daemon lease and SPI-spy lifecycle tests only. No FPGA service barrier, disk/input/video coordination, native snapshot or restore.'),indent=2))
