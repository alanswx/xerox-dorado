from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
q=load(root/'qualified/qualification.json');assert q['status']=='PASS'and q['new_required_wrapper_bits']==2
assert q['geometry']=={'original':{'fields':55,'bits':131816},'candidate':{'fields':57,'bits':131818}}
assert q['sequential_exclusions']==[]and len(q['cases'])==5
expected={'candidate','default_off','early_hps_freeze','unheld_ram_port','unheld_timer'}
assert{c['case']for c in q['cases']}==expected
p=root/'qualified/executed-inputs'
for n,h in q['inputs'].items():assert sha(p/n)==h,n
for c in q['cases']:
 log=root/'qualified'/c['case']/'test.log';assert sha(log)==c['log_sha256'];text=log.read_text()
 if c['expected_failure']:assert c['returncode']==23 and c['expected_failure']in text
 else:
  assert c['returncode']==0 and'PILOT-PACK PASS'in text and'PACK-FAULT PASS'in text
  if c['case']=='candidate':
   assert'DISK SNAPSHOT PASS holds=9 observed_bits=131818 all_track_RAM=1 pending_store=1 partial_CRC=1 inactive_disk=1 restored=0'in text
   assert{text.split('mask=')[1].split()[0]for text in text.splitlines()if text.startswith('DISK PAUSE POINT')}=={'1','2','4','8','16','32','64','128','256'}
unit=load(root/'fourstate/results.json');assert unit['status']=='PASS'and unit['new_required_wrapper_bits']==2 and len(unit['cases'])==7
assert unit['inputs']['medium.sv']==q['inputs']['medium.sv']
for n,h in unit['inputs'].items():assert sha(root/'fourstate/executed-inputs'/n)==h,n
for c in unit['cases']:
 for n,h in c['inputs'].items():assert sha(root/'fourstate'/c['case']/n)==h,n
 text=(root/'fourstate'/c['case']/'test.log').read_text()
 if c['case']=='candidate':assert c['returncode']==0 and'checks=560 admission_cases=256 new_state_bits=2'in text
 else:assert c['returncode']and'FATAL'in text
for n,h in load(root/'proof-source/source-hashes.json').items():assert sha(root/'proof-source'/n)==h,n
assert sha(root/'proof-source/fpga/mister/dorado_pack_hps.sv')==q['inputs']['medium.sv']
assert sha(root/'proof-source/fpga/mister/snapshot/test_disk_snapshot.py')==q['inputs']['test_disk_snapshot.py']
assert sha(root/'proof-source/verilog/verilator/pilot_pack_test.cpp')==q['inputs']['pilot_pack_test.cpp']
assert sha(root/'proof-source/verilog/verilator/tb_pilot_pack.sv')==q['inputs']['tb_pilot_pack.sv']
again=load(root/'archive-rebuild/qualification.json')
assert again['status']=='PASS'and again['inputs']==q['inputs']and again['geometry']==q['geometry']
for n,h in again['inputs'].items():assert sha(root/'archive-rebuild/executed-inputs'/n)==h,n
for c in again['cases']:
 log=root/'archive-rebuild'/c['case']/'test.log';assert sha(log)==c['log_sha256']
 original=next(x for x in q['cases']if x['case']==c['case'])
 assert c==original
fresh=load(root/'archive-rebuild-fourstate/results.json');assert fresh['status']=='PASS'and fresh['inputs']==unit['inputs']
for c in fresh['cases']:
 original=next(x for x in unit['cases']if x['case']==c['case']);assert c==original
 for n,h in c['inputs'].items():assert sha(root/'archive-rebuild-fourstate'/c['case']/n)==h,n
print(json.dumps(dict(status='PASS',disk_bits=131818,original_disk_bits=131816,track_RAM_bits=131072,new_required_bits=2,holds=9,compiled_bad_variants=9,unknown_admission_combinations=256,whole_image_bytes=(p/'pilot.pack').stat().st_size,limits='Actual disk component pause only; not Main coordination, native integration, timing, state access or complete FPGA restore.'),indent=2))
