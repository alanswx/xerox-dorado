module netlist6502_fixture(
input host_clk,ref_clk,advance,freeze,held,request,write,
input [6:0] index,input [17:0] data,input [13:0] pins,
output [17:0] result,output frozen,done,error,
output [1724:0] physical,original_state,next_state,
output [25:0] outputs,original_outputs);
chip_6502_snapshot candidate(.state_host_clk(host_clk),.state_advance(advance),
.state_freeze(freeze),.state_guest_held(held),.state_request(request),.state_write(write),
.state_index(index),.state_data(data),.state_frozen(frozen),.state_done(done),
.state_error(error),.state_result(result),.clk(ref_clk),.phi(pins[0]),.res(pins[1]),.so(pins[2]),.rdy(pins[3]),.nmi(pins[4]),.irq(pins[5]),.dbi(pins[13:6]),.dbo(outputs[7:0]),.rw(outputs[8]),.sync(outputs[9]),.ab(outputs[25:10]));
chip_6502 original(.clk(ref_clk),.phi(pins[0]),.res(pins[1]),.so(pins[2]),.rdy(pins[3]),.nmi(pins[4]),.irq(pins[5]),.dbi(pins[13:6]),.dbo(original_outputs[7:0]),.rw(original_outputs[8]),.sync(original_outputs[9]),.ab(original_outputs[25:10]));
assign physical=candidate.q;assign original_state=original.q;
assign next_state=candidate.no;
endmodule
