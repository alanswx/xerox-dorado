#pragma once
constexpr unsigned INPUTS=106,OUTPUTS=89,WORDS=229,BANKS=14,SMALLS=8,INDEX_COUNT=1048576,STATE_BITS=296554;
struct StateWord {unsigned word,width,offset;};
constexpr StateWord state_words[]={
{0,6,0},
{8192,6,6},
{16384,11,12},
{24576,13,23},
{32768,13,36},
{40960,9,49},
{49152,11,58},
{57344,11,69},
{65536,6,80},
{73728,5,86},
{81920,11,91},
{90112,13,102},
{98304,13,115},
{106496,6,128},
{114688,6,134},
{122880,9,140},
{131072,11,149},
{139264,6,160},
{147456,5,166},
{155648,13,171},
{163840,13,184},
{172032,13,197},
{180224,9,210},
{188416,6,219},
{196608,11,225},
{204800,13,236},
{212992,13,249},
{221184,13,262},
{229376,13,275},
{237568,11,288},
{245760,5,299},
{253952,13,304},
{262144,11,317},
{270336,13,328},
{278528,13,341},
{286720,9,354},
{294912,11,363},
{303104,13,374},
{311296,11,387},
{319488,13,398},
{327680,13,411},
{335872,13,424},
{344064,5,437},
{352256,13,442},
{360448,13,455},
{368640,13,468},
{376832,13,481},
{385024,11,494},
{393216,11,505},
{401408,13,516},
{409600,6,529},
{417792,6,535},
{425984,13,541},
{434176,11,554},
{442368,6,565},
{450560,13,571},
{458752,6,584},
{466944,6,590},
{475136,13,596},
{483328,11,609},
{491520,13,620},
{499712,11,633},
{507904,13,644},
{516096,13,657},
{524288,13,670},
{532480,13,683},
{540672,11,696},
{548864,6,707},
{557056,13,713},
{565248,6,726},
{573440,13,732},
{581632,6,745},
{589824,13,751},
{598016,13,764},
{606208,13,777},
{614400,13,790},
{622592,6,803},
{630784,11,809},
{638976,13,820},
{647168,9,833},
{655360,13,842},
{663552,13,855},
{671744,13,868},
{679936,13,881},
{688128,13,894},
{696320,6,907},
{704512,11,913},
{712704,6,924},
{720896,13,930},
{729088,13,943},
{737280,6,956},
{745472,6,962},
{753664,4,968},
{753665,4,972},
{753666,4,976},
{753667,4,980},
{753668,4,984},
{753669,4,988},
{753670,4,992},
{753671,4,996},
{753672,4,1000},
{753673,4,1004},
{753674,4,1008},
{753675,4,1012},
{753676,4,1016},
{753677,4,1020},
{753678,4,1024},
{753679,4,1028},
{753680,10,1032},
{761856,4,1042},
{761857,4,1046},
{761858,4,1050},
{761859,4,1054},
{761860,4,1058},
{761861,4,1062},
{761862,4,1066},
{761863,4,1070},
{761864,4,1074},
{761865,4,1078},
{761866,4,1082},
{761867,4,1086},
{761868,4,1090},
{761869,4,1094},
{761870,4,1098},
{761871,4,1102},
{761872,10,1106},
{770048,4,1116},
{770049,4,1120},
{770050,4,1124},
{770051,4,1128},
{770052,4,1132},
{770053,4,1136},
{770054,4,1140},
{770055,4,1144},
{770056,4,1148},
{770057,4,1152},
{770058,4,1156},
{770059,4,1160},
{770060,4,1164},
{770061,4,1168},
{770062,4,1172},
{770063,4,1176},
{770064,10,1180},
{778240,4,1190},
{778241,4,1194},
{778242,4,1198},
{778243,4,1202},
{778244,4,1206},
{778245,4,1210},
{778246,4,1214},
{778247,4,1218},
{778248,4,1222},
{778249,4,1226},
{778250,4,1230},
{778251,4,1234},
{778252,4,1238},
{778253,4,1242},
{778254,4,1246},
{778255,4,1250},
{778256,10,1254},
{786432,4,1264},
{786433,4,1268},
{786434,4,1272},
{786435,4,1276},
{786436,4,1280},
{786437,4,1284},
{786438,4,1288},
{786439,4,1292},
{786440,4,1296},
{786441,4,1300},
{786442,4,1304},
{786443,4,1308},
{786444,4,1312},
{786445,4,1316},
{786446,4,1320},
{786447,4,1324},
{786448,10,1328},
{794624,4,1338},
{794625,4,1342},
{794626,4,1346},
{794627,4,1350},
{794628,4,1354},
{794629,4,1358},
{794630,4,1362},
{794631,4,1366},
{794632,4,1370},
{794633,4,1374},
{794634,4,1378},
{794635,4,1382},
{794636,4,1386},
{794637,4,1390},
{794638,4,1394},
{794639,4,1398},
{794640,10,1402},
{802816,4,1412},
{802817,4,1416},
{802818,4,1420},
{802819,4,1424},
{802820,4,1428},
{802821,4,1432},
{802822,4,1436},
{802823,4,1440},
{802824,4,1444},
{802825,4,1448},
{802826,4,1452},
{802827,4,1456},
{802828,4,1460},
{802829,4,1464},
{802830,4,1468},
{802831,4,1472},
{802832,10,1476},
{811008,4,1486},
{811009,4,1490},
{811010,4,1494},
{811011,4,1498},
{811012,4,1502},
{811013,4,1506},
{811014,4,1510},
{811015,4,1514},
{811016,4,1518},
{811017,4,1522},
{811018,4,1526},
{811019,4,1530},
{811020,4,1534},
{811021,4,1538},
{811022,4,1542},
{811023,4,1546},
{811024,10,1550},
{933888,10,1560}};
constexpr unsigned BANK_WIDTHS[]={6,3,6,3,6,3,9,9,3,6,3,6,3,6};
constexpr unsigned BANK_PACKAGES[]={100,101,102,103,104,105,106,107,108,109,110,111,112,113};
constexpr unsigned BANK_OFFSETS[]={0,6,9,15,18,24,27,36,45,48,54,57,63,66};
constexpr unsigned PIN_BMux_00=0;
constexpr unsigned PIN_BMux_01=1;
constexpr unsigned PIN_BMux_02=2;
constexpr unsigned PIN_BMux_03=3;
constexpr unsigned PIN_BMux_04=4;
constexpr unsigned PIN_BMux_05=5;
constexpr unsigned PIN_BMux_06=6;
constexpr unsigned PIN_BMux_07=7;
constexpr unsigned PIN_BMux_08=8;
constexpr unsigned PIN_BMux_09=9;
constexpr unsigned PIN_BMux_10=10;
constexpr unsigned PIN_BMux_11=11;
constexpr unsigned PIN_BMux_12=12;
constexpr unsigned PIN_BMux_13=13;
constexpr unsigned PIN_BMux_14=14;
constexpr unsigned PIN_BMux_15=15;
constexpr unsigned PIN_BMux_16=16;
constexpr unsigned PIN_BMux_17=17;
constexpr unsigned PIN_CLK_md_p_=18;
constexpr unsigned PIN_DMuxClk=19;
constexpr unsigned PIN_DMuxData=20;
constexpr unsigned PIN_Dad_00=21;
constexpr unsigned PIN_Dad_01=22;
constexpr unsigned PIN_Dbuf_u__p_=23;
constexpr unsigned PIN_ECFault=24;
constexpr unsigned PIN_EcIn_0=25;
constexpr unsigned PIN_EcIn_1=26;
constexpr unsigned PIN_EnableFG_p_=27;
constexpr unsigned PIN_ErrorsFromEc2=28;
constexpr unsigned PIN_FastD_u_Dbuf=29;
constexpr unsigned PIN_Fin_00=30;
constexpr unsigned PIN_Fin_01=31;
constexpr unsigned PIN_Fin_02=32;
constexpr unsigned PIN_Fin_03=33;
constexpr unsigned PIN_Fin_04=34;
constexpr unsigned PIN_Fin_05=35;
constexpr unsigned PIN_Fin_06=36;
constexpr unsigned PIN_Fin_07=37;
constexpr unsigned PIN_Fin_08=38;
constexpr unsigned PIN_Fin_09=39;
constexpr unsigned PIN_Fin_10=40;
constexpr unsigned PIN_Fin_11=41;
constexpr unsigned PIN_Fin_12=42;
constexpr unsigned PIN_Fin_13=43;
constexpr unsigned PIN_Fin_14=44;
constexpr unsigned PIN_Fin_15=45;
constexpr unsigned PIN_Fin_16=46;
constexpr unsigned PIN_Fin_17=47;
constexpr unsigned PIN_Fout_00=48;
constexpr unsigned PIN_GDv_p_=49;
constexpr unsigned PIN_GLd_p_=50;
constexpr unsigned PIN_MakeD_u_CD=51;
constexpr unsigned PIN_MakeD_u_Dbuf=52;
constexpr unsigned PIN_MakeF_u_D=53;
constexpr unsigned PIN_MakeFout_u_D=54;
constexpr unsigned PIN_MakeMDM_u_D_p_=55;
constexpr unsigned PIN_MakeMD_u_D_p_=56;
constexpr unsigned PIN_MakeSout_u_D=57;
constexpr unsigned PIN_McrD_u__p_=58;
constexpr unsigned PIN_MemClkEnable_p_a=59;
constexpr unsigned PIN_MemError=60;
constexpr unsigned PIN_MemSH=61;
constexpr unsigned PIN_PcFG_15=62;
constexpr unsigned PIN_Sin_00=63;
constexpr unsigned PIN_Sin_01=64;
constexpr unsigned PIN_Sin_02=65;
constexpr unsigned PIN_Sin_03=66;
constexpr unsigned PIN_Sin_04=67;
constexpr unsigned PIN_Sin_05=68;
constexpr unsigned PIN_Sin_06=69;
constexpr unsigned PIN_Sin_07=70;
constexpr unsigned PIN_Sin_08=71;
constexpr unsigned PIN_Sin_09=72;
constexpr unsigned PIN_Sin_10=73;
constexpr unsigned PIN_Sin_11=74;
constexpr unsigned PIN_Sin_12=75;
constexpr unsigned PIN_Sin_13=76;
constexpr unsigned PIN_Sin_14=77;
constexpr unsigned PIN_Sin_15=78;
constexpr unsigned PIN_StartEcChk_p_=79;
constexpr unsigned PIN_StartEcGen_p_=80;
constexpr unsigned PIN_TempRef=81;
constexpr unsigned PIN_Transport_p_=82;
constexpr unsigned PIN__u_Dbuf=83;
constexpr unsigned PIN__u_Pipe4=84;
constexpr unsigned PIN_dDad_02=85;
constexpr unsigned PIN_dDad_03=86;
constexpr unsigned PIN_dDad_04=87;
constexpr unsigned PIN_dDad_05=88;
constexpr unsigned PIN_dDad_06=89;
constexpr unsigned PIN_dDad_07=90;
constexpr unsigned PIN_dDad_08=91;
constexpr unsigned PIN_dDad_09=92;
constexpr unsigned PIN_dDad_10=93;
constexpr unsigned PIN_dDad_11=94;
constexpr unsigned PIN_dDad_12=95;
constexpr unsigned PIN_dDad_13=96;
constexpr unsigned PIN_dMD_00=97;
constexpr unsigned PIN_dMDMad_0_p_=98;
constexpr unsigned PIN_dMDMad_1_p_=99;
constexpr unsigned PIN_dMDMad_2_p_=100;
constexpr unsigned PIN_dMDMad_3_p_=101;
constexpr unsigned PIN_dPipe34Ad_0=102;
constexpr unsigned PIN_dPipe34Ad_1=103;
constexpr unsigned PIN_dPipe34Ad_2=104;
constexpr unsigned PIN_dPipe34Ad_3=105;
