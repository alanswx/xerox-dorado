module snapshot_fit(
 input wire host_clk,advance,hold,write,input wire [13:0] pins,
 input wire [17:0] data,output reg [17:0] result,output reg [6:0] outputs);
 // Matched negative-edge launch/positive-edge capture:10ns into cell,20ns output paths.
 reg [34:0] launch;
 always @(negedge host_clk) launch<={advance,hold,write,pins,data};
 wire step_r,hold_r,write_r;wire [13:0] pins_r;wire [17:0] data_r;
 assign {step_r,hold_r,write_r,pins_r,data_r}=launch;
 wire [17:0] result_w;wire [6:0] outputs_w;
 always @(posedge host_clk)begin result<=result_w;outputs<=outputs_w;end
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_F100181_snapshot cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_hold(hold_r),
 .state_write(write_r),.state_data(data_r),.state_result(result_w),
`else
 assign result_w=18'b0;
 cell_F100181 cell_inst(
`endif
 .sys_clk(host_clk),.p1(pins_r[0]),.p24(pins_r[1]),.p23(pins_r[2]),.p22(pins_r[3]),
 .p12(pins_r[4]),.p13(pins_r[5]),.p14(pins_r[6]),.p15(pins_r[7]),
 .p16(pins_r[8]),.p17(pins_r[9]),.p20(pins_r[10]),.p21(pins_r[11]),
 .p11(pins_r[12]),.p19(pins_r[13]),.p6(1'b0),.p7(1'b0),.p18(1'b0),
 .p2(outputs_w[0]),.p3(outputs_w[1]),.p4(outputs_w[2]),.p5(outputs_w[3]),
 .p8(outputs_w[4]),.p9(outputs_w[5]),.p10(outputs_w[6]));
endmodule
