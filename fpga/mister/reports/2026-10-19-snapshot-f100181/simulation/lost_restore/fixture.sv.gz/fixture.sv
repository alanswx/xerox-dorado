module f100181_fixture(
 input wire host_clk,ref_clk,advance,hold,write,input wire [13:0] pins,
 input wire [17:0] data,output wire [17:0] result,
 output wire [6:0] outputs,original_outputs,output wire [3:0] original_state);
 cell_F100181_snapshot candidate(.state_host_clk(host_clk),.state_advance(advance),
 .state_hold(hold),.state_write(write),.state_data(data),.state_result(result),
 .sys_clk(ref_clk),.p1(pins[0]),.p24(pins[1]),.p23(pins[2]),.p22(pins[3]),
 .p12(pins[4]),.p13(pins[5]),.p14(pins[6]),.p15(pins[7]),
 .p16(pins[8]),.p17(pins[9]),.p20(pins[10]),.p21(pins[11]),
 .p11(pins[12]),.p19(pins[13]),.p6(1'b0),.p7(1'b0),.p18(1'b0),
 .p2(outputs[0]),.p3(outputs[1]),.p4(outputs[2]),.p5(outputs[3]),
 .p8(outputs[4]),.p9(outputs[5]),.p10(outputs[6]));
 cell_F100181 original(.sys_clk(ref_clk),.p1(pins[0]),.p24(pins[1]),.p23(pins[2]),.p22(pins[3]),
 .p12(pins[4]),.p13(pins[5]),.p14(pins[6]),.p15(pins[7]),
 .p16(pins[8]),.p17(pins[9]),.p20(pins[10]),.p21(pins[11]),
 .p11(pins[12]),.p19(pins[13]),.p6(1'b0),.p7(1'b0),.p18(1'b0),
 .p2(original_outputs[0]),.p3(original_outputs[1]),.p4(original_outputs[2]),.p5(original_outputs[3]),
 .p8(original_outputs[4]),.p9(original_outputs[5]),.p10(original_outputs[6]));
 assign original_state=original.q;
endmodule
