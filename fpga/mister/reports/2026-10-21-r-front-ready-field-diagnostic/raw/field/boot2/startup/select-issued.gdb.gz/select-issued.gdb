set pagination off
set confirm off
set language c++
python
from pathlib import Path
import hashlib
assert gdb.selected_inferior().pid==16808
assert hashlib.sha256(Path('/proc/16808/exe').read_bytes()).hexdigest()=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert 'user_io_status_set' in gdb.execute('info symbol 0x9e98c',to_string=True)
end
tbreak input_poll
continue
call ((void(*)(const char*,unsigned int,int))0x9e98d)("[10:9]",1,0)
detach
