from pathlib import Path
import json,os,signal,shutil,subprocess,time
from deploy_mc1668_native import MAIN,SERVER,SEED,sha,matches,stopped
from deploy_r_front_ready_native import RBF,no_open
base=Path('/media/fat/games/DoradoRTL');old=base/'CedarRFrontReady_20261021';new=base/'CedarRFrontReady_Boot2_20261021';core=Path('/media/fat/_Computer/DoradoRTL_CedarRFrontReady_Boot2_20261021')
j=json.loads((new/'preparation.json').read_text());assert j['phase']=='NEW_TEMPORARY_MAIN'and j['temporary_main']==16705
assert not Path('/proc/15708/exe').exists()and not Path('/proc/16705/exe').exists()
assert sha('/proc/16708/exe')=='adeae62b09e63537fc33fbebbee5145e66fbecdd950ed6b9f856a441147556ff'
assert '/dev/mem'not in Path('/proc/15703/maps').read_text()and sha('/proc/15703/exe')==SERVER
assert sha(core/'Dorado.rbf')==RBF
os.kill(16708,signal.SIGTERM);stopped(16708)
for p in [old/'cedar-work.pack',new/'cedar-work.pack']:no_open(p)
assert sha(new/'cedar-work.pack')==SEED
c=json.loads((old/'reboot-resume.json').read_text());trace=Path(c['main']['env']['DORADO_DISK_TRACE']);log=Path(c['main_stdout'])
with trace.open('rb')as f:f.seek(j['old_trace_offset']);window=[json.loads(x)for x in f]
assert window[-1]['event']=='barrier_end'and sum(x['event']=='barrier_end'for x in window)>=2
assert not [x for x in window if 'error'in x['event']or x.get('result',0)<0]
for p in [trace,log]:no_open(p)
tc=old/'disk-through-rfront-ready-boot2-load.jsonl';lc=old/'main-through-rfront-ready-boot2-load.log'
shutil.copyfile(trace,tc);shutil.copyfile(log,lc);assert sha(trace)==sha(tc)and sha(log)==sha(lc)
records=[json.loads(x)for x in tc.read_bytes().splitlines()];gaps=[x for x in records if x['event']=='trace_dropped']
proof=dict(path=str(old/'cedar-work.pack'),bytes=(old/'cedar-work.pack').stat().st_size,sha256=sha(old/'cedar-work.pack'),disk_trace=str(tc),disk_trace_sha256=sha(tc),disk_records=len(records),historical_trace_gaps=gaps,transition_trace_gaps=[x for x in window if x['event']=='trace_dropped'],barriers=sum(x['event']=='barrier_end'for x in window),boundary='Normal loader closed first custom Main; wrongly selected stock Main then stopped normally; no pack FDs',guest='First boot Cedar microcode/Mesa trap loop, no desktop or clean shutdown; original seed unchanged after close')
(old/'preservation-before-rfront-ready-boot2.json').write_text(json.dumps(proof,indent=2)+'\n')
assert proof['sha256']==SEED and not gaps
mgl=core/'CedarRFrontReadyBoot2.mgl';s=mgl.read_text();assert 'DoradoCedarRFrontReady_Boot2_20261021'in s
mgl.write_text(s.replace('DoradoCedarRFrontReady_Boot2_20261021','DoradoRFrontB2_20261021'))
ini=Path('/media/fat/MiSTer.ini');shutil.copy2(ini,new/'MiSTer.ini.before-name-fix');s=ini.read_text();assert s.count('[DoradoCedarRFrontReady_Boot2_20261021]')==1
ini.write_text(s.replace('[DoradoCedarRFrontReady_Boot2_20261021]','[DoradoRFrontB2_20261021]'))
j.update(phase='CLOSED_FIRST_BOOT_PRESERVED_SHORT_NAME_FIXED',preservation=proof,unexpected_stock_main=16708,stock_main_sha256='adeae62b09e63537fc33fbebbee5145e66fbecdd950ed6b9f856a441147556ff',launcher='DoradoRFrontB2_20261021')
(new/'preparation.json').write_text(json.dumps(j,indent=2)+'\n')
os.kill(15703,signal.SIGTERM);stopped(15703);assert not Path('/tmp/dorado-net.sock.control').exists()
with(new/'server.log').open('ab')as f:sp=subprocess.Popen(c['server']['argv'],cwd=c['server']['cwd'],env=dict(os.environ,**c['server']['env']),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
time.sleep(.3);assert sp.poll()is None
argv=[c['main']['exe'],str(core/'Dorado.rbf'),str(mgl)];ml=Path('/tmp/dorado-rfront-ready-boot2-main.log');dl=Path('/tmp/dorado-rfront-ready-boot2-disk.jsonl');assert not ml.exists()and not dl.exists()
c['main']['argv']=argv;c['main']['env']['DORADO_DISK_TRACE']=str(dl);c['main_stdout']=str(ml)
with ml.open('ab')as f:mp=subprocess.Popen(argv,cwd=c['main']['cwd'],env=dict(os.environ,**c['main']['env']),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(new/'reboot-resume.json').write_text(json.dumps(c,indent=2)+'\n')
d=dict(old_main=15708,old_server=15703,temporary_main=16705,unexpected_stock_main=16708,main_pid=mp.pid,server_pid=sp.pid,main_sha256=MAIN,server_sha256=SERVER,rbf_sha256=RBF,seed_sha256=SEED,preserved_old_volume=proof,main_log=str(ml),disk_trace=str(dl),phase='Same RBF loaded through normal Main loader; original firmware repeat pending;50MHz/SYSPER4',resume_driver_sha256=sha(Path(__file__)))
(new/'deployment.json').write_text(json.dumps(d,indent=2)+'\n')
j.update(phase='SHORT_NAME_MAIN_SERVER_STARTED',main_pid=mp.pid,server_pid=sp.pid);(new/'preparation.json').write_text(json.dumps(j,indent=2)+'\n')
for _ in range(300):
 assert mp.poll()is None and sp.poll()is None
 text=ml.read_text()
 if 'Dorado disk: image cache ready,'in text and 'Dorado DDR: direct frame queues active,'in text:break
 time.sleep(.1)
else:raise RuntimeError('Inspect same processes; cache/grant not ready')
assert sha('/proc/%d/exe'%mp.pid)==MAIN and '/dev/mem'in Path('/proc/%d/maps'%sp.pid).read_text()
j['phase']='CACHE_AND_DDR_READY_FIRMWARE_PENDING';(new/'preparation.json').write_text(json.dumps(j,indent=2)+'\n')
print(json.dumps(d,indent=2),flush=True)
