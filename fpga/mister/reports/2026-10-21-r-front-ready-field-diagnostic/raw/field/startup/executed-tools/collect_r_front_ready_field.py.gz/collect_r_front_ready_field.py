#!/usr/bin/env python3
"""Collect bounded live prefixes from the Ready/front test on MiSTer14.

Run on MiSTer14. This reads files and process identities only, does not copy
an active disk pack, and does not claim a coherent machine snapshot or a
completed boot. Prefixes and their original hashes are retained losslessly.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import time

from deploy_mc1668_native import MAIN, SERVER, sha
from deploy_r_front_ready_native import RBF


def collect(out):
    base=Path('/media/fat/games/DoradoRTL/CedarRFrontReady_20261021')
    deployment=json.loads((base/'deployment.json').read_text())
    assert deployment['main_pid']==15708 and deployment['server_pid']==15703
    assert sha('/proc/15708/exe')==MAIN and sha('/proc/15703/exe')==SERVER
    core=Path('/media/fat/_Computer/DoradoRTL_CedarRFrontReady_20261021/Dorado.rbf')
    assert sha(core)==RBF
    assert '/dev/mem' in Path('/proc/15703/maps').read_text()
    out.mkdir(parents=True,exist_ok=False)
    record=dict(scope=__doc__,started=time.time(),main_pid=15708,server_pid=15703,
                main_sha256=MAIN,server_sha256=SERVER,rbf_sha256=RBF,
                host_clock_hz=50000000,sysper=4,state_admin='INACTIVE',files=[])
    sources=[base/n for n in ('deployment.json','preparation.json','reboot-resume.json')]
    sources += [Path('/tmp/dorado-rfront-ready-main.log'),
                Path('/tmp/dorado-rfront-ready-disk.jsonl'),base/'server.log',
                base.parent/'CedarMC1668_20261020/preservation-before-rfront-ready.json']
    for source in sources:
        with source.open('rb') as stream:
            limit=source.stat().st_size
            data=stream.read(limit)
        assert len(data)==limit
        # Do not manufacture an incomplete final record in a live text prefix.
        if not data.endswith(b'\n'):
            data=data[:data.rfind(b'\n')+1]
        target=out/(source.name+'.gz')
        target.write_bytes(gzip.compress(data,mtime=0))
        assert gzip.decompress(target.read_bytes())==data
        record['files'].append(dict(source=str(source),file=target.name,
                                    prefix_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
                                    stored_sha256=sha(target)))
    record.update(finished=time.time(),desktop_qualified=False,hardware_speedup_claimed=False,
                  note='Live prefixes, not closed logs. Disk file excludes still-buffered RAM records.')
    (out/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    collect(p.parse_args().output)
