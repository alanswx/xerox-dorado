set pagination off
set confirm off
set language c++
python
from pathlib import Path
import hashlib
assert gdb.selected_inferior().pid==15708
assert hashlib.sha256(Path('/proc/15708/exe').read_bytes()).hexdigest()=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert 'user_io_status_set' in gdb.execute('info symbol 0x9e98c',to_string=True)
end
tbreak input_poll
continue
call ((void(*)(const char*,unsigned int,int))0x9e98d)("[10:9]",0,0)
python
import json,collections
samples=[]
for k in range(128):
 words=[]
 try:
  words.append(int(gdb.parse_and_eval('((unsigned short(*)(unsigned short))0x9ca91)(0x70)')))
  for i in range(12):words.append(int(gdb.parse_and_eval('((unsigned short(*)(unsigned short))0x701a5)(0)')))
 finally:gdb.execute('call ((void(*)())0x9c8b5)()')
 assert words[0]==0xd074,words
 samples.append(words)
print('NORMAL_CPU_SAMPLES '+json.dumps(samples))
end
call ((void(*)(const char*,unsigned int,int))0x9e98d)("[10:9]",1,0)
detach
