set pagination off
set confirm off
set language c++
python
from pathlib import Path
import hashlib
assert gdb.selected_inferior().pid==15708
assert hashlib.sha256(Path('/proc/15708/exe').read_bytes()).hexdigest()=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert 'user_io_status_set' in gdb.execute('info symbol 0x9e98c',to_string=True)
end
python
import gzip,json,struct,time,collections
inf=gdb.selected_inferior()
assert 'trace()::t' in gdb.execute('info symbol 0x1553d8',to_string=True)
ptr=struct.unpack('<I',bytes(inf.read_memory(0x1553d8,4)))[0]
blob=bytes(inf.read_memory(ptr,0x60030))
head,count=struct.unpack_from('<II',blob,0x60018);dropped=struct.unpack_from('<Q',blob,0x60020)[0]
assert head<8192 and count<=8192,(head,count)
strings={};events=[]
for k in range(count):
 off=((head+k)%8192)*48
 ns,offset,size,duration,result,kind=struct.unpack_from('<QQQQqI',blob,off)
 if kind not in strings:strings[kind]=bytes(inf.read_memory(kind,48)).split(bytes([0]),1)[0].decode('ascii')
 events.append(dict(ns=ns,event=strings[kind],offset=offset,bytes=size,result=result,duration_ns=duration))
r=dict(main_pid=15708,main_sha256='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60',time=time.time(),source='Passive copy of Main trace ring; no flush, no guest or cache state writes',head=head,count=count,previously_dropped=dropped,layout='Exact Main21e6 record disassembly:48-byte event; head/count at393240/393244; dropped at393248',events=events)
with gzip.open('/tmp/dorado-rfront-ready-trace-ram.json.gz','wt')as f:json.dump(r,f,indent=2)
print('PASSIVE_DISK_TRACE '+json.dumps(dict(count=count,previously_dropped=dropped,events=dict(collections.Counter(e['event']for e in events)))))
end
detach
