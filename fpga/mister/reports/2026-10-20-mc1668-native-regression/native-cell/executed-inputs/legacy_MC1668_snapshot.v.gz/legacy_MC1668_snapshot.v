// cell_MC1668 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 12 package position(s) across the sixteen boards.
//
// Dual clocked flip-flop with asynchronous Set and Reset (MECL III). EclDict
// names every pin -- S, R, C, D, Q, Q' for each half -- so the function is
// unambiguous without a datasheet, and there is no OR/NOR polarity question.
//
// MECL S/R are ACTIVE HIGH and dominate the clock, as cell_MC10231 records
// for the 10K equivalent; the two parts have the same shape and the same
// treatment here.
//
// FPGA: on `sys_clk` with C as an enable, like every other clocked cell --
// see cell_MC10176 for why.

`default_nettype none

module cell_MC1668_snapshot (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,
    output wire [17:0] state_result,
    input  wire sys_clk,
    output wire p2,  // Q
    output wire p3,  // Q'
    input  wire p4,  // R
    input  wire p5,  // S
    input  wire p6,  // D
    input  wire p7,  // C
    input  wire p9,  // C
    input  wire p11,  // D
    input  wire p12,  // S
    input  wire p13,  // R
    output wire p14,  // Q'
    output wire p15// Q
);

  reg cka_d, ckb_d;
  
  wire cka_en = p7 & ~cka_d;
  wire ckb_en = p9 & ~ckb_d;

  reg qa, qb;
  
  

  assign p2 =  qa;  assign p3  = ~qa;
  assign p15 = qb;  assign p14 = ~qb;

  assign state_result={14'b0,{ckb_d,cka_d,qb,qa}};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {ckb_d,cka_d,qb,qa}<=state_data[3:0];
    end else if (state_advance) begin
begin cka_d <= p7; ckb_d <= p9; end
begin
    if (p5)          qa <= 1'b1;      // S
    else if (p4)     qa <= 1'b0;      // R
    else if (cka_en) qa <= p6;        // D
  end
begin
    if (p12)         qb <= 1'b1;
    else if (p13)    qb <= 1'b0;
    else if (ckb_en) qb <= p11;
  end
    end
  end
endmodule

`default_nettype wire
