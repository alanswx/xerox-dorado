// cell_MC1668 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 12 package position(s) across the sixteen boards.
//
// Dual HIGH-transparent clocked latch (MECL III). Motorola's 1978 MECL data
// book, PDF p235 / printed4-30, gives C=1: Q follows D, ignoring S/R;
// C=0: set/reset or hold. PARC's timing dictionary independently marks the
// data arcs as HIGH-transparent. Treating this part as an edge-triggered FF
// lost updates within the R read/bypass window.
//
// S/R are active high while CLOSED. S=R=1,C=0 is unspecified by the sheet;
// preserve deterministic set priority for that undefined input combination.
//
// FPGA: sample on sys_clk throughout the high level, as the other latch cells
// do. This does not qualify the surrounding board's fabric-sampling cadence.

// Native59 adapter: state administration remains inactive in this candidate.
// Compatibility clock-history slots are retained but never select data capture.
`default_nettype none

module cell_MC1668_snapshot (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,
    output wire [17:0] state_result,
    input  wire sys_clk,
    output wire p2,  // Q
    output wire p3,  // Q'
    input  wire p4,  // R
    input  wire p5,  // S
    input  wire p6,  // D
    input  wire p7,  // C
    input  wire p9,  // C
    input  wire p11,  // D
    input  wire p12,  // S
    input  wire p13,  // R
    output wire p14,  // Q'
    output wire p15// Q
);

  reg cka_d, ckb_d;
  
  wire cka_en = p7 & ~cka_d;
  wire ckb_en = p9 & ~ckb_d;

  reg qa, qb;
  
  

  assign p2 =  qa;  assign p3  = ~qa;
  assign p15 = qb;  assign p14 = ~qb;

  assign state_result={14'b0,{ckb_d,cka_d,qb,qa}};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {ckb_d,cka_d,qb,qa}<=state_data[3:0];
    end else if (state_advance) begin
      cka_d<=p7; ckb_d<=p9; // inactive-interface compatibility only

   begin
    if (p7)          qa <= p6;        // transparent while C high
    else if (p5)     qa <= 1'b1;      // S while closed
    else if (p4)     qa <= 1'b0;      // R
  end
   begin
    if (p7)          qb <= p11;
    else if (p12)    qb <= 1'b1;
    else if (p13)    qb <= 1'b0;
  end


    end
  end
endmodule

`default_nettype wire
