"""Read-only qualified desktop evidence; never copy the live disk pack."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile

base=Path('/media/fat/games/DoradoRTL/Cedar56b_20261019')
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(Path('/proc/23403/exe').read_bytes())=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert sha(Path('/proc/23400/exe').read_bytes())=='c59962490772f12d061ec61aa64e6a567144d26d7802a28349a8d9a044eda87e'
assert sha(Path('/media/fat/_Computer/DoradoRTL_Cedar56b_20261019/Dorado.rbf').read_bytes())=='0bbe092f1e10476dc3cc465418836f94a3e06c04ce5f08530c055fbfc52dd7cf'
assert not Path('/proc/23698/exe').exists(),'completed loader observer reappeared'
files={name:path.read_bytes()for name,path in {
    'main-through-desktop.log':Path('/tmp/dorado56b-main.log'),
    'disk-through-desktop.jsonl':Path('/tmp/dorado56b-disk.jsonl'),
    'server-through-desktop.log':base/'server.log',
    'desktop-qualification.json':base/'desktop-qualification.json',
}.items()}
raw=files['disk-through-desktop.jsonl'];lines=raw.splitlines()
if not raw.endswith(b'\n'):lines=lines[:-1]
rows=[json.loads(x)for x in lines]
assert rows and not any('error'in r['event']or r['event']=='trace_dropped'for r in rows)
metadata=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    main_pid=23403,server_pid=23400,completed_disk_trace_records=len(rows),disk_errors_or_trace_loss=False,
    scope='Read-only live logs after observed desktop/input; no guest Boot boundary claimed; no host disk barrier, live pack copy, full snapshot or cold persistence claim',
    files={name:dict(bytes=len(data),sha256=sha(data))for name,data in files.items()})
files['desktop-collection.json']=(json.dumps(metadata,indent=2)+'\n').encode()
assert not Path('/tmp/dorado56b-desktop-collection.tar.gz').exists(),'inspect existing collection; do not overwrite'
with tarfile.open('/tmp/dorado56b-desktop-collection.tar.gz','w:gz')as tar:
    for name,data in files.items():
        if name.endswith(('.log','.jsonl')):data=gzip.compress(data,mtime=0);name+='.gz'
        info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(json.dumps(metadata,indent=2),flush=True)
