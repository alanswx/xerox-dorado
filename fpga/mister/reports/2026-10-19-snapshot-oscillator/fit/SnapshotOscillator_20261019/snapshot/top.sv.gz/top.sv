module snapshot_fit(
 input wire host_clk,advance,freeze,held,request,write,
 input wire [1:0] index,input wire [17:0] data,
 output reg [161:0] result,output reg [8:0] outputs,frozen,done,error);
 reg [24:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,request,write,index,data};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;wire [1:0] index_r;wire [17:0] data_r;
 assign {step_r,freeze_r,held_r,request_r,write_r,index_r,data_r}=launch;
 wire [161:0] result_w;wire [8:0] outputs_w,frozen_w,done_w,error_w;
 always @(posedge host_clk){result,outputs,frozen,done,error}<={result_w,outputs_w,frozen_w,done_w,error_w};
 genvar i;
 generate for(i=0;i<9;i=i+1)begin:cases
 localparam integer SP=i/3==0?2:i/3==1?4:16;
 localparam integer FREQ=i%3==0?10000:i%3==1?20000:50000;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_K1115A_snapshot #(.FREQ_KHZ(FREQ),.SYSPER(SP)) cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w[i]),.state_done(done_w[i]),.state_error(error_w[i]),.state_result(result_w[18*i+:18]),
`else
 assign {frozen_w[i],done_w[i],error_w[i],result_w[18*i+:18]}=21'b0;
 cell_K1115A #(.FREQ_KHZ(FREQ),.SYSPER(SP)) cell_inst(
`endif
 .sys_clk(host_clk),.p8(outputs_w[i]),.p7(1'b0),.p14(1'b1));
 end endgenerate
endmodule
