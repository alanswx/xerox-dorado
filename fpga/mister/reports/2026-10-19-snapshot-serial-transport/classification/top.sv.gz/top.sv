module snapshot_fit(input wire host_clk,input wire [279:0] pins,output reg [167:0] outputs);
 reg [279:0] input_stage,launch;
 always @(negedge host_clk)input_stage<=pins;
 always @(posedge host_clk)launch<=input_stage;
 wire system_reset,transport_reset,local_held;
 wire [4:0] services_held;
 wire [10:0] board_frozen,board_done,board_error,board_hold_required,board_fault;
 wire [197:0] board_result;wire [18:0] master;
 assign {system_reset,transport_reset,local_held,services_held,board_frozen,board_done,board_error,board_hold_required,board_fault,board_result,master}=launch;
 wire [35:0] bus;assign bus[35:33]=master[18:16];assign bus[31:16]=master[15:0];
 wire hold,command_hold,scan_abort,hold_update,hold_value,control_error;
 wire request,write,ready,done,fault,busy,complete;wire [3:0] board;wire [23:0] index;
 wire [17:0] data,result;wire [2:0] error;wire [10:0] board_request;
 wire [31:0] txn_sequence,control_errors;
 always @(posedge host_clk)outputs<={bus[32],bus[15:0],hold,command_hold,scan_abort,ready,board_request,busy,complete,txn_sequence,control_errors,fault,done,error,result,write,board,index,data};
 dorado_board_state_uio_serial #(.SCHEMA_ID(64'h79c5a16e42d38b07)) uio(
 .clk(host_clk),.system_reset(system_reset),.transport_reset(transport_reset),.bus(bus),
 .hold_update(hold_update),.hold_value(hold_value),.hold(hold),.command_hold(command_hold),
 .local_held(local_held),.services_held(services_held),.control_error(control_error),.board_frozen(board_frozen),
 .request(request),.write(write),.board(board),.index(index),.data(data),
 .ready(ready),.done(done),.error(error),.result(result),.fault(fault),
 .busy(busy),.complete(complete),.txn_sequence(txn_sequence),.control_errors(control_errors));
 dorado_board_state_fabric_serial fabric(
 .clk(host_clk),.system_reset(system_reset),.transport_reset(transport_reset),
 .hold_update(hold_update),.hold_value(hold_value),.local_held(local_held),.services_held(services_held),
 .hold(hold),.scan_abort(scan_abort),.command_hold(command_hold),.control_error(control_error),
 .request(request),.write(write),.board(board),.index(index),.data(data),
 .ready(ready),.done(done),.error(error),.result(result),.fault(fault),
 .board_frozen(board_frozen),.board_done(board_done),.board_error(board_error),
 .board_hold_required(board_hold_required),.board_fault(board_fault),.board_result(board_result),.board_request(board_request));
endmodule
