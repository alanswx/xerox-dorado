`timescale 1ns/1ps
`default_nettype none
module task_ready_procl(input wire fixture_load,input wire [19:0] fixture_state,
 input wire base,start_a,en,input wire [85:0] pins,input wire [3:0] next_raw,input wire priority_n,
 output wire [19:0] state_q,output wire [5:0] clocks,
 output wire [2:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock0'Bd
 wire n15; // Clock0'Da
 wire n16; // Clock0'Db
 wire n17; // Clock0'Dc
 wire n18; // Clock1'Ca
 wire n19; // Clock1'Cb
 wire n20; // Clock1'Da
 wire n21; // Clock1'Db
 wire n22; // Clock1'Dc
 wire n23; // Curr.0'
 wire n24; // Curr.1'
 wire n25; // Curr.2'
 wire n26; // Curr.3'
 wire n27; // Curr=Next'
 wire n28; // CurrLast.0'
 wire n29; // CurrLast.1'
 wire n30; // CurrLast.2'
 wire n31; // CurrLast.3'
 wire n32; // DblClock'Ba
 wire n33; // DblClock'Bc
 wire n34; // FA=0'b
 wire n35; // FB=2'
 wire n36; // FB=3'
 wire n37; // FB=7'
 wire n38; // FC=4/5'
 wire n39; // FC=5'
 wire n40; // FC=6'
 wire n41; // GND132
 wire n42; // GND264
 wire n43; // GND266
 wire n44; // GND312
 wire n45; // GND314
 wire n46; // GND40
 wire n47; // GND468
 wire n48; // GND500
 wire n49; // GND530
 wire n50; // Hold
 wire n51; // Hold'
 wire n52; // HoldDly
 wire n53; // IOB.Perr'
 wire n54; // IOBin'
 wire n55; // IOBout
 wire n56; // IOin'
 wire n57; // LC.0
 wire n58; // LC.1
 wire n59; // LC.1'a
 wire n60; // LC.1a
 wire n61; // LC.2
 wire n62; // LScopeFH
 wire n63; // Last.0'
 wire n64; // Last.1'
 wire n65; // Last.2'
 wire n66; // Last.3'
 wire n67; // Last=Curr'
 wire n68; // LastNext.0'
 wire n69; // LastNext.1'
 wire n70; // LastNext.2'
 wire n71; // LastNext.3'
 wire n72; // Next.0
 wire n73; // Next.0'
 wire n74; // Next.1
 wire n75; // Next.1'
 wire n76; // Next.2
 wire n77; // Next.2'
 wire n78; // Next.3
 wire n79; // Next.3'
 wire n80; // PRhold
 wire n81; // PreClock0'A
 wire n82; // PreClock0'B
 wire n83; // PreClock0'C
 wire n84; // PreClock0'D
 wire n85; // PreClock1'A
 wire n86; // PreClock1'B
 wire n87; // PreClock1'C
 wire n88; // PreClock1'D
 wire n89; // PreClock1B
 wire n90; // PreDblClock'B
 wire n91; // PreSHCP'A
 wire n92; // PreSHCP'B
 wire n93; // PreSHCP'C
 wire n94; // PreSHCP'Shc
 wire n95; // PreSHSelect'D
 wire n96; // ProcL10.sil+1
 wire n97; // ProcL11.sil+7
 wire n98; // ProcL12.sil+1
 wire n99; // ProcL12.sil+3
 wire n100; // ProcL12.sil+4
 wire n101; // ProcL12.sil+5
 wire n102; // ProcL12.sil+6
 wire n103; // ProcL15.sil+1
 wire n104; // ProcL20.sil+1
 wire n105; // ProcL20.sil+3
 wire n106; // ProcL20.sil+4
 wire n107; // ProcL20.sil+5
 wire n108; // ProcL20.sil+6
 wire n109; // ProcL26.sil+1
 wire n110; // ProcL27.sil+11
 wire n111; // ProcL30.sil+1
 wire n112; // RbSelMd
 wire n113; // RbSelMd'
 wire n114; // RbWriteEn'
 wire n115; // RepeatCurrB
 wire n116; // RepeatCurrC
 wire n117; // RepeatCurrD
 wire n118; // SHCP'C
 wire n119; // SHSelect'C
 wire n120; // SimHoldReq'
 wire n121; // StartCycle'a
 wire n122; // TbBypass
 wire n123; // TbSelMd
 wire n124; // TbWriteEn'
 wire n125; // TisIFdata
 wire n126; // TrueA
 wire n127; // pClk1En'
 wire n128; // ppClk'a
 wire n129; // ppClk'b
 wire n130; // ppClk'c
 assign n41=1'b0;
 assign n42=1'b0;
 assign n43=1'b0;
 assign n44=1'b0;
 assign n45=1'b0;
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n49=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n34=(pins[19:18]!=2'd0);
 assign n35=(pins[17:15]!=3'd2);
 assign n36=(pins[17:15]!=3'd3);
 assign n37=(pins[17:15]!=3'd7);
 assign n38=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n39=(pins[14:12]!=3'd5);
 assign n40=(pins[14:12]!=3'd6);
 assign n52=1'b0;
 assign n54=1'b0;
 assign n55=1'b0;
 assign n57=pins[11];
 assign n58=pins[10];
 assign n61=pins[9];
 assign n72=next_raw[0];
 assign n74=next_raw[1];
 assign n76=next_raw[2];
 assign n78=next_raw[3];
 assign n80=pins[68];
 assign n109=1'b0;
 assign n110=1'b0;
 assign n121=start_a;
 assign n125=1'b0;
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_k10_3;
 assign n14=n14_k10_3;
 wire n15_j18_3;
 assign n15=n15_j18_3;
 wire n16_j18_2;
 assign n16=n16_j18_2;
 wire n17_j18_4;
 assign n17=n17_j18_4;
 wire n18_c18_3;
 assign n18=n18_c18_3;
 wire n19_c18_2;
 assign n19=n19_c18_2;
 wire n20_j18_13;
 assign n20=n20_j18_13;
 wire n21_j18_14;
 assign n21=n21_j18_14;
 wire n22_j18_12;
 assign n22=n22_j18_12;
 wire n23_a21_14;
 assign n23=n23_a21_14;
 wire n24_a21_15;
 assign n24=n24_a21_15;
 wire n25_a21_2;
 assign n25=n25_a21_2;
 wire n26_a21_3;
 assign n26=n26_a21_3;
 wire n27_a22_2;
 wire n27_a22_3;
 wire n27_a22_15;
 wire n27_a22_14;
 assign n27=n27_a22_2 | n27_a22_3 | n27_a22_15 | n27_a22_14;
 wire n28_i14_14;
 assign n28=n28_i14_14;
 wire n29_i14_15;
 assign n29=n29_i14_15;
 wire n30_i14_2;
 assign n30=n30_i14_2;
 wire n31_i14_3;
 assign n31=n31_i14_3;
 wire n32_k10_13;
 assign n32=n32_k10_13;
 wire n33_k10_14;
 assign n33=n33_k10_14;
 wire n50_f19_15;
 assign n50=n50_f19_15;
 wire n51_f19_14;
 assign n51=n51_f19_14;
 wire n53_g23_14;
 assign n53=n53_g23_14;
 wire n56_g23_9;
 assign n56=n56_g23_9;
 wire n59_h24_15;
 assign n59=n59_h24_15;
 wire n60_h24_9;
 assign n60=n60_h24_9;
 wire n62_c18_14;
 assign n62=n62_c18_14;
 wire n63_a20_14;
 assign n63=n63_a20_14;
 wire n64_a20_15;
 assign n64=n64_a20_15;
 wire n65_a20_2;
 assign n65=n65_a20_2;
 wire n66_a20_3;
 assign n66=n66_a20_3;
 wire n67_d17_15;
 assign n67=n67_d17_15;
 wire n68_a19_1;
 assign n68=n68_a19_1;
 wire n69_a19_2;
 assign n69=n69_a19_2;
 wire n70_a19_15;
 assign n70=n70_a19_15;
 wire n71_a19_14;
 assign n71=n71_a19_14;
 wire n73_a24_15;
 assign n73=n73_a24_15;
 wire n75_a24_14;
 assign n75=n75_a24_14;
 wire n77_a24_3;
 assign n77=n77_a24_3;
 wire n79_a24_2;
 assign n79=n79_a24_2;
 wire n81_f13_13;
 assign n81=n81_f13_13;
 wire n82_f13_12;
 assign n82=n82_f13_12;
 wire n83_f13_14;
 assign n83=n83_f13_14;
 wire n84_g13_3;
 assign n84=n84_g13_3;
 wire n85_f12_14;
 assign n85=n85_f12_14;
 wire n86_f13_2;
 assign n86=n86_f13_2;
 wire n87_f13_4;
 assign n87=n87_f13_4;
 wire n88_f13_3;
 assign n88=n88_f13_3;
 wire n89_f12_13;
 assign n89=n89_f12_13;
 wire n90_g13_13;
 assign n90=n90_g13_13;
 wire n91_g12_3;
 assign n91=n91_g12_3;
 wire n92_g12_2;
 assign n92=n92_g12_2;
 wire n93_g12_4;
 assign n93=n93_g12_4;
 wire n94_f12_4;
 assign n94=n94_f12_4;
 wire n95_f12_3;
 assign n95=n95_f12_3;
 wire n96_f20_2;
 assign n96=n96_f20_2;
 wire n97_f20_3;
 assign n97=n97_f20_3;
 wire n98_a24_9;
 wire n98_a24_11;
 wire n98_a24_6;
 wire n98_a24_5;
 assign n98=n98_a24_9 | n98_a24_11 | n98_a24_6 | n98_a24_5;
 wire n99_a18_2;
 assign n99=n99_a18_2;
 wire n100_a18_1;
 assign n100=n100_a18_1;
 wire n101_a18_15;
 assign n101=n101_a18_15;
 wire n102_a18_14;
 assign n102=n102_a18_14;
 wire n103_f20_14;
 assign n103=n103_f20_14;
 wire n104_f20_15;
 wire n104_g23_3;
 assign n104=n104_f20_15 | n104_g23_3;
 wire n105_h23_2;
 assign n105=n105_h23_2;
 wire n106_h23_3;
 assign n106=n106_h23_3;
 wire n107_h23_14;
 assign n107=n107_h23_14;
 wire n108_g23_2;
 assign n108=n108_g23_2;
 wire n111_f12_2;
 assign n111=n111_f12_2;
 wire n112_d17_3;
 assign n112=n112_d17_3;
 wire n113_d17_2;
 assign n113=n113_d17_2;
 wire n114_d17_13;
 assign n114=n114_d17_13;
 wire n115_g12_13;
 assign n115=n115_g12_13;
 wire n116_g12_12;
 assign n116=n116_g12_12;
 wire n117_g12_14;
 assign n117=n117_g12_14;
 wire n118_c18_13;
 assign n118=n118_c18_13;
 wire n119_c18_12;
 assign n119=n119_c18_12;
 wire n120_a01_3;
 assign n120=n120_a01_3;
 wire n122_f19_3;
 assign n122=n122_f19_3;
 wire n123_d17_4;
 assign n123=n123_d17_4;
 wire n124_d17_14;
 assign n124=n124_d17_14;
 wire n126_a01_14;
 assign n126=n126_a01_14;
 wire n127_l02_2;
 assign n127=n127_l02_2;
 wire n128_l01_13;
 assign n128=n128_l01_13;
 wire n129_l01_12;
 assign n129=n129_l01_12;
 wire n130_l01_14;
 assign n130=n130_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n120_a01_3),.p4(n1),.p5(1'b0),.p6(n109),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n126_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n100_a18_1),.p2(n99_a18_2),.p3(n69),.p4(n24),.p5(n68),.p6(n23),.p9(n116),.p10(n71),.p11(n26),.p12(n70),.p13(n25),.p14(n102_a18_14),.p15(n101_a18_15));
 cell_MC10158 a19(.p1(n68_a19_1),.p2(n69_a19_2),.p3(n75),.p4(n64),.p5(n73),.p6(n63),.p9(n93),.p10(n79),.p11(n66),.p12(n77),.p13(n65),.p14(n71_a19_14),.p15(n70_a19_15));
 original_MC10141 a20(.p1(n46),.p2(n65_a20_2),.p3(n66_a20_3),.p4(n18),.p5(1'b0),.p6(n26),.p7(1'b0),.p8(1'b0),.p9(n25),.p10(1'b0),.p11(n24),.p12(n23),.p13(1'b0),.p14(n63_a20_14),.p15(n64_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n25_a21_2),.p3(n26_a21_3),.p4(n118),.p5(1'b0),.p6(n79),.p7(n116),.p8(1'b0),.p9(n77),.p10(n116),.p11(n75),.p12(n73),.p13(1'b0),.p14(n23_a21_14),.p15(n24_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n27_a22_2),.p3(n27_a22_3),.p4(n26),.p5(n79),.p6(n77),.p7(n25),.p9(1'b0),.p10(n75),.p11(n24),.p12(n73),.p13(n23),.p14(n27_a22_14),.p15(n27_a22_15));
 cell_MC10101 a24(.p2(n79_a24_2),.p3(n77_a24_3),.p4(n78),.p5(n98_a24_5),.p6(n98_a24_6),.p7(n76),.p9(n98_a24_9),.p10(n74),.p11(n98_a24_11),.p12(1'b0),.p13(n72),.p14(n75_a24_14),.p15(n73_a24_15));
 cell_SE10210 c18(.p2(n19_c18_2),.p3(n18_c18_3),.p5(n87),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n93),.p10(1'b0),.p11(1'b0),.p12(n119_c18_12),.p13(n118_c18_13),.p14(n62_c18_14),.p15(n41),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n113_d17_2),.p3(n112_d17_3),.p4(n123_d17_4),.p5(n60),.p6(n59),.p7(n104),.p8(1'b0),.p9(n118),.p10(n107),.p11(n108),.p12(n27),.p13(n114_d17_13),.p14(n124_d17_14),.p15(n67_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n111_f12_2),.p3(n95_f12_3),.p4(n94_f12_4),.p5(n127),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n111),.p10(1'b0),.p11(n128),.p13(n89_f12_13),.p14(n85_f12_14),.p15(n42),.p16(1'b0));
 cell_SE10210 f13(.p2(n86_f13_2),.p3(n88_f13_3),.p4(n87_f13_4),.p5(n129),.p6(1'b0),.p7(n111),.p8(1'b0),.p9(n129),.p10(n13),.p11(1'b0),.p12(n82_f13_12),.p13(n81_f13_13),.p14(n83_f13_14),.p15(n43),.p16(1'b0));
 cell_MC1660 f19(.p3(n122_f19_3),.p4(n52),.p5(n67),.p6(n124),.p7(n125),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n80),.p14(n51_f19_14),.p15(n50_f19_15));
 cell_MC10100 f20(.p2(n96_f20_2),.p3(n97_f20_3),.p4(n40),.p5(n35),.p6(n38),.p7(n35),.p9(n34),.p10(n40),.p11(n36),.p12(n39),.p13(n37),.p14(n103_f20_14),.p15(n104_f20_15));
 cell_SE10211 g12(.p2(n92_g12_2),.p3(n91_g12_3),.p4(n93_g12_4),.p5(1'b0),.p6(n127),.p7(1'b0),.p9(n0),.p10(n51),.p11(1'b0),.p12(n116_g12_12),.p13(n115_g12_13),.p14(n117_g12_14),.p15(n44),.p16(1'b0));
 cell_SE10210 g13(.p3(n84_g13_3),.p5(n130),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n130),.p10(1'b0),.p11(1'b0),.p13(n90_g13_13),.p15(n45),.p16(1'b0));
 cell_MC10102 g23(.p1(1'b0),.p2(n108_g23_2),.p3(n104_g23_3),.p4(n61),.p5(n106),.p6(n57),.p7(n59),.p9(n56_g23_9),.p10(n55),.p11(n110),.p12(n50),.p13(n54),.p14(n53_g23_14),.p16(1'b0));
 cell_MC10102 h23(.p1(1'b0),.p2(n105_h23_2),.p3(n106_h23_3),.p4(n59),.p5(n61),.p6(n57),.p7(n59),.p9(n10_h23_9),.p10(n57),.p11(n105),.p12(n6),.p13(n9),.p14(n107_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n60_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n58),.p14(n9_h24_14),.p15(n59_h24_15));
 original_MC10141 i14(.p1(1'b0),.p2(n30_i14_2),.p3(n31_i14_3),.p4(n33),.p5(1'b0),.p6(n102),.p7(1'b0),.p8(1'b0),.p9(n101),.p10(1'b0),.p11(n99),.p12(n100),.p13(1'b0),.p14(n28_i14_14),.p15(n29_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_SE10210 j18(.p2(n16_j18_2),.p3(n15_j18_3),.p4(n17_j18_4),.p5(n84),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n88),.p10(1'b0),.p11(1'b0),.p12(n22_j18_12),.p13(n20_j18_13),.p14(n21_j18_14),.p15(n47),.p16(1'b0));
 cell_SE10210 k10(.p3(n14_k10_3),.p5(n82),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n90),.p13(n32_k10_13),.p14(n33_k10_14),.p15(n48),.p16(1'b0));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n121),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n129_l01_12),.p13(n128_l01_13),.p14(n130_l01_14),.p15(n49),.p16(1'b0));
 original_SE10231 l02(.p2(n127_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n118;
 assign clocks[3]=n82;
 assign clocks[4]=n18;
 assign clocks[5]=n33;
 assign flags[0]=n116;
 assign flags[1]=n50;
 assign flags[2]=n27;
endmodule
`default_nettype wire
