`timescale 1ns/1ps
module task_ready_capture_reference(input wire fixture_load,input wire [103:0] fixture_state,
 input wire base,input wire [85:0] pins,output wire [103:0] state_q,
 output wire [26:0] clocks,output wire [8:0] flags,output wire [3:0] next_raw,output wire [29:0] ready_flags);
 wire [2:0] bases;
 cell_MC10210 base_fanout(.p7(base),.p11(base),.p5(1'b0),.p6(1'b0),.p9(1'b0),.p10(1'b0),
   .p2(bases[2]),.p12(bases[1]),.p13(bases[0]));
 wire [14:0] cc;wire [5:0] ch,cl;wire [42:0] fc;wire [2:0] fh,fl;
 wire en_h=fc[3],en_l=fc[4],start_a=fc[5],priority_n=fc[10];
 task_ready_conta c(fixture_load,{fixture_state[103:88],fixture_state[79:64],fixture_state[31:0]},bases[2],1'b0,1'b0,
   pins,next_raw,priority_n,{state_q[103:88],state_q[79:64],state_q[31:0]},cc,fc);
 task_ready_proch h(fixture_load,{fixture_state[83:80],fixture_state[47:32]},bases[1],start_a,en_h,
   pins,next_raw,priority_n,{state_q[83:80],state_q[47:32]},ch,fh);
 task_ready_procl l(fixture_load,{fixture_state[87:84],fixture_state[63:48]},bases[0],start_a,en_l,
   pins,next_raw,priority_n,{state_q[87:84],state_q[63:48]},cl,fl);
 assign next_raw=fc[9:6];
 assign clocks={cc[14:13],cl[5],ch[5],cc[12],cc[11:9],cl[4:0],ch[4:0],cc[8:0]};
 assign flags={fl,fh,fc[2:0]};
 assign ready_flags=fc[42:13];
endmodule
