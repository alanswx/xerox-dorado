module clock_fit(input wire host_clk,input wire [277:0] pins,
 output reg [188:0] result);
 reg [277:0] input_stage,launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [103:0] q,next_q;
 wire before_clock,after_clock;
 wire [85:0] before_controls,after_controls;
 wire [26:0] events,repeated;
 wire unsettled;wire [29:0] ready_flags;
 assign {q,before_clock,after_clock,before_controls,after_controls}=launch;
 dorado_task_ready_capture_step evaluator(q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled,ready_flags);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled,ready_flags};
endmodule
