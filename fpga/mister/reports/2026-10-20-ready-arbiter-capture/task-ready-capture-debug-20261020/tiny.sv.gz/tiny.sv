`timescale 1ns/1ps
module tiny;
reg [27:0] pins=28'hb00100d;
wire [15:0] next_q;wire [1:0] events,clocks;wire [14:0] mask,ready;
dorado_task_ready_step #(.INDEPENDENT_BNT(1)) dut(16'hffff,pins,pins,next_q,events,clocks,mask,ready);
initial begin $display("TINY START"); #20;$display("TINY PASS mask=%h",mask);$finish;end
endmodule
