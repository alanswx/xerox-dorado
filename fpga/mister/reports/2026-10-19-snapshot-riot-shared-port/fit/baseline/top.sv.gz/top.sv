module snapshot_fit(
 input wire host_clk,advance,freeze,held,request,write,
 input wire [7:0] index,input wire [17:0] data,input wire [36:0] pins,
 output reg [17:0] result,output reg [25:0] outputs,output reg frozen,done,error);
 reg [67:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,request,write,index,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;wire [7:0] index_r;wire [17:0] data_r;wire [36:0] pins_r;
 assign {step_r,freeze_r,held_r,request_r,write_r,index_r,data_r,pins_r}=launch;
 wire [17:0] result_w;wire [25:0] outputs_w;wire frozen_w,done_w,error_w;
 always @(posedge host_clk){result,outputs,frozen,done,error}<={result_w,outputs_w,frozen_w,done_w,error_w};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 M6532_snapshot #(.init_7800(0)) cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w),.state_done(done_w),.state_error(error_w),.state_result(result_w),
`else
 assign {frozen_w,done_w,error_w,result_w}=21'b0;
 M6532 #(.init_7800(0)) cell_inst(
`endif
 .clk(host_clk),.ce(pins_r[0]),.res_n(pins_r[1]),.addr(pins_r[8:2]),.RW_n(pins_r[9]),
 .d_in(pins_r[17:10]),.RS_n(pins_r[18]),.CS1(pins_r[19]),.CS2_n(pins_r[20]),
 .PA_in(pins_r[28:21]),.PB_in(pins_r[36:29]),.d_out(outputs_w[7:0]),
 .PA_out(outputs_w[15:8]),.PB_out(outputs_w[23:16]),.IRQ_n(outputs_w[24]),.oe(outputs_w[25]));
endmodule
