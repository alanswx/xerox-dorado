// VENDORED, WITH A MINIMAL PATCH.
//
// Source: MiSTer-devel/Atari7800_MiSTer rtl/RIOT/M6532.sv (k7800 by Jamie
// Blanks). The Atari 7800 core's RIOT is SystemVerilog; the 2600 core's is
// VHDL, which Verilator cannot take -- hence this one.
//
// *** LICENCE: CC BY-NC 4.0 -- NONCOMMERCIAL. ***
// That is more restrictive than the rest of this repository. See
// verilog/vendor/LICENSES.md before shipping anything that includes it.
//
// PATCH: the output ports assigned inside always blocks are declared
// `output logic` rather than `output wire`. Quartus infers that; Verilator
// follows IEEE 1800 strictly and rejects a procedural assignment to a wire
// (PROCASSWIRE).
// PATCH: the registered read data honors ce, just as writes and timers do.
// ce=1 retains the original PHI2-clocked behavior; a fabric-clock wrapper
// can now preserve that behavior with one enable per PHI2 rising edge.

// k7800 (c) by Jamie Blanks

// k7800 is licensed under a
// Creative Commons Attribution-NonCommercial 4.0 International License.

// You should have received a copy of the license along with this
// work. If not, see http://creativecommons.org/licenses/by-nc/4.0/.


module M6532_snapshot
(
    input state_host_clk,state_advance,state_freeze,state_guest_held,state_request,state_write,
    input [7:0] state_index,input [17:0] state_data,
    output reg state_frozen=1'b0,state_done=1'b0,state_error=1'b0,
    output reg [17:0] state_result,
	input        clk,       // PHI 2
	input        ce,        // Clock enable
	input        res_n,     // reset
	input  [6:0] addr,      // Address
	input        RW_n,      // 1 = read, 0 = write
	input  [7:0] d_in,
	output logic [7:0] d_out,
	input        RS_n,      // RAM select
	output       logic       IRQ_n,
	input        CS1,       // Chip select 1, 1 = selected
	input        CS2_n,     // Chip select 2, 0 = selected
	input  [7:0] PA_in,     // Port ins and outs
	output logic [7:0] PA_out,    // NOTE that port output must be fed back to input
	input  [7:0] PB_in,     // if not altered by a peripheral, in order for
	output logic [7:0] PB_out,    // the chip to read properly!
	output       logic       oe         // Output enabled (always 8 bits)
);

parameter init_7800 = 0;

reg [7:0] riot_ram[128];
reg [7:0] out_a, out_b, data;
reg [7:0] dir_a, dir_b;
reg [7:0] interrupt;
reg [7:0] timer;
reg [9:0] prescaler;

reg [1:0] incr;
logic rollover;
reg [1:0] irq_en;
reg edge_detect;

assign IRQ_n = ~((interrupt[7] & irq_en[1]) | (interrupt[6] & irq_en[0]));

// These wires have a weak pull up, so any undriven wires will be high
assign PA_out = out_a | ~dir_a;
assign PB_out = out_b | ~dir_b;

assign oe = (CS1 & ~CS2_n) && RW_n;

wire pa7 = dir_a[7] ? PA_out[7] : PA_in[7];
wire p1 = incr == 2'd0 || rollover;
wire p8 = ~|prescaler[2:0] && incr == 2'd1;
wire p64 = ~|prescaler[5:0] && incr == 2'd2;
wire p1024 = ~|prescaler[9:0] && incr == 2'd3;
wire tick_inc = p1 || p8 || p64 || p1024;


reg old_pa7;
wire state_hold=state_freeze && state_guest_held;
wire state_accept=state_hold && state_frozen && state_request;
wire state_valid=state_index<8'd133;
always @(posedge state_host_clk)begin
    state_frozen<=state_hold;state_done<=state_accept;state_error<=state_accept && !state_valid;
    if(state_accept)begin
        state_result<=18'b0;
        if(state_valid)begin
            if(!state_index[7])begin
                if(!state_write)state_result<={10'b0,ram_read_data};
            end else case(state_index)
                8'd128:if(state_write){out_b[1:0],out_a[7:0],d_out[7:0]}<=state_data[17:0];else state_result<={out_b[1:0],out_a[7:0],d_out[7:0]};
                8'd129:if(state_write){dir_b[3:0],dir_a[7:0],out_b[7:2]}<=state_data[17:0];else state_result<={dir_b[3:0],dir_a[7:0],out_b[7:2]};
                8'd130:if(state_write){timer[5:0],interrupt[7:0],dir_b[7:4]}<=state_data[17:0];else state_result<={timer[5:0],interrupt[7:0],dir_b[7:4]};
                8'd131:if(state_write){rollover,edge_detect,irq_en[1:0],incr[1:0],prescaler[9:0],timer[7:6]}<=state_data[17:0];else state_result<={rollover,edge_detect,irq_en[1:0],incr[1:0],prescaler[9:0],timer[7:6]};
                8'd132:if(state_write)old_pa7<=1'b0;else state_result<={17'b0,old_pa7};
                default:;
            endcase
        end
    end
    if(!state_hold && state_advance)begin
begin
	// The BaseBoard wrapper oversamples PHI2 on its fabric clock. Reads
	// must obey the same enable as writes/timers, preserving the original
	// PHI2-edge output register rather than updating on every fabric edge.
	if (ce && (CS1 & ~CS2_n) && RW_n) begin
		if (~RS_n) begin // RAM selected
			d_out <= ram_read_data;
		end else if (~addr[2]) begin // Address registers
			case(addr[1:0])
				2'b01: d_out <= dir_a; // DDRA
				2'b11: d_out <= dir_b; // DDRB
				2'b00: d_out <= (PA_in & PA_out); // Input A
				2'b10: d_out <= (PB_in & PB_out); // Input B
			endcase
		end else if (addr[2])begin // Timer & Interrupts
			if (~addr[0])
				d_out <= timer[7:0];
			else
				d_out <= {interrupt[7:6], 6'd0};
		end
	end
	if (~res_n)
		d_out <= 8'hFF;
end

if (~res_n) begin
	// Set to specific value on atari 7800 version, 0 on MOS version


	out_a <= 8'h00;
	out_b <= 8'h00;
	dir_a <= 8'h00;
	dir_b <= 8'h00;
	{interrupt, irq_en, edge_detect} <= '0;
	incr <= 2'b10; // Increment resets to 64
	timer <= 8'hFF;   // Timer resets to FF
	prescaler <= 0;
	rollover <= 0;
end else begin
	
	if (ce) begin : riot_stuff

	
		prescaler <= prescaler + 1'd1;
	
		if (tick_inc)
			timer <= timer - 8'd1;

		if (CS1 & ~CS2_n) begin
			if (~RS_n) begin // RAM selected
				if (~RW_n)
					begin end // RAM write uses the shared port below.
			end else if (~addr[2]) begin // Address registers
				if (~RW_n) begin
					case(addr[1:0])
						2'b01: dir_a <= d_in; // DDRA
						2'b11: dir_b <= d_in; // DDRB
						2'b00: out_a <= d_in; // Output A
						2'b10: out_b <= d_in; // Output B
					endcase
				end
			end else begin // Timer & Interrupts
				if (~RW_n) begin
					if (addr[4])begin
						prescaler <= 10'd0;
						rollover <= 0;
						interrupt[7] <= 0;
						incr <= addr[1:0];
						timer <= d_in;
						irq_en[1] <= addr[3];
					end else begin
						irq_en[0] <= addr[1];
						edge_detect <= addr[0];
					end
				end else begin
					if (~addr[0]) begin
						irq_en[1] <= addr[3];
						rollover <= 0;
						interrupt[7] <= 0;
					end else
						interrupt[6] <= 0;
				end
			end
		end
	
		if (tick_inc && timer == 0) begin
			interrupt[7] <= 1;
			rollover <= 1;
		end
	
		// Edge detection
		old_pa7 <= pa7;
		if ((edge_detect && ~old_pa7 && pa7) || (~edge_detect && old_pa7 && ~pa7))
			interrupt[6] <= 1;
	end
end

    end
end

// Normal and administrative accesses are mutually exclusive at state_hold.
// A single address/data/write-enable port retains read-before-write behavior.
wire ram_normal = !state_hold && state_advance;
wire ram_admin_write = state_accept && state_valid && !state_index[7] && state_write;
wire ram_guest_write = ram_normal && res_n && ce && CS1 && !CS2_n && !RS_n && !RW_n;
wire [6:0] ram_address = state_hold ? state_index[6:0] : addr;
wire [7:0] ram_write_data = state_hold ? state_data[7:0] : d_in;
wire [7:0] ram_read_data = riot_ram[ram_address];
always @(posedge state_host_clk)begin
    if(ram_normal && !res_n)begin
	if (init_7800)
		riot_ram <= '{
			8'hA9, 8'h00, 8'hAA, 8'h85, 8'h01, 8'h95, 8'h03, 8'hE8, 8'h00, 8'h2A, 8'hD0, 8'hF9, 8'h85, 8'h02, 8'hA9, 8'h04,
			8'hEA, 8'h30, 8'h23, 8'hA2, 8'h04, 8'hCA, 8'h10, 8'hFD, 8'h9A, 8'h8D, 8'h10, 8'h01, 8'h20, 8'hCB, 8'h04, 8'h20,
			8'hCB, 8'h04, 8'h85, 8'h11, 8'h85, 8'h1B, 8'h85, 8'h1C, 8'h85, 8'h0F, 8'hEA, 8'h85, 8'h02, 8'hA9, 8'h00, 8'hEA,
			8'h30, 8'h04, 8'h24, 8'h03, 8'h30, 8'h09, 8'hA9, 8'h02, 8'h85, 8'h09, 8'h8D, 8'h12, 8'hF1, 8'hD0, 8'h1E, 8'h24,
			8'h02, 8'h30, 8'h0C, 8'hA9, 8'h02, 8'h85, 8'h06, 8'h8D, 8'h18, 8'hF1, 8'h8D, 8'h60, 8'hF4, 8'hD0, 8'h0E, 8'h85,
			8'h2C, 8'hA9, 8'h08, 8'h85, 8'h1B, 8'h20, 8'hCB, 8'h04, 8'hEA, 8'h24, 8'h02, 8'h30, 8'hD9, 8'hA9, 8'hFD, 8'h85,
			8'h08, 8'h6C, 8'hFC, 8'hFF, 8'hEA, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF,
			8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'hFF, 8'h00, 8'h00
		};
	else
		riot_ram <= '{128{8'h00}};
    end else if(ram_admin_write || ram_guest_write)begin
        riot_ram[ram_address] <= ram_write_data;
    end
end

endmodule
