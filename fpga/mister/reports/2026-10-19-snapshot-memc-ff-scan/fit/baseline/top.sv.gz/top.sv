module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [124:0] stimulus,
 input wire freeze,held,request,write,input wire [15:0] index,
 input wire [17:0] state_data,output reg [86:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both MemC neighbors sample on positive host edges; full20ns budgets.
 reg [164:0] launch;
 reg [164:0] input_stage;
 always @(negedge host_clk)
  input_stage<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 always @(posedge host_clk) launch<=input_stage;
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [124:0] stimulus_r;wire [15:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [86:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_AfreeOrEc_p_b__drv;
wire bank_AwantsDifHit_p___drv;
wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_CBHold__drv;
wire bank_CacheRef_p___drv;
wire bank_CacheRefInEc1__drv;
wire bank_DMuxData__drv;
wire bank_Dad_00__drv;
wire bank_Dad_01__drv;
wire bank_Dbuf_u__p___drv;
wire bank_DirtyIoFetchInA_p___drv;
wire bank_DisHold__drv;
wire bank_EcKeepsAbusy__drv;
wire bank_FastD_u_Dbuf__drv;
wire bank_Hita__drv;
wire bank_Hold__drv;
wire bank_IOHold__drv;
wire bank_IfuAck__drv;
wire bank_IfuHold__drv;
wire bank_IfuRefInEc1__drv;
wire bank_IoFetchInA_p___drv;
wire bank_IoStoreInA__drv;
wire bank_MXHold__drv;
wire bank_MakeF_u_D__drv;
wire bank_MapAd_0__drv;
wire bank_MapAd_1__drv;
wire bank_MapAd_2__drv;
wire bank_MapAd_3__drv;
wire bank_MapAd_4__drv;
wire bank_MapAd_5__drv;
wire bank_MapAd_6__drv;
wire bank_MapAd_7__drv;
wire bank_MapAd_8__drv;
wire bank_Map_u_InPair_p___drv;
wire bank_McrD_u__p___drv;
wire bank_Mcr_u__p___drv;
wire bank_MemAd_5__drv;
wire bank_MemAd_6__drv;
wire bank_MemAd_7__drv;
wire bank_MemAd_8__drv;
wire bank_PRhold__drv;
wire bank_PairFull_p___drv;
wire bank_PrivRefInPair__drv;
wire bank_ProcSrn_u__p___drv;
wire bank_ReadInA_p___drv;
wire bank_StartMap_p___drv;
wire bank_Store_u_InA_p___drv;
wire bank_Store_u_InEc1_p___drv;
wire bank_TagInEc1__drv;
wire bank_UseAsrn__drv;
wire bank_VicIfMiss_p___drv;
wire bank_VicInPair_p___drv;
wire bank_VicOrFS1C__drv;
wire bank__u_Config__drv;
wire bank__u_FaultInfo__drv;
wire bank__u_MDdly_p___drv;
wire bank__u_Pipe2__drv;
wire bank__u_Pipe3__drv;
wire bank__u_Pipe4__drv;
wire bank_dDad_02__drv;
wire bank_dDad_03__drv;
wire bank_dDad_04__drv;
wire bank_dDad_05__drv;
wire bank_dDad_06__drv;
wire bank_dDad_07__drv;
wire bank_dDad_08__drv;
wire bank_dDad_09__drv;
wire bank_dDad_10__drv;
wire bank_dDad_11__drv;
wire bank_dDad_12__drv;
wire bank_dDad_13__drv;
wire bank_dHitPerr__drv;
assign bank_q={bank_dHitPerr__drv,bank_dDad_13__drv,bank_dDad_12__drv,bank_dDad_11__drv,bank_dDad_10__drv,bank_dDad_09__drv,bank_dDad_08__drv,bank_dDad_07__drv,bank_dDad_06__drv,bank_dDad_05__drv,bank_dDad_04__drv,bank_dDad_03__drv,bank_dDad_02__drv,bank__u_Pipe4__drv,bank__u_Pipe3__drv,bank__u_Pipe2__drv,bank__u_MDdly_p___drv,bank__u_FaultInfo__drv,bank__u_Config__drv,bank_VicOrFS1C__drv,bank_VicInPair_p___drv,bank_VicIfMiss_p___drv,bank_UseAsrn__drv,bank_TagInEc1__drv,bank_Store_u_InEc1_p___drv,bank_Store_u_InA_p___drv,bank_StartMap_p___drv,bank_ReadInA_p___drv,bank_ProcSrn_u__p___drv,bank_PrivRefInPair__drv,bank_PairFull_p___drv,bank_PRhold__drv,bank_MemAd_8__drv,bank_MemAd_7__drv,bank_MemAd_6__drv,bank_MemAd_5__drv,bank_Mcr_u__p___drv,bank_McrD_u__p___drv,bank_Map_u_InPair_p___drv,bank_MapAd_8__drv,bank_MapAd_7__drv,bank_MapAd_6__drv,bank_MapAd_5__drv,bank_MapAd_4__drv,bank_MapAd_3__drv,bank_MapAd_2__drv,bank_MapAd_1__drv,bank_MapAd_0__drv,bank_MakeF_u_D__drv,bank_MXHold__drv,bank_IoStoreInA__drv,bank_IoFetchInA_p___drv,bank_IfuRefInEc1__drv,bank_IfuHold__drv,bank_IfuAck__drv,bank_IOHold__drv,bank_Hold__drv,bank_Hita__drv,bank_FastD_u_Dbuf__drv,bank_EcKeepsAbusy__drv,bank_DisHold__drv,bank_DirtyIoFetchInA_p___drv,bank_Dbuf_u__p___drv,bank_Dad_01__drv,bank_Dad_00__drv,bank_DMuxData__drv,bank_CacheRefInEc1__drv,bank_CacheRef_p___drv,bank_CBHold__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv,bank_AwantsDifHit_p___drv,bank_AfreeOrEc_p_b__drv};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 MemC_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 MemC_m_Rev_m_Be #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.ASEL_0(stimulus_r[0]),
.ASEL_0_p_mem(stimulus_r[1]),
.ASEL_1_p_(stimulus_r[2]),
.ASEL_2_p_(stimulus_r[3]),
.AcanhaveMap_p_(stimulus_r[4]),
.AfreeOrEc_p_b(stimulus_r[5] | bank_AfreeOrEc_p_b__drv),
.At_eq_Curt_p_(stimulus_r[6]),
.AwantsDifHit_p_(stimulus_r[7] | bank_AwantsDifHit_p___drv),
.BMux_04(stimulus_r[8] | bank_BMux_04__drv),
.BMux_05(stimulus_r[9] | bank_BMux_05__drv),
.BMux_06(stimulus_r[10] | bank_BMux_06__drv),
.BMux_07(stimulus_r[11] | bank_BMux_07__drv),
.BMux_08(stimulus_r[12] | bank_BMux_08__drv),
.BMux_09(stimulus_r[13] | bank_BMux_09__drv),
.BMux_10(stimulus_r[14] | bank_BMux_10__drv),
.BMux_11(stimulus_r[15] | bank_BMux_11__drv),
.BMux_12(stimulus_r[16] | bank_BMux_12__drv),
.BMux_13(stimulus_r[17] | bank_BMux_13__drv),
.BMux_14(stimulus_r[18] | bank_BMux_14__drv),
.BMux_15(stimulus_r[19] | bank_BMux_15__drv),
.CHoldReq(stimulus_r[20]),
.CLK_mc_p_(stimulus_r[21]),
.CLKEnable_p_b(stimulus_r[22]),
.CacheRef_p_(stimulus_r[23] | bank_CacheRef_p___drv),
.DMuxClk(stimulus_r[24]),
.DMuxData(stimulus_r[25] | bank_DMuxData__drv),
.DdataGood_p_(stimulus_r[26]),
.DisHold(stimulus_r[27] | bank_DisHold__drv),
.EcDcomingForCt_p_(stimulus_r[28]),
.EcKeepsAbusy(stimulus_r[29] | bank_EcKeepsAbusy__drv),
.EcWantsA(stimulus_r[30]),
.EmuOrFT_p_(stimulus_r[31]),
.ExtHoldReq(stimulus_r[32]),
.FA_eq_1_p_(stimulus_r[33]),
.FF_0mem_p_(stimulus_r[34]),
.FF_1mem(stimulus_r[35]),
.FF_2(stimulus_r[36]),
.FF_3(stimulus_r[37]),
.FF_4(stimulus_r[38]),
.FF_5(stimulus_r[39]),
.FF_6(stimulus_r[40]),
.FF_7(stimulus_r[41]),
.FastD_u_Dbuf(stimulus_r[42] | bank_FastD_u_Dbuf__drv),
.Hita(stimulus_r[43] | bank_Hita__drv),
.Hold(stimulus_r[44] | bank_Hold__drv),
.HoldMapBuf(stimulus_r[45]),
.IfuData_0(stimulus_r[46]),
.IfuData_1(stimulus_r[47]),
.IfuData_2(stimulus_r[48]),
.IfuData_3(stimulus_r[49]),
.IfuData_4(stimulus_r[50]),
.IfuData_5(stimulus_r[51]),
.IfuData_6(stimulus_r[52]),
.IfuData_7(stimulus_r[53]),
.IoStoreInA(stimulus_r[54] | bank_IoStoreInA__drv),
.LdPipeVAdly_p_(stimulus_r[55]),
.MAR_00_p_(stimulus_r[56]),
.MAR_01_p_(stimulus_r[57]),
.MAR_02_p_(stimulus_r[58]),
.MAR_03_p_(stimulus_r[59]),
.MAR_04_p_(stimulus_r[60]),
.MAR_05_p_(stimulus_r[61]),
.MAR_06_p_(stimulus_r[62]),
.MAR_07_p_(stimulus_r[63]),
.MAR_08_p_(stimulus_r[64]),
.MAR_09_p_(stimulus_r[65]),
.MAR_10_p_(stimulus_r[66]),
.MAR_11_p_(stimulus_r[67]),
.MAR_12_p_(stimulus_r[68]),
.MAR_13_p_(stimulus_r[69]),
.MAR_14_p_(stimulus_r[70]),
.MAR_15_p_(stimulus_r[71]),
.MDMtag_p_(stimulus_r[72]),
.MXHold(stimulus_r[73] | bank_MXHold__drv),
.MakeD_u_CD(stimulus_r[74]),
.MakeD_u_Dbuf(stimulus_r[75]),
.MakeF_u_D(stimulus_r[76] | bank_MakeF_u_D__drv),
.MapAd_0(stimulus_r[77] | bank_MapAd_0__drv),
.MapAd_1(stimulus_r[78] | bank_MapAd_1__drv),
.MapAd_2(stimulus_r[79] | bank_MapAd_2__drv),
.MapAd_3(stimulus_r[80] | bank_MapAd_3__drv),
.MapAd_4(stimulus_r[81] | bank_MapAd_4__drv),
.MapAd_5(stimulus_r[82] | bank_MapAd_5__drv),
.MapAd_6(stimulus_r[83] | bank_MapAd_6__drv),
.MapAd_7(stimulus_r[84] | bank_MapAd_7__drv),
.MapAd_8(stimulus_r[85] | bank_MapAd_8__drv),
.MapRfsh_p_(stimulus_r[86]),
.MapTroubleInEc1(stimulus_r[87]),
.MapWait_m_D(stimulus_r[88]),
.Map_u_InPair_p_(stimulus_r[89] | bank_Map_u_InPair_p___drv),
.Mcr_u__p_(stimulus_r[90] | bank_Mcr_u__p___drv),
.MemBase_0(stimulus_r[91]),
.MemBase_1(stimulus_r[92]),
.MemBase_2(stimulus_r[93]),
.MemBase_3(stimulus_r[94]),
.MemBase_4(stimulus_r[95]),
.MemClkEnable_p_a(stimulus_r[96]),
.MemRfsh(stimulus_r[97]),
.MemSH(stimulus_r[98]),
.PairFull_p_(stimulus_r[99] | bank_PairFull_p___drv),
.PrHoldReq(stimulus_r[100]),
.PrivRefInPair(stimulus_r[101] | bank_PrivRefInPair__drv),
.ProcTag(stimulus_r[102]),
.ProcTagInA(stimulus_r[103]),
.RefOutstanding_p_(stimulus_r[104]),
.STfree_p_(stimulus_r[105]),
.StartMap_p_(stimulus_r[106] | bank_StartMap_p___drv),
.Store_u_InA_p_(stimulus_r[107] | bank_Store_u_InA_p___drv),
.Transport_p_(stimulus_r[108]),
.UseAsrn(stimulus_r[109] | bank_UseAsrn__drv),
.VicIfMiss_p_(stimulus_r[110] | bank_VicIfMiss_p___drv),
.VicInPair_p_(stimulus_r[111] | bank_VicInPair_p___drv),
.VicOrFS1C(stimulus_r[112] | bank_VicOrFS1C__drv),
.WPinEc1(stimulus_r[113]),
.WantIfuRef_p_(stimulus_r[114]),
.XWantsPipe(stimulus_r[115]),
._u_MD(stimulus_r[116]),
._u_MDI(stimulus_r[117]),
._u_MDI_p_(stimulus_r[118]),
._u_MDdly_p_(stimulus_r[119] | bank__u_MDdly_p___drv),
.dPipe02Ad_0(stimulus_r[120]),
.dPipe02Ad_1(stimulus_r[121]),
.dPipe02Ad_2(stimulus_r[122]),
.dPipe02Ad_3(stimulus_r[123]),
.preMCSb(stimulus_r[124]),
.AfreeOrEc_p_b__drv(bank_AfreeOrEc_p_b__drv),
.AwantsDifHit_p___drv(bank_AwantsDifHit_p___drv),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.CBHold__drv(bank_CBHold__drv),
.CacheRef_p___drv(bank_CacheRef_p___drv),
.CacheRefInEc1__drv(bank_CacheRefInEc1__drv),
.DMuxData__drv(bank_DMuxData__drv),
.Dad_00__drv(bank_Dad_00__drv),
.Dad_01__drv(bank_Dad_01__drv),
.Dbuf_u__p___drv(bank_Dbuf_u__p___drv),
.DirtyIoFetchInA_p___drv(bank_DirtyIoFetchInA_p___drv),
.DisHold__drv(bank_DisHold__drv),
.EcKeepsAbusy__drv(bank_EcKeepsAbusy__drv),
.FastD_u_Dbuf__drv(bank_FastD_u_Dbuf__drv),
.Hita__drv(bank_Hita__drv),
.Hold__drv(bank_Hold__drv),
.IOHold__drv(bank_IOHold__drv),
.IfuAck__drv(bank_IfuAck__drv),
.IfuHold__drv(bank_IfuHold__drv),
.IfuRefInEc1__drv(bank_IfuRefInEc1__drv),
.IoFetchInA_p___drv(bank_IoFetchInA_p___drv),
.IoStoreInA__drv(bank_IoStoreInA__drv),
.MXHold__drv(bank_MXHold__drv),
.MakeF_u_D__drv(bank_MakeF_u_D__drv),
.MapAd_0__drv(bank_MapAd_0__drv),
.MapAd_1__drv(bank_MapAd_1__drv),
.MapAd_2__drv(bank_MapAd_2__drv),
.MapAd_3__drv(bank_MapAd_3__drv),
.MapAd_4__drv(bank_MapAd_4__drv),
.MapAd_5__drv(bank_MapAd_5__drv),
.MapAd_6__drv(bank_MapAd_6__drv),
.MapAd_7__drv(bank_MapAd_7__drv),
.MapAd_8__drv(bank_MapAd_8__drv),
.Map_u_InPair_p___drv(bank_Map_u_InPair_p___drv),
.McrD_u__p___drv(bank_McrD_u__p___drv),
.Mcr_u__p___drv(bank_Mcr_u__p___drv),
.MemAd_5__drv(bank_MemAd_5__drv),
.MemAd_6__drv(bank_MemAd_6__drv),
.MemAd_7__drv(bank_MemAd_7__drv),
.MemAd_8__drv(bank_MemAd_8__drv),
.PRhold__drv(bank_PRhold__drv),
.PairFull_p___drv(bank_PairFull_p___drv),
.PrivRefInPair__drv(bank_PrivRefInPair__drv),
.ProcSrn_u__p___drv(bank_ProcSrn_u__p___drv),
.ReadInA_p___drv(bank_ReadInA_p___drv),
.StartMap_p___drv(bank_StartMap_p___drv),
.Store_u_InA_p___drv(bank_Store_u_InA_p___drv),
.Store_u_InEc1_p___drv(bank_Store_u_InEc1_p___drv),
.TagInEc1__drv(bank_TagInEc1__drv),
.UseAsrn__drv(bank_UseAsrn__drv),
.VicIfMiss_p___drv(bank_VicIfMiss_p___drv),
.VicInPair_p___drv(bank_VicInPair_p___drv),
.VicOrFS1C__drv(bank_VicOrFS1C__drv),
._u_Config__drv(bank__u_Config__drv),
._u_FaultInfo__drv(bank__u_FaultInfo__drv),
._u_MDdly_p___drv(bank__u_MDdly_p___drv),
._u_Pipe2__drv(bank__u_Pipe2__drv),
._u_Pipe3__drv(bank__u_Pipe3__drv),
._u_Pipe4__drv(bank__u_Pipe4__drv),
.dDad_02__drv(bank_dDad_02__drv),
.dDad_03__drv(bank_dDad_03__drv),
.dDad_04__drv(bank_dDad_04__drv),
.dDad_05__drv(bank_dDad_05__drv),
.dDad_06__drv(bank_dDad_06__drv),
.dDad_07__drv(bank_dDad_07__drv),
.dDad_08__drv(bank_dDad_08__drv),
.dDad_09__drv(bank_dDad_09__drv),
.dDad_10__drv(bank_dDad_10__drv),
.dDad_11__drv(bank_dDad_11__drv),
.dDad_12__drv(bank_dDad_12__drv),
.dDad_13__drv(bank_dDad_13__drv),
.dHitPerr__drv(bank_dHitPerr__drv)
);
endmodule
