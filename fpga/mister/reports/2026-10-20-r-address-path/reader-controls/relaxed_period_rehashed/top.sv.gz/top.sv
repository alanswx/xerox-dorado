module clock_fit(input wire host_clk,input wire [1041:0] pins,
 output reg [790:0] result);
 // Fixture input staging avoids treating a virtual package pin as the
 // evaluator's launch register. The evaluator still has a full 15ns path
 // from launch to result; the new staging path has a stricter half period.
 reg [1041:0] input_stage;
 reg [1041:0] launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [635:0] q,next_q;
 wire before_clock,after_clock;
 wire [201:0] before_controls,after_controls;
 wire [44:0] events,repeated;
 wire [1:0] write_n,latch_n,t_latch_n,bypass;
 wire [3:0] parity_ok,faults,r_flags;
 wire [1:0] r_read_n,r_visible_n;wire [1:0] rm_flags_n;wire [31:0] address;wire [3:0] select_n;wire [1:0] forwarded_bypass;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls}=launch;
 dorado_r_address_step evaluator(q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,address,select_n,forwarded_bypass);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,address,select_n,forwarded_bypass};
endmodule
