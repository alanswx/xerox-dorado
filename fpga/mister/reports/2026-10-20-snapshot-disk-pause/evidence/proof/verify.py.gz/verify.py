from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
negative={'unguarded_io':'snapshot served normal SPI request','premature_ready':'snapshot acknowledged unfinished write','premature_continue':'unfinished snapshot lost lease','ignored_generation':'stale pause generation accepted'}
results={}
for version in('linux-v2','linux-v3'):
 base=root/version;out=base/'results';receipt=json.loads((out/'qualification.json').read_text());state=json.loads((base/'terminal-state.json').read_text())
 assert state['status']=='TERMINAL'and not state['builder_live']and not state['project_processes']
 assert receipt['status']=='PASS'and len(receipt['steps'])==4
 for step in receipt['steps']:assert step['returncode']==0 and sha(out/(step['step']+'.log'))==step['log_sha256']
 for name,digest in receipt['source_hashes'].items():assert sha(base/'source'/name)==digest,name
 for folder in('snapshot','arm'):
  q=json.loads((out/folder/'qualification.json').read_text())
  assert q['status']==('PASS'if folder=='snapshot'else'BUILD_ONLY')
  for name,digest in q['executed_inputs'].items():assert sha(out/folder/'executed-inputs'/name)==digest
  if version=='linux-v3':
   assert isinstance(q['original_main_inputs'],dict)and len(q['original_main_inputs'])==4
   for name,digest in q['original_main_inputs'].items():assert sha(base/'source/pinned-main'/name)==digest
 snap=json.loads((out/'snapshot/qualification.json').read_text());assert len(snap['cases'])==7
 for case in snap['cases']:
  name=case['case']
  if name in negative:
   assert case['returncode']==23 and case['expected_failure']==negative[name]
   assert negative[name]in(out/'snapshot'/name/'test.log').read_text()
  else:
   assert name in('normal','write-error','sync-error')and case['returncode']==0
   log=out/'snapshot'/(name+'.log');assert sha(log)==case['log_sha256']and'DISK SNAPSHOT'in log.read_text()
   gap=float(re.search(r'max_gap_ms=([0-9.]+)',log.read_text())[1]);assert gap<100
 results[version]=dict(status='PASS',snapshot_cases=7,legacy_cache=True,legacy_adapter=True,arm_build_only=True)
arm=root/'arm-runtime'
assert(arm/'terminal.txt').read_text()=='PASS\n'
assert(arm/'results.tsv').read_text()=='normal\t0\nwrite-error\t0\nsync-error\t0\n'
assert'armv7l'in(arm/'platform.txt').read_text()
sha_arm=(arm/'binary.sha256').read_text().split()[0]
assert sha_arm==json.loads((root/'linux-v2/results/qualification.json').read_text())['arm_binary_sha256']
a=json.loads((root/'linux-v2/results/arm/qualification.json').read_text())['executed_inputs']
b=json.loads((root/'linux-v3/results/arm/qualification.json').read_text())['executed_inputs']
assert a==b,'ARM executed sources changed'
gaps=[]
for mode in('normal','write-error','sync-error'):
 text=(arm/(mode+'.log')).read_text();assert'DISK SNAPSHOT'in text
 gap=float(re.search(r'max_gap_ms=([0-9.]+)',text)[1]);assert gap<100;gaps.append(gap)
 if mode=='normal':assert'bytes=262144'in text and'sole_spi_owner=1'in text
 if mode=='write-error':assert'dirty=31'in text and'needs_sync=1'in text
 if mode=='sync-error':assert'needs_sync=1'in text
results['arm-runtime']=dict(status='PASS',binary_sha256=sha_arm,max_poll_gap_ms=max(gaps),cases=3,fpga_io=False)
print(json.dumps(dict(status='PASS',results=results,limits='Cache/adapter/actual worker only; no FPGA pause, complete machine bundle or restore.'),indent=2))
