from pathlib import Path
import hashlib,json,tarfile,time
jobs=[('linux-v1','Dorado_DiskSnapshotPause_20261020',2580839),('linux-v2','Dorado_DiskSnapshotPause2_20261020',2585137),('linux-v3','Dorado_DiskSnapshotPause3_20261020',2589753)]
skip={'db','incremental_db','obj','obj_xml','__pycache__'}
packet=Path('/home/alans/mister/dorado-disk-snapshot-terminal-20261020.tar.gz');assert not packet.exists()
with tarfile.open(packet,'w:gz')as archive:
 for label,name,pid in jobs:
  project=Path('/home/alans/mister')/name;live=[]
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    cwd=(proc/'cwd').resolve(strict=True)
    if cwd.is_relative_to(project):live.append(int(proc.name))
   except(OSError,RuntimeError):pass
  assert not Path('/proc/'+str(pid)).exists()and not live,(name,live)
  state=dict(status='TERMINAL',builder_pid=pid,builder_live=False,project_processes=live,observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
  (project/'terminal-state.json').write_text(json.dumps(state,indent=2)+'\n')
  for p in sorted(project.rglob('*')):
   rel=p.relative_to(project)
   if not p.is_file()or p.is_symlink()or any(x in skip for x in rel.parts)or p.suffix in('.o','.a','.so','.pyc'):continue
   raw=p.read_bytes()
   if raw.startswith((b'\x7fELF',b'\xcf\xfa\xed\xfe')):continue
   archive.add(p,arcname=label+'/'+str(rel),recursive=False)
  print(json.dumps(dict(label=label,state=state)),flush=True)
print(json.dumps(dict(packet=str(packet),sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),bytes=packet.stat().st_size)))
