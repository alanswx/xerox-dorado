from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
p=Path('/home/alans/mister/dorado-disk-snapshot-source-v4-20261020.tar.gz')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='ab83e6fc16b1b5db1cd450fe57a4c4328153ab8a1f680b9a768f39dfcf5c8c8c'
root=Path('/home/alans/mister/Dorado_DiskSnapshotPause3_20261020');assert not root.exists()
source=root/'source';source.mkdir(parents=True)
with tarfile.open(p)as t:t.extractall(source,filter='data')
shutil.copyfile(source/'qualify.py',root/'qualify.py')
with(root/'driver.log').open('w')as log:
 child=subprocess.Popen(['python3',str(root/'qualify.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(child.pid)+'\n');print(json.dumps(dict(pid=child.pid,root=str(root))))
