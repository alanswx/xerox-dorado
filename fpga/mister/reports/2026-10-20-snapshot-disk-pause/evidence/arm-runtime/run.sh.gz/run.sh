#!/bin/sh
set -eu
cd /tmp/dorado-disk-snapshot-20261020
uname -a > platform.txt
sha256sum disk-snapshot-test > binary.sha256
printf '%s  %s\n' '1cecbdbd750424967ab9e16c6085682312051f35c323e295b73918780b39d743' disk-snapshot-test | sha256sum -c - > binary-check.log
chmod 700 disk-snapshot-test
: > results.tsv
for mode in normal write-error sync-error; do
  if [ "$mode" = normal ]; then
    if timeout 30 ./disk-snapshot-test > "$mode.log" 2>&1; then result=0; else result=$?; fi
  else
    if timeout 30 ./disk-snapshot-test "$mode" > "$mode.log" 2>&1; then result=0; else result=$?; fi
  fi
  printf '%s\t%s\n' "$mode" "$result" >> results.tsv
  cat "$mode.log"
  if [ "$result" != 0 ]; then exit "$result"; fi
done
printf 'PASS\n' > terminal.txt
