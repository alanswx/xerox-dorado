from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent;source=root/'source';tests=source/'fpga/mister/main/tests';out=root/'results';out.mkdir(exist_ok=False)
steps=[]
commands=[('snapshot',['python3',str(tests/'test_disk_snapshot.py'),str(source/'pinned-main'),'--output',str(out/'snapshot'),'--mutations'],{}),
 ('legacy-cache',['python3',str(tests/'test_disk_cache.py'),str(source/'pinned-main')],{}),
 ('legacy-adapter',['python3',str(tests/'test_disk_adapter.py'),str(source/'pinned-main')],{}),
 ('arm-build',['python3',str(tests/'test_disk_snapshot.py'),str(source/'pinned-main'),'--output',str(out/'arm'),'--no-run','--static'],{'CXX':'arm-linux-gnueabihf-g++'})]
for label,cmd,extra in commands:
 env={k:v for k,v in os.environ.items()if not k.startswith('DORADO_')};env.update(extra)
 (out/(label+'-command.json')).write_text(json.dumps(dict(command=cmd,environment=extra),indent=2)+'\n')
 with(out/(label+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=150)
 print(label+': rc='+str(r.returncode),flush=True)
 steps.append(dict(step=label,returncode=r.returncode,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()))
 assert not r.returncode,(label,(out/(label+'.log')).read_text())
(out/'qualification.json').write_text(json.dumps(dict(status='PASS',steps=steps,source_hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()for p in source.rglob('*')if p.is_file()and'__pycache__'not in p.parts},arm_binary_sha256=hashlib.sha256((out/'arm/disk-snapshot-test').read_bytes()).hexdigest(),hardware_access=False),indent=2)+'\n')
