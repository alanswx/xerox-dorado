"""Read-only Native57 completed base loader and preserved56b evidence."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile,time
base=Path('/media/fat/games/DoradoRTL');run=base/'Cedar57_20261019';old=base/'Cedar56b_20261019'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  while True:
   block=f.read(1024*1024)
   if not block:break
   h.update(block)
 return h.hexdigest()
assert sha('/proc/25287/exe')=='21e67a3f5588a875320437133df316b7e8f87061eb06b6dcaf63ecb139e29b60'
assert sha('/proc/25286/exe')=='c59962490772f12d061ec61aa64e6a567144d26d7802a28349a8d9a044eda87e'
assert sha('/media/fat/_Computer/DoradoRTL_Cedar57_20261019/Dorado.rbf')=='064e37848a123cbc0affeeb07ff309d242aff8b8deca9c0992c78e8ee56bc268'
assert not any(Path('/proc/%d/exe'%pid).exists()for pid in [23403,23400,25263])
maps={n:[x for x in Path('/proc/%d/maps'%p).read_text().splitlines()if '/dev/mem'in x or 'input-probe'in x]for n,p in [('main',25287),('server',25286)]}
assert not any('1ff00000'in x or 'input-probe'in x for x in maps['main'])
assert len(maps['server'])==1 and '1ff00000'in maps['server'][0]
paths={'deployment.json':run/'deployment.json','reboot-resume.json':run/'reboot-resume.json','qualification.json':run/'qualification.json',
'main-through-deployment.log':Path('/tmp/dorado57-main.log'),'disk-through-deployment.jsonl':Path('/tmp/dorado57-disk.jsonl'),'server-through-deployment.log':run/'server.log',
'retired56b-preservation.json':old/'preservation.json','retired56b-desktop-qualification.json':old/'desktop-qualification.json','retired56b-normal-boot-qualification.json':old/'normal-boot-qualification.json',
# Exact retired56b files record the actual56b->57 normal loader boundary.
'retired56b-disk-through-load.jsonl':old/'disk-through-native57-load.jsonl',
'retired56b-main-through-load.log':old/'main-through-native57-loader.log'}
paths['loader-observer.jsonl']=Path('/tmp/dorado57-loader-observer.jsonl')
assert not Path('/proc/25586/exe').exists(),'Completed observer remains live; do not restart'
files={name:p.read_bytes()for name,p in paths.items()}
last_observer=None
for raw in io.BytesIO(files['loader-observer.jsonl']):last_observer=json.loads(raw)
assert last_observer['event']=='end'and last_observer['reason']=='stop file'
reference=json.loads(Path('/tmp/dorado57-source-manifest-reference.json').read_text())
source=base/'System_20261017/chm/cedar/stp-root';actual={}
for name,expected in reference.items():
 data=(source/name).read_bytes();entry=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 assert entry==expected,(name,entry,expected)
 actual[name]=entry
files['remote-source-hashes.json']=(json.dumps(dict(status='PASS',files=len(actual),manifest=actual,
 scope='Served source files after terminal timed observer; not physical received-payload hashes'),indent=2)+'\n').encode()
last_disk=None;disk_records=0
for raw in io.BytesIO(files['retired56b-disk-through-load.jsonl']):
 last_disk=json.loads(raw);disk_records+=1
 assert 'error'not in last_disk['event']and last_disk['event']!='trace_dropped'
assert disk_records and last_disk['event']=='barrier_end'
oldproof=json.loads(files['retired56b-preservation.json']);assert sha(oldproof['path'])==oldproof['sha256']
meta=dict(collector_memory='Streaming retired trace validation and1MiB pack hashing; no retained parsed disk-record list',retired_disk_records=disk_records,utc=time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),main_pid=25287,server_pid=25286,maps=maps,old_processes_absent=True,
old_pack_hash_reverified=oldproof['sha256'],scope='Read-only startup evidence; no live-pack copy, SPI, guest write or atomic snapshot. Actual34/final ACK proved separately; full desktop/input pending.',
remote_files={name:str(p)for name,p in paths.items()},files={n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest())for n,d in files.items()})
files['field-collection.json']=(json.dumps(meta,indent=2)+'\n').encode()
out=Path('/tmp/dorado57-field-evidence.tar.gz');assert not out.exists()
with tarfile.open(out,'w:gz')as tar:
 for name,data in files.items():
  if name.endswith(('.log','.jsonl')):data=gzip.compress(data,mtime=0);name+='.gz'
  info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=str(out),**meta),indent=2))
