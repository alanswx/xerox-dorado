constexpr unsigned STIM_BITS=64,SCAN_WORD=0,AUX_WORD=61440;
constexpr unsigned FF_BITS=2004,FF_WORDS=112;
