constexpr unsigned STIM_BITS=125,SCAN_WORD=0,AUX_WORD=32256;
constexpr unsigned FF_BITS=507,FF_WORDS=29;
