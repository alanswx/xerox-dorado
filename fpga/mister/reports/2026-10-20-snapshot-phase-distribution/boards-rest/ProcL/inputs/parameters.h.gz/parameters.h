constexpr unsigned STIM_BITS=146,SCAN_WORD=0,AUX_WORD=35328;
constexpr unsigned FF_BITS=519,FF_WORDS=29;
