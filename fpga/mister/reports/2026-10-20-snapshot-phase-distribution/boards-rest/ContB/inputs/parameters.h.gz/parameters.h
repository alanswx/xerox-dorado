constexpr unsigned STIM_BITS=102,SCAN_WORD=16384,AUX_WORD=0;
constexpr unsigned FF_BITS=209,FF_WORDS=12;
