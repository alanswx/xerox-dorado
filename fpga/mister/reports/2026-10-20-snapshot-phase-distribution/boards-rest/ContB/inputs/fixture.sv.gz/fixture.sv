module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [101:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [70:0] reference_outputs,dut_outputs,
 output wire [352:0] reference_state,dut_state,
 output wire [143:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire all_hold=global_hold || (freeze && held) ||
 reference_hold || dut_hold || reference_fault || dut_fault;
 reg original_step=0;
 always @(negedge clk)original_step<=advance && !all_hold;
 wire [18:0] board_steps;
 dorado_board_phase_enable copies(.clk(clk),.permit(advance && !all_hold),.advance(board_steps));
 // All nineteen copies must remain identical, including scan and reset edges.
 always @(posedge clk)begin
  if(board_steps!=={19{original_step}})$fatal(1,"board phase copies differ");
 end
 wire reference_ALUF_0__drv;
wire reference_ALUF_1__drv;
wire reference_ALUF_2__drv;
wire reference_ALUF_3__drv;
wire reference_ASEL_0__drv;
wire reference_ASEL_0_p___drv;
wire reference_ASEL_0_p_a__drv;
wire reference_ASEL_0_p_mem__drv;
wire reference_ASEL_1_p___drv;
wire reference_ASEL_2_p___drv;
wire reference_BNPC_04__drv;
wire reference_BNPC_05__drv;
wire reference_BNPC_06__drv;
wire reference_BNPC_07__drv;
wire reference_BNPC_08__drv;
wire reference_BNPC_09__drv;
wire reference_BNPC_10__drv;
wire reference_BNPC_11__drv;
wire reference_BNPC_12__drv;
wire reference_BNPC_13__drv;
wire reference_BNPC_14__drv;
wire reference_BNPC_15__drv;
wire reference_BSEL_0_p___drv;
wire reference_BSEL_1_p___drv;
wire reference_BSEL_2_p___drv;
wire reference_CBTempSense__drv;
wire reference_CPIn_0__drv;
wire reference_CPIn_1__drv;
wire reference_CPIn_2__drv;
wire reference_CPIn_3__drv;
wire reference_DMuxData__drv;
wire reference_Error_p___drv;
wire reference_IMLHPE_p___drv;
wire reference_IMLHPEDly__drv;
wire reference_IMRHPEDly__drv;
wire reference_LC_0__drv;
wire reference_LC_1__drv;
wire reference_LC_2__drv;
wire reference_RSTK_0__drv;
wire reference_RSTK_1__drv;
wire reference_RSTK_2__drv;
wire reference_RSTK_3__drv;
wire reference_StopMIRClk__drv;
wire reference_dBlock_p___drv;
wire reference_dFF_0__drv;
wire reference_dFF_1__drv;
wire reference_dFF_2__drv;
wire reference_dFF_3__drv;
wire reference_dFF_4__drv;
wire reference_dFF_5__drv;
wire reference_dFF_6__drv;
wire reference_dFF_7__drv;
wire reference_dIMOut_07__drv;
wire reference_dIMOut_08__drv;
wire reference_dIMOut_09__drv;
wire reference_dIMOut_10__drv;
wire reference_dIMOut_11__drv;
wire reference_dIMOut_12__drv;
wire reference_dIMOut_13__drv;
wire reference_dIMOut_14__drv;
wire reference_dIMOut_15__drv;
wire reference_dIMRH__drv;
wire reference_dJCN_0__drv;
wire reference_dJCN_1__drv;
wire reference_dJCN_2__drv;
wire reference_dJCN_3__drv;
wire reference_dJCN_4__drv;
wire reference_dJCN_5__drv;
wire reference_dJCN_6__drv;
wire reference_dJCN_7__drv;
wire reference_rMIRa__drv;
ContB_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ALUF_0(stimulus[0] | reference_ALUF_0__drv),
.ALUF_1(stimulus[1] | reference_ALUF_1__drv),
.ALUF_2(stimulus[2] | reference_ALUF_2__drv),
.ALUF_3(stimulus[3] | reference_ALUF_3__drv),
.BMux_00(stimulus[4]),
.BMux_01(stimulus[5]),
.BMux_02(stimulus[6]),
.BMux_03(stimulus[7]),
.BMux_04(stimulus[8]),
.BMux_05(stimulus[9]),
.BMux_06(stimulus[10]),
.BMux_07(stimulus[11]),
.BMux_08(stimulus[12]),
.BMux_09(stimulus[13]),
.BMux_10(stimulus[14]),
.BMux_11(stimulus[15]),
.BMux_12(stimulus[16]),
.BMux_13(stimulus[17]),
.BMux_14(stimulus[18]),
.BMux_15(stimulus[19]),
.BMux_16(stimulus[20]),
.BMux_17(stimulus[21]),
.BNPC_02(stimulus[22]),
.BNPC_03(stimulus[23]),
.BNPC_04(stimulus[24] | reference_BNPC_04__drv),
.BNPC_05(stimulus[25] | reference_BNPC_05__drv),
.BNPC_06(stimulus[26] | reference_BNPC_06__drv),
.BNPC_07(stimulus[27] | reference_BNPC_07__drv),
.BNPC_08(stimulus[28] | reference_BNPC_08__drv),
.BNPC_09(stimulus[29] | reference_BNPC_09__drv),
.BNPC_10(stimulus[30] | reference_BNPC_10__drv),
.BNPC_11(stimulus[31] | reference_BNPC_11__drv),
.BNPC_12(stimulus[32] | reference_BNPC_12__drv),
.BNPC_13(stimulus[33] | reference_BNPC_13__drv),
.BNPC_14(stimulus[34] | reference_BNPC_14__drv),
.BNPC_15(stimulus[35] | reference_BNPC_15__drv),
.BNTGtCT_p_a(stimulus[36]),
.CBHold(stimulus[37]),
.CBTempSense(stimulus[38] | reference_CBTempSense__drv),
.CLK_cb_p_(stimulus[39]),
.CLKEnable_p_a(stimulus[40]),
.CPAddr_0_p_(stimulus[41]),
.CPAddr_1_p_(stimulus[42]),
.CPAddr_2_p_(stimulus[43]),
.CPOut_0(stimulus[44]),
.CPOut_1(stimulus[45]),
.CPOut_2(stimulus[46]),
.CPOut_3(stimulus[47]),
.CPOut_8(stimulus[48]),
.CPStrb_p_(stimulus[49]),
.CRamClock(stimulus[50]),
.DMuxClk(stimulus[51]),
.DMuxData(stimulus[52] | reference_DMuxData__drv),
.DoCBr(stimulus[53]),
.IMLHPE_p_(stimulus[54] | reference_IMLHPE_p___drv),
.IMLHPEDly(stimulus[55] | reference_IMLHPEDly__drv),
.IMRHPE_p_(stimulus[56]),
.IMRHPEDly(stimulus[57] | reference_IMRHPEDly__drv),
.IOPE(stimulus[58]),
.LC_0(stimulus[59] | reference_LC_0__drv),
.LC_1(stimulus[60] | reference_LC_1__drv),
.LC_2(stimulus[61] | reference_LC_2__drv),
.MdPE(stimulus[62]),
.MemPE(stimulus[63]),
.RamPE(stimulus[64]),
.SW(stimulus[65]),
.StartCycle_p_a(stimulus[66]),
.TNIA_02(stimulus[67]),
.TNIA_03(stimulus[68]),
.TNIA_04(stimulus[69]),
.TNIA_05(stimulus[70]),
.TNIA_06(stimulus[71]),
.TNIA_07(stimulus[72]),
.TNIA_08(stimulus[73]),
.TNIA_09(stimulus[74]),
.TNIA_10(stimulus[75]),
.TNIA_11(stimulus[76]),
.TNIA_12(stimulus[77]),
.TNIA_13(stimulus[78]),
.TNIA_14(stimulus[79]),
.TNIA_15(stimulus[80]),
.TempRef(stimulus[81]),
.UseDMD(stimulus[82]),
.dBlock_p_(stimulus[83] | reference_dBlock_p___drv),
.dFF_0(stimulus[84] | reference_dFF_0__drv),
.dFF_1(stimulus[85] | reference_dFF_1__drv),
.dFF_2(stimulus[86] | reference_dFF_2__drv),
.dFF_3(stimulus[87] | reference_dFF_3__drv),
.dFF_4(stimulus[88] | reference_dFF_4__drv),
.dFF_5(stimulus[89] | reference_dFF_5__drv),
.dFF_6(stimulus[90] | reference_dFF_6__drv),
.dFF_7(stimulus[91] | reference_dFF_7__drv),
.dIMRH(stimulus[92] | reference_dIMRH__drv),
.dJCN_0(stimulus[93] | reference_dJCN_0__drv),
.dJCN_1(stimulus[94] | reference_dJCN_1__drv),
.dJCN_2(stimulus[95] | reference_dJCN_2__drv),
.dJCN_3(stimulus[96] | reference_dJCN_3__drv),
.dJCN_4(stimulus[97] | reference_dJCN_4__drv),
.dJCN_5(stimulus[98] | reference_dJCN_5__drv),
.dJCN_6(stimulus[99] | reference_dJCN_6__drv),
.dJCN_7(stimulus[100] | reference_dJCN_7__drv),
.rMIRa(stimulus[101] | reference_rMIRa__drv),
.ALUF_0__drv(reference_ALUF_0__drv),
.ALUF_1__drv(reference_ALUF_1__drv),
.ALUF_2__drv(reference_ALUF_2__drv),
.ALUF_3__drv(reference_ALUF_3__drv),
.ASEL_0__drv(reference_ASEL_0__drv),
.ASEL_0_p___drv(reference_ASEL_0_p___drv),
.ASEL_0_p_a__drv(reference_ASEL_0_p_a__drv),
.ASEL_0_p_mem__drv(reference_ASEL_0_p_mem__drv),
.ASEL_1_p___drv(reference_ASEL_1_p___drv),
.ASEL_2_p___drv(reference_ASEL_2_p___drv),
.BNPC_04__drv(reference_BNPC_04__drv),
.BNPC_05__drv(reference_BNPC_05__drv),
.BNPC_06__drv(reference_BNPC_06__drv),
.BNPC_07__drv(reference_BNPC_07__drv),
.BNPC_08__drv(reference_BNPC_08__drv),
.BNPC_09__drv(reference_BNPC_09__drv),
.BNPC_10__drv(reference_BNPC_10__drv),
.BNPC_11__drv(reference_BNPC_11__drv),
.BNPC_12__drv(reference_BNPC_12__drv),
.BNPC_13__drv(reference_BNPC_13__drv),
.BNPC_14__drv(reference_BNPC_14__drv),
.BNPC_15__drv(reference_BNPC_15__drv),
.BSEL_0_p___drv(reference_BSEL_0_p___drv),
.BSEL_1_p___drv(reference_BSEL_1_p___drv),
.BSEL_2_p___drv(reference_BSEL_2_p___drv),
.CBTempSense__drv(reference_CBTempSense__drv),
.CPIn_0__drv(reference_CPIn_0__drv),
.CPIn_1__drv(reference_CPIn_1__drv),
.CPIn_2__drv(reference_CPIn_2__drv),
.CPIn_3__drv(reference_CPIn_3__drv),
.DMuxData__drv(reference_DMuxData__drv),
.Error_p___drv(reference_Error_p___drv),
.IMLHPE_p___drv(reference_IMLHPE_p___drv),
.IMLHPEDly__drv(reference_IMLHPEDly__drv),
.IMRHPEDly__drv(reference_IMRHPEDly__drv),
.LC_0__drv(reference_LC_0__drv),
.LC_1__drv(reference_LC_1__drv),
.LC_2__drv(reference_LC_2__drv),
.RSTK_0__drv(reference_RSTK_0__drv),
.RSTK_1__drv(reference_RSTK_1__drv),
.RSTK_2__drv(reference_RSTK_2__drv),
.RSTK_3__drv(reference_RSTK_3__drv),
.StopMIRClk__drv(reference_StopMIRClk__drv),
.dBlock_p___drv(reference_dBlock_p___drv),
.dFF_0__drv(reference_dFF_0__drv),
.dFF_1__drv(reference_dFF_1__drv),
.dFF_2__drv(reference_dFF_2__drv),
.dFF_3__drv(reference_dFF_3__drv),
.dFF_4__drv(reference_dFF_4__drv),
.dFF_5__drv(reference_dFF_5__drv),
.dFF_6__drv(reference_dFF_6__drv),
.dFF_7__drv(reference_dFF_7__drv),
.dIMOut_07__drv(reference_dIMOut_07__drv),
.dIMOut_08__drv(reference_dIMOut_08__drv),
.dIMOut_09__drv(reference_dIMOut_09__drv),
.dIMOut_10__drv(reference_dIMOut_10__drv),
.dIMOut_11__drv(reference_dIMOut_11__drv),
.dIMOut_12__drv(reference_dIMOut_12__drv),
.dIMOut_13__drv(reference_dIMOut_13__drv),
.dIMOut_14__drv(reference_dIMOut_14__drv),
.dIMOut_15__drv(reference_dIMOut_15__drv),
.dIMRH__drv(reference_dIMRH__drv),
.dJCN_0__drv(reference_dJCN_0__drv),
.dJCN_1__drv(reference_dJCN_1__drv),
.dJCN_2__drv(reference_dJCN_2__drv),
.dJCN_3__drv(reference_dJCN_3__drv),
.dJCN_4__drv(reference_dJCN_4__drv),
.dJCN_5__drv(reference_dJCN_5__drv),
.dJCN_6__drv(reference_dJCN_6__drv),
.dJCN_7__drv(reference_dJCN_7__drv),
.rMIRa__drv(reference_rMIRa__drv),
.state_host_clk(clk),
.state_guest_advance(original_step),
.state_freeze(freeze || all_hold),
.state_guest_held(held || all_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[14:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_rMIRa__drv,reference_dJCN_7__drv,reference_dJCN_6__drv,reference_dJCN_5__drv,reference_dJCN_4__drv,reference_dJCN_3__drv,reference_dJCN_2__drv,reference_dJCN_1__drv,reference_dJCN_0__drv,reference_dIMRH__drv,reference_dIMOut_15__drv,reference_dIMOut_14__drv,reference_dIMOut_13__drv,reference_dIMOut_12__drv,reference_dIMOut_11__drv,reference_dIMOut_10__drv,reference_dIMOut_09__drv,reference_dIMOut_08__drv,reference_dIMOut_07__drv,reference_dFF_7__drv,reference_dFF_6__drv,reference_dFF_5__drv,reference_dFF_4__drv,reference_dFF_3__drv,reference_dFF_2__drv,reference_dFF_1__drv,reference_dFF_0__drv,reference_dBlock_p___drv,reference_StopMIRClk__drv,reference_RSTK_3__drv,reference_RSTK_2__drv,reference_RSTK_1__drv,reference_RSTK_0__drv,reference_LC_2__drv,reference_LC_1__drv,reference_LC_0__drv,reference_IMRHPEDly__drv,reference_IMLHPEDly__drv,reference_IMLHPE_p___drv,reference_Error_p___drv,reference_DMuxData__drv,reference_CPIn_3__drv,reference_CPIn_2__drv,reference_CPIn_1__drv,reference_CPIn_0__drv,reference_CBTempSense__drv,reference_BSEL_2_p___drv,reference_BSEL_1_p___drv,reference_BSEL_0_p___drv,reference_BNPC_15__drv,reference_BNPC_14__drv,reference_BNPC_13__drv,reference_BNPC_12__drv,reference_BNPC_11__drv,reference_BNPC_10__drv,reference_BNPC_09__drv,reference_BNPC_08__drv,reference_BNPC_07__drv,reference_BNPC_06__drv,reference_BNPC_05__drv,reference_BNPC_04__drv,reference_ASEL_2_p___drv,reference_ASEL_1_p___drv,reference_ASEL_0_p_mem__drv,reference_ASEL_0_p_a__drv,reference_ASEL_0_p___drv,reference_ASEL_0__drv,reference_ALUF_3__drv,reference_ALUF_2__drv,reference_ALUF_1__drv,reference_ALUF_0__drv};
assign reference_state[0+:18]=reference.snapshot_bank_0.saved_q;
assign reference_state[18+:18]=reference.snapshot_bank_1.saved_q;
assign reference_state[36+:18]=reference.snapshot_bank_2.saved_q;
assign reference_state[54+:18]=reference.snapshot_bank_3.saved_q;
assign reference_state[72+:18]=reference.snapshot_bank_4.saved_q;
assign reference_state[90+:18]=reference.snapshot_bank_5.saved_q;
assign reference_state[108+:18]=reference.snapshot_bank_6.saved_q;
assign reference_state[126+:18]=reference.snapshot_bank_7.saved_q;
assign reference_state[144+:1]=reference.u_b02.ck_d;
assign reference_state[145+:6]=reference.u_b02.d_pre;
assign reference_state[151+:6]=reference.u_b02.q;
assign reference_state[157+:1]=reference.u_b23.cka_d;
assign reference_state[158+:1]=reference.u_b23.ckb_d;
assign reference_state[159+:1]=reference.u_b23.d_pre_a;
assign reference_state[160+:1]=reference.u_b23.d_pre_b;
assign reference_state[161+:1]=reference.u_b23.qa;
assign reference_state[162+:1]=reference.u_b23.qb;
assign reference_state[163+:1]=reference.u_b24.cka_d;
assign reference_state[164+:1]=reference.u_b24.ckb_d;
assign reference_state[165+:1]=reference.u_b24.d_pre_a;
assign reference_state[166+:1]=reference.u_b24.d_pre_b;
assign reference_state[167+:1]=reference.u_b24.qa;
assign reference_state[168+:1]=reference.u_b24.qb;
assign reference_state[169+:1]=reference.u_c02.ck_d;
assign reference_state[170+:6]=reference.u_c02.d_pre;
assign reference_state[176+:6]=reference.u_c02.q;
assign reference_state[182+:1]=reference.u_c04.ck_d;
assign reference_state[183+:6]=reference.u_c04.d_pre;
assign reference_state[189+:6]=reference.u_c04.q;
assign reference_state[195+:1]=reference.u_c24.cka_d;
assign reference_state[196+:1]=reference.u_c24.ckb_d;
assign reference_state[197+:1]=reference.u_c24.d_pre_a;
assign reference_state[198+:1]=reference.u_c24.d_pre_b;
assign reference_state[199+:1]=reference.u_c24.qa;
assign reference_state[200+:1]=reference.u_c24.qb;
assign reference_state[201+:1]=reference.u_d02.ck_d;
assign reference_state[202+:6]=reference.u_d02.d_pre;
assign reference_state[208+:6]=reference.u_d02.q;
assign reference_state[214+:1]=reference.u_f22.ck_d;
assign reference_state[215+:6]=reference.u_f22.d_pre;
assign reference_state[221+:6]=reference.u_f22.q;
assign reference_state[227+:1]=reference.u_g03.ck_d;
assign reference_state[228+:6]=reference.u_g03.d_pre;
assign reference_state[234+:6]=reference.u_g03.q;
assign reference_state[240+:1]=reference.u_g22.ck_d;
assign reference_state[241+:6]=reference.u_g22.d_pre;
assign reference_state[247+:6]=reference.u_g22.q;
assign reference_state[253+:1]=reference.u_g24.cka_d;
assign reference_state[254+:1]=reference.u_g24.ckb_d;
assign reference_state[255+:1]=reference.u_g24.d_pre_a;
assign reference_state[256+:1]=reference.u_g24.d_pre_b;
assign reference_state[257+:1]=reference.u_g24.qa;
assign reference_state[258+:1]=reference.u_g24.qb;
assign reference_state[259+:1]=reference.u_h01.cka_d;
assign reference_state[260+:1]=reference.u_h01.ckb_d;
assign reference_state[261+:1]=reference.u_h01.d_pre_a;
assign reference_state[262+:1]=reference.u_h01.d_pre_b;
assign reference_state[263+:1]=reference.u_h01.qa;
assign reference_state[264+:1]=reference.u_h01.qb;
assign reference_state[265+:1]=reference.u_h03.ck_d;
assign reference_state[266+:6]=reference.u_h03.d_pre;
assign reference_state[272+:6]=reference.u_h03.q;
assign reference_state[278+:1]=reference.u_h24.cka_d;
assign reference_state[279+:1]=reference.u_h24.ckb_d;
assign reference_state[280+:1]=reference.u_h24.d_pre_a;
assign reference_state[281+:1]=reference.u_h24.d_pre_b;
assign reference_state[282+:1]=reference.u_h24.qa;
assign reference_state[283+:1]=reference.u_h24.qb;
assign reference_state[284+:1]=reference.u_i01.cka_d;
assign reference_state[285+:1]=reference.u_i01.ckb_d;
assign reference_state[286+:1]=reference.u_i01.d_pre_a;
assign reference_state[287+:1]=reference.u_i01.d_pre_b;
assign reference_state[288+:1]=reference.u_i01.qa;
assign reference_state[289+:1]=reference.u_i01.qb;
assign reference_state[290+:1]=reference.u_i24.cka_d;
assign reference_state[291+:1]=reference.u_i24.ckb_d;
assign reference_state[292+:1]=reference.u_i24.d_pre_a;
assign reference_state[293+:1]=reference.u_i24.d_pre_b;
assign reference_state[294+:1]=reference.u_i24.qa;
assign reference_state[295+:1]=reference.u_i24.qb;
assign reference_state[296+:1]=reference.u_j01.cka_d;
assign reference_state[297+:1]=reference.u_j01.ckb_d;
assign reference_state[298+:1]=reference.u_j01.d_pre_a;
assign reference_state[299+:1]=reference.u_j01.d_pre_b;
assign reference_state[300+:1]=reference.u_j01.qa;
assign reference_state[301+:1]=reference.u_j01.qb;
assign reference_state[302+:1]=reference.u_j24.cka_d;
assign reference_state[303+:1]=reference.u_j24.ckb_d;
assign reference_state[304+:1]=reference.u_j24.d_pre_a;
assign reference_state[305+:1]=reference.u_j24.d_pre_b;
assign reference_state[306+:1]=reference.u_j24.qa;
assign reference_state[307+:1]=reference.u_j24.qb;
assign reference_state[308+:1]=reference.u_k24.cka_d;
assign reference_state[309+:1]=reference.u_k24.ckb_d;
assign reference_state[310+:1]=reference.u_k24.d_pre_a;
assign reference_state[311+:1]=reference.u_k24.d_pre_b;
assign reference_state[312+:1]=reference.u_k24.qa;
assign reference_state[313+:1]=reference.u_k24.qb;
assign reference_state[314+:1]=reference.u_l04.ck_d;
assign reference_state[315+:6]=reference.u_l04.d_pre;
assign reference_state[321+:6]=reference.u_l04.q;
assign reference_state[327+:1]=reference.u_l20.ck_d;
assign reference_state[328+:6]=reference.u_l20.d_pre;
assign reference_state[334+:6]=reference.u_l20.q;
assign reference_state[340+:1]=reference.u_l22.ck_d;
assign reference_state[341+:6]=reference.u_l22.d_pre;
assign reference_state[347+:6]=reference.u_l22.q;
assign reference_probe[0+:1]=reference.snapshot_bank_0.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[1+:1]=reference.snapshot_bank_0.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[2+:1]=reference.snapshot_bank_0.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[3+:1]=reference.snapshot_bank_0.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[4+:1]=reference.snapshot_bank_0.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[5+:1]=reference.snapshot_bank_0.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[6+:1]=reference.snapshot_bank_0.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[7+:1]=reference.snapshot_bank_0.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[8+:1]=reference.snapshot_bank_0.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[9+:1]=reference.snapshot_bank_0.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[10+:1]=reference.snapshot_bank_0.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[11+:1]=reference.snapshot_bank_0.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[12+:1]=reference.snapshot_bank_0.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[13+:1]=reference.snapshot_bank_0.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[14+:1]=reference.snapshot_bank_0.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[15+:1]=reference.snapshot_bank_0.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[16+:1]=reference.snapshot_bank_0.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[17+:1]=reference.snapshot_bank_0.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[18+:1]=reference.snapshot_bank_1.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[19+:1]=reference.snapshot_bank_1.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[20+:1]=reference.snapshot_bank_1.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[21+:1]=reference.snapshot_bank_1.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[22+:1]=reference.snapshot_bank_1.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[23+:1]=reference.snapshot_bank_1.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[24+:1]=reference.snapshot_bank_1.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[25+:1]=reference.snapshot_bank_1.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[26+:1]=reference.snapshot_bank_1.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[27+:1]=reference.snapshot_bank_1.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[28+:1]=reference.snapshot_bank_1.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[29+:1]=reference.snapshot_bank_1.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[30+:1]=reference.snapshot_bank_1.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[31+:1]=reference.snapshot_bank_1.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[32+:1]=reference.snapshot_bank_1.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[33+:1]=reference.snapshot_bank_1.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[34+:1]=reference.snapshot_bank_1.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[35+:1]=reference.snapshot_bank_1.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[36+:1]=reference.snapshot_bank_2.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[37+:1]=reference.snapshot_bank_2.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[38+:1]=reference.snapshot_bank_2.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[39+:1]=reference.snapshot_bank_2.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[40+:1]=reference.snapshot_bank_2.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[41+:1]=reference.snapshot_bank_2.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[42+:1]=reference.snapshot_bank_2.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[43+:1]=reference.snapshot_bank_2.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[44+:1]=reference.snapshot_bank_2.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[45+:1]=reference.snapshot_bank_2.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[46+:1]=reference.snapshot_bank_2.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[47+:1]=reference.snapshot_bank_2.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[48+:1]=reference.snapshot_bank_2.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[49+:1]=reference.snapshot_bank_2.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[50+:1]=reference.snapshot_bank_2.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[51+:1]=reference.snapshot_bank_2.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[52+:1]=reference.snapshot_bank_2.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[53+:1]=reference.snapshot_bank_2.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[54+:1]=reference.snapshot_bank_3.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[55+:1]=reference.snapshot_bank_3.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[56+:1]=reference.snapshot_bank_3.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[57+:1]=reference.snapshot_bank_3.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[58+:1]=reference.snapshot_bank_3.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[59+:1]=reference.snapshot_bank_3.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[60+:1]=reference.snapshot_bank_3.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[61+:1]=reference.snapshot_bank_3.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[62+:1]=reference.snapshot_bank_3.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[63+:1]=reference.snapshot_bank_3.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[64+:1]=reference.snapshot_bank_3.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[65+:1]=reference.snapshot_bank_3.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[66+:1]=reference.snapshot_bank_3.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[67+:1]=reference.snapshot_bank_3.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[68+:1]=reference.snapshot_bank_3.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[69+:1]=reference.snapshot_bank_3.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[70+:1]=reference.snapshot_bank_3.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[71+:1]=reference.snapshot_bank_3.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[72+:1]=reference.snapshot_bank_4.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[73+:1]=reference.snapshot_bank_4.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[74+:1]=reference.snapshot_bank_4.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[75+:1]=reference.snapshot_bank_4.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[76+:1]=reference.snapshot_bank_4.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[77+:1]=reference.snapshot_bank_4.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[78+:1]=reference.snapshot_bank_4.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[79+:1]=reference.snapshot_bank_4.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[80+:1]=reference.snapshot_bank_4.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[81+:1]=reference.snapshot_bank_4.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[82+:1]=reference.snapshot_bank_4.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[83+:1]=reference.snapshot_bank_4.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[84+:1]=reference.snapshot_bank_4.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[85+:1]=reference.snapshot_bank_4.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[86+:1]=reference.snapshot_bank_4.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[87+:1]=reference.snapshot_bank_4.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[88+:1]=reference.snapshot_bank_4.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[89+:1]=reference.snapshot_bank_4.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[90+:1]=reference.snapshot_bank_5.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[91+:1]=reference.snapshot_bank_5.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[92+:1]=reference.snapshot_bank_5.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[93+:1]=reference.snapshot_bank_5.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[94+:1]=reference.snapshot_bank_5.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[95+:1]=reference.snapshot_bank_5.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[96+:1]=reference.snapshot_bank_5.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[97+:1]=reference.snapshot_bank_5.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[98+:1]=reference.snapshot_bank_5.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[99+:1]=reference.snapshot_bank_5.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[100+:1]=reference.snapshot_bank_5.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[101+:1]=reference.snapshot_bank_5.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[102+:1]=reference.snapshot_bank_5.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[103+:1]=reference.snapshot_bank_5.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[104+:1]=reference.snapshot_bank_5.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[105+:1]=reference.snapshot_bank_5.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[106+:1]=reference.snapshot_bank_5.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[107+:1]=reference.snapshot_bank_5.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[108+:1]=reference.snapshot_bank_6.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[109+:1]=reference.snapshot_bank_6.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[110+:1]=reference.snapshot_bank_6.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[111+:1]=reference.snapshot_bank_6.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[112+:1]=reference.snapshot_bank_6.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[113+:1]=reference.snapshot_bank_6.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[114+:1]=reference.snapshot_bank_6.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[115+:1]=reference.snapshot_bank_6.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[116+:1]=reference.snapshot_bank_6.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[117+:1]=reference.snapshot_bank_6.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[118+:1]=reference.snapshot_bank_6.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[119+:1]=reference.snapshot_bank_6.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[120+:1]=reference.snapshot_bank_6.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[121+:1]=reference.snapshot_bank_6.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[122+:1]=reference.snapshot_bank_6.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[123+:1]=reference.snapshot_bank_6.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[124+:1]=reference.snapshot_bank_6.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[125+:1]=reference.snapshot_bank_6.bits[9].mem[0+(probe_index%1024)];
assign reference_probe[126+:1]=reference.snapshot_bank_7.bits[0].mem[0+(probe_index%1024)];
assign reference_probe[127+:1]=reference.snapshot_bank_7.bits[10].mem[0+(probe_index%1024)];
assign reference_probe[128+:1]=reference.snapshot_bank_7.bits[11].mem[0+(probe_index%1024)];
assign reference_probe[129+:1]=reference.snapshot_bank_7.bits[12].mem[0+(probe_index%1024)];
assign reference_probe[130+:1]=reference.snapshot_bank_7.bits[13].mem[0+(probe_index%1024)];
assign reference_probe[131+:1]=reference.snapshot_bank_7.bits[14].mem[0+(probe_index%1024)];
assign reference_probe[132+:1]=reference.snapshot_bank_7.bits[15].mem[0+(probe_index%1024)];
assign reference_probe[133+:1]=reference.snapshot_bank_7.bits[16].mem[0+(probe_index%1024)];
assign reference_probe[134+:1]=reference.snapshot_bank_7.bits[17].mem[0+(probe_index%1024)];
assign reference_probe[135+:1]=reference.snapshot_bank_7.bits[1].mem[0+(probe_index%1024)];
assign reference_probe[136+:1]=reference.snapshot_bank_7.bits[2].mem[0+(probe_index%1024)];
assign reference_probe[137+:1]=reference.snapshot_bank_7.bits[3].mem[0+(probe_index%1024)];
assign reference_probe[138+:1]=reference.snapshot_bank_7.bits[4].mem[0+(probe_index%1024)];
assign reference_probe[139+:1]=reference.snapshot_bank_7.bits[5].mem[0+(probe_index%1024)];
assign reference_probe[140+:1]=reference.snapshot_bank_7.bits[6].mem[0+(probe_index%1024)];
assign reference_probe[141+:1]=reference.snapshot_bank_7.bits[7].mem[0+(probe_index%1024)];
assign reference_probe[142+:1]=reference.snapshot_bank_7.bits[8].mem[0+(probe_index%1024)];
assign reference_probe[143+:1]=reference.snapshot_bank_7.bits[9].mem[0+(probe_index%1024)];
wire dut_ALUF_0__drv;
wire dut_ALUF_1__drv;
wire dut_ALUF_2__drv;
wire dut_ALUF_3__drv;
wire dut_ASEL_0__drv;
wire dut_ASEL_0_p___drv;
wire dut_ASEL_0_p_a__drv;
wire dut_ASEL_0_p_mem__drv;
wire dut_ASEL_1_p___drv;
wire dut_ASEL_2_p___drv;
wire dut_BNPC_04__drv;
wire dut_BNPC_05__drv;
wire dut_BNPC_06__drv;
wire dut_BNPC_07__drv;
wire dut_BNPC_08__drv;
wire dut_BNPC_09__drv;
wire dut_BNPC_10__drv;
wire dut_BNPC_11__drv;
wire dut_BNPC_12__drv;
wire dut_BNPC_13__drv;
wire dut_BNPC_14__drv;
wire dut_BNPC_15__drv;
wire dut_BSEL_0_p___drv;
wire dut_BSEL_1_p___drv;
wire dut_BSEL_2_p___drv;
wire dut_CBTempSense__drv;
wire dut_CPIn_0__drv;
wire dut_CPIn_1__drv;
wire dut_CPIn_2__drv;
wire dut_CPIn_3__drv;
wire dut_DMuxData__drv;
wire dut_Error_p___drv;
wire dut_IMLHPE_p___drv;
wire dut_IMLHPEDly__drv;
wire dut_IMRHPEDly__drv;
wire dut_LC_0__drv;
wire dut_LC_1__drv;
wire dut_LC_2__drv;
wire dut_RSTK_0__drv;
wire dut_RSTK_1__drv;
wire dut_RSTK_2__drv;
wire dut_RSTK_3__drv;
wire dut_StopMIRClk__drv;
wire dut_dBlock_p___drv;
wire dut_dFF_0__drv;
wire dut_dFF_1__drv;
wire dut_dFF_2__drv;
wire dut_dFF_3__drv;
wire dut_dFF_4__drv;
wire dut_dFF_5__drv;
wire dut_dFF_6__drv;
wire dut_dFF_7__drv;
wire dut_dIMOut_07__drv;
wire dut_dIMOut_08__drv;
wire dut_dIMOut_09__drv;
wire dut_dIMOut_10__drv;
wire dut_dIMOut_11__drv;
wire dut_dIMOut_12__drv;
wire dut_dIMOut_13__drv;
wire dut_dIMOut_14__drv;
wire dut_dIMOut_15__drv;
wire dut_dIMRH__drv;
wire dut_dJCN_0__drv;
wire dut_dJCN_1__drv;
wire dut_dJCN_2__drv;
wire dut_dJCN_3__drv;
wire dut_dJCN_4__drv;
wire dut_dJCN_5__drv;
wire dut_dJCN_6__drv;
wire dut_dJCN_7__drv;
wire dut_rMIRa__drv;
dorado_serial_ContB #(.SYSPER(4)) dut(
.sys_clk(clk),
.ALUF_0(stimulus[0] | dut_ALUF_0__drv),
.ALUF_1(stimulus[1] | dut_ALUF_1__drv),
.ALUF_2(stimulus[2] | dut_ALUF_2__drv),
.ALUF_3(stimulus[3] | dut_ALUF_3__drv),
.BMux_00(stimulus[4]),
.BMux_01(stimulus[5]),
.BMux_02(stimulus[6]),
.BMux_03(stimulus[7]),
.BMux_04(stimulus[8]),
.BMux_05(stimulus[9]),
.BMux_06(stimulus[10]),
.BMux_07(stimulus[11]),
.BMux_08(stimulus[12]),
.BMux_09(stimulus[13]),
.BMux_10(stimulus[14]),
.BMux_11(stimulus[15]),
.BMux_12(stimulus[16]),
.BMux_13(stimulus[17]),
.BMux_14(stimulus[18]),
.BMux_15(stimulus[19]),
.BMux_16(stimulus[20]),
.BMux_17(stimulus[21]),
.BNPC_02(stimulus[22]),
.BNPC_03(stimulus[23]),
.BNPC_04(stimulus[24] | dut_BNPC_04__drv),
.BNPC_05(stimulus[25] | dut_BNPC_05__drv),
.BNPC_06(stimulus[26] | dut_BNPC_06__drv),
.BNPC_07(stimulus[27] | dut_BNPC_07__drv),
.BNPC_08(stimulus[28] | dut_BNPC_08__drv),
.BNPC_09(stimulus[29] | dut_BNPC_09__drv),
.BNPC_10(stimulus[30] | dut_BNPC_10__drv),
.BNPC_11(stimulus[31] | dut_BNPC_11__drv),
.BNPC_12(stimulus[32] | dut_BNPC_12__drv),
.BNPC_13(stimulus[33] | dut_BNPC_13__drv),
.BNPC_14(stimulus[34] | dut_BNPC_14__drv),
.BNPC_15(stimulus[35] | dut_BNPC_15__drv),
.BNTGtCT_p_a(stimulus[36]),
.CBHold(stimulus[37]),
.CBTempSense(stimulus[38] | dut_CBTempSense__drv),
.CLK_cb_p_(stimulus[39]),
.CLKEnable_p_a(stimulus[40]),
.CPAddr_0_p_(stimulus[41]),
.CPAddr_1_p_(stimulus[42]),
.CPAddr_2_p_(stimulus[43]),
.CPOut_0(stimulus[44]),
.CPOut_1(stimulus[45]),
.CPOut_2(stimulus[46]),
.CPOut_3(stimulus[47]),
.CPOut_8(stimulus[48]),
.CPStrb_p_(stimulus[49]),
.CRamClock(stimulus[50]),
.DMuxClk(stimulus[51]),
.DMuxData(stimulus[52] | dut_DMuxData__drv),
.DoCBr(stimulus[53]),
.IMLHPE_p_(stimulus[54] | dut_IMLHPE_p___drv),
.IMLHPEDly(stimulus[55] | dut_IMLHPEDly__drv),
.IMRHPE_p_(stimulus[56]),
.IMRHPEDly(stimulus[57] | dut_IMRHPEDly__drv),
.IOPE(stimulus[58]),
.LC_0(stimulus[59] | dut_LC_0__drv),
.LC_1(stimulus[60] | dut_LC_1__drv),
.LC_2(stimulus[61] | dut_LC_2__drv),
.MdPE(stimulus[62]),
.MemPE(stimulus[63]),
.RamPE(stimulus[64]),
.SW(stimulus[65]),
.StartCycle_p_a(stimulus[66]),
.TNIA_02(stimulus[67]),
.TNIA_03(stimulus[68]),
.TNIA_04(stimulus[69]),
.TNIA_05(stimulus[70]),
.TNIA_06(stimulus[71]),
.TNIA_07(stimulus[72]),
.TNIA_08(stimulus[73]),
.TNIA_09(stimulus[74]),
.TNIA_10(stimulus[75]),
.TNIA_11(stimulus[76]),
.TNIA_12(stimulus[77]),
.TNIA_13(stimulus[78]),
.TNIA_14(stimulus[79]),
.TNIA_15(stimulus[80]),
.TempRef(stimulus[81]),
.UseDMD(stimulus[82]),
.dBlock_p_(stimulus[83] | dut_dBlock_p___drv),
.dFF_0(stimulus[84] | dut_dFF_0__drv),
.dFF_1(stimulus[85] | dut_dFF_1__drv),
.dFF_2(stimulus[86] | dut_dFF_2__drv),
.dFF_3(stimulus[87] | dut_dFF_3__drv),
.dFF_4(stimulus[88] | dut_dFF_4__drv),
.dFF_5(stimulus[89] | dut_dFF_5__drv),
.dFF_6(stimulus[90] | dut_dFF_6__drv),
.dFF_7(stimulus[91] | dut_dFF_7__drv),
.dIMRH(stimulus[92] | dut_dIMRH__drv),
.dJCN_0(stimulus[93] | dut_dJCN_0__drv),
.dJCN_1(stimulus[94] | dut_dJCN_1__drv),
.dJCN_2(stimulus[95] | dut_dJCN_2__drv),
.dJCN_3(stimulus[96] | dut_dJCN_3__drv),
.dJCN_4(stimulus[97] | dut_dJCN_4__drv),
.dJCN_5(stimulus[98] | dut_dJCN_5__drv),
.dJCN_6(stimulus[99] | dut_dJCN_6__drv),
.dJCN_7(stimulus[100] | dut_dJCN_7__drv),
.rMIRa(stimulus[101] | dut_rMIRa__drv),
.ALUF_0__drv(dut_ALUF_0__drv),
.ALUF_1__drv(dut_ALUF_1__drv),
.ALUF_2__drv(dut_ALUF_2__drv),
.ALUF_3__drv(dut_ALUF_3__drv),
.ASEL_0__drv(dut_ASEL_0__drv),
.ASEL_0_p___drv(dut_ASEL_0_p___drv),
.ASEL_0_p_a__drv(dut_ASEL_0_p_a__drv),
.ASEL_0_p_mem__drv(dut_ASEL_0_p_mem__drv),
.ASEL_1_p___drv(dut_ASEL_1_p___drv),
.ASEL_2_p___drv(dut_ASEL_2_p___drv),
.BNPC_04__drv(dut_BNPC_04__drv),
.BNPC_05__drv(dut_BNPC_05__drv),
.BNPC_06__drv(dut_BNPC_06__drv),
.BNPC_07__drv(dut_BNPC_07__drv),
.BNPC_08__drv(dut_BNPC_08__drv),
.BNPC_09__drv(dut_BNPC_09__drv),
.BNPC_10__drv(dut_BNPC_10__drv),
.BNPC_11__drv(dut_BNPC_11__drv),
.BNPC_12__drv(dut_BNPC_12__drv),
.BNPC_13__drv(dut_BNPC_13__drv),
.BNPC_14__drv(dut_BNPC_14__drv),
.BNPC_15__drv(dut_BNPC_15__drv),
.BSEL_0_p___drv(dut_BSEL_0_p___drv),
.BSEL_1_p___drv(dut_BSEL_1_p___drv),
.BSEL_2_p___drv(dut_BSEL_2_p___drv),
.CBTempSense__drv(dut_CBTempSense__drv),
.CPIn_0__drv(dut_CPIn_0__drv),
.CPIn_1__drv(dut_CPIn_1__drv),
.CPIn_2__drv(dut_CPIn_2__drv),
.CPIn_3__drv(dut_CPIn_3__drv),
.DMuxData__drv(dut_DMuxData__drv),
.Error_p___drv(dut_Error_p___drv),
.IMLHPE_p___drv(dut_IMLHPE_p___drv),
.IMLHPEDly__drv(dut_IMLHPEDly__drv),
.IMRHPEDly__drv(dut_IMRHPEDly__drv),
.LC_0__drv(dut_LC_0__drv),
.LC_1__drv(dut_LC_1__drv),
.LC_2__drv(dut_LC_2__drv),
.RSTK_0__drv(dut_RSTK_0__drv),
.RSTK_1__drv(dut_RSTK_1__drv),
.RSTK_2__drv(dut_RSTK_2__drv),
.RSTK_3__drv(dut_RSTK_3__drv),
.StopMIRClk__drv(dut_StopMIRClk__drv),
.dBlock_p___drv(dut_dBlock_p___drv),
.dFF_0__drv(dut_dFF_0__drv),
.dFF_1__drv(dut_dFF_1__drv),
.dFF_2__drv(dut_dFF_2__drv),
.dFF_3__drv(dut_dFF_3__drv),
.dFF_4__drv(dut_dFF_4__drv),
.dFF_5__drv(dut_dFF_5__drv),
.dFF_6__drv(dut_dFF_6__drv),
.dFF_7__drv(dut_dFF_7__drv),
.dIMOut_07__drv(dut_dIMOut_07__drv),
.dIMOut_08__drv(dut_dIMOut_08__drv),
.dIMOut_09__drv(dut_dIMOut_09__drv),
.dIMOut_10__drv(dut_dIMOut_10__drv),
.dIMOut_11__drv(dut_dIMOut_11__drv),
.dIMOut_12__drv(dut_dIMOut_12__drv),
.dIMOut_13__drv(dut_dIMOut_13__drv),
.dIMOut_14__drv(dut_dIMOut_14__drv),
.dIMOut_15__drv(dut_dIMOut_15__drv),
.dIMRH__drv(dut_dIMRH__drv),
.dJCN_0__drv(dut_dJCN_0__drv),
.dJCN_1__drv(dut_dJCN_1__drv),
.dJCN_2__drv(dut_dJCN_2__drv),
.dJCN_3__drv(dut_dJCN_3__drv),
.dJCN_4__drv(dut_dJCN_4__drv),
.dJCN_5__drv(dut_dJCN_5__drv),
.dJCN_6__drv(dut_dJCN_6__drv),
.dJCN_7__drv(dut_dJCN_7__drv),
.rMIRa__drv(dut_rMIRa__drv),
.state_host_clk(clk),
.state_guest_advance(board_steps[0]),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[14:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(all_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_rMIRa__drv,dut_dJCN_7__drv,dut_dJCN_6__drv,dut_dJCN_5__drv,dut_dJCN_4__drv,dut_dJCN_3__drv,dut_dJCN_2__drv,dut_dJCN_1__drv,dut_dJCN_0__drv,dut_dIMRH__drv,dut_dIMOut_15__drv,dut_dIMOut_14__drv,dut_dIMOut_13__drv,dut_dIMOut_12__drv,dut_dIMOut_11__drv,dut_dIMOut_10__drv,dut_dIMOut_09__drv,dut_dIMOut_08__drv,dut_dIMOut_07__drv,dut_dFF_7__drv,dut_dFF_6__drv,dut_dFF_5__drv,dut_dFF_4__drv,dut_dFF_3__drv,dut_dFF_2__drv,dut_dFF_1__drv,dut_dFF_0__drv,dut_dBlock_p___drv,dut_StopMIRClk__drv,dut_RSTK_3__drv,dut_RSTK_2__drv,dut_RSTK_1__drv,dut_RSTK_0__drv,dut_LC_2__drv,dut_LC_1__drv,dut_LC_0__drv,dut_IMRHPEDly__drv,dut_IMLHPEDly__drv,dut_IMLHPE_p___drv,dut_Error_p___drv,dut_DMuxData__drv,dut_CPIn_3__drv,dut_CPIn_2__drv,dut_CPIn_1__drv,dut_CPIn_0__drv,dut_CBTempSense__drv,dut_BSEL_2_p___drv,dut_BSEL_1_p___drv,dut_BSEL_0_p___drv,dut_BNPC_15__drv,dut_BNPC_14__drv,dut_BNPC_13__drv,dut_BNPC_12__drv,dut_BNPC_11__drv,dut_BNPC_10__drv,dut_BNPC_09__drv,dut_BNPC_08__drv,dut_BNPC_07__drv,dut_BNPC_06__drv,dut_BNPC_05__drv,dut_BNPC_04__drv,dut_ASEL_2_p___drv,dut_ASEL_1_p___drv,dut_ASEL_0_p_mem__drv,dut_ASEL_0_p_a__drv,dut_ASEL_0_p___drv,dut_ASEL_0__drv,dut_ALUF_3__drv,dut_ALUF_2__drv,dut_ALUF_1__drv,dut_ALUF_0__drv};
assign dut_state[0+:18]=dut.snapshot_bank_0.saved_q;
assign dut_state[18+:18]=dut.snapshot_bank_1.saved_q;
assign dut_state[36+:18]=dut.snapshot_bank_2.saved_q;
assign dut_state[54+:18]=dut.snapshot_bank_3.saved_q;
assign dut_state[72+:18]=dut.snapshot_bank_4.saved_q;
assign dut_state[90+:18]=dut.snapshot_bank_5.saved_q;
assign dut_state[108+:18]=dut.snapshot_bank_6.saved_q;
assign dut_state[126+:18]=dut.snapshot_bank_7.saved_q;
assign dut_state[144+:1]=dut.u_b02.ck_d;
assign dut_state[145+:6]=dut.u_b02.d_pre;
assign dut_state[151+:6]=dut.u_b02.q;
assign dut_state[157+:1]=dut.u_b23.cka_d;
assign dut_state[158+:1]=dut.u_b23.ckb_d;
assign dut_state[159+:1]=dut.u_b23.d_pre_a;
assign dut_state[160+:1]=dut.u_b23.d_pre_b;
assign dut_state[161+:1]=dut.u_b23.qa;
assign dut_state[162+:1]=dut.u_b23.qb;
assign dut_state[163+:1]=dut.u_b24.cka_d;
assign dut_state[164+:1]=dut.u_b24.ckb_d;
assign dut_state[165+:1]=dut.u_b24.d_pre_a;
assign dut_state[166+:1]=dut.u_b24.d_pre_b;
assign dut_state[167+:1]=dut.u_b24.qa;
assign dut_state[168+:1]=dut.u_b24.qb;
assign dut_state[169+:1]=dut.u_c02.ck_d;
assign dut_state[170+:6]=dut.u_c02.d_pre;
assign dut_state[176+:6]=dut.u_c02.q;
assign dut_state[182+:1]=dut.u_c04.ck_d;
assign dut_state[183+:6]=dut.u_c04.d_pre;
assign dut_state[189+:6]=dut.u_c04.q;
assign dut_state[195+:1]=dut.u_c24.cka_d;
assign dut_state[196+:1]=dut.u_c24.ckb_d;
assign dut_state[197+:1]=dut.u_c24.d_pre_a;
assign dut_state[198+:1]=dut.u_c24.d_pre_b;
assign dut_state[199+:1]=dut.u_c24.qa;
assign dut_state[200+:1]=dut.u_c24.qb;
assign dut_state[201+:1]=dut.u_d02.ck_d;
assign dut_state[202+:6]=dut.u_d02.d_pre;
assign dut_state[208+:6]=dut.u_d02.q;
assign dut_state[214+:1]=dut.u_f22.ck_d;
assign dut_state[215+:6]=dut.u_f22.d_pre;
assign dut_state[221+:6]=dut.u_f22.q;
assign dut_state[227+:1]=dut.u_g03.ck_d;
assign dut_state[228+:6]=dut.u_g03.d_pre;
assign dut_state[234+:6]=dut.u_g03.q;
assign dut_state[240+:1]=dut.u_g22.ck_d;
assign dut_state[241+:6]=dut.u_g22.d_pre;
assign dut_state[247+:6]=dut.u_g22.q;
assign dut_state[253+:1]=dut.u_g24.cka_d;
assign dut_state[254+:1]=dut.u_g24.ckb_d;
assign dut_state[255+:1]=dut.u_g24.d_pre_a;
assign dut_state[256+:1]=dut.u_g24.d_pre_b;
assign dut_state[257+:1]=dut.u_g24.qa;
assign dut_state[258+:1]=dut.u_g24.qb;
assign dut_state[259+:1]=dut.u_h01.cka_d;
assign dut_state[260+:1]=dut.u_h01.ckb_d;
assign dut_state[261+:1]=dut.u_h01.d_pre_a;
assign dut_state[262+:1]=dut.u_h01.d_pre_b;
assign dut_state[263+:1]=dut.u_h01.qa;
assign dut_state[264+:1]=dut.u_h01.qb;
assign dut_state[265+:1]=dut.u_h03.ck_d;
assign dut_state[266+:6]=dut.u_h03.d_pre;
assign dut_state[272+:6]=dut.u_h03.q;
assign dut_state[278+:1]=dut.u_h24.cka_d;
assign dut_state[279+:1]=dut.u_h24.ckb_d;
assign dut_state[280+:1]=dut.u_h24.d_pre_a;
assign dut_state[281+:1]=dut.u_h24.d_pre_b;
assign dut_state[282+:1]=dut.u_h24.qa;
assign dut_state[283+:1]=dut.u_h24.qb;
assign dut_state[284+:1]=dut.u_i01.cka_d;
assign dut_state[285+:1]=dut.u_i01.ckb_d;
assign dut_state[286+:1]=dut.u_i01.d_pre_a;
assign dut_state[287+:1]=dut.u_i01.d_pre_b;
assign dut_state[288+:1]=dut.u_i01.qa;
assign dut_state[289+:1]=dut.u_i01.qb;
assign dut_state[290+:1]=dut.u_i24.cka_d;
assign dut_state[291+:1]=dut.u_i24.ckb_d;
assign dut_state[292+:1]=dut.u_i24.d_pre_a;
assign dut_state[293+:1]=dut.u_i24.d_pre_b;
assign dut_state[294+:1]=dut.u_i24.qa;
assign dut_state[295+:1]=dut.u_i24.qb;
assign dut_state[296+:1]=dut.u_j01.cka_d;
assign dut_state[297+:1]=dut.u_j01.ckb_d;
assign dut_state[298+:1]=dut.u_j01.d_pre_a;
assign dut_state[299+:1]=dut.u_j01.d_pre_b;
assign dut_state[300+:1]=dut.u_j01.qa;
assign dut_state[301+:1]=dut.u_j01.qb;
assign dut_state[302+:1]=dut.u_j24.cka_d;
assign dut_state[303+:1]=dut.u_j24.ckb_d;
assign dut_state[304+:1]=dut.u_j24.d_pre_a;
assign dut_state[305+:1]=dut.u_j24.d_pre_b;
assign dut_state[306+:1]=dut.u_j24.qa;
assign dut_state[307+:1]=dut.u_j24.qb;
assign dut_state[308+:1]=dut.u_k24.cka_d;
assign dut_state[309+:1]=dut.u_k24.ckb_d;
assign dut_state[310+:1]=dut.u_k24.d_pre_a;
assign dut_state[311+:1]=dut.u_k24.d_pre_b;
assign dut_state[312+:1]=dut.u_k24.qa;
assign dut_state[313+:1]=dut.u_k24.qb;
assign dut_state[314+:1]=dut.u_l04.ck_d;
assign dut_state[315+:6]=dut.u_l04.d_pre;
assign dut_state[321+:6]=dut.u_l04.q;
assign dut_state[327+:1]=dut.u_l20.ck_d;
assign dut_state[328+:6]=dut.u_l20.d_pre;
assign dut_state[334+:6]=dut.u_l20.q;
assign dut_state[340+:1]=dut.u_l22.ck_d;
assign dut_state[341+:6]=dut.u_l22.d_pre;
assign dut_state[347+:6]=dut.u_l22.q;
assign dut_probe[0+:1]=dut.snapshot_bank_0.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[1+:1]=dut.snapshot_bank_0.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[2+:1]=dut.snapshot_bank_0.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[3+:1]=dut.snapshot_bank_0.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[4+:1]=dut.snapshot_bank_0.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[5+:1]=dut.snapshot_bank_0.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[6+:1]=dut.snapshot_bank_0.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[7+:1]=dut.snapshot_bank_0.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[8+:1]=dut.snapshot_bank_0.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[9+:1]=dut.snapshot_bank_0.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[10+:1]=dut.snapshot_bank_0.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[11+:1]=dut.snapshot_bank_0.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[12+:1]=dut.snapshot_bank_0.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[13+:1]=dut.snapshot_bank_0.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[14+:1]=dut.snapshot_bank_0.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[15+:1]=dut.snapshot_bank_0.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[16+:1]=dut.snapshot_bank_0.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[17+:1]=dut.snapshot_bank_0.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[18+:1]=dut.snapshot_bank_1.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[19+:1]=dut.snapshot_bank_1.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[20+:1]=dut.snapshot_bank_1.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[21+:1]=dut.snapshot_bank_1.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[22+:1]=dut.snapshot_bank_1.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[23+:1]=dut.snapshot_bank_1.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[24+:1]=dut.snapshot_bank_1.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[25+:1]=dut.snapshot_bank_1.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[26+:1]=dut.snapshot_bank_1.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[27+:1]=dut.snapshot_bank_1.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[28+:1]=dut.snapshot_bank_1.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[29+:1]=dut.snapshot_bank_1.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[30+:1]=dut.snapshot_bank_1.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[31+:1]=dut.snapshot_bank_1.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[32+:1]=dut.snapshot_bank_1.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[33+:1]=dut.snapshot_bank_1.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[34+:1]=dut.snapshot_bank_1.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[35+:1]=dut.snapshot_bank_1.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[36+:1]=dut.snapshot_bank_2.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[37+:1]=dut.snapshot_bank_2.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[38+:1]=dut.snapshot_bank_2.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[39+:1]=dut.snapshot_bank_2.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[40+:1]=dut.snapshot_bank_2.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[41+:1]=dut.snapshot_bank_2.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[42+:1]=dut.snapshot_bank_2.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[43+:1]=dut.snapshot_bank_2.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[44+:1]=dut.snapshot_bank_2.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[45+:1]=dut.snapshot_bank_2.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[46+:1]=dut.snapshot_bank_2.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[47+:1]=dut.snapshot_bank_2.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[48+:1]=dut.snapshot_bank_2.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[49+:1]=dut.snapshot_bank_2.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[50+:1]=dut.snapshot_bank_2.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[51+:1]=dut.snapshot_bank_2.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[52+:1]=dut.snapshot_bank_2.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[53+:1]=dut.snapshot_bank_2.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[54+:1]=dut.snapshot_bank_3.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[55+:1]=dut.snapshot_bank_3.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[56+:1]=dut.snapshot_bank_3.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[57+:1]=dut.snapshot_bank_3.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[58+:1]=dut.snapshot_bank_3.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[59+:1]=dut.snapshot_bank_3.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[60+:1]=dut.snapshot_bank_3.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[61+:1]=dut.snapshot_bank_3.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[62+:1]=dut.snapshot_bank_3.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[63+:1]=dut.snapshot_bank_3.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[64+:1]=dut.snapshot_bank_3.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[65+:1]=dut.snapshot_bank_3.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[66+:1]=dut.snapshot_bank_3.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[67+:1]=dut.snapshot_bank_3.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[68+:1]=dut.snapshot_bank_3.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[69+:1]=dut.snapshot_bank_3.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[70+:1]=dut.snapshot_bank_3.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[71+:1]=dut.snapshot_bank_3.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[72+:1]=dut.snapshot_bank_4.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[73+:1]=dut.snapshot_bank_4.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[74+:1]=dut.snapshot_bank_4.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[75+:1]=dut.snapshot_bank_4.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[76+:1]=dut.snapshot_bank_4.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[77+:1]=dut.snapshot_bank_4.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[78+:1]=dut.snapshot_bank_4.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[79+:1]=dut.snapshot_bank_4.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[80+:1]=dut.snapshot_bank_4.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[81+:1]=dut.snapshot_bank_4.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[82+:1]=dut.snapshot_bank_4.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[83+:1]=dut.snapshot_bank_4.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[84+:1]=dut.snapshot_bank_4.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[85+:1]=dut.snapshot_bank_4.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[86+:1]=dut.snapshot_bank_4.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[87+:1]=dut.snapshot_bank_4.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[88+:1]=dut.snapshot_bank_4.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[89+:1]=dut.snapshot_bank_4.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[90+:1]=dut.snapshot_bank_5.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[91+:1]=dut.snapshot_bank_5.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[92+:1]=dut.snapshot_bank_5.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[93+:1]=dut.snapshot_bank_5.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[94+:1]=dut.snapshot_bank_5.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[95+:1]=dut.snapshot_bank_5.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[96+:1]=dut.snapshot_bank_5.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[97+:1]=dut.snapshot_bank_5.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[98+:1]=dut.snapshot_bank_5.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[99+:1]=dut.snapshot_bank_5.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[100+:1]=dut.snapshot_bank_5.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[101+:1]=dut.snapshot_bank_5.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[102+:1]=dut.snapshot_bank_5.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[103+:1]=dut.snapshot_bank_5.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[104+:1]=dut.snapshot_bank_5.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[105+:1]=dut.snapshot_bank_5.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[106+:1]=dut.snapshot_bank_5.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[107+:1]=dut.snapshot_bank_5.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[108+:1]=dut.snapshot_bank_6.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[109+:1]=dut.snapshot_bank_6.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[110+:1]=dut.snapshot_bank_6.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[111+:1]=dut.snapshot_bank_6.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[112+:1]=dut.snapshot_bank_6.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[113+:1]=dut.snapshot_bank_6.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[114+:1]=dut.snapshot_bank_6.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[115+:1]=dut.snapshot_bank_6.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[116+:1]=dut.snapshot_bank_6.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[117+:1]=dut.snapshot_bank_6.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[118+:1]=dut.snapshot_bank_6.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[119+:1]=dut.snapshot_bank_6.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[120+:1]=dut.snapshot_bank_6.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[121+:1]=dut.snapshot_bank_6.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[122+:1]=dut.snapshot_bank_6.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[123+:1]=dut.snapshot_bank_6.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[124+:1]=dut.snapshot_bank_6.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[125+:1]=dut.snapshot_bank_6.bits[9].mem[0+(probe_index%1024)];
assign dut_probe[126+:1]=dut.snapshot_bank_7.bits[0].mem[0+(probe_index%1024)];
assign dut_probe[127+:1]=dut.snapshot_bank_7.bits[10].mem[0+(probe_index%1024)];
assign dut_probe[128+:1]=dut.snapshot_bank_7.bits[11].mem[0+(probe_index%1024)];
assign dut_probe[129+:1]=dut.snapshot_bank_7.bits[12].mem[0+(probe_index%1024)];
assign dut_probe[130+:1]=dut.snapshot_bank_7.bits[13].mem[0+(probe_index%1024)];
assign dut_probe[131+:1]=dut.snapshot_bank_7.bits[14].mem[0+(probe_index%1024)];
assign dut_probe[132+:1]=dut.snapshot_bank_7.bits[15].mem[0+(probe_index%1024)];
assign dut_probe[133+:1]=dut.snapshot_bank_7.bits[16].mem[0+(probe_index%1024)];
assign dut_probe[134+:1]=dut.snapshot_bank_7.bits[17].mem[0+(probe_index%1024)];
assign dut_probe[135+:1]=dut.snapshot_bank_7.bits[1].mem[0+(probe_index%1024)];
assign dut_probe[136+:1]=dut.snapshot_bank_7.bits[2].mem[0+(probe_index%1024)];
assign dut_probe[137+:1]=dut.snapshot_bank_7.bits[3].mem[0+(probe_index%1024)];
assign dut_probe[138+:1]=dut.snapshot_bank_7.bits[4].mem[0+(probe_index%1024)];
assign dut_probe[139+:1]=dut.snapshot_bank_7.bits[5].mem[0+(probe_index%1024)];
assign dut_probe[140+:1]=dut.snapshot_bank_7.bits[6].mem[0+(probe_index%1024)];
assign dut_probe[141+:1]=dut.snapshot_bank_7.bits[7].mem[0+(probe_index%1024)];
assign dut_probe[142+:1]=dut.snapshot_bank_7.bits[8].mem[0+(probe_index%1024)];
assign dut_probe[143+:1]=dut.snapshot_bank_7.bits[9].mem[0+(probe_index%1024)];
assign all_helpers_frozen=&{dut.snapshot_bank_0.frozen,dut.snapshot_bank_1.frozen,dut.snapshot_bank_2.frozen,dut.snapshot_bank_3.frozen,dut.snapshot_bank_4.frozen,dut.snapshot_bank_5.frozen,dut.snapshot_bank_6.frozen,dut.snapshot_bank_7.frozen};
endmodule
