constexpr unsigned STIM_BITS=79,SCAN_WORD=0,AUX_WORD=215040;
constexpr unsigned FF_BITS=974,FF_WORDS=55;
