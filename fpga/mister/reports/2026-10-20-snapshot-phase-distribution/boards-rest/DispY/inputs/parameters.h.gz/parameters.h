constexpr unsigned STIM_BITS=94,SCAN_WORD=0,AUX_WORD=286720;
constexpr unsigned FF_BITS=1439,FF_WORDS=80;
