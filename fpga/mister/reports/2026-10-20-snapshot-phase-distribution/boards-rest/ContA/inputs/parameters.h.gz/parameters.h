constexpr unsigned STIM_BITS=133,SCAN_WORD=0,AUX_WORD=2400;
constexpr unsigned FF_BITS=681,FF_WORDS=38;
