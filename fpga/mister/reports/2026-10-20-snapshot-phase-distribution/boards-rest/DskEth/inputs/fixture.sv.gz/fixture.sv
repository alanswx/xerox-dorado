module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [91:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [114:0] reference_outputs,dut_outputs,
 output wire [2655:0] reference_state,dut_state,
 output wire [0:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire all_hold=global_hold || (freeze && held) ||
 reference_hold || dut_hold || reference_fault || dut_fault;
 reg original_step=0;
 always @(negedge clk)original_step<=advance && !all_hold;
 wire [18:0] board_steps;
 dorado_board_phase_enable copies(.clk(clk),.permit(advance && !all_hold),.advance(board_steps));
 // All nineteen copies must remain identical, including scan and reset edges.
 always @(posedge clk)begin
  if(board_steps!=={19{original_step}})$fatal(1,"board phase copies differ");
 end
 wire [31:0] reference_receive_debug;
wire reference_ClockM0__drv;
wire reference_ClockM1__drv;
wire reference_ClockM2__drv;
wire reference_ClockM3__drv;
wire reference_ClockP0__drv;
wire reference_ClockP1__drv;
wire reference_ClockP2__drv;
wire reference_ClockP3__drv;
wire reference_ContTag_p___drv;
wire reference_CylinderTag_p___drv;
wire reference_DMuxData__drv;
wire reference_DataM0__drv;
wire reference_DataM1__drv;
wire reference_DataM2__drv;
wire reference_DataM3__drv;
wire reference_DataP0__drv;
wire reference_DataP1__drv;
wire reference_DataP2__drv;
wire reference_DataP3__drv;
wire reference_DriveTag_p___drv;
wire reference_HeadTag_p___drv;
wire reference_IOB_00__drv;
wire reference_IOB_01__drv;
wire reference_IOB_02__drv;
wire reference_IOB_03__drv;
wire reference_IOB_04__drv;
wire reference_IOB_05__drv;
wire reference_IOB_06__drv;
wire reference_IOB_07__drv;
wire reference_IOB_08__drv;
wire reference_IOB_09__drv;
wire reference_IOB_10__drv;
wire reference_IOB_11__drv;
wire reference_IOB_12__drv;
wire reference_IOB_13__drv;
wire reference_IOB_14__drv;
wire reference_IOB_15__drv;
wire reference_IOB_16__drv;
wire reference_IOB_17__drv;
wire reference_IOatt__drv;
wire reference_OKToSelect__drv;
wire reference_OS0__drv;
wire reference_OS1__drv;
wire reference_OS2__drv;
wire reference_OS3__drv;
wire reference_SecIndx0_p___drv;
wire reference_SecIndx1_p___drv;
wire reference_SecIndx2_p___drv;
wire reference_SecIndx3_p___drv;
wire reference_Select0_p___drv;
wire reference_Select1_p___drv;
wire reference_Select2_p___drv;
wire reference_Select3_p___drv;
wire reference_Selected0_p___drv;
wire reference_Selected1_p___drv;
wire reference_Selected2_p___drv;
wire reference_Selected3_p___drv;
wire reference_TWReq_06__drv;
wire reference_TWReq_07__drv;
wire reference_TWReq_12__drv;
wire reference_TagBus_0_p___drv;
wire reference_TagBus_00_p___drv;
wire reference_TagBus_000_p___drv;
wire reference_TagBus_1_p___drv;
wire reference_TagBus_2_p___drv;
wire reference_TagBus_3_p___drv;
wire reference_TagBus_4_p___drv;
wire reference_TagBus_5_p___drv;
wire reference_TagBus_6_p___drv;
wire reference_TagBus_7_p___drv;
wire reference_TagBus_8_p___drv;
wire reference_TagBus_9_p___drv;
wire reference_TtlDeviceCk_p___drv;
wire reference_TtlEndOfCyl_p___drv;
wire reference_TtlIndex_p___drv;
wire reference_TtlOffSet_p___drv;
wire reference_TtlOnLine_p___drv;
wire reference_TtlReadOnly_p___drv;
wire reference_TtlReady_p___drv;
wire reference_TtlSector_p___drv;
wire reference_TtlSeekInc_p___drv;
wire reference_TtlTerm_p___drv;
wire reference_XmtData_p___drv;
DskEth_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.BNTGtCT_p_b(stimulus[0]),
.Block(stimulus[1]),
.CLK_disk_p_(stimulus[2]),
.CLKEnable_p_a(stimulus[3]),
.ClockM0(stimulus[4] | reference_ClockM0__drv),
.ClockM1(stimulus[5] | reference_ClockM1__drv),
.ClockM2(stimulus[6] | reference_ClockM2__drv),
.ClockM3(stimulus[7] | reference_ClockM3__drv),
.ClockP0(stimulus[8] | reference_ClockP0__drv),
.ClockP1(stimulus[9] | reference_ClockP1__drv),
.ClockP2(stimulus[10] | reference_ClockP2__drv),
.ClockP3(stimulus[11] | reference_ClockP3__drv),
.Collision(stimulus[12]),
.DMuxClk(stimulus[13]),
.DMuxData(stimulus[14] | reference_DMuxData__drv),
.DataM0(stimulus[15] | reference_DataM0__drv),
.DataM1(stimulus[16] | reference_DataM1__drv),
.DataM2(stimulus[17] | reference_DataM2__drv),
.DataM3(stimulus[18] | reference_DataM3__drv),
.DataP0(stimulus[19] | reference_DataP0__drv),
.DataP1(stimulus[20] | reference_DataP1__drv),
.DataP2(stimulus[21] | reference_DataP2__drv),
.DataP3(stimulus[22] | reference_DataP3__drv),
.Host_0(stimulus[23]),
.Host_1(stimulus[24]),
.Host_2(stimulus[25]),
.Host_3(stimulus[26]),
.Host_4(stimulus[27]),
.Host_5(stimulus[28]),
.Host_6(stimulus[29]),
.Host_7(stimulus[30]),
.IOB_00(stimulus[31] | reference_IOB_00__drv),
.IOB_01(stimulus[32] | reference_IOB_01__drv),
.IOB_02(stimulus[33] | reference_IOB_02__drv),
.IOB_03(stimulus[34] | reference_IOB_03__drv),
.IOB_04(stimulus[35] | reference_IOB_04__drv),
.IOB_05(stimulus[36] | reference_IOB_05__drv),
.IOB_06(stimulus[37] | reference_IOB_06__drv),
.IOB_07(stimulus[38] | reference_IOB_07__drv),
.IOB_08(stimulus[39] | reference_IOB_08__drv),
.IOB_09(stimulus[40] | reference_IOB_09__drv),
.IOB_10(stimulus[41] | reference_IOB_10__drv),
.IOB_11(stimulus[42] | reference_IOB_11__drv),
.IOB_12(stimulus[43] | reference_IOB_12__drv),
.IOB_13(stimulus[44] | reference_IOB_13__drv),
.IOB_14(stimulus[45] | reference_IOB_14__drv),
.IOB_15(stimulus[46] | reference_IOB_15__drv),
.IOB_16(stimulus[47] | reference_IOB_16__drv),
.IOB_17(stimulus[48] | reference_IOB_17__drv),
.IOHold(stimulus[49]),
.IOReset(stimulus[50]),
.IOin_p_(stimulus[51]),
.IOout_p_(stimulus[52]),
.MemSH_p_(stimulus[53]),
.Next_0(stimulus[54]),
.Next_1(stimulus[55]),
.Next_2(stimulus[56]),
.Next_3(stimulus[57]),
.OKToSelect(stimulus[58] | reference_OKToSelect__drv),
.OS0(stimulus[59] | reference_OS0__drv),
.OS1(stimulus[60] | reference_OS1__drv),
.OS2(stimulus[61] | reference_OS2__drv),
.OS3(stimulus[62] | reference_OS3__drv),
.Pendulum(stimulus[63]),
.RcvData(stimulus[64]),
.SecIndx0_p_(stimulus[65] | reference_SecIndx0_p___drv),
.SecIndx1_p_(stimulus[66] | reference_SecIndx1_p___drv),
.SecIndx2_p_(stimulus[67] | reference_SecIndx2_p___drv),
.SecIndx3_p_(stimulus[68] | reference_SecIndx3_p___drv),
.Selected0_p_(stimulus[69] | reference_Selected0_p___drv),
.Selected1_p_(stimulus[70] | reference_Selected1_p___drv),
.Selected2_p_(stimulus[71] | reference_Selected2_p___drv),
.Selected3_p_(stimulus[72] | reference_Selected3_p___drv),
.TIOA_0(stimulus[73]),
.TIOA_1(stimulus[74]),
.TIOA_2(stimulus[75]),
.TIOA_3(stimulus[76]),
.TIOA_4(stimulus[77]),
.TIOA_5(stimulus[78]),
.TIOA_6(stimulus[79]),
.TIOA_7(stimulus[80]),
.TempRef(stimulus[81]),
.TtlDeviceCk_p_(stimulus[82] | reference_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p_(stimulus[83] | reference_TtlEndOfCyl_p___drv),
.TtlIndex_p_(stimulus[84] | reference_TtlIndex_p___drv),
.TtlOffSet_p_(stimulus[85] | reference_TtlOffSet_p___drv),
.TtlOnLine_p_(stimulus[86] | reference_TtlOnLine_p___drv),
.TtlReadOnly_p_(stimulus[87] | reference_TtlReadOnly_p___drv),
.TtlReady_p_(stimulus[88] | reference_TtlReady_p___drv),
.TtlSector_p_(stimulus[89] | reference_TtlSector_p___drv),
.TtlSeekInc_p_(stimulus[90] | reference_TtlSeekInc_p___drv),
.TtlTerm_p_(stimulus[91] | reference_TtlTerm_p___drv),
.receive_debug(reference_receive_debug),
.ClockM0__drv(reference_ClockM0__drv),
.ClockM1__drv(reference_ClockM1__drv),
.ClockM2__drv(reference_ClockM2__drv),
.ClockM3__drv(reference_ClockM3__drv),
.ClockP0__drv(reference_ClockP0__drv),
.ClockP1__drv(reference_ClockP1__drv),
.ClockP2__drv(reference_ClockP2__drv),
.ClockP3__drv(reference_ClockP3__drv),
.ContTag_p___drv(reference_ContTag_p___drv),
.CylinderTag_p___drv(reference_CylinderTag_p___drv),
.DMuxData__drv(reference_DMuxData__drv),
.DataM0__drv(reference_DataM0__drv),
.DataM1__drv(reference_DataM1__drv),
.DataM2__drv(reference_DataM2__drv),
.DataM3__drv(reference_DataM3__drv),
.DataP0__drv(reference_DataP0__drv),
.DataP1__drv(reference_DataP1__drv),
.DataP2__drv(reference_DataP2__drv),
.DataP3__drv(reference_DataP3__drv),
.DriveTag_p___drv(reference_DriveTag_p___drv),
.HeadTag_p___drv(reference_HeadTag_p___drv),
.IOB_00__drv(reference_IOB_00__drv),
.IOB_01__drv(reference_IOB_01__drv),
.IOB_02__drv(reference_IOB_02__drv),
.IOB_03__drv(reference_IOB_03__drv),
.IOB_04__drv(reference_IOB_04__drv),
.IOB_05__drv(reference_IOB_05__drv),
.IOB_06__drv(reference_IOB_06__drv),
.IOB_07__drv(reference_IOB_07__drv),
.IOB_08__drv(reference_IOB_08__drv),
.IOB_09__drv(reference_IOB_09__drv),
.IOB_10__drv(reference_IOB_10__drv),
.IOB_11__drv(reference_IOB_11__drv),
.IOB_12__drv(reference_IOB_12__drv),
.IOB_13__drv(reference_IOB_13__drv),
.IOB_14__drv(reference_IOB_14__drv),
.IOB_15__drv(reference_IOB_15__drv),
.IOB_16__drv(reference_IOB_16__drv),
.IOB_17__drv(reference_IOB_17__drv),
.IOatt__drv(reference_IOatt__drv),
.OKToSelect__drv(reference_OKToSelect__drv),
.OS0__drv(reference_OS0__drv),
.OS1__drv(reference_OS1__drv),
.OS2__drv(reference_OS2__drv),
.OS3__drv(reference_OS3__drv),
.SecIndx0_p___drv(reference_SecIndx0_p___drv),
.SecIndx1_p___drv(reference_SecIndx1_p___drv),
.SecIndx2_p___drv(reference_SecIndx2_p___drv),
.SecIndx3_p___drv(reference_SecIndx3_p___drv),
.Select0_p___drv(reference_Select0_p___drv),
.Select1_p___drv(reference_Select1_p___drv),
.Select2_p___drv(reference_Select2_p___drv),
.Select3_p___drv(reference_Select3_p___drv),
.Selected0_p___drv(reference_Selected0_p___drv),
.Selected1_p___drv(reference_Selected1_p___drv),
.Selected2_p___drv(reference_Selected2_p___drv),
.Selected3_p___drv(reference_Selected3_p___drv),
.TWReq_06__drv(reference_TWReq_06__drv),
.TWReq_07__drv(reference_TWReq_07__drv),
.TWReq_12__drv(reference_TWReq_12__drv),
.TagBus_0_p___drv(reference_TagBus_0_p___drv),
.TagBus_00_p___drv(reference_TagBus_00_p___drv),
.TagBus_000_p___drv(reference_TagBus_000_p___drv),
.TagBus_1_p___drv(reference_TagBus_1_p___drv),
.TagBus_2_p___drv(reference_TagBus_2_p___drv),
.TagBus_3_p___drv(reference_TagBus_3_p___drv),
.TagBus_4_p___drv(reference_TagBus_4_p___drv),
.TagBus_5_p___drv(reference_TagBus_5_p___drv),
.TagBus_6_p___drv(reference_TagBus_6_p___drv),
.TagBus_7_p___drv(reference_TagBus_7_p___drv),
.TagBus_8_p___drv(reference_TagBus_8_p___drv),
.TagBus_9_p___drv(reference_TagBus_9_p___drv),
.TtlDeviceCk_p___drv(reference_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p___drv(reference_TtlEndOfCyl_p___drv),
.TtlIndex_p___drv(reference_TtlIndex_p___drv),
.TtlOffSet_p___drv(reference_TtlOffSet_p___drv),
.TtlOnLine_p___drv(reference_TtlOnLine_p___drv),
.TtlReadOnly_p___drv(reference_TtlReadOnly_p___drv),
.TtlReady_p___drv(reference_TtlReady_p___drv),
.TtlSector_p___drv(reference_TtlSector_p___drv),
.TtlSeekInc_p___drv(reference_TtlSeekInc_p___drv),
.TtlTerm_p___drv(reference_TtlTerm_p___drv),
.XmtData_p___drv(reference_XmtData_p___drv),
.state_host_clk(clk),
.state_guest_advance(original_step),
.state_freeze(freeze || all_hold),
.state_guest_held(held || all_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[12:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_XmtData_p___drv,reference_TtlTerm_p___drv,reference_TtlSeekInc_p___drv,reference_TtlSector_p___drv,reference_TtlReady_p___drv,reference_TtlReadOnly_p___drv,reference_TtlOnLine_p___drv,reference_TtlOffSet_p___drv,reference_TtlIndex_p___drv,reference_TtlEndOfCyl_p___drv,reference_TtlDeviceCk_p___drv,reference_TagBus_9_p___drv,reference_TagBus_8_p___drv,reference_TagBus_7_p___drv,reference_TagBus_6_p___drv,reference_TagBus_5_p___drv,reference_TagBus_4_p___drv,reference_TagBus_3_p___drv,reference_TagBus_2_p___drv,reference_TagBus_1_p___drv,reference_TagBus_000_p___drv,reference_TagBus_00_p___drv,reference_TagBus_0_p___drv,reference_TWReq_12__drv,reference_TWReq_07__drv,reference_TWReq_06__drv,reference_Selected3_p___drv,reference_Selected2_p___drv,reference_Selected1_p___drv,reference_Selected0_p___drv,reference_Select3_p___drv,reference_Select2_p___drv,reference_Select1_p___drv,reference_Select0_p___drv,reference_SecIndx3_p___drv,reference_SecIndx2_p___drv,reference_SecIndx1_p___drv,reference_SecIndx0_p___drv,reference_OS3__drv,reference_OS2__drv,reference_OS1__drv,reference_OS0__drv,reference_OKToSelect__drv,reference_IOatt__drv,reference_IOB_17__drv,reference_IOB_16__drv,reference_IOB_15__drv,reference_IOB_14__drv,reference_IOB_13__drv,reference_IOB_12__drv,reference_IOB_11__drv,reference_IOB_10__drv,reference_IOB_09__drv,reference_IOB_08__drv,reference_IOB_07__drv,reference_IOB_06__drv,reference_IOB_05__drv,reference_IOB_04__drv,reference_IOB_03__drv,reference_IOB_02__drv,reference_IOB_01__drv,reference_IOB_00__drv,reference_HeadTag_p___drv,reference_DriveTag_p___drv,reference_DataP3__drv,reference_DataP2__drv,reference_DataP1__drv,reference_DataP0__drv,reference_DataM3__drv,reference_DataM2__drv,reference_DataM1__drv,reference_DataM0__drv,reference_DMuxData__drv,reference_CylinderTag_p___drv,reference_ContTag_p___drv,reference_ClockP3__drv,reference_ClockP2__drv,reference_ClockP1__drv,reference_ClockP0__drv,reference_ClockM3__drv,reference_ClockM2__drv,reference_ClockM1__drv,reference_ClockM0__drv,reference_receive_debug};
assign reference_state[0+:1]=reference.Clk1;
assign reference_state[1+:1]=reference.Clock1_p_Bb;
assign reference_state[2+:1]=reference.Clock1_p_Bd;
assign reference_state[3+:1]=reference.Clock1_p_Ca;
assign reference_state[4+:1]=reference.Clock1_p_Cb;
assign reference_state[5+:1]=reference.Clock1_p_Cc;
assign reference_state[6+:1]=reference.Clock1_p_Da;
assign reference_state[7+:1]=reference.Clock1_p_Db;
assign reference_state[8+:1]=reference.Clock1_p_Dd;
assign reference_state[9+:1]=reference.u_a01.ck_d;
assign reference_state[10+:1]=reference.u_a01.p10_d;
assign reference_state[11+:1]=reference.u_a01.p7_d;
assign reference_state[12+:1]=reference.u_a01.p9_d;
assign reference_state[13+:4]=reference.u_a01.q;
assign reference_state[17+:1]=reference.u_a02.ck_d;
assign reference_state[18+:1]=reference.u_a02.p10_d;
assign reference_state[19+:1]=reference.u_a02.p7_d;
assign reference_state[20+:1]=reference.u_a02.p9_d;
assign reference_state[21+:4]=reference.u_a02.q;
assign reference_state[25+:1]=reference.u_a03.a1_d;
assign reference_state[26+:1]=reference.u_a03.a2_d;
assign reference_state[27+:1]=reference.u_a03.b1_d;
assign reference_state[28+:1]=reference.u_a03.b2_d;
assign reference_state[29+:1]=reference.u_a03.c1_d;
assign reference_state[30+:1]=reference.u_a03.c2_d;
assign reference_state[31+:32]=reference.u_a03.t1;
assign reference_state[63+:32]=reference.u_a03.t2;
assign reference_state[95+:1]=reference.u_a05.a1_d;
assign reference_state[96+:1]=reference.u_a05.a2_d;
assign reference_state[97+:1]=reference.u_a05.b1_d;
assign reference_state[98+:1]=reference.u_a05.b2_d;
assign reference_state[99+:1]=reference.u_a05.c1_d;
assign reference_state[100+:1]=reference.u_a05.c2_d;
assign reference_state[101+:32]=reference.u_a05.t1;
assign reference_state[133+:32]=reference.u_a05.t2;
assign reference_state[165+:1]=reference.u_a06.ck_d;
assign reference_state[166+:1]=reference.u_a06.p10_d;
assign reference_state[167+:1]=reference.u_a06.p7_d;
assign reference_state[168+:1]=reference.u_a06.p9_d;
assign reference_state[169+:4]=reference.u_a06.q;
assign reference_state[173+:1]=reference.u_a07.ck_d;
assign reference_state[174+:1]=reference.u_a07.p10_d;
assign reference_state[175+:1]=reference.u_a07.p7_d;
assign reference_state[176+:1]=reference.u_a07.p9_d;
assign reference_state[177+:4]=reference.u_a07.q;
assign reference_state[181+:1]=reference.u_a08.ck_d;
assign reference_state[182+:6]=reference.u_a08.d_pre;
assign reference_state[188+:6]=reference.u_a08.q;
assign reference_state[194+:1]=reference.u_a09.ck_d;
assign reference_state[195+:6]=reference.u_a09.d_pre;
assign reference_state[201+:6]=reference.u_a09.q;
assign reference_state[207+:1]=reference.u_a10.ck_d;
assign reference_state[208+:6]=reference.u_a10.d_pre;
assign reference_state[214+:6]=reference.u_a10.q;
assign reference_state[220+:1]=reference.u_a11.ck_d;
assign reference_state[221+:6]=reference.u_a11.d_pre;
assign reference_state[227+:6]=reference.u_a11.q;
assign reference_state[233+:1]=reference.u_a15.ck_d;
assign reference_state[234+:4]=reference.u_a15.q;
assign reference_state[238+:6]=reference.u_a15.setup_pre;
assign reference_state[244+:1]=reference.u_a16.ck_d;
assign reference_state[245+:4]=reference.u_a16.q;
assign reference_state[249+:6]=reference.u_a16.setup_pre;
assign reference_state[255+:1]=reference.u_a22.ck_d;
assign reference_state[256+:4]=reference.u_a22.q;
assign reference_state[260+:6]=reference.u_a22.setup_pre;
assign reference_state[266+:1]=reference.u_b03.ck_d;
assign reference_state[267+:6]=reference.u_b03.d_pre;
assign reference_state[273+:6]=reference.u_b03.q;
assign reference_state[279+:1]=reference.u_b04.ck_d;
assign reference_state[280+:6]=reference.u_b04.d_pre;
assign reference_state[286+:6]=reference.u_b04.q;
assign reference_state[292+:1]=reference.u_b05.ck_d;
assign reference_state[293+:6]=reference.u_b05.d_pre;
assign reference_state[299+:6]=reference.u_b05.q;
assign reference_state[305+:1]=reference.u_b06.ck_d;
assign reference_state[306+:6]=reference.u_b06.d_pre;
assign reference_state[312+:6]=reference.u_b06.q;
assign reference_state[318+:1]=reference.u_b09.cka_d;
assign reference_state[319+:1]=reference.u_b09.ckb_d;
assign reference_state[320+:1]=reference.u_b09.d_pre_a;
assign reference_state[321+:1]=reference.u_b09.d_pre_b;
assign reference_state[322+:1]=reference.u_b09.qa;
assign reference_state[323+:1]=reference.u_b09.qb;
assign reference_state[324+:1]=reference.u_b10.ck_d;
assign reference_state[325+:4]=reference.u_b10.q;
assign reference_state[329+:6]=reference.u_b10.setup_pre;
assign reference_state[335+:1]=reference.u_b12.cka_d;
assign reference_state[336+:1]=reference.u_b12.ckb_d;
assign reference_state[337+:1]=reference.u_b12.d_pre_a;
assign reference_state[338+:1]=reference.u_b12.d_pre_b;
assign reference_state[339+:1]=reference.u_b12.qa;
assign reference_state[340+:1]=reference.u_b12.qb;
assign reference_state[341+:1]=reference.u_b15.cka_d;
assign reference_state[342+:1]=reference.u_b15.ckb_d;
assign reference_state[343+:1]=reference.u_b15.d_pre_a;
assign reference_state[344+:1]=reference.u_b15.d_pre_b;
assign reference_state[345+:1]=reference.u_b15.qa;
assign reference_state[346+:1]=reference.u_b15.qb;
assign reference_state[347+:1]=reference.u_b20.ck_d;
assign reference_state[348+:4]=reference.u_b20.q;
assign reference_state[352+:6]=reference.u_b20.setup_pre;
assign reference_state[358+:1]=reference.u_b21.ck_d;
assign reference_state[359+:4]=reference.u_b21.q;
assign reference_state[363+:6]=reference.u_b21.setup_pre;
assign reference_state[369+:1]=reference.u_c01.qa;
assign reference_state[370+:1]=reference.u_c01.qb;
assign reference_state[371+:1]=reference.u_c02.qa;
assign reference_state[372+:1]=reference.u_c02.qb;
assign reference_state[373+:1]=reference.u_c07.ck_d;
assign reference_state[374+:6]=reference.u_c07.d_pre;
assign reference_state[380+:6]=reference.u_c07.q;
assign reference_state[386+:1]=reference.u_c08.ck_d;
assign reference_state[387+:6]=reference.u_c08.d_pre;
assign reference_state[393+:6]=reference.u_c08.q;
assign reference_state[399+:1]=reference.u_c09.cka_d;
assign reference_state[400+:1]=reference.u_c09.ckb_d;
assign reference_state[401+:1]=reference.u_c09.d_pre_a;
assign reference_state[402+:1]=reference.u_c09.d_pre_b;
assign reference_state[403+:1]=reference.u_c09.qa;
assign reference_state[404+:1]=reference.u_c09.qb;
assign reference_state[405+:1]=reference.u_c14.ck_d;
assign reference_state[406+:6]=reference.u_c14.d_pre;
assign reference_state[412+:6]=reference.u_c14.q;
assign reference_state[418+:1]=reference.u_c15.cka_d;
assign reference_state[419+:1]=reference.u_c15.ckb_d;
assign reference_state[420+:1]=reference.u_c15.d_pre_a;
assign reference_state[421+:1]=reference.u_c15.d_pre_b;
assign reference_state[422+:1]=reference.u_c15.qa;
assign reference_state[423+:1]=reference.u_c15.qb;
assign reference_state[424+:1]=reference.u_c16.ck_d;
assign reference_state[425+:4]=reference.u_c16.jk_pre;
assign reference_state[429+:1]=reference.u_c16.qa;
assign reference_state[430+:1]=reference.u_c16.qb;
assign reference_state[431+:1]=reference.u_c19.cin_pre;
assign reference_state[432+:1]=reference.u_c19.ck_d;
assign reference_state[433+:4]=reference.u_c19.d_pre;
assign reference_state[437+:4]=reference.u_c19.q;
assign reference_state[441+:1]=reference.u_c19.sd_pre;
assign reference_state[442+:1]=reference.u_c19.su_pre;
assign reference_state[443+:1]=reference.u_c20.cin_pre;
assign reference_state[444+:1]=reference.u_c20.ck_d;
assign reference_state[445+:4]=reference.u_c20.d_pre;
assign reference_state[449+:4]=reference.u_c20.q;
assign reference_state[453+:1]=reference.u_c20.sd_pre;
assign reference_state[454+:1]=reference.u_c20.su_pre;
assign reference_state[455+:1]=reference.u_c21.cin_pre;
assign reference_state[456+:1]=reference.u_c21.ck_d;
assign reference_state[457+:4]=reference.u_c21.d_pre;
assign reference_state[461+:4]=reference.u_c21.q;
assign reference_state[465+:1]=reference.u_c21.sd_pre;
assign reference_state[466+:1]=reference.u_c21.su_pre;
assign reference_state[467+:1]=reference.u_d04.ck_d;
assign reference_state[468+:6]=reference.u_d04.d_pre;
assign reference_state[474+:6]=reference.u_d04.q;
assign reference_state[480+:4]=reference.u_d08.a_lat;
assign reference_state[484+:1]=reference.u_d08.ce_lat;
assign reference_state[485+:4]=reference.u_d08.d_lat;
assign reference_state[489+:64]={reference.u_d08.mem[15],reference.u_d08.mem[14],reference.u_d08.mem[13],reference.u_d08.mem[12],reference.u_d08.mem[11],reference.u_d08.mem[10],reference.u_d08.mem[9],reference.u_d08.mem[8],reference.u_d08.mem[7],reference.u_d08.mem[6],reference.u_d08.mem[5],reference.u_d08.mem[4],reference.u_d08.mem[3],reference.u_d08.mem[2],reference.u_d08.mem[1],reference.u_d08.mem[0]};
assign reference_state[553+:1]=reference.u_d08.we_d;
assign reference_state[554+:4]=reference.u_d09.a_lat;
assign reference_state[558+:1]=reference.u_d09.ce_lat;
assign reference_state[559+:4]=reference.u_d09.d_lat;
assign reference_state[563+:64]={reference.u_d09.mem[15],reference.u_d09.mem[14],reference.u_d09.mem[13],reference.u_d09.mem[12],reference.u_d09.mem[11],reference.u_d09.mem[10],reference.u_d09.mem[9],reference.u_d09.mem[8],reference.u_d09.mem[7],reference.u_d09.mem[6],reference.u_d09.mem[5],reference.u_d09.mem[4],reference.u_d09.mem[3],reference.u_d09.mem[2],reference.u_d09.mem[1],reference.u_d09.mem[0]};
assign reference_state[627+:1]=reference.u_d09.we_d;
assign reference_state[628+:4]=reference.u_d10.a_lat;
assign reference_state[632+:1]=reference.u_d10.ce_lat;
assign reference_state[633+:4]=reference.u_d10.d_lat;
assign reference_state[637+:64]={reference.u_d10.mem[15],reference.u_d10.mem[14],reference.u_d10.mem[13],reference.u_d10.mem[12],reference.u_d10.mem[11],reference.u_d10.mem[10],reference.u_d10.mem[9],reference.u_d10.mem[8],reference.u_d10.mem[7],reference.u_d10.mem[6],reference.u_d10.mem[5],reference.u_d10.mem[4],reference.u_d10.mem[3],reference.u_d10.mem[2],reference.u_d10.mem[1],reference.u_d10.mem[0]};
assign reference_state[701+:1]=reference.u_d10.we_d;
assign reference_state[702+:4]=reference.u_d11.a_lat;
assign reference_state[706+:1]=reference.u_d11.ce_lat;
assign reference_state[707+:4]=reference.u_d11.d_lat;
assign reference_state[711+:64]={reference.u_d11.mem[15],reference.u_d11.mem[14],reference.u_d11.mem[13],reference.u_d11.mem[12],reference.u_d11.mem[11],reference.u_d11.mem[10],reference.u_d11.mem[9],reference.u_d11.mem[8],reference.u_d11.mem[7],reference.u_d11.mem[6],reference.u_d11.mem[5],reference.u_d11.mem[4],reference.u_d11.mem[3],reference.u_d11.mem[2],reference.u_d11.mem[1],reference.u_d11.mem[0]};
assign reference_state[775+:1]=reference.u_d11.we_d;
assign reference_state[776+:4]=reference.u_d12.a_lat;
assign reference_state[780+:1]=reference.u_d12.ce_lat;
assign reference_state[781+:4]=reference.u_d12.d_lat;
assign reference_state[785+:64]={reference.u_d12.mem[15],reference.u_d12.mem[14],reference.u_d12.mem[13],reference.u_d12.mem[12],reference.u_d12.mem[11],reference.u_d12.mem[10],reference.u_d12.mem[9],reference.u_d12.mem[8],reference.u_d12.mem[7],reference.u_d12.mem[6],reference.u_d12.mem[5],reference.u_d12.mem[4],reference.u_d12.mem[3],reference.u_d12.mem[2],reference.u_d12.mem[1],reference.u_d12.mem[0]};
assign reference_state[849+:1]=reference.u_d12.we_d;
assign reference_state[850+:4]=reference.u_d18.q;
assign reference_state[854+:4]=reference.u_d19.q;
assign reference_state[858+:1]=reference.u_d20.ck_d;
assign reference_state[859+:4]=reference.u_d20.jk_pre;
assign reference_state[863+:1]=reference.u_d20.qa;
assign reference_state[864+:1]=reference.u_d20.qb;
assign reference_state[865+:1]=reference.u_d22.ck_d;
assign reference_state[866+:4]=reference.u_d22.q;
assign reference_state[870+:6]=reference.u_d22.setup_pre;
assign reference_state[876+:5]=reference.u_e02.q;
assign reference_state[881+:1]=reference.u_e04.cka_d;
assign reference_state[882+:1]=reference.u_e04.ckb_d;
assign reference_state[883+:1]=reference.u_e04.d_pre_a;
assign reference_state[884+:1]=reference.u_e04.d_pre_b;
assign reference_state[885+:1]=reference.u_e04.qa;
assign reference_state[886+:1]=reference.u_e04.qb;
assign reference_state[887+:1]=reference.u_e05.cka_d;
assign reference_state[888+:1]=reference.u_e05.ckb_d;
assign reference_state[889+:1]=reference.u_e05.d_pre_a;
assign reference_state[890+:1]=reference.u_e05.d_pre_b;
assign reference_state[891+:1]=reference.u_e05.qa;
assign reference_state[892+:1]=reference.u_e05.qb;
assign reference_state[893+:1]=reference.u_e06.cka_d;
assign reference_state[894+:1]=reference.u_e06.ckb_d;
assign reference_state[895+:1]=reference.u_e06.d_pre_a;
assign reference_state[896+:1]=reference.u_e06.d_pre_b;
assign reference_state[897+:1]=reference.u_e06.qa;
assign reference_state[898+:1]=reference.u_e06.qb;
assign reference_state[899+:1]=reference.u_e08.ck_d;
assign reference_state[900+:6]=reference.u_e08.d_pre;
assign reference_state[906+:6]=reference.u_e08.q;
assign reference_state[912+:1]=reference.u_e10.ck_d;
assign reference_state[913+:6]=reference.u_e10.d_pre;
assign reference_state[919+:6]=reference.u_e10.q;
assign reference_state[925+:1]=reference.u_e12.ck_d;
assign reference_state[926+:6]=reference.u_e12.d_pre;
assign reference_state[932+:6]=reference.u_e12.q;
assign reference_state[938+:1]=reference.u_e13.ck_d;
assign reference_state[939+:4]=reference.u_e13.jk_pre;
assign reference_state[943+:1]=reference.u_e13.qa;
assign reference_state[944+:1]=reference.u_e13.qb;
assign reference_state[945+:1]=reference.u_e14.cka_d;
assign reference_state[946+:1]=reference.u_e14.ckb_d;
assign reference_state[947+:1]=reference.u_e14.d_pre_a;
assign reference_state[948+:1]=reference.u_e14.d_pre_b;
assign reference_state[949+:1]=reference.u_e14.qa;
assign reference_state[950+:1]=reference.u_e14.qb;
assign reference_state[951+:1]=reference.u_e15.cka_d;
assign reference_state[952+:1]=reference.u_e15.ckb_d;
assign reference_state[953+:1]=reference.u_e15.d_pre_a;
assign reference_state[954+:1]=reference.u_e15.d_pre_b;
assign reference_state[955+:1]=reference.u_e15.qa;
assign reference_state[956+:1]=reference.u_e15.qb;
assign reference_state[957+:4]=reference.u_e16.a_lat;
assign reference_state[961+:1]=reference.u_e16.ce_lat;
assign reference_state[962+:4]=reference.u_e16.d_lat;
assign reference_state[966+:64]={reference.u_e16.mem[15],reference.u_e16.mem[14],reference.u_e16.mem[13],reference.u_e16.mem[12],reference.u_e16.mem[11],reference.u_e16.mem[10],reference.u_e16.mem[9],reference.u_e16.mem[8],reference.u_e16.mem[7],reference.u_e16.mem[6],reference.u_e16.mem[5],reference.u_e16.mem[4],reference.u_e16.mem[3],reference.u_e16.mem[2],reference.u_e16.mem[1],reference.u_e16.mem[0]};
assign reference_state[1030+:1]=reference.u_e16.we_d;
assign reference_state[1031+:1]=reference.u_e17.cka_d;
assign reference_state[1032+:1]=reference.u_e17.ckb_d;
assign reference_state[1033+:1]=reference.u_e17.d_pre_a;
assign reference_state[1034+:1]=reference.u_e17.d_pre_b;
assign reference_state[1035+:1]=reference.u_e17.qa;
assign reference_state[1036+:1]=reference.u_e17.qb;
assign reference_state[1037+:4]=reference.u_e18.q;
assign reference_state[1041+:4]=reference.u_e20.q;
assign reference_state[1045+:4]=reference.u_e21.q;
assign reference_state[1049+:1]=reference.u_f01.qa;
assign reference_state[1050+:1]=reference.u_f01.qb;
assign reference_state[1051+:1]=reference.u_f02.qa;
assign reference_state[1052+:1]=reference.u_f02.qb;
assign reference_state[1053+:1]=reference.u_f08.ck_d;
assign reference_state[1054+:6]=reference.u_f08.d_pre;
assign reference_state[1060+:6]=reference.u_f08.q;
assign reference_state[1066+:1]=reference.u_f09.ck_d;
assign reference_state[1067+:4]=reference.u_f09.d_pre;
assign reference_state[1071+:4]=reference.u_f09.q;
assign reference_state[1075+:1]=reference.u_f10.ck_d;
assign reference_state[1076+:4]=reference.u_f10.d_pre;
assign reference_state[1080+:4]=reference.u_f10.q;
assign reference_state[1084+:1]=reference.u_f11.ck_d;
assign reference_state[1085+:4]=reference.u_f11.d_pre;
assign reference_state[1089+:4]=reference.u_f11.q;
assign reference_state[1093+:1]=reference.u_f12.ck_d;
assign reference_state[1094+:4]=reference.u_f12.d_pre;
assign reference_state[1098+:4]=reference.u_f12.q;
assign reference_state[1102+:1]=reference.u_f14.ck_d;
assign reference_state[1103+:4]=reference.u_f14.d_pre;
assign reference_state[1107+:4]=reference.u_f14.q;
assign reference_state[1111+:1]=reference.u_f15.ck_d;
assign reference_state[1112+:4]=reference.u_f15.d_pre;
assign reference_state[1116+:4]=reference.u_f15.q;
assign reference_state[1120+:4]=reference.u_f16.a_lat;
assign reference_state[1124+:1]=reference.u_f16.ce_lat;
assign reference_state[1125+:4]=reference.u_f16.d_lat;
assign reference_state[1129+:64]={reference.u_f16.mem[15],reference.u_f16.mem[14],reference.u_f16.mem[13],reference.u_f16.mem[12],reference.u_f16.mem[11],reference.u_f16.mem[10],reference.u_f16.mem[9],reference.u_f16.mem[8],reference.u_f16.mem[7],reference.u_f16.mem[6],reference.u_f16.mem[5],reference.u_f16.mem[4],reference.u_f16.mem[3],reference.u_f16.mem[2],reference.u_f16.mem[1],reference.u_f16.mem[0]};
assign reference_state[1193+:1]=reference.u_f16.we_d;
assign reference_state[1194+:4]=reference.u_f17.a_lat;
assign reference_state[1198+:1]=reference.u_f17.ce_lat;
assign reference_state[1199+:4]=reference.u_f17.d_lat;
assign reference_state[1203+:64]={reference.u_f17.mem[15],reference.u_f17.mem[14],reference.u_f17.mem[13],reference.u_f17.mem[12],reference.u_f17.mem[11],reference.u_f17.mem[10],reference.u_f17.mem[9],reference.u_f17.mem[8],reference.u_f17.mem[7],reference.u_f17.mem[6],reference.u_f17.mem[5],reference.u_f17.mem[4],reference.u_f17.mem[3],reference.u_f17.mem[2],reference.u_f17.mem[1],reference.u_f17.mem[0]};
assign reference_state[1267+:1]=reference.u_f17.we_d;
assign reference_state[1268+:4]=reference.u_f18.q;
assign reference_state[1272+:4]=reference.u_f20.q;
assign reference_state[1276+:4]=reference.u_f21.q;
assign reference_state[1280+:5]=reference.u_g06.q;
assign reference_state[1285+:4]=reference.u_g08.q;
assign reference_state[1289+:4]=reference.u_g09.q;
assign reference_state[1293+:4]=reference.u_g10.q;
assign reference_state[1297+:4]=reference.u_g11.q;
assign reference_state[1301+:4]=reference.u_g12.q;
assign reference_state[1305+:1]=reference.u_g17.cp_d;
assign reference_state[1306+:1]=reference.u_g17.cwe_pre;
assign reference_state[1307+:1]=reference.u_g17.d_pre;
assign reference_state[1308+:16]=reference.u_g17.r;
assign reference_state[1324+:1]=reference.u_g20.ck_d;
assign reference_state[1325+:6]=reference.u_g20.d_pre;
assign reference_state[1331+:6]=reference.u_g20.q;
assign reference_state[1337+:1]=reference.u_g21.ck_d;
assign reference_state[1338+:4]=reference.u_g21.q;
assign reference_state[1342+:6]=reference.u_g21.setup_pre;
assign reference_state[1348+:1]=reference.u_h04.cka_d;
assign reference_state[1349+:1]=reference.u_h04.ckb_d;
assign reference_state[1350+:1]=reference.u_h04.d_pre_a;
assign reference_state[1351+:1]=reference.u_h04.d_pre_b;
assign reference_state[1352+:1]=reference.u_h04.qa;
assign reference_state[1353+:1]=reference.u_h04.qb;
assign reference_state[1354+:1]=reference.u_h06.cka_d;
assign reference_state[1355+:1]=reference.u_h06.ckb_d;
assign reference_state[1356+:1]=reference.u_h06.d_pre_a;
assign reference_state[1357+:1]=reference.u_h06.d_pre_b;
assign reference_state[1358+:1]=reference.u_h06.qa;
assign reference_state[1359+:1]=reference.u_h06.qb;
assign reference_state[1360+:1]=reference.u_h08.ck_d;
assign reference_state[1361+:6]=reference.u_h08.d_pre;
assign reference_state[1367+:6]=reference.u_h08.q;
assign reference_state[1373+:1]=reference.u_h12.ck_d;
assign reference_state[1374+:6]=reference.u_h12.d_pre;
assign reference_state[1380+:6]=reference.u_h12.q;
assign reference_state[1386+:1]=reference.u_h13.ck_d;
assign reference_state[1387+:6]=reference.u_h13.d_pre;
assign reference_state[1393+:6]=reference.u_h13.q;
assign reference_state[1399+:1]=reference.u_h17.ck_d;
assign reference_state[1400+:6]=reference.u_h17.d_pre;
assign reference_state[1406+:6]=reference.u_h17.q;
assign reference_state[1412+:1]=reference.u_h24.ck_d;
assign reference_state[1413+:6]=reference.u_h24.d_pre;
assign reference_state[1419+:6]=reference.u_h24.q;
assign reference_state[1425+:1]=reference.u_i08.ck_d;
assign reference_state[1426+:4]=reference.u_i08.d_pre;
assign reference_state[1430+:1]=reference.u_i08.dl_pre;
assign reference_state[1431+:1]=reference.u_i08.dr_pre;
assign reference_state[1432+:4]=reference.u_i08.q;
assign reference_state[1436+:2]=reference.u_i08.s_pre;
assign reference_state[1438+:1]=reference.u_i09.ck_d;
assign reference_state[1439+:4]=reference.u_i09.d_pre;
assign reference_state[1443+:1]=reference.u_i09.dl_pre;
assign reference_state[1444+:1]=reference.u_i09.dr_pre;
assign reference_state[1445+:4]=reference.u_i09.q;
assign reference_state[1449+:2]=reference.u_i09.s_pre;
assign reference_state[1451+:1]=reference.u_i10.ck_d;
assign reference_state[1452+:4]=reference.u_i10.d_pre;
assign reference_state[1456+:1]=reference.u_i10.dl_pre;
assign reference_state[1457+:1]=reference.u_i10.dr_pre;
assign reference_state[1458+:4]=reference.u_i10.q;
assign reference_state[1462+:2]=reference.u_i10.s_pre;
assign reference_state[1464+:1]=reference.u_i11.ck_d;
assign reference_state[1465+:4]=reference.u_i11.d_pre;
assign reference_state[1469+:1]=reference.u_i11.dl_pre;
assign reference_state[1470+:1]=reference.u_i11.dr_pre;
assign reference_state[1471+:4]=reference.u_i11.q;
assign reference_state[1475+:2]=reference.u_i11.s_pre;
assign reference_state[1477+:1]=reference.u_i12.cin_pre;
assign reference_state[1478+:1]=reference.u_i12.ck_d;
assign reference_state[1479+:4]=reference.u_i12.d_pre;
assign reference_state[1483+:4]=reference.u_i12.q;
assign reference_state[1487+:1]=reference.u_i12.sd_pre;
assign reference_state[1488+:1]=reference.u_i12.su_pre;
assign reference_state[1489+:1]=reference.u_i13.cin_pre;
assign reference_state[1490+:1]=reference.u_i13.ck_d;
assign reference_state[1491+:4]=reference.u_i13.d_pre;
assign reference_state[1495+:4]=reference.u_i13.q;
assign reference_state[1499+:1]=reference.u_i13.sd_pre;
assign reference_state[1500+:1]=reference.u_i13.su_pre;
assign reference_state[1501+:1]=reference.u_i14.ck_d;
assign reference_state[1502+:4]=reference.u_i14.d_pre;
assign reference_state[1506+:1]=reference.u_i14.dl_pre;
assign reference_state[1507+:1]=reference.u_i14.dr_pre;
assign reference_state[1508+:4]=reference.u_i14.q;
assign reference_state[1512+:2]=reference.u_i14.s_pre;
assign reference_state[1514+:1]=reference.u_i15.ck_d;
assign reference_state[1515+:4]=reference.u_i15.d_pre;
assign reference_state[1519+:1]=reference.u_i15.dl_pre;
assign reference_state[1520+:1]=reference.u_i15.dr_pre;
assign reference_state[1521+:4]=reference.u_i15.q;
assign reference_state[1525+:2]=reference.u_i15.s_pre;
assign reference_state[1527+:1]=reference.u_i16.ck_d;
assign reference_state[1528+:4]=reference.u_i16.d_pre;
assign reference_state[1532+:1]=reference.u_i16.dl_pre;
assign reference_state[1533+:1]=reference.u_i16.dr_pre;
assign reference_state[1534+:4]=reference.u_i16.q;
assign reference_state[1538+:2]=reference.u_i16.s_pre;
assign reference_state[1540+:1]=reference.u_i17.ck_d;
assign reference_state[1541+:4]=reference.u_i17.d_pre;
assign reference_state[1545+:1]=reference.u_i17.dl_pre;
assign reference_state[1546+:1]=reference.u_i17.dr_pre;
assign reference_state[1547+:4]=reference.u_i17.q;
assign reference_state[1551+:2]=reference.u_i17.s_pre;
assign reference_state[1553+:1]=reference.u_i22.cka_d;
assign reference_state[1554+:1]=reference.u_i22.ckb_d;
assign reference_state[1555+:1]=reference.u_i22.d_pre_a;
assign reference_state[1556+:1]=reference.u_i22.d_pre_b;
assign reference_state[1557+:1]=reference.u_i22.qa;
assign reference_state[1558+:1]=reference.u_i22.qb;
assign reference_state[1559+:1]=reference.u_j04.cka_d;
assign reference_state[1560+:1]=reference.u_j04.ckb_d;
assign reference_state[1561+:1]=reference.u_j04.d_pre_a;
assign reference_state[1562+:1]=reference.u_j04.d_pre_b;
assign reference_state[1563+:1]=reference.u_j04.qa;
assign reference_state[1564+:1]=reference.u_j04.qb;
assign reference_state[1565+:1]=reference.u_j05.cp_d;
assign reference_state[1566+:1]=reference.u_j05.cwe_pre;
assign reference_state[1567+:1]=reference.u_j05.d_pre;
assign reference_state[1568+:16]=reference.u_j05.r;
assign reference_state[1584+:4]=reference.u_j08.a_lat;
assign reference_state[1588+:1]=reference.u_j08.ce_lat;
assign reference_state[1589+:4]=reference.u_j08.d_lat;
assign reference_state[1593+:64]={reference.u_j08.mem[15],reference.u_j08.mem[14],reference.u_j08.mem[13],reference.u_j08.mem[12],reference.u_j08.mem[11],reference.u_j08.mem[10],reference.u_j08.mem[9],reference.u_j08.mem[8],reference.u_j08.mem[7],reference.u_j08.mem[6],reference.u_j08.mem[5],reference.u_j08.mem[4],reference.u_j08.mem[3],reference.u_j08.mem[2],reference.u_j08.mem[1],reference.u_j08.mem[0]};
assign reference_state[1657+:1]=reference.u_j08.we_d;
assign reference_state[1658+:4]=reference.u_j09.a_lat;
assign reference_state[1662+:1]=reference.u_j09.ce_lat;
assign reference_state[1663+:4]=reference.u_j09.d_lat;
assign reference_state[1667+:64]={reference.u_j09.mem[15],reference.u_j09.mem[14],reference.u_j09.mem[13],reference.u_j09.mem[12],reference.u_j09.mem[11],reference.u_j09.mem[10],reference.u_j09.mem[9],reference.u_j09.mem[8],reference.u_j09.mem[7],reference.u_j09.mem[6],reference.u_j09.mem[5],reference.u_j09.mem[4],reference.u_j09.mem[3],reference.u_j09.mem[2],reference.u_j09.mem[1],reference.u_j09.mem[0]};
assign reference_state[1731+:1]=reference.u_j09.we_d;
assign reference_state[1732+:4]=reference.u_j10.a_lat;
assign reference_state[1736+:1]=reference.u_j10.ce_lat;
assign reference_state[1737+:4]=reference.u_j10.d_lat;
assign reference_state[1741+:64]={reference.u_j10.mem[15],reference.u_j10.mem[14],reference.u_j10.mem[13],reference.u_j10.mem[12],reference.u_j10.mem[11],reference.u_j10.mem[10],reference.u_j10.mem[9],reference.u_j10.mem[8],reference.u_j10.mem[7],reference.u_j10.mem[6],reference.u_j10.mem[5],reference.u_j10.mem[4],reference.u_j10.mem[3],reference.u_j10.mem[2],reference.u_j10.mem[1],reference.u_j10.mem[0]};
assign reference_state[1805+:1]=reference.u_j10.we_d;
assign reference_state[1806+:4]=reference.u_j11.a_lat;
assign reference_state[1810+:1]=reference.u_j11.ce_lat;
assign reference_state[1811+:4]=reference.u_j11.d_lat;
assign reference_state[1815+:64]={reference.u_j11.mem[15],reference.u_j11.mem[14],reference.u_j11.mem[13],reference.u_j11.mem[12],reference.u_j11.mem[11],reference.u_j11.mem[10],reference.u_j11.mem[9],reference.u_j11.mem[8],reference.u_j11.mem[7],reference.u_j11.mem[6],reference.u_j11.mem[5],reference.u_j11.mem[4],reference.u_j11.mem[3],reference.u_j11.mem[2],reference.u_j11.mem[1],reference.u_j11.mem[0]};
assign reference_state[1879+:1]=reference.u_j11.we_d;
assign reference_state[1880+:4]=reference.u_j12.a_lat;
assign reference_state[1884+:1]=reference.u_j12.ce_lat;
assign reference_state[1885+:4]=reference.u_j12.d_lat;
assign reference_state[1889+:64]={reference.u_j12.mem[15],reference.u_j12.mem[14],reference.u_j12.mem[13],reference.u_j12.mem[12],reference.u_j12.mem[11],reference.u_j12.mem[10],reference.u_j12.mem[9],reference.u_j12.mem[8],reference.u_j12.mem[7],reference.u_j12.mem[6],reference.u_j12.mem[5],reference.u_j12.mem[4],reference.u_j12.mem[3],reference.u_j12.mem[2],reference.u_j12.mem[1],reference.u_j12.mem[0]};
assign reference_state[1953+:1]=reference.u_j12.we_d;
assign reference_state[1954+:4]=reference.u_j13.a_lat;
assign reference_state[1958+:1]=reference.u_j13.ce_lat;
assign reference_state[1959+:4]=reference.u_j13.d_lat;
assign reference_state[1963+:64]={reference.u_j13.mem[15],reference.u_j13.mem[14],reference.u_j13.mem[13],reference.u_j13.mem[12],reference.u_j13.mem[11],reference.u_j13.mem[10],reference.u_j13.mem[9],reference.u_j13.mem[8],reference.u_j13.mem[7],reference.u_j13.mem[6],reference.u_j13.mem[5],reference.u_j13.mem[4],reference.u_j13.mem[3],reference.u_j13.mem[2],reference.u_j13.mem[1],reference.u_j13.mem[0]};
assign reference_state[2027+:1]=reference.u_j13.we_d;
assign reference_state[2028+:4]=reference.u_j14.a_lat;
assign reference_state[2032+:1]=reference.u_j14.ce_lat;
assign reference_state[2033+:4]=reference.u_j14.d_lat;
assign reference_state[2037+:64]={reference.u_j14.mem[15],reference.u_j14.mem[14],reference.u_j14.mem[13],reference.u_j14.mem[12],reference.u_j14.mem[11],reference.u_j14.mem[10],reference.u_j14.mem[9],reference.u_j14.mem[8],reference.u_j14.mem[7],reference.u_j14.mem[6],reference.u_j14.mem[5],reference.u_j14.mem[4],reference.u_j14.mem[3],reference.u_j14.mem[2],reference.u_j14.mem[1],reference.u_j14.mem[0]};
assign reference_state[2101+:1]=reference.u_j14.we_d;
assign reference_state[2102+:4]=reference.u_j15.a_lat;
assign reference_state[2106+:1]=reference.u_j15.ce_lat;
assign reference_state[2107+:4]=reference.u_j15.d_lat;
assign reference_state[2111+:64]={reference.u_j15.mem[15],reference.u_j15.mem[14],reference.u_j15.mem[13],reference.u_j15.mem[12],reference.u_j15.mem[11],reference.u_j15.mem[10],reference.u_j15.mem[9],reference.u_j15.mem[8],reference.u_j15.mem[7],reference.u_j15.mem[6],reference.u_j15.mem[5],reference.u_j15.mem[4],reference.u_j15.mem[3],reference.u_j15.mem[2],reference.u_j15.mem[1],reference.u_j15.mem[0]};
assign reference_state[2175+:1]=reference.u_j15.we_d;
assign reference_state[2176+:4]=reference.u_j16.a_lat;
assign reference_state[2180+:1]=reference.u_j16.ce_lat;
assign reference_state[2181+:4]=reference.u_j16.d_lat;
assign reference_state[2185+:64]={reference.u_j16.mem[15],reference.u_j16.mem[14],reference.u_j16.mem[13],reference.u_j16.mem[12],reference.u_j16.mem[11],reference.u_j16.mem[10],reference.u_j16.mem[9],reference.u_j16.mem[8],reference.u_j16.mem[7],reference.u_j16.mem[6],reference.u_j16.mem[5],reference.u_j16.mem[4],reference.u_j16.mem[3],reference.u_j16.mem[2],reference.u_j16.mem[1],reference.u_j16.mem[0]};
assign reference_state[2249+:1]=reference.u_j16.we_d;
assign reference_state[2250+:4]=reference.u_j17.a_lat;
assign reference_state[2254+:1]=reference.u_j17.ce_lat;
assign reference_state[2255+:4]=reference.u_j17.d_lat;
assign reference_state[2259+:64]={reference.u_j17.mem[15],reference.u_j17.mem[14],reference.u_j17.mem[13],reference.u_j17.mem[12],reference.u_j17.mem[11],reference.u_j17.mem[10],reference.u_j17.mem[9],reference.u_j17.mem[8],reference.u_j17.mem[7],reference.u_j17.mem[6],reference.u_j17.mem[5],reference.u_j17.mem[4],reference.u_j17.mem[3],reference.u_j17.mem[2],reference.u_j17.mem[1],reference.u_j17.mem[0]};
assign reference_state[2323+:1]=reference.u_j17.we_d;
assign reference_state[2324+:1]=reference.u_j19.ck_d;
assign reference_state[2325+:4]=reference.u_j19.jk_pre;
assign reference_state[2329+:1]=reference.u_j19.qa;
assign reference_state[2330+:1]=reference.u_j19.qb;
assign reference_state[2331+:32]=reference.u_j20.acc;
assign reference_state[2363+:1]=reference.u_j20.osc;
assign reference_state[2364+:1]=reference.u_j21.cin_pre;
assign reference_state[2365+:1]=reference.u_j21.ck_d;
assign reference_state[2366+:4]=reference.u_j21.d_pre;
assign reference_state[2370+:4]=reference.u_j21.q;
assign reference_state[2374+:1]=reference.u_j21.sd_pre;
assign reference_state[2375+:1]=reference.u_j21.su_pre;
assign reference_state[2376+:1]=reference.u_j24.ck_d;
assign reference_state[2377+:6]=reference.u_j24.d_pre;
assign reference_state[2383+:6]=reference.u_j24.q;
assign reference_state[2389+:1]=reference.u_k04.ck_d;
assign reference_state[2390+:4]=reference.u_k04.jk_pre;
assign reference_state[2394+:1]=reference.u_k04.qa;
assign reference_state[2395+:1]=reference.u_k04.qb;
assign reference_state[2396+:1]=reference.u_k07.ck_d;
assign reference_state[2397+:4]=reference.u_k07.jk_pre;
assign reference_state[2401+:1]=reference.u_k07.qa;
assign reference_state[2402+:1]=reference.u_k07.qb;
assign reference_state[2403+:1]=reference.u_k09.ck_d;
assign reference_state[2404+:6]=reference.u_k09.d_pre;
assign reference_state[2410+:6]=reference.u_k09.q;
assign reference_state[2416+:1]=reference.u_k10.ck_d;
assign reference_state[2417+:6]=reference.u_k10.d_pre;
assign reference_state[2423+:6]=reference.u_k10.q;
assign reference_state[2429+:1]=reference.u_k11.ck_d;
assign reference_state[2430+:6]=reference.u_k11.d_pre;
assign reference_state[2436+:6]=reference.u_k11.q;
assign reference_state[2442+:1]=reference.u_k14.ck_d;
assign reference_state[2443+:6]=reference.u_k14.d_pre;
assign reference_state[2449+:6]=reference.u_k14.q;
assign reference_state[2455+:1]=reference.u_k15.ck_d;
assign reference_state[2456+:6]=reference.u_k15.d_pre;
assign reference_state[2462+:6]=reference.u_k15.q;
assign reference_state[2468+:1]=reference.u_k16.ck_d;
assign reference_state[2469+:6]=reference.u_k16.d_pre;
assign reference_state[2475+:6]=reference.u_k16.q;
assign reference_state[2481+:1]=reference.u_k19.ck_d;
assign reference_state[2482+:4]=reference.u_k19.jk_pre;
assign reference_state[2486+:1]=reference.u_k19.qa;
assign reference_state[2487+:1]=reference.u_k19.qb;
assign reference_state[2488+:1]=reference.u_k20.cka_d;
assign reference_state[2489+:1]=reference.u_k20.ckb_d;
assign reference_state[2490+:1]=reference.u_k20.d_pre_a;
assign reference_state[2491+:1]=reference.u_k20.d_pre_b;
assign reference_state[2492+:1]=reference.u_k20.qa;
assign reference_state[2493+:1]=reference.u_k20.qb;
assign reference_state[2494+:1]=reference.u_k22.ck_d;
assign reference_state[2495+:4]=reference.u_k22.jk_pre;
assign reference_state[2499+:1]=reference.u_k22.qa;
assign reference_state[2500+:1]=reference.u_k22.qb;
assign reference_state[2501+:1]=reference.u_l02.cka_d;
assign reference_state[2502+:1]=reference.u_l02.ckb_d;
assign reference_state[2503+:1]=reference.u_l02.d_pre_a;
assign reference_state[2504+:1]=reference.u_l02.d_pre_b;
assign reference_state[2505+:1]=reference.u_l02.qa;
assign reference_state[2506+:1]=reference.u_l02.qb;
assign reference_state[2507+:1]=reference.u_l04.cka_d;
assign reference_state[2508+:1]=reference.u_l04.ckb_d;
assign reference_state[2509+:1]=reference.u_l04.d_pre_a;
assign reference_state[2510+:1]=reference.u_l04.d_pre_b;
assign reference_state[2511+:1]=reference.u_l04.qa;
assign reference_state[2512+:1]=reference.u_l04.qb;
assign reference_state[2513+:1]=reference.u_l06.ck_d;
assign reference_state[2514+:4]=reference.u_l06.jk_pre;
assign reference_state[2518+:1]=reference.u_l06.qa;
assign reference_state[2519+:1]=reference.u_l06.qb;
assign reference_state[2520+:1]=reference.u_l07.cka_d;
assign reference_state[2521+:1]=reference.u_l07.ckb_d;
assign reference_state[2522+:1]=reference.u_l07.d_pre_a;
assign reference_state[2523+:1]=reference.u_l07.d_pre_b;
assign reference_state[2524+:1]=reference.u_l07.qa;
assign reference_state[2525+:1]=reference.u_l07.qb;
assign reference_state[2526+:1]=reference.u_l09.ck_d;
assign reference_state[2527+:4]=reference.u_l09.q;
assign reference_state[2531+:6]=reference.u_l09.setup_pre;
assign reference_state[2537+:1]=reference.u_l12.ck_d;
assign reference_state[2538+:4]=reference.u_l12.q;
assign reference_state[2542+:6]=reference.u_l12.setup_pre;
assign reference_state[2548+:1]=reference.u_l13.ck_d;
assign reference_state[2549+:4]=reference.u_l13.q;
assign reference_state[2553+:6]=reference.u_l13.setup_pre;
assign reference_state[2559+:1]=reference.u_l16.ck_d;
assign reference_state[2560+:4]=reference.u_l16.q;
assign reference_state[2564+:6]=reference.u_l16.setup_pre;
assign reference_state[2570+:1]=reference.u_l18.ck_d;
assign reference_state[2571+:6]=reference.u_l18.d_pre;
assign reference_state[2577+:6]=reference.u_l18.q;
assign reference_state[2583+:1]=reference.u_l19.ck_d;
assign reference_state[2584+:4]=reference.u_l19.jk_pre;
assign reference_state[2588+:1]=reference.u_l19.qa;
assign reference_state[2589+:1]=reference.u_l19.qb;
assign reference_state[2590+:1]=reference.u_l20.cka_d;
assign reference_state[2591+:1]=reference.u_l20.ckb_d;
assign reference_state[2592+:1]=reference.u_l20.d_pre_a;
assign reference_state[2593+:1]=reference.u_l20.d_pre_b;
assign reference_state[2594+:1]=reference.u_l20.qa;
assign reference_state[2595+:1]=reference.u_l20.qb;
assign reference_state[2596+:1]=reference.u_l22.ck_d;
assign reference_state[2597+:6]=reference.u_l22.d_pre;
assign reference_state[2603+:6]=reference.u_l22.q;
assign reference_state[2609+:1]=reference.u_l23.ck_d;
assign reference_state[2610+:6]=reference.u_l23.d_pre;
assign reference_state[2616+:6]=reference.u_l23.q;
assign reference_state[2622+:8]=reference.u_receive_monitor.consumed;
assign reference_state[2630+:8]=reference.u_receive_monitor.cpu_status;
assign reference_state[2638+:1]=reference.u_receive_monitor.input_d;
assign reference_state[2639+:8]=reference.u_receive_monitor.received;
assign reference_state[2647+:8]=reference.u_receive_monitor.wire_status;
assign reference_state[2655+:1]=reference.u_receive_monitor.write_d;
assign reference_probe=1'b0;
wire [31:0] dut_receive_debug;
wire dut_ClockM0__drv;
wire dut_ClockM1__drv;
wire dut_ClockM2__drv;
wire dut_ClockM3__drv;
wire dut_ClockP0__drv;
wire dut_ClockP1__drv;
wire dut_ClockP2__drv;
wire dut_ClockP3__drv;
wire dut_ContTag_p___drv;
wire dut_CylinderTag_p___drv;
wire dut_DMuxData__drv;
wire dut_DataM0__drv;
wire dut_DataM1__drv;
wire dut_DataM2__drv;
wire dut_DataM3__drv;
wire dut_DataP0__drv;
wire dut_DataP1__drv;
wire dut_DataP2__drv;
wire dut_DataP3__drv;
wire dut_DriveTag_p___drv;
wire dut_HeadTag_p___drv;
wire dut_IOB_00__drv;
wire dut_IOB_01__drv;
wire dut_IOB_02__drv;
wire dut_IOB_03__drv;
wire dut_IOB_04__drv;
wire dut_IOB_05__drv;
wire dut_IOB_06__drv;
wire dut_IOB_07__drv;
wire dut_IOB_08__drv;
wire dut_IOB_09__drv;
wire dut_IOB_10__drv;
wire dut_IOB_11__drv;
wire dut_IOB_12__drv;
wire dut_IOB_13__drv;
wire dut_IOB_14__drv;
wire dut_IOB_15__drv;
wire dut_IOB_16__drv;
wire dut_IOB_17__drv;
wire dut_IOatt__drv;
wire dut_OKToSelect__drv;
wire dut_OS0__drv;
wire dut_OS1__drv;
wire dut_OS2__drv;
wire dut_OS3__drv;
wire dut_SecIndx0_p___drv;
wire dut_SecIndx1_p___drv;
wire dut_SecIndx2_p___drv;
wire dut_SecIndx3_p___drv;
wire dut_Select0_p___drv;
wire dut_Select1_p___drv;
wire dut_Select2_p___drv;
wire dut_Select3_p___drv;
wire dut_Selected0_p___drv;
wire dut_Selected1_p___drv;
wire dut_Selected2_p___drv;
wire dut_Selected3_p___drv;
wire dut_TWReq_06__drv;
wire dut_TWReq_07__drv;
wire dut_TWReq_12__drv;
wire dut_TagBus_0_p___drv;
wire dut_TagBus_00_p___drv;
wire dut_TagBus_000_p___drv;
wire dut_TagBus_1_p___drv;
wire dut_TagBus_2_p___drv;
wire dut_TagBus_3_p___drv;
wire dut_TagBus_4_p___drv;
wire dut_TagBus_5_p___drv;
wire dut_TagBus_6_p___drv;
wire dut_TagBus_7_p___drv;
wire dut_TagBus_8_p___drv;
wire dut_TagBus_9_p___drv;
wire dut_TtlDeviceCk_p___drv;
wire dut_TtlEndOfCyl_p___drv;
wire dut_TtlIndex_p___drv;
wire dut_TtlOffSet_p___drv;
wire dut_TtlOnLine_p___drv;
wire dut_TtlReadOnly_p___drv;
wire dut_TtlReady_p___drv;
wire dut_TtlSector_p___drv;
wire dut_TtlSeekInc_p___drv;
wire dut_TtlTerm_p___drv;
wire dut_XmtData_p___drv;
dorado_serial_DskEth #(.SYSPER(4)) dut(
.sys_clk(clk),
.BNTGtCT_p_b(stimulus[0]),
.Block(stimulus[1]),
.CLK_disk_p_(stimulus[2]),
.CLKEnable_p_a(stimulus[3]),
.ClockM0(stimulus[4] | dut_ClockM0__drv),
.ClockM1(stimulus[5] | dut_ClockM1__drv),
.ClockM2(stimulus[6] | dut_ClockM2__drv),
.ClockM3(stimulus[7] | dut_ClockM3__drv),
.ClockP0(stimulus[8] | dut_ClockP0__drv),
.ClockP1(stimulus[9] | dut_ClockP1__drv),
.ClockP2(stimulus[10] | dut_ClockP2__drv),
.ClockP3(stimulus[11] | dut_ClockP3__drv),
.Collision(stimulus[12]),
.DMuxClk(stimulus[13]),
.DMuxData(stimulus[14] | dut_DMuxData__drv),
.DataM0(stimulus[15] | dut_DataM0__drv),
.DataM1(stimulus[16] | dut_DataM1__drv),
.DataM2(stimulus[17] | dut_DataM2__drv),
.DataM3(stimulus[18] | dut_DataM3__drv),
.DataP0(stimulus[19] | dut_DataP0__drv),
.DataP1(stimulus[20] | dut_DataP1__drv),
.DataP2(stimulus[21] | dut_DataP2__drv),
.DataP3(stimulus[22] | dut_DataP3__drv),
.Host_0(stimulus[23]),
.Host_1(stimulus[24]),
.Host_2(stimulus[25]),
.Host_3(stimulus[26]),
.Host_4(stimulus[27]),
.Host_5(stimulus[28]),
.Host_6(stimulus[29]),
.Host_7(stimulus[30]),
.IOB_00(stimulus[31] | dut_IOB_00__drv),
.IOB_01(stimulus[32] | dut_IOB_01__drv),
.IOB_02(stimulus[33] | dut_IOB_02__drv),
.IOB_03(stimulus[34] | dut_IOB_03__drv),
.IOB_04(stimulus[35] | dut_IOB_04__drv),
.IOB_05(stimulus[36] | dut_IOB_05__drv),
.IOB_06(stimulus[37] | dut_IOB_06__drv),
.IOB_07(stimulus[38] | dut_IOB_07__drv),
.IOB_08(stimulus[39] | dut_IOB_08__drv),
.IOB_09(stimulus[40] | dut_IOB_09__drv),
.IOB_10(stimulus[41] | dut_IOB_10__drv),
.IOB_11(stimulus[42] | dut_IOB_11__drv),
.IOB_12(stimulus[43] | dut_IOB_12__drv),
.IOB_13(stimulus[44] | dut_IOB_13__drv),
.IOB_14(stimulus[45] | dut_IOB_14__drv),
.IOB_15(stimulus[46] | dut_IOB_15__drv),
.IOB_16(stimulus[47] | dut_IOB_16__drv),
.IOB_17(stimulus[48] | dut_IOB_17__drv),
.IOHold(stimulus[49]),
.IOReset(stimulus[50]),
.IOin_p_(stimulus[51]),
.IOout_p_(stimulus[52]),
.MemSH_p_(stimulus[53]),
.Next_0(stimulus[54]),
.Next_1(stimulus[55]),
.Next_2(stimulus[56]),
.Next_3(stimulus[57]),
.OKToSelect(stimulus[58] | dut_OKToSelect__drv),
.OS0(stimulus[59] | dut_OS0__drv),
.OS1(stimulus[60] | dut_OS1__drv),
.OS2(stimulus[61] | dut_OS2__drv),
.OS3(stimulus[62] | dut_OS3__drv),
.Pendulum(stimulus[63]),
.RcvData(stimulus[64]),
.SecIndx0_p_(stimulus[65] | dut_SecIndx0_p___drv),
.SecIndx1_p_(stimulus[66] | dut_SecIndx1_p___drv),
.SecIndx2_p_(stimulus[67] | dut_SecIndx2_p___drv),
.SecIndx3_p_(stimulus[68] | dut_SecIndx3_p___drv),
.Selected0_p_(stimulus[69] | dut_Selected0_p___drv),
.Selected1_p_(stimulus[70] | dut_Selected1_p___drv),
.Selected2_p_(stimulus[71] | dut_Selected2_p___drv),
.Selected3_p_(stimulus[72] | dut_Selected3_p___drv),
.TIOA_0(stimulus[73]),
.TIOA_1(stimulus[74]),
.TIOA_2(stimulus[75]),
.TIOA_3(stimulus[76]),
.TIOA_4(stimulus[77]),
.TIOA_5(stimulus[78]),
.TIOA_6(stimulus[79]),
.TIOA_7(stimulus[80]),
.TempRef(stimulus[81]),
.TtlDeviceCk_p_(stimulus[82] | dut_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p_(stimulus[83] | dut_TtlEndOfCyl_p___drv),
.TtlIndex_p_(stimulus[84] | dut_TtlIndex_p___drv),
.TtlOffSet_p_(stimulus[85] | dut_TtlOffSet_p___drv),
.TtlOnLine_p_(stimulus[86] | dut_TtlOnLine_p___drv),
.TtlReadOnly_p_(stimulus[87] | dut_TtlReadOnly_p___drv),
.TtlReady_p_(stimulus[88] | dut_TtlReady_p___drv),
.TtlSector_p_(stimulus[89] | dut_TtlSector_p___drv),
.TtlSeekInc_p_(stimulus[90] | dut_TtlSeekInc_p___drv),
.TtlTerm_p_(stimulus[91] | dut_TtlTerm_p___drv),
.receive_debug(dut_receive_debug),
.ClockM0__drv(dut_ClockM0__drv),
.ClockM1__drv(dut_ClockM1__drv),
.ClockM2__drv(dut_ClockM2__drv),
.ClockM3__drv(dut_ClockM3__drv),
.ClockP0__drv(dut_ClockP0__drv),
.ClockP1__drv(dut_ClockP1__drv),
.ClockP2__drv(dut_ClockP2__drv),
.ClockP3__drv(dut_ClockP3__drv),
.ContTag_p___drv(dut_ContTag_p___drv),
.CylinderTag_p___drv(dut_CylinderTag_p___drv),
.DMuxData__drv(dut_DMuxData__drv),
.DataM0__drv(dut_DataM0__drv),
.DataM1__drv(dut_DataM1__drv),
.DataM2__drv(dut_DataM2__drv),
.DataM3__drv(dut_DataM3__drv),
.DataP0__drv(dut_DataP0__drv),
.DataP1__drv(dut_DataP1__drv),
.DataP2__drv(dut_DataP2__drv),
.DataP3__drv(dut_DataP3__drv),
.DriveTag_p___drv(dut_DriveTag_p___drv),
.HeadTag_p___drv(dut_HeadTag_p___drv),
.IOB_00__drv(dut_IOB_00__drv),
.IOB_01__drv(dut_IOB_01__drv),
.IOB_02__drv(dut_IOB_02__drv),
.IOB_03__drv(dut_IOB_03__drv),
.IOB_04__drv(dut_IOB_04__drv),
.IOB_05__drv(dut_IOB_05__drv),
.IOB_06__drv(dut_IOB_06__drv),
.IOB_07__drv(dut_IOB_07__drv),
.IOB_08__drv(dut_IOB_08__drv),
.IOB_09__drv(dut_IOB_09__drv),
.IOB_10__drv(dut_IOB_10__drv),
.IOB_11__drv(dut_IOB_11__drv),
.IOB_12__drv(dut_IOB_12__drv),
.IOB_13__drv(dut_IOB_13__drv),
.IOB_14__drv(dut_IOB_14__drv),
.IOB_15__drv(dut_IOB_15__drv),
.IOB_16__drv(dut_IOB_16__drv),
.IOB_17__drv(dut_IOB_17__drv),
.IOatt__drv(dut_IOatt__drv),
.OKToSelect__drv(dut_OKToSelect__drv),
.OS0__drv(dut_OS0__drv),
.OS1__drv(dut_OS1__drv),
.OS2__drv(dut_OS2__drv),
.OS3__drv(dut_OS3__drv),
.SecIndx0_p___drv(dut_SecIndx0_p___drv),
.SecIndx1_p___drv(dut_SecIndx1_p___drv),
.SecIndx2_p___drv(dut_SecIndx2_p___drv),
.SecIndx3_p___drv(dut_SecIndx3_p___drv),
.Select0_p___drv(dut_Select0_p___drv),
.Select1_p___drv(dut_Select1_p___drv),
.Select2_p___drv(dut_Select2_p___drv),
.Select3_p___drv(dut_Select3_p___drv),
.Selected0_p___drv(dut_Selected0_p___drv),
.Selected1_p___drv(dut_Selected1_p___drv),
.Selected2_p___drv(dut_Selected2_p___drv),
.Selected3_p___drv(dut_Selected3_p___drv),
.TWReq_06__drv(dut_TWReq_06__drv),
.TWReq_07__drv(dut_TWReq_07__drv),
.TWReq_12__drv(dut_TWReq_12__drv),
.TagBus_0_p___drv(dut_TagBus_0_p___drv),
.TagBus_00_p___drv(dut_TagBus_00_p___drv),
.TagBus_000_p___drv(dut_TagBus_000_p___drv),
.TagBus_1_p___drv(dut_TagBus_1_p___drv),
.TagBus_2_p___drv(dut_TagBus_2_p___drv),
.TagBus_3_p___drv(dut_TagBus_3_p___drv),
.TagBus_4_p___drv(dut_TagBus_4_p___drv),
.TagBus_5_p___drv(dut_TagBus_5_p___drv),
.TagBus_6_p___drv(dut_TagBus_6_p___drv),
.TagBus_7_p___drv(dut_TagBus_7_p___drv),
.TagBus_8_p___drv(dut_TagBus_8_p___drv),
.TagBus_9_p___drv(dut_TagBus_9_p___drv),
.TtlDeviceCk_p___drv(dut_TtlDeviceCk_p___drv),
.TtlEndOfCyl_p___drv(dut_TtlEndOfCyl_p___drv),
.TtlIndex_p___drv(dut_TtlIndex_p___drv),
.TtlOffSet_p___drv(dut_TtlOffSet_p___drv),
.TtlOnLine_p___drv(dut_TtlOnLine_p___drv),
.TtlReadOnly_p___drv(dut_TtlReadOnly_p___drv),
.TtlReady_p___drv(dut_TtlReady_p___drv),
.TtlSector_p___drv(dut_TtlSector_p___drv),
.TtlSeekInc_p___drv(dut_TtlSeekInc_p___drv),
.TtlTerm_p___drv(dut_TtlTerm_p___drv),
.XmtData_p___drv(dut_XmtData_p___drv),
.state_host_clk(clk),
.state_guest_advance(board_steps[0]),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[12:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(all_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_XmtData_p___drv,dut_TtlTerm_p___drv,dut_TtlSeekInc_p___drv,dut_TtlSector_p___drv,dut_TtlReady_p___drv,dut_TtlReadOnly_p___drv,dut_TtlOnLine_p___drv,dut_TtlOffSet_p___drv,dut_TtlIndex_p___drv,dut_TtlEndOfCyl_p___drv,dut_TtlDeviceCk_p___drv,dut_TagBus_9_p___drv,dut_TagBus_8_p___drv,dut_TagBus_7_p___drv,dut_TagBus_6_p___drv,dut_TagBus_5_p___drv,dut_TagBus_4_p___drv,dut_TagBus_3_p___drv,dut_TagBus_2_p___drv,dut_TagBus_1_p___drv,dut_TagBus_000_p___drv,dut_TagBus_00_p___drv,dut_TagBus_0_p___drv,dut_TWReq_12__drv,dut_TWReq_07__drv,dut_TWReq_06__drv,dut_Selected3_p___drv,dut_Selected2_p___drv,dut_Selected1_p___drv,dut_Selected0_p___drv,dut_Select3_p___drv,dut_Select2_p___drv,dut_Select1_p___drv,dut_Select0_p___drv,dut_SecIndx3_p___drv,dut_SecIndx2_p___drv,dut_SecIndx1_p___drv,dut_SecIndx0_p___drv,dut_OS3__drv,dut_OS2__drv,dut_OS1__drv,dut_OS0__drv,dut_OKToSelect__drv,dut_IOatt__drv,dut_IOB_17__drv,dut_IOB_16__drv,dut_IOB_15__drv,dut_IOB_14__drv,dut_IOB_13__drv,dut_IOB_12__drv,dut_IOB_11__drv,dut_IOB_10__drv,dut_IOB_09__drv,dut_IOB_08__drv,dut_IOB_07__drv,dut_IOB_06__drv,dut_IOB_05__drv,dut_IOB_04__drv,dut_IOB_03__drv,dut_IOB_02__drv,dut_IOB_01__drv,dut_IOB_00__drv,dut_HeadTag_p___drv,dut_DriveTag_p___drv,dut_DataP3__drv,dut_DataP2__drv,dut_DataP1__drv,dut_DataP0__drv,dut_DataM3__drv,dut_DataM2__drv,dut_DataM1__drv,dut_DataM0__drv,dut_DMuxData__drv,dut_CylinderTag_p___drv,dut_ContTag_p___drv,dut_ClockP3__drv,dut_ClockP2__drv,dut_ClockP1__drv,dut_ClockP0__drv,dut_ClockM3__drv,dut_ClockM2__drv,dut_ClockM1__drv,dut_ClockM0__drv,dut_receive_debug};
assign dut_state[0+:1]=dut.Clk1;
assign dut_state[1+:1]=dut.Clock1_p_Bb;
assign dut_state[2+:1]=dut.Clock1_p_Bd;
assign dut_state[3+:1]=dut.Clock1_p_Ca;
assign dut_state[4+:1]=dut.Clock1_p_Cb;
assign dut_state[5+:1]=dut.Clock1_p_Cc;
assign dut_state[6+:1]=dut.Clock1_p_Da;
assign dut_state[7+:1]=dut.Clock1_p_Db;
assign dut_state[8+:1]=dut.Clock1_p_Dd;
assign dut_state[9+:1]=dut.u_a01.ck_d;
assign dut_state[10+:1]=dut.u_a01.p10_d;
assign dut_state[11+:1]=dut.u_a01.p7_d;
assign dut_state[12+:1]=dut.u_a01.p9_d;
assign dut_state[13+:4]=dut.u_a01.q;
assign dut_state[17+:1]=dut.u_a02.ck_d;
assign dut_state[18+:1]=dut.u_a02.p10_d;
assign dut_state[19+:1]=dut.u_a02.p7_d;
assign dut_state[20+:1]=dut.u_a02.p9_d;
assign dut_state[21+:4]=dut.u_a02.q;
assign dut_state[25+:1]=dut.u_a03.a1_d;
assign dut_state[26+:1]=dut.u_a03.a2_d;
assign dut_state[27+:1]=dut.u_a03.b1_d;
assign dut_state[28+:1]=dut.u_a03.b2_d;
assign dut_state[29+:1]=dut.u_a03.c1_d;
assign dut_state[30+:1]=dut.u_a03.c2_d;
assign dut_state[31+:32]=dut.u_a03.t1;
assign dut_state[63+:32]=dut.u_a03.t2;
assign dut_state[95+:1]=dut.u_a05.a1_d;
assign dut_state[96+:1]=dut.u_a05.a2_d;
assign dut_state[97+:1]=dut.u_a05.b1_d;
assign dut_state[98+:1]=dut.u_a05.b2_d;
assign dut_state[99+:1]=dut.u_a05.c1_d;
assign dut_state[100+:1]=dut.u_a05.c2_d;
assign dut_state[101+:32]=dut.u_a05.t1;
assign dut_state[133+:32]=dut.u_a05.t2;
assign dut_state[165+:1]=dut.u_a06.ck_d;
assign dut_state[166+:1]=dut.u_a06.p10_d;
assign dut_state[167+:1]=dut.u_a06.p7_d;
assign dut_state[168+:1]=dut.u_a06.p9_d;
assign dut_state[169+:4]=dut.u_a06.q;
assign dut_state[173+:1]=dut.u_a07.ck_d;
assign dut_state[174+:1]=dut.u_a07.p10_d;
assign dut_state[175+:1]=dut.u_a07.p7_d;
assign dut_state[176+:1]=dut.u_a07.p9_d;
assign dut_state[177+:4]=dut.u_a07.q;
assign dut_state[181+:1]=dut.u_a08.ck_d;
assign dut_state[182+:6]=dut.u_a08.d_pre;
assign dut_state[188+:6]=dut.u_a08.q;
assign dut_state[194+:1]=dut.u_a09.ck_d;
assign dut_state[195+:6]=dut.u_a09.d_pre;
assign dut_state[201+:6]=dut.u_a09.q;
assign dut_state[207+:1]=dut.u_a10.ck_d;
assign dut_state[208+:6]=dut.u_a10.d_pre;
assign dut_state[214+:6]=dut.u_a10.q;
assign dut_state[220+:1]=dut.u_a11.ck_d;
assign dut_state[221+:6]=dut.u_a11.d_pre;
assign dut_state[227+:6]=dut.u_a11.q;
assign dut_state[233+:1]=dut.u_a15.ck_d;
assign dut_state[234+:4]=dut.u_a15.q;
assign dut_state[238+:6]=dut.u_a15.setup_pre;
assign dut_state[244+:1]=dut.u_a16.ck_d;
assign dut_state[245+:4]=dut.u_a16.q;
assign dut_state[249+:6]=dut.u_a16.setup_pre;
assign dut_state[255+:1]=dut.u_a22.ck_d;
assign dut_state[256+:4]=dut.u_a22.q;
assign dut_state[260+:6]=dut.u_a22.setup_pre;
assign dut_state[266+:1]=dut.u_b03.ck_d;
assign dut_state[267+:6]=dut.u_b03.d_pre;
assign dut_state[273+:6]=dut.u_b03.q;
assign dut_state[279+:1]=dut.u_b04.ck_d;
assign dut_state[280+:6]=dut.u_b04.d_pre;
assign dut_state[286+:6]=dut.u_b04.q;
assign dut_state[292+:1]=dut.u_b05.ck_d;
assign dut_state[293+:6]=dut.u_b05.d_pre;
assign dut_state[299+:6]=dut.u_b05.q;
assign dut_state[305+:1]=dut.u_b06.ck_d;
assign dut_state[306+:6]=dut.u_b06.d_pre;
assign dut_state[312+:6]=dut.u_b06.q;
assign dut_state[318+:1]=dut.u_b09.cka_d;
assign dut_state[319+:1]=dut.u_b09.ckb_d;
assign dut_state[320+:1]=dut.u_b09.d_pre_a;
assign dut_state[321+:1]=dut.u_b09.d_pre_b;
assign dut_state[322+:1]=dut.u_b09.qa;
assign dut_state[323+:1]=dut.u_b09.qb;
assign dut_state[324+:1]=dut.u_b10.ck_d;
assign dut_state[325+:4]=dut.u_b10.q;
assign dut_state[329+:6]=dut.u_b10.setup_pre;
assign dut_state[335+:1]=dut.u_b12.cka_d;
assign dut_state[336+:1]=dut.u_b12.ckb_d;
assign dut_state[337+:1]=dut.u_b12.d_pre_a;
assign dut_state[338+:1]=dut.u_b12.d_pre_b;
assign dut_state[339+:1]=dut.u_b12.qa;
assign dut_state[340+:1]=dut.u_b12.qb;
assign dut_state[341+:1]=dut.u_b15.cka_d;
assign dut_state[342+:1]=dut.u_b15.ckb_d;
assign dut_state[343+:1]=dut.u_b15.d_pre_a;
assign dut_state[344+:1]=dut.u_b15.d_pre_b;
assign dut_state[345+:1]=dut.u_b15.qa;
assign dut_state[346+:1]=dut.u_b15.qb;
assign dut_state[347+:1]=dut.u_b20.ck_d;
assign dut_state[348+:4]=dut.u_b20.q;
assign dut_state[352+:6]=dut.u_b20.setup_pre;
assign dut_state[358+:1]=dut.u_b21.ck_d;
assign dut_state[359+:4]=dut.u_b21.q;
assign dut_state[363+:6]=dut.u_b21.setup_pre;
assign dut_state[369+:1]=dut.u_c01.qa;
assign dut_state[370+:1]=dut.u_c01.qb;
assign dut_state[371+:1]=dut.u_c02.qa;
assign dut_state[372+:1]=dut.u_c02.qb;
assign dut_state[373+:1]=dut.u_c07.ck_d;
assign dut_state[374+:6]=dut.u_c07.d_pre;
assign dut_state[380+:6]=dut.u_c07.q;
assign dut_state[386+:1]=dut.u_c08.ck_d;
assign dut_state[387+:6]=dut.u_c08.d_pre;
assign dut_state[393+:6]=dut.u_c08.q;
assign dut_state[399+:1]=dut.u_c09.cka_d;
assign dut_state[400+:1]=dut.u_c09.ckb_d;
assign dut_state[401+:1]=dut.u_c09.d_pre_a;
assign dut_state[402+:1]=dut.u_c09.d_pre_b;
assign dut_state[403+:1]=dut.u_c09.qa;
assign dut_state[404+:1]=dut.u_c09.qb;
assign dut_state[405+:1]=dut.u_c14.ck_d;
assign dut_state[406+:6]=dut.u_c14.d_pre;
assign dut_state[412+:6]=dut.u_c14.q;
assign dut_state[418+:1]=dut.u_c15.cka_d;
assign dut_state[419+:1]=dut.u_c15.ckb_d;
assign dut_state[420+:1]=dut.u_c15.d_pre_a;
assign dut_state[421+:1]=dut.u_c15.d_pre_b;
assign dut_state[422+:1]=dut.u_c15.qa;
assign dut_state[423+:1]=dut.u_c15.qb;
assign dut_state[424+:1]=dut.u_c16.ck_d;
assign dut_state[425+:4]=dut.u_c16.jk_pre;
assign dut_state[429+:1]=dut.u_c16.qa;
assign dut_state[430+:1]=dut.u_c16.qb;
assign dut_state[431+:1]=dut.u_c19.cin_pre;
assign dut_state[432+:1]=dut.u_c19.ck_d;
assign dut_state[433+:4]=dut.u_c19.d_pre;
assign dut_state[437+:4]=dut.u_c19.q;
assign dut_state[441+:1]=dut.u_c19.sd_pre;
assign dut_state[442+:1]=dut.u_c19.su_pre;
assign dut_state[443+:1]=dut.u_c20.cin_pre;
assign dut_state[444+:1]=dut.u_c20.ck_d;
assign dut_state[445+:4]=dut.u_c20.d_pre;
assign dut_state[449+:4]=dut.u_c20.q;
assign dut_state[453+:1]=dut.u_c20.sd_pre;
assign dut_state[454+:1]=dut.u_c20.su_pre;
assign dut_state[455+:1]=dut.u_c21.cin_pre;
assign dut_state[456+:1]=dut.u_c21.ck_d;
assign dut_state[457+:4]=dut.u_c21.d_pre;
assign dut_state[461+:4]=dut.u_c21.q;
assign dut_state[465+:1]=dut.u_c21.sd_pre;
assign dut_state[466+:1]=dut.u_c21.su_pre;
assign dut_state[467+:1]=dut.u_d04.ck_d;
assign dut_state[468+:6]=dut.u_d04.d_pre;
assign dut_state[474+:6]=dut.u_d04.q;
assign dut_state[480+:4]=dut.u_d08.a_lat;
assign dut_state[484+:1]=dut.u_d08.ce_lat;
assign dut_state[485+:4]=dut.u_d08.d_lat;
assign dut_state[489+:64]={dut.u_d08.mem[15],dut.u_d08.mem[14],dut.u_d08.mem[13],dut.u_d08.mem[12],dut.u_d08.mem[11],dut.u_d08.mem[10],dut.u_d08.mem[9],dut.u_d08.mem[8],dut.u_d08.mem[7],dut.u_d08.mem[6],dut.u_d08.mem[5],dut.u_d08.mem[4],dut.u_d08.mem[3],dut.u_d08.mem[2],dut.u_d08.mem[1],dut.u_d08.mem[0]};
assign dut_state[553+:1]=dut.u_d08.we_d;
assign dut_state[554+:4]=dut.u_d09.a_lat;
assign dut_state[558+:1]=dut.u_d09.ce_lat;
assign dut_state[559+:4]=dut.u_d09.d_lat;
assign dut_state[563+:64]={dut.u_d09.mem[15],dut.u_d09.mem[14],dut.u_d09.mem[13],dut.u_d09.mem[12],dut.u_d09.mem[11],dut.u_d09.mem[10],dut.u_d09.mem[9],dut.u_d09.mem[8],dut.u_d09.mem[7],dut.u_d09.mem[6],dut.u_d09.mem[5],dut.u_d09.mem[4],dut.u_d09.mem[3],dut.u_d09.mem[2],dut.u_d09.mem[1],dut.u_d09.mem[0]};
assign dut_state[627+:1]=dut.u_d09.we_d;
assign dut_state[628+:4]=dut.u_d10.a_lat;
assign dut_state[632+:1]=dut.u_d10.ce_lat;
assign dut_state[633+:4]=dut.u_d10.d_lat;
assign dut_state[637+:64]={dut.u_d10.mem[15],dut.u_d10.mem[14],dut.u_d10.mem[13],dut.u_d10.mem[12],dut.u_d10.mem[11],dut.u_d10.mem[10],dut.u_d10.mem[9],dut.u_d10.mem[8],dut.u_d10.mem[7],dut.u_d10.mem[6],dut.u_d10.mem[5],dut.u_d10.mem[4],dut.u_d10.mem[3],dut.u_d10.mem[2],dut.u_d10.mem[1],dut.u_d10.mem[0]};
assign dut_state[701+:1]=dut.u_d10.we_d;
assign dut_state[702+:4]=dut.u_d11.a_lat;
assign dut_state[706+:1]=dut.u_d11.ce_lat;
assign dut_state[707+:4]=dut.u_d11.d_lat;
assign dut_state[711+:64]={dut.u_d11.mem[15],dut.u_d11.mem[14],dut.u_d11.mem[13],dut.u_d11.mem[12],dut.u_d11.mem[11],dut.u_d11.mem[10],dut.u_d11.mem[9],dut.u_d11.mem[8],dut.u_d11.mem[7],dut.u_d11.mem[6],dut.u_d11.mem[5],dut.u_d11.mem[4],dut.u_d11.mem[3],dut.u_d11.mem[2],dut.u_d11.mem[1],dut.u_d11.mem[0]};
assign dut_state[775+:1]=dut.u_d11.we_d;
assign dut_state[776+:4]=dut.u_d12.a_lat;
assign dut_state[780+:1]=dut.u_d12.ce_lat;
assign dut_state[781+:4]=dut.u_d12.d_lat;
assign dut_state[785+:64]={dut.u_d12.mem[15],dut.u_d12.mem[14],dut.u_d12.mem[13],dut.u_d12.mem[12],dut.u_d12.mem[11],dut.u_d12.mem[10],dut.u_d12.mem[9],dut.u_d12.mem[8],dut.u_d12.mem[7],dut.u_d12.mem[6],dut.u_d12.mem[5],dut.u_d12.mem[4],dut.u_d12.mem[3],dut.u_d12.mem[2],dut.u_d12.mem[1],dut.u_d12.mem[0]};
assign dut_state[849+:1]=dut.u_d12.we_d;
assign dut_state[850+:4]=dut.u_d18.q;
assign dut_state[854+:4]=dut.u_d19.q;
assign dut_state[858+:1]=dut.u_d20.ck_d;
assign dut_state[859+:4]=dut.u_d20.jk_pre;
assign dut_state[863+:1]=dut.u_d20.qa;
assign dut_state[864+:1]=dut.u_d20.qb;
assign dut_state[865+:1]=dut.u_d22.ck_d;
assign dut_state[866+:4]=dut.u_d22.q;
assign dut_state[870+:6]=dut.u_d22.setup_pre;
assign dut_state[876+:5]=dut.u_e02.q;
assign dut_state[881+:1]=dut.u_e04.cka_d;
assign dut_state[882+:1]=dut.u_e04.ckb_d;
assign dut_state[883+:1]=dut.u_e04.d_pre_a;
assign dut_state[884+:1]=dut.u_e04.d_pre_b;
assign dut_state[885+:1]=dut.u_e04.qa;
assign dut_state[886+:1]=dut.u_e04.qb;
assign dut_state[887+:1]=dut.u_e05.cka_d;
assign dut_state[888+:1]=dut.u_e05.ckb_d;
assign dut_state[889+:1]=dut.u_e05.d_pre_a;
assign dut_state[890+:1]=dut.u_e05.d_pre_b;
assign dut_state[891+:1]=dut.u_e05.qa;
assign dut_state[892+:1]=dut.u_e05.qb;
assign dut_state[893+:1]=dut.u_e06.cka_d;
assign dut_state[894+:1]=dut.u_e06.ckb_d;
assign dut_state[895+:1]=dut.u_e06.d_pre_a;
assign dut_state[896+:1]=dut.u_e06.d_pre_b;
assign dut_state[897+:1]=dut.u_e06.qa;
assign dut_state[898+:1]=dut.u_e06.qb;
assign dut_state[899+:1]=dut.u_e08.ck_d;
assign dut_state[900+:6]=dut.u_e08.d_pre;
assign dut_state[906+:6]=dut.u_e08.q;
assign dut_state[912+:1]=dut.u_e10.ck_d;
assign dut_state[913+:6]=dut.u_e10.d_pre;
assign dut_state[919+:6]=dut.u_e10.q;
assign dut_state[925+:1]=dut.u_e12.ck_d;
assign dut_state[926+:6]=dut.u_e12.d_pre;
assign dut_state[932+:6]=dut.u_e12.q;
assign dut_state[938+:1]=dut.u_e13.ck_d;
assign dut_state[939+:4]=dut.u_e13.jk_pre;
assign dut_state[943+:1]=dut.u_e13.qa;
assign dut_state[944+:1]=dut.u_e13.qb;
assign dut_state[945+:1]=dut.u_e14.cka_d;
assign dut_state[946+:1]=dut.u_e14.ckb_d;
assign dut_state[947+:1]=dut.u_e14.d_pre_a;
assign dut_state[948+:1]=dut.u_e14.d_pre_b;
assign dut_state[949+:1]=dut.u_e14.qa;
assign dut_state[950+:1]=dut.u_e14.qb;
assign dut_state[951+:1]=dut.u_e15.cka_d;
assign dut_state[952+:1]=dut.u_e15.ckb_d;
assign dut_state[953+:1]=dut.u_e15.d_pre_a;
assign dut_state[954+:1]=dut.u_e15.d_pre_b;
assign dut_state[955+:1]=dut.u_e15.qa;
assign dut_state[956+:1]=dut.u_e15.qb;
assign dut_state[957+:4]=dut.u_e16.a_lat;
assign dut_state[961+:1]=dut.u_e16.ce_lat;
assign dut_state[962+:4]=dut.u_e16.d_lat;
assign dut_state[966+:64]={dut.u_e16.mem[15],dut.u_e16.mem[14],dut.u_e16.mem[13],dut.u_e16.mem[12],dut.u_e16.mem[11],dut.u_e16.mem[10],dut.u_e16.mem[9],dut.u_e16.mem[8],dut.u_e16.mem[7],dut.u_e16.mem[6],dut.u_e16.mem[5],dut.u_e16.mem[4],dut.u_e16.mem[3],dut.u_e16.mem[2],dut.u_e16.mem[1],dut.u_e16.mem[0]};
assign dut_state[1030+:1]=dut.u_e16.we_d;
assign dut_state[1031+:1]=dut.u_e17.cka_d;
assign dut_state[1032+:1]=dut.u_e17.ckb_d;
assign dut_state[1033+:1]=dut.u_e17.d_pre_a;
assign dut_state[1034+:1]=dut.u_e17.d_pre_b;
assign dut_state[1035+:1]=dut.u_e17.qa;
assign dut_state[1036+:1]=dut.u_e17.qb;
assign dut_state[1037+:4]=dut.u_e18.q;
assign dut_state[1041+:4]=dut.u_e20.q;
assign dut_state[1045+:4]=dut.u_e21.q;
assign dut_state[1049+:1]=dut.u_f01.qa;
assign dut_state[1050+:1]=dut.u_f01.qb;
assign dut_state[1051+:1]=dut.u_f02.qa;
assign dut_state[1052+:1]=dut.u_f02.qb;
assign dut_state[1053+:1]=dut.u_f08.ck_d;
assign dut_state[1054+:6]=dut.u_f08.d_pre;
assign dut_state[1060+:6]=dut.u_f08.q;
assign dut_state[1066+:1]=dut.u_f09.ck_d;
assign dut_state[1067+:4]=dut.u_f09.d_pre;
assign dut_state[1071+:4]=dut.u_f09.q;
assign dut_state[1075+:1]=dut.u_f10.ck_d;
assign dut_state[1076+:4]=dut.u_f10.d_pre;
assign dut_state[1080+:4]=dut.u_f10.q;
assign dut_state[1084+:1]=dut.u_f11.ck_d;
assign dut_state[1085+:4]=dut.u_f11.d_pre;
assign dut_state[1089+:4]=dut.u_f11.q;
assign dut_state[1093+:1]=dut.u_f12.ck_d;
assign dut_state[1094+:4]=dut.u_f12.d_pre;
assign dut_state[1098+:4]=dut.u_f12.q;
assign dut_state[1102+:1]=dut.u_f14.ck_d;
assign dut_state[1103+:4]=dut.u_f14.d_pre;
assign dut_state[1107+:4]=dut.u_f14.q;
assign dut_state[1111+:1]=dut.u_f15.ck_d;
assign dut_state[1112+:4]=dut.u_f15.d_pre;
assign dut_state[1116+:4]=dut.u_f15.q;
assign dut_state[1120+:4]=dut.u_f16.a_lat;
assign dut_state[1124+:1]=dut.u_f16.ce_lat;
assign dut_state[1125+:4]=dut.u_f16.d_lat;
assign dut_state[1129+:64]={dut.u_f16.mem[15],dut.u_f16.mem[14],dut.u_f16.mem[13],dut.u_f16.mem[12],dut.u_f16.mem[11],dut.u_f16.mem[10],dut.u_f16.mem[9],dut.u_f16.mem[8],dut.u_f16.mem[7],dut.u_f16.mem[6],dut.u_f16.mem[5],dut.u_f16.mem[4],dut.u_f16.mem[3],dut.u_f16.mem[2],dut.u_f16.mem[1],dut.u_f16.mem[0]};
assign dut_state[1193+:1]=dut.u_f16.we_d;
assign dut_state[1194+:4]=dut.u_f17.a_lat;
assign dut_state[1198+:1]=dut.u_f17.ce_lat;
assign dut_state[1199+:4]=dut.u_f17.d_lat;
assign dut_state[1203+:64]={dut.u_f17.mem[15],dut.u_f17.mem[14],dut.u_f17.mem[13],dut.u_f17.mem[12],dut.u_f17.mem[11],dut.u_f17.mem[10],dut.u_f17.mem[9],dut.u_f17.mem[8],dut.u_f17.mem[7],dut.u_f17.mem[6],dut.u_f17.mem[5],dut.u_f17.mem[4],dut.u_f17.mem[3],dut.u_f17.mem[2],dut.u_f17.mem[1],dut.u_f17.mem[0]};
assign dut_state[1267+:1]=dut.u_f17.we_d;
assign dut_state[1268+:4]=dut.u_f18.q;
assign dut_state[1272+:4]=dut.u_f20.q;
assign dut_state[1276+:4]=dut.u_f21.q;
assign dut_state[1280+:5]=dut.u_g06.q;
assign dut_state[1285+:4]=dut.u_g08.q;
assign dut_state[1289+:4]=dut.u_g09.q;
assign dut_state[1293+:4]=dut.u_g10.q;
assign dut_state[1297+:4]=dut.u_g11.q;
assign dut_state[1301+:4]=dut.u_g12.q;
assign dut_state[1305+:1]=dut.u_g17.cp_d;
assign dut_state[1306+:1]=dut.u_g17.cwe_pre;
assign dut_state[1307+:1]=dut.u_g17.d_pre;
assign dut_state[1308+:16]=dut.u_g17.r;
assign dut_state[1324+:1]=dut.u_g20.ck_d;
assign dut_state[1325+:6]=dut.u_g20.d_pre;
assign dut_state[1331+:6]=dut.u_g20.q;
assign dut_state[1337+:1]=dut.u_g21.ck_d;
assign dut_state[1338+:4]=dut.u_g21.q;
assign dut_state[1342+:6]=dut.u_g21.setup_pre;
assign dut_state[1348+:1]=dut.u_h04.cka_d;
assign dut_state[1349+:1]=dut.u_h04.ckb_d;
assign dut_state[1350+:1]=dut.u_h04.d_pre_a;
assign dut_state[1351+:1]=dut.u_h04.d_pre_b;
assign dut_state[1352+:1]=dut.u_h04.qa;
assign dut_state[1353+:1]=dut.u_h04.qb;
assign dut_state[1354+:1]=dut.u_h06.cka_d;
assign dut_state[1355+:1]=dut.u_h06.ckb_d;
assign dut_state[1356+:1]=dut.u_h06.d_pre_a;
assign dut_state[1357+:1]=dut.u_h06.d_pre_b;
assign dut_state[1358+:1]=dut.u_h06.qa;
assign dut_state[1359+:1]=dut.u_h06.qb;
assign dut_state[1360+:1]=dut.u_h08.ck_d;
assign dut_state[1361+:6]=dut.u_h08.d_pre;
assign dut_state[1367+:6]=dut.u_h08.q;
assign dut_state[1373+:1]=dut.u_h12.ck_d;
assign dut_state[1374+:6]=dut.u_h12.d_pre;
assign dut_state[1380+:6]=dut.u_h12.q;
assign dut_state[1386+:1]=dut.u_h13.ck_d;
assign dut_state[1387+:6]=dut.u_h13.d_pre;
assign dut_state[1393+:6]=dut.u_h13.q;
assign dut_state[1399+:1]=dut.u_h17.ck_d;
assign dut_state[1400+:6]=dut.u_h17.d_pre;
assign dut_state[1406+:6]=dut.u_h17.q;
assign dut_state[1412+:1]=dut.u_h24.ck_d;
assign dut_state[1413+:6]=dut.u_h24.d_pre;
assign dut_state[1419+:6]=dut.u_h24.q;
assign dut_state[1425+:1]=dut.u_i08.ck_d;
assign dut_state[1426+:4]=dut.u_i08.d_pre;
assign dut_state[1430+:1]=dut.u_i08.dl_pre;
assign dut_state[1431+:1]=dut.u_i08.dr_pre;
assign dut_state[1432+:4]=dut.u_i08.q;
assign dut_state[1436+:2]=dut.u_i08.s_pre;
assign dut_state[1438+:1]=dut.u_i09.ck_d;
assign dut_state[1439+:4]=dut.u_i09.d_pre;
assign dut_state[1443+:1]=dut.u_i09.dl_pre;
assign dut_state[1444+:1]=dut.u_i09.dr_pre;
assign dut_state[1445+:4]=dut.u_i09.q;
assign dut_state[1449+:2]=dut.u_i09.s_pre;
assign dut_state[1451+:1]=dut.u_i10.ck_d;
assign dut_state[1452+:4]=dut.u_i10.d_pre;
assign dut_state[1456+:1]=dut.u_i10.dl_pre;
assign dut_state[1457+:1]=dut.u_i10.dr_pre;
assign dut_state[1458+:4]=dut.u_i10.q;
assign dut_state[1462+:2]=dut.u_i10.s_pre;
assign dut_state[1464+:1]=dut.u_i11.ck_d;
assign dut_state[1465+:4]=dut.u_i11.d_pre;
assign dut_state[1469+:1]=dut.u_i11.dl_pre;
assign dut_state[1470+:1]=dut.u_i11.dr_pre;
assign dut_state[1471+:4]=dut.u_i11.q;
assign dut_state[1475+:2]=dut.u_i11.s_pre;
assign dut_state[1477+:1]=dut.u_i12.cin_pre;
assign dut_state[1478+:1]=dut.u_i12.ck_d;
assign dut_state[1479+:4]=dut.u_i12.d_pre;
assign dut_state[1483+:4]=dut.u_i12.q;
assign dut_state[1487+:1]=dut.u_i12.sd_pre;
assign dut_state[1488+:1]=dut.u_i12.su_pre;
assign dut_state[1489+:1]=dut.u_i13.cin_pre;
assign dut_state[1490+:1]=dut.u_i13.ck_d;
assign dut_state[1491+:4]=dut.u_i13.d_pre;
assign dut_state[1495+:4]=dut.u_i13.q;
assign dut_state[1499+:1]=dut.u_i13.sd_pre;
assign dut_state[1500+:1]=dut.u_i13.su_pre;
assign dut_state[1501+:1]=dut.u_i14.ck_d;
assign dut_state[1502+:4]=dut.u_i14.d_pre;
assign dut_state[1506+:1]=dut.u_i14.dl_pre;
assign dut_state[1507+:1]=dut.u_i14.dr_pre;
assign dut_state[1508+:4]=dut.u_i14.q;
assign dut_state[1512+:2]=dut.u_i14.s_pre;
assign dut_state[1514+:1]=dut.u_i15.ck_d;
assign dut_state[1515+:4]=dut.u_i15.d_pre;
assign dut_state[1519+:1]=dut.u_i15.dl_pre;
assign dut_state[1520+:1]=dut.u_i15.dr_pre;
assign dut_state[1521+:4]=dut.u_i15.q;
assign dut_state[1525+:2]=dut.u_i15.s_pre;
assign dut_state[1527+:1]=dut.u_i16.ck_d;
assign dut_state[1528+:4]=dut.u_i16.d_pre;
assign dut_state[1532+:1]=dut.u_i16.dl_pre;
assign dut_state[1533+:1]=dut.u_i16.dr_pre;
assign dut_state[1534+:4]=dut.u_i16.q;
assign dut_state[1538+:2]=dut.u_i16.s_pre;
assign dut_state[1540+:1]=dut.u_i17.ck_d;
assign dut_state[1541+:4]=dut.u_i17.d_pre;
assign dut_state[1545+:1]=dut.u_i17.dl_pre;
assign dut_state[1546+:1]=dut.u_i17.dr_pre;
assign dut_state[1547+:4]=dut.u_i17.q;
assign dut_state[1551+:2]=dut.u_i17.s_pre;
assign dut_state[1553+:1]=dut.u_i22.cka_d;
assign dut_state[1554+:1]=dut.u_i22.ckb_d;
assign dut_state[1555+:1]=dut.u_i22.d_pre_a;
assign dut_state[1556+:1]=dut.u_i22.d_pre_b;
assign dut_state[1557+:1]=dut.u_i22.qa;
assign dut_state[1558+:1]=dut.u_i22.qb;
assign dut_state[1559+:1]=dut.u_j04.cka_d;
assign dut_state[1560+:1]=dut.u_j04.ckb_d;
assign dut_state[1561+:1]=dut.u_j04.d_pre_a;
assign dut_state[1562+:1]=dut.u_j04.d_pre_b;
assign dut_state[1563+:1]=dut.u_j04.qa;
assign dut_state[1564+:1]=dut.u_j04.qb;
assign dut_state[1565+:1]=dut.u_j05.cp_d;
assign dut_state[1566+:1]=dut.u_j05.cwe_pre;
assign dut_state[1567+:1]=dut.u_j05.d_pre;
assign dut_state[1568+:16]=dut.u_j05.r;
assign dut_state[1584+:4]=dut.u_j08.a_lat;
assign dut_state[1588+:1]=dut.u_j08.ce_lat;
assign dut_state[1589+:4]=dut.u_j08.d_lat;
assign dut_state[1593+:64]={dut.u_j08.mem[15],dut.u_j08.mem[14],dut.u_j08.mem[13],dut.u_j08.mem[12],dut.u_j08.mem[11],dut.u_j08.mem[10],dut.u_j08.mem[9],dut.u_j08.mem[8],dut.u_j08.mem[7],dut.u_j08.mem[6],dut.u_j08.mem[5],dut.u_j08.mem[4],dut.u_j08.mem[3],dut.u_j08.mem[2],dut.u_j08.mem[1],dut.u_j08.mem[0]};
assign dut_state[1657+:1]=dut.u_j08.we_d;
assign dut_state[1658+:4]=dut.u_j09.a_lat;
assign dut_state[1662+:1]=dut.u_j09.ce_lat;
assign dut_state[1663+:4]=dut.u_j09.d_lat;
assign dut_state[1667+:64]={dut.u_j09.mem[15],dut.u_j09.mem[14],dut.u_j09.mem[13],dut.u_j09.mem[12],dut.u_j09.mem[11],dut.u_j09.mem[10],dut.u_j09.mem[9],dut.u_j09.mem[8],dut.u_j09.mem[7],dut.u_j09.mem[6],dut.u_j09.mem[5],dut.u_j09.mem[4],dut.u_j09.mem[3],dut.u_j09.mem[2],dut.u_j09.mem[1],dut.u_j09.mem[0]};
assign dut_state[1731+:1]=dut.u_j09.we_d;
assign dut_state[1732+:4]=dut.u_j10.a_lat;
assign dut_state[1736+:1]=dut.u_j10.ce_lat;
assign dut_state[1737+:4]=dut.u_j10.d_lat;
assign dut_state[1741+:64]={dut.u_j10.mem[15],dut.u_j10.mem[14],dut.u_j10.mem[13],dut.u_j10.mem[12],dut.u_j10.mem[11],dut.u_j10.mem[10],dut.u_j10.mem[9],dut.u_j10.mem[8],dut.u_j10.mem[7],dut.u_j10.mem[6],dut.u_j10.mem[5],dut.u_j10.mem[4],dut.u_j10.mem[3],dut.u_j10.mem[2],dut.u_j10.mem[1],dut.u_j10.mem[0]};
assign dut_state[1805+:1]=dut.u_j10.we_d;
assign dut_state[1806+:4]=dut.u_j11.a_lat;
assign dut_state[1810+:1]=dut.u_j11.ce_lat;
assign dut_state[1811+:4]=dut.u_j11.d_lat;
assign dut_state[1815+:64]={dut.u_j11.mem[15],dut.u_j11.mem[14],dut.u_j11.mem[13],dut.u_j11.mem[12],dut.u_j11.mem[11],dut.u_j11.mem[10],dut.u_j11.mem[9],dut.u_j11.mem[8],dut.u_j11.mem[7],dut.u_j11.mem[6],dut.u_j11.mem[5],dut.u_j11.mem[4],dut.u_j11.mem[3],dut.u_j11.mem[2],dut.u_j11.mem[1],dut.u_j11.mem[0]};
assign dut_state[1879+:1]=dut.u_j11.we_d;
assign dut_state[1880+:4]=dut.u_j12.a_lat;
assign dut_state[1884+:1]=dut.u_j12.ce_lat;
assign dut_state[1885+:4]=dut.u_j12.d_lat;
assign dut_state[1889+:64]={dut.u_j12.mem[15],dut.u_j12.mem[14],dut.u_j12.mem[13],dut.u_j12.mem[12],dut.u_j12.mem[11],dut.u_j12.mem[10],dut.u_j12.mem[9],dut.u_j12.mem[8],dut.u_j12.mem[7],dut.u_j12.mem[6],dut.u_j12.mem[5],dut.u_j12.mem[4],dut.u_j12.mem[3],dut.u_j12.mem[2],dut.u_j12.mem[1],dut.u_j12.mem[0]};
assign dut_state[1953+:1]=dut.u_j12.we_d;
assign dut_state[1954+:4]=dut.u_j13.a_lat;
assign dut_state[1958+:1]=dut.u_j13.ce_lat;
assign dut_state[1959+:4]=dut.u_j13.d_lat;
assign dut_state[1963+:64]={dut.u_j13.mem[15],dut.u_j13.mem[14],dut.u_j13.mem[13],dut.u_j13.mem[12],dut.u_j13.mem[11],dut.u_j13.mem[10],dut.u_j13.mem[9],dut.u_j13.mem[8],dut.u_j13.mem[7],dut.u_j13.mem[6],dut.u_j13.mem[5],dut.u_j13.mem[4],dut.u_j13.mem[3],dut.u_j13.mem[2],dut.u_j13.mem[1],dut.u_j13.mem[0]};
assign dut_state[2027+:1]=dut.u_j13.we_d;
assign dut_state[2028+:4]=dut.u_j14.a_lat;
assign dut_state[2032+:1]=dut.u_j14.ce_lat;
assign dut_state[2033+:4]=dut.u_j14.d_lat;
assign dut_state[2037+:64]={dut.u_j14.mem[15],dut.u_j14.mem[14],dut.u_j14.mem[13],dut.u_j14.mem[12],dut.u_j14.mem[11],dut.u_j14.mem[10],dut.u_j14.mem[9],dut.u_j14.mem[8],dut.u_j14.mem[7],dut.u_j14.mem[6],dut.u_j14.mem[5],dut.u_j14.mem[4],dut.u_j14.mem[3],dut.u_j14.mem[2],dut.u_j14.mem[1],dut.u_j14.mem[0]};
assign dut_state[2101+:1]=dut.u_j14.we_d;
assign dut_state[2102+:4]=dut.u_j15.a_lat;
assign dut_state[2106+:1]=dut.u_j15.ce_lat;
assign dut_state[2107+:4]=dut.u_j15.d_lat;
assign dut_state[2111+:64]={dut.u_j15.mem[15],dut.u_j15.mem[14],dut.u_j15.mem[13],dut.u_j15.mem[12],dut.u_j15.mem[11],dut.u_j15.mem[10],dut.u_j15.mem[9],dut.u_j15.mem[8],dut.u_j15.mem[7],dut.u_j15.mem[6],dut.u_j15.mem[5],dut.u_j15.mem[4],dut.u_j15.mem[3],dut.u_j15.mem[2],dut.u_j15.mem[1],dut.u_j15.mem[0]};
assign dut_state[2175+:1]=dut.u_j15.we_d;
assign dut_state[2176+:4]=dut.u_j16.a_lat;
assign dut_state[2180+:1]=dut.u_j16.ce_lat;
assign dut_state[2181+:4]=dut.u_j16.d_lat;
assign dut_state[2185+:64]={dut.u_j16.mem[15],dut.u_j16.mem[14],dut.u_j16.mem[13],dut.u_j16.mem[12],dut.u_j16.mem[11],dut.u_j16.mem[10],dut.u_j16.mem[9],dut.u_j16.mem[8],dut.u_j16.mem[7],dut.u_j16.mem[6],dut.u_j16.mem[5],dut.u_j16.mem[4],dut.u_j16.mem[3],dut.u_j16.mem[2],dut.u_j16.mem[1],dut.u_j16.mem[0]};
assign dut_state[2249+:1]=dut.u_j16.we_d;
assign dut_state[2250+:4]=dut.u_j17.a_lat;
assign dut_state[2254+:1]=dut.u_j17.ce_lat;
assign dut_state[2255+:4]=dut.u_j17.d_lat;
assign dut_state[2259+:64]={dut.u_j17.mem[15],dut.u_j17.mem[14],dut.u_j17.mem[13],dut.u_j17.mem[12],dut.u_j17.mem[11],dut.u_j17.mem[10],dut.u_j17.mem[9],dut.u_j17.mem[8],dut.u_j17.mem[7],dut.u_j17.mem[6],dut.u_j17.mem[5],dut.u_j17.mem[4],dut.u_j17.mem[3],dut.u_j17.mem[2],dut.u_j17.mem[1],dut.u_j17.mem[0]};
assign dut_state[2323+:1]=dut.u_j17.we_d;
assign dut_state[2324+:1]=dut.u_j19.ck_d;
assign dut_state[2325+:4]=dut.u_j19.jk_pre;
assign dut_state[2329+:1]=dut.u_j19.qa;
assign dut_state[2330+:1]=dut.u_j19.qb;
assign dut_state[2331+:32]=dut.u_j20.acc;
assign dut_state[2363+:1]=dut.u_j20.osc;
assign dut_state[2364+:1]=dut.u_j21.cin_pre;
assign dut_state[2365+:1]=dut.u_j21.ck_d;
assign dut_state[2366+:4]=dut.u_j21.d_pre;
assign dut_state[2370+:4]=dut.u_j21.q;
assign dut_state[2374+:1]=dut.u_j21.sd_pre;
assign dut_state[2375+:1]=dut.u_j21.su_pre;
assign dut_state[2376+:1]=dut.u_j24.ck_d;
assign dut_state[2377+:6]=dut.u_j24.d_pre;
assign dut_state[2383+:6]=dut.u_j24.q;
assign dut_state[2389+:1]=dut.u_k04.ck_d;
assign dut_state[2390+:4]=dut.u_k04.jk_pre;
assign dut_state[2394+:1]=dut.u_k04.qa;
assign dut_state[2395+:1]=dut.u_k04.qb;
assign dut_state[2396+:1]=dut.u_k07.ck_d;
assign dut_state[2397+:4]=dut.u_k07.jk_pre;
assign dut_state[2401+:1]=dut.u_k07.qa;
assign dut_state[2402+:1]=dut.u_k07.qb;
assign dut_state[2403+:1]=dut.u_k09.ck_d;
assign dut_state[2404+:6]=dut.u_k09.d_pre;
assign dut_state[2410+:6]=dut.u_k09.q;
assign dut_state[2416+:1]=dut.u_k10.ck_d;
assign dut_state[2417+:6]=dut.u_k10.d_pre;
assign dut_state[2423+:6]=dut.u_k10.q;
assign dut_state[2429+:1]=dut.u_k11.ck_d;
assign dut_state[2430+:6]=dut.u_k11.d_pre;
assign dut_state[2436+:6]=dut.u_k11.q;
assign dut_state[2442+:1]=dut.u_k14.ck_d;
assign dut_state[2443+:6]=dut.u_k14.d_pre;
assign dut_state[2449+:6]=dut.u_k14.q;
assign dut_state[2455+:1]=dut.u_k15.ck_d;
assign dut_state[2456+:6]=dut.u_k15.d_pre;
assign dut_state[2462+:6]=dut.u_k15.q;
assign dut_state[2468+:1]=dut.u_k16.ck_d;
assign dut_state[2469+:6]=dut.u_k16.d_pre;
assign dut_state[2475+:6]=dut.u_k16.q;
assign dut_state[2481+:1]=dut.u_k19.ck_d;
assign dut_state[2482+:4]=dut.u_k19.jk_pre;
assign dut_state[2486+:1]=dut.u_k19.qa;
assign dut_state[2487+:1]=dut.u_k19.qb;
assign dut_state[2488+:1]=dut.u_k20.cka_d;
assign dut_state[2489+:1]=dut.u_k20.ckb_d;
assign dut_state[2490+:1]=dut.u_k20.d_pre_a;
assign dut_state[2491+:1]=dut.u_k20.d_pre_b;
assign dut_state[2492+:1]=dut.u_k20.qa;
assign dut_state[2493+:1]=dut.u_k20.qb;
assign dut_state[2494+:1]=dut.u_k22.ck_d;
assign dut_state[2495+:4]=dut.u_k22.jk_pre;
assign dut_state[2499+:1]=dut.u_k22.qa;
assign dut_state[2500+:1]=dut.u_k22.qb;
assign dut_state[2501+:1]=dut.u_l02.cka_d;
assign dut_state[2502+:1]=dut.u_l02.ckb_d;
assign dut_state[2503+:1]=dut.u_l02.d_pre_a;
assign dut_state[2504+:1]=dut.u_l02.d_pre_b;
assign dut_state[2505+:1]=dut.u_l02.qa;
assign dut_state[2506+:1]=dut.u_l02.qb;
assign dut_state[2507+:1]=dut.u_l04.cka_d;
assign dut_state[2508+:1]=dut.u_l04.ckb_d;
assign dut_state[2509+:1]=dut.u_l04.d_pre_a;
assign dut_state[2510+:1]=dut.u_l04.d_pre_b;
assign dut_state[2511+:1]=dut.u_l04.qa;
assign dut_state[2512+:1]=dut.u_l04.qb;
assign dut_state[2513+:1]=dut.u_l06.ck_d;
assign dut_state[2514+:4]=dut.u_l06.jk_pre;
assign dut_state[2518+:1]=dut.u_l06.qa;
assign dut_state[2519+:1]=dut.u_l06.qb;
assign dut_state[2520+:1]=dut.u_l07.cka_d;
assign dut_state[2521+:1]=dut.u_l07.ckb_d;
assign dut_state[2522+:1]=dut.u_l07.d_pre_a;
assign dut_state[2523+:1]=dut.u_l07.d_pre_b;
assign dut_state[2524+:1]=dut.u_l07.qa;
assign dut_state[2525+:1]=dut.u_l07.qb;
assign dut_state[2526+:1]=dut.u_l09.ck_d;
assign dut_state[2527+:4]=dut.u_l09.q;
assign dut_state[2531+:6]=dut.u_l09.setup_pre;
assign dut_state[2537+:1]=dut.u_l12.ck_d;
assign dut_state[2538+:4]=dut.u_l12.q;
assign dut_state[2542+:6]=dut.u_l12.setup_pre;
assign dut_state[2548+:1]=dut.u_l13.ck_d;
assign dut_state[2549+:4]=dut.u_l13.q;
assign dut_state[2553+:6]=dut.u_l13.setup_pre;
assign dut_state[2559+:1]=dut.u_l16.ck_d;
assign dut_state[2560+:4]=dut.u_l16.q;
assign dut_state[2564+:6]=dut.u_l16.setup_pre;
assign dut_state[2570+:1]=dut.u_l18.ck_d;
assign dut_state[2571+:6]=dut.u_l18.d_pre;
assign dut_state[2577+:6]=dut.u_l18.q;
assign dut_state[2583+:1]=dut.u_l19.ck_d;
assign dut_state[2584+:4]=dut.u_l19.jk_pre;
assign dut_state[2588+:1]=dut.u_l19.qa;
assign dut_state[2589+:1]=dut.u_l19.qb;
assign dut_state[2590+:1]=dut.u_l20.cka_d;
assign dut_state[2591+:1]=dut.u_l20.ckb_d;
assign dut_state[2592+:1]=dut.u_l20.d_pre_a;
assign dut_state[2593+:1]=dut.u_l20.d_pre_b;
assign dut_state[2594+:1]=dut.u_l20.qa;
assign dut_state[2595+:1]=dut.u_l20.qb;
assign dut_state[2596+:1]=dut.u_l22.ck_d;
assign dut_state[2597+:6]=dut.u_l22.d_pre;
assign dut_state[2603+:6]=dut.u_l22.q;
assign dut_state[2609+:1]=dut.u_l23.ck_d;
assign dut_state[2610+:6]=dut.u_l23.d_pre;
assign dut_state[2616+:6]=dut.u_l23.q;
assign dut_state[2622+:8]=dut.u_receive_monitor.consumed;
assign dut_state[2630+:8]=dut.u_receive_monitor.cpu_status;
assign dut_state[2638+:1]=dut.u_receive_monitor.input_d;
assign dut_state[2639+:8]=dut.u_receive_monitor.received;
assign dut_state[2647+:8]=dut.u_receive_monitor.wire_status;
assign dut_state[2655+:1]=dut.u_receive_monitor.write_d;
assign dut_probe=1'b0;
assign all_helpers_frozen=&{dut.state_frozen,dut.u_a03.state_frozen,dut.u_a05.state_frozen,dut.u_d08.state_frozen,dut.u_d09.state_frozen,dut.u_d10.state_frozen,dut.u_d11.state_frozen,dut.u_d12.state_frozen,dut.u_e16.state_frozen,dut.u_f16.state_frozen,dut.u_f17.state_frozen,dut.u_g17.state_frozen,dut.u_j05.state_frozen,dut.u_j08.state_frozen,dut.u_j09.state_frozen,dut.u_j10.state_frozen,dut.u_j11.state_frozen,dut.u_j12.state_frozen,dut.u_j13.state_frozen,dut.u_j14.state_frozen,dut.u_j15.state_frozen,dut.u_j16.state_frozen,dut.u_j17.state_frozen,dut.u_j20.state_frozen,dut.u_receive_monitor.state_frozen};
endmodule
