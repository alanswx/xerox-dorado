#include "Vglobal_fixture.h"
#include "verilated.h"
#include "parameters.h"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
static Vglobal_fixture d;
static unsigned edges=0,checks=0;static uint32_t seed=0x19b04d77;
static uint32_t rnd(){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static void check(bool condition,const char*why){if(!condition)throw std::runtime_error(std::string(why)+" at edge "+std::to_string(edges));++checks;}
static void pins(){
 auto*p=reinterpret_cast<unsigned char*>(&d.stimulus);
 for(unsigned i=0;i<sizeof(d.stimulus);++i)p[i]=i<(STIM_BITS+7)/8?rnd():0;
 if(STIM_BITS%8)p[STIM_BITS/8]&=(1u<<(STIM_BITS%8))-1;
}
static void equal(){
 check(!std::memcmp(&d.reference_outputs,&d.dut_outputs,sizeof(d.dut_outputs)),"ordinary outputs differ");
 check(!std::memcmp(&d.reference_state,&d.dut_state,sizeof(d.dut_state)),"physical state differs");
 check(!std::memcmp(&d.reference_probe,&d.dut_probe,sizeof(d.dut_probe)),"RAM probe differs");
}
static void tick(bool compare=false){d.clk=0;d.eval();d.clk=1;d.eval();++edges;if(compare)equal();}
static uint32_t access(unsigned word,bool writing,uint32_t value){
 d.index=word;d.write=writing;d.data=value;d.request=1;tick(true);d.request=0;
 for(unsigned age=0;!d.dut_done;++age){check(age<FF_BITS+8,"whole-board scan deadline");tick(true);}
 check(d.reference_done&&!d.dut_error&&!d.reference_error,"whole-board scan completion differs");
 check(d.dut_result==d.reference_result,"whole-board scan result differs");return d.dut_result;
}
static void restore_check(){
 auto before=d.dut_state;std::vector<uint32_t> saved;
 for(unsigned word=0;word<FF_WORDS;++word)saved.push_back(access(SCAN_WORD+word,false,0));
 check(!std::memcmp(&before,&d.dut_state,sizeof(before)),"whole-board scan read changed physical state");
 for(unsigned word=0;word<FF_WORDS;++word)access(SCAN_WORD+word,true,saved[word]^0x3ffff);
 for(unsigned word=0;word<FF_WORDS;++word)access(SCAN_WORD+word,true,saved[word]);
 check(!std::memcmp(&before,&d.dut_state,sizeof(before)),"whole-board restore changed physical state");
 d.freeze=d.held=d.global_hold=0;d.request=0;
 for(unsigned n=0;n<2000;++n){pins();d.advance=(rnd()&3)!=0;d.probe_index=rnd();tick(true);}
 d.global_hold=1;d.advance=1;d.freeze=d.held=1;for(unsigned n=0;n<4;++n)tick(true);
}
int main(int argc,char**argv){
 Verilated::commandArgs(argc,argv);
 try{
  d.eval();equal();d.system_reset=1;for(unsigned i=0;i<3;++i)tick(true);d.system_reset=0;
  for(unsigned i=0;i<20000;++i){pins();d.advance=(rnd()&3)!=0;d.request=rnd()&1;d.write=rnd()&1;d.index=rnd();d.data=rnd()&0x3ffff;d.probe_index=rnd();tick(true);check(!d.dut_done,"running access admitted");}
  d.request=0;d.freeze=d.held=0;d.global_hold=1;d.advance=1;
  for(unsigned i=0;i<4;++i)tick();equal();
  check(d.dut_frozen&&d.all_helpers_frozen,"forced hold did not freeze every helper");
  check(!d.dut_hold&&!d.dut_fault,"idle hold relied on local quarantine");
  auto saved=d.dut_state;
  // Reference is held through its already-qualified boundary. DUT raw
  // freeze/held remain ZERO, so only the new global input can protect it.
  for(unsigned row=0;row<32;++row){
   d.probe_index=rnd();d.eval();auto memory=d.dut_probe;
   for(unsigned i=0;i<4;++i){pins();d.request=d.write=1;d.index=rnd();d.data=rnd()&0x3ffff;tick();
    check(d.dut_frozen&&d.all_helpers_frozen,"forced hold helper escaped");
    check(!std::memcmp(&saved,&d.dut_state,sizeof(saved)),"forced hold changed physical state");
    check(!std::memcmp(&memory,&d.dut_probe,sizeof(memory)),"forced hold changed RAM");
    check(!d.dut_done,"forced hold admitted unowned request");equal();
   }
  }
  // Both boards execute the same actual partial scan; only DUT then aborts.
  d.request=0;d.freeze=d.held=1;tick();tick();restore_check();d.index=SCAN_WORD;d.data=0x315ca;d.write=d.request=1;tick();
  check(d.dut_hold,"physical scan not active");d.request=0;
  for(unsigned i=0;i<5;++i)tick(true);
  d.global_abort=1;tick();
  check(d.dut_fault&&d.dut_hold&&d.dut_done&&d.dut_error,"global abort did not quarantine scan");
  auto quarantined=d.dut_state;auto memory=d.dut_probe;
  for(unsigned i=0;i<32;++i){pins();d.request=d.write=1;d.index=AUX_WORD;d.data=0x3ffff;tick();
   check(d.dut_frozen&&d.all_helpers_frozen,"abort released memory helper");
   check(!std::memcmp(&quarantined,&d.dut_state,sizeof(quarantined)),"aborted physical state changed");
   check(!std::memcmp(&memory,&d.dut_probe,sizeof(memory)),"aborted RAM changed");
  }
  // After SYSTEM reset clears local scan quarantine, a still-asserted global
  // abort must also block non-FF requests; local fault is no longer the gate.
  d.request=0;d.system_reset=1;tick();d.system_reset=0;tick();tick();
  check(!d.dut_fault&&!d.dut_hold&&d.dut_frozen,"local reset/boundary differs");
  d.request=d.write=1;d.index=AUX_WORD;d.data=0x3ffff;tick();
  check(!d.dut_done&&!d.dut_error,"global abort admitted auxiliary access");
  check(d.all_helpers_frozen,"global abort dropped forced hold");
  std::printf("PHASE WHOLE BOARD PASS host=%u checks=%u ordinary=20000 forced_rows=32 abort=32\n",edges,checks);return 0;
 }catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}
}
