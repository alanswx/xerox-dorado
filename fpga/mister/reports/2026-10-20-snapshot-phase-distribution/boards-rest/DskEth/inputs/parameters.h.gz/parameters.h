constexpr unsigned STIM_BITS=92,SCAN_WORD=0,AUX_WORD=3744;
constexpr unsigned FF_BITS=1070,FF_WORDS=60;
