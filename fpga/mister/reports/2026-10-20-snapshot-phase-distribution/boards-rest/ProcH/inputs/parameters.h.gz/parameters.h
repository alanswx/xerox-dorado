constexpr unsigned STIM_BITS=160,SCAN_WORD=0,AUX_WORD=32768;
constexpr unsigned FF_BITS=502,FF_WORDS=28;
