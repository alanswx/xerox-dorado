module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [159:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [74:0] reference_outputs,dut_outputs,
 output wire [1103:0] reference_state,dut_state,
 output wire [17:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire all_hold=global_hold || (freeze && held) ||
 reference_hold || dut_hold || reference_fault || dut_fault;
 reg original_step=0;
 always @(negedge clk)original_step<=advance && !all_hold;
 wire [18:0] board_steps;
 dorado_board_phase_enable copies(.clk(clk),.permit(advance && !all_hold),.advance(board_steps));
 // All nineteen copies must remain identical, including scan and reset edges.
 always @(posedge clk)begin
  if(board_steps!=={19{original_step}})$fatal(1,"board phase copies differ");
 end
 wire reference_ALUCarry__drv;
wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_16__drv;
wire reference_Cnt_eq_Zero_p___drv;
wire reference_DMuxData__drv;
wire reference_FA_eq_0_p___drv;
wire reference_FA_eq_1_p___drv;
wire reference_FF_0mem_p___drv;
wire reference_FF_1mem__drv;
wire reference_IOB_00__drv;
wire reference_IOB_01__drv;
wire reference_IOB_02__drv;
wire reference_IOB_03__drv;
wire reference_IOB_04__drv;
wire reference_IOB_05__drv;
wire reference_IOB_06__drv;
wire reference_IOB_07__drv;
wire reference_IOB_16__drv;
wire reference_IOPE__drv;
wire reference_IOatt__drv;
wire reference_MAR_00_p___drv;
wire reference_MAR_01_p___drv;
wire reference_MAR_02_p___drv;
wire reference_MAR_03_p___drv;
wire reference_MAR_04_p___drv;
wire reference_MAR_05_p___drv;
wire reference_MAR_06_p___drv;
wire reference_MAR_07_p___drv;
wire reference_MdPE__drv;
wire reference_MemBase_0__drv;
wire reference_MemBase_1__drv;
wire reference_MemBase_2__drv;
wire reference_MemBase_3__drv;
wire reference_MemBase_4__drv;
wire reference_NextData_p___drv;
wire reference_Overflow_p___drv;
wire reference_Pdata_15__drv;
wire reference_Q_07__drv;
wire reference_RamPE__drv;
wire reference_ResEqZero_p___drv;
wire reference_ResLtZero_p___drv;
wire reference_RmLtZero_p___drv;
wire reference_ShA_00__drv;
wire reference_ShA_01__drv;
wire reference_ShA_02__drv;
wire reference_ShA_03__drv;
wire reference_ShA_04__drv;
wire reference_ShA_05__drv;
wire reference_ShA_06__drv;
wire reference_ShA_07__drv;
wire reference_Shc_02__drv;
wire reference_Shc_03__drv;
wire reference_Shc_04b__drv;
wire reference_Shc_05b__drv;
wire reference_Shc_06b__drv;
wire reference_Shc_07b__drv;
wire reference_TIOA_0__drv;
wire reference_TIOA_1__drv;
wire reference_TIOA_2__drv;
wire reference_TIOA_3__drv;
wire reference_TIOA_4__drv;
wire reference_TIOA_5__drv;
wire reference_TIOA_6__drv;
wire reference_TIOA_7__drv;
wire reference_TestTW__drv;
wire reference_alu_07__drv;
wire reference_aluCout__drv;
wire reference_aluOut_eq_0_p___drv;
ProcH_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ALUCarry(stimulus[0] | reference_ALUCarry__drv),
.ALUF_0(stimulus[1]),
.ALUF_1(stimulus[2]),
.ALUF_2(stimulus[3]),
.ASEL_0_p_(stimulus[4]),
.ASEL_1_p_(stimulus[5]),
.ASEL_2_p_(stimulus[6]),
.BMux_00(stimulus[7] | reference_BMux_00__drv),
.BMux_01(stimulus[8] | reference_BMux_01__drv),
.BMux_02(stimulus[9] | reference_BMux_02__drv),
.BMux_03(stimulus[10] | reference_BMux_03__drv),
.BMux_04(stimulus[11] | reference_BMux_04__drv),
.BMux_05(stimulus[12] | reference_BMux_05__drv),
.BMux_06(stimulus[13] | reference_BMux_06__drv),
.BMux_07(stimulus[14] | reference_BMux_07__drv),
.BMux_16(stimulus[15] | reference_BMux_16__drv),
.BNTGtCT_p_a(stimulus[16]),
.BSEL_0_p_(stimulus[17]),
.BSEL_1_p_(stimulus[18]),
.BSEL_2_p_(stimulus[19]),
.CLK_ph_p_(stimulus[20]),
.CLKEnable_p_c(stimulus[21]),
.CkMdParity_p_(stimulus[22]),
.Cnt_eq_Zero_p_(stimulus[23] | reference_Cnt_eq_Zero_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | reference_DMuxData__drv),
.FF_0(stimulus[26]),
.FF_0mem_p_(stimulus[27] | reference_FF_0mem_p___drv),
.FF_1(stimulus[28]),
.FF_1mem(stimulus[29] | reference_FF_1mem__drv),
.FF_2(stimulus[30]),
.FF_3(stimulus[31]),
.FF_4(stimulus[32]),
.FF_5(stimulus[33]),
.FF_6(stimulus[34]),
.FF_7(stimulus[35]),
.FFok_p_a(stimulus[36]),
.Freeze(stimulus[37]),
.IOB_00(stimulus[38] | reference_IOB_00__drv),
.IOB_01(stimulus[39] | reference_IOB_01__drv),
.IOB_02(stimulus[40] | reference_IOB_02__drv),
.IOB_03(stimulus[41] | reference_IOB_03__drv),
.IOB_04(stimulus[42] | reference_IOB_04__drv),
.IOB_05(stimulus[43] | reference_IOB_05__drv),
.IOB_06(stimulus[44] | reference_IOB_06__drv),
.IOB_07(stimulus[45] | reference_IOB_07__drv),
.IOB_16(stimulus[46] | reference_IOB_16__drv),
.IOatt(stimulus[47] | reference_IOatt__drv),
.LC_0(stimulus[48]),
.LC_1(stimulus[49]),
.LC_2(stimulus[50]),
.MAR_00_p_(stimulus[51] | reference_MAR_00_p___drv),
.MAR_01_p_(stimulus[52] | reference_MAR_01_p___drv),
.MAR_02_p_(stimulus[53] | reference_MAR_02_p___drv),
.MAR_03_p_(stimulus[54] | reference_MAR_03_p___drv),
.MAR_04_p_(stimulus[55] | reference_MAR_04_p___drv),
.MAR_05_p_(stimulus[56] | reference_MAR_05_p___drv),
.MAR_06_p_(stimulus[57] | reference_MAR_06_p___drv),
.MAR_07_p_(stimulus[58] | reference_MAR_07_p___drv),
.MemBM_0(stimulus[59]),
.MemBM_1(stimulus[60]),
.MemBM34(stimulus[61]),
.MemBase_0(stimulus[62] | reference_MemBase_0__drv),
.MemBase_1(stimulus[63] | reference_MemBase_1__drv),
.Next_0(stimulus[64]),
.Next_1(stimulus[65]),
.Next_2(stimulus[66]),
.Next_3(stimulus[67]),
.NextData_p_(stimulus[68] | reference_NextData_p___drv),
.NextMacro(stimulus[69]),
.Overflow_p_(stimulus[70] | reference_Overflow_p___drv),
.PRhold(stimulus[71]),
.PropCnt_p_(stimulus[72]),
.Q_07(stimulus[73] | reference_Q_07__drv),
.Q_08(stimulus[74]),
.RSTK_0(stimulus[75]),
.RSTK_1(stimulus[76]),
.RSTK_2(stimulus[77]),
.RSTK_3(stimulus[78]),
.RbAdr_0(stimulus[79]),
.RbAdr_1(stimulus[80]),
.RbAdr_2(stimulus[81]),
.RbAdr_3(stimulus[82]),
.RbBypass(stimulus[83]),
.RbBypass_p_(stimulus[84]),
.ResEqZero_p_(stimulus[85] | reference_ResEqZero_p___drv),
.ResLtZero_p_(stimulus[86] | reference_ResLtZero_p___drv),
.RmLtZero_p_(stimulus[87] | reference_RmLtZero_p___drv),
.SelectRm_p_a(stimulus[88]),
.SelectStk_p_a(stimulus[89]),
.ShA_00(stimulus[90] | reference_ShA_00__drv),
.ShA_01(stimulus[91] | reference_ShA_01__drv),
.ShA_02(stimulus[92] | reference_ShA_02__drv),
.ShA_03(stimulus[93] | reference_ShA_03__drv),
.ShA_04(stimulus[94] | reference_ShA_04__drv),
.ShA_05(stimulus[95] | reference_ShA_05__drv),
.ShA_06(stimulus[96] | reference_ShA_06__drv),
.ShA_08(stimulus[97]),
.ShA_09(stimulus[98]),
.ShA_10(stimulus[99]),
.ShA_11(stimulus[100]),
.ShA_12(stimulus[101]),
.ShA_13(stimulus[102]),
.ShA_14(stimulus[103]),
.ShA_15(stimulus[104]),
.Shc_02(stimulus[105] | reference_Shc_02__drv),
.Shc_03(stimulus[106] | reference_Shc_03__drv),
.Shc_08(stimulus[107]),
.Shc_09(stimulus[108]),
.Shc_10(stimulus[109]),
.Shc_11(stimulus[110]),
.Shc_12(stimulus[111]),
.Shc_13(stimulus[112]),
.Shc_14(stimulus[113]),
.Shc_15(stimulus[114]),
.ShcAlu_0(stimulus[115]),
.ShcAlu_1(stimulus[116]),
.ShcAlu_2(stimulus[117]),
.ShcAlu_3(stimulus[118]),
.SignIfuData(stimulus[119]),
.StartCycle_p_a(stimulus[120]),
.StkAdr_0a(stimulus[121]),
.StkAdr_1a(stimulus[122]),
.StkAdr_2a(stimulus[123]),
.StkAdr_3a(stimulus[124]),
.StkAdr_4a(stimulus[125]),
.StkAdr_5a(stimulus[126]),
.StkAdr_6a(stimulus[127]),
.StkAdr_7a(stimulus[128]),
.TIOA_0(stimulus[129] | reference_TIOA_0__drv),
.TIOA_1(stimulus[130] | reference_TIOA_1__drv),
.TIOA_2(stimulus[131] | reference_TIOA_2__drv),
.TIOA_3(stimulus[132] | reference_TIOA_3__drv),
.TIOA_4(stimulus[133] | reference_TIOA_4__drv),
.TIOA_5(stimulus[134] | reference_TIOA_5__drv),
.TIOA_6(stimulus[135] | reference_TIOA_6__drv),
.TIOA_7(stimulus[136] | reference_TIOA_7__drv),
.TempRef(stimulus[137]),
.alu_07(stimulus[138] | reference_alu_07__drv),
.alu_08(stimulus[139]),
.alu_15(stimulus[140]),
.aluC0(stimulus[141]),
.aluCout(stimulus[142] | reference_aluCout__drv),
.aluF0(stimulus[143]),
.aluF1(stimulus[144]),
.aluF2(stimulus[145]),
.aluF3(stimulus[146]),
.aluG1(stimulus[147]),
.aluM(stimulus[148]),
.aluOut_eq_0_p_(stimulus[149] | reference_aluOut_eq_0_p___drv),
.aluP1(stimulus[150]),
.dMD_00(stimulus[151]),
.dMD_01(stimulus[152]),
.dMD_02(stimulus[153]),
.dMD_03(stimulus[154]),
.dMD_04(stimulus[155]),
.dMD_05(stimulus[156]),
.dMD_06(stimulus[157]),
.dMD_07(stimulus[158]),
.dMD_16(stimulus[159]),
.ALUCarry__drv(reference_ALUCarry__drv),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_16__drv(reference_BMux_16__drv),
.Cnt_eq_Zero_p___drv(reference_Cnt_eq_Zero_p___drv),
.DMuxData__drv(reference_DMuxData__drv),
.FA_eq_0_p___drv(reference_FA_eq_0_p___drv),
.FA_eq_1_p___drv(reference_FA_eq_1_p___drv),
.FF_0mem_p___drv(reference_FF_0mem_p___drv),
.FF_1mem__drv(reference_FF_1mem__drv),
.IOB_00__drv(reference_IOB_00__drv),
.IOB_01__drv(reference_IOB_01__drv),
.IOB_02__drv(reference_IOB_02__drv),
.IOB_03__drv(reference_IOB_03__drv),
.IOB_04__drv(reference_IOB_04__drv),
.IOB_05__drv(reference_IOB_05__drv),
.IOB_06__drv(reference_IOB_06__drv),
.IOB_07__drv(reference_IOB_07__drv),
.IOB_16__drv(reference_IOB_16__drv),
.IOPE__drv(reference_IOPE__drv),
.IOatt__drv(reference_IOatt__drv),
.MAR_00_p___drv(reference_MAR_00_p___drv),
.MAR_01_p___drv(reference_MAR_01_p___drv),
.MAR_02_p___drv(reference_MAR_02_p___drv),
.MAR_03_p___drv(reference_MAR_03_p___drv),
.MAR_04_p___drv(reference_MAR_04_p___drv),
.MAR_05_p___drv(reference_MAR_05_p___drv),
.MAR_06_p___drv(reference_MAR_06_p___drv),
.MAR_07_p___drv(reference_MAR_07_p___drv),
.MdPE__drv(reference_MdPE__drv),
.MemBase_0__drv(reference_MemBase_0__drv),
.MemBase_1__drv(reference_MemBase_1__drv),
.MemBase_2__drv(reference_MemBase_2__drv),
.MemBase_3__drv(reference_MemBase_3__drv),
.MemBase_4__drv(reference_MemBase_4__drv),
.NextData_p___drv(reference_NextData_p___drv),
.Overflow_p___drv(reference_Overflow_p___drv),
.Pdata_15__drv(reference_Pdata_15__drv),
.Q_07__drv(reference_Q_07__drv),
.RamPE__drv(reference_RamPE__drv),
.ResEqZero_p___drv(reference_ResEqZero_p___drv),
.ResLtZero_p___drv(reference_ResLtZero_p___drv),
.RmLtZero_p___drv(reference_RmLtZero_p___drv),
.ShA_00__drv(reference_ShA_00__drv),
.ShA_01__drv(reference_ShA_01__drv),
.ShA_02__drv(reference_ShA_02__drv),
.ShA_03__drv(reference_ShA_03__drv),
.ShA_04__drv(reference_ShA_04__drv),
.ShA_05__drv(reference_ShA_05__drv),
.ShA_06__drv(reference_ShA_06__drv),
.ShA_07__drv(reference_ShA_07__drv),
.Shc_02__drv(reference_Shc_02__drv),
.Shc_03__drv(reference_Shc_03__drv),
.Shc_04b__drv(reference_Shc_04b__drv),
.Shc_05b__drv(reference_Shc_05b__drv),
.Shc_06b__drv(reference_Shc_06b__drv),
.Shc_07b__drv(reference_Shc_07b__drv),
.TIOA_0__drv(reference_TIOA_0__drv),
.TIOA_1__drv(reference_TIOA_1__drv),
.TIOA_2__drv(reference_TIOA_2__drv),
.TIOA_3__drv(reference_TIOA_3__drv),
.TIOA_4__drv(reference_TIOA_4__drv),
.TIOA_5__drv(reference_TIOA_5__drv),
.TIOA_6__drv(reference_TIOA_6__drv),
.TIOA_7__drv(reference_TIOA_7__drv),
.TestTW__drv(reference_TestTW__drv),
.alu_07__drv(reference_alu_07__drv),
.aluCout__drv(reference_aluCout__drv),
.aluOut_eq_0_p___drv(reference_aluOut_eq_0_p___drv),
.state_host_clk(clk),
.state_guest_advance(original_step),
.state_freeze(freeze || all_hold),
.state_guest_held(held || all_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_aluOut_eq_0_p___drv,reference_aluCout__drv,reference_alu_07__drv,reference_TestTW__drv,reference_TIOA_7__drv,reference_TIOA_6__drv,reference_TIOA_5__drv,reference_TIOA_4__drv,reference_TIOA_3__drv,reference_TIOA_2__drv,reference_TIOA_1__drv,reference_TIOA_0__drv,reference_Shc_07b__drv,reference_Shc_06b__drv,reference_Shc_05b__drv,reference_Shc_04b__drv,reference_Shc_03__drv,reference_Shc_02__drv,reference_ShA_07__drv,reference_ShA_06__drv,reference_ShA_05__drv,reference_ShA_04__drv,reference_ShA_03__drv,reference_ShA_02__drv,reference_ShA_01__drv,reference_ShA_00__drv,reference_RmLtZero_p___drv,reference_ResLtZero_p___drv,reference_ResEqZero_p___drv,reference_RamPE__drv,reference_Q_07__drv,reference_Pdata_15__drv,reference_Overflow_p___drv,reference_NextData_p___drv,reference_MemBase_4__drv,reference_MemBase_3__drv,reference_MemBase_2__drv,reference_MemBase_1__drv,reference_MemBase_0__drv,reference_MdPE__drv,reference_MAR_07_p___drv,reference_MAR_06_p___drv,reference_MAR_05_p___drv,reference_MAR_04_p___drv,reference_MAR_03_p___drv,reference_MAR_02_p___drv,reference_MAR_01_p___drv,reference_MAR_00_p___drv,reference_IOatt__drv,reference_IOPE__drv,reference_IOB_16__drv,reference_IOB_07__drv,reference_IOB_06__drv,reference_IOB_05__drv,reference_IOB_04__drv,reference_IOB_03__drv,reference_IOB_02__drv,reference_IOB_01__drv,reference_IOB_00__drv,reference_FF_1mem__drv,reference_FF_0mem_p___drv,reference_FA_eq_1_p___drv,reference_FA_eq_0_p___drv,reference_DMuxData__drv,reference_Cnt_eq_Zero_p___drv,reference_BMux_16__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv,reference_ALUCarry__drv};
assign reference_state[0+:1]=reference.Clock1Bd;
assign reference_state[1+:1]=reference.Clock1_p_Ac;
assign reference_state[2+:1]=reference.Clock1_p_Ba;
assign reference_state[3+:1]=reference.Clock1_p_Bb;
assign reference_state[4+:1]=reference.Clock1_p_Ca;
assign reference_state[5+:1]=reference.Clock1_p_Cb;
assign reference_state[6+:1]=reference.Clock1_p_Cd;
assign reference_state[7+:1]=reference.Clock1_p_Da;
assign reference_state[8+:1]=reference.Clock1_p_Dc;
assign reference_state[9+:1]=reference.PostClock0_p_Bc;
assign reference_state[10+:1]=reference.u_a03.ck_d;
assign reference_state[11+:4]=reference.u_a03.q;
assign reference_state[15+:6]=reference.u_a03.setup_pre;
assign reference_state[21+:1]=reference.u_a04.ck_d;
assign reference_state[22+:4]=reference.u_a04.q;
assign reference_state[26+:6]=reference.u_a04.setup_pre;
assign reference_state[32+:1]=reference.u_a10.cka_d;
assign reference_state[33+:1]=reference.u_a10.ckb_d;
assign reference_state[34+:1]=reference.u_a10.d_pre_a;
assign reference_state[35+:1]=reference.u_a10.d_pre_b;
assign reference_state[36+:1]=reference.u_a10.qa;
assign reference_state[37+:1]=reference.u_a10.qb;
assign reference_state[38+:1]=reference.u_a11.cka_d;
assign reference_state[39+:1]=reference.u_a11.ckb_d;
assign reference_state[40+:1]=reference.u_a11.d_pre_a;
assign reference_state[41+:1]=reference.u_a11.d_pre_b;
assign reference_state[42+:1]=reference.u_a11.qa;
assign reference_state[43+:1]=reference.u_a11.qb;
assign reference_state[44+:4]=reference.u_a12.q;
assign reference_state[48+:4]=reference.u_a13.q;
assign reference_state[52+:1]=reference.u_a20.ck_d;
assign reference_state[53+:4]=reference.u_a20.d_pre;
assign reference_state[57+:1]=reference.u_a20.dl_pre;
assign reference_state[58+:1]=reference.u_a20.dr_pre;
assign reference_state[59+:4]=reference.u_a20.q;
assign reference_state[63+:2]=reference.u_a20.s_pre;
assign reference_state[65+:1]=reference.u_a21.ck_d;
assign reference_state[66+:4]=reference.u_a21.d_pre;
assign reference_state[70+:1]=reference.u_a21.dl_pre;
assign reference_state[71+:1]=reference.u_a21.dr_pre;
assign reference_state[72+:4]=reference.u_a21.q;
assign reference_state[76+:2]=reference.u_a21.s_pre;
assign reference_state[78+:4]=reference.u_b05.q;
assign reference_state[82+:1]=reference.u_b10.cka_d;
assign reference_state[83+:1]=reference.u_b10.ckb_d;
assign reference_state[84+:1]=reference.u_b10.d_pre_a;
assign reference_state[85+:1]=reference.u_b10.d_pre_b;
assign reference_state[86+:1]=reference.u_b10.qa;
assign reference_state[87+:1]=reference.u_b10.qb;
assign reference_state[88+:1]=reference.u_b11.ck_d;
assign reference_state[89+:4]=reference.u_b11.d_pre;
assign reference_state[93+:1]=reference.u_b11.dl_pre;
assign reference_state[94+:1]=reference.u_b11.dr_pre;
assign reference_state[95+:4]=reference.u_b11.q;
assign reference_state[99+:2]=reference.u_b11.s_pre;
assign reference_state[101+:4]=reference.u_b12.q;
assign reference_state[105+:4]=reference.u_b13.q;
assign reference_state[109+:1]=reference.u_b15.ck_d;
assign reference_state[110+:6]=reference.u_b15.d_pre;
assign reference_state[116+:6]=reference.u_b15.q;
assign reference_state[122+:4]=reference.u_c05.q;
assign reference_state[126+:1]=reference.u_c10.ck_d;
assign reference_state[127+:6]=reference.u_c10.d_pre;
assign reference_state[133+:6]=reference.u_c10.q;
assign reference_state[139+:1]=reference.u_c11.ck_d;
assign reference_state[140+:4]=reference.u_c11.d_pre;
assign reference_state[144+:1]=reference.u_c11.dl_pre;
assign reference_state[145+:1]=reference.u_c11.dr_pre;
assign reference_state[146+:4]=reference.u_c11.q;
assign reference_state[150+:2]=reference.u_c11.s_pre;
assign reference_state[152+:1]=reference.u_c12.ck_d;
assign reference_state[153+:4]=reference.u_c12.d_pre;
assign reference_state[157+:1]=reference.u_c12.dl_pre;
assign reference_state[158+:1]=reference.u_c12.dr_pre;
assign reference_state[159+:4]=reference.u_c12.q;
assign reference_state[163+:2]=reference.u_c12.s_pre;
assign reference_state[165+:4]=reference.u_c13.q;
assign reference_state[169+:4]=reference.u_d05.q;
assign reference_state[173+:1]=reference.u_d16.ck_d;
assign reference_state[174+:4]=reference.u_d16.q;
assign reference_state[178+:6]=reference.u_d16.setup_pre;
assign reference_state[184+:4]=reference.u_e05.q;
assign reference_state[188+:4]=reference.u_e06.q;
assign reference_state[192+:4]=reference.u_e13.a_lat;
assign reference_state[196+:1]=reference.u_e13.ce_lat;
assign reference_state[197+:4]=reference.u_e13.d_lat;
assign reference_state[201+:64]={reference.u_e13.mem[15],reference.u_e13.mem[14],reference.u_e13.mem[13],reference.u_e13.mem[12],reference.u_e13.mem[11],reference.u_e13.mem[10],reference.u_e13.mem[9],reference.u_e13.mem[8],reference.u_e13.mem[7],reference.u_e13.mem[6],reference.u_e13.mem[5],reference.u_e13.mem[4],reference.u_e13.mem[3],reference.u_e13.mem[2],reference.u_e13.mem[1],reference.u_e13.mem[0]};
assign reference_state[265+:1]=reference.u_e13.we_d;
assign reference_state[266+:1]=reference.u_e16.ck_d;
assign reference_state[267+:4]=reference.u_e16.q;
assign reference_state[271+:6]=reference.u_e16.setup_pre;
assign reference_state[277+:4]=reference.u_f06.q;
assign reference_state[281+:1]=reference.u_f16.ck_d;
assign reference_state[282+:4]=reference.u_f16.d_pre;
assign reference_state[286+:4]=reference.u_f16.q;
assign reference_state[290+:4]=reference.u_f17.q;
assign reference_state[294+:1]=reference.u_f21.ck_d;
assign reference_state[295+:6]=reference.u_f21.d_pre;
assign reference_state[301+:6]=reference.u_f21.q;
assign reference_state[307+:4]=reference.u_g05.q;
assign reference_state[311+:4]=reference.u_g06.q;
assign reference_state[315+:4]=reference.u_g07.q;
assign reference_state[319+:1]=reference.u_g10.ck_d;
assign reference_state[320+:4]=reference.u_g10.d_pre;
assign reference_state[324+:4]=reference.u_g10.q;
assign reference_state[328+:1]=reference.u_g11.ck_d;
assign reference_state[329+:6]=reference.u_g11.d_pre;
assign reference_state[335+:6]=reference.u_g11.q;
assign reference_state[341+:4]=reference.u_g15.a_lat;
assign reference_state[345+:1]=reference.u_g15.ce_lat;
assign reference_state[346+:4]=reference.u_g15.d_lat;
assign reference_state[350+:64]={reference.u_g15.mem[15],reference.u_g15.mem[14],reference.u_g15.mem[13],reference.u_g15.mem[12],reference.u_g15.mem[11],reference.u_g15.mem[10],reference.u_g15.mem[9],reference.u_g15.mem[8],reference.u_g15.mem[7],reference.u_g15.mem[6],reference.u_g15.mem[5],reference.u_g15.mem[4],reference.u_g15.mem[3],reference.u_g15.mem[2],reference.u_g15.mem[1],reference.u_g15.mem[0]};
assign reference_state[414+:1]=reference.u_g15.we_d;
assign reference_state[415+:1]=reference.u_g16.ck_d;
assign reference_state[416+:4]=reference.u_g16.d_pre;
assign reference_state[420+:4]=reference.u_g16.q;
assign reference_state[424+:1]=reference.u_g18.ck_d;
assign reference_state[425+:6]=reference.u_g18.d_pre;
assign reference_state[431+:6]=reference.u_g18.q;
assign reference_state[437+:1]=reference.u_g22.cka_d;
assign reference_state[438+:1]=reference.u_g22.ckb_d;
assign reference_state[439+:1]=reference.u_g22.d_pre_a;
assign reference_state[440+:1]=reference.u_g22.d_pre_b;
assign reference_state[441+:1]=reference.u_g22.qa;
assign reference_state[442+:1]=reference.u_g22.qb;
assign reference_state[443+:1]=reference.u_g23.cka_d;
assign reference_state[444+:1]=reference.u_g23.ckb_d;
assign reference_state[445+:1]=reference.u_g23.d_pre_a;
assign reference_state[446+:1]=reference.u_g23.d_pre_b;
assign reference_state[447+:1]=reference.u_g23.qa;
assign reference_state[448+:1]=reference.u_g23.qb;
assign reference_state[449+:1]=reference.u_g24.cka_d;
assign reference_state[450+:1]=reference.u_g24.ckb_d;
assign reference_state[451+:1]=reference.u_g24.d_pre_a;
assign reference_state[452+:1]=reference.u_g24.d_pre_b;
assign reference_state[453+:1]=reference.u_g24.qa;
assign reference_state[454+:1]=reference.u_g24.qb;
assign reference_state[455+:4]=reference.u_h05.q;
assign reference_state[459+:1]=reference.u_h10.ck_d;
assign reference_state[460+:4]=reference.u_h10.d_pre;
assign reference_state[464+:4]=reference.u_h10.q;
assign reference_state[468+:1]=reference.u_h11.ck_d;
assign reference_state[469+:6]=reference.u_h11.d_pre;
assign reference_state[475+:6]=reference.u_h11.q;
assign reference_state[481+:4]=reference.u_h15.a_lat;
assign reference_state[485+:1]=reference.u_h15.ce_lat;
assign reference_state[486+:4]=reference.u_h15.d_lat;
assign reference_state[490+:64]={reference.u_h15.mem[15],reference.u_h15.mem[14],reference.u_h15.mem[13],reference.u_h15.mem[12],reference.u_h15.mem[11],reference.u_h15.mem[10],reference.u_h15.mem[9],reference.u_h15.mem[8],reference.u_h15.mem[7],reference.u_h15.mem[6],reference.u_h15.mem[5],reference.u_h15.mem[4],reference.u_h15.mem[3],reference.u_h15.mem[2],reference.u_h15.mem[1],reference.u_h15.mem[0]};
assign reference_state[554+:1]=reference.u_h15.we_d;
assign reference_state[555+:1]=reference.u_h18.ck_d;
assign reference_state[556+:6]=reference.u_h18.d_pre;
assign reference_state[562+:6]=reference.u_h18.q;
assign reference_state[568+:1]=reference.u_h22.ck_d;
assign reference_state[569+:6]=reference.u_h22.d_pre;
assign reference_state[575+:6]=reference.u_h22.q;
assign reference_state[581+:5]=reference.u_i01.q;
assign reference_state[586+:5]=reference.u_i02.q;
assign reference_state[591+:4]=reference.u_i03.q;
assign reference_state[595+:4]=reference.u_i04.q;
assign reference_state[599+:4]=reference.u_i11.a_lat;
assign reference_state[603+:1]=reference.u_i11.ce_lat;
assign reference_state[604+:4]=reference.u_i11.d_lat;
assign reference_state[608+:64]={reference.u_i11.mem[15],reference.u_i11.mem[14],reference.u_i11.mem[13],reference.u_i11.mem[12],reference.u_i11.mem[11],reference.u_i11.mem[10],reference.u_i11.mem[9],reference.u_i11.mem[8],reference.u_i11.mem[7],reference.u_i11.mem[6],reference.u_i11.mem[5],reference.u_i11.mem[4],reference.u_i11.mem[3],reference.u_i11.mem[2],reference.u_i11.mem[1],reference.u_i11.mem[0]};
assign reference_state[672+:1]=reference.u_i11.we_d;
assign reference_state[673+:1]=reference.u_i12.ck_d;
assign reference_state[674+:4]=reference.u_i12.d_pre;
assign reference_state[678+:1]=reference.u_i12.dl_pre;
assign reference_state[679+:1]=reference.u_i12.dr_pre;
assign reference_state[680+:4]=reference.u_i12.q;
assign reference_state[684+:2]=reference.u_i12.s_pre;
assign reference_state[686+:1]=reference.u_i19.ck_d;
assign reference_state[687+:6]=reference.u_i19.d_pre;
assign reference_state[693+:6]=reference.u_i19.q;
assign reference_state[699+:4]=reference.u_j01.q;
assign reference_state[703+:4]=reference.u_j02.q;
assign reference_state[707+:4]=reference.u_j03.q;
assign reference_state[711+:4]=reference.u_j04.q;
assign reference_state[715+:1]=reference.u_j11.ck_d;
assign reference_state[716+:6]=reference.u_j11.d_pre;
assign reference_state[722+:6]=reference.u_j11.q;
assign reference_state[728+:4]=reference.u_j16.a_lat;
assign reference_state[732+:1]=reference.u_j16.ce_lat;
assign reference_state[733+:4]=reference.u_j16.d_lat;
assign reference_state[737+:64]={reference.u_j16.mem[15],reference.u_j16.mem[14],reference.u_j16.mem[13],reference.u_j16.mem[12],reference.u_j16.mem[11],reference.u_j16.mem[10],reference.u_j16.mem[9],reference.u_j16.mem[8],reference.u_j16.mem[7],reference.u_j16.mem[6],reference.u_j16.mem[5],reference.u_j16.mem[4],reference.u_j16.mem[3],reference.u_j16.mem[2],reference.u_j16.mem[1],reference.u_j16.mem[0]};
assign reference_state[801+:1]=reference.u_j16.we_d;
assign reference_state[802+:4]=reference.u_j17.a_lat;
assign reference_state[806+:1]=reference.u_j17.ce_lat;
assign reference_state[807+:4]=reference.u_j17.d_lat;
assign reference_state[811+:64]={reference.u_j17.mem[15],reference.u_j17.mem[14],reference.u_j17.mem[13],reference.u_j17.mem[12],reference.u_j17.mem[11],reference.u_j17.mem[10],reference.u_j17.mem[9],reference.u_j17.mem[8],reference.u_j17.mem[7],reference.u_j17.mem[6],reference.u_j17.mem[5],reference.u_j17.mem[4],reference.u_j17.mem[3],reference.u_j17.mem[2],reference.u_j17.mem[1],reference.u_j17.mem[0]};
assign reference_state[875+:1]=reference.u_j17.we_d;
assign reference_state[876+:1]=reference.u_j20.cka_d;
assign reference_state[877+:1]=reference.u_j20.ckb_d;
assign reference_state[878+:1]=reference.u_j20.d_pre_a;
assign reference_state[879+:1]=reference.u_j20.d_pre_b;
assign reference_state[880+:1]=reference.u_j20.qa;
assign reference_state[881+:1]=reference.u_j20.qb;
assign reference_state[882+:4]=reference.u_k01.q;
assign reference_state[886+:4]=reference.u_k02.q;
assign reference_state[890+:1]=reference.u_k21.ck_d;
assign reference_state[891+:6]=reference.u_k21.d_pre;
assign reference_state[897+:6]=reference.u_k21.q;
assign reference_state[903+:1]=reference.u_k22.ck_d;
assign reference_state[904+:6]=reference.u_k22.d_pre;
assign reference_state[910+:6]=reference.u_k22.q;
assign reference_state[916+:1]=reference.u_l02.cka_d;
assign reference_state[917+:1]=reference.u_l02.ckb_d;
assign reference_state[918+:1]=reference.u_l02.d_pre_a;
assign reference_state[919+:1]=reference.u_l02.d_pre_b;
assign reference_state[920+:1]=reference.u_l02.qa;
assign reference_state[921+:1]=reference.u_l02.qb;
assign reference_state[922+:4]=reference.u_l03.a_lat;
assign reference_state[926+:1]=reference.u_l03.ce_lat;
assign reference_state[927+:4]=reference.u_l03.d_lat;
assign reference_state[931+:64]={reference.u_l03.mem[15],reference.u_l03.mem[14],reference.u_l03.mem[13],reference.u_l03.mem[12],reference.u_l03.mem[11],reference.u_l03.mem[10],reference.u_l03.mem[9],reference.u_l03.mem[8],reference.u_l03.mem[7],reference.u_l03.mem[6],reference.u_l03.mem[5],reference.u_l03.mem[4],reference.u_l03.mem[3],reference.u_l03.mem[2],reference.u_l03.mem[1],reference.u_l03.mem[0]};
assign reference_state[995+:1]=reference.u_l03.we_d;
assign reference_state[996+:4]=reference.u_l04.a_lat;
assign reference_state[1000+:1]=reference.u_l04.ce_lat;
assign reference_state[1001+:4]=reference.u_l04.d_lat;
assign reference_state[1005+:64]={reference.u_l04.mem[15],reference.u_l04.mem[14],reference.u_l04.mem[13],reference.u_l04.mem[12],reference.u_l04.mem[11],reference.u_l04.mem[10],reference.u_l04.mem[9],reference.u_l04.mem[8],reference.u_l04.mem[7],reference.u_l04.mem[6],reference.u_l04.mem[5],reference.u_l04.mem[4],reference.u_l04.mem[3],reference.u_l04.mem[2],reference.u_l04.mem[1],reference.u_l04.mem[0]};
assign reference_state[1069+:1]=reference.u_l04.we_d;
assign reference_state[1070+:1]=reference.u_l05.ck_d;
assign reference_state[1071+:6]=reference.u_l05.d_pre;
assign reference_state[1077+:6]=reference.u_l05.q;
assign reference_state[1083+:1]=reference.u_l06.cka_d;
assign reference_state[1084+:1]=reference.u_l06.ckb_d;
assign reference_state[1085+:1]=reference.u_l06.qa;
assign reference_state[1086+:1]=reference.u_l06.qb;
assign reference_state[1087+:1]=reference.u_l07.cka_d;
assign reference_state[1088+:1]=reference.u_l07.ckb_d;
assign reference_state[1089+:1]=reference.u_l07.qa;
assign reference_state[1090+:1]=reference.u_l07.qb;
assign reference_state[1091+:1]=reference.u_l22.ck_d;
assign reference_state[1092+:6]=reference.u_l22.d_pre;
assign reference_state[1098+:6]=reference.u_l22.q;
assign reference_probe[0+:4]=reference.u_h06.mem[0+(probe_index%256)];
assign reference_probe[4+:4]=reference.u_i06.mem[0+(probe_index%256)];
assign reference_probe[8+:1]=reference.u_i08.mem[0+(probe_index%256)];
assign reference_probe[9+:4]=reference.u_j06.mem[0+(probe_index%256)];
assign reference_probe[13+:1]=reference.u_j08.mem[0+(probe_index%256)];
assign reference_probe[14+:4]=reference.u_k06.mem[0+(probe_index%256)];
wire dut_ALUCarry__drv;
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_16__drv;
wire dut_Cnt_eq_Zero_p___drv;
wire dut_DMuxData__drv;
wire dut_FA_eq_0_p___drv;
wire dut_FA_eq_1_p___drv;
wire dut_FF_0mem_p___drv;
wire dut_FF_1mem__drv;
wire dut_IOB_00__drv;
wire dut_IOB_01__drv;
wire dut_IOB_02__drv;
wire dut_IOB_03__drv;
wire dut_IOB_04__drv;
wire dut_IOB_05__drv;
wire dut_IOB_06__drv;
wire dut_IOB_07__drv;
wire dut_IOB_16__drv;
wire dut_IOPE__drv;
wire dut_IOatt__drv;
wire dut_MAR_00_p___drv;
wire dut_MAR_01_p___drv;
wire dut_MAR_02_p___drv;
wire dut_MAR_03_p___drv;
wire dut_MAR_04_p___drv;
wire dut_MAR_05_p___drv;
wire dut_MAR_06_p___drv;
wire dut_MAR_07_p___drv;
wire dut_MdPE__drv;
wire dut_MemBase_0__drv;
wire dut_MemBase_1__drv;
wire dut_MemBase_2__drv;
wire dut_MemBase_3__drv;
wire dut_MemBase_4__drv;
wire dut_NextData_p___drv;
wire dut_Overflow_p___drv;
wire dut_Pdata_15__drv;
wire dut_Q_07__drv;
wire dut_RamPE__drv;
wire dut_ResEqZero_p___drv;
wire dut_ResLtZero_p___drv;
wire dut_RmLtZero_p___drv;
wire dut_ShA_00__drv;
wire dut_ShA_01__drv;
wire dut_ShA_02__drv;
wire dut_ShA_03__drv;
wire dut_ShA_04__drv;
wire dut_ShA_05__drv;
wire dut_ShA_06__drv;
wire dut_ShA_07__drv;
wire dut_Shc_02__drv;
wire dut_Shc_03__drv;
wire dut_Shc_04b__drv;
wire dut_Shc_05b__drv;
wire dut_Shc_06b__drv;
wire dut_Shc_07b__drv;
wire dut_TIOA_0__drv;
wire dut_TIOA_1__drv;
wire dut_TIOA_2__drv;
wire dut_TIOA_3__drv;
wire dut_TIOA_4__drv;
wire dut_TIOA_5__drv;
wire dut_TIOA_6__drv;
wire dut_TIOA_7__drv;
wire dut_TestTW__drv;
wire dut_alu_07__drv;
wire dut_aluCout__drv;
wire dut_aluOut_eq_0_p___drv;
dorado_serial_ProcH #(.SYSPER(4)) dut(
.sys_clk(clk),
.ALUCarry(stimulus[0] | dut_ALUCarry__drv),
.ALUF_0(stimulus[1]),
.ALUF_1(stimulus[2]),
.ALUF_2(stimulus[3]),
.ASEL_0_p_(stimulus[4]),
.ASEL_1_p_(stimulus[5]),
.ASEL_2_p_(stimulus[6]),
.BMux_00(stimulus[7] | dut_BMux_00__drv),
.BMux_01(stimulus[8] | dut_BMux_01__drv),
.BMux_02(stimulus[9] | dut_BMux_02__drv),
.BMux_03(stimulus[10] | dut_BMux_03__drv),
.BMux_04(stimulus[11] | dut_BMux_04__drv),
.BMux_05(stimulus[12] | dut_BMux_05__drv),
.BMux_06(stimulus[13] | dut_BMux_06__drv),
.BMux_07(stimulus[14] | dut_BMux_07__drv),
.BMux_16(stimulus[15] | dut_BMux_16__drv),
.BNTGtCT_p_a(stimulus[16]),
.BSEL_0_p_(stimulus[17]),
.BSEL_1_p_(stimulus[18]),
.BSEL_2_p_(stimulus[19]),
.CLK_ph_p_(stimulus[20]),
.CLKEnable_p_c(stimulus[21]),
.CkMdParity_p_(stimulus[22]),
.Cnt_eq_Zero_p_(stimulus[23] | dut_Cnt_eq_Zero_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | dut_DMuxData__drv),
.FF_0(stimulus[26]),
.FF_0mem_p_(stimulus[27] | dut_FF_0mem_p___drv),
.FF_1(stimulus[28]),
.FF_1mem(stimulus[29] | dut_FF_1mem__drv),
.FF_2(stimulus[30]),
.FF_3(stimulus[31]),
.FF_4(stimulus[32]),
.FF_5(stimulus[33]),
.FF_6(stimulus[34]),
.FF_7(stimulus[35]),
.FFok_p_a(stimulus[36]),
.Freeze(stimulus[37]),
.IOB_00(stimulus[38] | dut_IOB_00__drv),
.IOB_01(stimulus[39] | dut_IOB_01__drv),
.IOB_02(stimulus[40] | dut_IOB_02__drv),
.IOB_03(stimulus[41] | dut_IOB_03__drv),
.IOB_04(stimulus[42] | dut_IOB_04__drv),
.IOB_05(stimulus[43] | dut_IOB_05__drv),
.IOB_06(stimulus[44] | dut_IOB_06__drv),
.IOB_07(stimulus[45] | dut_IOB_07__drv),
.IOB_16(stimulus[46] | dut_IOB_16__drv),
.IOatt(stimulus[47] | dut_IOatt__drv),
.LC_0(stimulus[48]),
.LC_1(stimulus[49]),
.LC_2(stimulus[50]),
.MAR_00_p_(stimulus[51] | dut_MAR_00_p___drv),
.MAR_01_p_(stimulus[52] | dut_MAR_01_p___drv),
.MAR_02_p_(stimulus[53] | dut_MAR_02_p___drv),
.MAR_03_p_(stimulus[54] | dut_MAR_03_p___drv),
.MAR_04_p_(stimulus[55] | dut_MAR_04_p___drv),
.MAR_05_p_(stimulus[56] | dut_MAR_05_p___drv),
.MAR_06_p_(stimulus[57] | dut_MAR_06_p___drv),
.MAR_07_p_(stimulus[58] | dut_MAR_07_p___drv),
.MemBM_0(stimulus[59]),
.MemBM_1(stimulus[60]),
.MemBM34(stimulus[61]),
.MemBase_0(stimulus[62] | dut_MemBase_0__drv),
.MemBase_1(stimulus[63] | dut_MemBase_1__drv),
.Next_0(stimulus[64]),
.Next_1(stimulus[65]),
.Next_2(stimulus[66]),
.Next_3(stimulus[67]),
.NextData_p_(stimulus[68] | dut_NextData_p___drv),
.NextMacro(stimulus[69]),
.Overflow_p_(stimulus[70] | dut_Overflow_p___drv),
.PRhold(stimulus[71]),
.PropCnt_p_(stimulus[72]),
.Q_07(stimulus[73] | dut_Q_07__drv),
.Q_08(stimulus[74]),
.RSTK_0(stimulus[75]),
.RSTK_1(stimulus[76]),
.RSTK_2(stimulus[77]),
.RSTK_3(stimulus[78]),
.RbAdr_0(stimulus[79]),
.RbAdr_1(stimulus[80]),
.RbAdr_2(stimulus[81]),
.RbAdr_3(stimulus[82]),
.RbBypass(stimulus[83]),
.RbBypass_p_(stimulus[84]),
.ResEqZero_p_(stimulus[85] | dut_ResEqZero_p___drv),
.ResLtZero_p_(stimulus[86] | dut_ResLtZero_p___drv),
.RmLtZero_p_(stimulus[87] | dut_RmLtZero_p___drv),
.SelectRm_p_a(stimulus[88]),
.SelectStk_p_a(stimulus[89]),
.ShA_00(stimulus[90] | dut_ShA_00__drv),
.ShA_01(stimulus[91] | dut_ShA_01__drv),
.ShA_02(stimulus[92] | dut_ShA_02__drv),
.ShA_03(stimulus[93] | dut_ShA_03__drv),
.ShA_04(stimulus[94] | dut_ShA_04__drv),
.ShA_05(stimulus[95] | dut_ShA_05__drv),
.ShA_06(stimulus[96] | dut_ShA_06__drv),
.ShA_08(stimulus[97]),
.ShA_09(stimulus[98]),
.ShA_10(stimulus[99]),
.ShA_11(stimulus[100]),
.ShA_12(stimulus[101]),
.ShA_13(stimulus[102]),
.ShA_14(stimulus[103]),
.ShA_15(stimulus[104]),
.Shc_02(stimulus[105] | dut_Shc_02__drv),
.Shc_03(stimulus[106] | dut_Shc_03__drv),
.Shc_08(stimulus[107]),
.Shc_09(stimulus[108]),
.Shc_10(stimulus[109]),
.Shc_11(stimulus[110]),
.Shc_12(stimulus[111]),
.Shc_13(stimulus[112]),
.Shc_14(stimulus[113]),
.Shc_15(stimulus[114]),
.ShcAlu_0(stimulus[115]),
.ShcAlu_1(stimulus[116]),
.ShcAlu_2(stimulus[117]),
.ShcAlu_3(stimulus[118]),
.SignIfuData(stimulus[119]),
.StartCycle_p_a(stimulus[120]),
.StkAdr_0a(stimulus[121]),
.StkAdr_1a(stimulus[122]),
.StkAdr_2a(stimulus[123]),
.StkAdr_3a(stimulus[124]),
.StkAdr_4a(stimulus[125]),
.StkAdr_5a(stimulus[126]),
.StkAdr_6a(stimulus[127]),
.StkAdr_7a(stimulus[128]),
.TIOA_0(stimulus[129] | dut_TIOA_0__drv),
.TIOA_1(stimulus[130] | dut_TIOA_1__drv),
.TIOA_2(stimulus[131] | dut_TIOA_2__drv),
.TIOA_3(stimulus[132] | dut_TIOA_3__drv),
.TIOA_4(stimulus[133] | dut_TIOA_4__drv),
.TIOA_5(stimulus[134] | dut_TIOA_5__drv),
.TIOA_6(stimulus[135] | dut_TIOA_6__drv),
.TIOA_7(stimulus[136] | dut_TIOA_7__drv),
.TempRef(stimulus[137]),
.alu_07(stimulus[138] | dut_alu_07__drv),
.alu_08(stimulus[139]),
.alu_15(stimulus[140]),
.aluC0(stimulus[141]),
.aluCout(stimulus[142] | dut_aluCout__drv),
.aluF0(stimulus[143]),
.aluF1(stimulus[144]),
.aluF2(stimulus[145]),
.aluF3(stimulus[146]),
.aluG1(stimulus[147]),
.aluM(stimulus[148]),
.aluOut_eq_0_p_(stimulus[149] | dut_aluOut_eq_0_p___drv),
.aluP1(stimulus[150]),
.dMD_00(stimulus[151]),
.dMD_01(stimulus[152]),
.dMD_02(stimulus[153]),
.dMD_03(stimulus[154]),
.dMD_04(stimulus[155]),
.dMD_05(stimulus[156]),
.dMD_06(stimulus[157]),
.dMD_07(stimulus[158]),
.dMD_16(stimulus[159]),
.ALUCarry__drv(dut_ALUCarry__drv),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_16__drv(dut_BMux_16__drv),
.Cnt_eq_Zero_p___drv(dut_Cnt_eq_Zero_p___drv),
.DMuxData__drv(dut_DMuxData__drv),
.FA_eq_0_p___drv(dut_FA_eq_0_p___drv),
.FA_eq_1_p___drv(dut_FA_eq_1_p___drv),
.FF_0mem_p___drv(dut_FF_0mem_p___drv),
.FF_1mem__drv(dut_FF_1mem__drv),
.IOB_00__drv(dut_IOB_00__drv),
.IOB_01__drv(dut_IOB_01__drv),
.IOB_02__drv(dut_IOB_02__drv),
.IOB_03__drv(dut_IOB_03__drv),
.IOB_04__drv(dut_IOB_04__drv),
.IOB_05__drv(dut_IOB_05__drv),
.IOB_06__drv(dut_IOB_06__drv),
.IOB_07__drv(dut_IOB_07__drv),
.IOB_16__drv(dut_IOB_16__drv),
.IOPE__drv(dut_IOPE__drv),
.IOatt__drv(dut_IOatt__drv),
.MAR_00_p___drv(dut_MAR_00_p___drv),
.MAR_01_p___drv(dut_MAR_01_p___drv),
.MAR_02_p___drv(dut_MAR_02_p___drv),
.MAR_03_p___drv(dut_MAR_03_p___drv),
.MAR_04_p___drv(dut_MAR_04_p___drv),
.MAR_05_p___drv(dut_MAR_05_p___drv),
.MAR_06_p___drv(dut_MAR_06_p___drv),
.MAR_07_p___drv(dut_MAR_07_p___drv),
.MdPE__drv(dut_MdPE__drv),
.MemBase_0__drv(dut_MemBase_0__drv),
.MemBase_1__drv(dut_MemBase_1__drv),
.MemBase_2__drv(dut_MemBase_2__drv),
.MemBase_3__drv(dut_MemBase_3__drv),
.MemBase_4__drv(dut_MemBase_4__drv),
.NextData_p___drv(dut_NextData_p___drv),
.Overflow_p___drv(dut_Overflow_p___drv),
.Pdata_15__drv(dut_Pdata_15__drv),
.Q_07__drv(dut_Q_07__drv),
.RamPE__drv(dut_RamPE__drv),
.ResEqZero_p___drv(dut_ResEqZero_p___drv),
.ResLtZero_p___drv(dut_ResLtZero_p___drv),
.RmLtZero_p___drv(dut_RmLtZero_p___drv),
.ShA_00__drv(dut_ShA_00__drv),
.ShA_01__drv(dut_ShA_01__drv),
.ShA_02__drv(dut_ShA_02__drv),
.ShA_03__drv(dut_ShA_03__drv),
.ShA_04__drv(dut_ShA_04__drv),
.ShA_05__drv(dut_ShA_05__drv),
.ShA_06__drv(dut_ShA_06__drv),
.ShA_07__drv(dut_ShA_07__drv),
.Shc_02__drv(dut_Shc_02__drv),
.Shc_03__drv(dut_Shc_03__drv),
.Shc_04b__drv(dut_Shc_04b__drv),
.Shc_05b__drv(dut_Shc_05b__drv),
.Shc_06b__drv(dut_Shc_06b__drv),
.Shc_07b__drv(dut_Shc_07b__drv),
.TIOA_0__drv(dut_TIOA_0__drv),
.TIOA_1__drv(dut_TIOA_1__drv),
.TIOA_2__drv(dut_TIOA_2__drv),
.TIOA_3__drv(dut_TIOA_3__drv),
.TIOA_4__drv(dut_TIOA_4__drv),
.TIOA_5__drv(dut_TIOA_5__drv),
.TIOA_6__drv(dut_TIOA_6__drv),
.TIOA_7__drv(dut_TIOA_7__drv),
.TestTW__drv(dut_TestTW__drv),
.alu_07__drv(dut_alu_07__drv),
.aluCout__drv(dut_aluCout__drv),
.aluOut_eq_0_p___drv(dut_aluOut_eq_0_p___drv),
.state_host_clk(clk),
.state_guest_advance(board_steps[0]),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(all_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_aluOut_eq_0_p___drv,dut_aluCout__drv,dut_alu_07__drv,dut_TestTW__drv,dut_TIOA_7__drv,dut_TIOA_6__drv,dut_TIOA_5__drv,dut_TIOA_4__drv,dut_TIOA_3__drv,dut_TIOA_2__drv,dut_TIOA_1__drv,dut_TIOA_0__drv,dut_Shc_07b__drv,dut_Shc_06b__drv,dut_Shc_05b__drv,dut_Shc_04b__drv,dut_Shc_03__drv,dut_Shc_02__drv,dut_ShA_07__drv,dut_ShA_06__drv,dut_ShA_05__drv,dut_ShA_04__drv,dut_ShA_03__drv,dut_ShA_02__drv,dut_ShA_01__drv,dut_ShA_00__drv,dut_RmLtZero_p___drv,dut_ResLtZero_p___drv,dut_ResEqZero_p___drv,dut_RamPE__drv,dut_Q_07__drv,dut_Pdata_15__drv,dut_Overflow_p___drv,dut_NextData_p___drv,dut_MemBase_4__drv,dut_MemBase_3__drv,dut_MemBase_2__drv,dut_MemBase_1__drv,dut_MemBase_0__drv,dut_MdPE__drv,dut_MAR_07_p___drv,dut_MAR_06_p___drv,dut_MAR_05_p___drv,dut_MAR_04_p___drv,dut_MAR_03_p___drv,dut_MAR_02_p___drv,dut_MAR_01_p___drv,dut_MAR_00_p___drv,dut_IOatt__drv,dut_IOPE__drv,dut_IOB_16__drv,dut_IOB_07__drv,dut_IOB_06__drv,dut_IOB_05__drv,dut_IOB_04__drv,dut_IOB_03__drv,dut_IOB_02__drv,dut_IOB_01__drv,dut_IOB_00__drv,dut_FF_1mem__drv,dut_FF_0mem_p___drv,dut_FA_eq_1_p___drv,dut_FA_eq_0_p___drv,dut_DMuxData__drv,dut_Cnt_eq_Zero_p___drv,dut_BMux_16__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv,dut_ALUCarry__drv};
assign dut_state[0+:1]=dut.Clock1Bd;
assign dut_state[1+:1]=dut.Clock1_p_Ac;
assign dut_state[2+:1]=dut.Clock1_p_Ba;
assign dut_state[3+:1]=dut.Clock1_p_Bb;
assign dut_state[4+:1]=dut.Clock1_p_Ca;
assign dut_state[5+:1]=dut.Clock1_p_Cb;
assign dut_state[6+:1]=dut.Clock1_p_Cd;
assign dut_state[7+:1]=dut.Clock1_p_Da;
assign dut_state[8+:1]=dut.Clock1_p_Dc;
assign dut_state[9+:1]=dut.PostClock0_p_Bc;
assign dut_state[10+:1]=dut.u_a03.ck_d;
assign dut_state[11+:4]=dut.u_a03.q;
assign dut_state[15+:6]=dut.u_a03.setup_pre;
assign dut_state[21+:1]=dut.u_a04.ck_d;
assign dut_state[22+:4]=dut.u_a04.q;
assign dut_state[26+:6]=dut.u_a04.setup_pre;
assign dut_state[32+:1]=dut.u_a10.cka_d;
assign dut_state[33+:1]=dut.u_a10.ckb_d;
assign dut_state[34+:1]=dut.u_a10.d_pre_a;
assign dut_state[35+:1]=dut.u_a10.d_pre_b;
assign dut_state[36+:1]=dut.u_a10.qa;
assign dut_state[37+:1]=dut.u_a10.qb;
assign dut_state[38+:1]=dut.u_a11.cka_d;
assign dut_state[39+:1]=dut.u_a11.ckb_d;
assign dut_state[40+:1]=dut.u_a11.d_pre_a;
assign dut_state[41+:1]=dut.u_a11.d_pre_b;
assign dut_state[42+:1]=dut.u_a11.qa;
assign dut_state[43+:1]=dut.u_a11.qb;
assign dut_state[44+:4]=dut.u_a12.q;
assign dut_state[48+:4]=dut.u_a13.q;
assign dut_state[52+:1]=dut.u_a20.ck_d;
assign dut_state[53+:4]=dut.u_a20.d_pre;
assign dut_state[57+:1]=dut.u_a20.dl_pre;
assign dut_state[58+:1]=dut.u_a20.dr_pre;
assign dut_state[59+:4]=dut.u_a20.q;
assign dut_state[63+:2]=dut.u_a20.s_pre;
assign dut_state[65+:1]=dut.u_a21.ck_d;
assign dut_state[66+:4]=dut.u_a21.d_pre;
assign dut_state[70+:1]=dut.u_a21.dl_pre;
assign dut_state[71+:1]=dut.u_a21.dr_pre;
assign dut_state[72+:4]=dut.u_a21.q;
assign dut_state[76+:2]=dut.u_a21.s_pre;
assign dut_state[78+:4]=dut.u_b05.q;
assign dut_state[82+:1]=dut.u_b10.cka_d;
assign dut_state[83+:1]=dut.u_b10.ckb_d;
assign dut_state[84+:1]=dut.u_b10.d_pre_a;
assign dut_state[85+:1]=dut.u_b10.d_pre_b;
assign dut_state[86+:1]=dut.u_b10.qa;
assign dut_state[87+:1]=dut.u_b10.qb;
assign dut_state[88+:1]=dut.u_b11.ck_d;
assign dut_state[89+:4]=dut.u_b11.d_pre;
assign dut_state[93+:1]=dut.u_b11.dl_pre;
assign dut_state[94+:1]=dut.u_b11.dr_pre;
assign dut_state[95+:4]=dut.u_b11.q;
assign dut_state[99+:2]=dut.u_b11.s_pre;
assign dut_state[101+:4]=dut.u_b12.q;
assign dut_state[105+:4]=dut.u_b13.q;
assign dut_state[109+:1]=dut.u_b15.ck_d;
assign dut_state[110+:6]=dut.u_b15.d_pre;
assign dut_state[116+:6]=dut.u_b15.q;
assign dut_state[122+:4]=dut.u_c05.q;
assign dut_state[126+:1]=dut.u_c10.ck_d;
assign dut_state[127+:6]=dut.u_c10.d_pre;
assign dut_state[133+:6]=dut.u_c10.q;
assign dut_state[139+:1]=dut.u_c11.ck_d;
assign dut_state[140+:4]=dut.u_c11.d_pre;
assign dut_state[144+:1]=dut.u_c11.dl_pre;
assign dut_state[145+:1]=dut.u_c11.dr_pre;
assign dut_state[146+:4]=dut.u_c11.q;
assign dut_state[150+:2]=dut.u_c11.s_pre;
assign dut_state[152+:1]=dut.u_c12.ck_d;
assign dut_state[153+:4]=dut.u_c12.d_pre;
assign dut_state[157+:1]=dut.u_c12.dl_pre;
assign dut_state[158+:1]=dut.u_c12.dr_pre;
assign dut_state[159+:4]=dut.u_c12.q;
assign dut_state[163+:2]=dut.u_c12.s_pre;
assign dut_state[165+:4]=dut.u_c13.q;
assign dut_state[169+:4]=dut.u_d05.q;
assign dut_state[173+:1]=dut.u_d16.ck_d;
assign dut_state[174+:4]=dut.u_d16.q;
assign dut_state[178+:6]=dut.u_d16.setup_pre;
assign dut_state[184+:4]=dut.u_e05.q;
assign dut_state[188+:4]=dut.u_e06.q;
assign dut_state[192+:4]=dut.u_e13.a_lat;
assign dut_state[196+:1]=dut.u_e13.ce_lat;
assign dut_state[197+:4]=dut.u_e13.d_lat;
assign dut_state[201+:64]={dut.u_e13.mem[15],dut.u_e13.mem[14],dut.u_e13.mem[13],dut.u_e13.mem[12],dut.u_e13.mem[11],dut.u_e13.mem[10],dut.u_e13.mem[9],dut.u_e13.mem[8],dut.u_e13.mem[7],dut.u_e13.mem[6],dut.u_e13.mem[5],dut.u_e13.mem[4],dut.u_e13.mem[3],dut.u_e13.mem[2],dut.u_e13.mem[1],dut.u_e13.mem[0]};
assign dut_state[265+:1]=dut.u_e13.we_d;
assign dut_state[266+:1]=dut.u_e16.ck_d;
assign dut_state[267+:4]=dut.u_e16.q;
assign dut_state[271+:6]=dut.u_e16.setup_pre;
assign dut_state[277+:4]=dut.u_f06.q;
assign dut_state[281+:1]=dut.u_f16.ck_d;
assign dut_state[282+:4]=dut.u_f16.d_pre;
assign dut_state[286+:4]=dut.u_f16.q;
assign dut_state[290+:4]=dut.u_f17.q;
assign dut_state[294+:1]=dut.u_f21.ck_d;
assign dut_state[295+:6]=dut.u_f21.d_pre;
assign dut_state[301+:6]=dut.u_f21.q;
assign dut_state[307+:4]=dut.u_g05.q;
assign dut_state[311+:4]=dut.u_g06.q;
assign dut_state[315+:4]=dut.u_g07.q;
assign dut_state[319+:1]=dut.u_g10.ck_d;
assign dut_state[320+:4]=dut.u_g10.d_pre;
assign dut_state[324+:4]=dut.u_g10.q;
assign dut_state[328+:1]=dut.u_g11.ck_d;
assign dut_state[329+:6]=dut.u_g11.d_pre;
assign dut_state[335+:6]=dut.u_g11.q;
assign dut_state[341+:4]=dut.u_g15.a_lat;
assign dut_state[345+:1]=dut.u_g15.ce_lat;
assign dut_state[346+:4]=dut.u_g15.d_lat;
assign dut_state[350+:64]={dut.u_g15.mem[15],dut.u_g15.mem[14],dut.u_g15.mem[13],dut.u_g15.mem[12],dut.u_g15.mem[11],dut.u_g15.mem[10],dut.u_g15.mem[9],dut.u_g15.mem[8],dut.u_g15.mem[7],dut.u_g15.mem[6],dut.u_g15.mem[5],dut.u_g15.mem[4],dut.u_g15.mem[3],dut.u_g15.mem[2],dut.u_g15.mem[1],dut.u_g15.mem[0]};
assign dut_state[414+:1]=dut.u_g15.we_d;
assign dut_state[415+:1]=dut.u_g16.ck_d;
assign dut_state[416+:4]=dut.u_g16.d_pre;
assign dut_state[420+:4]=dut.u_g16.q;
assign dut_state[424+:1]=dut.u_g18.ck_d;
assign dut_state[425+:6]=dut.u_g18.d_pre;
assign dut_state[431+:6]=dut.u_g18.q;
assign dut_state[437+:1]=dut.u_g22.cka_d;
assign dut_state[438+:1]=dut.u_g22.ckb_d;
assign dut_state[439+:1]=dut.u_g22.d_pre_a;
assign dut_state[440+:1]=dut.u_g22.d_pre_b;
assign dut_state[441+:1]=dut.u_g22.qa;
assign dut_state[442+:1]=dut.u_g22.qb;
assign dut_state[443+:1]=dut.u_g23.cka_d;
assign dut_state[444+:1]=dut.u_g23.ckb_d;
assign dut_state[445+:1]=dut.u_g23.d_pre_a;
assign dut_state[446+:1]=dut.u_g23.d_pre_b;
assign dut_state[447+:1]=dut.u_g23.qa;
assign dut_state[448+:1]=dut.u_g23.qb;
assign dut_state[449+:1]=dut.u_g24.cka_d;
assign dut_state[450+:1]=dut.u_g24.ckb_d;
assign dut_state[451+:1]=dut.u_g24.d_pre_a;
assign dut_state[452+:1]=dut.u_g24.d_pre_b;
assign dut_state[453+:1]=dut.u_g24.qa;
assign dut_state[454+:1]=dut.u_g24.qb;
assign dut_state[455+:4]=dut.u_h05.q;
assign dut_state[459+:1]=dut.u_h10.ck_d;
assign dut_state[460+:4]=dut.u_h10.d_pre;
assign dut_state[464+:4]=dut.u_h10.q;
assign dut_state[468+:1]=dut.u_h11.ck_d;
assign dut_state[469+:6]=dut.u_h11.d_pre;
assign dut_state[475+:6]=dut.u_h11.q;
assign dut_state[481+:4]=dut.u_h15.a_lat;
assign dut_state[485+:1]=dut.u_h15.ce_lat;
assign dut_state[486+:4]=dut.u_h15.d_lat;
assign dut_state[490+:64]={dut.u_h15.mem[15],dut.u_h15.mem[14],dut.u_h15.mem[13],dut.u_h15.mem[12],dut.u_h15.mem[11],dut.u_h15.mem[10],dut.u_h15.mem[9],dut.u_h15.mem[8],dut.u_h15.mem[7],dut.u_h15.mem[6],dut.u_h15.mem[5],dut.u_h15.mem[4],dut.u_h15.mem[3],dut.u_h15.mem[2],dut.u_h15.mem[1],dut.u_h15.mem[0]};
assign dut_state[554+:1]=dut.u_h15.we_d;
assign dut_state[555+:1]=dut.u_h18.ck_d;
assign dut_state[556+:6]=dut.u_h18.d_pre;
assign dut_state[562+:6]=dut.u_h18.q;
assign dut_state[568+:1]=dut.u_h22.ck_d;
assign dut_state[569+:6]=dut.u_h22.d_pre;
assign dut_state[575+:6]=dut.u_h22.q;
assign dut_state[581+:5]=dut.u_i01.q;
assign dut_state[586+:5]=dut.u_i02.q;
assign dut_state[591+:4]=dut.u_i03.q;
assign dut_state[595+:4]=dut.u_i04.q;
assign dut_state[599+:4]=dut.u_i11.a_lat;
assign dut_state[603+:1]=dut.u_i11.ce_lat;
assign dut_state[604+:4]=dut.u_i11.d_lat;
assign dut_state[608+:64]={dut.u_i11.mem[15],dut.u_i11.mem[14],dut.u_i11.mem[13],dut.u_i11.mem[12],dut.u_i11.mem[11],dut.u_i11.mem[10],dut.u_i11.mem[9],dut.u_i11.mem[8],dut.u_i11.mem[7],dut.u_i11.mem[6],dut.u_i11.mem[5],dut.u_i11.mem[4],dut.u_i11.mem[3],dut.u_i11.mem[2],dut.u_i11.mem[1],dut.u_i11.mem[0]};
assign dut_state[672+:1]=dut.u_i11.we_d;
assign dut_state[673+:1]=dut.u_i12.ck_d;
assign dut_state[674+:4]=dut.u_i12.d_pre;
assign dut_state[678+:1]=dut.u_i12.dl_pre;
assign dut_state[679+:1]=dut.u_i12.dr_pre;
assign dut_state[680+:4]=dut.u_i12.q;
assign dut_state[684+:2]=dut.u_i12.s_pre;
assign dut_state[686+:1]=dut.u_i19.ck_d;
assign dut_state[687+:6]=dut.u_i19.d_pre;
assign dut_state[693+:6]=dut.u_i19.q;
assign dut_state[699+:4]=dut.u_j01.q;
assign dut_state[703+:4]=dut.u_j02.q;
assign dut_state[707+:4]=dut.u_j03.q;
assign dut_state[711+:4]=dut.u_j04.q;
assign dut_state[715+:1]=dut.u_j11.ck_d;
assign dut_state[716+:6]=dut.u_j11.d_pre;
assign dut_state[722+:6]=dut.u_j11.q;
assign dut_state[728+:4]=dut.u_j16.a_lat;
assign dut_state[732+:1]=dut.u_j16.ce_lat;
assign dut_state[733+:4]=dut.u_j16.d_lat;
assign dut_state[737+:64]={dut.u_j16.mem[15],dut.u_j16.mem[14],dut.u_j16.mem[13],dut.u_j16.mem[12],dut.u_j16.mem[11],dut.u_j16.mem[10],dut.u_j16.mem[9],dut.u_j16.mem[8],dut.u_j16.mem[7],dut.u_j16.mem[6],dut.u_j16.mem[5],dut.u_j16.mem[4],dut.u_j16.mem[3],dut.u_j16.mem[2],dut.u_j16.mem[1],dut.u_j16.mem[0]};
assign dut_state[801+:1]=dut.u_j16.we_d;
assign dut_state[802+:4]=dut.u_j17.a_lat;
assign dut_state[806+:1]=dut.u_j17.ce_lat;
assign dut_state[807+:4]=dut.u_j17.d_lat;
assign dut_state[811+:64]={dut.u_j17.mem[15],dut.u_j17.mem[14],dut.u_j17.mem[13],dut.u_j17.mem[12],dut.u_j17.mem[11],dut.u_j17.mem[10],dut.u_j17.mem[9],dut.u_j17.mem[8],dut.u_j17.mem[7],dut.u_j17.mem[6],dut.u_j17.mem[5],dut.u_j17.mem[4],dut.u_j17.mem[3],dut.u_j17.mem[2],dut.u_j17.mem[1],dut.u_j17.mem[0]};
assign dut_state[875+:1]=dut.u_j17.we_d;
assign dut_state[876+:1]=dut.u_j20.cka_d;
assign dut_state[877+:1]=dut.u_j20.ckb_d;
assign dut_state[878+:1]=dut.u_j20.d_pre_a;
assign dut_state[879+:1]=dut.u_j20.d_pre_b;
assign dut_state[880+:1]=dut.u_j20.qa;
assign dut_state[881+:1]=dut.u_j20.qb;
assign dut_state[882+:4]=dut.u_k01.q;
assign dut_state[886+:4]=dut.u_k02.q;
assign dut_state[890+:1]=dut.u_k21.ck_d;
assign dut_state[891+:6]=dut.u_k21.d_pre;
assign dut_state[897+:6]=dut.u_k21.q;
assign dut_state[903+:1]=dut.u_k22.ck_d;
assign dut_state[904+:6]=dut.u_k22.d_pre;
assign dut_state[910+:6]=dut.u_k22.q;
assign dut_state[916+:1]=dut.u_l02.cka_d;
assign dut_state[917+:1]=dut.u_l02.ckb_d;
assign dut_state[918+:1]=dut.u_l02.d_pre_a;
assign dut_state[919+:1]=dut.u_l02.d_pre_b;
assign dut_state[920+:1]=dut.u_l02.qa;
assign dut_state[921+:1]=dut.u_l02.qb;
assign dut_state[922+:4]=dut.u_l03.a_lat;
assign dut_state[926+:1]=dut.u_l03.ce_lat;
assign dut_state[927+:4]=dut.u_l03.d_lat;
assign dut_state[931+:64]={dut.u_l03.mem[15],dut.u_l03.mem[14],dut.u_l03.mem[13],dut.u_l03.mem[12],dut.u_l03.mem[11],dut.u_l03.mem[10],dut.u_l03.mem[9],dut.u_l03.mem[8],dut.u_l03.mem[7],dut.u_l03.mem[6],dut.u_l03.mem[5],dut.u_l03.mem[4],dut.u_l03.mem[3],dut.u_l03.mem[2],dut.u_l03.mem[1],dut.u_l03.mem[0]};
assign dut_state[995+:1]=dut.u_l03.we_d;
assign dut_state[996+:4]=dut.u_l04.a_lat;
assign dut_state[1000+:1]=dut.u_l04.ce_lat;
assign dut_state[1001+:4]=dut.u_l04.d_lat;
assign dut_state[1005+:64]={dut.u_l04.mem[15],dut.u_l04.mem[14],dut.u_l04.mem[13],dut.u_l04.mem[12],dut.u_l04.mem[11],dut.u_l04.mem[10],dut.u_l04.mem[9],dut.u_l04.mem[8],dut.u_l04.mem[7],dut.u_l04.mem[6],dut.u_l04.mem[5],dut.u_l04.mem[4],dut.u_l04.mem[3],dut.u_l04.mem[2],dut.u_l04.mem[1],dut.u_l04.mem[0]};
assign dut_state[1069+:1]=dut.u_l04.we_d;
assign dut_state[1070+:1]=dut.u_l05.ck_d;
assign dut_state[1071+:6]=dut.u_l05.d_pre;
assign dut_state[1077+:6]=dut.u_l05.q;
assign dut_state[1083+:1]=dut.u_l06.cka_d;
assign dut_state[1084+:1]=dut.u_l06.ckb_d;
assign dut_state[1085+:1]=dut.u_l06.qa;
assign dut_state[1086+:1]=dut.u_l06.qb;
assign dut_state[1087+:1]=dut.u_l07.cka_d;
assign dut_state[1088+:1]=dut.u_l07.ckb_d;
assign dut_state[1089+:1]=dut.u_l07.qa;
assign dut_state[1090+:1]=dut.u_l07.qb;
assign dut_state[1091+:1]=dut.u_l22.ck_d;
assign dut_state[1092+:6]=dut.u_l22.d_pre;
assign dut_state[1098+:6]=dut.u_l22.q;
assign dut_probe[0+:4]=dut.u_h06.mem[0+(probe_index%256)];
assign dut_probe[4+:4]=dut.u_i06.mem[0+(probe_index%256)];
assign dut_probe[8+:1]=dut.u_i08.mem[0+(probe_index%256)];
assign dut_probe[9+:4]=dut.u_j06.mem[0+(probe_index%256)];
assign dut_probe[13+:1]=dut.u_j08.mem[0+(probe_index%256)];
assign dut_probe[14+:4]=dut.u_k06.mem[0+(probe_index%256)];
assign all_helpers_frozen=&{dut.state_frozen,dut.u_e13.state_frozen,dut.u_g15.state_frozen,dut.u_h06.state_frozen,dut.u_h15.state_frozen,dut.u_i06.state_frozen,dut.u_i08.state_frozen,dut.u_i11.state_frozen,dut.u_j06.state_frozen,dut.u_j08.state_frozen,dut.u_j16.state_frozen,dut.u_j17.state_frozen,dut.u_k06.state_frozen,dut.u_l03.state_frozen,dut.u_l04.state_frozen};
endmodule
