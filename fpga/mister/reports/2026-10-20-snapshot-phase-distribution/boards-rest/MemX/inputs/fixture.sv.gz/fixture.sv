module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [123:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [112:0] reference_outputs,dut_outputs,
 output wire [2055:0] reference_state,dut_state,
 output wire [20:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire all_hold=global_hold || (freeze && held) ||
 reference_hold || dut_hold || reference_fault || dut_fault;
 reg original_step=0;
 always @(negedge clk)original_step<=advance && !all_hold;
 wire [18:0] board_steps;
 dorado_board_phase_enable copies(.clk(clk),.permit(advance && !all_hold),.advance(board_steps));
 // All nineteen copies must remain identical, including scan and reset edges.
 always @(posedge clk)begin
  if(board_steps!=={19{original_step}})$fatal(1,"board phase copies differ");
 end
 wire reference_AcanhaveMap_p___drv;
wire reference_At_eq_Curt_p___drv;
wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_CountMiss__drv;
wire reference_DMuxData__drv;
wire reference_DdataGood_p___drv;
wire reference_EcDcomingForCt_p___drv;
wire reference_EcWantsA__drv;
wire reference_EmuOrFT_p___drv;
wire reference_ErrorsFromEc2__drv;
wire reference_FinNext__drv;
wire reference_FinSubtask_0__drv;
wire reference_FinSubtask_1__drv;
wire reference_FinTask_0__drv;
wire reference_FinTask_1__drv;
wire reference_FinTask_2__drv;
wire reference_FinTask_3__drv;
wire reference_Fout_flt__drv;
wire reference_FoutNext__drv;
wire reference_FoutSubTask_0__drv;
wire reference_FoutSubtask_1__drv;
wire reference_FoutTask_0__drv;
wire reference_FoutTask_1__drv;
wire reference_FoutTask_2__drv;
wire reference_FoutTask_3__drv;
wire reference_HoldMapBuf__drv;
wire reference_IfuFaultInEc2__drv;
wire reference_LargeHold__drv;
wire reference_LdPipeVAdly_p___drv;
wire reference_LoadEcOut_p___drv;
wire reference_LoadSinE__drv;
wire reference_LoadSinO__drv;
wire reference_LoadSoutE_p___drv;
wire reference_LoadSoutO_p___drv;
wire reference_MDMtag_p___drv;
wire reference_MakeD_u_CD__drv;
wire reference_MakeD_u_Dbuf__drv;
wire reference_MakeF_u_D__drv;
wire reference_MakeFout_u_D__drv;
wire reference_MakeMDM_u_D_p___drv;
wire reference_MakeMD_u_D_p___drv;
wire reference_MakeSout_u_D__drv;
wire reference_MapRfsh_p___drv;
wire reference_MapTroubleInEc1__drv;
wire reference_MapWait_m_D__drv;
wire reference_MemAd_0__drv;
wire reference_MemAd_1__drv;
wire reference_MemAd_2__drv;
wire reference_MemAd_3__drv;
wire reference_MemAd_4__drv;
wire reference_MemAd_5__drv;
wire reference_MemAd_6__drv;
wire reference_MemAd_7__drv;
wire reference_MemAd_8__drv;
wire reference_MemCASa__drv;
wire reference_MemCASb__drv;
wire reference_MemError__drv;
wire reference_MemPE__drv;
wire reference_MemRASa__drv;
wire reference_MemRASb__drv;
wire reference_MemRfsh__drv;
wire reference_MemWEa__drv;
wire reference_MemWEb__drv;
wire reference_Mod0SinEn_p___drv;
wire reference_Mod0StrEn_p___drv;
wire reference_Mod1SinEn_p___drv;
wire reference_Mod1StrEn_p___drv;
wire reference_Mod2SinEn_p___drv;
wire reference_Mod2StrEn_p___drv;
wire reference_Mod3SinEn_p___drv;
wire reference_Mod3StrEn_p___drv;
wire reference_ProcTag__drv;
wire reference_ProcTagInA__drv;
wire reference_STfree_p___drv;
wire reference_ShiftEcOut__drv;
wire reference_ShiftSinE__drv;
wire reference_ShiftSinO__drv;
wire reference_ShiftSoutE__drv;
wire reference_ShiftSoutO__drv;
wire reference_StartEcChk_p___drv;
wire reference_StartEcGen_p___drv;
wire reference_TWReq_15__drv;
wire reference_Transport_p___drv;
wire reference_WPinEc1__drv;
wire reference_XWantsPipe__drv;
wire reference_dMDMad_0_p___drv;
wire reference_dMDMad_1_p___drv;
wire reference_dMDMad_2_p___drv;
wire reference_dMDMad_3_p___drv;
wire reference_dPipe02Ad_0__drv;
wire reference_dPipe02Ad_1__drv;
wire reference_dPipe02Ad_2__drv;
wire reference_dPipe02Ad_3__drv;
wire reference_dPipe34Ad_0__drv;
wire reference_dPipe34Ad_1__drv;
wire reference_dPipe34Ad_2__drv;
wire reference_dPipe34Ad_3__drv;
wire reference_preMCSb__drv;
MemX_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.AfreeOrEc_p_b(stimulus[0]),
.At_eq_Curt_p_(stimulus[1] | reference_At_eq_Curt_p___drv),
.AwantsDifHit_p_(stimulus[2]),
.BMux_00(stimulus[3] | reference_BMux_00__drv),
.BMux_01(stimulus[4] | reference_BMux_01__drv),
.BMux_02(stimulus[5] | reference_BMux_02__drv),
.BMux_03(stimulus[6] | reference_BMux_03__drv),
.BMux_04(stimulus[7] | reference_BMux_04__drv),
.BMux_05(stimulus[8] | reference_BMux_05__drv),
.BMux_06(stimulus[9] | reference_BMux_06__drv),
.BMux_07(stimulus[10] | reference_BMux_07__drv),
.BMux_08(stimulus[11] | reference_BMux_08__drv),
.BMux_09(stimulus[12] | reference_BMux_09__drv),
.BMux_10(stimulus[13] | reference_BMux_10__drv),
.BMux_11(stimulus[14] | reference_BMux_11__drv),
.BMux_12(stimulus[15] | reference_BMux_12__drv),
.BMux_13(stimulus[16] | reference_BMux_13__drv),
.BMux_14(stimulus[17] | reference_BMux_14__drv),
.BMux_15(stimulus[18] | reference_BMux_15__drv),
.BMux_16(stimulus[19]),
.BMux_17(stimulus[20]),
.BNTGtCT_p_a(stimulus[21]),
.CLK_mx_p_(stimulus[22]),
.CacheRef_p_(stimulus[23]),
.CacheRefInEc1(stimulus[24]),
.ChipsAre256_s_16K(stimulus[25]),
.ChipsAre64K(stimulus[26]),
.ClkEnable_p_a(stimulus[27]),
.CountMiss(stimulus[28] | reference_CountMiss__drv),
.DMuxClk(stimulus[29]),
.DMuxData(stimulus[30] | reference_DMuxData__drv),
.DdataGood_p_(stimulus[31] | reference_DdataGood_p___drv),
.DirtyIoFetchInA_p_(stimulus[32]),
.DisHold(stimulus[33]),
.ECFault(stimulus[34]),
.EcDcomingForCt_p_(stimulus[35] | reference_EcDcomingForCt_p___drv),
.EcKeepsAbusy(stimulus[36]),
.EcWantsA(stimulus[37] | reference_EcWantsA__drv),
.ErrorsFromEc2(stimulus[38] | reference_ErrorsFromEc2__drv),
.FinNext(stimulus[39] | reference_FinNext__drv),
.FoutNext(stimulus[40] | reference_FoutNext__drv),
.Hita(stimulus[41]),
.HoldMapBuf(stimulus[42] | reference_HoldMapBuf__drv),
.IfuRefInEc1(stimulus[43]),
.IoFetchInA_p_(stimulus[44]),
.IoStoreInA(stimulus[45]),
.LoadSinE(stimulus[46] | reference_LoadSinE__drv),
.LoadSinO(stimulus[47] | reference_LoadSinO__drv),
.M0(stimulus[48]),
.M1(stimulus[49]),
.M2(stimulus[50]),
.M3(stimulus[51]),
.MDMtag_p_(stimulus[52] | reference_MDMtag_p___drv),
.MXHold(stimulus[53]),
.MakeD_u_CD(stimulus[54] | reference_MakeD_u_CD__drv),
.MakeD_u_Dbuf(stimulus[55] | reference_MakeD_u_Dbuf__drv),
.MakeF_u_D(stimulus[56] | reference_MakeF_u_D__drv),
.MakeFout_u_D(stimulus[57] | reference_MakeFout_u_D__drv),
.MakeMDM_u_D_p_(stimulus[58] | reference_MakeMDM_u_D_p___drv),
.MakeSout_u_D(stimulus[59] | reference_MakeSout_u_D__drv),
.MapAd_0(stimulus[60]),
.MapAd_1(stimulus[61]),
.MapAd_2(stimulus[62]),
.MapAd_3(stimulus[63]),
.MapAd_4(stimulus[64]),
.MapAd_5(stimulus[65]),
.MapAd_6(stimulus[66]),
.MapAd_7(stimulus[67]),
.MapAd_8(stimulus[68]),
.MapRfsh_p_(stimulus[69] | reference_MapRfsh_p___drv),
.MapTroubleInEc1(stimulus[70] | reference_MapTroubleInEc1__drv),
.MapWait_m_D(stimulus[71] | reference_MapWait_m_D__drv),
.Map_u_InPair_p_(stimulus[72]),
.Mcr_u__p_(stimulus[73]),
.MemClkEnable_p_c(stimulus[74]),
.MemError(stimulus[75] | reference_MemError__drv),
.MemPE(stimulus[76] | reference_MemPE__drv),
.MemRfsh(stimulus[77] | reference_MemRfsh__drv),
.MemSH(stimulus[78]),
.Next_0(stimulus[79]),
.Next_1(stimulus[80]),
.Next_2(stimulus[81]),
.Next_3(stimulus[82]),
.PairFull_p_(stimulus[83]),
.PrivRefInPair(stimulus[84]),
.ProcSrn_u__p_(stimulus[85]),
.ProcTag(stimulus[86] | reference_ProcTag__drv),
.ProcTagInA(stimulus[87] | reference_ProcTagInA__drv),
.ReadInA_p_(stimulus[88]),
.RfshPeriod(stimulus[89]),
.STfree_p_(stimulus[90] | reference_STfree_p___drv),
.SW(stimulus[91]),
.StartMap_p_(stimulus[92]),
.StkError(stimulus[93]),
.Store_u_InA_p_(stimulus[94]),
.Store_u_InEc1_p_(stimulus[95]),
.SubTask_0(stimulus[96]),
.SubTask_1(stimulus[97]),
.TIOA_0(stimulus[98]),
.TIOA_1(stimulus[99]),
.TagInEc1(stimulus[100]),
.UseAsrn(stimulus[101]),
.VicIfMiss_p_(stimulus[102]),
.VicInPair_p_(stimulus[103]),
.VicOrFS1C(stimulus[104]),
.WPinEc1(stimulus[105] | reference_WPinEc1__drv),
._u_Config(stimulus[106]),
._u_FaultInfo(stimulus[107]),
._u_MD(stimulus[108]),
._u_MDdly_p_(stimulus[109]),
._u_Map(stimulus[110]),
._u_Pipe2(stimulus[111]),
._u_Pipe3(stimulus[112]),
._u_Pipe4(stimulus[113]),
.dHitPerr(stimulus[114]),
.dPipe02Ad_0(stimulus[115] | reference_dPipe02Ad_0__drv),
.dPipe02Ad_1(stimulus[116] | reference_dPipe02Ad_1__drv),
.dPipe02Ad_2(stimulus[117] | reference_dPipe02Ad_2__drv),
.dPipe02Ad_3(stimulus[118] | reference_dPipe02Ad_3__drv),
.dPipe34Ad_0(stimulus[119] | reference_dPipe34Ad_0__drv),
.dPipe34Ad_1(stimulus[120] | reference_dPipe34Ad_1__drv),
.dPipe34Ad_2(stimulus[121] | reference_dPipe34Ad_2__drv),
.dPipe34Ad_3(stimulus[122] | reference_dPipe34Ad_3__drv),
.dSTPerr(stimulus[123]),
.AcanhaveMap_p___drv(reference_AcanhaveMap_p___drv),
.At_eq_Curt_p___drv(reference_At_eq_Curt_p___drv),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.CountMiss__drv(reference_CountMiss__drv),
.DMuxData__drv(reference_DMuxData__drv),
.DdataGood_p___drv(reference_DdataGood_p___drv),
.EcDcomingForCt_p___drv(reference_EcDcomingForCt_p___drv),
.EcWantsA__drv(reference_EcWantsA__drv),
.EmuOrFT_p___drv(reference_EmuOrFT_p___drv),
.ErrorsFromEc2__drv(reference_ErrorsFromEc2__drv),
.FinNext__drv(reference_FinNext__drv),
.FinSubtask_0__drv(reference_FinSubtask_0__drv),
.FinSubtask_1__drv(reference_FinSubtask_1__drv),
.FinTask_0__drv(reference_FinTask_0__drv),
.FinTask_1__drv(reference_FinTask_1__drv),
.FinTask_2__drv(reference_FinTask_2__drv),
.FinTask_3__drv(reference_FinTask_3__drv),
.Fout_flt__drv(reference_Fout_flt__drv),
.FoutNext__drv(reference_FoutNext__drv),
.FoutSubTask_0__drv(reference_FoutSubTask_0__drv),
.FoutSubtask_1__drv(reference_FoutSubtask_1__drv),
.FoutTask_0__drv(reference_FoutTask_0__drv),
.FoutTask_1__drv(reference_FoutTask_1__drv),
.FoutTask_2__drv(reference_FoutTask_2__drv),
.FoutTask_3__drv(reference_FoutTask_3__drv),
.HoldMapBuf__drv(reference_HoldMapBuf__drv),
.IfuFaultInEc2__drv(reference_IfuFaultInEc2__drv),
.LargeHold__drv(reference_LargeHold__drv),
.LdPipeVAdly_p___drv(reference_LdPipeVAdly_p___drv),
.LoadEcOut_p___drv(reference_LoadEcOut_p___drv),
.LoadSinE__drv(reference_LoadSinE__drv),
.LoadSinO__drv(reference_LoadSinO__drv),
.LoadSoutE_p___drv(reference_LoadSoutE_p___drv),
.LoadSoutO_p___drv(reference_LoadSoutO_p___drv),
.MDMtag_p___drv(reference_MDMtag_p___drv),
.MakeD_u_CD__drv(reference_MakeD_u_CD__drv),
.MakeD_u_Dbuf__drv(reference_MakeD_u_Dbuf__drv),
.MakeF_u_D__drv(reference_MakeF_u_D__drv),
.MakeFout_u_D__drv(reference_MakeFout_u_D__drv),
.MakeMDM_u_D_p___drv(reference_MakeMDM_u_D_p___drv),
.MakeMD_u_D_p___drv(reference_MakeMD_u_D_p___drv),
.MakeSout_u_D__drv(reference_MakeSout_u_D__drv),
.MapRfsh_p___drv(reference_MapRfsh_p___drv),
.MapTroubleInEc1__drv(reference_MapTroubleInEc1__drv),
.MapWait_m_D__drv(reference_MapWait_m_D__drv),
.MemAd_0__drv(reference_MemAd_0__drv),
.MemAd_1__drv(reference_MemAd_1__drv),
.MemAd_2__drv(reference_MemAd_2__drv),
.MemAd_3__drv(reference_MemAd_3__drv),
.MemAd_4__drv(reference_MemAd_4__drv),
.MemAd_5__drv(reference_MemAd_5__drv),
.MemAd_6__drv(reference_MemAd_6__drv),
.MemAd_7__drv(reference_MemAd_7__drv),
.MemAd_8__drv(reference_MemAd_8__drv),
.MemCASa__drv(reference_MemCASa__drv),
.MemCASb__drv(reference_MemCASb__drv),
.MemError__drv(reference_MemError__drv),
.MemPE__drv(reference_MemPE__drv),
.MemRASa__drv(reference_MemRASa__drv),
.MemRASb__drv(reference_MemRASb__drv),
.MemRfsh__drv(reference_MemRfsh__drv),
.MemWEa__drv(reference_MemWEa__drv),
.MemWEb__drv(reference_MemWEb__drv),
.Mod0SinEn_p___drv(reference_Mod0SinEn_p___drv),
.Mod0StrEn_p___drv(reference_Mod0StrEn_p___drv),
.Mod1SinEn_p___drv(reference_Mod1SinEn_p___drv),
.Mod1StrEn_p___drv(reference_Mod1StrEn_p___drv),
.Mod2SinEn_p___drv(reference_Mod2SinEn_p___drv),
.Mod2StrEn_p___drv(reference_Mod2StrEn_p___drv),
.Mod3SinEn_p___drv(reference_Mod3SinEn_p___drv),
.Mod3StrEn_p___drv(reference_Mod3StrEn_p___drv),
.ProcTag__drv(reference_ProcTag__drv),
.ProcTagInA__drv(reference_ProcTagInA__drv),
.STfree_p___drv(reference_STfree_p___drv),
.ShiftEcOut__drv(reference_ShiftEcOut__drv),
.ShiftSinE__drv(reference_ShiftSinE__drv),
.ShiftSinO__drv(reference_ShiftSinO__drv),
.ShiftSoutE__drv(reference_ShiftSoutE__drv),
.ShiftSoutO__drv(reference_ShiftSoutO__drv),
.StartEcChk_p___drv(reference_StartEcChk_p___drv),
.StartEcGen_p___drv(reference_StartEcGen_p___drv),
.TWReq_15__drv(reference_TWReq_15__drv),
.Transport_p___drv(reference_Transport_p___drv),
.WPinEc1__drv(reference_WPinEc1__drv),
.XWantsPipe__drv(reference_XWantsPipe__drv),
.dMDMad_0_p___drv(reference_dMDMad_0_p___drv),
.dMDMad_1_p___drv(reference_dMDMad_1_p___drv),
.dMDMad_2_p___drv(reference_dMDMad_2_p___drv),
.dMDMad_3_p___drv(reference_dMDMad_3_p___drv),
.dPipe02Ad_0__drv(reference_dPipe02Ad_0__drv),
.dPipe02Ad_1__drv(reference_dPipe02Ad_1__drv),
.dPipe02Ad_2__drv(reference_dPipe02Ad_2__drv),
.dPipe02Ad_3__drv(reference_dPipe02Ad_3__drv),
.dPipe34Ad_0__drv(reference_dPipe34Ad_0__drv),
.dPipe34Ad_1__drv(reference_dPipe34Ad_1__drv),
.dPipe34Ad_2__drv(reference_dPipe34Ad_2__drv),
.dPipe34Ad_3__drv(reference_dPipe34Ad_3__drv),
.preMCSb__drv(reference_preMCSb__drv),
.state_host_clk(clk),
.state_guest_advance(original_step),
.state_freeze(freeze || all_hold),
.state_guest_held(held || all_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[23:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_preMCSb__drv,reference_dPipe34Ad_3__drv,reference_dPipe34Ad_2__drv,reference_dPipe34Ad_1__drv,reference_dPipe34Ad_0__drv,reference_dPipe02Ad_3__drv,reference_dPipe02Ad_2__drv,reference_dPipe02Ad_1__drv,reference_dPipe02Ad_0__drv,reference_dMDMad_3_p___drv,reference_dMDMad_2_p___drv,reference_dMDMad_1_p___drv,reference_dMDMad_0_p___drv,reference_XWantsPipe__drv,reference_WPinEc1__drv,reference_Transport_p___drv,reference_TWReq_15__drv,reference_StartEcGen_p___drv,reference_StartEcChk_p___drv,reference_ShiftSoutO__drv,reference_ShiftSoutE__drv,reference_ShiftSinO__drv,reference_ShiftSinE__drv,reference_ShiftEcOut__drv,reference_STfree_p___drv,reference_ProcTagInA__drv,reference_ProcTag__drv,reference_Mod3StrEn_p___drv,reference_Mod3SinEn_p___drv,reference_Mod2StrEn_p___drv,reference_Mod2SinEn_p___drv,reference_Mod1StrEn_p___drv,reference_Mod1SinEn_p___drv,reference_Mod0StrEn_p___drv,reference_Mod0SinEn_p___drv,reference_MemWEb__drv,reference_MemWEa__drv,reference_MemRfsh__drv,reference_MemRASb__drv,reference_MemRASa__drv,reference_MemPE__drv,reference_MemError__drv,reference_MemCASb__drv,reference_MemCASa__drv,reference_MemAd_8__drv,reference_MemAd_7__drv,reference_MemAd_6__drv,reference_MemAd_5__drv,reference_MemAd_4__drv,reference_MemAd_3__drv,reference_MemAd_2__drv,reference_MemAd_1__drv,reference_MemAd_0__drv,reference_MapWait_m_D__drv,reference_MapTroubleInEc1__drv,reference_MapRfsh_p___drv,reference_MakeSout_u_D__drv,reference_MakeMD_u_D_p___drv,reference_MakeMDM_u_D_p___drv,reference_MakeFout_u_D__drv,reference_MakeF_u_D__drv,reference_MakeD_u_Dbuf__drv,reference_MakeD_u_CD__drv,reference_MDMtag_p___drv,reference_LoadSoutO_p___drv,reference_LoadSoutE_p___drv,reference_LoadSinO__drv,reference_LoadSinE__drv,reference_LoadEcOut_p___drv,reference_LdPipeVAdly_p___drv,reference_LargeHold__drv,reference_IfuFaultInEc2__drv,reference_HoldMapBuf__drv,reference_FoutTask_3__drv,reference_FoutTask_2__drv,reference_FoutTask_1__drv,reference_FoutTask_0__drv,reference_FoutSubtask_1__drv,reference_FoutSubTask_0__drv,reference_FoutNext__drv,reference_Fout_flt__drv,reference_FinTask_3__drv,reference_FinTask_2__drv,reference_FinTask_1__drv,reference_FinTask_0__drv,reference_FinSubtask_1__drv,reference_FinSubtask_0__drv,reference_FinNext__drv,reference_ErrorsFromEc2__drv,reference_EmuOrFT_p___drv,reference_EcWantsA__drv,reference_EcDcomingForCt_p___drv,reference_DdataGood_p___drv,reference_DMuxData__drv,reference_CountMiss__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv,reference_At_eq_Curt_p___drv,reference_AcanhaveMap_p___drv};
assign reference_state[0+:1]=reference.Clk1_p_Aa;
assign reference_state[1+:1]=reference.Clk1_p_Ab;
assign reference_state[2+:1]=reference.Clk1_p_Ab__lag1;
assign reference_state[3+:1]=reference.Clk1_p_Ab__lag2;
assign reference_state[4+:1]=reference.Clk1_p_Ba;
assign reference_state[5+:1]=reference.Clk1_p_Bb;
assign reference_state[6+:1]=reference.Clk1_p_Bc;
assign reference_state[7+:1]=reference.Clk1_p_Ca;
assign reference_state[8+:1]=reference.Clk1_p_Cb;
assign reference_state[9+:1]=reference.Clk1_p_Cc;
assign reference_state[10+:3]=reference.mapbuf_fh_delay;
assign reference_state[13+:1]=reference.sin_select_clock;
assign reference_state[14+:1]=reference.u_a03.ck_d;
assign reference_state[15+:4]=reference.u_a03.q;
assign reference_state[19+:6]=reference.u_a03.setup_pre;
assign reference_state[25+:1]=reference.u_a04.cas_d;
assign reference_state[26+:8]=reference.u_a04.col;
assign reference_state[34+:1]=reference.u_a04.dout;
assign reference_state[35+:1]=reference.u_a04.ras_d;
assign reference_state[36+:8]=reference.u_a04.row;
assign reference_state[44+:1]=reference.u_a04.saved_dout_r;
assign reference_state[45+:1]=reference.u_a04.we_d;
assign reference_state[46+:1]=reference.u_a04.write_data;
assign reference_state[47+:1]=reference.u_a04.write_pending;
assign reference_state[48+:1]=reference.u_a05.cas_d;
assign reference_state[49+:8]=reference.u_a05.col;
assign reference_state[57+:1]=reference.u_a05.dout;
assign reference_state[58+:1]=reference.u_a05.ras_d;
assign reference_state[59+:8]=reference.u_a05.row;
assign reference_state[67+:1]=reference.u_a05.saved_dout_r;
assign reference_state[68+:1]=reference.u_a05.we_d;
assign reference_state[69+:1]=reference.u_a05.write_data;
assign reference_state[70+:1]=reference.u_a05.write_pending;
assign reference_state[71+:1]=reference.u_a06.cas_d;
assign reference_state[72+:8]=reference.u_a06.col;
assign reference_state[80+:1]=reference.u_a06.dout;
assign reference_state[81+:1]=reference.u_a06.ras_d;
assign reference_state[82+:8]=reference.u_a06.row;
assign reference_state[90+:1]=reference.u_a06.saved_dout_r;
assign reference_state[91+:1]=reference.u_a06.we_d;
assign reference_state[92+:1]=reference.u_a06.write_data;
assign reference_state[93+:1]=reference.u_a06.write_pending;
assign reference_state[94+:1]=reference.u_a07.cas_d;
assign reference_state[95+:8]=reference.u_a07.col;
assign reference_state[103+:1]=reference.u_a07.dout;
assign reference_state[104+:1]=reference.u_a07.ras_d;
assign reference_state[105+:8]=reference.u_a07.row;
assign reference_state[113+:1]=reference.u_a07.saved_dout_r;
assign reference_state[114+:1]=reference.u_a07.we_d;
assign reference_state[115+:1]=reference.u_a07.write_data;
assign reference_state[116+:1]=reference.u_a07.write_pending;
assign reference_state[117+:1]=reference.u_a08.cas_d;
assign reference_state[118+:8]=reference.u_a08.col;
assign reference_state[126+:1]=reference.u_a08.dout;
assign reference_state[127+:1]=reference.u_a08.ras_d;
assign reference_state[128+:8]=reference.u_a08.row;
assign reference_state[136+:1]=reference.u_a08.saved_dout_r;
assign reference_state[137+:1]=reference.u_a08.we_d;
assign reference_state[138+:1]=reference.u_a08.write_data;
assign reference_state[139+:1]=reference.u_a08.write_pending;
assign reference_state[140+:1]=reference.u_a09.cas_d;
assign reference_state[141+:8]=reference.u_a09.col;
assign reference_state[149+:1]=reference.u_a09.dout;
assign reference_state[150+:1]=reference.u_a09.ras_d;
assign reference_state[151+:8]=reference.u_a09.row;
assign reference_state[159+:1]=reference.u_a09.saved_dout_r;
assign reference_state[160+:1]=reference.u_a09.we_d;
assign reference_state[161+:1]=reference.u_a09.write_data;
assign reference_state[162+:1]=reference.u_a09.write_pending;
assign reference_state[163+:1]=reference.u_a10.cas_d;
assign reference_state[164+:8]=reference.u_a10.col;
assign reference_state[172+:1]=reference.u_a10.dout;
assign reference_state[173+:1]=reference.u_a10.ras_d;
assign reference_state[174+:8]=reference.u_a10.row;
assign reference_state[182+:1]=reference.u_a10.saved_dout_r;
assign reference_state[183+:1]=reference.u_a10.we_d;
assign reference_state[184+:1]=reference.u_a10.write_data;
assign reference_state[185+:1]=reference.u_a10.write_pending;
assign reference_state[186+:1]=reference.u_a11.cas_d;
assign reference_state[187+:8]=reference.u_a11.col;
assign reference_state[195+:1]=reference.u_a11.dout;
assign reference_state[196+:1]=reference.u_a11.ras_d;
assign reference_state[197+:8]=reference.u_a11.row;
assign reference_state[205+:1]=reference.u_a11.saved_dout_r;
assign reference_state[206+:1]=reference.u_a11.we_d;
assign reference_state[207+:1]=reference.u_a11.write_data;
assign reference_state[208+:1]=reference.u_a11.write_pending;
assign reference_state[209+:1]=reference.u_a12.cas_d;
assign reference_state[210+:8]=reference.u_a12.col;
assign reference_state[218+:1]=reference.u_a12.dout;
assign reference_state[219+:1]=reference.u_a12.ras_d;
assign reference_state[220+:8]=reference.u_a12.row;
assign reference_state[228+:1]=reference.u_a12.saved_dout_r;
assign reference_state[229+:1]=reference.u_a12.we_d;
assign reference_state[230+:1]=reference.u_a12.write_data;
assign reference_state[231+:1]=reference.u_a12.write_pending;
assign reference_state[232+:1]=reference.u_a13.cas_d;
assign reference_state[233+:8]=reference.u_a13.col;
assign reference_state[241+:1]=reference.u_a13.dout;
assign reference_state[242+:1]=reference.u_a13.ras_d;
assign reference_state[243+:8]=reference.u_a13.row;
assign reference_state[251+:1]=reference.u_a13.saved_dout_r;
assign reference_state[252+:1]=reference.u_a13.we_d;
assign reference_state[253+:1]=reference.u_a13.write_data;
assign reference_state[254+:1]=reference.u_a13.write_pending;
assign reference_state[255+:1]=reference.u_a14.cas_d;
assign reference_state[256+:8]=reference.u_a14.col;
assign reference_state[264+:1]=reference.u_a14.dout;
assign reference_state[265+:1]=reference.u_a14.ras_d;
assign reference_state[266+:8]=reference.u_a14.row;
assign reference_state[274+:1]=reference.u_a14.saved_dout_r;
assign reference_state[275+:1]=reference.u_a14.we_d;
assign reference_state[276+:1]=reference.u_a14.write_data;
assign reference_state[277+:1]=reference.u_a14.write_pending;
assign reference_state[278+:1]=reference.u_a17.ck_d;
assign reference_state[279+:4]=reference.u_a17.q;
assign reference_state[283+:6]=reference.u_a17.setup_pre;
assign reference_state[289+:1]=reference.u_a18.ck_d;
assign reference_state[290+:4]=reference.u_a18.d_pre;
assign reference_state[294+:1]=reference.u_a18.dl_pre;
assign reference_state[295+:1]=reference.u_a18.dr_pre;
assign reference_state[296+:4]=reference.u_a18.q;
assign reference_state[300+:2]=reference.u_a18.s_pre;
assign reference_state[302+:1]=reference.u_a21.ck_d;
assign reference_state[303+:4]=reference.u_a21.q;
assign reference_state[307+:6]=reference.u_a21.setup_pre;
assign reference_state[313+:1]=reference.u_a23.ck_d;
assign reference_state[314+:4]=reference.u_a23.q;
assign reference_state[318+:6]=reference.u_a23.setup_pre;
assign reference_state[324+:5]=reference.u_b01.q;
assign reference_state[329+:1]=reference.u_b23.ck_d;
assign reference_state[330+:4]=reference.u_b23.d_pre;
assign reference_state[334+:1]=reference.u_b23.dl_pre;
assign reference_state[335+:1]=reference.u_b23.dr_pre;
assign reference_state[336+:4]=reference.u_b23.q;
assign reference_state[340+:2]=reference.u_b23.s_pre;
assign reference_state[342+:1]=reference.u_b24.ck_d;
assign reference_state[343+:4]=reference.u_b24.q;
assign reference_state[347+:6]=reference.u_b24.setup_pre;
assign reference_state[353+:1]=reference.u_c01.cka_d;
assign reference_state[354+:1]=reference.u_c01.ckb_d;
assign reference_state[355+:1]=reference.u_c01.d_pre_a;
assign reference_state[356+:1]=reference.u_c01.d_pre_b;
assign reference_state[357+:1]=reference.u_c01.qa;
assign reference_state[358+:1]=reference.u_c01.qb;
assign reference_state[359+:1]=reference.u_c02.ck_d;
assign reference_state[360+:6]=reference.u_c02.d_pre;
assign reference_state[366+:6]=reference.u_c02.q;
assign reference_state[372+:4]=reference.u_c21.a_lat;
assign reference_state[376+:1]=reference.u_c21.ce_lat;
assign reference_state[377+:4]=reference.u_c21.d_lat;
assign reference_state[381+:64]={reference.u_c21.mem[15],reference.u_c21.mem[14],reference.u_c21.mem[13],reference.u_c21.mem[12],reference.u_c21.mem[11],reference.u_c21.mem[10],reference.u_c21.mem[9],reference.u_c21.mem[8],reference.u_c21.mem[7],reference.u_c21.mem[6],reference.u_c21.mem[5],reference.u_c21.mem[4],reference.u_c21.mem[3],reference.u_c21.mem[2],reference.u_c21.mem[1],reference.u_c21.mem[0]};
assign reference_state[445+:1]=reference.u_c21.we_d;
assign reference_state[446+:1]=reference.u_c22.ck_d;
assign reference_state[447+:4]=reference.u_c22.q;
assign reference_state[451+:6]=reference.u_c22.setup_pre;
assign reference_state[457+:5]=reference.u_d01.q;
assign reference_state[462+:1]=reference.u_d04.cas_d;
assign reference_state[463+:8]=reference.u_d04.col;
assign reference_state[471+:1]=reference.u_d04.dout;
assign reference_state[472+:1]=reference.u_d04.ras_d;
assign reference_state[473+:8]=reference.u_d04.row;
assign reference_state[481+:1]=reference.u_d04.saved_dout_r;
assign reference_state[482+:1]=reference.u_d04.we_d;
assign reference_state[483+:1]=reference.u_d04.write_data;
assign reference_state[484+:1]=reference.u_d04.write_pending;
assign reference_state[485+:1]=reference.u_d05.cas_d;
assign reference_state[486+:8]=reference.u_d05.col;
assign reference_state[494+:1]=reference.u_d05.dout;
assign reference_state[495+:1]=reference.u_d05.ras_d;
assign reference_state[496+:8]=reference.u_d05.row;
assign reference_state[504+:1]=reference.u_d05.saved_dout_r;
assign reference_state[505+:1]=reference.u_d05.we_d;
assign reference_state[506+:1]=reference.u_d05.write_data;
assign reference_state[507+:1]=reference.u_d05.write_pending;
assign reference_state[508+:1]=reference.u_d06.cas_d;
assign reference_state[509+:8]=reference.u_d06.col;
assign reference_state[517+:1]=reference.u_d06.dout;
assign reference_state[518+:1]=reference.u_d06.ras_d;
assign reference_state[519+:8]=reference.u_d06.row;
assign reference_state[527+:1]=reference.u_d06.saved_dout_r;
assign reference_state[528+:1]=reference.u_d06.we_d;
assign reference_state[529+:1]=reference.u_d06.write_data;
assign reference_state[530+:1]=reference.u_d06.write_pending;
assign reference_state[531+:1]=reference.u_d07.cas_d;
assign reference_state[532+:8]=reference.u_d07.col;
assign reference_state[540+:1]=reference.u_d07.dout;
assign reference_state[541+:1]=reference.u_d07.ras_d;
assign reference_state[542+:8]=reference.u_d07.row;
assign reference_state[550+:1]=reference.u_d07.saved_dout_r;
assign reference_state[551+:1]=reference.u_d07.we_d;
assign reference_state[552+:1]=reference.u_d07.write_data;
assign reference_state[553+:1]=reference.u_d07.write_pending;
assign reference_state[554+:1]=reference.u_d08.cas_d;
assign reference_state[555+:8]=reference.u_d08.col;
assign reference_state[563+:1]=reference.u_d08.dout;
assign reference_state[564+:1]=reference.u_d08.ras_d;
assign reference_state[565+:8]=reference.u_d08.row;
assign reference_state[573+:1]=reference.u_d08.saved_dout_r;
assign reference_state[574+:1]=reference.u_d08.we_d;
assign reference_state[575+:1]=reference.u_d08.write_data;
assign reference_state[576+:1]=reference.u_d08.write_pending;
assign reference_state[577+:1]=reference.u_d09.cas_d;
assign reference_state[578+:8]=reference.u_d09.col;
assign reference_state[586+:1]=reference.u_d09.dout;
assign reference_state[587+:1]=reference.u_d09.ras_d;
assign reference_state[588+:8]=reference.u_d09.row;
assign reference_state[596+:1]=reference.u_d09.saved_dout_r;
assign reference_state[597+:1]=reference.u_d09.we_d;
assign reference_state[598+:1]=reference.u_d09.write_data;
assign reference_state[599+:1]=reference.u_d09.write_pending;
assign reference_state[600+:1]=reference.u_d10.cas_d;
assign reference_state[601+:8]=reference.u_d10.col;
assign reference_state[609+:1]=reference.u_d10.dout;
assign reference_state[610+:1]=reference.u_d10.ras_d;
assign reference_state[611+:8]=reference.u_d10.row;
assign reference_state[619+:1]=reference.u_d10.saved_dout_r;
assign reference_state[620+:1]=reference.u_d10.we_d;
assign reference_state[621+:1]=reference.u_d10.write_data;
assign reference_state[622+:1]=reference.u_d10.write_pending;
assign reference_state[623+:1]=reference.u_d11.cas_d;
assign reference_state[624+:8]=reference.u_d11.col;
assign reference_state[632+:1]=reference.u_d11.dout;
assign reference_state[633+:1]=reference.u_d11.ras_d;
assign reference_state[634+:8]=reference.u_d11.row;
assign reference_state[642+:1]=reference.u_d11.saved_dout_r;
assign reference_state[643+:1]=reference.u_d11.we_d;
assign reference_state[644+:1]=reference.u_d11.write_data;
assign reference_state[645+:1]=reference.u_d11.write_pending;
assign reference_state[646+:1]=reference.u_d12.cas_d;
assign reference_state[647+:8]=reference.u_d12.col;
assign reference_state[655+:1]=reference.u_d12.dout;
assign reference_state[656+:1]=reference.u_d12.ras_d;
assign reference_state[657+:8]=reference.u_d12.row;
assign reference_state[665+:1]=reference.u_d12.saved_dout_r;
assign reference_state[666+:1]=reference.u_d12.we_d;
assign reference_state[667+:1]=reference.u_d12.write_data;
assign reference_state[668+:1]=reference.u_d12.write_pending;
assign reference_state[669+:1]=reference.u_d13.cas_d;
assign reference_state[670+:8]=reference.u_d13.col;
assign reference_state[678+:1]=reference.u_d13.dout;
assign reference_state[679+:1]=reference.u_d13.ras_d;
assign reference_state[680+:8]=reference.u_d13.row;
assign reference_state[688+:1]=reference.u_d13.saved_dout_r;
assign reference_state[689+:1]=reference.u_d13.we_d;
assign reference_state[690+:1]=reference.u_d13.write_data;
assign reference_state[691+:1]=reference.u_d13.write_pending;
assign reference_state[692+:1]=reference.u_d18.ck_d;
assign reference_state[693+:6]=reference.u_d18.d_pre;
assign reference_state[699+:6]=reference.u_d18.q;
assign reference_state[705+:1]=reference.u_d22.ck_d;
assign reference_state[706+:4]=reference.u_d22.d_pre;
assign reference_state[710+:1]=reference.u_d22.dl_pre;
assign reference_state[711+:1]=reference.u_d22.dr_pre;
assign reference_state[712+:4]=reference.u_d22.q;
assign reference_state[716+:2]=reference.u_d22.s_pre;
assign reference_state[718+:4]=reference.u_e16.a_lat;
assign reference_state[722+:1]=reference.u_e16.ce_lat;
assign reference_state[723+:4]=reference.u_e16.d_lat;
assign reference_state[727+:64]={reference.u_e16.mem[15],reference.u_e16.mem[14],reference.u_e16.mem[13],reference.u_e16.mem[12],reference.u_e16.mem[11],reference.u_e16.mem[10],reference.u_e16.mem[9],reference.u_e16.mem[8],reference.u_e16.mem[7],reference.u_e16.mem[6],reference.u_e16.mem[5],reference.u_e16.mem[4],reference.u_e16.mem[3],reference.u_e16.mem[2],reference.u_e16.mem[1],reference.u_e16.mem[0]};
assign reference_state[791+:1]=reference.u_e16.we_d;
assign reference_state[792+:1]=reference.u_e18.ck_d;
assign reference_state[793+:4]=reference.u_e18.q;
assign reference_state[797+:6]=reference.u_e18.setup_pre;
assign reference_state[803+:1]=reference.u_e19.ck_d;
assign reference_state[804+:6]=reference.u_e19.d_pre;
assign reference_state[810+:6]=reference.u_e19.q;
assign reference_state[816+:4]=reference.u_e20.a_lat;
assign reference_state[820+:1]=reference.u_e20.ce_lat;
assign reference_state[821+:4]=reference.u_e20.d_lat;
assign reference_state[825+:64]={reference.u_e20.mem[15],reference.u_e20.mem[14],reference.u_e20.mem[13],reference.u_e20.mem[12],reference.u_e20.mem[11],reference.u_e20.mem[10],reference.u_e20.mem[9],reference.u_e20.mem[8],reference.u_e20.mem[7],reference.u_e20.mem[6],reference.u_e20.mem[5],reference.u_e20.mem[4],reference.u_e20.mem[3],reference.u_e20.mem[2],reference.u_e20.mem[1],reference.u_e20.mem[0]};
assign reference_state[889+:1]=reference.u_e20.we_d;
assign reference_state[890+:4]=reference.u_e21.a_lat;
assign reference_state[894+:1]=reference.u_e21.ce_lat;
assign reference_state[895+:4]=reference.u_e21.d_lat;
assign reference_state[899+:64]={reference.u_e21.mem[15],reference.u_e21.mem[14],reference.u_e21.mem[13],reference.u_e21.mem[12],reference.u_e21.mem[11],reference.u_e21.mem[10],reference.u_e21.mem[9],reference.u_e21.mem[8],reference.u_e21.mem[7],reference.u_e21.mem[6],reference.u_e21.mem[5],reference.u_e21.mem[4],reference.u_e21.mem[3],reference.u_e21.mem[2],reference.u_e21.mem[1],reference.u_e21.mem[0]};
assign reference_state[963+:1]=reference.u_e21.we_d;
assign reference_state[964+:1]=reference.u_e22.ck_d;
assign reference_state[965+:4]=reference.u_e22.q;
assign reference_state[969+:6]=reference.u_e22.setup_pre;
assign reference_state[975+:1]=reference.u_e23.ck_d;
assign reference_state[976+:6]=reference.u_e23.d_pre;
assign reference_state[982+:6]=reference.u_e23.q;
assign reference_state[988+:1]=reference.u_e24.cka_d;
assign reference_state[989+:1]=reference.u_e24.ckb_d;
assign reference_state[990+:1]=reference.u_e24.d_pre_a;
assign reference_state[991+:1]=reference.u_e24.d_pre_b;
assign reference_state[992+:1]=reference.u_e24.qa;
assign reference_state[993+:1]=reference.u_e24.qb;
assign reference_state[994+:5]=reference.u_f01.q;
assign reference_state[999+:1]=reference.u_f03.ck_d;
assign reference_state[1000+:4]=reference.u_f03.q;
assign reference_state[1004+:6]=reference.u_f03.setup_pre;
assign reference_state[1010+:1]=reference.u_f04.ck_d;
assign reference_state[1011+:4]=reference.u_f04.q;
assign reference_state[1015+:6]=reference.u_f04.setup_pre;
assign reference_state[1021+:4]=reference.u_f13.a_lat;
assign reference_state[1025+:1]=reference.u_f13.ce_lat;
assign reference_state[1026+:4]=reference.u_f13.d_lat;
assign reference_state[1030+:64]={reference.u_f13.mem[15],reference.u_f13.mem[14],reference.u_f13.mem[13],reference.u_f13.mem[12],reference.u_f13.mem[11],reference.u_f13.mem[10],reference.u_f13.mem[9],reference.u_f13.mem[8],reference.u_f13.mem[7],reference.u_f13.mem[6],reference.u_f13.mem[5],reference.u_f13.mem[4],reference.u_f13.mem[3],reference.u_f13.mem[2],reference.u_f13.mem[1],reference.u_f13.mem[0]};
assign reference_state[1094+:1]=reference.u_f13.we_d;
assign reference_state[1095+:4]=reference.u_f14.a_lat;
assign reference_state[1099+:1]=reference.u_f14.ce_lat;
assign reference_state[1100+:4]=reference.u_f14.d_lat;
assign reference_state[1104+:64]={reference.u_f14.mem[15],reference.u_f14.mem[14],reference.u_f14.mem[13],reference.u_f14.mem[12],reference.u_f14.mem[11],reference.u_f14.mem[10],reference.u_f14.mem[9],reference.u_f14.mem[8],reference.u_f14.mem[7],reference.u_f14.mem[6],reference.u_f14.mem[5],reference.u_f14.mem[4],reference.u_f14.mem[3],reference.u_f14.mem[2],reference.u_f14.mem[1],reference.u_f14.mem[0]};
assign reference_state[1168+:1]=reference.u_f14.we_d;
assign reference_state[1169+:4]=reference.u_f15.a_lat;
assign reference_state[1173+:1]=reference.u_f15.ce_lat;
assign reference_state[1174+:4]=reference.u_f15.d_lat;
assign reference_state[1178+:64]={reference.u_f15.mem[15],reference.u_f15.mem[14],reference.u_f15.mem[13],reference.u_f15.mem[12],reference.u_f15.mem[11],reference.u_f15.mem[10],reference.u_f15.mem[9],reference.u_f15.mem[8],reference.u_f15.mem[7],reference.u_f15.mem[6],reference.u_f15.mem[5],reference.u_f15.mem[4],reference.u_f15.mem[3],reference.u_f15.mem[2],reference.u_f15.mem[1],reference.u_f15.mem[0]};
assign reference_state[1242+:1]=reference.u_f15.we_d;
assign reference_state[1243+:4]=reference.u_f16.a_lat;
assign reference_state[1247+:1]=reference.u_f16.ce_lat;
assign reference_state[1248+:4]=reference.u_f16.d_lat;
assign reference_state[1252+:64]={reference.u_f16.mem[15],reference.u_f16.mem[14],reference.u_f16.mem[13],reference.u_f16.mem[12],reference.u_f16.mem[11],reference.u_f16.mem[10],reference.u_f16.mem[9],reference.u_f16.mem[8],reference.u_f16.mem[7],reference.u_f16.mem[6],reference.u_f16.mem[5],reference.u_f16.mem[4],reference.u_f16.mem[3],reference.u_f16.mem[2],reference.u_f16.mem[1],reference.u_f16.mem[0]};
assign reference_state[1316+:1]=reference.u_f16.we_d;
assign reference_state[1317+:4]=reference.u_f17.a_lat;
assign reference_state[1321+:1]=reference.u_f17.ce_lat;
assign reference_state[1322+:4]=reference.u_f17.d_lat;
assign reference_state[1326+:64]={reference.u_f17.mem[15],reference.u_f17.mem[14],reference.u_f17.mem[13],reference.u_f17.mem[12],reference.u_f17.mem[11],reference.u_f17.mem[10],reference.u_f17.mem[9],reference.u_f17.mem[8],reference.u_f17.mem[7],reference.u_f17.mem[6],reference.u_f17.mem[5],reference.u_f17.mem[4],reference.u_f17.mem[3],reference.u_f17.mem[2],reference.u_f17.mem[1],reference.u_f17.mem[0]};
assign reference_state[1390+:1]=reference.u_f17.we_d;
assign reference_state[1391+:1]=reference.u_f18.ck_d;
assign reference_state[1392+:4]=reference.u_f18.q;
assign reference_state[1396+:6]=reference.u_f18.setup_pre;
assign reference_state[1402+:1]=reference.u_f19.ck_d;
assign reference_state[1403+:4]=reference.u_f19.q;
assign reference_state[1407+:6]=reference.u_f19.setup_pre;
assign reference_state[1413+:4]=reference.u_f21.a_lat;
assign reference_state[1417+:1]=reference.u_f21.ce_lat;
assign reference_state[1418+:4]=reference.u_f21.d_lat;
assign reference_state[1422+:64]={reference.u_f21.mem[15],reference.u_f21.mem[14],reference.u_f21.mem[13],reference.u_f21.mem[12],reference.u_f21.mem[11],reference.u_f21.mem[10],reference.u_f21.mem[9],reference.u_f21.mem[8],reference.u_f21.mem[7],reference.u_f21.mem[6],reference.u_f21.mem[5],reference.u_f21.mem[4],reference.u_f21.mem[3],reference.u_f21.mem[2],reference.u_f21.mem[1],reference.u_f21.mem[0]};
assign reference_state[1486+:1]=reference.u_f21.we_d;
assign reference_state[1487+:5]=reference.u_g01.q;
assign reference_state[1492+:1]=reference.u_g05.ck_d;
assign reference_state[1493+:4]=reference.u_g05.q;
assign reference_state[1497+:6]=reference.u_g05.setup_pre;
assign reference_state[1503+:1]=reference.u_g06.ck_d;
assign reference_state[1504+:4]=reference.u_g06.q;
assign reference_state[1508+:6]=reference.u_g06.setup_pre;
assign reference_state[1514+:1]=reference.u_g07.ck_d;
assign reference_state[1515+:4]=reference.u_g07.q;
assign reference_state[1519+:6]=reference.u_g07.setup_pre;
assign reference_state[1525+:4]=reference.u_g18.q;
assign reference_state[1529+:4]=reference.u_g19.q;
assign reference_state[1533+:1]=reference.u_g23.ck_d;
assign reference_state[1534+:6]=reference.u_g23.d_pre;
assign reference_state[1540+:6]=reference.u_g23.q;
assign reference_state[1546+:1]=reference.u_h05.ck_d;
assign reference_state[1547+:4]=reference.u_h05.d_pre;
assign reference_state[1551+:1]=reference.u_h05.dl_pre;
assign reference_state[1552+:1]=reference.u_h05.dr_pre;
assign reference_state[1553+:4]=reference.u_h05.q;
assign reference_state[1557+:2]=reference.u_h05.s_pre;
assign reference_state[1559+:1]=reference.u_h06.ck_d;
assign reference_state[1560+:4]=reference.u_h06.d_pre;
assign reference_state[1564+:1]=reference.u_h06.dl_pre;
assign reference_state[1565+:1]=reference.u_h06.dr_pre;
assign reference_state[1566+:4]=reference.u_h06.q;
assign reference_state[1570+:2]=reference.u_h06.s_pre;
assign reference_state[1572+:1]=reference.u_h08.ck_d;
assign reference_state[1573+:4]=reference.u_h08.d_pre;
assign reference_state[1577+:4]=reference.u_h08.q;
assign reference_state[1581+:1]=reference.u_h09.ck_d;
assign reference_state[1582+:4]=reference.u_h09.d_pre;
assign reference_state[1586+:1]=reference.u_h09.dl_pre;
assign reference_state[1587+:1]=reference.u_h09.dr_pre;
assign reference_state[1588+:4]=reference.u_h09.q;
assign reference_state[1592+:2]=reference.u_h09.s_pre;
assign reference_state[1594+:1]=reference.u_h12.ck_d;
assign reference_state[1595+:4]=reference.u_h12.q;
assign reference_state[1599+:6]=reference.u_h12.setup_pre;
assign reference_state[1605+:1]=reference.u_h14.ck_d;
assign reference_state[1606+:6]=reference.u_h14.d_pre;
assign reference_state[1612+:6]=reference.u_h14.q;
assign reference_state[1618+:1]=reference.u_h15.ck_d;
assign reference_state[1619+:4]=reference.u_h15.q;
assign reference_state[1623+:6]=reference.u_h15.setup_pre;
assign reference_state[1629+:1]=reference.u_h18.ck_d;
assign reference_state[1630+:4]=reference.u_h18.d_pre;
assign reference_state[1634+:1]=reference.u_h18.dl_pre;
assign reference_state[1635+:1]=reference.u_h18.dr_pre;
assign reference_state[1636+:4]=reference.u_h18.q;
assign reference_state[1640+:2]=reference.u_h18.s_pre;
assign reference_state[1642+:1]=reference.u_h22.ck_d;
assign reference_state[1643+:4]=reference.u_h22.d_pre;
assign reference_state[1647+:1]=reference.u_h22.dl_pre;
assign reference_state[1648+:1]=reference.u_h22.dr_pre;
assign reference_state[1649+:4]=reference.u_h22.q;
assign reference_state[1653+:2]=reference.u_h22.s_pre;
assign reference_state[1655+:1]=reference.u_h24.ck_d;
assign reference_state[1656+:4]=reference.u_h24.d_pre;
assign reference_state[1660+:1]=reference.u_h24.dl_pre;
assign reference_state[1661+:1]=reference.u_h24.dr_pre;
assign reference_state[1662+:4]=reference.u_h24.q;
assign reference_state[1666+:2]=reference.u_h24.s_pre;
assign reference_state[1668+:1]=reference.u_i03.ck_d;
assign reference_state[1669+:6]=reference.u_i03.d_pre;
assign reference_state[1675+:6]=reference.u_i03.q;
assign reference_state[1681+:1]=reference.u_i05.ck_d;
assign reference_state[1682+:6]=reference.u_i05.d_pre;
assign reference_state[1688+:6]=reference.u_i05.q;
assign reference_state[1694+:1]=reference.u_i09.ck_d;
assign reference_state[1695+:4]=reference.u_i09.d_pre;
assign reference_state[1699+:1]=reference.u_i09.dl_pre;
assign reference_state[1700+:1]=reference.u_i09.dr_pre;
assign reference_state[1701+:4]=reference.u_i09.q;
assign reference_state[1705+:2]=reference.u_i09.s_pre;
assign reference_state[1707+:1]=reference.u_i10.ck_d;
assign reference_state[1708+:4]=reference.u_i10.q;
assign reference_state[1712+:6]=reference.u_i10.setup_pre;
assign reference_state[1718+:1]=reference.u_i15.ck_d;
assign reference_state[1719+:6]=reference.u_i15.d_pre;
assign reference_state[1725+:6]=reference.u_i15.q;
assign reference_state[1731+:1]=reference.u_i22.ck_d;
assign reference_state[1732+:6]=reference.u_i22.d_pre;
assign reference_state[1738+:6]=reference.u_i22.q;
assign reference_state[1744+:1]=reference.u_j01.ck_d;
assign reference_state[1745+:4]=reference.u_j01.q;
assign reference_state[1749+:6]=reference.u_j01.setup_pre;
assign reference_state[1755+:1]=reference.u_j03.ck_d;
assign reference_state[1756+:6]=reference.u_j03.d_pre;
assign reference_state[1762+:6]=reference.u_j03.q;
assign reference_state[1768+:1]=reference.u_j08.ck_d;
assign reference_state[1769+:4]=reference.u_j08.jk_pre;
assign reference_state[1773+:1]=reference.u_j08.qa;
assign reference_state[1774+:1]=reference.u_j08.qb;
assign reference_state[1775+:1]=reference.u_j11.ck_d;
assign reference_state[1776+:6]=reference.u_j11.d_pre;
assign reference_state[1782+:6]=reference.u_j11.q;
assign reference_state[1788+:1]=reference.u_j12.ck_d;
assign reference_state[1789+:4]=reference.u_j12.q;
assign reference_state[1793+:6]=reference.u_j12.setup_pre;
assign reference_state[1799+:1]=reference.u_j16.ck_d;
assign reference_state[1800+:4]=reference.u_j16.q;
assign reference_state[1804+:6]=reference.u_j16.setup_pre;
assign reference_state[1810+:1]=reference.u_j20.ck_d;
assign reference_state[1811+:6]=reference.u_j20.d_pre;
assign reference_state[1817+:6]=reference.u_j20.q;
assign reference_state[1823+:1]=reference.u_j21.ck_d;
assign reference_state[1824+:4]=reference.u_j21.q;
assign reference_state[1828+:6]=reference.u_j21.setup_pre;
assign reference_state[1834+:1]=reference.u_j22.ck_d;
assign reference_state[1835+:4]=reference.u_j22.q;
assign reference_state[1839+:6]=reference.u_j22.setup_pre;
assign reference_state[1845+:1]=reference.u_j24.ck_d;
assign reference_state[1846+:6]=reference.u_j24.d_pre;
assign reference_state[1852+:6]=reference.u_j24.q;
assign reference_state[1858+:1]=reference.u_k01.ck_d;
assign reference_state[1859+:4]=reference.u_k01.q;
assign reference_state[1863+:6]=reference.u_k01.setup_pre;
assign reference_state[1869+:1]=reference.u_k02.ck_d;
assign reference_state[1870+:4]=reference.u_k02.q;
assign reference_state[1874+:6]=reference.u_k02.setup_pre;
assign reference_state[1880+:1]=reference.u_k05.ck_d;
assign reference_state[1881+:4]=reference.u_k05.q;
assign reference_state[1885+:6]=reference.u_k05.setup_pre;
assign reference_state[1891+:1]=reference.u_k09.ck_d;
assign reference_state[1892+:4]=reference.u_k09.q;
assign reference_state[1896+:6]=reference.u_k09.setup_pre;
assign reference_state[1902+:1]=reference.u_k13.ck_d;
assign reference_state[1903+:6]=reference.u_k13.d_pre;
assign reference_state[1909+:6]=reference.u_k13.q;
assign reference_state[1915+:1]=reference.u_k14.ck_d;
assign reference_state[1916+:6]=reference.u_k14.d_pre;
assign reference_state[1922+:6]=reference.u_k14.q;
assign reference_state[1928+:1]=reference.u_k17.ck_d;
assign reference_state[1929+:4]=reference.u_k17.q;
assign reference_state[1933+:6]=reference.u_k17.setup_pre;
assign reference_state[1939+:1]=reference.u_k20.ck_d;
assign reference_state[1940+:6]=reference.u_k20.d_pre;
assign reference_state[1946+:6]=reference.u_k20.q;
assign reference_state[1952+:1]=reference.u_k21.ck_d;
assign reference_state[1953+:4]=reference.u_k21.q;
assign reference_state[1957+:6]=reference.u_k21.setup_pre;
assign reference_state[1963+:1]=reference.u_l02.cka_d;
assign reference_state[1964+:1]=reference.u_l02.ckb_d;
assign reference_state[1965+:1]=reference.u_l02.d_pre_a;
assign reference_state[1966+:1]=reference.u_l02.d_pre_b;
assign reference_state[1967+:1]=reference.u_l02.qa;
assign reference_state[1968+:1]=reference.u_l02.qb;
assign reference_state[1969+:1]=reference.u_l03.ck_d;
assign reference_state[1970+:6]=reference.u_l03.d_pre;
assign reference_state[1976+:6]=reference.u_l03.q;
assign reference_state[1982+:1]=reference.u_l07.ck_d;
assign reference_state[1983+:6]=reference.u_l07.d_pre;
assign reference_state[1989+:6]=reference.u_l07.q;
assign reference_state[1995+:1]=reference.u_l10.ck_d;
assign reference_state[1996+:4]=reference.u_l10.q;
assign reference_state[2000+:6]=reference.u_l10.setup_pre;
assign reference_state[2006+:1]=reference.u_l16.ck_d;
assign reference_state[2007+:4]=reference.u_l16.q;
assign reference_state[2011+:6]=reference.u_l16.setup_pre;
assign reference_state[2017+:1]=reference.u_l19.ck_d;
assign reference_state[2018+:6]=reference.u_l19.d_pre;
assign reference_state[2024+:6]=reference.u_l19.q;
assign reference_state[2030+:1]=reference.u_l21.ck_d;
assign reference_state[2031+:6]=reference.u_l21.d_pre;
assign reference_state[2037+:6]=reference.u_l21.q;
assign reference_state[2043+:1]=reference.u_l23.ck_d;
assign reference_state[2044+:6]=reference.u_l23.d_pre;
assign reference_state[2050+:6]=reference.u_l23.q;
assign reference_probe[0+:1]=reference.u_a04.mem[0+(probe_index%65536)];
assign reference_probe[1+:1]=reference.u_a05.mem[0+(probe_index%65536)];
assign reference_probe[2+:1]=reference.u_a06.mem[0+(probe_index%65536)];
assign reference_probe[3+:1]=reference.u_a07.mem[0+(probe_index%65536)];
assign reference_probe[4+:1]=reference.u_a08.mem[0+(probe_index%65536)];
assign reference_probe[5+:1]=reference.u_a09.mem[0+(probe_index%65536)];
assign reference_probe[6+:1]=reference.u_a10.mem[0+(probe_index%65536)];
assign reference_probe[7+:1]=reference.u_a11.mem[0+(probe_index%65536)];
assign reference_probe[8+:1]=reference.u_a12.mem[0+(probe_index%65536)];
assign reference_probe[9+:1]=reference.u_a13.mem[0+(probe_index%65536)];
assign reference_probe[10+:1]=reference.u_a14.mem[0+(probe_index%65536)];
assign reference_probe[11+:1]=reference.u_d04.mem[0+(probe_index%65536)];
assign reference_probe[12+:1]=reference.u_d05.mem[0+(probe_index%65536)];
assign reference_probe[13+:1]=reference.u_d06.mem[0+(probe_index%65536)];
assign reference_probe[14+:1]=reference.u_d07.mem[0+(probe_index%65536)];
assign reference_probe[15+:1]=reference.u_d08.mem[0+(probe_index%65536)];
assign reference_probe[16+:1]=reference.u_d09.mem[0+(probe_index%65536)];
assign reference_probe[17+:1]=reference.u_d10.mem[0+(probe_index%65536)];
assign reference_probe[18+:1]=reference.u_d11.mem[0+(probe_index%65536)];
assign reference_probe[19+:1]=reference.u_d12.mem[0+(probe_index%65536)];
assign reference_probe[20+:1]=reference.u_d13.mem[0+(probe_index%65536)];
wire dut_AcanhaveMap_p___drv;
wire dut_At_eq_Curt_p___drv;
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_CountMiss__drv;
wire dut_DMuxData__drv;
wire dut_DdataGood_p___drv;
wire dut_EcDcomingForCt_p___drv;
wire dut_EcWantsA__drv;
wire dut_EmuOrFT_p___drv;
wire dut_ErrorsFromEc2__drv;
wire dut_FinNext__drv;
wire dut_FinSubtask_0__drv;
wire dut_FinSubtask_1__drv;
wire dut_FinTask_0__drv;
wire dut_FinTask_1__drv;
wire dut_FinTask_2__drv;
wire dut_FinTask_3__drv;
wire dut_Fout_flt__drv;
wire dut_FoutNext__drv;
wire dut_FoutSubTask_0__drv;
wire dut_FoutSubtask_1__drv;
wire dut_FoutTask_0__drv;
wire dut_FoutTask_1__drv;
wire dut_FoutTask_2__drv;
wire dut_FoutTask_3__drv;
wire dut_HoldMapBuf__drv;
wire dut_IfuFaultInEc2__drv;
wire dut_LargeHold__drv;
wire dut_LdPipeVAdly_p___drv;
wire dut_LoadEcOut_p___drv;
wire dut_LoadSinE__drv;
wire dut_LoadSinO__drv;
wire dut_LoadSoutE_p___drv;
wire dut_LoadSoutO_p___drv;
wire dut_MDMtag_p___drv;
wire dut_MakeD_u_CD__drv;
wire dut_MakeD_u_Dbuf__drv;
wire dut_MakeF_u_D__drv;
wire dut_MakeFout_u_D__drv;
wire dut_MakeMDM_u_D_p___drv;
wire dut_MakeMD_u_D_p___drv;
wire dut_MakeSout_u_D__drv;
wire dut_MapRfsh_p___drv;
wire dut_MapTroubleInEc1__drv;
wire dut_MapWait_m_D__drv;
wire dut_MemAd_0__drv;
wire dut_MemAd_1__drv;
wire dut_MemAd_2__drv;
wire dut_MemAd_3__drv;
wire dut_MemAd_4__drv;
wire dut_MemAd_5__drv;
wire dut_MemAd_6__drv;
wire dut_MemAd_7__drv;
wire dut_MemAd_8__drv;
wire dut_MemCASa__drv;
wire dut_MemCASb__drv;
wire dut_MemError__drv;
wire dut_MemPE__drv;
wire dut_MemRASa__drv;
wire dut_MemRASb__drv;
wire dut_MemRfsh__drv;
wire dut_MemWEa__drv;
wire dut_MemWEb__drv;
wire dut_Mod0SinEn_p___drv;
wire dut_Mod0StrEn_p___drv;
wire dut_Mod1SinEn_p___drv;
wire dut_Mod1StrEn_p___drv;
wire dut_Mod2SinEn_p___drv;
wire dut_Mod2StrEn_p___drv;
wire dut_Mod3SinEn_p___drv;
wire dut_Mod3StrEn_p___drv;
wire dut_ProcTag__drv;
wire dut_ProcTagInA__drv;
wire dut_STfree_p___drv;
wire dut_ShiftEcOut__drv;
wire dut_ShiftSinE__drv;
wire dut_ShiftSinO__drv;
wire dut_ShiftSoutE__drv;
wire dut_ShiftSoutO__drv;
wire dut_StartEcChk_p___drv;
wire dut_StartEcGen_p___drv;
wire dut_TWReq_15__drv;
wire dut_Transport_p___drv;
wire dut_WPinEc1__drv;
wire dut_XWantsPipe__drv;
wire dut_dMDMad_0_p___drv;
wire dut_dMDMad_1_p___drv;
wire dut_dMDMad_2_p___drv;
wire dut_dMDMad_3_p___drv;
wire dut_dPipe02Ad_0__drv;
wire dut_dPipe02Ad_1__drv;
wire dut_dPipe02Ad_2__drv;
wire dut_dPipe02Ad_3__drv;
wire dut_dPipe34Ad_0__drv;
wire dut_dPipe34Ad_1__drv;
wire dut_dPipe34Ad_2__drv;
wire dut_dPipe34Ad_3__drv;
wire dut_preMCSb__drv;
dorado_serial_MemX #(.SYSPER(4)) dut(
.sys_clk(clk),
.AfreeOrEc_p_b(stimulus[0]),
.At_eq_Curt_p_(stimulus[1] | dut_At_eq_Curt_p___drv),
.AwantsDifHit_p_(stimulus[2]),
.BMux_00(stimulus[3] | dut_BMux_00__drv),
.BMux_01(stimulus[4] | dut_BMux_01__drv),
.BMux_02(stimulus[5] | dut_BMux_02__drv),
.BMux_03(stimulus[6] | dut_BMux_03__drv),
.BMux_04(stimulus[7] | dut_BMux_04__drv),
.BMux_05(stimulus[8] | dut_BMux_05__drv),
.BMux_06(stimulus[9] | dut_BMux_06__drv),
.BMux_07(stimulus[10] | dut_BMux_07__drv),
.BMux_08(stimulus[11] | dut_BMux_08__drv),
.BMux_09(stimulus[12] | dut_BMux_09__drv),
.BMux_10(stimulus[13] | dut_BMux_10__drv),
.BMux_11(stimulus[14] | dut_BMux_11__drv),
.BMux_12(stimulus[15] | dut_BMux_12__drv),
.BMux_13(stimulus[16] | dut_BMux_13__drv),
.BMux_14(stimulus[17] | dut_BMux_14__drv),
.BMux_15(stimulus[18] | dut_BMux_15__drv),
.BMux_16(stimulus[19]),
.BMux_17(stimulus[20]),
.BNTGtCT_p_a(stimulus[21]),
.CLK_mx_p_(stimulus[22]),
.CacheRef_p_(stimulus[23]),
.CacheRefInEc1(stimulus[24]),
.ChipsAre256_s_16K(stimulus[25]),
.ChipsAre64K(stimulus[26]),
.ClkEnable_p_a(stimulus[27]),
.CountMiss(stimulus[28] | dut_CountMiss__drv),
.DMuxClk(stimulus[29]),
.DMuxData(stimulus[30] | dut_DMuxData__drv),
.DdataGood_p_(stimulus[31] | dut_DdataGood_p___drv),
.DirtyIoFetchInA_p_(stimulus[32]),
.DisHold(stimulus[33]),
.ECFault(stimulus[34]),
.EcDcomingForCt_p_(stimulus[35] | dut_EcDcomingForCt_p___drv),
.EcKeepsAbusy(stimulus[36]),
.EcWantsA(stimulus[37] | dut_EcWantsA__drv),
.ErrorsFromEc2(stimulus[38] | dut_ErrorsFromEc2__drv),
.FinNext(stimulus[39] | dut_FinNext__drv),
.FoutNext(stimulus[40] | dut_FoutNext__drv),
.Hita(stimulus[41]),
.HoldMapBuf(stimulus[42] | dut_HoldMapBuf__drv),
.IfuRefInEc1(stimulus[43]),
.IoFetchInA_p_(stimulus[44]),
.IoStoreInA(stimulus[45]),
.LoadSinE(stimulus[46] | dut_LoadSinE__drv),
.LoadSinO(stimulus[47] | dut_LoadSinO__drv),
.M0(stimulus[48]),
.M1(stimulus[49]),
.M2(stimulus[50]),
.M3(stimulus[51]),
.MDMtag_p_(stimulus[52] | dut_MDMtag_p___drv),
.MXHold(stimulus[53]),
.MakeD_u_CD(stimulus[54] | dut_MakeD_u_CD__drv),
.MakeD_u_Dbuf(stimulus[55] | dut_MakeD_u_Dbuf__drv),
.MakeF_u_D(stimulus[56] | dut_MakeF_u_D__drv),
.MakeFout_u_D(stimulus[57] | dut_MakeFout_u_D__drv),
.MakeMDM_u_D_p_(stimulus[58] | dut_MakeMDM_u_D_p___drv),
.MakeSout_u_D(stimulus[59] | dut_MakeSout_u_D__drv),
.MapAd_0(stimulus[60]),
.MapAd_1(stimulus[61]),
.MapAd_2(stimulus[62]),
.MapAd_3(stimulus[63]),
.MapAd_4(stimulus[64]),
.MapAd_5(stimulus[65]),
.MapAd_6(stimulus[66]),
.MapAd_7(stimulus[67]),
.MapAd_8(stimulus[68]),
.MapRfsh_p_(stimulus[69] | dut_MapRfsh_p___drv),
.MapTroubleInEc1(stimulus[70] | dut_MapTroubleInEc1__drv),
.MapWait_m_D(stimulus[71] | dut_MapWait_m_D__drv),
.Map_u_InPair_p_(stimulus[72]),
.Mcr_u__p_(stimulus[73]),
.MemClkEnable_p_c(stimulus[74]),
.MemError(stimulus[75] | dut_MemError__drv),
.MemPE(stimulus[76] | dut_MemPE__drv),
.MemRfsh(stimulus[77] | dut_MemRfsh__drv),
.MemSH(stimulus[78]),
.Next_0(stimulus[79]),
.Next_1(stimulus[80]),
.Next_2(stimulus[81]),
.Next_3(stimulus[82]),
.PairFull_p_(stimulus[83]),
.PrivRefInPair(stimulus[84]),
.ProcSrn_u__p_(stimulus[85]),
.ProcTag(stimulus[86] | dut_ProcTag__drv),
.ProcTagInA(stimulus[87] | dut_ProcTagInA__drv),
.ReadInA_p_(stimulus[88]),
.RfshPeriod(stimulus[89]),
.STfree_p_(stimulus[90] | dut_STfree_p___drv),
.SW(stimulus[91]),
.StartMap_p_(stimulus[92]),
.StkError(stimulus[93]),
.Store_u_InA_p_(stimulus[94]),
.Store_u_InEc1_p_(stimulus[95]),
.SubTask_0(stimulus[96]),
.SubTask_1(stimulus[97]),
.TIOA_0(stimulus[98]),
.TIOA_1(stimulus[99]),
.TagInEc1(stimulus[100]),
.UseAsrn(stimulus[101]),
.VicIfMiss_p_(stimulus[102]),
.VicInPair_p_(stimulus[103]),
.VicOrFS1C(stimulus[104]),
.WPinEc1(stimulus[105] | dut_WPinEc1__drv),
._u_Config(stimulus[106]),
._u_FaultInfo(stimulus[107]),
._u_MD(stimulus[108]),
._u_MDdly_p_(stimulus[109]),
._u_Map(stimulus[110]),
._u_Pipe2(stimulus[111]),
._u_Pipe3(stimulus[112]),
._u_Pipe4(stimulus[113]),
.dHitPerr(stimulus[114]),
.dPipe02Ad_0(stimulus[115] | dut_dPipe02Ad_0__drv),
.dPipe02Ad_1(stimulus[116] | dut_dPipe02Ad_1__drv),
.dPipe02Ad_2(stimulus[117] | dut_dPipe02Ad_2__drv),
.dPipe02Ad_3(stimulus[118] | dut_dPipe02Ad_3__drv),
.dPipe34Ad_0(stimulus[119] | dut_dPipe34Ad_0__drv),
.dPipe34Ad_1(stimulus[120] | dut_dPipe34Ad_1__drv),
.dPipe34Ad_2(stimulus[121] | dut_dPipe34Ad_2__drv),
.dPipe34Ad_3(stimulus[122] | dut_dPipe34Ad_3__drv),
.dSTPerr(stimulus[123]),
.AcanhaveMap_p___drv(dut_AcanhaveMap_p___drv),
.At_eq_Curt_p___drv(dut_At_eq_Curt_p___drv),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.CountMiss__drv(dut_CountMiss__drv),
.DMuxData__drv(dut_DMuxData__drv),
.DdataGood_p___drv(dut_DdataGood_p___drv),
.EcDcomingForCt_p___drv(dut_EcDcomingForCt_p___drv),
.EcWantsA__drv(dut_EcWantsA__drv),
.EmuOrFT_p___drv(dut_EmuOrFT_p___drv),
.ErrorsFromEc2__drv(dut_ErrorsFromEc2__drv),
.FinNext__drv(dut_FinNext__drv),
.FinSubtask_0__drv(dut_FinSubtask_0__drv),
.FinSubtask_1__drv(dut_FinSubtask_1__drv),
.FinTask_0__drv(dut_FinTask_0__drv),
.FinTask_1__drv(dut_FinTask_1__drv),
.FinTask_2__drv(dut_FinTask_2__drv),
.FinTask_3__drv(dut_FinTask_3__drv),
.Fout_flt__drv(dut_Fout_flt__drv),
.FoutNext__drv(dut_FoutNext__drv),
.FoutSubTask_0__drv(dut_FoutSubTask_0__drv),
.FoutSubtask_1__drv(dut_FoutSubtask_1__drv),
.FoutTask_0__drv(dut_FoutTask_0__drv),
.FoutTask_1__drv(dut_FoutTask_1__drv),
.FoutTask_2__drv(dut_FoutTask_2__drv),
.FoutTask_3__drv(dut_FoutTask_3__drv),
.HoldMapBuf__drv(dut_HoldMapBuf__drv),
.IfuFaultInEc2__drv(dut_IfuFaultInEc2__drv),
.LargeHold__drv(dut_LargeHold__drv),
.LdPipeVAdly_p___drv(dut_LdPipeVAdly_p___drv),
.LoadEcOut_p___drv(dut_LoadEcOut_p___drv),
.LoadSinE__drv(dut_LoadSinE__drv),
.LoadSinO__drv(dut_LoadSinO__drv),
.LoadSoutE_p___drv(dut_LoadSoutE_p___drv),
.LoadSoutO_p___drv(dut_LoadSoutO_p___drv),
.MDMtag_p___drv(dut_MDMtag_p___drv),
.MakeD_u_CD__drv(dut_MakeD_u_CD__drv),
.MakeD_u_Dbuf__drv(dut_MakeD_u_Dbuf__drv),
.MakeF_u_D__drv(dut_MakeF_u_D__drv),
.MakeFout_u_D__drv(dut_MakeFout_u_D__drv),
.MakeMDM_u_D_p___drv(dut_MakeMDM_u_D_p___drv),
.MakeMD_u_D_p___drv(dut_MakeMD_u_D_p___drv),
.MakeSout_u_D__drv(dut_MakeSout_u_D__drv),
.MapRfsh_p___drv(dut_MapRfsh_p___drv),
.MapTroubleInEc1__drv(dut_MapTroubleInEc1__drv),
.MapWait_m_D__drv(dut_MapWait_m_D__drv),
.MemAd_0__drv(dut_MemAd_0__drv),
.MemAd_1__drv(dut_MemAd_1__drv),
.MemAd_2__drv(dut_MemAd_2__drv),
.MemAd_3__drv(dut_MemAd_3__drv),
.MemAd_4__drv(dut_MemAd_4__drv),
.MemAd_5__drv(dut_MemAd_5__drv),
.MemAd_6__drv(dut_MemAd_6__drv),
.MemAd_7__drv(dut_MemAd_7__drv),
.MemAd_8__drv(dut_MemAd_8__drv),
.MemCASa__drv(dut_MemCASa__drv),
.MemCASb__drv(dut_MemCASb__drv),
.MemError__drv(dut_MemError__drv),
.MemPE__drv(dut_MemPE__drv),
.MemRASa__drv(dut_MemRASa__drv),
.MemRASb__drv(dut_MemRASb__drv),
.MemRfsh__drv(dut_MemRfsh__drv),
.MemWEa__drv(dut_MemWEa__drv),
.MemWEb__drv(dut_MemWEb__drv),
.Mod0SinEn_p___drv(dut_Mod0SinEn_p___drv),
.Mod0StrEn_p___drv(dut_Mod0StrEn_p___drv),
.Mod1SinEn_p___drv(dut_Mod1SinEn_p___drv),
.Mod1StrEn_p___drv(dut_Mod1StrEn_p___drv),
.Mod2SinEn_p___drv(dut_Mod2SinEn_p___drv),
.Mod2StrEn_p___drv(dut_Mod2StrEn_p___drv),
.Mod3SinEn_p___drv(dut_Mod3SinEn_p___drv),
.Mod3StrEn_p___drv(dut_Mod3StrEn_p___drv),
.ProcTag__drv(dut_ProcTag__drv),
.ProcTagInA__drv(dut_ProcTagInA__drv),
.STfree_p___drv(dut_STfree_p___drv),
.ShiftEcOut__drv(dut_ShiftEcOut__drv),
.ShiftSinE__drv(dut_ShiftSinE__drv),
.ShiftSinO__drv(dut_ShiftSinO__drv),
.ShiftSoutE__drv(dut_ShiftSoutE__drv),
.ShiftSoutO__drv(dut_ShiftSoutO__drv),
.StartEcChk_p___drv(dut_StartEcChk_p___drv),
.StartEcGen_p___drv(dut_StartEcGen_p___drv),
.TWReq_15__drv(dut_TWReq_15__drv),
.Transport_p___drv(dut_Transport_p___drv),
.WPinEc1__drv(dut_WPinEc1__drv),
.XWantsPipe__drv(dut_XWantsPipe__drv),
.dMDMad_0_p___drv(dut_dMDMad_0_p___drv),
.dMDMad_1_p___drv(dut_dMDMad_1_p___drv),
.dMDMad_2_p___drv(dut_dMDMad_2_p___drv),
.dMDMad_3_p___drv(dut_dMDMad_3_p___drv),
.dPipe02Ad_0__drv(dut_dPipe02Ad_0__drv),
.dPipe02Ad_1__drv(dut_dPipe02Ad_1__drv),
.dPipe02Ad_2__drv(dut_dPipe02Ad_2__drv),
.dPipe02Ad_3__drv(dut_dPipe02Ad_3__drv),
.dPipe34Ad_0__drv(dut_dPipe34Ad_0__drv),
.dPipe34Ad_1__drv(dut_dPipe34Ad_1__drv),
.dPipe34Ad_2__drv(dut_dPipe34Ad_2__drv),
.dPipe34Ad_3__drv(dut_dPipe34Ad_3__drv),
.preMCSb__drv(dut_preMCSb__drv),
.state_host_clk(clk),
.state_guest_advance(board_steps[0]),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[23:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(all_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_preMCSb__drv,dut_dPipe34Ad_3__drv,dut_dPipe34Ad_2__drv,dut_dPipe34Ad_1__drv,dut_dPipe34Ad_0__drv,dut_dPipe02Ad_3__drv,dut_dPipe02Ad_2__drv,dut_dPipe02Ad_1__drv,dut_dPipe02Ad_0__drv,dut_dMDMad_3_p___drv,dut_dMDMad_2_p___drv,dut_dMDMad_1_p___drv,dut_dMDMad_0_p___drv,dut_XWantsPipe__drv,dut_WPinEc1__drv,dut_Transport_p___drv,dut_TWReq_15__drv,dut_StartEcGen_p___drv,dut_StartEcChk_p___drv,dut_ShiftSoutO__drv,dut_ShiftSoutE__drv,dut_ShiftSinO__drv,dut_ShiftSinE__drv,dut_ShiftEcOut__drv,dut_STfree_p___drv,dut_ProcTagInA__drv,dut_ProcTag__drv,dut_Mod3StrEn_p___drv,dut_Mod3SinEn_p___drv,dut_Mod2StrEn_p___drv,dut_Mod2SinEn_p___drv,dut_Mod1StrEn_p___drv,dut_Mod1SinEn_p___drv,dut_Mod0StrEn_p___drv,dut_Mod0SinEn_p___drv,dut_MemWEb__drv,dut_MemWEa__drv,dut_MemRfsh__drv,dut_MemRASb__drv,dut_MemRASa__drv,dut_MemPE__drv,dut_MemError__drv,dut_MemCASb__drv,dut_MemCASa__drv,dut_MemAd_8__drv,dut_MemAd_7__drv,dut_MemAd_6__drv,dut_MemAd_5__drv,dut_MemAd_4__drv,dut_MemAd_3__drv,dut_MemAd_2__drv,dut_MemAd_1__drv,dut_MemAd_0__drv,dut_MapWait_m_D__drv,dut_MapTroubleInEc1__drv,dut_MapRfsh_p___drv,dut_MakeSout_u_D__drv,dut_MakeMD_u_D_p___drv,dut_MakeMDM_u_D_p___drv,dut_MakeFout_u_D__drv,dut_MakeF_u_D__drv,dut_MakeD_u_Dbuf__drv,dut_MakeD_u_CD__drv,dut_MDMtag_p___drv,dut_LoadSoutO_p___drv,dut_LoadSoutE_p___drv,dut_LoadSinO__drv,dut_LoadSinE__drv,dut_LoadEcOut_p___drv,dut_LdPipeVAdly_p___drv,dut_LargeHold__drv,dut_IfuFaultInEc2__drv,dut_HoldMapBuf__drv,dut_FoutTask_3__drv,dut_FoutTask_2__drv,dut_FoutTask_1__drv,dut_FoutTask_0__drv,dut_FoutSubtask_1__drv,dut_FoutSubTask_0__drv,dut_FoutNext__drv,dut_Fout_flt__drv,dut_FinTask_3__drv,dut_FinTask_2__drv,dut_FinTask_1__drv,dut_FinTask_0__drv,dut_FinSubtask_1__drv,dut_FinSubtask_0__drv,dut_FinNext__drv,dut_ErrorsFromEc2__drv,dut_EmuOrFT_p___drv,dut_EcWantsA__drv,dut_EcDcomingForCt_p___drv,dut_DdataGood_p___drv,dut_DMuxData__drv,dut_CountMiss__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv,dut_At_eq_Curt_p___drv,dut_AcanhaveMap_p___drv};
assign dut_state[0+:1]=dut.Clk1_p_Aa;
assign dut_state[1+:1]=dut.Clk1_p_Ab;
assign dut_state[2+:1]=dut.Clk1_p_Ab__lag1;
assign dut_state[3+:1]=dut.Clk1_p_Ab__lag2;
assign dut_state[4+:1]=dut.Clk1_p_Ba;
assign dut_state[5+:1]=dut.Clk1_p_Bb;
assign dut_state[6+:1]=dut.Clk1_p_Bc;
assign dut_state[7+:1]=dut.Clk1_p_Ca;
assign dut_state[8+:1]=dut.Clk1_p_Cb;
assign dut_state[9+:1]=dut.Clk1_p_Cc;
assign dut_state[10+:3]=dut.mapbuf_fh_delay;
assign dut_state[13+:1]=dut.sin_select_clock;
assign dut_state[14+:1]=dut.u_a03.ck_d;
assign dut_state[15+:4]=dut.u_a03.q;
assign dut_state[19+:6]=dut.u_a03.setup_pre;
assign dut_state[25+:1]=dut.u_a04.cas_d;
assign dut_state[26+:8]=dut.u_a04.col;
assign dut_state[34+:1]=dut.u_a04.dout;
assign dut_state[35+:1]=dut.u_a04.ras_d;
assign dut_state[36+:8]=dut.u_a04.row;
assign dut_state[44+:1]=dut.u_a04.saved_dout_r;
assign dut_state[45+:1]=dut.u_a04.we_d;
assign dut_state[46+:1]=dut.u_a04.write_data;
assign dut_state[47+:1]=dut.u_a04.write_pending;
assign dut_state[48+:1]=dut.u_a05.cas_d;
assign dut_state[49+:8]=dut.u_a05.col;
assign dut_state[57+:1]=dut.u_a05.dout;
assign dut_state[58+:1]=dut.u_a05.ras_d;
assign dut_state[59+:8]=dut.u_a05.row;
assign dut_state[67+:1]=dut.u_a05.saved_dout_r;
assign dut_state[68+:1]=dut.u_a05.we_d;
assign dut_state[69+:1]=dut.u_a05.write_data;
assign dut_state[70+:1]=dut.u_a05.write_pending;
assign dut_state[71+:1]=dut.u_a06.cas_d;
assign dut_state[72+:8]=dut.u_a06.col;
assign dut_state[80+:1]=dut.u_a06.dout;
assign dut_state[81+:1]=dut.u_a06.ras_d;
assign dut_state[82+:8]=dut.u_a06.row;
assign dut_state[90+:1]=dut.u_a06.saved_dout_r;
assign dut_state[91+:1]=dut.u_a06.we_d;
assign dut_state[92+:1]=dut.u_a06.write_data;
assign dut_state[93+:1]=dut.u_a06.write_pending;
assign dut_state[94+:1]=dut.u_a07.cas_d;
assign dut_state[95+:8]=dut.u_a07.col;
assign dut_state[103+:1]=dut.u_a07.dout;
assign dut_state[104+:1]=dut.u_a07.ras_d;
assign dut_state[105+:8]=dut.u_a07.row;
assign dut_state[113+:1]=dut.u_a07.saved_dout_r;
assign dut_state[114+:1]=dut.u_a07.we_d;
assign dut_state[115+:1]=dut.u_a07.write_data;
assign dut_state[116+:1]=dut.u_a07.write_pending;
assign dut_state[117+:1]=dut.u_a08.cas_d;
assign dut_state[118+:8]=dut.u_a08.col;
assign dut_state[126+:1]=dut.u_a08.dout;
assign dut_state[127+:1]=dut.u_a08.ras_d;
assign dut_state[128+:8]=dut.u_a08.row;
assign dut_state[136+:1]=dut.u_a08.saved_dout_r;
assign dut_state[137+:1]=dut.u_a08.we_d;
assign dut_state[138+:1]=dut.u_a08.write_data;
assign dut_state[139+:1]=dut.u_a08.write_pending;
assign dut_state[140+:1]=dut.u_a09.cas_d;
assign dut_state[141+:8]=dut.u_a09.col;
assign dut_state[149+:1]=dut.u_a09.dout;
assign dut_state[150+:1]=dut.u_a09.ras_d;
assign dut_state[151+:8]=dut.u_a09.row;
assign dut_state[159+:1]=dut.u_a09.saved_dout_r;
assign dut_state[160+:1]=dut.u_a09.we_d;
assign dut_state[161+:1]=dut.u_a09.write_data;
assign dut_state[162+:1]=dut.u_a09.write_pending;
assign dut_state[163+:1]=dut.u_a10.cas_d;
assign dut_state[164+:8]=dut.u_a10.col;
assign dut_state[172+:1]=dut.u_a10.dout;
assign dut_state[173+:1]=dut.u_a10.ras_d;
assign dut_state[174+:8]=dut.u_a10.row;
assign dut_state[182+:1]=dut.u_a10.saved_dout_r;
assign dut_state[183+:1]=dut.u_a10.we_d;
assign dut_state[184+:1]=dut.u_a10.write_data;
assign dut_state[185+:1]=dut.u_a10.write_pending;
assign dut_state[186+:1]=dut.u_a11.cas_d;
assign dut_state[187+:8]=dut.u_a11.col;
assign dut_state[195+:1]=dut.u_a11.dout;
assign dut_state[196+:1]=dut.u_a11.ras_d;
assign dut_state[197+:8]=dut.u_a11.row;
assign dut_state[205+:1]=dut.u_a11.saved_dout_r;
assign dut_state[206+:1]=dut.u_a11.we_d;
assign dut_state[207+:1]=dut.u_a11.write_data;
assign dut_state[208+:1]=dut.u_a11.write_pending;
assign dut_state[209+:1]=dut.u_a12.cas_d;
assign dut_state[210+:8]=dut.u_a12.col;
assign dut_state[218+:1]=dut.u_a12.dout;
assign dut_state[219+:1]=dut.u_a12.ras_d;
assign dut_state[220+:8]=dut.u_a12.row;
assign dut_state[228+:1]=dut.u_a12.saved_dout_r;
assign dut_state[229+:1]=dut.u_a12.we_d;
assign dut_state[230+:1]=dut.u_a12.write_data;
assign dut_state[231+:1]=dut.u_a12.write_pending;
assign dut_state[232+:1]=dut.u_a13.cas_d;
assign dut_state[233+:8]=dut.u_a13.col;
assign dut_state[241+:1]=dut.u_a13.dout;
assign dut_state[242+:1]=dut.u_a13.ras_d;
assign dut_state[243+:8]=dut.u_a13.row;
assign dut_state[251+:1]=dut.u_a13.saved_dout_r;
assign dut_state[252+:1]=dut.u_a13.we_d;
assign dut_state[253+:1]=dut.u_a13.write_data;
assign dut_state[254+:1]=dut.u_a13.write_pending;
assign dut_state[255+:1]=dut.u_a14.cas_d;
assign dut_state[256+:8]=dut.u_a14.col;
assign dut_state[264+:1]=dut.u_a14.dout;
assign dut_state[265+:1]=dut.u_a14.ras_d;
assign dut_state[266+:8]=dut.u_a14.row;
assign dut_state[274+:1]=dut.u_a14.saved_dout_r;
assign dut_state[275+:1]=dut.u_a14.we_d;
assign dut_state[276+:1]=dut.u_a14.write_data;
assign dut_state[277+:1]=dut.u_a14.write_pending;
assign dut_state[278+:1]=dut.u_a17.ck_d;
assign dut_state[279+:4]=dut.u_a17.q;
assign dut_state[283+:6]=dut.u_a17.setup_pre;
assign dut_state[289+:1]=dut.u_a18.ck_d;
assign dut_state[290+:4]=dut.u_a18.d_pre;
assign dut_state[294+:1]=dut.u_a18.dl_pre;
assign dut_state[295+:1]=dut.u_a18.dr_pre;
assign dut_state[296+:4]=dut.u_a18.q;
assign dut_state[300+:2]=dut.u_a18.s_pre;
assign dut_state[302+:1]=dut.u_a21.ck_d;
assign dut_state[303+:4]=dut.u_a21.q;
assign dut_state[307+:6]=dut.u_a21.setup_pre;
assign dut_state[313+:1]=dut.u_a23.ck_d;
assign dut_state[314+:4]=dut.u_a23.q;
assign dut_state[318+:6]=dut.u_a23.setup_pre;
assign dut_state[324+:5]=dut.u_b01.q;
assign dut_state[329+:1]=dut.u_b23.ck_d;
assign dut_state[330+:4]=dut.u_b23.d_pre;
assign dut_state[334+:1]=dut.u_b23.dl_pre;
assign dut_state[335+:1]=dut.u_b23.dr_pre;
assign dut_state[336+:4]=dut.u_b23.q;
assign dut_state[340+:2]=dut.u_b23.s_pre;
assign dut_state[342+:1]=dut.u_b24.ck_d;
assign dut_state[343+:4]=dut.u_b24.q;
assign dut_state[347+:6]=dut.u_b24.setup_pre;
assign dut_state[353+:1]=dut.u_c01.cka_d;
assign dut_state[354+:1]=dut.u_c01.ckb_d;
assign dut_state[355+:1]=dut.u_c01.d_pre_a;
assign dut_state[356+:1]=dut.u_c01.d_pre_b;
assign dut_state[357+:1]=dut.u_c01.qa;
assign dut_state[358+:1]=dut.u_c01.qb;
assign dut_state[359+:1]=dut.u_c02.ck_d;
assign dut_state[360+:6]=dut.u_c02.d_pre;
assign dut_state[366+:6]=dut.u_c02.q;
assign dut_state[372+:4]=dut.u_c21.a_lat;
assign dut_state[376+:1]=dut.u_c21.ce_lat;
assign dut_state[377+:4]=dut.u_c21.d_lat;
assign dut_state[381+:64]={dut.u_c21.mem[15],dut.u_c21.mem[14],dut.u_c21.mem[13],dut.u_c21.mem[12],dut.u_c21.mem[11],dut.u_c21.mem[10],dut.u_c21.mem[9],dut.u_c21.mem[8],dut.u_c21.mem[7],dut.u_c21.mem[6],dut.u_c21.mem[5],dut.u_c21.mem[4],dut.u_c21.mem[3],dut.u_c21.mem[2],dut.u_c21.mem[1],dut.u_c21.mem[0]};
assign dut_state[445+:1]=dut.u_c21.we_d;
assign dut_state[446+:1]=dut.u_c22.ck_d;
assign dut_state[447+:4]=dut.u_c22.q;
assign dut_state[451+:6]=dut.u_c22.setup_pre;
assign dut_state[457+:5]=dut.u_d01.q;
assign dut_state[462+:1]=dut.u_d04.cas_d;
assign dut_state[463+:8]=dut.u_d04.col;
assign dut_state[471+:1]=dut.u_d04.dout;
assign dut_state[472+:1]=dut.u_d04.ras_d;
assign dut_state[473+:8]=dut.u_d04.row;
assign dut_state[481+:1]=dut.u_d04.saved_dout_r;
assign dut_state[482+:1]=dut.u_d04.we_d;
assign dut_state[483+:1]=dut.u_d04.write_data;
assign dut_state[484+:1]=dut.u_d04.write_pending;
assign dut_state[485+:1]=dut.u_d05.cas_d;
assign dut_state[486+:8]=dut.u_d05.col;
assign dut_state[494+:1]=dut.u_d05.dout;
assign dut_state[495+:1]=dut.u_d05.ras_d;
assign dut_state[496+:8]=dut.u_d05.row;
assign dut_state[504+:1]=dut.u_d05.saved_dout_r;
assign dut_state[505+:1]=dut.u_d05.we_d;
assign dut_state[506+:1]=dut.u_d05.write_data;
assign dut_state[507+:1]=dut.u_d05.write_pending;
assign dut_state[508+:1]=dut.u_d06.cas_d;
assign dut_state[509+:8]=dut.u_d06.col;
assign dut_state[517+:1]=dut.u_d06.dout;
assign dut_state[518+:1]=dut.u_d06.ras_d;
assign dut_state[519+:8]=dut.u_d06.row;
assign dut_state[527+:1]=dut.u_d06.saved_dout_r;
assign dut_state[528+:1]=dut.u_d06.we_d;
assign dut_state[529+:1]=dut.u_d06.write_data;
assign dut_state[530+:1]=dut.u_d06.write_pending;
assign dut_state[531+:1]=dut.u_d07.cas_d;
assign dut_state[532+:8]=dut.u_d07.col;
assign dut_state[540+:1]=dut.u_d07.dout;
assign dut_state[541+:1]=dut.u_d07.ras_d;
assign dut_state[542+:8]=dut.u_d07.row;
assign dut_state[550+:1]=dut.u_d07.saved_dout_r;
assign dut_state[551+:1]=dut.u_d07.we_d;
assign dut_state[552+:1]=dut.u_d07.write_data;
assign dut_state[553+:1]=dut.u_d07.write_pending;
assign dut_state[554+:1]=dut.u_d08.cas_d;
assign dut_state[555+:8]=dut.u_d08.col;
assign dut_state[563+:1]=dut.u_d08.dout;
assign dut_state[564+:1]=dut.u_d08.ras_d;
assign dut_state[565+:8]=dut.u_d08.row;
assign dut_state[573+:1]=dut.u_d08.saved_dout_r;
assign dut_state[574+:1]=dut.u_d08.we_d;
assign dut_state[575+:1]=dut.u_d08.write_data;
assign dut_state[576+:1]=dut.u_d08.write_pending;
assign dut_state[577+:1]=dut.u_d09.cas_d;
assign dut_state[578+:8]=dut.u_d09.col;
assign dut_state[586+:1]=dut.u_d09.dout;
assign dut_state[587+:1]=dut.u_d09.ras_d;
assign dut_state[588+:8]=dut.u_d09.row;
assign dut_state[596+:1]=dut.u_d09.saved_dout_r;
assign dut_state[597+:1]=dut.u_d09.we_d;
assign dut_state[598+:1]=dut.u_d09.write_data;
assign dut_state[599+:1]=dut.u_d09.write_pending;
assign dut_state[600+:1]=dut.u_d10.cas_d;
assign dut_state[601+:8]=dut.u_d10.col;
assign dut_state[609+:1]=dut.u_d10.dout;
assign dut_state[610+:1]=dut.u_d10.ras_d;
assign dut_state[611+:8]=dut.u_d10.row;
assign dut_state[619+:1]=dut.u_d10.saved_dout_r;
assign dut_state[620+:1]=dut.u_d10.we_d;
assign dut_state[621+:1]=dut.u_d10.write_data;
assign dut_state[622+:1]=dut.u_d10.write_pending;
assign dut_state[623+:1]=dut.u_d11.cas_d;
assign dut_state[624+:8]=dut.u_d11.col;
assign dut_state[632+:1]=dut.u_d11.dout;
assign dut_state[633+:1]=dut.u_d11.ras_d;
assign dut_state[634+:8]=dut.u_d11.row;
assign dut_state[642+:1]=dut.u_d11.saved_dout_r;
assign dut_state[643+:1]=dut.u_d11.we_d;
assign dut_state[644+:1]=dut.u_d11.write_data;
assign dut_state[645+:1]=dut.u_d11.write_pending;
assign dut_state[646+:1]=dut.u_d12.cas_d;
assign dut_state[647+:8]=dut.u_d12.col;
assign dut_state[655+:1]=dut.u_d12.dout;
assign dut_state[656+:1]=dut.u_d12.ras_d;
assign dut_state[657+:8]=dut.u_d12.row;
assign dut_state[665+:1]=dut.u_d12.saved_dout_r;
assign dut_state[666+:1]=dut.u_d12.we_d;
assign dut_state[667+:1]=dut.u_d12.write_data;
assign dut_state[668+:1]=dut.u_d12.write_pending;
assign dut_state[669+:1]=dut.u_d13.cas_d;
assign dut_state[670+:8]=dut.u_d13.col;
assign dut_state[678+:1]=dut.u_d13.dout;
assign dut_state[679+:1]=dut.u_d13.ras_d;
assign dut_state[680+:8]=dut.u_d13.row;
assign dut_state[688+:1]=dut.u_d13.saved_dout_r;
assign dut_state[689+:1]=dut.u_d13.we_d;
assign dut_state[690+:1]=dut.u_d13.write_data;
assign dut_state[691+:1]=dut.u_d13.write_pending;
assign dut_state[692+:1]=dut.u_d18.ck_d;
assign dut_state[693+:6]=dut.u_d18.d_pre;
assign dut_state[699+:6]=dut.u_d18.q;
assign dut_state[705+:1]=dut.u_d22.ck_d;
assign dut_state[706+:4]=dut.u_d22.d_pre;
assign dut_state[710+:1]=dut.u_d22.dl_pre;
assign dut_state[711+:1]=dut.u_d22.dr_pre;
assign dut_state[712+:4]=dut.u_d22.q;
assign dut_state[716+:2]=dut.u_d22.s_pre;
assign dut_state[718+:4]=dut.u_e16.a_lat;
assign dut_state[722+:1]=dut.u_e16.ce_lat;
assign dut_state[723+:4]=dut.u_e16.d_lat;
assign dut_state[727+:64]={dut.u_e16.mem[15],dut.u_e16.mem[14],dut.u_e16.mem[13],dut.u_e16.mem[12],dut.u_e16.mem[11],dut.u_e16.mem[10],dut.u_e16.mem[9],dut.u_e16.mem[8],dut.u_e16.mem[7],dut.u_e16.mem[6],dut.u_e16.mem[5],dut.u_e16.mem[4],dut.u_e16.mem[3],dut.u_e16.mem[2],dut.u_e16.mem[1],dut.u_e16.mem[0]};
assign dut_state[791+:1]=dut.u_e16.we_d;
assign dut_state[792+:1]=dut.u_e18.ck_d;
assign dut_state[793+:4]=dut.u_e18.q;
assign dut_state[797+:6]=dut.u_e18.setup_pre;
assign dut_state[803+:1]=dut.u_e19.ck_d;
assign dut_state[804+:6]=dut.u_e19.d_pre;
assign dut_state[810+:6]=dut.u_e19.q;
assign dut_state[816+:4]=dut.u_e20.a_lat;
assign dut_state[820+:1]=dut.u_e20.ce_lat;
assign dut_state[821+:4]=dut.u_e20.d_lat;
assign dut_state[825+:64]={dut.u_e20.mem[15],dut.u_e20.mem[14],dut.u_e20.mem[13],dut.u_e20.mem[12],dut.u_e20.mem[11],dut.u_e20.mem[10],dut.u_e20.mem[9],dut.u_e20.mem[8],dut.u_e20.mem[7],dut.u_e20.mem[6],dut.u_e20.mem[5],dut.u_e20.mem[4],dut.u_e20.mem[3],dut.u_e20.mem[2],dut.u_e20.mem[1],dut.u_e20.mem[0]};
assign dut_state[889+:1]=dut.u_e20.we_d;
assign dut_state[890+:4]=dut.u_e21.a_lat;
assign dut_state[894+:1]=dut.u_e21.ce_lat;
assign dut_state[895+:4]=dut.u_e21.d_lat;
assign dut_state[899+:64]={dut.u_e21.mem[15],dut.u_e21.mem[14],dut.u_e21.mem[13],dut.u_e21.mem[12],dut.u_e21.mem[11],dut.u_e21.mem[10],dut.u_e21.mem[9],dut.u_e21.mem[8],dut.u_e21.mem[7],dut.u_e21.mem[6],dut.u_e21.mem[5],dut.u_e21.mem[4],dut.u_e21.mem[3],dut.u_e21.mem[2],dut.u_e21.mem[1],dut.u_e21.mem[0]};
assign dut_state[963+:1]=dut.u_e21.we_d;
assign dut_state[964+:1]=dut.u_e22.ck_d;
assign dut_state[965+:4]=dut.u_e22.q;
assign dut_state[969+:6]=dut.u_e22.setup_pre;
assign dut_state[975+:1]=dut.u_e23.ck_d;
assign dut_state[976+:6]=dut.u_e23.d_pre;
assign dut_state[982+:6]=dut.u_e23.q;
assign dut_state[988+:1]=dut.u_e24.cka_d;
assign dut_state[989+:1]=dut.u_e24.ckb_d;
assign dut_state[990+:1]=dut.u_e24.d_pre_a;
assign dut_state[991+:1]=dut.u_e24.d_pre_b;
assign dut_state[992+:1]=dut.u_e24.qa;
assign dut_state[993+:1]=dut.u_e24.qb;
assign dut_state[994+:5]=dut.u_f01.q;
assign dut_state[999+:1]=dut.u_f03.ck_d;
assign dut_state[1000+:4]=dut.u_f03.q;
assign dut_state[1004+:6]=dut.u_f03.setup_pre;
assign dut_state[1010+:1]=dut.u_f04.ck_d;
assign dut_state[1011+:4]=dut.u_f04.q;
assign dut_state[1015+:6]=dut.u_f04.setup_pre;
assign dut_state[1021+:4]=dut.u_f13.a_lat;
assign dut_state[1025+:1]=dut.u_f13.ce_lat;
assign dut_state[1026+:4]=dut.u_f13.d_lat;
assign dut_state[1030+:64]={dut.u_f13.mem[15],dut.u_f13.mem[14],dut.u_f13.mem[13],dut.u_f13.mem[12],dut.u_f13.mem[11],dut.u_f13.mem[10],dut.u_f13.mem[9],dut.u_f13.mem[8],dut.u_f13.mem[7],dut.u_f13.mem[6],dut.u_f13.mem[5],dut.u_f13.mem[4],dut.u_f13.mem[3],dut.u_f13.mem[2],dut.u_f13.mem[1],dut.u_f13.mem[0]};
assign dut_state[1094+:1]=dut.u_f13.we_d;
assign dut_state[1095+:4]=dut.u_f14.a_lat;
assign dut_state[1099+:1]=dut.u_f14.ce_lat;
assign dut_state[1100+:4]=dut.u_f14.d_lat;
assign dut_state[1104+:64]={dut.u_f14.mem[15],dut.u_f14.mem[14],dut.u_f14.mem[13],dut.u_f14.mem[12],dut.u_f14.mem[11],dut.u_f14.mem[10],dut.u_f14.mem[9],dut.u_f14.mem[8],dut.u_f14.mem[7],dut.u_f14.mem[6],dut.u_f14.mem[5],dut.u_f14.mem[4],dut.u_f14.mem[3],dut.u_f14.mem[2],dut.u_f14.mem[1],dut.u_f14.mem[0]};
assign dut_state[1168+:1]=dut.u_f14.we_d;
assign dut_state[1169+:4]=dut.u_f15.a_lat;
assign dut_state[1173+:1]=dut.u_f15.ce_lat;
assign dut_state[1174+:4]=dut.u_f15.d_lat;
assign dut_state[1178+:64]={dut.u_f15.mem[15],dut.u_f15.mem[14],dut.u_f15.mem[13],dut.u_f15.mem[12],dut.u_f15.mem[11],dut.u_f15.mem[10],dut.u_f15.mem[9],dut.u_f15.mem[8],dut.u_f15.mem[7],dut.u_f15.mem[6],dut.u_f15.mem[5],dut.u_f15.mem[4],dut.u_f15.mem[3],dut.u_f15.mem[2],dut.u_f15.mem[1],dut.u_f15.mem[0]};
assign dut_state[1242+:1]=dut.u_f15.we_d;
assign dut_state[1243+:4]=dut.u_f16.a_lat;
assign dut_state[1247+:1]=dut.u_f16.ce_lat;
assign dut_state[1248+:4]=dut.u_f16.d_lat;
assign dut_state[1252+:64]={dut.u_f16.mem[15],dut.u_f16.mem[14],dut.u_f16.mem[13],dut.u_f16.mem[12],dut.u_f16.mem[11],dut.u_f16.mem[10],dut.u_f16.mem[9],dut.u_f16.mem[8],dut.u_f16.mem[7],dut.u_f16.mem[6],dut.u_f16.mem[5],dut.u_f16.mem[4],dut.u_f16.mem[3],dut.u_f16.mem[2],dut.u_f16.mem[1],dut.u_f16.mem[0]};
assign dut_state[1316+:1]=dut.u_f16.we_d;
assign dut_state[1317+:4]=dut.u_f17.a_lat;
assign dut_state[1321+:1]=dut.u_f17.ce_lat;
assign dut_state[1322+:4]=dut.u_f17.d_lat;
assign dut_state[1326+:64]={dut.u_f17.mem[15],dut.u_f17.mem[14],dut.u_f17.mem[13],dut.u_f17.mem[12],dut.u_f17.mem[11],dut.u_f17.mem[10],dut.u_f17.mem[9],dut.u_f17.mem[8],dut.u_f17.mem[7],dut.u_f17.mem[6],dut.u_f17.mem[5],dut.u_f17.mem[4],dut.u_f17.mem[3],dut.u_f17.mem[2],dut.u_f17.mem[1],dut.u_f17.mem[0]};
assign dut_state[1390+:1]=dut.u_f17.we_d;
assign dut_state[1391+:1]=dut.u_f18.ck_d;
assign dut_state[1392+:4]=dut.u_f18.q;
assign dut_state[1396+:6]=dut.u_f18.setup_pre;
assign dut_state[1402+:1]=dut.u_f19.ck_d;
assign dut_state[1403+:4]=dut.u_f19.q;
assign dut_state[1407+:6]=dut.u_f19.setup_pre;
assign dut_state[1413+:4]=dut.u_f21.a_lat;
assign dut_state[1417+:1]=dut.u_f21.ce_lat;
assign dut_state[1418+:4]=dut.u_f21.d_lat;
assign dut_state[1422+:64]={dut.u_f21.mem[15],dut.u_f21.mem[14],dut.u_f21.mem[13],dut.u_f21.mem[12],dut.u_f21.mem[11],dut.u_f21.mem[10],dut.u_f21.mem[9],dut.u_f21.mem[8],dut.u_f21.mem[7],dut.u_f21.mem[6],dut.u_f21.mem[5],dut.u_f21.mem[4],dut.u_f21.mem[3],dut.u_f21.mem[2],dut.u_f21.mem[1],dut.u_f21.mem[0]};
assign dut_state[1486+:1]=dut.u_f21.we_d;
assign dut_state[1487+:5]=dut.u_g01.q;
assign dut_state[1492+:1]=dut.u_g05.ck_d;
assign dut_state[1493+:4]=dut.u_g05.q;
assign dut_state[1497+:6]=dut.u_g05.setup_pre;
assign dut_state[1503+:1]=dut.u_g06.ck_d;
assign dut_state[1504+:4]=dut.u_g06.q;
assign dut_state[1508+:6]=dut.u_g06.setup_pre;
assign dut_state[1514+:1]=dut.u_g07.ck_d;
assign dut_state[1515+:4]=dut.u_g07.q;
assign dut_state[1519+:6]=dut.u_g07.setup_pre;
assign dut_state[1525+:4]=dut.u_g18.q;
assign dut_state[1529+:4]=dut.u_g19.q;
assign dut_state[1533+:1]=dut.u_g23.ck_d;
assign dut_state[1534+:6]=dut.u_g23.d_pre;
assign dut_state[1540+:6]=dut.u_g23.q;
assign dut_state[1546+:1]=dut.u_h05.ck_d;
assign dut_state[1547+:4]=dut.u_h05.d_pre;
assign dut_state[1551+:1]=dut.u_h05.dl_pre;
assign dut_state[1552+:1]=dut.u_h05.dr_pre;
assign dut_state[1553+:4]=dut.u_h05.q;
assign dut_state[1557+:2]=dut.u_h05.s_pre;
assign dut_state[1559+:1]=dut.u_h06.ck_d;
assign dut_state[1560+:4]=dut.u_h06.d_pre;
assign dut_state[1564+:1]=dut.u_h06.dl_pre;
assign dut_state[1565+:1]=dut.u_h06.dr_pre;
assign dut_state[1566+:4]=dut.u_h06.q;
assign dut_state[1570+:2]=dut.u_h06.s_pre;
assign dut_state[1572+:1]=dut.u_h08.ck_d;
assign dut_state[1573+:4]=dut.u_h08.d_pre;
assign dut_state[1577+:4]=dut.u_h08.q;
assign dut_state[1581+:1]=dut.u_h09.ck_d;
assign dut_state[1582+:4]=dut.u_h09.d_pre;
assign dut_state[1586+:1]=dut.u_h09.dl_pre;
assign dut_state[1587+:1]=dut.u_h09.dr_pre;
assign dut_state[1588+:4]=dut.u_h09.q;
assign dut_state[1592+:2]=dut.u_h09.s_pre;
assign dut_state[1594+:1]=dut.u_h12.ck_d;
assign dut_state[1595+:4]=dut.u_h12.q;
assign dut_state[1599+:6]=dut.u_h12.setup_pre;
assign dut_state[1605+:1]=dut.u_h14.ck_d;
assign dut_state[1606+:6]=dut.u_h14.d_pre;
assign dut_state[1612+:6]=dut.u_h14.q;
assign dut_state[1618+:1]=dut.u_h15.ck_d;
assign dut_state[1619+:4]=dut.u_h15.q;
assign dut_state[1623+:6]=dut.u_h15.setup_pre;
assign dut_state[1629+:1]=dut.u_h18.ck_d;
assign dut_state[1630+:4]=dut.u_h18.d_pre;
assign dut_state[1634+:1]=dut.u_h18.dl_pre;
assign dut_state[1635+:1]=dut.u_h18.dr_pre;
assign dut_state[1636+:4]=dut.u_h18.q;
assign dut_state[1640+:2]=dut.u_h18.s_pre;
assign dut_state[1642+:1]=dut.u_h22.ck_d;
assign dut_state[1643+:4]=dut.u_h22.d_pre;
assign dut_state[1647+:1]=dut.u_h22.dl_pre;
assign dut_state[1648+:1]=dut.u_h22.dr_pre;
assign dut_state[1649+:4]=dut.u_h22.q;
assign dut_state[1653+:2]=dut.u_h22.s_pre;
assign dut_state[1655+:1]=dut.u_h24.ck_d;
assign dut_state[1656+:4]=dut.u_h24.d_pre;
assign dut_state[1660+:1]=dut.u_h24.dl_pre;
assign dut_state[1661+:1]=dut.u_h24.dr_pre;
assign dut_state[1662+:4]=dut.u_h24.q;
assign dut_state[1666+:2]=dut.u_h24.s_pre;
assign dut_state[1668+:1]=dut.u_i03.ck_d;
assign dut_state[1669+:6]=dut.u_i03.d_pre;
assign dut_state[1675+:6]=dut.u_i03.q;
assign dut_state[1681+:1]=dut.u_i05.ck_d;
assign dut_state[1682+:6]=dut.u_i05.d_pre;
assign dut_state[1688+:6]=dut.u_i05.q;
assign dut_state[1694+:1]=dut.u_i09.ck_d;
assign dut_state[1695+:4]=dut.u_i09.d_pre;
assign dut_state[1699+:1]=dut.u_i09.dl_pre;
assign dut_state[1700+:1]=dut.u_i09.dr_pre;
assign dut_state[1701+:4]=dut.u_i09.q;
assign dut_state[1705+:2]=dut.u_i09.s_pre;
assign dut_state[1707+:1]=dut.u_i10.ck_d;
assign dut_state[1708+:4]=dut.u_i10.q;
assign dut_state[1712+:6]=dut.u_i10.setup_pre;
assign dut_state[1718+:1]=dut.u_i15.ck_d;
assign dut_state[1719+:6]=dut.u_i15.d_pre;
assign dut_state[1725+:6]=dut.u_i15.q;
assign dut_state[1731+:1]=dut.u_i22.ck_d;
assign dut_state[1732+:6]=dut.u_i22.d_pre;
assign dut_state[1738+:6]=dut.u_i22.q;
assign dut_state[1744+:1]=dut.u_j01.ck_d;
assign dut_state[1745+:4]=dut.u_j01.q;
assign dut_state[1749+:6]=dut.u_j01.setup_pre;
assign dut_state[1755+:1]=dut.u_j03.ck_d;
assign dut_state[1756+:6]=dut.u_j03.d_pre;
assign dut_state[1762+:6]=dut.u_j03.q;
assign dut_state[1768+:1]=dut.u_j08.ck_d;
assign dut_state[1769+:4]=dut.u_j08.jk_pre;
assign dut_state[1773+:1]=dut.u_j08.qa;
assign dut_state[1774+:1]=dut.u_j08.qb;
assign dut_state[1775+:1]=dut.u_j11.ck_d;
assign dut_state[1776+:6]=dut.u_j11.d_pre;
assign dut_state[1782+:6]=dut.u_j11.q;
assign dut_state[1788+:1]=dut.u_j12.ck_d;
assign dut_state[1789+:4]=dut.u_j12.q;
assign dut_state[1793+:6]=dut.u_j12.setup_pre;
assign dut_state[1799+:1]=dut.u_j16.ck_d;
assign dut_state[1800+:4]=dut.u_j16.q;
assign dut_state[1804+:6]=dut.u_j16.setup_pre;
assign dut_state[1810+:1]=dut.u_j20.ck_d;
assign dut_state[1811+:6]=dut.u_j20.d_pre;
assign dut_state[1817+:6]=dut.u_j20.q;
assign dut_state[1823+:1]=dut.u_j21.ck_d;
assign dut_state[1824+:4]=dut.u_j21.q;
assign dut_state[1828+:6]=dut.u_j21.setup_pre;
assign dut_state[1834+:1]=dut.u_j22.ck_d;
assign dut_state[1835+:4]=dut.u_j22.q;
assign dut_state[1839+:6]=dut.u_j22.setup_pre;
assign dut_state[1845+:1]=dut.u_j24.ck_d;
assign dut_state[1846+:6]=dut.u_j24.d_pre;
assign dut_state[1852+:6]=dut.u_j24.q;
assign dut_state[1858+:1]=dut.u_k01.ck_d;
assign dut_state[1859+:4]=dut.u_k01.q;
assign dut_state[1863+:6]=dut.u_k01.setup_pre;
assign dut_state[1869+:1]=dut.u_k02.ck_d;
assign dut_state[1870+:4]=dut.u_k02.q;
assign dut_state[1874+:6]=dut.u_k02.setup_pre;
assign dut_state[1880+:1]=dut.u_k05.ck_d;
assign dut_state[1881+:4]=dut.u_k05.q;
assign dut_state[1885+:6]=dut.u_k05.setup_pre;
assign dut_state[1891+:1]=dut.u_k09.ck_d;
assign dut_state[1892+:4]=dut.u_k09.q;
assign dut_state[1896+:6]=dut.u_k09.setup_pre;
assign dut_state[1902+:1]=dut.u_k13.ck_d;
assign dut_state[1903+:6]=dut.u_k13.d_pre;
assign dut_state[1909+:6]=dut.u_k13.q;
assign dut_state[1915+:1]=dut.u_k14.ck_d;
assign dut_state[1916+:6]=dut.u_k14.d_pre;
assign dut_state[1922+:6]=dut.u_k14.q;
assign dut_state[1928+:1]=dut.u_k17.ck_d;
assign dut_state[1929+:4]=dut.u_k17.q;
assign dut_state[1933+:6]=dut.u_k17.setup_pre;
assign dut_state[1939+:1]=dut.u_k20.ck_d;
assign dut_state[1940+:6]=dut.u_k20.d_pre;
assign dut_state[1946+:6]=dut.u_k20.q;
assign dut_state[1952+:1]=dut.u_k21.ck_d;
assign dut_state[1953+:4]=dut.u_k21.q;
assign dut_state[1957+:6]=dut.u_k21.setup_pre;
assign dut_state[1963+:1]=dut.u_l02.cka_d;
assign dut_state[1964+:1]=dut.u_l02.ckb_d;
assign dut_state[1965+:1]=dut.u_l02.d_pre_a;
assign dut_state[1966+:1]=dut.u_l02.d_pre_b;
assign dut_state[1967+:1]=dut.u_l02.qa;
assign dut_state[1968+:1]=dut.u_l02.qb;
assign dut_state[1969+:1]=dut.u_l03.ck_d;
assign dut_state[1970+:6]=dut.u_l03.d_pre;
assign dut_state[1976+:6]=dut.u_l03.q;
assign dut_state[1982+:1]=dut.u_l07.ck_d;
assign dut_state[1983+:6]=dut.u_l07.d_pre;
assign dut_state[1989+:6]=dut.u_l07.q;
assign dut_state[1995+:1]=dut.u_l10.ck_d;
assign dut_state[1996+:4]=dut.u_l10.q;
assign dut_state[2000+:6]=dut.u_l10.setup_pre;
assign dut_state[2006+:1]=dut.u_l16.ck_d;
assign dut_state[2007+:4]=dut.u_l16.q;
assign dut_state[2011+:6]=dut.u_l16.setup_pre;
assign dut_state[2017+:1]=dut.u_l19.ck_d;
assign dut_state[2018+:6]=dut.u_l19.d_pre;
assign dut_state[2024+:6]=dut.u_l19.q;
assign dut_state[2030+:1]=dut.u_l21.ck_d;
assign dut_state[2031+:6]=dut.u_l21.d_pre;
assign dut_state[2037+:6]=dut.u_l21.q;
assign dut_state[2043+:1]=dut.u_l23.ck_d;
assign dut_state[2044+:6]=dut.u_l23.d_pre;
assign dut_state[2050+:6]=dut.u_l23.q;
assign dut_probe[0+:1]=dut.u_a04.mem[0+(probe_index%65536)];
assign dut_probe[1+:1]=dut.u_a05.mem[0+(probe_index%65536)];
assign dut_probe[2+:1]=dut.u_a06.mem[0+(probe_index%65536)];
assign dut_probe[3+:1]=dut.u_a07.mem[0+(probe_index%65536)];
assign dut_probe[4+:1]=dut.u_a08.mem[0+(probe_index%65536)];
assign dut_probe[5+:1]=dut.u_a09.mem[0+(probe_index%65536)];
assign dut_probe[6+:1]=dut.u_a10.mem[0+(probe_index%65536)];
assign dut_probe[7+:1]=dut.u_a11.mem[0+(probe_index%65536)];
assign dut_probe[8+:1]=dut.u_a12.mem[0+(probe_index%65536)];
assign dut_probe[9+:1]=dut.u_a13.mem[0+(probe_index%65536)];
assign dut_probe[10+:1]=dut.u_a14.mem[0+(probe_index%65536)];
assign dut_probe[11+:1]=dut.u_d04.mem[0+(probe_index%65536)];
assign dut_probe[12+:1]=dut.u_d05.mem[0+(probe_index%65536)];
assign dut_probe[13+:1]=dut.u_d06.mem[0+(probe_index%65536)];
assign dut_probe[14+:1]=dut.u_d07.mem[0+(probe_index%65536)];
assign dut_probe[15+:1]=dut.u_d08.mem[0+(probe_index%65536)];
assign dut_probe[16+:1]=dut.u_d09.mem[0+(probe_index%65536)];
assign dut_probe[17+:1]=dut.u_d10.mem[0+(probe_index%65536)];
assign dut_probe[18+:1]=dut.u_d11.mem[0+(probe_index%65536)];
assign dut_probe[19+:1]=dut.u_d12.mem[0+(probe_index%65536)];
assign dut_probe[20+:1]=dut.u_d13.mem[0+(probe_index%65536)];
assign all_helpers_frozen=&{dut.state_frozen,dut.u_a04.state_frozen,dut.u_a05.state_frozen,dut.u_a06.state_frozen,dut.u_a07.state_frozen,dut.u_a08.state_frozen,dut.u_a09.state_frozen,dut.u_a10.state_frozen,dut.u_a11.state_frozen,dut.u_a12.state_frozen,dut.u_a13.state_frozen,dut.u_a14.state_frozen,dut.u_c21.state_frozen,dut.u_d04.state_frozen,dut.u_d05.state_frozen,dut.u_d06.state_frozen,dut.u_d07.state_frozen,dut.u_d08.state_frozen,dut.u_d09.state_frozen,dut.u_d10.state_frozen,dut.u_d11.state_frozen,dut.u_d12.state_frozen,dut.u_d13.state_frozen,dut.u_e16.state_frozen,dut.u_e20.state_frozen,dut.u_e21.state_frozen,dut.u_f13.state_frozen,dut.u_f14.state_frozen,dut.u_f15.state_frozen,dut.u_f16.state_frozen,dut.u_f17.state_frozen,dut.u_f21.state_frozen};
endmodule
