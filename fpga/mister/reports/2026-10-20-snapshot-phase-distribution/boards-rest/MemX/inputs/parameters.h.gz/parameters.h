constexpr unsigned STIM_BITS=124,SCAN_WORD=0,AUX_WORD=9699328;
constexpr unsigned FF_BITS=819,FF_WORDS=46;
