constexpr unsigned STIM_BITS=106,SCAN_WORD=0,AUX_WORD=753664;
constexpr unsigned FF_BITS=968,FF_WORDS=54;
