module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [105:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [88:0] reference_outputs,dut_outputs,
 output wire [1678:0] reference_state,dut_state,
 output wire [71:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire all_hold=global_hold || (freeze && held) ||
 reference_hold || dut_hold || reference_fault || dut_fault;
 reg original_step=0;
 always @(negedge clk)original_step<=advance && !all_hold;
 wire [18:0] board_steps;
 dorado_board_phase_enable copies(.clk(clk),.permit(advance && !all_hold),.advance(board_steps));
 // All nineteen copies must remain identical, including scan and reset edges.
 always @(posedge clk)begin
  if(board_steps!=={19{original_step}})$fatal(1,"board phase copies differ");
 end
 wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_DMuxData__drv;
wire reference_ECFault__drv;
wire reference_EcOut_0__drv;
wire reference_EcOut_1__drv;
wire reference_EcOut_2__drv;
wire reference_EcOut_3__drv;
wire reference_EcOut_4__drv;
wire reference_EcOut_5__drv;
wire reference_EcOut_6__drv;
wire reference_EcOut_7_p___drv;
wire reference_FG_0__drv;
wire reference_FG_1__drv;
wire reference_FG_2__drv;
wire reference_FG_3__drv;
wire reference_FG_4__drv;
wire reference_FG_5__drv;
wire reference_FG_6__drv;
wire reference_FG_7__drv;
wire reference_FG_8__drv;
wire reference_Fout_00__drv;
wire reference_Fout_01__drv;
wire reference_Fout_02__drv;
wire reference_Fout_03__drv;
wire reference_Fout_04__drv;
wire reference_Fout_05__drv;
wire reference_Fout_06__drv;
wire reference_Fout_07__drv;
wire reference_Fout_08__drv;
wire reference_Fout_09__drv;
wire reference_Fout_10__drv;
wire reference_Fout_11__drv;
wire reference_Fout_12__drv;
wire reference_Fout_13__drv;
wire reference_Fout_14__drv;
wire reference_Fout_15__drv;
wire reference_Fout_16__drv;
wire reference_Fout_17__drv;
wire reference_MemError__drv;
wire reference_Sout_00__drv;
wire reference_Sout_01__drv;
wire reference_Sout_02__drv;
wire reference_Sout_03__drv;
wire reference_Sout_04__drv;
wire reference_Sout_05__drv;
wire reference_Sout_06__drv;
wire reference_Sout_07__drv;
wire reference_Sout_08__drv;
wire reference_Sout_09__drv;
wire reference_Sout_10__drv;
wire reference_Sout_11__drv;
wire reference_Sout_12__drv;
wire reference_Sout_13__drv;
wire reference_Sout_14__drv;
wire reference_Sout_15__drv;
wire reference_dMD_00__drv;
wire reference_dMD_01__drv;
wire reference_dMD_02__drv;
wire reference_dMD_03__drv;
wire reference_dMD_04__drv;
wire reference_dMD_05__drv;
wire reference_dMD_06__drv;
wire reference_dMD_07__drv;
wire reference_dMD_08__drv;
wire reference_dMD_09__drv;
wire reference_dMD_10__drv;
wire reference_dMD_11__drv;
wire reference_dMD_12__drv;
wire reference_dMD_13__drv;
wire reference_dMD_14__drv;
wire reference_dMD_15__drv;
wire reference_dMD_16__drv;
wire reference_dMD_17__drv;
wire reference_dSTPerr__drv;
MemD_full_snapshot_experiment #(.SYSPER(4),.STORAGE_INPUT_DELAY(2)) reference(
.sys_clk(clk),
.BMux_00(stimulus[0] | reference_BMux_00__drv),
.BMux_01(stimulus[1] | reference_BMux_01__drv),
.BMux_02(stimulus[2] | reference_BMux_02__drv),
.BMux_03(stimulus[3] | reference_BMux_03__drv),
.BMux_04(stimulus[4] | reference_BMux_04__drv),
.BMux_05(stimulus[5] | reference_BMux_05__drv),
.BMux_06(stimulus[6] | reference_BMux_06__drv),
.BMux_07(stimulus[7] | reference_BMux_07__drv),
.BMux_08(stimulus[8] | reference_BMux_08__drv),
.BMux_09(stimulus[9] | reference_BMux_09__drv),
.BMux_10(stimulus[10] | reference_BMux_10__drv),
.BMux_11(stimulus[11] | reference_BMux_11__drv),
.BMux_12(stimulus[12] | reference_BMux_12__drv),
.BMux_13(stimulus[13] | reference_BMux_13__drv),
.BMux_14(stimulus[14] | reference_BMux_14__drv),
.BMux_15(stimulus[15] | reference_BMux_15__drv),
.BMux_16(stimulus[16]),
.BMux_17(stimulus[17]),
.CLK_md_p_(stimulus[18]),
.DMuxClk(stimulus[19]),
.DMuxData(stimulus[20] | reference_DMuxData__drv),
.Dad_00(stimulus[21]),
.Dad_01(stimulus[22]),
.Dbuf_u__p_(stimulus[23]),
.ECFault(stimulus[24] | reference_ECFault__drv),
.EcIn_0(stimulus[25]),
.EcIn_1(stimulus[26]),
.EnableFG_p_(stimulus[27]),
.ErrorsFromEc2(stimulus[28]),
.FastD_u_Dbuf(stimulus[29]),
.Fin_00(stimulus[30]),
.Fin_01(stimulus[31]),
.Fin_02(stimulus[32]),
.Fin_03(stimulus[33]),
.Fin_04(stimulus[34]),
.Fin_05(stimulus[35]),
.Fin_06(stimulus[36]),
.Fin_07(stimulus[37]),
.Fin_08(stimulus[38]),
.Fin_09(stimulus[39]),
.Fin_10(stimulus[40]),
.Fin_11(stimulus[41]),
.Fin_12(stimulus[42]),
.Fin_13(stimulus[43]),
.Fin_14(stimulus[44]),
.Fin_15(stimulus[45]),
.Fin_16(stimulus[46]),
.Fin_17(stimulus[47]),
.Fout_00(stimulus[48] | reference_Fout_00__drv),
.GDv_p_(stimulus[49]),
.GLd_p_(stimulus[50]),
.MakeD_u_CD(stimulus[51]),
.MakeD_u_Dbuf(stimulus[52]),
.MakeF_u_D(stimulus[53]),
.MakeFout_u_D(stimulus[54]),
.MakeMDM_u_D_p_(stimulus[55]),
.MakeMD_u_D_p_(stimulus[56]),
.MakeSout_u_D(stimulus[57]),
.McrD_u__p_(stimulus[58]),
.MemClkEnable_p_a(stimulus[59]),
.MemError(stimulus[60] | reference_MemError__drv),
.MemSH(stimulus[61]),
.PcFG_15(stimulus[62]),
.Sin_00(stimulus[63]),
.Sin_01(stimulus[64]),
.Sin_02(stimulus[65]),
.Sin_03(stimulus[66]),
.Sin_04(stimulus[67]),
.Sin_05(stimulus[68]),
.Sin_06(stimulus[69]),
.Sin_07(stimulus[70]),
.Sin_08(stimulus[71]),
.Sin_09(stimulus[72]),
.Sin_10(stimulus[73]),
.Sin_11(stimulus[74]),
.Sin_12(stimulus[75]),
.Sin_13(stimulus[76]),
.Sin_14(stimulus[77]),
.Sin_15(stimulus[78]),
.StartEcChk_p_(stimulus[79]),
.StartEcGen_p_(stimulus[80]),
.TempRef(stimulus[81]),
.Transport_p_(stimulus[82]),
._u_Dbuf(stimulus[83]),
._u_Pipe4(stimulus[84]),
.dDad_02(stimulus[85]),
.dDad_03(stimulus[86]),
.dDad_04(stimulus[87]),
.dDad_05(stimulus[88]),
.dDad_06(stimulus[89]),
.dDad_07(stimulus[90]),
.dDad_08(stimulus[91]),
.dDad_09(stimulus[92]),
.dDad_10(stimulus[93]),
.dDad_11(stimulus[94]),
.dDad_12(stimulus[95]),
.dDad_13(stimulus[96]),
.dMD_00(stimulus[97] | reference_dMD_00__drv),
.dMDMad_0_p_(stimulus[98]),
.dMDMad_1_p_(stimulus[99]),
.dMDMad_2_p_(stimulus[100]),
.dMDMad_3_p_(stimulus[101]),
.dPipe34Ad_0(stimulus[102]),
.dPipe34Ad_1(stimulus[103]),
.dPipe34Ad_2(stimulus[104]),
.dPipe34Ad_3(stimulus[105]),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.DMuxData__drv(reference_DMuxData__drv),
.ECFault__drv(reference_ECFault__drv),
.EcOut_0__drv(reference_EcOut_0__drv),
.EcOut_1__drv(reference_EcOut_1__drv),
.EcOut_2__drv(reference_EcOut_2__drv),
.EcOut_3__drv(reference_EcOut_3__drv),
.EcOut_4__drv(reference_EcOut_4__drv),
.EcOut_5__drv(reference_EcOut_5__drv),
.EcOut_6__drv(reference_EcOut_6__drv),
.EcOut_7_p___drv(reference_EcOut_7_p___drv),
.FG_0__drv(reference_FG_0__drv),
.FG_1__drv(reference_FG_1__drv),
.FG_2__drv(reference_FG_2__drv),
.FG_3__drv(reference_FG_3__drv),
.FG_4__drv(reference_FG_4__drv),
.FG_5__drv(reference_FG_5__drv),
.FG_6__drv(reference_FG_6__drv),
.FG_7__drv(reference_FG_7__drv),
.FG_8__drv(reference_FG_8__drv),
.Fout_00__drv(reference_Fout_00__drv),
.Fout_01__drv(reference_Fout_01__drv),
.Fout_02__drv(reference_Fout_02__drv),
.Fout_03__drv(reference_Fout_03__drv),
.Fout_04__drv(reference_Fout_04__drv),
.Fout_05__drv(reference_Fout_05__drv),
.Fout_06__drv(reference_Fout_06__drv),
.Fout_07__drv(reference_Fout_07__drv),
.Fout_08__drv(reference_Fout_08__drv),
.Fout_09__drv(reference_Fout_09__drv),
.Fout_10__drv(reference_Fout_10__drv),
.Fout_11__drv(reference_Fout_11__drv),
.Fout_12__drv(reference_Fout_12__drv),
.Fout_13__drv(reference_Fout_13__drv),
.Fout_14__drv(reference_Fout_14__drv),
.Fout_15__drv(reference_Fout_15__drv),
.Fout_16__drv(reference_Fout_16__drv),
.Fout_17__drv(reference_Fout_17__drv),
.MemError__drv(reference_MemError__drv),
.Sout_00__drv(reference_Sout_00__drv),
.Sout_01__drv(reference_Sout_01__drv),
.Sout_02__drv(reference_Sout_02__drv),
.Sout_03__drv(reference_Sout_03__drv),
.Sout_04__drv(reference_Sout_04__drv),
.Sout_05__drv(reference_Sout_05__drv),
.Sout_06__drv(reference_Sout_06__drv),
.Sout_07__drv(reference_Sout_07__drv),
.Sout_08__drv(reference_Sout_08__drv),
.Sout_09__drv(reference_Sout_09__drv),
.Sout_10__drv(reference_Sout_10__drv),
.Sout_11__drv(reference_Sout_11__drv),
.Sout_12__drv(reference_Sout_12__drv),
.Sout_13__drv(reference_Sout_13__drv),
.Sout_14__drv(reference_Sout_14__drv),
.Sout_15__drv(reference_Sout_15__drv),
.dMD_00__drv(reference_dMD_00__drv),
.dMD_01__drv(reference_dMD_01__drv),
.dMD_02__drv(reference_dMD_02__drv),
.dMD_03__drv(reference_dMD_03__drv),
.dMD_04__drv(reference_dMD_04__drv),
.dMD_05__drv(reference_dMD_05__drv),
.dMD_06__drv(reference_dMD_06__drv),
.dMD_07__drv(reference_dMD_07__drv),
.dMD_08__drv(reference_dMD_08__drv),
.dMD_09__drv(reference_dMD_09__drv),
.dMD_10__drv(reference_dMD_10__drv),
.dMD_11__drv(reference_dMD_11__drv),
.dMD_12__drv(reference_dMD_12__drv),
.dMD_13__drv(reference_dMD_13__drv),
.dMD_14__drv(reference_dMD_14__drv),
.dMD_15__drv(reference_dMD_15__drv),
.dMD_16__drv(reference_dMD_16__drv),
.dMD_17__drv(reference_dMD_17__drv),
.dSTPerr__drv(reference_dSTPerr__drv),
.state_host_clk(clk),
.state_guest_advance(original_step),
.state_freeze(freeze || all_hold),
.state_guest_held(held || all_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[19:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_dSTPerr__drv,reference_dMD_17__drv,reference_dMD_16__drv,reference_dMD_15__drv,reference_dMD_14__drv,reference_dMD_13__drv,reference_dMD_12__drv,reference_dMD_11__drv,reference_dMD_10__drv,reference_dMD_09__drv,reference_dMD_08__drv,reference_dMD_07__drv,reference_dMD_06__drv,reference_dMD_05__drv,reference_dMD_04__drv,reference_dMD_03__drv,reference_dMD_02__drv,reference_dMD_01__drv,reference_dMD_00__drv,reference_Sout_15__drv,reference_Sout_14__drv,reference_Sout_13__drv,reference_Sout_12__drv,reference_Sout_11__drv,reference_Sout_10__drv,reference_Sout_09__drv,reference_Sout_08__drv,reference_Sout_07__drv,reference_Sout_06__drv,reference_Sout_05__drv,reference_Sout_04__drv,reference_Sout_03__drv,reference_Sout_02__drv,reference_Sout_01__drv,reference_Sout_00__drv,reference_MemError__drv,reference_Fout_17__drv,reference_Fout_16__drv,reference_Fout_15__drv,reference_Fout_14__drv,reference_Fout_13__drv,reference_Fout_12__drv,reference_Fout_11__drv,reference_Fout_10__drv,reference_Fout_09__drv,reference_Fout_08__drv,reference_Fout_07__drv,reference_Fout_06__drv,reference_Fout_05__drv,reference_Fout_04__drv,reference_Fout_03__drv,reference_Fout_02__drv,reference_Fout_01__drv,reference_Fout_00__drv,reference_FG_8__drv,reference_FG_7__drv,reference_FG_6__drv,reference_FG_5__drv,reference_FG_4__drv,reference_FG_3__drv,reference_FG_2__drv,reference_FG_1__drv,reference_FG_0__drv,reference_EcOut_7_p___drv,reference_EcOut_6__drv,reference_EcOut_5__drv,reference_EcOut_4__drv,reference_EcOut_3__drv,reference_EcOut_2__drv,reference_EcOut_1__drv,reference_EcOut_0__drv,reference_ECFault__drv,reference_DMuxData__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv};
assign reference_state[0+:1]=reference.Fclk_p_a;
assign reference_state[1+:1]=reference.Fclk_p_b;
assign reference_state[2+:1]=reference.clk1_p_Aa;
assign reference_state[3+:1]=reference.clk1_p_Ab;
assign reference_state[4+:1]=reference.clk1_p_Ac;
assign reference_state[5+:1]=reference.clk1_p_Ba;
assign reference_state[6+:1]=reference.clk1_p_Bb;
assign reference_state[7+:1]=reference.clk1_p_Ca;
assign reference_state[8+:1]=reference.clk1_p_Cb;
assign reference_state[9+:1]=reference.clk1_p_Cc;
assign reference_state[10+:6]=reference.snapshot_bank_0.saved_q;
assign reference_state[16+:3]=reference.snapshot_bank_1.saved_q;
assign reference_state[19+:3]=reference.snapshot_bank_10.saved_q;
assign reference_state[22+:6]=reference.snapshot_bank_11.saved_q;
assign reference_state[28+:3]=reference.snapshot_bank_12.saved_q;
assign reference_state[31+:6]=reference.snapshot_bank_13.saved_q;
assign reference_state[37+:6]=reference.snapshot_bank_2.saved_q;
assign reference_state[43+:3]=reference.snapshot_bank_3.saved_q;
assign reference_state[46+:6]=reference.snapshot_bank_4.saved_q;
assign reference_state[52+:3]=reference.snapshot_bank_5.saved_q;
assign reference_state[55+:9]=reference.snapshot_bank_6.saved_q;
assign reference_state[64+:9]=reference.snapshot_bank_7.saved_q;
assign reference_state[73+:3]=reference.snapshot_bank_8.saved_q;
assign reference_state[76+:6]=reference.snapshot_bank_9.saved_q;
assign reference_state[82+:1]=reference.storage_rx_pipeline.clock_d;
assign reference_state[83+:36]={reference.storage_rx_pipeline.words[1],reference.storage_rx_pipeline.words[0]};
assign reference_state[119+:1]=reference.u_a01.cka_d;
assign reference_state[120+:1]=reference.u_a01.ckb_d;
assign reference_state[121+:1]=reference.u_a01.d_pre_a;
assign reference_state[122+:1]=reference.u_a01.d_pre_b;
assign reference_state[123+:1]=reference.u_a01.qa;
assign reference_state[124+:1]=reference.u_a01.qb;
assign reference_state[125+:1]=reference.u_a02.cka_d;
assign reference_state[126+:1]=reference.u_a02.ckb_d;
assign reference_state[127+:1]=reference.u_a02.d_pre_a;
assign reference_state[128+:1]=reference.u_a02.d_pre_b;
assign reference_state[129+:1]=reference.u_a02.qa;
assign reference_state[130+:1]=reference.u_a02.qb;
assign reference_state[131+:4]=reference.u_a06.a_lat;
assign reference_state[135+:1]=reference.u_a06.ce_lat;
assign reference_state[136+:4]=reference.u_a06.d_lat;
assign reference_state[140+:64]={reference.u_a06.mem[15],reference.u_a06.mem[14],reference.u_a06.mem[13],reference.u_a06.mem[12],reference.u_a06.mem[11],reference.u_a06.mem[10],reference.u_a06.mem[9],reference.u_a06.mem[8],reference.u_a06.mem[7],reference.u_a06.mem[6],reference.u_a06.mem[5],reference.u_a06.mem[4],reference.u_a06.mem[3],reference.u_a06.mem[2],reference.u_a06.mem[1],reference.u_a06.mem[0]};
assign reference_state[204+:1]=reference.u_a06.we_d;
assign reference_state[205+:1]=reference.u_a08.ck_d;
assign reference_state[206+:4]=reference.u_a08.q;
assign reference_state[210+:6]=reference.u_a08.setup_pre;
assign reference_state[216+:1]=reference.u_a10.ck_d;
assign reference_state[217+:6]=reference.u_a10.d_pre;
assign reference_state[223+:6]=reference.u_a10.q;
assign reference_state[229+:1]=reference.u_a12.ck_d;
assign reference_state[230+:6]=reference.u_a12.d_pre;
assign reference_state[236+:6]=reference.u_a12.q;
assign reference_state[242+:1]=reference.u_a18.ck_d;
assign reference_state[243+:4]=reference.u_a18.d_pre;
assign reference_state[247+:4]=reference.u_a18.q;
assign reference_state[251+:1]=reference.u_a20.ck_d;
assign reference_state[252+:4]=reference.u_a20.q;
assign reference_state[256+:6]=reference.u_a20.setup_pre;
assign reference_state[262+:1]=reference.u_a23.ck_d;
assign reference_state[263+:4]=reference.u_a23.q;
assign reference_state[267+:6]=reference.u_a23.setup_pre;
assign reference_state[273+:1]=reference.u_a24.cka_d;
assign reference_state[274+:1]=reference.u_a24.ckb_d;
assign reference_state[275+:1]=reference.u_a24.d_pre_a;
assign reference_state[276+:1]=reference.u_a24.d_pre_b;
assign reference_state[277+:1]=reference.u_a24.qa;
assign reference_state[278+:1]=reference.u_a24.qb;
assign reference_state[279+:5]=reference.u_b01.q;
assign reference_state[284+:4]=reference.u_b05.a_lat;
assign reference_state[288+:1]=reference.u_b05.ce_lat;
assign reference_state[289+:4]=reference.u_b05.d_lat;
assign reference_state[293+:64]={reference.u_b05.mem[15],reference.u_b05.mem[14],reference.u_b05.mem[13],reference.u_b05.mem[12],reference.u_b05.mem[11],reference.u_b05.mem[10],reference.u_b05.mem[9],reference.u_b05.mem[8],reference.u_b05.mem[7],reference.u_b05.mem[6],reference.u_b05.mem[5],reference.u_b05.mem[4],reference.u_b05.mem[3],reference.u_b05.mem[2],reference.u_b05.mem[1],reference.u_b05.mem[0]};
assign reference_state[357+:1]=reference.u_b05.we_d;
assign reference_state[358+:4]=reference.u_b06.a_lat;
assign reference_state[362+:1]=reference.u_b06.ce_lat;
assign reference_state[363+:4]=reference.u_b06.d_lat;
assign reference_state[367+:64]={reference.u_b06.mem[15],reference.u_b06.mem[14],reference.u_b06.mem[13],reference.u_b06.mem[12],reference.u_b06.mem[11],reference.u_b06.mem[10],reference.u_b06.mem[9],reference.u_b06.mem[8],reference.u_b06.mem[7],reference.u_b06.mem[6],reference.u_b06.mem[5],reference.u_b06.mem[4],reference.u_b06.mem[3],reference.u_b06.mem[2],reference.u_b06.mem[1],reference.u_b06.mem[0]};
assign reference_state[431+:1]=reference.u_b06.we_d;
assign reference_state[432+:1]=reference.u_b09.ck_d;
assign reference_state[433+:4]=reference.u_b09.q;
assign reference_state[437+:6]=reference.u_b09.setup_pre;
assign reference_state[443+:1]=reference.u_b10.ck_d;
assign reference_state[444+:6]=reference.u_b10.d_pre;
assign reference_state[450+:6]=reference.u_b10.q;
assign reference_state[456+:1]=reference.u_b12.ck_d;
assign reference_state[457+:6]=reference.u_b12.d_pre;
assign reference_state[463+:6]=reference.u_b12.q;
assign reference_state[469+:1]=reference.u_b18.cka_d;
assign reference_state[470+:1]=reference.u_b18.ckb_d;
assign reference_state[471+:1]=reference.u_b18.d_pre_a;
assign reference_state[472+:1]=reference.u_b18.d_pre_b;
assign reference_state[473+:1]=reference.u_b18.qa;
assign reference_state[474+:1]=reference.u_b18.qb;
assign reference_state[475+:1]=reference.u_b19.cka_d;
assign reference_state[476+:1]=reference.u_b19.ckb_d;
assign reference_state[477+:1]=reference.u_b19.d_pre_a;
assign reference_state[478+:1]=reference.u_b19.d_pre_b;
assign reference_state[479+:1]=reference.u_b19.qa;
assign reference_state[480+:1]=reference.u_b19.qb;
assign reference_state[481+:1]=reference.u_b20.ck_d;
assign reference_state[482+:4]=reference.u_b20.d_pre;
assign reference_state[486+:4]=reference.u_b20.q;
assign reference_state[490+:1]=reference.u_b23.ck_d;
assign reference_state[491+:4]=reference.u_b23.q;
assign reference_state[495+:6]=reference.u_b23.setup_pre;
assign reference_state[501+:1]=reference.u_b24.cka_d;
assign reference_state[502+:1]=reference.u_b24.ckb_d;
assign reference_state[503+:1]=reference.u_b24.d_pre_a;
assign reference_state[504+:1]=reference.u_b24.d_pre_b;
assign reference_state[505+:1]=reference.u_b24.qa;
assign reference_state[506+:1]=reference.u_b24.qb;
assign reference_state[507+:5]=reference.u_c01.q;
assign reference_state[512+:1]=reference.u_c02.ck_d;
assign reference_state[513+:6]=reference.u_c02.d_pre;
assign reference_state[519+:6]=reference.u_c02.q;
assign reference_state[525+:1]=reference.u_c10.ck_d;
assign reference_state[526+:6]=reference.u_c10.d_pre;
assign reference_state[532+:6]=reference.u_c10.q;
assign reference_state[538+:1]=reference.u_c12.ck_d;
assign reference_state[539+:6]=reference.u_c12.d_pre;
assign reference_state[545+:6]=reference.u_c12.q;
assign reference_state[551+:1]=reference.u_c20.ck_d;
assign reference_state[552+:4]=reference.u_c20.d_pre;
assign reference_state[556+:4]=reference.u_c20.q;
assign reference_state[560+:1]=reference.u_c21.cka_d;
assign reference_state[561+:1]=reference.u_c21.ckb_d;
assign reference_state[562+:1]=reference.u_c21.d_pre_a;
assign reference_state[563+:1]=reference.u_c21.d_pre_b;
assign reference_state[564+:1]=reference.u_c21.qa;
assign reference_state[565+:1]=reference.u_c21.qb;
assign reference_state[566+:1]=reference.u_c23.ck_d;
assign reference_state[567+:4]=reference.u_c23.q;
assign reference_state[571+:6]=reference.u_c23.setup_pre;
assign reference_state[577+:1]=reference.u_c24.ck_d;
assign reference_state[578+:6]=reference.u_c24.d_pre;
assign reference_state[584+:6]=reference.u_c24.q;
assign reference_state[590+:1]=reference.u_d01.ck_d;
assign reference_state[591+:6]=reference.u_d01.d_pre;
assign reference_state[597+:6]=reference.u_d01.q;
assign reference_state[603+:1]=reference.u_d10.ck_d;
assign reference_state[604+:6]=reference.u_d10.d_pre;
assign reference_state[610+:6]=reference.u_d10.q;
assign reference_state[616+:1]=reference.u_d12.ck_d;
assign reference_state[617+:6]=reference.u_d12.d_pre;
assign reference_state[623+:6]=reference.u_d12.q;
assign reference_state[629+:1]=reference.u_d14.ck_d;
assign reference_state[630+:4]=reference.u_d14.q;
assign reference_state[634+:6]=reference.u_d14.setup_pre;
assign reference_state[640+:5]=reference.u_e01.q;
assign reference_state[645+:1]=reference.u_e06.ck_d;
assign reference_state[646+:6]=reference.u_e06.d_pre;
assign reference_state[652+:6]=reference.u_e06.q;
assign reference_state[658+:1]=reference.u_e09.ck_d;
assign reference_state[659+:4]=reference.u_e09.q;
assign reference_state[663+:6]=reference.u_e09.setup_pre;
assign reference_state[669+:1]=reference.u_e10.ck_d;
assign reference_state[670+:6]=reference.u_e10.d_pre;
assign reference_state[676+:6]=reference.u_e10.q;
assign reference_state[682+:1]=reference.u_e12.ck_d;
assign reference_state[683+:6]=reference.u_e12.d_pre;
assign reference_state[689+:6]=reference.u_e12.q;
assign reference_state[695+:1]=reference.u_e13.ck_d;
assign reference_state[696+:4]=reference.u_e13.d_pre;
assign reference_state[700+:4]=reference.u_e13.q;
assign reference_state[704+:1]=reference.u_e14.ck_d;
assign reference_state[705+:4]=reference.u_e14.q;
assign reference_state[709+:6]=reference.u_e14.setup_pre;
assign reference_state[715+:1]=reference.u_e17.ck_d;
assign reference_state[716+:6]=reference.u_e17.d_pre;
assign reference_state[722+:6]=reference.u_e17.q;
assign reference_state[728+:1]=reference.u_e18.ck_d;
assign reference_state[729+:4]=reference.u_e18.q;
assign reference_state[733+:6]=reference.u_e18.setup_pre;
assign reference_state[739+:1]=reference.u_e20.ck_d;
assign reference_state[740+:6]=reference.u_e20.d_pre;
assign reference_state[746+:6]=reference.u_e20.q;
assign reference_state[752+:1]=reference.u_e21.ck_d;
assign reference_state[753+:6]=reference.u_e21.d_pre;
assign reference_state[759+:6]=reference.u_e21.q;
assign reference_state[765+:1]=reference.u_e22.ck_d;
assign reference_state[766+:6]=reference.u_e22.d_pre;
assign reference_state[772+:6]=reference.u_e22.q;
assign reference_state[778+:5]=reference.u_f01.q;
assign reference_state[783+:1]=reference.u_f06.ck_d;
assign reference_state[784+:6]=reference.u_f06.d_pre;
assign reference_state[790+:6]=reference.u_f06.q;
assign reference_state[796+:1]=reference.u_f10.ck_d;
assign reference_state[797+:6]=reference.u_f10.d_pre;
assign reference_state[803+:6]=reference.u_f10.q;
assign reference_state[809+:1]=reference.u_f14.ck_d;
assign reference_state[810+:6]=reference.u_f14.d_pre;
assign reference_state[816+:6]=reference.u_f14.q;
assign reference_state[822+:1]=reference.u_f18.ck_d;
assign reference_state[823+:6]=reference.u_f18.d_pre;
assign reference_state[829+:6]=reference.u_f18.q;
assign reference_state[835+:1]=reference.u_f20.ck_d;
assign reference_state[836+:4]=reference.u_f20.q;
assign reference_state[840+:6]=reference.u_f20.setup_pre;
assign reference_state[846+:1]=reference.u_f22.ck_d;
assign reference_state[847+:4]=reference.u_f22.q;
assign reference_state[851+:6]=reference.u_f22.setup_pre;
assign reference_state[857+:1]=reference.u_f24.ck_d;
assign reference_state[858+:6]=reference.u_f24.d_pre;
assign reference_state[864+:6]=reference.u_f24.q;
assign reference_state[870+:1]=reference.u_g01.cka_d;
assign reference_state[871+:1]=reference.u_g01.ckb_d;
assign reference_state[872+:1]=reference.u_g01.d_pre_a;
assign reference_state[873+:1]=reference.u_g01.d_pre_b;
assign reference_state[874+:1]=reference.u_g01.qa;
assign reference_state[875+:1]=reference.u_g01.qb;
assign reference_state[876+:1]=reference.u_g02.cka_d;
assign reference_state[877+:1]=reference.u_g02.ckb_d;
assign reference_state[878+:1]=reference.u_g02.d_pre_a;
assign reference_state[879+:1]=reference.u_g02.d_pre_b;
assign reference_state[880+:1]=reference.u_g02.qa;
assign reference_state[881+:1]=reference.u_g02.qb;
assign reference_state[882+:1]=reference.u_g16.ck_d;
assign reference_state[883+:6]=reference.u_g16.d_pre;
assign reference_state[889+:6]=reference.u_g16.q;
assign reference_state[895+:1]=reference.u_g20.ck_d;
assign reference_state[896+:4]=reference.u_g20.q;
assign reference_state[900+:6]=reference.u_g20.setup_pre;
assign reference_state[906+:1]=reference.u_g22.cka_d;
assign reference_state[907+:1]=reference.u_g22.ckb_d;
assign reference_state[908+:1]=reference.u_g22.d_pre_a;
assign reference_state[909+:1]=reference.u_g22.d_pre_b;
assign reference_state[910+:1]=reference.u_g22.qa;
assign reference_state[911+:1]=reference.u_g22.qb;
assign reference_state[912+:1]=reference.u_g24.ck_d;
assign reference_state[913+:6]=reference.u_g24.d_pre;
assign reference_state[919+:6]=reference.u_g24.q;
assign reference_state[925+:1]=reference.u_h01.cka_d;
assign reference_state[926+:1]=reference.u_h01.ckb_d;
assign reference_state[927+:1]=reference.u_h01.d_pre_a;
assign reference_state[928+:1]=reference.u_h01.d_pre_b;
assign reference_state[929+:1]=reference.u_h01.qa;
assign reference_state[930+:1]=reference.u_h01.qb;
assign reference_state[931+:1]=reference.u_h02.cka_d;
assign reference_state[932+:1]=reference.u_h02.ckb_d;
assign reference_state[933+:1]=reference.u_h02.d_pre_a;
assign reference_state[934+:1]=reference.u_h02.d_pre_b;
assign reference_state[935+:1]=reference.u_h02.qa;
assign reference_state[936+:1]=reference.u_h02.qb;
assign reference_state[937+:1]=reference.u_h03.ck_d;
assign reference_state[938+:6]=reference.u_h03.d_pre;
assign reference_state[944+:6]=reference.u_h03.q;
assign reference_state[950+:4]=reference.u_h04.a_lat;
assign reference_state[954+:1]=reference.u_h04.ce_lat;
assign reference_state[955+:4]=reference.u_h04.d_lat;
assign reference_state[959+:64]={reference.u_h04.mem[15],reference.u_h04.mem[14],reference.u_h04.mem[13],reference.u_h04.mem[12],reference.u_h04.mem[11],reference.u_h04.mem[10],reference.u_h04.mem[9],reference.u_h04.mem[8],reference.u_h04.mem[7],reference.u_h04.mem[6],reference.u_h04.mem[5],reference.u_h04.mem[4],reference.u_h04.mem[3],reference.u_h04.mem[2],reference.u_h04.mem[1],reference.u_h04.mem[0]};
assign reference_state[1023+:1]=reference.u_h04.we_d;
assign reference_state[1024+:4]=reference.u_h06.a_lat;
assign reference_state[1028+:1]=reference.u_h06.ce_lat;
assign reference_state[1029+:4]=reference.u_h06.d_lat;
assign reference_state[1033+:64]={reference.u_h06.mem[15],reference.u_h06.mem[14],reference.u_h06.mem[13],reference.u_h06.mem[12],reference.u_h06.mem[11],reference.u_h06.mem[10],reference.u_h06.mem[9],reference.u_h06.mem[8],reference.u_h06.mem[7],reference.u_h06.mem[6],reference.u_h06.mem[5],reference.u_h06.mem[4],reference.u_h06.mem[3],reference.u_h06.mem[2],reference.u_h06.mem[1],reference.u_h06.mem[0]};
assign reference_state[1097+:1]=reference.u_h06.we_d;
assign reference_state[1098+:1]=reference.u_h07.ck_d;
assign reference_state[1099+:4]=reference.u_h07.q;
assign reference_state[1103+:6]=reference.u_h07.setup_pre;
assign reference_state[1109+:4]=reference.u_h11.a_lat;
assign reference_state[1113+:1]=reference.u_h11.ce_lat;
assign reference_state[1114+:4]=reference.u_h11.d_lat;
assign reference_state[1118+:64]={reference.u_h11.mem[15],reference.u_h11.mem[14],reference.u_h11.mem[13],reference.u_h11.mem[12],reference.u_h11.mem[11],reference.u_h11.mem[10],reference.u_h11.mem[9],reference.u_h11.mem[8],reference.u_h11.mem[7],reference.u_h11.mem[6],reference.u_h11.mem[5],reference.u_h11.mem[4],reference.u_h11.mem[3],reference.u_h11.mem[2],reference.u_h11.mem[1],reference.u_h11.mem[0]};
assign reference_state[1182+:1]=reference.u_h11.we_d;
assign reference_state[1183+:1]=reference.u_h12.ck_d;
assign reference_state[1184+:4]=reference.u_h12.d_pre;
assign reference_state[1188+:1]=reference.u_h12.dl_pre;
assign reference_state[1189+:1]=reference.u_h12.dr_pre;
assign reference_state[1190+:4]=reference.u_h12.q;
assign reference_state[1194+:2]=reference.u_h12.s_pre;
assign reference_state[1196+:4]=reference.u_h15.a_lat;
assign reference_state[1200+:1]=reference.u_h15.ce_lat;
assign reference_state[1201+:4]=reference.u_h15.d_lat;
assign reference_state[1205+:64]={reference.u_h15.mem[15],reference.u_h15.mem[14],reference.u_h15.mem[13],reference.u_h15.mem[12],reference.u_h15.mem[11],reference.u_h15.mem[10],reference.u_h15.mem[9],reference.u_h15.mem[8],reference.u_h15.mem[7],reference.u_h15.mem[6],reference.u_h15.mem[5],reference.u_h15.mem[4],reference.u_h15.mem[3],reference.u_h15.mem[2],reference.u_h15.mem[1],reference.u_h15.mem[0]};
assign reference_state[1269+:1]=reference.u_h15.we_d;
assign reference_state[1270+:4]=reference.u_h17.a_lat;
assign reference_state[1274+:1]=reference.u_h17.ce_lat;
assign reference_state[1275+:4]=reference.u_h17.d_lat;
assign reference_state[1279+:64]={reference.u_h17.mem[15],reference.u_h17.mem[14],reference.u_h17.mem[13],reference.u_h17.mem[12],reference.u_h17.mem[11],reference.u_h17.mem[10],reference.u_h17.mem[9],reference.u_h17.mem[8],reference.u_h17.mem[7],reference.u_h17.mem[6],reference.u_h17.mem[5],reference.u_h17.mem[4],reference.u_h17.mem[3],reference.u_h17.mem[2],reference.u_h17.mem[1],reference.u_h17.mem[0]};
assign reference_state[1343+:1]=reference.u_h17.we_d;
assign reference_state[1344+:1]=reference.u_h20.ck_d;
assign reference_state[1345+:4]=reference.u_h20.q;
assign reference_state[1349+:6]=reference.u_h20.setup_pre;
assign reference_state[1355+:1]=reference.u_i01.ck_d;
assign reference_state[1356+:6]=reference.u_i01.d_pre;
assign reference_state[1362+:6]=reference.u_i01.q;
assign reference_state[1368+:1]=reference.u_i02.ck_d;
assign reference_state[1369+:6]=reference.u_i02.d_pre;
assign reference_state[1375+:6]=reference.u_i02.q;
assign reference_state[1381+:1]=reference.u_i16.ck_d;
assign reference_state[1382+:6]=reference.u_i16.d_pre;
assign reference_state[1388+:6]=reference.u_i16.q;
assign reference_state[1394+:1]=reference.u_i20.ck_d;
assign reference_state[1395+:6]=reference.u_i20.d_pre;
assign reference_state[1401+:6]=reference.u_i20.q;
assign reference_state[1407+:1]=reference.u_i21.ck_d;
assign reference_state[1408+:4]=reference.u_i21.q;
assign reference_state[1412+:6]=reference.u_i21.setup_pre;
assign reference_state[1418+:1]=reference.u_i23.cka_d;
assign reference_state[1419+:1]=reference.u_i23.ckb_d;
assign reference_state[1420+:1]=reference.u_i23.d_pre_a;
assign reference_state[1421+:1]=reference.u_i23.d_pre_b;
assign reference_state[1422+:1]=reference.u_i23.qa;
assign reference_state[1423+:1]=reference.u_i23.qb;
assign reference_state[1424+:1]=reference.u_i24.ck_d;
assign reference_state[1425+:6]=reference.u_i24.d_pre;
assign reference_state[1431+:6]=reference.u_i24.q;
assign reference_state[1437+:1]=reference.u_j01.cka_d;
assign reference_state[1438+:1]=reference.u_j01.ckb_d;
assign reference_state[1439+:1]=reference.u_j01.d_pre_a;
assign reference_state[1440+:1]=reference.u_j01.d_pre_b;
assign reference_state[1441+:1]=reference.u_j01.qa;
assign reference_state[1442+:1]=reference.u_j01.qb;
assign reference_state[1443+:1]=reference.u_j02.ck_d;
assign reference_state[1444+:6]=reference.u_j02.d_pre;
assign reference_state[1450+:6]=reference.u_j02.q;
assign reference_state[1456+:1]=reference.u_j16.cka_d;
assign reference_state[1457+:1]=reference.u_j16.ckb_d;
assign reference_state[1458+:1]=reference.u_j16.d_pre_a;
assign reference_state[1459+:1]=reference.u_j16.d_pre_b;
assign reference_state[1460+:1]=reference.u_j16.qa;
assign reference_state[1461+:1]=reference.u_j16.qb;
assign reference_state[1462+:1]=reference.u_j20.ck_d;
assign reference_state[1463+:6]=reference.u_j20.d_pre;
assign reference_state[1469+:6]=reference.u_j20.q;
assign reference_state[1475+:1]=reference.u_j21.ck_d;
assign reference_state[1476+:6]=reference.u_j21.d_pre;
assign reference_state[1482+:6]=reference.u_j21.q;
assign reference_state[1488+:1]=reference.u_j22.ck_d;
assign reference_state[1489+:6]=reference.u_j22.d_pre;
assign reference_state[1495+:6]=reference.u_j22.q;
assign reference_state[1501+:1]=reference.u_j24.ck_d;
assign reference_state[1502+:6]=reference.u_j24.d_pre;
assign reference_state[1508+:6]=reference.u_j24.q;
assign reference_state[1514+:1]=reference.u_k01.cka_d;
assign reference_state[1515+:1]=reference.u_k01.ckb_d;
assign reference_state[1516+:1]=reference.u_k01.d_pre_a;
assign reference_state[1517+:1]=reference.u_k01.d_pre_b;
assign reference_state[1518+:1]=reference.u_k01.qa;
assign reference_state[1519+:1]=reference.u_k01.qb;
assign reference_state[1520+:1]=reference.u_k09.ck_d;
assign reference_state[1521+:4]=reference.u_k09.q;
assign reference_state[1525+:6]=reference.u_k09.setup_pre;
assign reference_state[1531+:1]=reference.u_k13.ck_d;
assign reference_state[1532+:6]=reference.u_k13.d_pre;
assign reference_state[1538+:6]=reference.u_k13.q;
assign reference_state[1544+:1]=reference.u_k18.ck_d;
assign reference_state[1545+:4]=reference.u_k18.d_pre;
assign reference_state[1549+:4]=reference.u_k18.q;
assign reference_state[1553+:1]=reference.u_k19.ck_d;
assign reference_state[1554+:6]=reference.u_k19.d_pre;
assign reference_state[1560+:6]=reference.u_k19.q;
assign reference_state[1566+:1]=reference.u_k20.ck_d;
assign reference_state[1567+:6]=reference.u_k20.d_pre;
assign reference_state[1573+:6]=reference.u_k20.q;
assign reference_state[1579+:1]=reference.u_k21.ck_d;
assign reference_state[1580+:6]=reference.u_k21.d_pre;
assign reference_state[1586+:6]=reference.u_k21.q;
assign reference_state[1592+:1]=reference.u_k23.ck_d;
assign reference_state[1593+:6]=reference.u_k23.d_pre;
assign reference_state[1599+:6]=reference.u_k23.q;
assign reference_state[1605+:1]=reference.u_k24.ck_d;
assign reference_state[1606+:6]=reference.u_k24.d_pre;
assign reference_state[1612+:6]=reference.u_k24.q;
assign reference_state[1618+:1]=reference.u_l02.cka_d;
assign reference_state[1619+:1]=reference.u_l02.ckb_d;
assign reference_state[1620+:1]=reference.u_l02.d_pre_a;
assign reference_state[1621+:1]=reference.u_l02.d_pre_b;
assign reference_state[1622+:1]=reference.u_l02.qa;
assign reference_state[1623+:1]=reference.u_l02.qb;
assign reference_state[1624+:1]=reference.u_l08.ck_d;
assign reference_state[1625+:4]=reference.u_l08.q;
assign reference_state[1629+:6]=reference.u_l08.setup_pre;
assign reference_state[1635+:1]=reference.u_l16.cka_d;
assign reference_state[1636+:1]=reference.u_l16.ckb_d;
assign reference_state[1637+:1]=reference.u_l16.d_pre_a;
assign reference_state[1638+:1]=reference.u_l16.d_pre_b;
assign reference_state[1639+:1]=reference.u_l16.qa;
assign reference_state[1640+:1]=reference.u_l16.qb;
assign reference_state[1641+:1]=reference.u_l20.ck_d;
assign reference_state[1642+:6]=reference.u_l20.d_pre;
assign reference_state[1648+:6]=reference.u_l20.q;
assign reference_state[1654+:1]=reference.u_l21.ck_d;
assign reference_state[1655+:6]=reference.u_l21.d_pre;
assign reference_state[1661+:6]=reference.u_l21.q;
assign reference_state[1667+:1]=reference.u_l23.cka_d;
assign reference_state[1668+:1]=reference.u_l23.ckb_d;
assign reference_state[1669+:1]=reference.u_l23.d_pre_a;
assign reference_state[1670+:1]=reference.u_l23.d_pre_b;
assign reference_state[1671+:1]=reference.u_l23.qa;
assign reference_state[1672+:1]=reference.u_l23.qb;
assign reference_state[1673+:1]=reference.u_l24.cka_d;
assign reference_state[1674+:1]=reference.u_l24.ckb_d;
assign reference_state[1675+:1]=reference.u_l24.d_pre_a;
assign reference_state[1676+:1]=reference.u_l24.d_pre_b;
assign reference_state[1677+:1]=reference.u_l24.qa;
assign reference_state[1678+:1]=reference.u_l24.qb;
assign reference_probe[0+:6]=reference.snapshot_bank_0.mem[0+(probe_index%4096)];
assign reference_probe[6+:3]=reference.snapshot_bank_1.mem[0+(probe_index%4096)];
assign reference_probe[9+:3]=reference.snapshot_bank_10.mem[0+(probe_index%4096)];
assign reference_probe[12+:6]=reference.snapshot_bank_11.mem[0+(probe_index%4096)];
assign reference_probe[18+:3]=reference.snapshot_bank_12.mem[0+(probe_index%4096)];
assign reference_probe[21+:6]=reference.snapshot_bank_13.mem[0+(probe_index%4096)];
assign reference_probe[27+:6]=reference.snapshot_bank_2.mem[0+(probe_index%4096)];
assign reference_probe[33+:3]=reference.snapshot_bank_3.mem[0+(probe_index%4096)];
assign reference_probe[36+:6]=reference.snapshot_bank_4.mem[0+(probe_index%4096)];
assign reference_probe[42+:3]=reference.snapshot_bank_5.mem[0+(probe_index%4096)];
assign reference_probe[45+:9]=reference.snapshot_bank_6.mem[0+(probe_index%4096)];
assign reference_probe[54+:9]=reference.snapshot_bank_7.mem[0+(probe_index%4096)];
assign reference_probe[63+:3]=reference.snapshot_bank_8.mem[0+(probe_index%4096)];
assign reference_probe[66+:6]=reference.snapshot_bank_9.mem[0+(probe_index%4096)];
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_DMuxData__drv;
wire dut_ECFault__drv;
wire dut_EcOut_0__drv;
wire dut_EcOut_1__drv;
wire dut_EcOut_2__drv;
wire dut_EcOut_3__drv;
wire dut_EcOut_4__drv;
wire dut_EcOut_5__drv;
wire dut_EcOut_6__drv;
wire dut_EcOut_7_p___drv;
wire dut_FG_0__drv;
wire dut_FG_1__drv;
wire dut_FG_2__drv;
wire dut_FG_3__drv;
wire dut_FG_4__drv;
wire dut_FG_5__drv;
wire dut_FG_6__drv;
wire dut_FG_7__drv;
wire dut_FG_8__drv;
wire dut_Fout_00__drv;
wire dut_Fout_01__drv;
wire dut_Fout_02__drv;
wire dut_Fout_03__drv;
wire dut_Fout_04__drv;
wire dut_Fout_05__drv;
wire dut_Fout_06__drv;
wire dut_Fout_07__drv;
wire dut_Fout_08__drv;
wire dut_Fout_09__drv;
wire dut_Fout_10__drv;
wire dut_Fout_11__drv;
wire dut_Fout_12__drv;
wire dut_Fout_13__drv;
wire dut_Fout_14__drv;
wire dut_Fout_15__drv;
wire dut_Fout_16__drv;
wire dut_Fout_17__drv;
wire dut_MemError__drv;
wire dut_Sout_00__drv;
wire dut_Sout_01__drv;
wire dut_Sout_02__drv;
wire dut_Sout_03__drv;
wire dut_Sout_04__drv;
wire dut_Sout_05__drv;
wire dut_Sout_06__drv;
wire dut_Sout_07__drv;
wire dut_Sout_08__drv;
wire dut_Sout_09__drv;
wire dut_Sout_10__drv;
wire dut_Sout_11__drv;
wire dut_Sout_12__drv;
wire dut_Sout_13__drv;
wire dut_Sout_14__drv;
wire dut_Sout_15__drv;
wire dut_dMD_00__drv;
wire dut_dMD_01__drv;
wire dut_dMD_02__drv;
wire dut_dMD_03__drv;
wire dut_dMD_04__drv;
wire dut_dMD_05__drv;
wire dut_dMD_06__drv;
wire dut_dMD_07__drv;
wire dut_dMD_08__drv;
wire dut_dMD_09__drv;
wire dut_dMD_10__drv;
wire dut_dMD_11__drv;
wire dut_dMD_12__drv;
wire dut_dMD_13__drv;
wire dut_dMD_14__drv;
wire dut_dMD_15__drv;
wire dut_dMD_16__drv;
wire dut_dMD_17__drv;
wire dut_dSTPerr__drv;
dorado_serial_MemD #(.SYSPER(4),.STORAGE_INPUT_DELAY(2)) dut(
.sys_clk(clk),
.BMux_00(stimulus[0] | dut_BMux_00__drv),
.BMux_01(stimulus[1] | dut_BMux_01__drv),
.BMux_02(stimulus[2] | dut_BMux_02__drv),
.BMux_03(stimulus[3] | dut_BMux_03__drv),
.BMux_04(stimulus[4] | dut_BMux_04__drv),
.BMux_05(stimulus[5] | dut_BMux_05__drv),
.BMux_06(stimulus[6] | dut_BMux_06__drv),
.BMux_07(stimulus[7] | dut_BMux_07__drv),
.BMux_08(stimulus[8] | dut_BMux_08__drv),
.BMux_09(stimulus[9] | dut_BMux_09__drv),
.BMux_10(stimulus[10] | dut_BMux_10__drv),
.BMux_11(stimulus[11] | dut_BMux_11__drv),
.BMux_12(stimulus[12] | dut_BMux_12__drv),
.BMux_13(stimulus[13] | dut_BMux_13__drv),
.BMux_14(stimulus[14] | dut_BMux_14__drv),
.BMux_15(stimulus[15] | dut_BMux_15__drv),
.BMux_16(stimulus[16]),
.BMux_17(stimulus[17]),
.CLK_md_p_(stimulus[18]),
.DMuxClk(stimulus[19]),
.DMuxData(stimulus[20] | dut_DMuxData__drv),
.Dad_00(stimulus[21]),
.Dad_01(stimulus[22]),
.Dbuf_u__p_(stimulus[23]),
.ECFault(stimulus[24] | dut_ECFault__drv),
.EcIn_0(stimulus[25]),
.EcIn_1(stimulus[26]),
.EnableFG_p_(stimulus[27]),
.ErrorsFromEc2(stimulus[28]),
.FastD_u_Dbuf(stimulus[29]),
.Fin_00(stimulus[30]),
.Fin_01(stimulus[31]),
.Fin_02(stimulus[32]),
.Fin_03(stimulus[33]),
.Fin_04(stimulus[34]),
.Fin_05(stimulus[35]),
.Fin_06(stimulus[36]),
.Fin_07(stimulus[37]),
.Fin_08(stimulus[38]),
.Fin_09(stimulus[39]),
.Fin_10(stimulus[40]),
.Fin_11(stimulus[41]),
.Fin_12(stimulus[42]),
.Fin_13(stimulus[43]),
.Fin_14(stimulus[44]),
.Fin_15(stimulus[45]),
.Fin_16(stimulus[46]),
.Fin_17(stimulus[47]),
.Fout_00(stimulus[48] | dut_Fout_00__drv),
.GDv_p_(stimulus[49]),
.GLd_p_(stimulus[50]),
.MakeD_u_CD(stimulus[51]),
.MakeD_u_Dbuf(stimulus[52]),
.MakeF_u_D(stimulus[53]),
.MakeFout_u_D(stimulus[54]),
.MakeMDM_u_D_p_(stimulus[55]),
.MakeMD_u_D_p_(stimulus[56]),
.MakeSout_u_D(stimulus[57]),
.McrD_u__p_(stimulus[58]),
.MemClkEnable_p_a(stimulus[59]),
.MemError(stimulus[60] | dut_MemError__drv),
.MemSH(stimulus[61]),
.PcFG_15(stimulus[62]),
.Sin_00(stimulus[63]),
.Sin_01(stimulus[64]),
.Sin_02(stimulus[65]),
.Sin_03(stimulus[66]),
.Sin_04(stimulus[67]),
.Sin_05(stimulus[68]),
.Sin_06(stimulus[69]),
.Sin_07(stimulus[70]),
.Sin_08(stimulus[71]),
.Sin_09(stimulus[72]),
.Sin_10(stimulus[73]),
.Sin_11(stimulus[74]),
.Sin_12(stimulus[75]),
.Sin_13(stimulus[76]),
.Sin_14(stimulus[77]),
.Sin_15(stimulus[78]),
.StartEcChk_p_(stimulus[79]),
.StartEcGen_p_(stimulus[80]),
.TempRef(stimulus[81]),
.Transport_p_(stimulus[82]),
._u_Dbuf(stimulus[83]),
._u_Pipe4(stimulus[84]),
.dDad_02(stimulus[85]),
.dDad_03(stimulus[86]),
.dDad_04(stimulus[87]),
.dDad_05(stimulus[88]),
.dDad_06(stimulus[89]),
.dDad_07(stimulus[90]),
.dDad_08(stimulus[91]),
.dDad_09(stimulus[92]),
.dDad_10(stimulus[93]),
.dDad_11(stimulus[94]),
.dDad_12(stimulus[95]),
.dDad_13(stimulus[96]),
.dMD_00(stimulus[97] | dut_dMD_00__drv),
.dMDMad_0_p_(stimulus[98]),
.dMDMad_1_p_(stimulus[99]),
.dMDMad_2_p_(stimulus[100]),
.dMDMad_3_p_(stimulus[101]),
.dPipe34Ad_0(stimulus[102]),
.dPipe34Ad_1(stimulus[103]),
.dPipe34Ad_2(stimulus[104]),
.dPipe34Ad_3(stimulus[105]),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.DMuxData__drv(dut_DMuxData__drv),
.ECFault__drv(dut_ECFault__drv),
.EcOut_0__drv(dut_EcOut_0__drv),
.EcOut_1__drv(dut_EcOut_1__drv),
.EcOut_2__drv(dut_EcOut_2__drv),
.EcOut_3__drv(dut_EcOut_3__drv),
.EcOut_4__drv(dut_EcOut_4__drv),
.EcOut_5__drv(dut_EcOut_5__drv),
.EcOut_6__drv(dut_EcOut_6__drv),
.EcOut_7_p___drv(dut_EcOut_7_p___drv),
.FG_0__drv(dut_FG_0__drv),
.FG_1__drv(dut_FG_1__drv),
.FG_2__drv(dut_FG_2__drv),
.FG_3__drv(dut_FG_3__drv),
.FG_4__drv(dut_FG_4__drv),
.FG_5__drv(dut_FG_5__drv),
.FG_6__drv(dut_FG_6__drv),
.FG_7__drv(dut_FG_7__drv),
.FG_8__drv(dut_FG_8__drv),
.Fout_00__drv(dut_Fout_00__drv),
.Fout_01__drv(dut_Fout_01__drv),
.Fout_02__drv(dut_Fout_02__drv),
.Fout_03__drv(dut_Fout_03__drv),
.Fout_04__drv(dut_Fout_04__drv),
.Fout_05__drv(dut_Fout_05__drv),
.Fout_06__drv(dut_Fout_06__drv),
.Fout_07__drv(dut_Fout_07__drv),
.Fout_08__drv(dut_Fout_08__drv),
.Fout_09__drv(dut_Fout_09__drv),
.Fout_10__drv(dut_Fout_10__drv),
.Fout_11__drv(dut_Fout_11__drv),
.Fout_12__drv(dut_Fout_12__drv),
.Fout_13__drv(dut_Fout_13__drv),
.Fout_14__drv(dut_Fout_14__drv),
.Fout_15__drv(dut_Fout_15__drv),
.Fout_16__drv(dut_Fout_16__drv),
.Fout_17__drv(dut_Fout_17__drv),
.MemError__drv(dut_MemError__drv),
.Sout_00__drv(dut_Sout_00__drv),
.Sout_01__drv(dut_Sout_01__drv),
.Sout_02__drv(dut_Sout_02__drv),
.Sout_03__drv(dut_Sout_03__drv),
.Sout_04__drv(dut_Sout_04__drv),
.Sout_05__drv(dut_Sout_05__drv),
.Sout_06__drv(dut_Sout_06__drv),
.Sout_07__drv(dut_Sout_07__drv),
.Sout_08__drv(dut_Sout_08__drv),
.Sout_09__drv(dut_Sout_09__drv),
.Sout_10__drv(dut_Sout_10__drv),
.Sout_11__drv(dut_Sout_11__drv),
.Sout_12__drv(dut_Sout_12__drv),
.Sout_13__drv(dut_Sout_13__drv),
.Sout_14__drv(dut_Sout_14__drv),
.Sout_15__drv(dut_Sout_15__drv),
.dMD_00__drv(dut_dMD_00__drv),
.dMD_01__drv(dut_dMD_01__drv),
.dMD_02__drv(dut_dMD_02__drv),
.dMD_03__drv(dut_dMD_03__drv),
.dMD_04__drv(dut_dMD_04__drv),
.dMD_05__drv(dut_dMD_05__drv),
.dMD_06__drv(dut_dMD_06__drv),
.dMD_07__drv(dut_dMD_07__drv),
.dMD_08__drv(dut_dMD_08__drv),
.dMD_09__drv(dut_dMD_09__drv),
.dMD_10__drv(dut_dMD_10__drv),
.dMD_11__drv(dut_dMD_11__drv),
.dMD_12__drv(dut_dMD_12__drv),
.dMD_13__drv(dut_dMD_13__drv),
.dMD_14__drv(dut_dMD_14__drv),
.dMD_15__drv(dut_dMD_15__drv),
.dMD_16__drv(dut_dMD_16__drv),
.dMD_17__drv(dut_dMD_17__drv),
.dSTPerr__drv(dut_dSTPerr__drv),
.state_host_clk(clk),
.state_guest_advance(board_steps[0]),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[19:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(all_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_dSTPerr__drv,dut_dMD_17__drv,dut_dMD_16__drv,dut_dMD_15__drv,dut_dMD_14__drv,dut_dMD_13__drv,dut_dMD_12__drv,dut_dMD_11__drv,dut_dMD_10__drv,dut_dMD_09__drv,dut_dMD_08__drv,dut_dMD_07__drv,dut_dMD_06__drv,dut_dMD_05__drv,dut_dMD_04__drv,dut_dMD_03__drv,dut_dMD_02__drv,dut_dMD_01__drv,dut_dMD_00__drv,dut_Sout_15__drv,dut_Sout_14__drv,dut_Sout_13__drv,dut_Sout_12__drv,dut_Sout_11__drv,dut_Sout_10__drv,dut_Sout_09__drv,dut_Sout_08__drv,dut_Sout_07__drv,dut_Sout_06__drv,dut_Sout_05__drv,dut_Sout_04__drv,dut_Sout_03__drv,dut_Sout_02__drv,dut_Sout_01__drv,dut_Sout_00__drv,dut_MemError__drv,dut_Fout_17__drv,dut_Fout_16__drv,dut_Fout_15__drv,dut_Fout_14__drv,dut_Fout_13__drv,dut_Fout_12__drv,dut_Fout_11__drv,dut_Fout_10__drv,dut_Fout_09__drv,dut_Fout_08__drv,dut_Fout_07__drv,dut_Fout_06__drv,dut_Fout_05__drv,dut_Fout_04__drv,dut_Fout_03__drv,dut_Fout_02__drv,dut_Fout_01__drv,dut_Fout_00__drv,dut_FG_8__drv,dut_FG_7__drv,dut_FG_6__drv,dut_FG_5__drv,dut_FG_4__drv,dut_FG_3__drv,dut_FG_2__drv,dut_FG_1__drv,dut_FG_0__drv,dut_EcOut_7_p___drv,dut_EcOut_6__drv,dut_EcOut_5__drv,dut_EcOut_4__drv,dut_EcOut_3__drv,dut_EcOut_2__drv,dut_EcOut_1__drv,dut_EcOut_0__drv,dut_ECFault__drv,dut_DMuxData__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv};
assign dut_state[0+:1]=dut.Fclk_p_a;
assign dut_state[1+:1]=dut.Fclk_p_b;
assign dut_state[2+:1]=dut.clk1_p_Aa;
assign dut_state[3+:1]=dut.clk1_p_Ab;
assign dut_state[4+:1]=dut.clk1_p_Ac;
assign dut_state[5+:1]=dut.clk1_p_Ba;
assign dut_state[6+:1]=dut.clk1_p_Bb;
assign dut_state[7+:1]=dut.clk1_p_Ca;
assign dut_state[8+:1]=dut.clk1_p_Cb;
assign dut_state[9+:1]=dut.clk1_p_Cc;
assign dut_state[10+:6]=dut.snapshot_bank_0.saved_q;
assign dut_state[16+:3]=dut.snapshot_bank_1.saved_q;
assign dut_state[19+:3]=dut.snapshot_bank_10.saved_q;
assign dut_state[22+:6]=dut.snapshot_bank_11.saved_q;
assign dut_state[28+:3]=dut.snapshot_bank_12.saved_q;
assign dut_state[31+:6]=dut.snapshot_bank_13.saved_q;
assign dut_state[37+:6]=dut.snapshot_bank_2.saved_q;
assign dut_state[43+:3]=dut.snapshot_bank_3.saved_q;
assign dut_state[46+:6]=dut.snapshot_bank_4.saved_q;
assign dut_state[52+:3]=dut.snapshot_bank_5.saved_q;
assign dut_state[55+:9]=dut.snapshot_bank_6.saved_q;
assign dut_state[64+:9]=dut.snapshot_bank_7.saved_q;
assign dut_state[73+:3]=dut.snapshot_bank_8.saved_q;
assign dut_state[76+:6]=dut.snapshot_bank_9.saved_q;
assign dut_state[82+:1]=dut.storage_rx_pipeline.clock_d;
assign dut_state[83+:36]={dut.storage_rx_pipeline.words[1],dut.storage_rx_pipeline.words[0]};
assign dut_state[119+:1]=dut.u_a01.cka_d;
assign dut_state[120+:1]=dut.u_a01.ckb_d;
assign dut_state[121+:1]=dut.u_a01.d_pre_a;
assign dut_state[122+:1]=dut.u_a01.d_pre_b;
assign dut_state[123+:1]=dut.u_a01.qa;
assign dut_state[124+:1]=dut.u_a01.qb;
assign dut_state[125+:1]=dut.u_a02.cka_d;
assign dut_state[126+:1]=dut.u_a02.ckb_d;
assign dut_state[127+:1]=dut.u_a02.d_pre_a;
assign dut_state[128+:1]=dut.u_a02.d_pre_b;
assign dut_state[129+:1]=dut.u_a02.qa;
assign dut_state[130+:1]=dut.u_a02.qb;
assign dut_state[131+:4]=dut.u_a06.a_lat;
assign dut_state[135+:1]=dut.u_a06.ce_lat;
assign dut_state[136+:4]=dut.u_a06.d_lat;
assign dut_state[140+:64]={dut.u_a06.mem[15],dut.u_a06.mem[14],dut.u_a06.mem[13],dut.u_a06.mem[12],dut.u_a06.mem[11],dut.u_a06.mem[10],dut.u_a06.mem[9],dut.u_a06.mem[8],dut.u_a06.mem[7],dut.u_a06.mem[6],dut.u_a06.mem[5],dut.u_a06.mem[4],dut.u_a06.mem[3],dut.u_a06.mem[2],dut.u_a06.mem[1],dut.u_a06.mem[0]};
assign dut_state[204+:1]=dut.u_a06.we_d;
assign dut_state[205+:1]=dut.u_a08.ck_d;
assign dut_state[206+:4]=dut.u_a08.q;
assign dut_state[210+:6]=dut.u_a08.setup_pre;
assign dut_state[216+:1]=dut.u_a10.ck_d;
assign dut_state[217+:6]=dut.u_a10.d_pre;
assign dut_state[223+:6]=dut.u_a10.q;
assign dut_state[229+:1]=dut.u_a12.ck_d;
assign dut_state[230+:6]=dut.u_a12.d_pre;
assign dut_state[236+:6]=dut.u_a12.q;
assign dut_state[242+:1]=dut.u_a18.ck_d;
assign dut_state[243+:4]=dut.u_a18.d_pre;
assign dut_state[247+:4]=dut.u_a18.q;
assign dut_state[251+:1]=dut.u_a20.ck_d;
assign dut_state[252+:4]=dut.u_a20.q;
assign dut_state[256+:6]=dut.u_a20.setup_pre;
assign dut_state[262+:1]=dut.u_a23.ck_d;
assign dut_state[263+:4]=dut.u_a23.q;
assign dut_state[267+:6]=dut.u_a23.setup_pre;
assign dut_state[273+:1]=dut.u_a24.cka_d;
assign dut_state[274+:1]=dut.u_a24.ckb_d;
assign dut_state[275+:1]=dut.u_a24.d_pre_a;
assign dut_state[276+:1]=dut.u_a24.d_pre_b;
assign dut_state[277+:1]=dut.u_a24.qa;
assign dut_state[278+:1]=dut.u_a24.qb;
assign dut_state[279+:5]=dut.u_b01.q;
assign dut_state[284+:4]=dut.u_b05.a_lat;
assign dut_state[288+:1]=dut.u_b05.ce_lat;
assign dut_state[289+:4]=dut.u_b05.d_lat;
assign dut_state[293+:64]={dut.u_b05.mem[15],dut.u_b05.mem[14],dut.u_b05.mem[13],dut.u_b05.mem[12],dut.u_b05.mem[11],dut.u_b05.mem[10],dut.u_b05.mem[9],dut.u_b05.mem[8],dut.u_b05.mem[7],dut.u_b05.mem[6],dut.u_b05.mem[5],dut.u_b05.mem[4],dut.u_b05.mem[3],dut.u_b05.mem[2],dut.u_b05.mem[1],dut.u_b05.mem[0]};
assign dut_state[357+:1]=dut.u_b05.we_d;
assign dut_state[358+:4]=dut.u_b06.a_lat;
assign dut_state[362+:1]=dut.u_b06.ce_lat;
assign dut_state[363+:4]=dut.u_b06.d_lat;
assign dut_state[367+:64]={dut.u_b06.mem[15],dut.u_b06.mem[14],dut.u_b06.mem[13],dut.u_b06.mem[12],dut.u_b06.mem[11],dut.u_b06.mem[10],dut.u_b06.mem[9],dut.u_b06.mem[8],dut.u_b06.mem[7],dut.u_b06.mem[6],dut.u_b06.mem[5],dut.u_b06.mem[4],dut.u_b06.mem[3],dut.u_b06.mem[2],dut.u_b06.mem[1],dut.u_b06.mem[0]};
assign dut_state[431+:1]=dut.u_b06.we_d;
assign dut_state[432+:1]=dut.u_b09.ck_d;
assign dut_state[433+:4]=dut.u_b09.q;
assign dut_state[437+:6]=dut.u_b09.setup_pre;
assign dut_state[443+:1]=dut.u_b10.ck_d;
assign dut_state[444+:6]=dut.u_b10.d_pre;
assign dut_state[450+:6]=dut.u_b10.q;
assign dut_state[456+:1]=dut.u_b12.ck_d;
assign dut_state[457+:6]=dut.u_b12.d_pre;
assign dut_state[463+:6]=dut.u_b12.q;
assign dut_state[469+:1]=dut.u_b18.cka_d;
assign dut_state[470+:1]=dut.u_b18.ckb_d;
assign dut_state[471+:1]=dut.u_b18.d_pre_a;
assign dut_state[472+:1]=dut.u_b18.d_pre_b;
assign dut_state[473+:1]=dut.u_b18.qa;
assign dut_state[474+:1]=dut.u_b18.qb;
assign dut_state[475+:1]=dut.u_b19.cka_d;
assign dut_state[476+:1]=dut.u_b19.ckb_d;
assign dut_state[477+:1]=dut.u_b19.d_pre_a;
assign dut_state[478+:1]=dut.u_b19.d_pre_b;
assign dut_state[479+:1]=dut.u_b19.qa;
assign dut_state[480+:1]=dut.u_b19.qb;
assign dut_state[481+:1]=dut.u_b20.ck_d;
assign dut_state[482+:4]=dut.u_b20.d_pre;
assign dut_state[486+:4]=dut.u_b20.q;
assign dut_state[490+:1]=dut.u_b23.ck_d;
assign dut_state[491+:4]=dut.u_b23.q;
assign dut_state[495+:6]=dut.u_b23.setup_pre;
assign dut_state[501+:1]=dut.u_b24.cka_d;
assign dut_state[502+:1]=dut.u_b24.ckb_d;
assign dut_state[503+:1]=dut.u_b24.d_pre_a;
assign dut_state[504+:1]=dut.u_b24.d_pre_b;
assign dut_state[505+:1]=dut.u_b24.qa;
assign dut_state[506+:1]=dut.u_b24.qb;
assign dut_state[507+:5]=dut.u_c01.q;
assign dut_state[512+:1]=dut.u_c02.ck_d;
assign dut_state[513+:6]=dut.u_c02.d_pre;
assign dut_state[519+:6]=dut.u_c02.q;
assign dut_state[525+:1]=dut.u_c10.ck_d;
assign dut_state[526+:6]=dut.u_c10.d_pre;
assign dut_state[532+:6]=dut.u_c10.q;
assign dut_state[538+:1]=dut.u_c12.ck_d;
assign dut_state[539+:6]=dut.u_c12.d_pre;
assign dut_state[545+:6]=dut.u_c12.q;
assign dut_state[551+:1]=dut.u_c20.ck_d;
assign dut_state[552+:4]=dut.u_c20.d_pre;
assign dut_state[556+:4]=dut.u_c20.q;
assign dut_state[560+:1]=dut.u_c21.cka_d;
assign dut_state[561+:1]=dut.u_c21.ckb_d;
assign dut_state[562+:1]=dut.u_c21.d_pre_a;
assign dut_state[563+:1]=dut.u_c21.d_pre_b;
assign dut_state[564+:1]=dut.u_c21.qa;
assign dut_state[565+:1]=dut.u_c21.qb;
assign dut_state[566+:1]=dut.u_c23.ck_d;
assign dut_state[567+:4]=dut.u_c23.q;
assign dut_state[571+:6]=dut.u_c23.setup_pre;
assign dut_state[577+:1]=dut.u_c24.ck_d;
assign dut_state[578+:6]=dut.u_c24.d_pre;
assign dut_state[584+:6]=dut.u_c24.q;
assign dut_state[590+:1]=dut.u_d01.ck_d;
assign dut_state[591+:6]=dut.u_d01.d_pre;
assign dut_state[597+:6]=dut.u_d01.q;
assign dut_state[603+:1]=dut.u_d10.ck_d;
assign dut_state[604+:6]=dut.u_d10.d_pre;
assign dut_state[610+:6]=dut.u_d10.q;
assign dut_state[616+:1]=dut.u_d12.ck_d;
assign dut_state[617+:6]=dut.u_d12.d_pre;
assign dut_state[623+:6]=dut.u_d12.q;
assign dut_state[629+:1]=dut.u_d14.ck_d;
assign dut_state[630+:4]=dut.u_d14.q;
assign dut_state[634+:6]=dut.u_d14.setup_pre;
assign dut_state[640+:5]=dut.u_e01.q;
assign dut_state[645+:1]=dut.u_e06.ck_d;
assign dut_state[646+:6]=dut.u_e06.d_pre;
assign dut_state[652+:6]=dut.u_e06.q;
assign dut_state[658+:1]=dut.u_e09.ck_d;
assign dut_state[659+:4]=dut.u_e09.q;
assign dut_state[663+:6]=dut.u_e09.setup_pre;
assign dut_state[669+:1]=dut.u_e10.ck_d;
assign dut_state[670+:6]=dut.u_e10.d_pre;
assign dut_state[676+:6]=dut.u_e10.q;
assign dut_state[682+:1]=dut.u_e12.ck_d;
assign dut_state[683+:6]=dut.u_e12.d_pre;
assign dut_state[689+:6]=dut.u_e12.q;
assign dut_state[695+:1]=dut.u_e13.ck_d;
assign dut_state[696+:4]=dut.u_e13.d_pre;
assign dut_state[700+:4]=dut.u_e13.q;
assign dut_state[704+:1]=dut.u_e14.ck_d;
assign dut_state[705+:4]=dut.u_e14.q;
assign dut_state[709+:6]=dut.u_e14.setup_pre;
assign dut_state[715+:1]=dut.u_e17.ck_d;
assign dut_state[716+:6]=dut.u_e17.d_pre;
assign dut_state[722+:6]=dut.u_e17.q;
assign dut_state[728+:1]=dut.u_e18.ck_d;
assign dut_state[729+:4]=dut.u_e18.q;
assign dut_state[733+:6]=dut.u_e18.setup_pre;
assign dut_state[739+:1]=dut.u_e20.ck_d;
assign dut_state[740+:6]=dut.u_e20.d_pre;
assign dut_state[746+:6]=dut.u_e20.q;
assign dut_state[752+:1]=dut.u_e21.ck_d;
assign dut_state[753+:6]=dut.u_e21.d_pre;
assign dut_state[759+:6]=dut.u_e21.q;
assign dut_state[765+:1]=dut.u_e22.ck_d;
assign dut_state[766+:6]=dut.u_e22.d_pre;
assign dut_state[772+:6]=dut.u_e22.q;
assign dut_state[778+:5]=dut.u_f01.q;
assign dut_state[783+:1]=dut.u_f06.ck_d;
assign dut_state[784+:6]=dut.u_f06.d_pre;
assign dut_state[790+:6]=dut.u_f06.q;
assign dut_state[796+:1]=dut.u_f10.ck_d;
assign dut_state[797+:6]=dut.u_f10.d_pre;
assign dut_state[803+:6]=dut.u_f10.q;
assign dut_state[809+:1]=dut.u_f14.ck_d;
assign dut_state[810+:6]=dut.u_f14.d_pre;
assign dut_state[816+:6]=dut.u_f14.q;
assign dut_state[822+:1]=dut.u_f18.ck_d;
assign dut_state[823+:6]=dut.u_f18.d_pre;
assign dut_state[829+:6]=dut.u_f18.q;
assign dut_state[835+:1]=dut.u_f20.ck_d;
assign dut_state[836+:4]=dut.u_f20.q;
assign dut_state[840+:6]=dut.u_f20.setup_pre;
assign dut_state[846+:1]=dut.u_f22.ck_d;
assign dut_state[847+:4]=dut.u_f22.q;
assign dut_state[851+:6]=dut.u_f22.setup_pre;
assign dut_state[857+:1]=dut.u_f24.ck_d;
assign dut_state[858+:6]=dut.u_f24.d_pre;
assign dut_state[864+:6]=dut.u_f24.q;
assign dut_state[870+:1]=dut.u_g01.cka_d;
assign dut_state[871+:1]=dut.u_g01.ckb_d;
assign dut_state[872+:1]=dut.u_g01.d_pre_a;
assign dut_state[873+:1]=dut.u_g01.d_pre_b;
assign dut_state[874+:1]=dut.u_g01.qa;
assign dut_state[875+:1]=dut.u_g01.qb;
assign dut_state[876+:1]=dut.u_g02.cka_d;
assign dut_state[877+:1]=dut.u_g02.ckb_d;
assign dut_state[878+:1]=dut.u_g02.d_pre_a;
assign dut_state[879+:1]=dut.u_g02.d_pre_b;
assign dut_state[880+:1]=dut.u_g02.qa;
assign dut_state[881+:1]=dut.u_g02.qb;
assign dut_state[882+:1]=dut.u_g16.ck_d;
assign dut_state[883+:6]=dut.u_g16.d_pre;
assign dut_state[889+:6]=dut.u_g16.q;
assign dut_state[895+:1]=dut.u_g20.ck_d;
assign dut_state[896+:4]=dut.u_g20.q;
assign dut_state[900+:6]=dut.u_g20.setup_pre;
assign dut_state[906+:1]=dut.u_g22.cka_d;
assign dut_state[907+:1]=dut.u_g22.ckb_d;
assign dut_state[908+:1]=dut.u_g22.d_pre_a;
assign dut_state[909+:1]=dut.u_g22.d_pre_b;
assign dut_state[910+:1]=dut.u_g22.qa;
assign dut_state[911+:1]=dut.u_g22.qb;
assign dut_state[912+:1]=dut.u_g24.ck_d;
assign dut_state[913+:6]=dut.u_g24.d_pre;
assign dut_state[919+:6]=dut.u_g24.q;
assign dut_state[925+:1]=dut.u_h01.cka_d;
assign dut_state[926+:1]=dut.u_h01.ckb_d;
assign dut_state[927+:1]=dut.u_h01.d_pre_a;
assign dut_state[928+:1]=dut.u_h01.d_pre_b;
assign dut_state[929+:1]=dut.u_h01.qa;
assign dut_state[930+:1]=dut.u_h01.qb;
assign dut_state[931+:1]=dut.u_h02.cka_d;
assign dut_state[932+:1]=dut.u_h02.ckb_d;
assign dut_state[933+:1]=dut.u_h02.d_pre_a;
assign dut_state[934+:1]=dut.u_h02.d_pre_b;
assign dut_state[935+:1]=dut.u_h02.qa;
assign dut_state[936+:1]=dut.u_h02.qb;
assign dut_state[937+:1]=dut.u_h03.ck_d;
assign dut_state[938+:6]=dut.u_h03.d_pre;
assign dut_state[944+:6]=dut.u_h03.q;
assign dut_state[950+:4]=dut.u_h04.a_lat;
assign dut_state[954+:1]=dut.u_h04.ce_lat;
assign dut_state[955+:4]=dut.u_h04.d_lat;
assign dut_state[959+:64]={dut.u_h04.mem[15],dut.u_h04.mem[14],dut.u_h04.mem[13],dut.u_h04.mem[12],dut.u_h04.mem[11],dut.u_h04.mem[10],dut.u_h04.mem[9],dut.u_h04.mem[8],dut.u_h04.mem[7],dut.u_h04.mem[6],dut.u_h04.mem[5],dut.u_h04.mem[4],dut.u_h04.mem[3],dut.u_h04.mem[2],dut.u_h04.mem[1],dut.u_h04.mem[0]};
assign dut_state[1023+:1]=dut.u_h04.we_d;
assign dut_state[1024+:4]=dut.u_h06.a_lat;
assign dut_state[1028+:1]=dut.u_h06.ce_lat;
assign dut_state[1029+:4]=dut.u_h06.d_lat;
assign dut_state[1033+:64]={dut.u_h06.mem[15],dut.u_h06.mem[14],dut.u_h06.mem[13],dut.u_h06.mem[12],dut.u_h06.mem[11],dut.u_h06.mem[10],dut.u_h06.mem[9],dut.u_h06.mem[8],dut.u_h06.mem[7],dut.u_h06.mem[6],dut.u_h06.mem[5],dut.u_h06.mem[4],dut.u_h06.mem[3],dut.u_h06.mem[2],dut.u_h06.mem[1],dut.u_h06.mem[0]};
assign dut_state[1097+:1]=dut.u_h06.we_d;
assign dut_state[1098+:1]=dut.u_h07.ck_d;
assign dut_state[1099+:4]=dut.u_h07.q;
assign dut_state[1103+:6]=dut.u_h07.setup_pre;
assign dut_state[1109+:4]=dut.u_h11.a_lat;
assign dut_state[1113+:1]=dut.u_h11.ce_lat;
assign dut_state[1114+:4]=dut.u_h11.d_lat;
assign dut_state[1118+:64]={dut.u_h11.mem[15],dut.u_h11.mem[14],dut.u_h11.mem[13],dut.u_h11.mem[12],dut.u_h11.mem[11],dut.u_h11.mem[10],dut.u_h11.mem[9],dut.u_h11.mem[8],dut.u_h11.mem[7],dut.u_h11.mem[6],dut.u_h11.mem[5],dut.u_h11.mem[4],dut.u_h11.mem[3],dut.u_h11.mem[2],dut.u_h11.mem[1],dut.u_h11.mem[0]};
assign dut_state[1182+:1]=dut.u_h11.we_d;
assign dut_state[1183+:1]=dut.u_h12.ck_d;
assign dut_state[1184+:4]=dut.u_h12.d_pre;
assign dut_state[1188+:1]=dut.u_h12.dl_pre;
assign dut_state[1189+:1]=dut.u_h12.dr_pre;
assign dut_state[1190+:4]=dut.u_h12.q;
assign dut_state[1194+:2]=dut.u_h12.s_pre;
assign dut_state[1196+:4]=dut.u_h15.a_lat;
assign dut_state[1200+:1]=dut.u_h15.ce_lat;
assign dut_state[1201+:4]=dut.u_h15.d_lat;
assign dut_state[1205+:64]={dut.u_h15.mem[15],dut.u_h15.mem[14],dut.u_h15.mem[13],dut.u_h15.mem[12],dut.u_h15.mem[11],dut.u_h15.mem[10],dut.u_h15.mem[9],dut.u_h15.mem[8],dut.u_h15.mem[7],dut.u_h15.mem[6],dut.u_h15.mem[5],dut.u_h15.mem[4],dut.u_h15.mem[3],dut.u_h15.mem[2],dut.u_h15.mem[1],dut.u_h15.mem[0]};
assign dut_state[1269+:1]=dut.u_h15.we_d;
assign dut_state[1270+:4]=dut.u_h17.a_lat;
assign dut_state[1274+:1]=dut.u_h17.ce_lat;
assign dut_state[1275+:4]=dut.u_h17.d_lat;
assign dut_state[1279+:64]={dut.u_h17.mem[15],dut.u_h17.mem[14],dut.u_h17.mem[13],dut.u_h17.mem[12],dut.u_h17.mem[11],dut.u_h17.mem[10],dut.u_h17.mem[9],dut.u_h17.mem[8],dut.u_h17.mem[7],dut.u_h17.mem[6],dut.u_h17.mem[5],dut.u_h17.mem[4],dut.u_h17.mem[3],dut.u_h17.mem[2],dut.u_h17.mem[1],dut.u_h17.mem[0]};
assign dut_state[1343+:1]=dut.u_h17.we_d;
assign dut_state[1344+:1]=dut.u_h20.ck_d;
assign dut_state[1345+:4]=dut.u_h20.q;
assign dut_state[1349+:6]=dut.u_h20.setup_pre;
assign dut_state[1355+:1]=dut.u_i01.ck_d;
assign dut_state[1356+:6]=dut.u_i01.d_pre;
assign dut_state[1362+:6]=dut.u_i01.q;
assign dut_state[1368+:1]=dut.u_i02.ck_d;
assign dut_state[1369+:6]=dut.u_i02.d_pre;
assign dut_state[1375+:6]=dut.u_i02.q;
assign dut_state[1381+:1]=dut.u_i16.ck_d;
assign dut_state[1382+:6]=dut.u_i16.d_pre;
assign dut_state[1388+:6]=dut.u_i16.q;
assign dut_state[1394+:1]=dut.u_i20.ck_d;
assign dut_state[1395+:6]=dut.u_i20.d_pre;
assign dut_state[1401+:6]=dut.u_i20.q;
assign dut_state[1407+:1]=dut.u_i21.ck_d;
assign dut_state[1408+:4]=dut.u_i21.q;
assign dut_state[1412+:6]=dut.u_i21.setup_pre;
assign dut_state[1418+:1]=dut.u_i23.cka_d;
assign dut_state[1419+:1]=dut.u_i23.ckb_d;
assign dut_state[1420+:1]=dut.u_i23.d_pre_a;
assign dut_state[1421+:1]=dut.u_i23.d_pre_b;
assign dut_state[1422+:1]=dut.u_i23.qa;
assign dut_state[1423+:1]=dut.u_i23.qb;
assign dut_state[1424+:1]=dut.u_i24.ck_d;
assign dut_state[1425+:6]=dut.u_i24.d_pre;
assign dut_state[1431+:6]=dut.u_i24.q;
assign dut_state[1437+:1]=dut.u_j01.cka_d;
assign dut_state[1438+:1]=dut.u_j01.ckb_d;
assign dut_state[1439+:1]=dut.u_j01.d_pre_a;
assign dut_state[1440+:1]=dut.u_j01.d_pre_b;
assign dut_state[1441+:1]=dut.u_j01.qa;
assign dut_state[1442+:1]=dut.u_j01.qb;
assign dut_state[1443+:1]=dut.u_j02.ck_d;
assign dut_state[1444+:6]=dut.u_j02.d_pre;
assign dut_state[1450+:6]=dut.u_j02.q;
assign dut_state[1456+:1]=dut.u_j16.cka_d;
assign dut_state[1457+:1]=dut.u_j16.ckb_d;
assign dut_state[1458+:1]=dut.u_j16.d_pre_a;
assign dut_state[1459+:1]=dut.u_j16.d_pre_b;
assign dut_state[1460+:1]=dut.u_j16.qa;
assign dut_state[1461+:1]=dut.u_j16.qb;
assign dut_state[1462+:1]=dut.u_j20.ck_d;
assign dut_state[1463+:6]=dut.u_j20.d_pre;
assign dut_state[1469+:6]=dut.u_j20.q;
assign dut_state[1475+:1]=dut.u_j21.ck_d;
assign dut_state[1476+:6]=dut.u_j21.d_pre;
assign dut_state[1482+:6]=dut.u_j21.q;
assign dut_state[1488+:1]=dut.u_j22.ck_d;
assign dut_state[1489+:6]=dut.u_j22.d_pre;
assign dut_state[1495+:6]=dut.u_j22.q;
assign dut_state[1501+:1]=dut.u_j24.ck_d;
assign dut_state[1502+:6]=dut.u_j24.d_pre;
assign dut_state[1508+:6]=dut.u_j24.q;
assign dut_state[1514+:1]=dut.u_k01.cka_d;
assign dut_state[1515+:1]=dut.u_k01.ckb_d;
assign dut_state[1516+:1]=dut.u_k01.d_pre_a;
assign dut_state[1517+:1]=dut.u_k01.d_pre_b;
assign dut_state[1518+:1]=dut.u_k01.qa;
assign dut_state[1519+:1]=dut.u_k01.qb;
assign dut_state[1520+:1]=dut.u_k09.ck_d;
assign dut_state[1521+:4]=dut.u_k09.q;
assign dut_state[1525+:6]=dut.u_k09.setup_pre;
assign dut_state[1531+:1]=dut.u_k13.ck_d;
assign dut_state[1532+:6]=dut.u_k13.d_pre;
assign dut_state[1538+:6]=dut.u_k13.q;
assign dut_state[1544+:1]=dut.u_k18.ck_d;
assign dut_state[1545+:4]=dut.u_k18.d_pre;
assign dut_state[1549+:4]=dut.u_k18.q;
assign dut_state[1553+:1]=dut.u_k19.ck_d;
assign dut_state[1554+:6]=dut.u_k19.d_pre;
assign dut_state[1560+:6]=dut.u_k19.q;
assign dut_state[1566+:1]=dut.u_k20.ck_d;
assign dut_state[1567+:6]=dut.u_k20.d_pre;
assign dut_state[1573+:6]=dut.u_k20.q;
assign dut_state[1579+:1]=dut.u_k21.ck_d;
assign dut_state[1580+:6]=dut.u_k21.d_pre;
assign dut_state[1586+:6]=dut.u_k21.q;
assign dut_state[1592+:1]=dut.u_k23.ck_d;
assign dut_state[1593+:6]=dut.u_k23.d_pre;
assign dut_state[1599+:6]=dut.u_k23.q;
assign dut_state[1605+:1]=dut.u_k24.ck_d;
assign dut_state[1606+:6]=dut.u_k24.d_pre;
assign dut_state[1612+:6]=dut.u_k24.q;
assign dut_state[1618+:1]=dut.u_l02.cka_d;
assign dut_state[1619+:1]=dut.u_l02.ckb_d;
assign dut_state[1620+:1]=dut.u_l02.d_pre_a;
assign dut_state[1621+:1]=dut.u_l02.d_pre_b;
assign dut_state[1622+:1]=dut.u_l02.qa;
assign dut_state[1623+:1]=dut.u_l02.qb;
assign dut_state[1624+:1]=dut.u_l08.ck_d;
assign dut_state[1625+:4]=dut.u_l08.q;
assign dut_state[1629+:6]=dut.u_l08.setup_pre;
assign dut_state[1635+:1]=dut.u_l16.cka_d;
assign dut_state[1636+:1]=dut.u_l16.ckb_d;
assign dut_state[1637+:1]=dut.u_l16.d_pre_a;
assign dut_state[1638+:1]=dut.u_l16.d_pre_b;
assign dut_state[1639+:1]=dut.u_l16.qa;
assign dut_state[1640+:1]=dut.u_l16.qb;
assign dut_state[1641+:1]=dut.u_l20.ck_d;
assign dut_state[1642+:6]=dut.u_l20.d_pre;
assign dut_state[1648+:6]=dut.u_l20.q;
assign dut_state[1654+:1]=dut.u_l21.ck_d;
assign dut_state[1655+:6]=dut.u_l21.d_pre;
assign dut_state[1661+:6]=dut.u_l21.q;
assign dut_state[1667+:1]=dut.u_l23.cka_d;
assign dut_state[1668+:1]=dut.u_l23.ckb_d;
assign dut_state[1669+:1]=dut.u_l23.d_pre_a;
assign dut_state[1670+:1]=dut.u_l23.d_pre_b;
assign dut_state[1671+:1]=dut.u_l23.qa;
assign dut_state[1672+:1]=dut.u_l23.qb;
assign dut_state[1673+:1]=dut.u_l24.cka_d;
assign dut_state[1674+:1]=dut.u_l24.ckb_d;
assign dut_state[1675+:1]=dut.u_l24.d_pre_a;
assign dut_state[1676+:1]=dut.u_l24.d_pre_b;
assign dut_state[1677+:1]=dut.u_l24.qa;
assign dut_state[1678+:1]=dut.u_l24.qb;
assign dut_probe[0+:6]=dut.snapshot_bank_0.mem[0+(probe_index%4096)];
assign dut_probe[6+:3]=dut.snapshot_bank_1.mem[0+(probe_index%4096)];
assign dut_probe[9+:3]=dut.snapshot_bank_10.mem[0+(probe_index%4096)];
assign dut_probe[12+:6]=dut.snapshot_bank_11.mem[0+(probe_index%4096)];
assign dut_probe[18+:3]=dut.snapshot_bank_12.mem[0+(probe_index%4096)];
assign dut_probe[21+:6]=dut.snapshot_bank_13.mem[0+(probe_index%4096)];
assign dut_probe[27+:6]=dut.snapshot_bank_2.mem[0+(probe_index%4096)];
assign dut_probe[33+:3]=dut.snapshot_bank_3.mem[0+(probe_index%4096)];
assign dut_probe[36+:6]=dut.snapshot_bank_4.mem[0+(probe_index%4096)];
assign dut_probe[42+:3]=dut.snapshot_bank_5.mem[0+(probe_index%4096)];
assign dut_probe[45+:9]=dut.snapshot_bank_6.mem[0+(probe_index%4096)];
assign dut_probe[54+:9]=dut.snapshot_bank_7.mem[0+(probe_index%4096)];
assign dut_probe[63+:3]=dut.snapshot_bank_8.mem[0+(probe_index%4096)];
assign dut_probe[66+:6]=dut.snapshot_bank_9.mem[0+(probe_index%4096)];
assign all_helpers_frozen=&{dut.snapshot_bank_0.frozen,dut.snapshot_bank_1.frozen,dut.snapshot_bank_10.frozen,dut.snapshot_bank_11.frozen,dut.snapshot_bank_12.frozen,dut.snapshot_bank_13.frozen,dut.snapshot_bank_2.frozen,dut.snapshot_bank_3.frozen,dut.snapshot_bank_4.frozen,dut.snapshot_bank_5.frozen,dut.snapshot_bank_6.frozen,dut.snapshot_bank_7.frozen,dut.snapshot_bank_8.frozen,dut.snapshot_bank_9.frozen,dut.state_frozen,dut.u_a06.state_frozen,dut.u_b05.state_frozen,dut.u_b06.state_frozen,dut.u_h04.state_frozen,dut.u_h06.state_frozen,dut.u_h11.state_frozen,dut.u_h15.state_frozen,dut.u_h17.state_frozen};
endmodule
