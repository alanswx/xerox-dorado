module i2125_fixture(
 input host_clk,ref_clk,advance,freeze,held,request,write,
 input [9:0] address,input [7:0] data,input [3:0] ce_n,we_n,
 input [12:0] index,input [17:0] state_data,
 output [3:0] frozen,done,error,
 output [7:0] q[4],original_q[4],raw_q[4],original_raw[4],
 output [17:0] result[4],output [7:0] physical[4][1024]);
 genvar k,b,a;
 generate for(k=0;k<4;k=k+1)begin:banks
  dorado_snapshot_i2125_byte_bank candidate(
   .host_clk(host_clk),.guest_advance(advance),.address(address),.data(data),
   .ce_n(ce_n[k]),.we_n(we_n[k]),.q(q[k]),.freeze(freeze),.guest_held(held),.frozen(frozen[k]),
   .request(request && index[12:11]==k),.write(write),.word_index(index[10:0]),
   .state_data(state_data),.done(done[k]),.error(error[k]),.result(result[k]));
  assign raw_q[k]=candidate.memory.logical_q;
  for(a=0;a<1024;a=a+1)begin:words
   assign physical[k][a]=candidate.memory.mem[a];
  end
  for(b=0;b<8;b=b+1)begin:bits
   cell_i2125 original(.sys_clk(ref_clk),.p13(address[9]),.p12(address[8]),
    .p11(address[7]),.p10(address[6]),.p9(address[5]),.p6(address[4]),
    .p5(address[3]),.p4(address[2]),.p3(address[1]),.p2(address[0]),
    .p1(ce_n[k]),.p14(we_n[k]),.p15(data[b]),.p7(original_q[k][b]),.p8(1'b0),.p16(1'b1));
   assign original_raw[k][b]=original.dout_r;
  end
 end endgenerate
endmodule
