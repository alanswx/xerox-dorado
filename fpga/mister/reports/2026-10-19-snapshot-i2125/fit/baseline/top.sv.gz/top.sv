module snapshot_fit(
 input wire host_clk,input wire [3:0] advance,ce_n,we_n,freeze,held,request,write,
 input wire [39:0] address,input wire [31:0] data,input wire [71:0] state_data,
 input wire [43:0] word_index,output reg [31:0] q,output reg [71:0] result,
 output reg [3:0] frozen,done,error);
 // Same opposite-edge launch/capture shell and10ns embedded paths.
 // Independent controls preserve four separately writable byte groups.

 reg [53:0] launch_0;
 always @(negedge host_clk)launch_0<=
  {advance[0],address[0+:10],data[0+:8],ce_n[0],we_n[0],
    freeze[0],held[0],request[0],write[0],word_index[0+:11],state_data[0+:18]};
 wire step_0,ce_0,we_0,freeze_0,held_0,request_0,write_0;
 wire [9:0] address_0;wire [7:0] data_0;wire [17:0] state_0;wire [10:0] word_0;
 assign {step_0,address_0,data_0,ce_0,we_0,freeze_0,held_0,request_0,write_0,word_0,state_0}=launch_0;
 wire [7:0] q_0;wire [17:0] result_0;wire frozen_0,done_0,error_0;
 always @(negedge host_clk)
  {q[0+:8],frozen[0],done[0],error[0],result[0+:18]}<=
  {q_0,frozen_0,done_0,error_0,result_0};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_i2125_byte_bank bank_0(
  .host_clk(host_clk),.guest_advance(step_0),.address(address_0),.data(data_0),
  .ce_n(ce_0),.we_n(we_0),.q(q_0),.freeze(freeze_0),.guest_held(held_0),.frozen(frozen_0),
  .request(request_0),.write(write_0),.word_index(word_0),.state_data(state_0),
  .done(done_0),.error(error_0),.result(result_0));
`else
 assign frozen_0=0;assign done_0=0;assign error_0=0;assign result_0=0;
 genvar b_0;
 generate for(b_0=0;b_0<8;b_0=b_0+1)begin:original_0
  cell_i2125 bit_cell(.sys_clk(host_clk),.p13(address_0[9]),.p12(address_0[8]),
   .p11(address_0[7]),.p10(address_0[6]),.p9(address_0[5]),.p6(address_0[4]),
   .p5(address_0[3]),.p4(address_0[2]),.p3(address_0[1]),.p2(address_0[0]),
   .p15(data_0[b_0]),.p1(ce_0),.p14(we_0),.p7(q_0[b_0]),.p8(1'b0),.p16(1'b1));
 end endgenerate
`endif

 reg [53:0] launch_1;
 always @(negedge host_clk)launch_1<=
  {advance[1],address[10+:10],data[8+:8],ce_n[1],we_n[1],
    freeze[1],held[1],request[1],write[1],word_index[11+:11],state_data[18+:18]};
 wire step_1,ce_1,we_1,freeze_1,held_1,request_1,write_1;
 wire [9:0] address_1;wire [7:0] data_1;wire [17:0] state_1;wire [10:0] word_1;
 assign {step_1,address_1,data_1,ce_1,we_1,freeze_1,held_1,request_1,write_1,word_1,state_1}=launch_1;
 wire [7:0] q_1;wire [17:0] result_1;wire frozen_1,done_1,error_1;
 always @(negedge host_clk)
  {q[8+:8],frozen[1],done[1],error[1],result[18+:18]}<=
  {q_1,frozen_1,done_1,error_1,result_1};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_i2125_byte_bank bank_1(
  .host_clk(host_clk),.guest_advance(step_1),.address(address_1),.data(data_1),
  .ce_n(ce_1),.we_n(we_1),.q(q_1),.freeze(freeze_1),.guest_held(held_1),.frozen(frozen_1),
  .request(request_1),.write(write_1),.word_index(word_1),.state_data(state_1),
  .done(done_1),.error(error_1),.result(result_1));
`else
 assign frozen_1=0;assign done_1=0;assign error_1=0;assign result_1=0;
 genvar b_1;
 generate for(b_1=0;b_1<8;b_1=b_1+1)begin:original_1
  cell_i2125 bit_cell(.sys_clk(host_clk),.p13(address_1[9]),.p12(address_1[8]),
   .p11(address_1[7]),.p10(address_1[6]),.p9(address_1[5]),.p6(address_1[4]),
   .p5(address_1[3]),.p4(address_1[2]),.p3(address_1[1]),.p2(address_1[0]),
   .p15(data_1[b_1]),.p1(ce_1),.p14(we_1),.p7(q_1[b_1]),.p8(1'b0),.p16(1'b1));
 end endgenerate
`endif

 reg [53:0] launch_2;
 always @(negedge host_clk)launch_2<=
  {advance[2],address[20+:10],data[16+:8],ce_n[2],we_n[2],
    freeze[2],held[2],request[2],write[2],word_index[22+:11],state_data[36+:18]};
 wire step_2,ce_2,we_2,freeze_2,held_2,request_2,write_2;
 wire [9:0] address_2;wire [7:0] data_2;wire [17:0] state_2;wire [10:0] word_2;
 assign {step_2,address_2,data_2,ce_2,we_2,freeze_2,held_2,request_2,write_2,word_2,state_2}=launch_2;
 wire [7:0] q_2;wire [17:0] result_2;wire frozen_2,done_2,error_2;
 always @(negedge host_clk)
  {q[16+:8],frozen[2],done[2],error[2],result[36+:18]}<=
  {q_2,frozen_2,done_2,error_2,result_2};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_i2125_byte_bank bank_2(
  .host_clk(host_clk),.guest_advance(step_2),.address(address_2),.data(data_2),
  .ce_n(ce_2),.we_n(we_2),.q(q_2),.freeze(freeze_2),.guest_held(held_2),.frozen(frozen_2),
  .request(request_2),.write(write_2),.word_index(word_2),.state_data(state_2),
  .done(done_2),.error(error_2),.result(result_2));
`else
 assign frozen_2=0;assign done_2=0;assign error_2=0;assign result_2=0;
 genvar b_2;
 generate for(b_2=0;b_2<8;b_2=b_2+1)begin:original_2
  cell_i2125 bit_cell(.sys_clk(host_clk),.p13(address_2[9]),.p12(address_2[8]),
   .p11(address_2[7]),.p10(address_2[6]),.p9(address_2[5]),.p6(address_2[4]),
   .p5(address_2[3]),.p4(address_2[2]),.p3(address_2[1]),.p2(address_2[0]),
   .p15(data_2[b_2]),.p1(ce_2),.p14(we_2),.p7(q_2[b_2]),.p8(1'b0),.p16(1'b1));
 end endgenerate
`endif

 reg [53:0] launch_3;
 always @(negedge host_clk)launch_3<=
  {advance[3],address[30+:10],data[24+:8],ce_n[3],we_n[3],
    freeze[3],held[3],request[3],write[3],word_index[33+:11],state_data[54+:18]};
 wire step_3,ce_3,we_3,freeze_3,held_3,request_3,write_3;
 wire [9:0] address_3;wire [7:0] data_3;wire [17:0] state_3;wire [10:0] word_3;
 assign {step_3,address_3,data_3,ce_3,we_3,freeze_3,held_3,request_3,write_3,word_3,state_3}=launch_3;
 wire [7:0] q_3;wire [17:0] result_3;wire frozen_3,done_3,error_3;
 always @(negedge host_clk)
  {q[24+:8],frozen[3],done[3],error[3],result[54+:18]}<=
  {q_3,frozen_3,done_3,error_3,result_3};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_i2125_byte_bank bank_3(
  .host_clk(host_clk),.guest_advance(step_3),.address(address_3),.data(data_3),
  .ce_n(ce_3),.we_n(we_3),.q(q_3),.freeze(freeze_3),.guest_held(held_3),.frozen(frozen_3),
  .request(request_3),.write(write_3),.word_index(word_3),.state_data(state_3),
  .done(done_3),.error(error_3),.result(result_3));
`else
 assign frozen_3=0;assign done_3=0;assign error_3=0;assign result_3=0;
 genvar b_3;
 generate for(b_3=0;b_3<8;b_3=b_3+1)begin:original_3
  cell_i2125 bit_cell(.sys_clk(host_clk),.p13(address_3[9]),.p12(address_3[8]),
   .p11(address_3[7]),.p10(address_3[6]),.p9(address_3[5]),.p6(address_3[4]),
   .p5(address_3[3]),.p4(address_3[2]),.p3(address_3[1]),.p2(address_3[0]),
   .p15(data_3[b_3]),.p1(ce_3),.p14(we_3),.p7(q_3[b_3]),.p8(1'b0),.p16(1'b1));
 end endgenerate
`endif
endmodule
