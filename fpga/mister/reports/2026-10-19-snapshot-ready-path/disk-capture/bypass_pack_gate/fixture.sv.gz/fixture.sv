`timescale 1ns/1ps
`default_nettype none
module disk_cache_capture;
 reg clk=0,pll_reset=1,extra_reset=0,extra_ready=0;
 reg attached=1,remounted=0,sd_ack=0;
 reg [11:0] tagbus_n=12'hfff;
 reg cyltag_n=1,headtag_n=1,conttag_n=1;
 wire pack_ready,machine_clk;
 reg gate_open=1'b1;
 wire machine_enable=!(pll_reset||extra_reset) && extra_ready;
 always @(negedge clk)gate_open<=machine_enable;
 assign machine_clk=clk && gate_open;
 dorado_pack_hps #(.INITIAL_CYL(4),.INITIAL_HEAD(4),.HOST_TIMEOUT_CLOCKS(31)) dut(
 .clk_sys(clk),.machine_clk(machine_clk),.reset(pll_reset),.attached(attached),.readonly(1'b0),.remounted(remounted),
 .tagbus_n(tagbus_n),.cyltag_n(cyltag_n),.headtag_n(headtag_n),.drivetag_n(1'b1),.conttag_n(conttag_n),
 .selected(1'b0),.data_adv(1'b0),.pulse(16'b0),.write_data_p(1'b0),.write_data_m(1'b0),
 .data_bit(),.write_gate(),.endofcyl_n(),.ready(pack_ready),.dirty(),.fault(),.host_phase(),.fault_debug(),.fault_extra(),
 .sd_lba(),.sd_blk_cnt(),.sd_rd(),.sd_wr(),.sd_ack(sd_ack),.sd_buff_addr(13'b0),.sd_buff_dout(16'b0),.sd_buff_wr(1'b0),.sd_buff_din(),.reads(),.writes());
 integer ticks=0,captures=0,guest_edges=0,tag_changes=0,illegal_heads=0,failures=0;
 integer previous_captures;
 reg [11:0] before_cyl;
 reg [5:0] before_head;
 always @(posedge machine_clk)guest_edges=guest_edges+1;
 task high;begin
  previous_captures=dut.proof_captures;before_cyl=dut.cyl;before_head=dut.head;
  clk=1;#2;ticks=ticks+1;
  if(dut.proof_captures!=previous_captures)begin
   captures=captures+1;
   if(gate_open!==0)$fatal(1,"cache capture overlapped enabled guest edge");
   if(dut.cyl!==before_cyl || dut.head!==before_head)$fatal(1,"cache source changed on capture edge");
   if(dut.cached_cyl!==before_cyl || dut.cached_head!==before_head)$fatal(1,"cache capture did not preserve source");
  end
  if(dut.cyl!==before_cyl || dut.head!==before_head)tag_changes=tag_changes+1;
  if(dut.head>=5)illegal_heads=illegal_heads+1;
  if(dut.host_fault)failures=failures+1;
 end endtask
 integer seed=32'h674d13ac,i,r;
 initial begin
  // The PLL/reset guard is present before first useful cache capture even if
  // the clock-control enable register powers up high.
  repeat(4)begin high();clk=0;#2;end
  pll_reset=0;extra_ready=1;
  for(i=0;i<200000;i=i+1)begin
   // Drive before the falling edge, exactly as the core's raw enable contract.
   r=$random(seed);
   extra_ready=(r&7)!=0;extra_reset=(i%431)==0;
   pll_reset=(i%997)==0;remounted=(i%283)==0;
   attached=(i%509)>3;
   cyltag_n=(r&15)!=0;headtag_n=((r>>4)&15)!=0;conttag_n=((r>>8)&15)!=0;
   tagbus_n=~(r>>12);
   sd_ack=((r>>6)&7)==0;
   clk=0;#2;
   // A request changing AFTER the sampling edge cannot create a guest edge.
   if((i%5)==0)extra_ready=~extra_ready;
   high();
  end
  if(captures<100 || guest_edges<1000 || tag_changes<100 || illegal_heads<100 || failures<100)$fatal(1,"disk capture coverage missing captures=%0d guest=%0d tags=%0d illegal=%0d failures=%0d",captures,guest_edges,tag_changes,illegal_heads,failures);
  $display("DISK CACHE CAPTURE PASS ticks=%0d captures=%0d guest=%0d tags=%0d illegal=%0d failures=%0d",ticks,captures,guest_edges,tag_changes,illegal_heads,failures);$finish;
 end
endmodule
`default_nettype wire
