`timescale 1ns/1ps
`default_nettype none
module disk_cache_capture;
 reg clk=0,pll_reset=1,extra_reset=0,extra_ready=0;
 reg attached=1,remounted=0,sd_ack=0;
 reg [11:0] tagbus_n=12'hfff;
 reg cyltag_n=1,headtag_n=1,conttag_n=1;
 wire pack_ready,machine_clk;
 reg gate_open=1'b1;
 wire machine_enable=!(pll_reset||extra_reset) && pack_ready && extra_ready;
 always @(negedge clk)gate_open<=machine_enable;
 assign machine_clk=clk && gate_open;
 wire candidate_ready;
 dorado_pack_hps_reference #(.INITIAL_CYL(4),.INITIAL_HEAD(4),.HOST_TIMEOUT_CLOCKS(31)) dut(
 .clk_sys(clk),.machine_clk(machine_clk),.reset(pll_reset),.attached(attached),.readonly(1'b0),.remounted(remounted),
 .tagbus_n(tagbus_n),.cyltag_n(cyltag_n),.headtag_n(headtag_n),.drivetag_n(1'b1),.conttag_n(conttag_n),
 .selected(1'b0),.data_adv(1'b0),.pulse(16'b0),.write_data_p(1'b0),.write_data_m(1'b0),
 .data_bit(),.write_gate(),.endofcyl_n(),.ready(pack_ready),.dirty(),.fault(),.host_phase(),.fault_debug(),.fault_extra(),
 .sd_lba(),.sd_blk_cnt(),.sd_rd(),.sd_wr(),.sd_ack(sd_ack),.sd_buff_addr(13'b0),.sd_buff_dout(16'b0),.sd_buff_wr(1'b0),.sd_buff_din(),.reads(),.writes());
 dorado_pack_hps #(.INITIAL_CYL(4),.INITIAL_HEAD(4),.HOST_TIMEOUT_CLOCKS(31)) candidate(
 .clk_sys(clk),.machine_clk(machine_clk),.reset(pll_reset),.attached(attached),.readonly(1'b0),.remounted(remounted),
 .tagbus_n(tagbus_n),.cyltag_n(cyltag_n),.headtag_n(headtag_n),.drivetag_n(1'b1),.conttag_n(conttag_n),
 .selected(1'b0),.data_adv(1'b0),.pulse(16'b0),.write_data_p(1'b0),.write_data_m(1'b0),
 .data_bit(),.write_gate(),.endofcyl_n(),.ready(candidate_ready),.dirty(),.fault(),.host_phase(),.fault_debug(),.fault_extra(),
 .sd_lba(),.sd_blk_cnt(),.sd_rd(),.sd_wr(),.sd_ack(sd_ack),.sd_buff_addr(13'b0),.sd_buff_dout(16'b0),.sd_buff_wr(1'b0),.sd_buff_din(),.reads(),.writes());
 integer ticks=0,captures=0,guest_edges=0,tag_changes=0,illegal_heads=0,failures=0;
 integer previous_captures;
 reg [11:0] before_cyl;
 reg [5:0] before_head;
 always @(posedge machine_clk)guest_edges=guest_edges+1;
 task high;begin
  previous_captures=dut.proof_captures;before_cyl=dut.cyl;before_head=dut.head;
  clk=1;#2;ticks=ticks+1;
  if(candidate_ready!==pack_ready)$fatal(1,"disk phase ready differs");
  if(candidate.bi!==dut.bi)$fatal(1,"disk phase field differs: bi");
  if(candidate.blk!==dut.blk)$fatal(1,"disk phase field differs: blk");
  if(candidate.cached_count!==dut.cached_count)$fatal(1,"disk phase field differs: cached_count");
  if(candidate.cached_cyl!==dut.cached_cyl)$fatal(1,"disk phase field differs: cached_cyl");
  if(candidate.cached_head!==dut.cached_head)$fatal(1,"disk phase field differs: cached_head");
  if(candidate.cached_lba!==dut.cached_lba)$fatal(1,"disk phase field differs: cached_lba");
  if(candidate.cnt!==dut.cnt)$fatal(1,"disk phase field differs: cnt");
  if(candidate.conttag_d!==dut.conttag_d)$fatal(1,"disk phase field differs: conttag_d");
  if(candidate.cyl!==dut.cyl)$fatal(1,"disk phase field differs: cyl");
  if(candidate.cyltag_d!==dut.cyltag_d)$fatal(1,"disk phase field differs: cyltag_d");
  if(candidate.data_bit!==dut.data_bit)$fatal(1,"disk phase field differs: data_bit");
  if(candidate.ecc!==dut.ecc)$fatal(1,"disk phase field differs: ecc");
  if(candidate.ecc_next!==dut.ecc_next)$fatal(1,"disk phase field differs: ecc_next");
  if(candidate.eoc!==dut.eoc)$fatal(1,"disk phase field differs: eoc");
  if(candidate.first_word!==dut.first_word)$fatal(1,"disk phase field differs: first_word");
  if(candidate.flushed_generation!==dut.flushed_generation)$fatal(1,"disk phase field differs: flushed_generation");
  if(candidate.generation!==dut.generation)$fatal(1,"disk phase field differs: generation");
  if(candidate.head!==dut.head)$fatal(1,"disk phase field differs: head");
  if(candidate.headtag_d!==dut.headtag_d)$fatal(1,"disk phase field differs: headtag_d");
  if(candidate.host_debug!==dut.host_debug)$fatal(1,"disk phase field differs: host_debug");
  if(candidate.host_extra!==dut.host_extra)$fatal(1,"disk phase field differs: host_extra");
  if(candidate.host_fault!==dut.host_fault)$fatal(1,"disk phase field differs: host_fault");
  if(candidate.host_state!==dut.host_state)$fatal(1,"disk phase field differs: host_state");
  if(candidate.host_wait!==dut.host_wait)$fatal(1,"disk phase field differs: host_wait");
  if(candidate.next_ecc!==dut.next_ecc)$fatal(1,"disk phase field differs: next_ecc");
  if(candidate.phase!==dut.phase)$fatal(1,"disk phase field differs: phase");
  if(candidate.pulse_d!==dut.pulse_d)$fatal(1,"disk phase field differs: pulse_d");
  if(candidate.reads!==dut.reads)$fatal(1,"disk phase field differs: reads");
  if(candidate.sd_blk_cnt!==dut.sd_blk_cnt)$fatal(1,"disk phase field differs: sd_blk_cnt");
  if(candidate.sd_buff_din!==dut.sd_buff_din)$fatal(1,"disk phase field differs: sd_buff_din");
  if(candidate.sd_lba!==dut.sd_lba)$fatal(1,"disk phase field differs: sd_lba");
  if(candidate.sd_rd!==dut.sd_rd)$fatal(1,"disk phase field differs: sd_rd");
  if(candidate.sd_wr!==dut.sd_wr)$fatal(1,"disk phase field differs: sd_wr");
  if(candidate.sec!==dut.sec)$fatal(1,"disk phase field differs: sec");
  if(candidate.serial_debug!==dut.serial_debug)$fatal(1,"disk phase field differs: serial_debug");
  if(candidate.serial_extra!==dut.serial_extra)$fatal(1,"disk phase field differs: serial_extra");
  if(candidate.serial_fault!==dut.serial_fault)$fatal(1,"disk phase field differs: serial_fault");
  if(candidate.shift_next!==dut.shift_next)$fatal(1,"disk phase field differs: shift_next");
  if(candidate.store!==dut.store)$fatal(1,"disk phase field differs: store");
  if(candidate.store_addr!==dut.store_addr)$fatal(1,"disk phase field differs: store_addr");
  if(candidate.store_data!==dut.store_data)$fatal(1,"disk phase field differs: store_data");
  if(candidate.sync_word!==dut.sync_word)$fatal(1,"disk phase field differs: sync_word");
  if(candidate.valid!==dut.valid)$fatal(1,"disk phase field differs: valid");
  if(candidate.wi!==dut.wi)$fatal(1,"disk phase field differs: wi");
  if(candidate.word_q!==dut.word_q)$fatal(1,"disk phase field differs: word_q");
  if(candidate.wr_base!==dut.wr_base)$fatal(1,"disk phase field differs: wr_base");
  if(candidate.wr_bits!==dut.wr_bits)$fatal(1,"disk phase field differs: wr_bits");
  if(candidate.wr_block!==dut.wr_block)$fatal(1,"disk phase field differs: wr_block");
  if(candidate.wr_count!==dut.wr_count)$fatal(1,"disk phase field differs: wr_count");
  if(candidate.wr_ecc!==dut.wr_ecc)$fatal(1,"disk phase field differs: wr_ecc");
  if(candidate.wr_gate_d!==dut.wr_gate_d)$fatal(1,"disk phase field differs: wr_gate_d");
  if(candidate.wr_shift!==dut.wr_shift)$fatal(1,"disk phase field differs: wr_shift");
  if(candidate.wr_state!==dut.wr_state)$fatal(1,"disk phase field differs: wr_state");
  if(candidate.writes!==dut.writes)$fatal(1,"disk phase field differs: writes");
  if(dut.proof_captures!=previous_captures)begin
   captures=captures+1;
   if(gate_open!==0)$fatal(1,"cache capture overlapped enabled guest edge");
   if(dut.cyl!==before_cyl || dut.head!==before_head)$fatal(1,"cache source changed on capture edge");
   if(dut.cached_cyl!==before_cyl || dut.cached_head!==before_head)$fatal(1,"cache capture did not preserve source");
  end
  if(dut.cyl!==before_cyl || dut.head!==before_head)tag_changes=tag_changes+1;
  if(dut.head>=5)illegal_heads=illegal_heads+1;
  if(dut.host_fault)failures=failures+1;
 end endtask
 integer seed=32'h674d13ac,i,r;
 initial begin
  for(integer a=0;a<8192;a=a+1)begin dut.buffer[a]=(a*16'h9e37)^16'h584a;candidate.buffer[a]=dut.buffer[a];end
  // The PLL/reset guard is present before first useful cache capture even if
  // the clock-control enable register powers up high.
  repeat(4)begin high();clk=0;#2;end
  pll_reset=0;extra_ready=1;
  for(i=0;i<200000;i=i+1)begin
   // Drive before the falling edge, exactly as the core's raw enable contract.
   r=$random(seed);
   extra_ready=(r&7)!=0;extra_reset=(i%431)==0;
   pll_reset=(i%997)==0;remounted=(i%283)==0;
   attached=(i%509)>3;
   cyltag_n=(r&15)!=0;headtag_n=((r>>4)&15)!=0;conttag_n=((r>>8)&15)!=0;
   tagbus_n=~(r>>12);
   sd_ack=((r>>6)&7)==0;
   clk=0;#2;
   // A request changing AFTER the sampling edge cannot create a guest edge.
   if((i%5)==0)extra_ready=~extra_ready;
   high();
  end
  if(captures<100 || guest_edges<1000 || tag_changes<100 || illegal_heads<100 || failures<100)$fatal(1,"disk capture coverage missing captures=%0d guest=%0d tags=%0d illegal=%0d failures=%0d",captures,guest_edges,tag_changes,illegal_heads,failures);
  for(integer a=0;a<8192;a=a+1)if(candidate.buffer[a]!==dut.buffer[a])$fatal(1,"disk phase buffer differs");
  $display("DISK CACHE PHASE PASS ticks=%0d captures=%0d guest=%0d tags=%0d illegal=%0d failures=%0d",ticks,captures,guest_edges,tag_changes,illegal_heads,failures);$finish;
 end
endmodule
`default_nettype wire
