module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [132:0] stimulus,
 input wire freeze,held,request,write,input wire [11:0] index,
 input wire [17:0] state_data,output reg [137:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Same opposite-edge launch/capture shell and budgets for both variants.
 reg [168:0] launch;
 always @(negedge host_clk)
  launch<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [132:0] stimulus_r;wire [11:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [137:0] bank_q;
 always @(negedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire [4:0] bank_instruction_signals;
wire [31:0] bank_processor_debug;
wire [14:0] bank_processor_control;
wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_BNPC_02__drv;
wire bank_BNPC_03__drv;
wire bank_BNPC_04__drv;
wire bank_BNPC_05__drv;
wire bank_BNPC_06__drv;
wire bank_BNPC_07__drv;
wire bank_BNPC_08__drv;
wire bank_BNPC_09__drv;
wire bank_BNPC_10__drv;
wire bank_BNPC_11__drv;
wire bank_BNPC_12__drv;
wire bank_BNPC_13__drv;
wire bank_BNPC_14__drv;
wire bank_BNPC_15__drv;
wire bank_BNTGtCT_p_a__drv;
wire bank_BNTGtCT_p_b__drv;
wire bank_Block__drv;
wire bank_CHoldReq__drv;
wire bank_CLKEnable_p_a__drv;
wire bank_CLKEnable_p_b__drv;
wire bank_CLKEnable_p_c__drv;
wire bank_CRamClock__drv;
wire bank_DMuxClk__drv;
wire bank_DMuxData__drv;
wire bank_DoCBr__drv;
wire bank_FF_0__drv;
wire bank_FF_1__drv;
wire bank_FF_2__drv;
wire bank_FF_3__drv;
wire bank_FF_4__drv;
wire bank_FF_5__drv;
wire bank_FF_6__drv;
wire bank_FF_7__drv;
wire bank_FFok_p_a__drv;
wire bank_FFok_p_b__drv;
wire bank_Freeze__drv;
wire bank_IMRHPE_p___drv;
wire bank_IfuNextMacro_p___drv;
wire bank_MemClkEnable_p_a__drv;
wire bank_MemClkEnable_p_b__drv;
wire bank_MemSH__drv;
wire bank_MemSH_p___drv;
wire bank_Next_0__drv;
wire bank_Next_1__drv;
wire bank_Next_2__drv;
wire bank_Next_3__drv;
wire bank_NextMacro__drv;
wire bank_PrBlock_p___drv;
wire bank_SW__drv;
wire bank_SWm__drv;
wire bank_StartCycle_p_a__drv;
wire bank_TNIA_02__drv;
wire bank_TNIA_03__drv;
wire bank_TNIA_04__drv;
wire bank_TNIA_05__drv;
wire bank_TNIA_06__drv;
wire bank_TNIA_07__drv;
wire bank_TNIA_08__drv;
wire bank_TNIA_09__drv;
wire bank_TNIA_10__drv;
wire bank_TNIA_11__drv;
wire bank_TNIA_12__drv;
wire bank_TNIA_13__drv;
wire bank_TNIA_14__drv;
wire bank_TNIA_15__drv;
wire bank_UseDMD__drv;
wire bank__u_Dbuf__drv;
wire bank__u_Map__drv;
wire bank_jcnt__drv;
wire bank_rMIRa__drv;
assign bank_q={bank_rMIRa__drv,bank_jcnt__drv,bank__u_Map__drv,bank__u_Dbuf__drv,bank_UseDMD__drv,bank_TNIA_15__drv,bank_TNIA_14__drv,bank_TNIA_13__drv,bank_TNIA_12__drv,bank_TNIA_11__drv,bank_TNIA_10__drv,bank_TNIA_09__drv,bank_TNIA_08__drv,bank_TNIA_07__drv,bank_TNIA_06__drv,bank_TNIA_05__drv,bank_TNIA_04__drv,bank_TNIA_03__drv,bank_TNIA_02__drv,bank_StartCycle_p_a__drv,bank_SWm__drv,bank_SW__drv,bank_PrBlock_p___drv,bank_NextMacro__drv,bank_Next_3__drv,bank_Next_2__drv,bank_Next_1__drv,bank_Next_0__drv,bank_MemSH_p___drv,bank_MemSH__drv,bank_MemClkEnable_p_b__drv,bank_MemClkEnable_p_a__drv,bank_IfuNextMacro_p___drv,bank_IMRHPE_p___drv,bank_Freeze__drv,bank_FFok_p_b__drv,bank_FFok_p_a__drv,bank_FF_7__drv,bank_FF_6__drv,bank_FF_5__drv,bank_FF_4__drv,bank_FF_3__drv,bank_FF_2__drv,bank_FF_1__drv,bank_FF_0__drv,bank_DoCBr__drv,bank_DMuxData__drv,bank_DMuxClk__drv,bank_CRamClock__drv,bank_CLKEnable_p_c__drv,bank_CLKEnable_p_b__drv,bank_CLKEnable_p_a__drv,bank_CHoldReq__drv,bank_Block__drv,bank_BNTGtCT_p_b__drv,bank_BNTGtCT_p_a__drv,bank_BNPC_15__drv,bank_BNPC_14__drv,bank_BNPC_13__drv,bank_BNPC_12__drv,bank_BNPC_11__drv,bank_BNPC_10__drv,bank_BNPC_09__drv,bank_BNPC_08__drv,bank_BNPC_07__drv,bank_BNPC_06__drv,bank_BNPC_05__drv,bank_BNPC_04__drv,bank_BNPC_03__drv,bank_BNPC_02__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv,bank_processor_control,bank_processor_debug,bank_instruction_signals};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 ContA_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 ContA_m_Rev_m_Cd_monitor #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.ALUCarry(stimulus_r[0]),
.ASEL_0_p_a(stimulus_r[1]),
.BMux_00(stimulus_r[2] | bank_BMux_00__drv),
.BMux_01(stimulus_r[3] | bank_BMux_01__drv),
.BMux_02(stimulus_r[4] | bank_BMux_02__drv),
.BMux_03(stimulus_r[5] | bank_BMux_03__drv),
.BMux_04(stimulus_r[6] | bank_BMux_04__drv),
.BMux_05(stimulus_r[7] | bank_BMux_05__drv),
.BMux_06(stimulus_r[8] | bank_BMux_06__drv),
.BMux_07(stimulus_r[9] | bank_BMux_07__drv),
.BMux_08(stimulus_r[10] | bank_BMux_08__drv),
.BMux_09(stimulus_r[11] | bank_BMux_09__drv),
.BMux_10(stimulus_r[12] | bank_BMux_10__drv),
.BMux_11(stimulus_r[13] | bank_BMux_11__drv),
.BMux_12(stimulus_r[14] | bank_BMux_12__drv),
.BMux_13(stimulus_r[15] | bank_BMux_13__drv),
.BMux_14(stimulus_r[16] | bank_BMux_14__drv),
.BMux_15(stimulus_r[17] | bank_BMux_15__drv),
.BNPC_02(stimulus_r[18] | bank_BNPC_02__drv),
.BNPC_03(stimulus_r[19] | bank_BNPC_03__drv),
.BNPC_04(stimulus_r[20] | bank_BNPC_04__drv),
.BNPC_05(stimulus_r[21] | bank_BNPC_05__drv),
.BNPC_06(stimulus_r[22] | bank_BNPC_06__drv),
.BNPC_07(stimulus_r[23] | bank_BNPC_07__drv),
.BNPC_08(stimulus_r[24] | bank_BNPC_08__drv),
.BNPC_09(stimulus_r[25] | bank_BNPC_09__drv),
.BNPC_10(stimulus_r[26] | bank_BNPC_10__drv),
.BNPC_11(stimulus_r[27] | bank_BNPC_11__drv),
.BNPC_12(stimulus_r[28] | bank_BNPC_12__drv),
.BNPC_13(stimulus_r[29] | bank_BNPC_13__drv),
.BNPC_14(stimulus_r[30] | bank_BNPC_14__drv),
.BNPC_15(stimulus_r[31] | bank_BNPC_15__drv),
.BSEL_0_p_(stimulus_r[32]),
.CLK_ca_p_(stimulus_r[33]),
.CPAddr_0_p_(stimulus_r[34]),
.CPAddr_1_p_(stimulus_r[35]),
.CPAddr_2_p_(stimulus_r[36]),
.CPOut_0(stimulus_r[37]),
.CPOut_1(stimulus_r[38]),
.CPOut_2(stimulus_r[39]),
.CPOut_3(stimulus_r[40]),
.CPOut_4(stimulus_r[41]),
.CPOut_5(stimulus_r[42]),
.CPOut_6(stimulus_r[43]),
.CPOut_7(stimulus_r[44]),
.CPOut_8(stimulus_r[45]),
.CPStrb_p_(stimulus_r[46]),
.Cnt_eq_Zero_p_(stimulus_r[47]),
.DMuxClk(stimulus_r[48] | bank_DMuxClk__drv),
.DMuxData(stimulus_r[49] | bank_DMuxData__drv),
.Error_p_(stimulus_r[50]),
.FF_0(stimulus_r[51] | bank_FF_0__drv),
.Hold(stimulus_r[52]),
.IOatt(stimulus_r[53]),
.IfuAddr_04_p_(stimulus_r[54]),
.IfuAddr_05_p_(stimulus_r[55]),
.IfuAddr_06_p_(stimulus_r[56]),
.IfuAddr_07_p_(stimulus_r[57]),
.IfuAddr_08_p_(stimulus_r[58]),
.IfuAddr_09_p_(stimulus_r[59]),
.IfuAddr_10_p_(stimulus_r[60]),
.IfuAddr_11_p_(stimulus_r[61]),
.IfuAddr_12_p_(stimulus_r[62]),
.IfuAddr_13_p_(stimulus_r[63]),
.Overflow_p_(stimulus_r[64]),
.QBit_p_(stimulus_r[65]),
.ResEqZero_p_(stimulus_r[66]),
.ResLtZero_p_(stimulus_r[67]),
.RmLtZero_p_(stimulus_r[68]),
.RmOdd_p_(stimulus_r[69]),
.SWm(stimulus_r[70] | bank_SWm__drv),
.SetRun(stimulus_r[71]),
.SetRunRfsh(stimulus_r[72]),
.SetSS_p_(stimulus_r[73]),
.StopMIRClk(stimulus_r[74]),
.TNIA_02(stimulus_r[75] | bank_TNIA_02__drv),
.TNIA_03(stimulus_r[76] | bank_TNIA_03__drv),
.TNIA_04(stimulus_r[77] | bank_TNIA_04__drv),
.TNIA_05(stimulus_r[78] | bank_TNIA_05__drv),
.TNIA_06(stimulus_r[79] | bank_TNIA_06__drv),
.TNIA_07(stimulus_r[80] | bank_TNIA_07__drv),
.TNIA_08(stimulus_r[81] | bank_TNIA_08__drv),
.TNIA_09(stimulus_r[82] | bank_TNIA_09__drv),
.TNIA_10(stimulus_r[83] | bank_TNIA_10__drv),
.TNIA_11(stimulus_r[84] | bank_TNIA_11__drv),
.TNIA_12(stimulus_r[85] | bank_TNIA_12__drv),
.TNIA_13(stimulus_r[86] | bank_TNIA_13__drv),
.TNIA_14(stimulus_r[87] | bank_TNIA_14__drv),
.TNIA_15(stimulus_r[88] | bank_TNIA_15__drv),
.TWReq_01(stimulus_r[89]),
.TWReq_02(stimulus_r[90]),
.TWReq_03(stimulus_r[91]),
.TWReq_04(stimulus_r[92]),
.TWReq_05(stimulus_r[93]),
.TWReq_06(stimulus_r[94]),
.TWReq_07(stimulus_r[95]),
.TWReq_08(stimulus_r[96]),
.TWReq_09(stimulus_r[97]),
.TWReq_10(stimulus_r[98]),
.TWReq_11(stimulus_r[99]),
.TWReq_12(stimulus_r[100]),
.TWReq_13(stimulus_r[101]),
.TWReq_14(stimulus_r[102]),
.TWReq_15(stimulus_r[103]),
.WantIfuHold_p_(stimulus_r[104]),
.dBlock_p_(stimulus_r[105]),
.dFF_0(stimulus_r[106]),
.dFF_1(stimulus_r[107]),
.dFF_2(stimulus_r[108]),
.dFF_3(stimulus_r[109]),
.dFF_4(stimulus_r[110]),
.dFF_5(stimulus_r[111]),
.dFF_6(stimulus_r[112]),
.dFF_7(stimulus_r[113]),
.dIMOut_07(stimulus_r[114]),
.dIMOut_08(stimulus_r[115]),
.dIMOut_09(stimulus_r[116]),
.dIMOut_10(stimulus_r[117]),
.dIMOut_11(stimulus_r[118]),
.dIMOut_12(stimulus_r[119]),
.dIMOut_13(stimulus_r[120]),
.dIMOut_14(stimulus_r[121]),
.dIMOut_15(stimulus_r[122]),
.dIMRH(stimulus_r[123]),
.dJCN_0(stimulus_r[124]),
.dJCN_1(stimulus_r[125]),
.dJCN_2(stimulus_r[126]),
.dJCN_3(stimulus_r[127]),
.dJCN_4(stimulus_r[128]),
.dJCN_5(stimulus_r[129]),
.dJCN_6(stimulus_r[130]),
.dJCN_7(stimulus_r[131]),
.rMIRa(stimulus_r[132] | bank_rMIRa__drv),
.instruction_signals(bank_instruction_signals),
.processor_debug(bank_processor_debug),
.processor_control(bank_processor_control),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.BNPC_02__drv(bank_BNPC_02__drv),
.BNPC_03__drv(bank_BNPC_03__drv),
.BNPC_04__drv(bank_BNPC_04__drv),
.BNPC_05__drv(bank_BNPC_05__drv),
.BNPC_06__drv(bank_BNPC_06__drv),
.BNPC_07__drv(bank_BNPC_07__drv),
.BNPC_08__drv(bank_BNPC_08__drv),
.BNPC_09__drv(bank_BNPC_09__drv),
.BNPC_10__drv(bank_BNPC_10__drv),
.BNPC_11__drv(bank_BNPC_11__drv),
.BNPC_12__drv(bank_BNPC_12__drv),
.BNPC_13__drv(bank_BNPC_13__drv),
.BNPC_14__drv(bank_BNPC_14__drv),
.BNPC_15__drv(bank_BNPC_15__drv),
.BNTGtCT_p_a__drv(bank_BNTGtCT_p_a__drv),
.BNTGtCT_p_b__drv(bank_BNTGtCT_p_b__drv),
.Block__drv(bank_Block__drv),
.CHoldReq__drv(bank_CHoldReq__drv),
.CLKEnable_p_a__drv(bank_CLKEnable_p_a__drv),
.CLKEnable_p_b__drv(bank_CLKEnable_p_b__drv),
.CLKEnable_p_c__drv(bank_CLKEnable_p_c__drv),
.CRamClock__drv(bank_CRamClock__drv),
.DMuxClk__drv(bank_DMuxClk__drv),
.DMuxData__drv(bank_DMuxData__drv),
.DoCBr__drv(bank_DoCBr__drv),
.FF_0__drv(bank_FF_0__drv),
.FF_1__drv(bank_FF_1__drv),
.FF_2__drv(bank_FF_2__drv),
.FF_3__drv(bank_FF_3__drv),
.FF_4__drv(bank_FF_4__drv),
.FF_5__drv(bank_FF_5__drv),
.FF_6__drv(bank_FF_6__drv),
.FF_7__drv(bank_FF_7__drv),
.FFok_p_a__drv(bank_FFok_p_a__drv),
.FFok_p_b__drv(bank_FFok_p_b__drv),
.Freeze__drv(bank_Freeze__drv),
.IMRHPE_p___drv(bank_IMRHPE_p___drv),
.IfuNextMacro_p___drv(bank_IfuNextMacro_p___drv),
.MemClkEnable_p_a__drv(bank_MemClkEnable_p_a__drv),
.MemClkEnable_p_b__drv(bank_MemClkEnable_p_b__drv),
.MemSH__drv(bank_MemSH__drv),
.MemSH_p___drv(bank_MemSH_p___drv),
.Next_0__drv(bank_Next_0__drv),
.Next_1__drv(bank_Next_1__drv),
.Next_2__drv(bank_Next_2__drv),
.Next_3__drv(bank_Next_3__drv),
.NextMacro__drv(bank_NextMacro__drv),
.PrBlock_p___drv(bank_PrBlock_p___drv),
.SW__drv(bank_SW__drv),
.SWm__drv(bank_SWm__drv),
.StartCycle_p_a__drv(bank_StartCycle_p_a__drv),
.TNIA_02__drv(bank_TNIA_02__drv),
.TNIA_03__drv(bank_TNIA_03__drv),
.TNIA_04__drv(bank_TNIA_04__drv),
.TNIA_05__drv(bank_TNIA_05__drv),
.TNIA_06__drv(bank_TNIA_06__drv),
.TNIA_07__drv(bank_TNIA_07__drv),
.TNIA_08__drv(bank_TNIA_08__drv),
.TNIA_09__drv(bank_TNIA_09__drv),
.TNIA_10__drv(bank_TNIA_10__drv),
.TNIA_11__drv(bank_TNIA_11__drv),
.TNIA_12__drv(bank_TNIA_12__drv),
.TNIA_13__drv(bank_TNIA_13__drv),
.TNIA_14__drv(bank_TNIA_14__drv),
.TNIA_15__drv(bank_TNIA_15__drv),
.UseDMD__drv(bank_UseDMD__drv),
._u_Dbuf__drv(bank__u_Dbuf__drv),
._u_Map__drv(bank__u_Map__drv),
.jcnt__drv(bank_jcnt__drv),
.rMIRa__drv(bank_rMIRa__drv)
);
endmodule
