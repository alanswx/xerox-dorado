#include "Vconta_full_fixture.h"
#include "verilated.h"
#include "ports.h"
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>

static Vconta_full_fixture d;
static uint32_t rng=0x1353ca49;
static unsigned edges,holds,late_changes,requests,walked_bits;
static std::array<unsigned,9>writes{};
static uint32_t random_word() { rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng; }
static void check(bool ok,const char *why) {
    if (!ok) { std::fprintf(stderr,"FAIL edge=%u: %s\n",edges,why);std::exit(1); }
}
template<class W>static unsigned get(const W&bus,unsigned start,unsigned width) {
    unsigned value=0;
    for (unsigned i=0;i<width;++i)value|=((bus[(start+i)/32]>>((start+i)%32))&1u)<<i;
    return value;
}
static void equal() {
    for (const auto &w:state_words)
        check(get(d.original_state,w.offset,w.width)==get(d.candidate_state,w.offset,w.width),"board physical state differs");
    for (unsigned i=0;i<(OUTPUTS+31)/32;++i)
        check(d.original_outputs[i]==d.candidate_outputs[i],"board output differs");
}
static void pins() { for (unsigned i=0;i<(INPUTS+31)/32;++i)d.stimulus[i]=random_word(); }
static void cycle(bool run,bool reference,bool late=false,bool compare=true) {
    d.run=run;d.run_ref=reference;d.host_clk=0;d.eval();
    if (late) { d.run=!run;d.run_ref=!reference;d.eval();++late_changes; }
    if (d.ref_advance)for (unsigned i=0;i<9;++i)if ((d.ref_write>>i)&1)++writes[i];
    if (!d.advance)++holds;
    d.host_clk=1;d.eval();++edges;
    if (compare)equal();
}
static unsigned access(unsigned word,bool write,unsigned data=0,bool error=false,bool compare=true) {
    d.state_index=word;d.write=write;d.state_data=data;d.request=1;
    cycle(false,false,false,false);++requests;
    unsigned waited=0;
    while (!d.done) {
        // Spoof RAM writes while a scan owns the board. These must be ignored.
        d.request=1;d.state_index=(75u<<5)|16;d.write=1;d.state_data=0x3ffff;
        cycle(false,false,false,false);
        check(++waited<=682,"scan completion timeout");
    }
    d.request=0;
    if (word<38 && !error) check(waited==681,"scan rotation length differs");
    check(!d.scan_hold_required && !d.scan_fault,"completed access still held/faulted");
    check(bool(d.error)==error,"invalid state access accepted");
    if (compare) equal();
    return d.result;
}

int main(int argc,char **argv) {
    Verilated::commandArgs(argc,argv);
    d.system_reset=0;d.host_clk=1;d.run=0;d.run_ref=0;d.freeze=0;d.held=0;
    d.request=1;d.write=0;d.state_index=0;d.state_data=0;d.eval();
    d.freeze=1;d.held=1;d.request=0;cycle(false,false);
    d.system_reset=1;d.request=1;d.write=1;
    d.state_index=(75u<<5)|16;d.state_data=0x3ffff;
    cycle(false,false,false,false);
    check(!d.frozen&&!d.done&&!d.error&&!d.scan_hold_required&&!d.scan_fault,"system reset admitted access");
    equal();
    d.system_reset=0;cycle(false,false);
    check(d.frozen&&!d.done,"reset reentry request accepted");
    d.request=0;d.freeze=0;d.held=0;cycle(false,false);
    d.request=1;d.write=0;d.state_index=0;d.state_data=0;
    for (unsigned i=0;i<20000;++i) {
        pins();bool advance=(random_word()&3)!=0;
        cycle(advance,advance,i%3==0);
        check(!d.done,"running request accepted");
    }
    d.request=0;cycle(false,false);
    d.freeze=1;d.held=0;cycle(false,false);check(!d.frozen,"unheld freeze accepted");
    d.held=1;d.request=1;d.write=1;d.state_index=0;d.state_data=(1u<<18)-1;
    cycle(false,false);check(d.frozen&&!d.done,"entry request accepted");
    auto saved_inputs=d.stimulus;
    std::array<unsigned,WORDS>image{};
    std::array<bool,4096>valid{};
    for (unsigned i=0;i<WORDS;++i) {
        const auto &w=state_words[i];valid[w.word]=true;
        image[i]=access(w.word,false);
        check(image[i]==get(d.original_state,w.offset,w.width),"state export differs");
    }
    for (unsigned i=0;i<WORDS;++i) {
        const auto &w=state_words[i];
        for (unsigned bit=0;bit<w.width;++bit) {
            unsigned value=image[i]^(1u<<bit);
            access(w.word,true,value,false,false);
            check(access(w.word,false,0,false,false)==value,"state bit write/readback differs");
            for (unsigned j=0;j<WORDS;++j)
                check(get(d.candidate_state,state_words[j].offset,state_words[j].width)==(i==j?value:image[j]),"state write affected another package/row");
            access(w.word,true,image[i]);++walked_bits;
        }
        // Unused high response bits are zero; write padding cannot create
        // hidden state or clobber another package's register.
        access(w.word,true,image[i]|(((1u<<18)-1)^((1u<<w.width)-1)));
        check(access(w.word,false)==image[i],"padding changed physical state");
    }
    for (unsigned word=0;word<4096;++word)if (!valid[word])access(word,true,random_word()&((1u<<18)-1),true);
    for (unsigned i=0;i<WORDS;++i)check(access(state_words[i].word,false)==image[i],"invalid access mutated state");
    // Reference remains untouched at the saved real-board boundary while
    // the candidate alone executes its original feedback and strobes.
    d.freeze=0;d.request=0;cycle(false,false);d.held=0;
    for (unsigned i=0;i<10000;++i) { pins();cycle(true,false,false,false); }
    bool changed=false;
    for (unsigned i=0;i<WORDS;++i) {
        changed|=get(d.candidate_state,state_words[i].offset,state_words[i].width)!=image[i];
        check(get(d.original_state,state_words[i].offset,state_words[i].width)==image[i],"reference advanced during continuation");
    }
    check(changed,"candidate-only continuation did not change state");
    d.stimulus=saved_inputs;cycle(false,false,false,false);
    d.freeze=1;d.held=1;cycle(false,false,false,false);check(d.frozen,"second freeze failed");
    for (unsigned i=0;i<WORDS;++i)access(state_words[i].word,true,image[i]^((1u<<state_words[i].width)-1),false,false);
    for (unsigned i=0;i<WORDS;++i)
        check(access(state_words[i].word,false,0,false,false)==(image[i]^((1u<<state_words[i].width)-1)),"destructive state write differs");
    for (unsigned i=0;i<WORDS;++i)access(state_words[i].word,true,image[i],false,false);
    equal();
    d.freeze=0;d.request=0;cycle(false,false);check(!d.frozen,"release failed");
    for (unsigned i=0;i<20;++i) { pins();cycle(false,false); }
    d.freeze=1;cycle(false,false);
    for (unsigned i=0;i<WORDS;++i)check(access(state_words[i].word,false)==image[i],"recapture differs before resumed guest edge");
    d.freeze=0;d.request=0;cycle(false,false);d.held=0;
    // No warm-up guest edge. The first real edge and20,000 further clocks
    // must match the original, including actual pending write windows.
    for (unsigned i=0;i<20000;++i) {
        pins();bool advance=(random_word()&3)!=0;cycle(advance,advance,i%3==0);
    }
    d.request=0;cycle(false,false);
    d.freeze=1;d.held=1;cycle(false,false);
    d.request=1;d.write=1;d.state_index=0;d.state_data=0x12345;
    cycle(false,false,false,false);
    d.request=0;cycle(false,false,false,false);cycle(false,false,false,false);
    check(d.scan_hold_required,"partial scan lost board hold");
    d.freeze=0;d.held=0;cycle(false,false,false,false);
    check(d.scan_fault&&d.scan_hold_required&&d.error&&d.done,"lost boundary not quarantined");
    auto quarantined=d.candidate_state;
    d.request=1;d.write=1;d.state_index=(75u<<5)|16;d.state_data=0x3ffff;
    for (unsigned i=0;i<20;++i) {
        pins();cycle(true,false,false,false);
        check(d.scan_hold_required&&d.scan_fault&&d.frozen,"quarantine released");
        for (unsigned word=0;word<(STATE_BITS+31)/32;++word)
            check(d.candidate_state[word]==quarantined[word],"quarantined board state changed");
    }
    d.system_reset=1;d.freeze=1;d.held=1;cycle(false,false,false,false);
    check(!d.frozen&&!d.done&&!d.error&&!d.scan_hold_required&&!d.scan_fault,"system reset failed to close access");
    d.system_reset=0;cycle(false,false,false,false);
    check(d.frozen&&!d.done,"fault-reset reentry request accepted");
    d.request=0;cycle(false,false,false,false);
    check(walked_bits==1353&&late_changes>10000&&holds>10000,"insufficient coverage");
    std::printf("FULL CONTA RESTORE PASS: %u host edges, %u held, %u late-enable changes, %u requests; all1353 physical bits,192 state words,%u output bits; real writes=",edges,holds,late_changes,requests,OUTPUTS);
    for (auto n:writes)std::printf(" %u",n);
    std::puts("; no machine/physical qualification");
}
