from pathlib import Path
import hashlib,json,subprocess,tarfile,time
project=Path('/home/alans/mister/Dorado_Serial70MemoryFanout_20261020');pid=2602043
live=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  cwd=(proc/'cwd').resolve(strict=True)
  if cwd.is_relative_to(project):live.append(int(proc.name))
 except(OSError,RuntimeError):pass
assert not Path('/proc/'+str(pid)).exists()and not live,live
rbfs=[str(p.relative_to(project))for p in project.rglob('*')if p.is_file()and p.suffix in('.rbf','.sof')]
assert not rbfs
assert 'Fanout experiment terminal;'in(project/'driver.log').read_text()
record=json.loads((project/'fanout-integration.json').read_text())
changed=[n for n,d in record['source_hashes'].items()if hashlib.sha256((project/n).read_bytes()).hexdigest()!=d]
assert len(record['source_hashes'])==660 and not changed,changed
state=dict(status='TERMINAL_DRIVER_COMPLETE',builder_pid=pid,builder_live=False,project_processes=live,assembly_started=False,rbfs=rbfs,sta_started=(project/'sta.log').exists(),observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),prepared_inputs=660,prepared_inputs_changed=changed)
(project/'terminal-state.json').write_text(json.dumps(state,indent=2)+'\n')
packet=Path('/home/alans/mister/dorado-serial70-terminal-20261020.tar.gz');assert not packet.exists()
skip={'db','incremental_db','obj','obj_xml','__pycache__'}
with tarfile.open(packet,'w:gz')as archive:
 for p in sorted(project.rglob('*')):
  rel=p.relative_to(project)
  if not p.is_file()or p.is_symlink()or any(x in skip for x in rel.parts)or p.name.startswith('._')or p.suffix in('.o','.a','.so','.pyc'):continue
  if p.read_bytes().startswith((b'\x7fELF',b'\xcf\xfa\xed\xfe')):continue
  archive.add(p,arcname='serial70/'+str(rel),recursive=False)
print(json.dumps(dict(state=state,packet=str(packet),sha256=hashlib.sha256(packet.read_bytes()).hexdigest(),bytes=packet.stat().st_size)))
