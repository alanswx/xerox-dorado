// Passive bring-up observation. Never drives the controller or guest state.
`default_nettype none
module dorado_serial_DskEth__dorado_receive_monitor_snapshot (
    input wire state_host_clk,state_advance,state_freeze,state_guest_held,state_request,state_write,
    input wire [1:0] state_index,input wire [17:0] state_data,
    output reg state_frozen=1'b0,state_done=1'b0,state_error=1'b0,
    output reg [17:0] state_result,
    input wire clk,
    input wire fifo_write_n, fifo_eop,
    input wire [15:0] fifo_word,
    input wire input_n, input_eop,
    input wire [7:0] tioa,
    input wire [15:0] input_word,
    output wire [31:0] observation
);
    reg write_d=1, input_d=1;
    reg [7:0] received=0, consumed=0, wire_status=0, cpu_status=0;
    
    assign observation={received,consumed,wire_status,cpu_status};

 wire state_hold=state_freeze && state_guest_held;
 wire state_accept=state_hold && state_frozen && state_request;
 wire state_valid=!state_index[1];
 always @(posedge state_host_clk)begin
  state_frozen<=state_hold;state_done<=state_accept;state_error<=state_accept && !state_valid;
  if(state_accept)begin
   state_result<=18'b0;
   if(state_valid)begin
    if(state_write)begin
     if(!state_index[0]){wire_status[1:0],consumed,received}<=state_data;
     else {write_d,input_d,cpu_status,wire_status[7:2]}<=state_data[15:0];
    end else if(!state_index[0])state_result<={wire_status[1:0],consumed,received};
    else state_result<={2'b0,write_d,input_d,cpu_status,wire_status[7:2]};
   end
  end
  if(!state_hold && state_advance)begin
begin
        write_d<=fifo_write_n;
        input_d<=input_n;
        if(write_d && !fifo_write_n && fifo_eop) begin
            received<=received+1'b1;
            wire_status<=fifo_word[7:0];
        end
        if(input_d && !input_n && tioa==8'o15 && input_eop) begin
            consumed<=consumed+1'b1;
            cpu_status<=input_word[7:0];
        end
    end
  end
 end
endmodule
`default_nettype wire
