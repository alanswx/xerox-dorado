from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve();project=root/'terminal-fit';qualification=root/'qualification';proof=qualification/'proof'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record=load(project/'network-pause-integration.json');state=load(project/'terminal-state.json')
assert state['status']=='TERMINAL_DRIVER_COMPLETE'and not state['builder_live']and not state['project_processes']and not state['rbfs']and not state['assembly_started']
assert state['prepared_inputs']==661 and not state['prepared_inputs_changed']
assert len(record['source_hashes'])==661 and not record['assembly_permitted']
for n,h in record['source_hashes'].items():assert sha(project/n)==h,n
for n,h in load(qualification/'review-tools/frozen-tools.json').items():assert sha(qualification/'review-tools'/n)==h,n
source=load(proof/'source-audit.json');capacity=load(proof/'capacity-audit.json');timing=load(proof/'timing-audit.json');crossing=load(proof/'crossings-audit.json')
classification=load(qualification/'classification/classification.json')
assert source['status']=='PASS_NATIVE_NETWORK_PAUSE_SOURCE_ONLY'and len(source['failure_controls'])==12 and source['original_pin_connections']==2761
assert source['new_top_state_bits']==6 and source['constraints_unchanged']and not source['real_pause_barriers']
assert classification['status']=='PASS_NATIVE_MEMORY_PAUSE_STATE_ACCESS_PENDING'and len(classification['failure_controls'])==15
assert classification['totals']=={'PHYSICAL BOARD':1957048,'PRIVATE BOARD':4578,'PRIVATE TRANSPORT':69,'WRAPPER ACCESS PENDING':132606}
assert classification['subroutine_review']['required_bits']==120 and classification['subroutine_review']['function_scratch_bits']==215
assert capacity['status']=='PASS_CAPACITY_TIMING_AND_BARRIERS_PENDING'and capacity['alms']==41464 and capacity['available_alms']==41910 and capacity['fit_registers']==52155
assert len(capacity['failure_controls'])==15 and len(capacity['real_service_hierarchy'])==5 and not capacity['timing_qualified']
for n,h in capacity['input_hashes'].items():assert sha(project/n)==h,n
assert timing['status']=='REJECTED_TIMING'and len(timing['failure_controls'])==6
for c in timing['clocks']:assert len(timing['clocks'][c])>0
want={('7_slow_1100mv_100c','setup'):-1.668,('7_slow_1100mv_-40c','setup'):-1.326,('7_slow_1100mv_-40c','hold'):-.292}
assert {(r['corner'],r['kind']):r['slack_ns']for r in timing['violations']}==want
assert min(r['slack_ns']for r in timing['timing']if r['kind'].startswith('sdram'))==1.662
for n,h in timing['input_hashes'].items():
 p=Path(n);f=qualification/'native59-timing'/p.name if p.name.startswith('native59-')else project/'core'/p.name
 assert sha(f)==h,n
assert crossing['status']=='REJECTED_CROSSING_TIMING'and crossing['reports']==304 and len(crossing['records'])==304 and len(crossing['violations'])==17 and len(crossing['failure_controls'])==3
assert all(r['mode']=='setup'for r in crossing['violations'])
for old,alms,controls in(('69',41468,8),('70',41449,11)):
 c=load(proof/('capacity-regression-serial'+old+'.json'));assert c['alms']==alms and len(c['failure_controls'])==controls
sys.path.insert(0,str(qualification/'review-tools/fpga/mister/snapshot'))
import audit_serial_chipwidth_capacity as cap
import audit_serial_chipwidth_timing as sta
import audit_adapter_crossings as crossings
fresh=cap.review(project,source,classification);assert fresh['alms']==capacity['alms']and fresh['real_service_hierarchy']==capacity['real_service_hierarchy'];assert len(cap.controls(project,source,classification))==15
fresh=json.loads(json.dumps(sta.audit(project/'core',qualification/'native59-timing',allow_timing_failure=True)));assert fresh['timing']==timing['timing']and fresh['framework_exceptions']==timing['framework_exceptions']and fresh['clocks']==timing['clocks']
assert len(sta.controls(qualification/'native59-timing',qualification/'native59-timing','native59'))==6
fresh=crossings.audit(project/'core','serial61',True);assert fresh['records']==crossing['records']and len(crossings.controls(project/'core','serial61'))==3
assert load(proof/'actual-restaged-hashes.json')==record['source_hashes']
assert load(proof/'archive-replay.json')['status']=='PASS'
assert load(proof/'archive-rebuild-source-audit.json')==source
again=load(qualification/'archive-rebuild-classification/classification.json')
a=dict(classification);b=dict(again)
for key in ('xml_sha256','normalized_xml_sha256'):a.pop(key);b.pop(key)
assert a==b
assert load(qualification/'classification/provenance.json')==load(qualification/'archive-rebuild-classification/provenance.json')
for label in ('classification','archive-rebuild-classification'):
 c=load(qualification/label/'classification.json')
 assert sha(qualification/label/'native.xml')==c['xml_sha256']
 assert sha(qualification/label/'native-normalized.xml')==c['normalized_xml_sha256']
print(json.dumps(dict(status='PASS_REJECTION_RECEIPT',native71='REJECTED_TIMING',prepared_inputs=661,original_pins=2761,alms=41464,free_alms=446,source_state_capacity_timing_crossing_controls=[12,15,15,6,3],crossing_groups=304,failed_setup_groups=17,sdram_io_minimum_ns=1.662,limits='No RBF, FPGA reload, new speed, complete service coordinator or full snapshot. Native59 remains the qualified hardware baseline.'),indent=2))
