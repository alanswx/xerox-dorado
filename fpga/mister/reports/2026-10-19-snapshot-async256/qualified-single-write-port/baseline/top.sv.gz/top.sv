module snapshot_fit(
 input wire host_clk,advance,input wire [7:0] address,
 input wire [3:0] data,select_mb,input wire ce_f,we_mb_n,we_f_n,
 input wire freeze,held,request,write,input wire [8:0] index,
 input wire [3:0] state_data,state_data_f,
 output reg [1:0] frozen,done,error,
 output reg [3:0] result_mb,result_f,q_mb,output reg q_f);
 // Matched50MHz/opposite-edge shell:10ns embedded data paths.
 // Both variants include the same2ns max/0ns min virtual I/O contract.
 reg [40:0] launch;
 always @(negedge host_clk)
  launch<={advance,address,data,select_mb,ce_f,we_mb_n,we_f_n,
            freeze,held,request,write,index,state_data,state_data_f};
 wire step_r,ce_r,wem_r,wef_r,freeze_r,held_r,request_r,write_r;
 wire [7:0] address_r;wire [3:0] data_r,select_r,state_r,statef_r;
 wire [8:0] index_r;
 assign {step_r,address_r,data_r,select_r,ce_r,wem_r,wef_r,
         freeze_r,held_r,request_r,write_r,index_r,state_r,statef_r}=launch;
 wire [1:0] frozen_w,done_w,error_w;
 wire [3:0] resultmb_w,resultf_w,qmb_w;wire qf_w;
 always @(negedge host_clk)
  {frozen,done,error,result_mb,result_f,q_mb,q_f}<=
  {frozen_w,done_w,error_w,resultmb_w,resultf_w,qmb_w,qf_w};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_MB7071H_snapshot mb(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(frozen_w[0]),
 .state_done(done_w[0]),.state_error(error_w[0]),.state_result(resultmb_w),
`else
 assign {frozen_w,done_w,error_w,resultmb_w,resultf_w}=14'b0;
 cell_MB7071H mb(
`endif
 .sys_clk(host_clk),
 .p2(wem_r),.p3(select_r[3]),.p4(select_r[2]),
 .p5(select_r[1]),.p6(select_r[0]),
 .p7(address_r[7]),.p8(address_r[6]),.p9(address_r[5]),.p10(address_r[4]),
 .p11(address_r[3]),.p12(address_r[2]),.p13(address_r[1]),.p14(address_r[0]),
 .p15(1'b0),.p16(data_r[3]),.p17(data_r[2]),.p18(data_r[1]),.p19(data_r[0]),
 .p20(qmb_w[3]),.p21(qmb_w[2]),.p22(qmb_w[1]),.p23(qmb_w[0]));
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_F10414_snapshot f(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(statef_r),.state_frozen(frozen_w[1]),
 .state_done(done_w[1]),.state_error(error_w[1]),.state_result(resultf_w),
`else
 cell_F10414 f(
`endif
 .sys_clk(host_clk),
 .p1(address_r[7]),.p2(address_r[6]),.p3(address_r[5]),.p4(address_r[4]),
 .p7(ce_r),.p9(address_r[3]),.p10(address_r[2]),.p11(address_r[1]),.p12(address_r[0]),
 .p13(data_r[0]),.p14(wef_r),.p15(qf_w));
endmodule
