module async256_fixture(
 input wire host_clk,ref_clk,advance,freeze,held,request,write,
 input wire [8:0] index,input wire [3:0] state_data,state_data_f,
 input wire [7:0] address,input wire [3:0] data,select_mb,
 input wire ce_f,we_mb_n,we_f_n,
 output wire [1:0] frozen,done,error,
 output wire [3:0] result_mb,result_f,q_mb,ref_q_mb,
 output wire q_f,ref_q_f,
 output wire [1023:0] memory_mb,ref_memory_mb,
 output wire [255:0] memory_f,ref_memory_f);
 cell_MB7071H_snapshot candidate_mb(
 .state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),
 .state_guest_held(held),.state_request(request),.state_write(write),
 .state_index(index),.state_data(state_data),.state_frozen(frozen[0]),
 .state_done(done[0]),.state_error(error[0]),.state_result(result_mb),
 .sys_clk(ref_clk),
 .p2(we_mb_n),.p3(select_mb[3]),.p4(select_mb[2]),
 .p5(select_mb[1]),.p6(select_mb[0]),
 .p7(address[7]),.p8(address[6]),.p9(address[5]),.p10(address[4]),
 .p11(address[3]),.p12(address[2]),.p13(address[1]),.p14(address[0]),
 .p15(1'b0),.p16(data[3]),.p17(data[2]),.p18(data[1]),.p19(data[0]),
 .p20(q_mb[3]),.p21(q_mb[2]),.p22(q_mb[1]),.p23(q_mb[0]));
 cell_MB7071H original_mb(.sys_clk(ref_clk),
 .p2(we_mb_n),.p3(select_mb[3]),.p4(select_mb[2]),
 .p5(select_mb[1]),.p6(select_mb[0]),
 .p7(address[7]),.p8(address[6]),.p9(address[5]),.p10(address[4]),
 .p11(address[3]),.p12(address[2]),.p13(address[1]),.p14(address[0]),
 .p15(1'b0),.p16(data[3]),.p17(data[2]),.p18(data[1]),.p19(data[0]),
 .p20(ref_q_mb[3]),.p21(ref_q_mb[2]),.p22(ref_q_mb[1]),.p23(ref_q_mb[0]));
 cell_F10414_snapshot candidate_f(
 .state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),
 .state_guest_held(held),.state_request(request),.state_write(write),
 .state_index(index),.state_data(state_data_f),.state_frozen(frozen[1]),
 .state_done(done[1]),.state_error(error[1]),.state_result(result_f),
 .sys_clk(ref_clk),
 .p1(address[7]),.p2(address[6]),.p3(address[5]),.p4(address[4]),
 .p7(ce_f),.p9(address[3]),.p10(address[2]),.p11(address[1]),.p12(address[0]),
 .p13(data[0]),.p14(we_f_n),.p15(q_f));
 cell_F10414 original_f(.sys_clk(ref_clk),
 .p1(address[7]),.p2(address[6]),.p3(address[5]),.p4(address[4]),
 .p7(ce_f),.p9(address[3]),.p10(address[2]),.p11(address[1]),.p12(address[0]),
 .p13(data[0]),.p14(we_f_n),.p15(ref_q_f));
 genvar i;
 generate for(i=0;i<256;i=i+1)begin:observe
  assign memory_mb[i*4+:4]=candidate_mb.mem[i];
  assign ref_memory_mb[i*4+:4]=original_mb.mem[i];
  assign memory_f[i]=candidate_f.mem[i];
  assign ref_memory_f[i]=original_f.mem[i];
 end endgenerate
endmodule
