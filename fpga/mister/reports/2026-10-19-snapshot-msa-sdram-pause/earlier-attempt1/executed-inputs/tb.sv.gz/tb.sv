`timescale 1ns/1ps
module tb;
    // Generated fixture declarations and physical-field mask follow here.
    logic drain_mode,arbiter_idle,raw_service_idle;
    logic clk,ref_clk,advance,freeze,held,global_hold,global_abort,system_reset,request,write,reset;
    logic [23:0] state_index,input wire [17:0] state_data,input wire [46:0] stimulus;
    logic [15:0] req_ready,rsp_valid,input wire [15:0] rsp_data[16];
    logic [15:0] req_valid,req_write,rsp_ready,ref_req_valid,ref_req_write,ref_rsp_ready;
    logic [15:0] req_addr[16],req_data[16],ref_req_addr[16],ref_req_data[16];
    logic storage_ready,ref_storage_ready,ready,frozen,done,error,hold_required,fault,drained;
    logic [15:0] helper_frozen,output wire busy,scan_step;
    logic pause_ready,pause_frontend_hold,pause_guest_hold,pause_fault;
    logic [17:0] result,output wire [18:0] dut_outputs,reference_outputs;
    logic [1537:0] dut_state,reference_state;
    localparam integer STATE_BITS=1538,SCAN_WORDS=86;
    localparam [1537:0] FF_MASK=1538'h3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff;
    localparam integer canonical_bit[1538]='{7,8,9,10,1,2,3,4,11,12,6,5,0,80,81,82,83,74,75,76,77,84,85,79,78,73,847,848,849,850,841,842,843,844,851,852,846,845,840,860,861,862,863,854,855,856,857,864,865,859,858,853,93,94,95,96,97,98,87,88,89,90,91,92,86,138,139,140,141,142,143,132,133,134,135,136,137,131,151,152,153,154,155,156,145,146,147,148,149,150,144,196,197,198,199,200,201,190,191,192,193,194,195,189,529,530,531,532,533,534,523,524,525,526,527,528,522,560,561,562,563,564,565,554,555,556,557,558,559,553,591,592,593,594,595,596,585,586,587,588,589,590,584,658,659,660,661,662,663,652,653,654,655,656,657,651,735,736,737,738,739,740,729,730,731,732,733,734,728,808,809,810,811,812,813,802,803,804,805,806,807,801,821,822,823,824,825,826,815,816,817,818,819,820,814,834,835,836,837,838,839,828,829,830,831,832,833,827,598,599,600,601,602,603,604,605,606,607,597,641,642,643,644,645,646,647,648,649,650,640,35,36,37,38,39,40,41,42,34,44,45,46,47,48,49,50,51,43,107,108,109,110,111,112,113,114,106,116,117,118,119,120,121,122,123,115,165,166,167,168,169,170,171,172,164,174,175,176,177,178,179,180,181,173,210,211,212,213,214,215,216,217,209,219,220,221,222,223,224,225,226,218,536,537,538,539,540,541,542,543,535,545,546,547,548,549,550,551,552,544,567,568,569,570,571,572,573,574,566,576,577,578,579,580,581,582,583,575,616,617,618,619,620,621,622,623,615,625,626,627,628,629,630,631,632,624,672,673,674,675,676,677,678,679,671,681,682,683,684,685,686,687,688,680,704,705,706,707,708,709,710,711,703,713,714,715,716,717,718,719,720,712,763,764,765,766,767,768,769,770,762,772,773,774,775,776,777,778,779,771,14,15,16,17,18,19,13,21,22,23,24,25,26,20,28,29,30,31,32,33,27,53,54,55,56,57,58,52,60,61,62,63,64,65,59,67,68,69,70,71,72,66,100,101,102,103,104,105,99,125,126,127,128,129,130,124,158,159,160,161,162,163,157,183,184,185,186,187,188,182,203,204,205,206,207,208,202,228,229,230,231,232,233,227,609,610,611,612,613,614,608,634,635,636,637,638,639,633,665,666,667,668,669,670,664,690,691,692,693,694,695,689,697,698,699,700,701,702,696,722,723,724,725,726,727,721,742,743,744,745,746,747,741,749,750,751,752,753,754,748,756,757,758,759,760,761,755,781,782,783,784,785,786,780,788,789,790,791,792,793,787,795,796,797,798,799,800,794,244,245,246,247,248,249,250,251,235,236,237,238,239,240,241,242,243,234,262,263,264,265,266,267,268,269,253,254,255,256,257,258,259,260,261,252,280,281,282,283,284,285,286,287,271,272,273,274,275,276,277,278,279,270,298,299,300,301,302,303,304,305,289,290,291,292,293,294,295,296,297,288,316,317,318,319,320,321,322,323,307,308,309,310,311,312,313,314,315,306,334,335,336,337,338,339,340,341,325,326,327,328,329,330,331,332,333,324,352,353,354,355,356,357,358,359,343,344,345,346,347,348,349,350,351,342,370,371,372,373,374,375,376,377,361,362,363,364,365,366,367,368,369,360,388,389,390,391,392,393,394,395,379,380,381,382,383,384,385,386,387,378,406,407,408,409,410,411,412,413,397,398,399,400,401,402,403,404,405,396,424,425,426,427,428,429,430,431,415,416,417,418,419,420,421,422,423,414,442,443,444,445,446,447,448,449,433,434,435,436,437,438,439,440,441,432,460,461,462,463,464,465,466,467,451,452,453,454,455,456,457,458,459,450,478,479,480,481,482,483,484,485,469,470,471,472,473,474,475,476,477,468,496,497,498,499,500,501,502,503,487,488,489,490,491,492,493,494,495,486,514,515,516,517,518,519,520,521,505,506,507,508,509,510,511,512,513,504,879,905,919,906,907,908,909,910,911,912,913,914,915,916,917,892,893,894,895,896,897,898,899,900,901,902,903,880,881,882,883,884,885,886,887,888,889,890,891,878,918,904,866,867,868,869,870,871,872,873,874,875,876,877,933,959,973,960,961,962,963,964,965,966,967,968,969,970,971,946,947,948,949,950,951,952,953,954,955,956,957,934,935,936,937,938,939,940,941,942,943,944,945,932,972,958,920,921,922,923,924,925,926,927,928,929,930,931,1243,1261,1271,1262,1263,1264,1265,1266,1267,1268,1269,1252,1253,1254,1255,1256,1257,1258,1259,1244,1245,1246,1247,1248,1249,1250,1251,1242,1270,1260,1234,1235,1236,1237,1238,1239,1240,1241,1281,1299,1309,1300,1301,1302,1303,1304,1305,1306,1307,1290,1291,1292,1293,1294,1295,1296,1297,1282,1283,1284,1285,1286,1287,1288,1289,1280,1308,1298,1272,1273,1274,1275,1276,1277,1278,1279,1319,1337,1347,1338,1339,1340,1341,1342,1343,1344,1345,1328,1329,1330,1331,1332,1333,1334,1335,1320,1321,1322,1323,1324,1325,1326,1327,1318,1346,1336,1310,1311,1312,1313,1314,1315,1316,1317,1357,1375,1385,1376,1377,1378,1379,1380,1381,1382,1383,1366,1367,1368,1369,1370,1371,1372,1373,1358,1359,1360,1361,1362,1363,1364,1365,1356,1384,1374,1348,1349,1350,1351,1352,1353,1354,1355,1395,1413,1423,1414,1415,1416,1417,1418,1419,1420,1421,1404,1405,1406,1407,1408,1409,1410,1411,1396,1397,1398,1399,1400,1401,1402,1403,1394,1422,1412,1386,1387,1388,1389,1390,1391,1392,1393,1433,1451,1461,1452,1453,1454,1455,1456,1457,1458,1459,1442,1443,1444,1445,1446,1447,1448,1449,1434,1435,1436,1437,1438,1439,1440,1441,1432,1460,1450,1424,1425,1426,1427,1428,1429,1430,1431,1471,1489,1499,1490,1491,1492,1493,1494,1495,1496,1497,1480,1481,1482,1483,1484,1485,1486,1487,1472,1473,1474,1475,1476,1477,1478,1479,1470,1498,1488,1462,1463,1464,1465,1466,1467,1468,1469,1509,1527,1537,1528,1529,1530,1531,1532,1533,1534,1535,1518,1519,1520,1521,1522,1523,1524,1525,1510,1511,1512,1513,1514,1515,1516,1517,1508,1536,1526,1500,1501,1502,1503,1504,1505,1506,1507,983,1001,1011,1002,1003,1004,1005,1006,1007,1008,1009,992,993,994,995,996,997,998,999,984,985,986,987,988,989,990,991,982,1010,1000,974,975,976,977,978,979,980,981,1021,1039,1049,1040,1041,1042,1043,1044,1045,1046,1047,1030,1031,1032,1033,1034,1035,1036,1037,1022,1023,1024,1025,1026,1027,1028,1029,1020,1048,1038,1012,1013,1014,1015,1016,1017,1018,1019,1059,1077,1087,1078,1079,1080,1081,1082,1083,1084,1085,1068,1069,1070,1071,1072,1073,1074,1075,1060,1061,1062,1063,1064,1065,1066,1067,1058,1086,1076,1050,1051,1052,1053,1054,1055,1056,1057,1097,1115,1125,1116,1117,1118,1119,1120,1121,1122,1123,1106,1107,1108,1109,1110,1111,1112,1113,1098,1099,1100,1101,1102,1103,1104,1105,1096,1124,1114,1088,1089,1090,1091,1092,1093,1094,1095,1139,1165,1179,1166,1167,1168,1169,1170,1171,1172,1173,1174,1175,1176,1177,1152,1153,1154,1155,1156,1157,1158,1159,1160,1161,1162,1163,1140,1141,1142,1143,1144,1145,1146,1147,1148,1149,1150,1151,1138,1178,1164,1126,1127,1128,1129,1130,1131,1132,1133,1134,1135,1136,1137,1193,1219,1233,1220,1221,1222,1223,1224,1225,1226,1227,1228,1229,1230,1231,1206,1207,1208,1209,1210,1211,1212,1213,1214,1215,1216,1217,1194,1195,1196,1197,1198,1199,1200,1201,1202,1203,1204,1205,1192,1232,1218,1180,1181,1182,1183,1184,1185,1186,1187,1188,1189,1190,1191};
    initial clk=0;
    always #10 clk=~clk;
    assign ref_clk=clk;
    msa_board_fixture dut(.*);
    wire [255:0] address_bus,data_bus,response_bus;
    wire rv,rr,rw,sv,sr;
    wire [22:0] ra;
    wire [15:0] wd,sd;
    for(genvar g=0;g<16;g=g+1)begin
        assign address_bus[g*16+:16]=req_addr[g];
        assign data_bus[g*16+:16]=req_data[g];
        assign rsp_data[g]=response_bus[g*16+:16];
    end
    dorado_storage_arb #(.GROUPS(16),.GROUP_ADDR_BITS(16),.RAW_ADDR_BITS(23),
        .PREFETCH_NEXT(1),.INTERLEAVE_GROUPS(1)) arbiter(
        .clk(clk),.reset(reset),.snapshot_idle(arbiter_idle),
        .req_valid(req_valid),.req_write(req_write),.req_ready(req_ready),
        .req_addr(address_bus),.req_data(data_bus),.rsp_valid(rsp_valid),
        .rsp_ready(rsp_ready),.rsp_data(response_bus),
        .raw_req_valid(rv),.raw_req_write(rw),.raw_req_ready(rr),
        .raw_req_addr(ra),.raw_req_data(wd),.raw_rsp_valid(sv),
        .raw_rsp_ready(sr),.raw_rsp_data(sd));
    wire initialized,cache_hit,physical_read,physical_write,read_return;
    wire [12:0] sdram_a;
    wire [1:0] sdram_ba;
    wire ncs,nras,ncas,nwe,dqml,dqmh,cke,dq_oe;
    wire [15:0] dq_out,dq;
    assign dq=dq_oe?dq_out:16'hzzzz;
    dorado_storage_sdram #(.ADDR_BITS(23),.CLOCK_HZ(50000000)) memory(
        .clk(clk),.reset(reset),.snapshot_idle(raw_service_idle),
        .req_valid(rv),.req_ready(rr),.req_write(rw),.req_addr(ra),.req_data(wd),
        .rsp_valid(sv),.rsp_ready(sr),.rsp_data(sd),.initialized(initialized),
        .cache_hit(cache_hit),.physical_read(physical_read),.physical_write(physical_write),
        .read_return(read_return),.sdram_a(sdram_a),.sdram_ba(sdram_ba),
        .sdram_ncs(ncs),.sdram_nras(nras),.sdram_ncas(ncas),.sdram_nwe(nwe),
        .sdram_dqml(dqml),.sdram_dqmh(dqmh),.sdram_cke(cke),
        .dq_out(dq_out),.dq_oe(dq_oe),.dq_in(dq));
    as4c32m16sb_6tin_chip_model #(.CHIP_NAME("PAUSE_RANK0"),
        .tRC_MIN(63.0),.tRFC_MIN(63.0),.tRCD_MIN(21.0),.tRP_MIN(21.0),
        .tRRD_MIN(14.0),.tMRD_MIN(14.0),.tWR_MIN(14.0),.tAC_MAX(6.0)) chip0(
        .Clk(~clk),.Cke(cke),.Cs_n(ncs),.Ras_n(nras),.Cas_n(ncas),.We_n(nwe),
        .Ba(sdram_ba),.Addr(sdram_a),.Ldqm(dqml),.Udqm(dqmh),.Dq(dq));
    as4c32m16sb_6tin_chip_model #(.CHIP_NAME("PAUSE_RANK1"),
        .tRC_MIN(63.0),.tRFC_MIN(63.0),.tRCD_MIN(21.0),.tRP_MIN(21.0),
        .tRRD_MIN(14.0),.tMRD_MIN(14.0),.tWR_MIN(14.0),.tAC_MAX(6.0)) chip1(
        .Clk(~clk),.Cke(cke),.Cs_n(~ncs),.Ras_n(nras),.Cas_n(ncas),.We_n(nwe),
        .Ba(sdram_ba),.Addr(sdram_a),.Ldqm(dqml),.Udqm(dqmh),.Dq(dq));
    integer checks=0,host_edges=0,guest_edges=0,raw_reads=0,raw_writes=0;
    integer refreshes=0,pauses=0,pending_reads=0,pending_writes=0;
    bit raw_pending=0,pending_write=0;
    reg [31:0] rng=32'h5bd4af31;
    always @(posedge clk)begin
        host_edges++;
        if(advance)guest_edges++;
        if(reset)raw_pending=0;
        else begin
            if(rv&&rr)begin
                raw_pending=1;pending_write=rw;
                if(rw)raw_writes++;else raw_reads++;
            end
            if(sv&&sr)raw_pending=0;
        end
    end
    always @(negedge clk)if({nras,ncas,nwe}==3'b001)refreshes++;
    task check(input bit ok,input string message);
        checks++;if(!ok)$fatal(1,"%s host=%0d",message,host_edges);
    endtask
    task compare;
        check(dut_state===reference_state,"ordinary physical MSA state differs");
        check(dut_outputs===reference_outputs,"ordinary MSA pins differ");
        check(req_valid===ref_req_valid&&req_write===ref_req_write&&
              rsp_ready===ref_rsp_ready,"ordinary MSA raw controls differ");
        check(req_addr===ref_req_addr&&req_data===ref_req_data,"ordinary MSA raw payload differs");
    endtask
    task tick(input bit guest,input bit ordinary);
        @(negedge clk);advance=guest;
        check(!guest||(!pause_guest_hold&&storage_ready&&ref_storage_ready),"advanced held/stalled guest");
        @(posedge clk);#1;advance=0;
        if(ordinary)compare();
    endtask
    task settle;
        integer age;
        age=0;
        while(!storage_ready||!ref_storage_ready)begin
            tick(0,1);age++;check(age<20000,"normal raw service timeout");
        end
    endtask
    task step;
        @(negedge clk);
        for(integer b=0;b<$bits(stimulus);b++)begin
            rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);stimulus[b]=rng[0];
        end
        settle();tick(1,1);
    endtask
    function automatic [17:0] saved_word(input [1537:0] saved,input integer index);
        reg [17:0] value;
        value=0;
        for(integer b=0;b<18&&index*18+b<STATE_BITS;b++)value[b]=saved[canonical_bit[index*18+b]];
        return value;
    endfunction
    task pause_with_pending(input bit writing);
        integer search,age,held_guest,refresh_before;
        reg [1537:0] before_ff,saved;
        bit found;
        found=0;
        for(search=0;search<4000&&!found;search++)begin
            step();age=0;
            while(age<1000&&!found)begin
                tick(0,1);age++;
                found=raw_pending&&pending_write==writing;
                if(storage_ready&&ref_storage_ready)break;
            end
        end
        check(found,"pending read/write pause coverage missing");
        if(writing)pending_writes++;else pending_reads++;
        before_ff=dut_state;held_guest=guest_edges;
        @(negedge clk);global_hold=1;freeze=1;held=1;
        age=0;
        while(!pause_ready)begin
            tick(0,0);age++;
            check((dut_state&FF_MASK)===(before_ff&FF_MASK),"FF moved while real raw service drained");
            if(!pause_frontend_hold)compare();
            check(!pause_frontend_hold||(!raw_pending&&arbiter_idle&&raw_service_idle),"froze real raw work early");
            check(age<10000,"actual raw response deadlocked behind hold");
        end
        check(guest_edges==held_guest&&!raw_pending&&!pause_fault,"invalid real frozen boundary");
        saved=dut_state;refresh_before=refreshes;
        for(integer i=0;i<SCAN_WORDS;i++)begin
            check(ready,"scan not ready");
            @(negedge clk);state_index=24'(i);write=0;request=1;
            tick(0,0);request=0;age=0;
            while(!done)begin
                check(pause_frontend_hold&&pause_ready,"rotation lost real raw service hold");
                tick(0,0);age++;check(age<1600,"real raw-service scan timeout");
            end
            check(!error&&result===saved_word(saved,i),"real raw-service snapshot word differs");
            check(dut_state===saved,"real raw-service rotation changed state");
        end
        check(refreshes>refresh_before+20,"physical SDRAM refresh stopped while held");
        @(negedge clk);global_hold=0;freeze=0;held=0;
        check(pause_guest_hold,"guest hold released before frontend thaw");
        tick(0,0);check(!pause_guest_hold&&!pause_frontend_hold&&!pause_fault,"real pause failed to thaw");
        compare();for(integer n=0;n<100;n++)step();settle();pauses++;
    endtask
    initial begin
        advance=0;freeze=0;held=0;global_hold=0;global_abort=0;system_reset=0;
        request=0;write=0;reset=1;drain_mode=1;state_index=0;state_data=0;stimulus=0;
        repeat(3)tick(0,0);reset=0;settle();
        for(integer n=0;n<2000;n++)step();settle();
        for(integer p=0;p<4;p++)pause_with_pending(p[0]);
        for(integer n=0;n<2000;n++)step();settle();
        check(chip0.error_count==0&&chip1.error_count==0&&
              chip0.warning_count==0&&chip1.warning_count==0,"SDRAM pin-model errors/warnings");
        check(raw_reads>0&&raw_writes>0&&pending_reads>0&&pending_writes>0,"missing actual raw traffic");
        $display("MSA SDRAM PAUSE PASS checks=%0d host=%0d guest=%0d reads=%0d writes=%0d pauses=%0d pending_reads=%0d pending_writes=%0d refreshes=%0d",checks,host_edges,guest_edges,raw_reads,raw_writes,pauses,pending_reads,pending_writes,refreshes);
        $finish;
    end
    initial begin #100000000;$fatal(1,"combined memory pause test deadline");end
endmodule
