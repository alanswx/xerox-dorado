module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [93:0] stimulus,
 input wire freeze,held,request,write,input wire [18:0] index,
 input wire [17:0] state_data,output reg [58:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both DispY neighbors sample on positive host edges; full20ns budgets.
 reg [136:0] launch;
 reg [136:0] input_stage;
 always @(negedge host_clk)
  input_stage<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 always @(posedge host_clk) launch<=input_stage;
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [93:0] stimulus_r;wire [18:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [58:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_video_field;
wire bank_n_24Bit__drv;
wire bank_A8B2__drv;
wire bank_AItem_0__drv;
wire bank_AItem_1__drv;
wire bank_AItem_2__drv;
wire bank_AItem_3__drv;
wire bank_AItem_4__drv;
wire bank_AItem_5__drv;
wire bank_AItem_6__drv;
wire bank_AItem_7__drv;
wire bank_AItemClkEn_p_b__drv;
wire bank_AOff__drv;
wire bank_AltoCSync_p___drv;
wire bank_AltoHSync__drv;
wire bank_AltoTTLVideo__drv;
wire bank_AltoVSync_p___drv;
wire bank_BByPass__drv;
wire bank_BItem_0__drv;
wire bank_BItem_1__drv;
wire bank_BItem_2__drv;
wire bank_BItem_3__drv;
wire bank_BItem_4__drv;
wire bank_BItem_5__drv;
wire bank_BItem_6__drv;
wire bank_BItem_7__drv;
wire bank_BItemClkEn_p_b__drv;
wire bank_BOff__drv;
wire bank_Crystal__drv;
wire bank_CursorData__drv;
wire bank_DMuxData__drv;
wire bank_GNDFour__drv;
wire bank_HBlank__drv;
wire bank_HSync__drv;
wire bank_HalfLine__drv;
wire bank_IOB_00__drv;
wire bank_IOB_15__drv;
wire bank_IOB_16__drv;
wire bank_IOB_17__drv;
wire bank_IOut_m___drv;
wire bank_JamVBlank__drv;
wire bank_OISClkA__drv;
wire bank_OISClkA_p___drv;
wire bank_OISClkB__drv;
wire bank_OISClkB_p___drv;
wire bank_OISData_0__drv;
wire bank_OISData_0_p___drv;
wire bank_OISData_1__drv;
wire bank_OISData_1_p___drv;
wire bank_OISData_2__drv;
wire bank_OISData_2_p___drv;
wire bank_OISData_3__drv;
wire bank_OISData_3_p___drv;
wire bank_SubTask_0__drv;
wire bank_TWReq_03__drv;
wire bank_TWReq_11__drv;
wire bank_VBlank__drv;
wire bank_VSync__drv;
wire bank_XSyncEn_p___drv;
assign bank_q={bank_XSyncEn_p___drv,bank_VSync__drv,bank_VBlank__drv,bank_TWReq_11__drv,bank_TWReq_03__drv,bank_SubTask_0__drv,bank_OISData_3_p___drv,bank_OISData_3__drv,bank_OISData_2_p___drv,bank_OISData_2__drv,bank_OISData_1_p___drv,bank_OISData_1__drv,bank_OISData_0_p___drv,bank_OISData_0__drv,bank_OISClkB_p___drv,bank_OISClkB__drv,bank_OISClkA_p___drv,bank_OISClkA__drv,bank_JamVBlank__drv,bank_IOut_m___drv,bank_IOB_17__drv,bank_IOB_16__drv,bank_IOB_15__drv,bank_IOB_00__drv,bank_HalfLine__drv,bank_HSync__drv,bank_HBlank__drv,bank_GNDFour__drv,bank_DMuxData__drv,bank_CursorData__drv,bank_Crystal__drv,bank_BOff__drv,bank_BItemClkEn_p_b__drv,bank_BItem_7__drv,bank_BItem_6__drv,bank_BItem_5__drv,bank_BItem_4__drv,bank_BItem_3__drv,bank_BItem_2__drv,bank_BItem_1__drv,bank_BItem_0__drv,bank_BByPass__drv,bank_AltoVSync_p___drv,bank_AltoTTLVideo__drv,bank_AltoHSync__drv,bank_AltoCSync_p___drv,bank_AOff__drv,bank_AItemClkEn_p_b__drv,bank_AItem_7__drv,bank_AItem_6__drv,bank_AItem_5__drv,bank_AItem_4__drv,bank_AItem_3__drv,bank_AItem_2__drv,bank_AItem_1__drv,bank_AItem_0__drv,bank_A8B2__drv,bank_n_24Bit__drv,bank_video_field};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 DispY_full_snapshot_experiment  bank(
 .state_system_reset(system_reset_r),.state_scan_hold_required(bank_scan_hold),.state_scan_fault(bank_scan_fault),
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 DispY_m_Rev_m_Cl_field  bank(
`endif
.sys_clk(host_clk),
.AItem_0(stimulus_r[0] | bank_AItem_0__drv),
.AItem_1(stimulus_r[1] | bank_AItem_1__drv),
.AItem_2(stimulus_r[2] | bank_AItem_2__drv),
.AItem_3(stimulus_r[3] | bank_AItem_3__drv),
.AItem_4(stimulus_r[4] | bank_AItem_4__drv),
.AItem_5(stimulus_r[5] | bank_AItem_5__drv),
.AItem_6(stimulus_r[6] | bank_AItem_6__drv),
.AItem_7(stimulus_r[7] | bank_AItem_7__drv),
.AOff(stimulus_r[8] | bank_AOff__drv),
.BItem_0(stimulus_r[9] | bank_BItem_0__drv),
.BItem_1(stimulus_r[10] | bank_BItem_1__drv),
.BItem_2(stimulus_r[11] | bank_BItem_2__drv),
.BItem_3(stimulus_r[12] | bank_BItem_3__drv),
.BItem_4(stimulus_r[13] | bank_BItem_4__drv),
.BItem_5(stimulus_r[14] | bank_BItem_5__drv),
.BItem_6(stimulus_r[15] | bank_BItem_6__drv),
.BItem_7(stimulus_r[16] | bank_BItem_7__drv),
.BNTGtCT_p_b(stimulus_r[17]),
.BOff(stimulus_r[18] | bank_BOff__drv),
.Block(stimulus_r[19]),
.CLK_display_p_(stimulus_r[20]),
.CLKEnable_p_b(stimulus_r[21]),
.CursorData(stimulus_r[22] | bank_CursorData__drv),
.DMuxClk(stimulus_r[23]),
.DMuxData(stimulus_r[24] | bank_DMuxData__drv),
.Fout_00(stimulus_r[25]),
.Fout_01(stimulus_r[26]),
.Fout_02(stimulus_r[27]),
.Fout_03(stimulus_r[28]),
.Fout_04(stimulus_r[29]),
.Fout_05(stimulus_r[30]),
.Fout_06(stimulus_r[31]),
.Fout_07(stimulus_r[32]),
.Fout_08(stimulus_r[33]),
.Fout_09(stimulus_r[34]),
.Fout_10(stimulus_r[35]),
.Fout_11(stimulus_r[36]),
.Fout_12(stimulus_r[37]),
.Fout_13(stimulus_r[38]),
.Fout_14(stimulus_r[39]),
.Fout_15(stimulus_r[40]),
.FoutNext(stimulus_r[41]),
.FoutSubTask_0(stimulus_r[42]),
.FoutTask_0(stimulus_r[43]),
.FoutTask_1(stimulus_r[44]),
.FoutTask_2(stimulus_r[45]),
.FoutTask_3(stimulus_r[46]),
.GNDFour(stimulus_r[47] | bank_GNDFour__drv),
.HBlank(stimulus_r[48] | bank_HBlank__drv),
.HSync(stimulus_r[49] | bank_HSync__drv),
.HalfLine(stimulus_r[50] | bank_HalfLine__drv),
.IOB_00(stimulus_r[51] | bank_IOB_00__drv),
.IOB_01(stimulus_r[52]),
.IOB_02(stimulus_r[53]),
.IOB_03(stimulus_r[54]),
.IOB_04(stimulus_r[55]),
.IOB_05(stimulus_r[56]),
.IOB_06(stimulus_r[57]),
.IOB_07(stimulus_r[58]),
.IOB_08(stimulus_r[59]),
.IOB_09(stimulus_r[60]),
.IOB_10(stimulus_r[61]),
.IOB_11(stimulus_r[62]),
.IOB_12(stimulus_r[63]),
.IOB_13(stimulus_r[64]),
.IOB_14(stimulus_r[65]),
.IOB_15(stimulus_r[66] | bank_IOB_15__drv),
.IOHold(stimulus_r[67]),
.IOReset(stimulus_r[68]),
.IOin_p_(stimulus_r[69]),
.IOout_p_(stimulus_r[70]),
.KeyboardData(stimulus_r[71]),
.MemClkEnable_p_a(stimulus_r[72]),
.MemSH_p_(stimulus_r[73]),
.Next_0(stimulus_r[74]),
.Next_1(stimulus_r[75]),
.Next_2(stimulus_r[76]),
.Next_3(stimulus_r[77]),
.PixelClkVCO(stimulus_r[78]),
.RawPixelClk(stimulus_r[79]),
.TIOA_0(stimulus_r[80]),
.TIOA_1(stimulus_r[81]),
.TIOA_2(stimulus_r[82]),
.TIOA_3(stimulus_r[83]),
.TIOA_4(stimulus_r[84]),
.TIOA_5(stimulus_r[85]),
.TIOA_6(stimulus_r[86]),
.TIOA_7(stimulus_r[87]),
.TWReq_03(stimulus_r[88] | bank_TWReq_03__drv),
.TermIsLF(stimulus_r[89]),
.VBlank(stimulus_r[90] | bank_VBlank__drv),
.VSync(stimulus_r[91] | bank_VSync__drv),
.XHsync(stimulus_r[92]),
.XSyncEn_p_(stimulus_r[93] | bank_XSyncEn_p___drv),
.video_field(bank_video_field),
.n_24Bit__drv(bank_n_24Bit__drv),
.A8B2__drv(bank_A8B2__drv),
.AItem_0__drv(bank_AItem_0__drv),
.AItem_1__drv(bank_AItem_1__drv),
.AItem_2__drv(bank_AItem_2__drv),
.AItem_3__drv(bank_AItem_3__drv),
.AItem_4__drv(bank_AItem_4__drv),
.AItem_5__drv(bank_AItem_5__drv),
.AItem_6__drv(bank_AItem_6__drv),
.AItem_7__drv(bank_AItem_7__drv),
.AItemClkEn_p_b__drv(bank_AItemClkEn_p_b__drv),
.AOff__drv(bank_AOff__drv),
.AltoCSync_p___drv(bank_AltoCSync_p___drv),
.AltoHSync__drv(bank_AltoHSync__drv),
.AltoTTLVideo__drv(bank_AltoTTLVideo__drv),
.AltoVSync_p___drv(bank_AltoVSync_p___drv),
.BByPass__drv(bank_BByPass__drv),
.BItem_0__drv(bank_BItem_0__drv),
.BItem_1__drv(bank_BItem_1__drv),
.BItem_2__drv(bank_BItem_2__drv),
.BItem_3__drv(bank_BItem_3__drv),
.BItem_4__drv(bank_BItem_4__drv),
.BItem_5__drv(bank_BItem_5__drv),
.BItem_6__drv(bank_BItem_6__drv),
.BItem_7__drv(bank_BItem_7__drv),
.BItemClkEn_p_b__drv(bank_BItemClkEn_p_b__drv),
.BOff__drv(bank_BOff__drv),
.Crystal__drv(bank_Crystal__drv),
.CursorData__drv(bank_CursorData__drv),
.DMuxData__drv(bank_DMuxData__drv),
.GNDFour__drv(bank_GNDFour__drv),
.HBlank__drv(bank_HBlank__drv),
.HSync__drv(bank_HSync__drv),
.HalfLine__drv(bank_HalfLine__drv),
.IOB_00__drv(bank_IOB_00__drv),
.IOB_15__drv(bank_IOB_15__drv),
.IOB_16__drv(bank_IOB_16__drv),
.IOB_17__drv(bank_IOB_17__drv),
.IOut_m___drv(bank_IOut_m___drv),
.JamVBlank__drv(bank_JamVBlank__drv),
.OISClkA__drv(bank_OISClkA__drv),
.OISClkA_p___drv(bank_OISClkA_p___drv),
.OISClkB__drv(bank_OISClkB__drv),
.OISClkB_p___drv(bank_OISClkB_p___drv),
.OISData_0__drv(bank_OISData_0__drv),
.OISData_0_p___drv(bank_OISData_0_p___drv),
.OISData_1__drv(bank_OISData_1__drv),
.OISData_1_p___drv(bank_OISData_1_p___drv),
.OISData_2__drv(bank_OISData_2__drv),
.OISData_2_p___drv(bank_OISData_2_p___drv),
.OISData_3__drv(bank_OISData_3__drv),
.OISData_3_p___drv(bank_OISData_3_p___drv),
.SubTask_0__drv(bank_SubTask_0__drv),
.TWReq_03__drv(bank_TWReq_03__drv),
.TWReq_11__drv(bank_TWReq_11__drv),
.VBlank__drv(bank_VBlank__drv),
.VSync__drv(bank_VSync__drv),
.XSyncEn_p___drv(bank_XSyncEn_p___drv)
);
endmodule
