module fourstate;
 reg clk=0,advance=0,hold=0,scan_step=0,serial_in=0,reset=0;
 reg [1:0] ras_n=3,cas_n=3,we_n=3,req_ready=0,rsp_valid=0;
 reg [15:0] addr[0:1],data[0:1],rsp_data[0:1];
 wire [127:0] physical_old[0:1],physical_new[0:1];
 wire [54:0] ports_old[0:1],ports_new[0:1];
 integer ticks=0,seed=32'h51a7face;reg [31:0] noise;
 wire [7:0] dout_old0;
 wire [15:0] req_addr_old0,req_data_old0;
 wire ready_old0,valid_old0,wr_old0,rsp_old0,frozen_old0,drained_old0,serial_old0;
 dorado_storage_group_reference #(.ADDR_BITS(16),.WIDTH(8)) old0(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step),.state_serial_in(serial_in),
 .state_serial_out(serial_old0),.state_frozen(frozen_old0),.state_drain_ready(drained_old0),
 .host_clk(clk),.machine_clk(clk),.reset(reset),.ras_n(ras_n[0]),.cas_n(cas_n[0]),.we_n(we_n[0]),
 .addr(addr[0]),.data_in(data[0][7:0]),.data_out(dout_old0),
 .ready(ready_old0),.req_valid(valid_old0),.req_write(wr_old0),.req_addr(req_addr_old0),.req_data(req_data_old0),
 .req_ready(req_ready[0]),.rsp_valid(rsp_valid[0]),.rsp_ready(rsp_old0),.rsp_data(rsp_data[0]));
 assign ports_old[0]={serial_old0,drained_old0,frozen_old0,rsp_old0,wr_old0,valid_old0,ready_old0,req_addr_old0,req_data_old0,{8{1'b0}},dout_old0};
 assign physical_old[0]={17'b0,{old0.old_data,old0.saved_data,old0.cache_data,old0.saved_addr,old0.cache_addr,old0.saved_write,old0.waiting,old0.write_done,old0.cache_valid,old0.data_out,old0.read_pipe,old0.write_data,old0.write_pending,old0.we_d,old0.cas_d}};
 wire [7:0] dout_new0;
 wire [15:0] req_addr_new0,req_data_new0;
 wire ready_new0,valid_new0,wr_new0,rsp_new0,frozen_new0,drained_new0,serial_new0;
 dorado_storage_group_snapshot #(.ADDR_BITS(16),.WIDTH(8)) new0(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step),.state_serial_in(serial_in),
 .state_serial_out(serial_new0),.state_frozen(frozen_new0),.state_drain_ready(drained_new0),
 .host_clk(clk),.machine_clk(clk),.reset(reset),.ras_n(ras_n[0]),.cas_n(cas_n[0]),.we_n(we_n[0]),
 .addr(addr[0]),.data_in(data[0][7:0]),.data_out(dout_new0),
 .ready(ready_new0),.req_valid(valid_new0),.req_write(wr_new0),.req_addr(req_addr_new0),.req_data(req_data_new0),
 .req_ready(req_ready[0]),.rsp_valid(rsp_valid[0]),.rsp_ready(rsp_new0),.rsp_data(rsp_data[0]));
 assign ports_new[0]={serial_new0,drained_new0,frozen_new0,rsp_new0,wr_new0,valid_new0,ready_new0,req_addr_new0,req_data_new0,{8{1'b0}},dout_new0};
 assign physical_new[0]={17'b0,{new0.old_data,new0.saved_data,new0.cache_data,new0.saved_addr,new0.cache_addr,new0.saved_write,new0.waiting,new0.write_done,new0.cache_valid,new0.data_out,new0.read_pipe,new0.write_data,new0.write_pending,new0.we_d,new0.cas_d}};
 wire [11:0] dout_old1;
 wire [15:0] req_addr_old1,req_data_old1;
 wire ready_old1,valid_old1,wr_old1,rsp_old1,frozen_old1,drained_old1,serial_old1;
 dorado_storage_group_reference #(.ADDR_BITS(16),.WIDTH(12)) old1(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step),.state_serial_in(serial_in),
 .state_serial_out(serial_old1),.state_frozen(frozen_old1),.state_drain_ready(drained_old1),
 .host_clk(clk),.machine_clk(clk),.reset(reset),.ras_n(ras_n[1]),.cas_n(cas_n[1]),.we_n(we_n[1]),
 .addr(addr[1]),.data_in(data[1][11:0]),.data_out(dout_old1),
 .ready(ready_old1),.req_valid(valid_old1),.req_write(wr_old1),.req_addr(req_addr_old1),.req_data(req_data_old1),
 .req_ready(req_ready[1]),.rsp_valid(rsp_valid[1]),.rsp_ready(rsp_old1),.rsp_data(rsp_data[1]));
 assign ports_old[1]={serial_old1,drained_old1,frozen_old1,rsp_old1,wr_old1,valid_old1,ready_old1,req_addr_old1,req_data_old1,{4{1'b0}},dout_old1};
 assign physical_old[1]={5'b0,{old1.old_data,old1.saved_data,old1.cache_data,old1.saved_addr,old1.cache_addr,old1.saved_write,old1.waiting,old1.write_done,old1.cache_valid,old1.data_out,old1.read_pipe,old1.write_data,old1.write_pending,old1.we_d,old1.cas_d}};
 wire [11:0] dout_new1;
 wire [15:0] req_addr_new1,req_data_new1;
 wire ready_new1,valid_new1,wr_new1,rsp_new1,frozen_new1,drained_new1,serial_new1;
 dorado_storage_group_snapshot #(.ADDR_BITS(16),.WIDTH(12)) new1(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step),.state_serial_in(serial_in),
 .state_serial_out(serial_new1),.state_frozen(frozen_new1),.state_drain_ready(drained_new1),
 .host_clk(clk),.machine_clk(clk),.reset(reset),.ras_n(ras_n[1]),.cas_n(cas_n[1]),.we_n(we_n[1]),
 .addr(addr[1]),.data_in(data[1][11:0]),.data_out(dout_new1),
 .ready(ready_new1),.req_valid(valid_new1),.req_write(wr_new1),.req_addr(req_addr_new1),.req_data(req_data_new1),
 .req_ready(req_ready[1]),.rsp_valid(rsp_valid[1]),.rsp_ready(rsp_new1),.rsp_data(rsp_data[1]));
 assign ports_new[1]={serial_new1,drained_new1,frozen_new1,rsp_new1,wr_new1,valid_new1,ready_new1,req_addr_new1,req_data_new1,{4{1'b0}},dout_new1};
 assign physical_new[1]={5'b0,{new1.old_data,new1.saved_data,new1.cache_data,new1.saved_addr,new1.cache_addr,new1.saved_write,new1.waiting,new1.write_done,new1.cache_valid,new1.data_out,new1.read_pipe,new1.write_data,new1.write_pending,new1.we_d,new1.cas_d}};
 task edge_and_check;
 begin
  #2;clk=1;#2;ticks=ticks+1;
  for(integer unit=0;unit<2;unit=unit+1)begin
   if(physical_old[unit]!==physical_new[unit])$fatal(1,"four-state physical mismatch tick=%0d unit=%0d",ticks,unit);
   if(ports_old[unit]!==ports_new[unit])$fatal(1,"four-state port mismatch tick=%0d unit=%0d",ticks,unit);
  end
  clk=0;#2;
 end endtask
 initial begin
  for(integer u=0;u<2;u=u+1)begin addr[u]=0;data[u]=16'h95a7;rsp_data[u]=16'hc3e1;end
  advance=1;edge_and_check;
  hold=1'bx;cas_n=0;edge_and_check;
  hold=1'bz;cas_n=3;edge_and_check;
  hold=1;scan_step=1;serial_in=1'bx;
  repeat(140)edge_and_check;
  for(integer n=0;n<12000;n=n+1)begin
   noise=$random(seed);{advance,hold,scan_step,serial_in,reset,ras_n,cas_n,we_n,req_ready,rsp_valid}=noise[14:0];
   for(integer u=0;u<2;u=u+1)begin addr[u]=$random(seed);data[u]=$random(seed);rsp_data[u]=$random(seed);end
   case(n%19)
    0:hold=1'bx;1:hold=1'bz;2:scan_step=1'bx;3:advance=1'bx;
    4:reset=1'bx;5:serial_in=1'bx;6:serial_in=1'bz;
    7:cas_n[0]=1'bx;8:we_n[1]=1'bz;9:req_ready[0]=1'bx;
    10:rsp_valid[1]=1'bx;11:rsp_data[0][7]=1'bz;12:addr[1][15]=1'bx;
   endcase
   edge_and_check;
  end
  $display("FOUR-STATE FACTORED PASS ticks=%0d physical=111/123",ticks);$finish;
 end
endmodule
