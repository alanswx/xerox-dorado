// The storage chips which share RAS/CAS/WE and row/column address are one
// vector here. Their original capture, write and output-register cycles
// are retained. Only their bit arrays move behind the raw storage port.
// host_clk keeps running while ready pauses the complete Dorado clock.
`default_nettype none
module dorado_storage_group_snapshot #(
    parameter integer ADDR_BITS=14,
    parameter integer WIDTH=16
) (
    input wire state_guest_advance,state_hold,state_scan_step,state_serial_in,
    output wire state_serial_out,state_drain_ready,
    output reg state_frozen=1'b0,
    input wire host_clk, machine_clk, reset,
    input wire ras_n, cas_n, we_n,
    input wire [ADDR_BITS-1:0] addr,
    input wire [WIDTH-1:0] data_in,
    output reg [WIDTH-1:0] data_out=0,
    output wire ready,
    output wire req_valid,
    input wire req_ready,
    output wire req_write,
    output wire [ADDR_BITS-1:0] req_addr,
    output wire [15:0] req_data,
    input wire rsp_valid,
    output wire rsp_ready,
    input wire [15:0] rsp_data
);
    reg cas_d=0,we_d=0,write_pending=0;
    reg [WIDTH-1:0] write_data=0,read_pipe=0;
    reg cache_valid=0,write_done=0,waiting=0,saved_write=0;
    reg [ADDR_BITS-1:0] cache_addr=0,saved_addr=0;
    reg [15:0] cache_data=0,saved_data=0,old_data=0;
    wire normal_ready,normal_req_valid;
    wire hit=cache_valid && cache_addr==addr;
    assign normal_ready=!reset && !waiting && hit && (!write_pending || write_done);
    assign normal_req_valid=!reset && !waiting && (!hit || (write_pending && !write_done));
    // Read a missing word first, including before a write. The read value
    // on the chip's write-commit edge is the OLD word (read-before-write).
    assign req_write=hit && write_pending && !write_done;
    assign req_addr=addr;
    assign req_data={{(16-WIDTH){1'b0}},write_data};
    assign rsp_ready=waiting && !state_hold;
    wire [15:0] read_value=(write_pending && write_done) ? old_data : cache_data;

    // These are cell_MK4096P_6's cycles, on the paused machine clock.
    localparam integer STATE_BITS=55+3*WIDTH+2*ADDR_BITS;
    wire [STATE_BITS-1:0] state_bits={old_data,saved_data,cache_data,saved_addr,cache_addr,saved_write,waiting,write_done,cache_valid,data_out,read_pipe,write_data,write_pending,we_d,cas_d};
    assign state_serial_out=state_bits[0];
    assign ready=normal_ready && !state_hold;
    assign req_valid=normal_req_valid && !state_hold;
    // Use only BEFORE final hold, not as a live acknowledgment during rotation.
    assign state_drain_ready=normal_ready && !normal_req_valid;
    always @(posedge host_clk) state_frozen<=state_hold;
    reg [14:0] update_enable;
    reg cas_d_next;
    reg we_d_next;
    reg write_pending_next;
    reg [WIDTH-1:0] write_data_next;
    reg [WIDTH-1:0] read_pipe_next;
    reg [WIDTH-1:0] data_out_next;
    reg cache_valid_next;
    reg write_done_next;
    reg waiting_next;
    reg saved_write_next;
    reg [ADDR_BITS-1:0] cache_addr_next;
    reg [ADDR_BITS-1:0] saved_addr_next;
    reg [16-1:0] cache_data_next;
    reg [16-1:0] saved_data_next;
    reg [16-1:0] old_data_next;
    always_comb begin
        update_enable=0;
        cas_d_next=0;
        we_d_next=0;
        write_pending_next=0;
        write_data_next=0;
        read_pipe_next=0;
        data_out_next=0;
        cache_valid_next=0;
        write_done_next=0;
        waiting_next=0;
        saved_write_next=0;
        cache_addr_next=0;
        saved_addr_next=0;
        cache_data_next=0;
        saved_data_next=0;
        old_data_next=0;
        if(state_hold)begin
            if(state_scan_step) begin {old_data_next,saved_data_next,cache_data_next,saved_addr_next,cache_addr_next,saved_write_next,waiting_next,write_done_next,cache_valid_next,data_out_next,read_pipe_next,write_data_next,write_pending_next,we_d_next,cas_d_next}={state_serial_in,state_bits[STATE_BITS-1:1]};update_enable=15'h7fff;end
        end else begin
            if(state_guest_advance) begin
        begin cas_d_next=cas_n;update_enable[0]=1'b1;end begin we_d_next=we_n;update_enable[1]=1'b1;end 
        begin write_pending_next=!ras_n && !cas_n && !we_n && (cas_d || we_d);update_enable[2]=1'b1;end 
        if(!ras_n && !cas_n && !we_n && (cas_d || we_d))begin write_data_next=data_in;update_enable[3]=1'b1;end 
        begin read_pipe_next=read_value[WIDTH-1:0];update_enable[4]=1'b1;end 
        if(!ras_n && !cas_n && we_n)begin data_out_next=read_pipe;update_enable[5]=1'b1;end 
    end

            begin
        if(reset) begin begin cache_valid_next=0;update_enable[6]=1'b1;end begin write_done_next=0;update_enable[7]=1'b1;end begin waiting_next=0;update_enable[8]=1'b1;end end
        else begin
            if(!write_pending)begin write_done_next=0;update_enable[7]=1'b1;end 
            if(req_valid && req_ready)begin
                begin waiting_next=1;update_enable[8]=1'b1;end begin saved_write_next=req_write;update_enable[9]=1'b1;end begin saved_addr_next=addr;update_enable[11]=1'b1;end 
                begin saved_data_next=req_data;update_enable[13]=1'b1;end 
                if(req_write)begin old_data_next=cache_data;update_enable[14]=1'b1;end 
            end
            if(waiting && rsp_valid)begin
                begin waiting_next=0;update_enable[8]=1'b1;end begin cache_valid_next=1;update_enable[6]=1'b1;end begin cache_addr_next=saved_addr;update_enable[10]=1'b1;end 
                if(saved_write)begin begin cache_data_next=saved_data;update_enable[12]=1'b1;end begin write_done_next=0;update_enable[7]=1'b1;end end
                else begin cache_data_next=rsp_data;update_enable[12]=1'b1;end 
            end
        end
    end

        end
    end
    always @(posedge host_clk)begin
        if(update_enable[0]) cas_d<=cas_d_next;
        if(update_enable[1]) we_d<=we_d_next;
        if(update_enable[2]) write_pending<=write_pending_next;
        if(update_enable[3]) write_data<=write_data_next;
        if(update_enable[4]) read_pipe<=read_pipe_next;
        if(update_enable[5]) data_out<=data_out_next;
        if(update_enable[6]) cache_valid<=cache_valid_next;
        if(update_enable[7]) write_done<=write_done_next;
        if(update_enable[8]) waiting<=waiting_next;
        if(update_enable[9]) saved_write<=saved_write_next;
        if(update_enable[10]) cache_addr<=cache_addr_next;
        if(update_enable[11]) saved_addr<=saved_addr_next;
        if(update_enable[12]) cache_data<=cache_data_next;
        if(update_enable[13]) saved_data<=saved_data_next;
        if(update_enable[14]) old_data<=old_data_next;
    end
    generate if(ADDR_BITS!=16 || (WIDTH!=8 && WIDTH!=12))begin:unqualified_native_geometry
        initial $fatal(1,"Storage snapshot requires native address16/width8-or-12");
    end endgenerate
endmodule
`default_nettype wire
