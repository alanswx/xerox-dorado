package require ::quartus::project
puts [lsort [info commands *assignment*]]
