module snapshot_fit(
 input wire host_clk,advance,hold,scan_step,serial_in,reset,
 input wire [1:0] ras_n,cas_n,we_n,req_ready,rsp_valid,
 input wire [31:0] addr,data,rsp_data,
 output reg [109:0] outputs);
 reg [110:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,hold,scan_step,serial_in,reset,ras_n,cas_n,we_n,req_ready,rsp_valid,addr,data,rsp_data};
 always @(posedge host_clk)launch<=input_stage;
 wire advance_r,hold_r,scan_r,serial_r,reset_r;
 wire [1:0] ras_r,cas_r,we_r,req_ready_r,rsp_valid_r;
 wire [31:0] addr_r,data_r,rsp_data_r;
 assign {advance_r,hold_r,scan_r,serial_r,reset_r,ras_r,cas_r,we_r,req_ready_r,rsp_valid_r,addr_r,data_r,rsp_data_r}=launch;
 wire [1:0] ready,req_valid,req_write,rsp_ready,frozen,drained,serial_out;
 wire [31:0] req_addr,req_data,data_out;
 dorado_storage_group_snapshot #(.ADDR_BITS(16),.WIDTH(8)) case0(
 .state_guest_advance(advance_r),.state_hold(hold_r),.state_scan_step(scan_r),.state_serial_in(serial_r),
 .state_serial_out(serial_out[0]),.state_frozen(frozen[0]),.state_drain_ready(drained[0]),
 .host_clk(host_clk),.machine_clk(host_clk),.reset(reset_r),.ras_n(ras_r[0]),.cas_n(cas_r[0]),.we_n(we_r[0]),
 .addr(addr_r[0+:16]),.data_in(data_r[0+:8]),.data_out(data_out[0+:8]),
 .ready(ready[0]),.req_valid(req_valid[0]),.req_write(req_write[0]),.req_addr(req_addr[0+:16]),
 .req_data(req_data[0+:16]),.req_ready(req_ready_r[0]),.rsp_valid(rsp_valid_r[0]),
 .rsp_ready(rsp_ready[0]),.rsp_data(rsp_data_r[0+:16]));
 assign data_out[8+:8]=0;
 dorado_storage_group_snapshot #(.ADDR_BITS(16),.WIDTH(12)) case1(
 .state_guest_advance(advance_r),.state_hold(hold_r),.state_scan_step(scan_r),.state_serial_in(serial_r),
 .state_serial_out(serial_out[1]),.state_frozen(frozen[1]),.state_drain_ready(drained[1]),
 .host_clk(host_clk),.machine_clk(host_clk),.reset(reset_r),.ras_n(ras_r[1]),.cas_n(cas_r[1]),.we_n(we_r[1]),
 .addr(addr_r[16+:16]),.data_in(data_r[16+:12]),.data_out(data_out[16+:12]),
 .ready(ready[1]),.req_valid(req_valid[1]),.req_write(req_write[1]),.req_addr(req_addr[16+:16]),
 .req_data(req_data[16+:16]),.req_ready(req_ready_r[1]),.rsp_valid(rsp_valid_r[1]),
 .rsp_ready(rsp_ready[1]),.rsp_data(rsp_data_r[16+:16]));
 assign data_out[28+:4]=0;
 always @(posedge host_clk)outputs<={ready,req_valid,req_write,rsp_ready,frozen,drained,serial_out,req_addr,req_data,data_out};
endmodule
