package require ::quartus::project
puts [get_assignment_info -long_help]
puts [get_assignment_name_info -long_help]
