package require ::quartus::project
get_assignment_info -long_help
get_assignment_name_info -long_help
