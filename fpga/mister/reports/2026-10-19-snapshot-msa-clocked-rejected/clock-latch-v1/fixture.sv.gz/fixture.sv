`timescale 1ns/1ps
module clock_fixture;
 reg clk=0,enable=0;wire gated_clk,gate_open;
 dorado_ff_clock_model dut(.clk(clk),.enable(enable),.gated_clk(gated_clk),.gate_open(gate_open));
 integer ff_edges=0,source_edges=0,changes=0,seed=32'hc10c7e57;
 reg expected_level;integer before_edges;
 always @(posedge gated_clk)ff_edges=ff_edges+1;
 initial begin
  #2;
  for(integer cycle=0;cycle<5000;cycle=cycle+1)begin
   enable=$random(seed)&1;#1;
   if(gated_clk!==1'b0)$fatal(1,"clock high during source low");
   expected_level=enable;before_edges=ff_edges;
   clk=1;source_edges=source_edges+1;#1;
   if(gated_clk!==expected_level || ff_edges!=before_edges+expected_level)$fatal(1,"source-edge clock contract differs");
   for(integer n=0;n<8;n=n+1)begin
    enable=~enable;changes=changes+1;#1;
    if(gated_clk!==expected_level || ff_edges!=before_edges+expected_level)$fatal(1,"high-half request caused clock glitch");
   end
   clk=0;#1;
   if(gated_clk!==1'b0)$fatal(1,"clock failed to close");
  end
  $display("FF CLOCK MODEL PASS source_edges=%0d output_edges=%0d high_changes=%0d",source_edges,ff_edges,changes);$finish;
 end
endmodule
