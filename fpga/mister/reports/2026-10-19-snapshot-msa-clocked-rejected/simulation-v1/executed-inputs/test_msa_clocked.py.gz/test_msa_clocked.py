#!/usr/bin/env python3
"""Complete MSA against untouched original using the external FF-clock contract.

The low-latch clock model prevents mid-high requests producing edges. It is a
simulation model, not vendor clock-control qualification or native integration.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import generate_msa_clocked as gen
import test_msa_board as base

HERE=Path(__file__).resolve().parent


def fixture(manifest):
    top,header,metadata=base.fixture(manifest)
    top=gen.base.once(top,' output wire [17:0] result,',
                     ' output wire ff_clock,ff_gate_open,output reg [31:0] ff_edges=0,\n output wire [17:0] result,')
    marker=' wire reference_machine_clk=ref_clk && advance;'
    code=''' wire ff_request;
 dorado_ff_clock_model gate(.clk(clk),.enable(advance || ff_request),.gated_clk(ff_clock),.gate_open(ff_gate_open));
 always @(posedge ff_clock)ff_edges<=ff_edges+1'b1;
'''
    top=gen.base.once(top,marker,marker+'\n'+code)
    top=gen.base.once(top,'dorado_serial_MSA #(.SYSPER(4)) dut(\n',
                     'dorado_serial_MSA #(.SYSPER(4)) dut(\n.state_ff_clk(ff_clock),.state_ff_clock_request(ff_request),\n')
    return top,header,metadata


def run(out,mutations):
    out.mkdir(parents=True,exist_ok=False);inputs=out/'executed-inputs';inputs.mkdir()
    board,manifest,helpers=gen.generate();top,header,metadata=fixture(manifest)
    for p in(Path(__file__),Path(gen.__file__),Path(base.__file__),HERE/'generate_msa_board.py',HERE/'ff_clock_model.sv'):
        (inputs/p.name).write_bytes(p.read_bytes())
    cpp=(HERE/'test_msa_board.cpp').read_text();(inputs/'test_msa_board_original.cpp').write_text(cpp)
    cpp=gen.base.once(cpp,' const bool shifting=d.scan_step;',
        ' const bool shifting=d.scan_step;const unsigned before_ff=d.ff_edges;\n check(!d.ff_clock,"FF clock high before source edge");')
    cpp=gen.base.once(cpp,' if(shifting)++scan_edges;',
        ' check(d.ff_edges==before_ff+unsigned(advance||shifting),"FF clock edge contract differs");\n if(shifting)++scan_edges;')
    (inputs/'test_msa_clocked.cpp').write_text(cpp)
    (inputs/'msa_ddram.v').write_bytes(gen.base.original(gen.base.SOURCE));(inputs/'dorado_storage_group.sv').write_bytes(gen.base.storage.original_source())
    originals=gen.base.original_cells()
    for name,raw in originals.items():(inputs/name).write_bytes(raw)
    assets={'msa_board.sv':board,**helpers,'ff_clock_model.sv':(HERE/'ff_clock_model.sv').read_text()}
    cases=[('candidate',None,None,None,None)]
    if mutations:cases+=[
        ('missing_scan_clock','msa_board.sv','assign state_ff_clock_request=scan_step;',"assign state_ff_clock_request=1'b0;",'FF clock edge contract differs'),
        ('lost_local_hold','msa_board.sv','wire state_hold=state_global_hold ||','wire state_hold=', 'held raw request/response leak'),
        ('wrong_ff_clock','msa_board.sv','.state_host_clk(state_ff_clk)', '.state_host_clk(storage_clk)', 'ordinary physical state differs'),
        ('runt_gate','ff_clock_model.sv','assign gated_clk=clk & gate_open;','assign gated_clk=clk & enable;', 'FF clock edge contract differs'),
    ]
    results=[]
    for label,target,before,after,why in cases:
        case=out/label;case.mkdir();sources=dict(assets)
        if target:
            assert before in sources[target];sources[target]=sources[target].replace(before,after,1)
        for name,body in sources.items():(case/name).write_text(body)
        (case/'fixture.sv').write_text(top);(case/'parameters.h').write_text(header)
        command=['verilator','--cc','--exe','--build','-j','4','--top-module','msa_board_fixture','-Wno-fatal','--assert',
                 '--Mdir',str(case/'obj'),'-CFLAGS','-I'+str(case),str(case/'fixture.sv'),*[str(case/n)for n in sources],
                 str(inputs/'msa_ddram.v'),str(inputs/'dorado_storage_group.sv'),*[str(inputs/n)for n in originals],str(inputs/'test_msa_clocked.cpp')]
        (case/'command.json').write_text(json.dumps(command,indent=2)+'\n')
        with(case/'build.log').open('w')as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
        result=subprocess.run([str(case/'obj/Vmsa_board_fixture')],capture_output=True,text=True,timeout=180)
        text=result.stdout+result.stderr;(case/'test.txt').write_text(text);print(label+': '+text.strip(),flush=True)
        if why:assert result.returncode and why in text,(label,text)
        else:assert result.returncode==0 and 'MSA BOARD PASS'in text,text
        results.append(dict(case=label,returncode=result.returncode,expected_failure=why))
    for name,value in [('manifest',manifest),('fixture-metadata',metadata),('results',dict(status='PASS',scope=__doc__,cases=results,
        executed_inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs.iterdir()},physical_bits=2690,
        limits='External-clock contract with a low-latch simulation gate; no vendor clock implementation, native barriers, area/timing or speed qualification.'))]:
        (out/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args();run(a.output.resolve(),a.mutations)
