module clock_fit(input wire host_clk,input wire [121:0] pins,
 output reg [108:0] result);
 // Fixture input staging avoids treating a virtual package pin as the
 // evaluator's launch register. The evaluator still has a full 15ns path
 // from launch to result; the new staging path has a stricter half period.
 reg [121:0] input_stage;
 reg [121:0] launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [63:0] q,next_q;
 wire before_clock,after_clock;
 wire [27:0] before_controls,after_controls;
 wire [21:0] events,repeated;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls}=launch;
 dorado_processor_capture_step evaluator(q,before_clock,after_clock,
   before_controls,after_controls,next_q,events,repeated,unsettled);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled};
endmodule
