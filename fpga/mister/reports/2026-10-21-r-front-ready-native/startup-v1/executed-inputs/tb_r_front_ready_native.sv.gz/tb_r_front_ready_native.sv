`timescale 1ns/1ps
`default_nettype none
module tb_r_front_ready_native;
 reg host_clk=0,advance=1;
 always #10 host_clk=~host_clk;
 wire guest_clk=host_clk & advance;
 wire [31:0] bb,processor;
 wire [4:0] instructions;
 dorado_native_backplane #(.SYSPER(4)) dut(
   .sys_clk(guest_clk),.storage_clk(host_clk),.contb_advance(advance),
   .baseboard_boot_n(1'b1),.storage_reset(1'b0),
   .storage_req_ready(128'b0),.storage_rsp_valid(128'b0),.storage_rsp_data(2048'b0),
   .baseboard_debug(bb),.processor_debug(processor),.instruction_signals(instructions),
   .RcvData(1'b0),.Collision(1'b0),
   .ClockM0__in(1'b0),.ClockP0__in(1'b0),.DataM0__in(1'b0),.DataP0__in(1'b0));
 integer cycles=0,limit=2000000,cp=0,issues=0,root_edges=0,paused=0,aliases=0,unsettled=0;
 reg prev_cp=0,prev_issue=0,prev_root=0;
 reg [751:0] saved;
 initial begin
  void'($value$plusargs("cycles=%d",limit));
  while(cycles<limit) begin
   @(negedge host_clk);#1;
   cycles=cycles+1;
   if(!advance)begin
     if(dut.r_front_q!==saved)$fatal(1,"native R-front state advanced during backend pause");
     paused=paused+1;
   end
   saved=dut.r_front_q;
   if(cycles>1024 && !dut.r_front_alias_ok)begin
     $display("NATIVE_ALIAS_FAIL cycle=%0d CA=%b PH=%b PL=%b Hhold=%b PRhold=%b LPRhold=%b FFokH=%b FFokL=%b roots=%b%b%b",
        cycles,dut.r_front_alias_ContA,dut.r_front_alias_ProcH,dut.r_front_alias_ProcL,
        dut.b_ProcH.Holda,dut.b_ProcH.PRhold,dut.b_ProcL.PRhold,
        dut.b_ProcH.FFok_p_a,dut.b_ProcL.FFok_p_b,dut.CLK_ca_p_,dut.CLK_ph_p_,dut.CLK_pl_p_);
     $fatal(1,"native boundary alias contract failed");
   end
   if(cycles>1024)aliases=aliases+1;
   if(dut.r_front_unsettled)unsettled=unsettled+1;
   if(dut.CPStrb_p_ && !prev_cp)cp=cp+1;
   if(instructions[4] && !prev_issue)issues=issues+1;
   if(dut.CLK_ca_p_ && !prev_root)root_edges=root_edges+1;
   prev_cp=dut.CPStrb_p_;prev_issue=instructions[4];prev_root=dut.CLK_ca_p_;
   if(cycles%100000==0)$display("NATIVE_STARTUP cycle=%0d bb=%h processor=%h cp=%0d issues=%0d roots=%0d unsettled=%0d",
       cycles,bb,processor,cp,issues,root_edges,unsettled);
   // Gate the machine clock and its matching host-clock storage enables.
   advance=(cycles%100003>=17);
  end
  if(root_edges<1000 || paused<100 || aliases<100000)$fatal(1,"native diagnostic coverage incomplete");
  $display("NATIVE_R_FRONT_STARTUP_BOUNDARIES PASS cycles=%0d cp=%0d issues=%0d roots=%0d pauses=%0d aliases=%0d unsettled=%0d;external storage unresponsive;no boot qualification",
    cycles,cp,issues,root_edges,paused,aliases,unsettled);
  $finish;
 end
endmodule
`default_nettype wire
