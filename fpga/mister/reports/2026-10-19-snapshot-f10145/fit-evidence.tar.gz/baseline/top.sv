module snapshot_fit(
 input wire host_clk,advance,input wire [3:0] address,data,
 input wire ce_n,we_n,freeze,held,request,write,
 input wire [4:0] index,input wire [9:0] state_data,
 output reg frozen,done,error,output reg [9:0] result,output reg [3:0] q);
 // Matched opposite-edge shell. Embedded cell paths have10ns budgets;
 // virtual I/O has2ns maximum/0ns minimum delays. Counts include the shell.
 reg [29:0] launch;
 always @(negedge host_clk)
  launch <= {advance,address,data,ce_n,we_n,freeze,held,request,write,index,state_data};
 wire step_r,ce_r,we_r,freeze_r,held_r,request_r,write_r;
 wire [3:0] address_r,data_r;wire [4:0] index_r;wire [9:0] state_r;
 assign {step_r,address_r,data_r,ce_r,we_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire frozen_w,done_w,error_w;wire [9:0] result_w;wire [3:0] q_w;
 always @(negedge host_clk){frozen,done,error,result,q}<={frozen_w,done_w,error_w,result_w,q_w};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_F10145A_snapshot bank(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(frozen_w),
 .state_done(done_w),.state_error(error_w),.state_result(result_w),
`else
 assign {frozen_w,done_w,error_w,result_w}=13'b0;
 cell_F10145A bank(
`endif
 .sys_clk(host_clk),.p10(address_r[3]),.p9(address_r[2]),.p7(address_r[1]),.p6(address_r[0]),
 .p5(data_r[0]),.p4(data_r[1]),.p11(data_r[2]),.p12(data_r[3]),
 .p3(ce_r),.p13(we_r),.p2(q_w[0]),.p1(q_w[1]),.p15(q_w[2]),.p14(q_w[3]),.p8(1'b0));
endmodule
