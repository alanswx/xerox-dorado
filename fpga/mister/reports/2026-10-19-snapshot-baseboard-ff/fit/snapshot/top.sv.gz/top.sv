module snapshot_fit(input wire host_clk,advance,hold,write,
 input wire [3:0] selected,input wire [1:0] index,input wire [17:0] data,input wire [143:0] pins,
 output reg [161:0] result,output reg [143:0] outputs);
 reg [170:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,hold,write,selected,index,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire advance_r,hold_r,write_r;wire [3:0] selected_r;wire [1:0] index_r;wire [17:0] data_r;wire [143:0] pins_flat;
 assign {advance_r,hold_r,write_r,selected_r,index_r,data_r,pins_flat}=launch;
 wire [15:0] pins_r[9];wire [17:0] result_w[9];wire [15:0] outputs_w[9];
assign pins_r[0]=pins_flat[0+:16];
generate begin:case0
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS259_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd0),.state_index(index_r),.state_data(data_r),.state_result(result_w[0]),.sys_clk(host_clk),.p1(pins_r[0][0]),.p2(pins_r[0][1]),.p3(pins_r[0][2]),.p8(pins_r[0][7]),.p13(pins_r[0][12]),.p14(pins_r[0][13]),.p15(pins_r[0][14]),.p16(pins_r[0][15]),.p5(outputs_w[0][0]),.p7(outputs_w[0][1]));
`else
assign result_w[0]=0;
cell_SN74LS259 cell_inst(.sys_clk(host_clk),.p1(pins_r[0][0]),.p2(pins_r[0][1]),.p3(pins_r[0][2]),.p8(pins_r[0][7]),.p13(pins_r[0][12]),.p14(pins_r[0][13]),.p15(pins_r[0][14]),.p16(pins_r[0][15]),.p5(outputs_w[0][0]),.p7(outputs_w[0][1]));
`endif
assign outputs_w[0][15:2]=0;
always @(posedge host_clk)begin result[0+:18]<=result_w[0];outputs[0+:16]<=outputs_w[0];end
end endgenerate
assign pins_r[1]=pins_flat[16+:16];
generate begin:case1
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS163_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd1),.state_index(index_r),.state_data(data_r),.state_result(result_w[1]),.sys_clk(host_clk),.p1(pins_r[1][0]),.p2(pins_r[1][1]),.p3(pins_r[1][2]),.p4(pins_r[1][3]),.p5(pins_r[1][4]),.p6(pins_r[1][5]),.p7(pins_r[1][6]),.p8(pins_r[1][7]),.p9(pins_r[1][8]),.p10(pins_r[1][9]),.p16(pins_r[1][15]),.p15(outputs_w[1][0]));
`else
assign result_w[1]=0;
cell_SN74LS163 cell_inst(.sys_clk(host_clk),.p1(pins_r[1][0]),.p2(pins_r[1][1]),.p3(pins_r[1][2]),.p4(pins_r[1][3]),.p5(pins_r[1][4]),.p6(pins_r[1][5]),.p7(pins_r[1][6]),.p8(pins_r[1][7]),.p9(pins_r[1][8]),.p10(pins_r[1][9]),.p16(pins_r[1][15]),.p15(outputs_w[1][0]));
`endif
assign outputs_w[1][15:1]=0;
always @(posedge host_clk)begin result[18+:18]<=result_w[1];outputs[16+:16]<=outputs_w[1];end
end endgenerate
assign pins_r[2]=pins_flat[32+:16];
generate begin:case2
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS175_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd2),.state_index(index_r),.state_data(data_r),.state_result(result_w[2]),.sys_clk(host_clk),.p1(pins_r[2][0]),.p4(pins_r[2][3]),.p5(pins_r[2][4]),.p8(pins_r[2][7]),.p9(pins_r[2][8]),.p16(pins_r[2][15]),.p2(outputs_w[2][0]),.p7(outputs_w[2][1]));
`else
assign result_w[2]=0;
cell_SN74LS175 cell_inst(.sys_clk(host_clk),.p1(pins_r[2][0]),.p4(pins_r[2][3]),.p5(pins_r[2][4]),.p8(pins_r[2][7]),.p9(pins_r[2][8]),.p16(pins_r[2][15]),.p2(outputs_w[2][0]),.p7(outputs_w[2][1]));
`endif
assign outputs_w[2][15:2]=0;
always @(posedge host_clk)begin result[36+:18]<=result_w[2];outputs[32+:16]<=outputs_w[2];end
end endgenerate
assign pins_r[3]=pins_flat[48+:16];
generate begin:case3
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS74_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd3),.state_index(index_r),.state_data(data_r),.state_result(result_w[3]),.sys_clk(host_clk),.p1(pins_r[3][0]),.p2(pins_r[3][1]),.p3(pins_r[3][2]),.p4(pins_r[3][3]),.p7(pins_r[3][6]),.p10(pins_r[3][9]),.p11(pins_r[3][10]),.p12(pins_r[3][11]),.p13(pins_r[3][12]),.p14(pins_r[3][13]),.p5(outputs_w[3][0]),.p6(outputs_w[3][1]),.p8(outputs_w[3][2]));
`else
assign result_w[3]=0;
cell_SN74LS74 cell_inst(.sys_clk(host_clk),.p1(pins_r[3][0]),.p2(pins_r[3][1]),.p3(pins_r[3][2]),.p4(pins_r[3][3]),.p7(pins_r[3][6]),.p10(pins_r[3][9]),.p11(pins_r[3][10]),.p12(pins_r[3][11]),.p13(pins_r[3][12]),.p14(pins_r[3][13]),.p5(outputs_w[3][0]),.p6(outputs_w[3][1]),.p8(outputs_w[3][2]));
`endif
assign outputs_w[3][15:3]=0;
always @(posedge host_clk)begin result[54+:18]<=result_w[3];outputs[48+:16]<=outputs_w[3];end
end endgenerate
assign pins_r[4]=pins_flat[64+:16];
generate begin:case4
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MC1690_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd4),.state_index(index_r),.state_data(data_r),.state_result(result_w[4]),.sys_clk(host_clk),.p7(pins_r[4][6]),.p11(pins_r[4][10]),.p2(outputs_w[4][0]),.p3(outputs_w[4][1]));
`else
assign result_w[4]=0;
cell_MC1690 cell_inst(.sys_clk(host_clk),.p7(pins_r[4][6]),.p11(pins_r[4][10]),.p2(outputs_w[4][0]),.p3(outputs_w[4][1]));
`endif
assign outputs_w[4][15:2]=0;
always @(posedge host_clk)begin result[72+:18]<=result_w[4];outputs[64+:16]<=outputs_w[4];end
end endgenerate
assign pins_r[5]=pins_flat[80+:16];
generate begin:case5
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MC12061_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd5),.state_index(index_r),.state_data(data_r),.state_result(result_w[5]),.sys_clk(host_clk),.p1(pins_r[5][0]),.p4(pins_r[5][3]),.p5(pins_r[5][4]),.p6(pins_r[5][5]),.p7(pins_r[5][6]),.p8(pins_r[5][7]),.p9(pins_r[5][8]),.p11(pins_r[5][10]),.p14(pins_r[5][13]),.p15(pins_r[5][14]),.p16(pins_r[5][15]),.p2(outputs_w[5][0]),.p3(outputs_w[5][1]),.p10(outputs_w[5][2]));
`else
assign result_w[5]=0;
cell_MC12061 cell_inst(.sys_clk(host_clk),.p1(pins_r[5][0]),.p4(pins_r[5][3]),.p5(pins_r[5][4]),.p6(pins_r[5][5]),.p7(pins_r[5][6]),.p8(pins_r[5][7]),.p9(pins_r[5][8]),.p11(pins_r[5][10]),.p14(pins_r[5][13]),.p15(pins_r[5][14]),.p16(pins_r[5][15]),.p2(outputs_w[5][0]),.p3(outputs_w[5][1]),.p10(outputs_w[5][2]));
`endif
assign outputs_w[5][15:3]=0;
always @(posedge host_clk)begin result[90+:18]<=result_w[5];outputs[80+:16]<=outputs_w[5];end
end endgenerate
assign pins_r[6]=pins_flat[96+:16];
generate begin:case6
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MC14521B_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd6),.state_index(index_r),.state_data(data_r),.state_result(result_w[6]),.sys_clk(host_clk),.p2(pins_r[6][1]),.p3(pins_r[6][2]),.p5(pins_r[6][4]),.p6(pins_r[6][5]),.p8(pins_r[6][7]),.p16(pins_r[6][15]),.p13(outputs_w[6][0]));
`else
assign result_w[6]=0;
cell_MC14521B cell_inst(.sys_clk(host_clk),.p2(pins_r[6][1]),.p3(pins_r[6][2]),.p5(pins_r[6][4]),.p6(pins_r[6][5]),.p8(pins_r[6][7]),.p16(pins_r[6][15]),.p13(outputs_w[6][0]));
`endif
assign outputs_w[6][15:1]=0;
always @(posedge host_clk)begin result[108+:18]<=result_w[6];outputs[96+:16]<=outputs_w[6];end
end endgenerate
assign pins_r[7]=pins_flat[112+:16];
generate begin:case7
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MPQ3303_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd7),.state_index(index_r),.state_data(data_r),.state_result(result_w[7]),.sys_clk(host_clk),.p2(pins_r[7][1]),.p6(pins_r[7][5]),.p9(pins_r[7][8]),.p13(pins_r[7][12]),.p1(outputs_w[7][0]),.p3(outputs_w[7][1]),.p5(outputs_w[7][2]),.p7(outputs_w[7][3]),.p8(outputs_w[7][4]),.p10(outputs_w[7][5]),.p12(outputs_w[7][6]),.p14(outputs_w[7][7]));
`else
assign result_w[7]=0;
cell_MPQ3303 cell_inst(.sys_clk(host_clk),.p2(pins_r[7][1]),.p6(pins_r[7][5]),.p9(pins_r[7][8]),.p13(pins_r[7][12]),.p1(outputs_w[7][0]),.p3(outputs_w[7][1]),.p5(outputs_w[7][2]),.p7(outputs_w[7][3]),.p8(outputs_w[7][4]),.p10(outputs_w[7][5]),.p12(outputs_w[7][6]),.p14(outputs_w[7][7]));
`endif
assign outputs_w[7][15:8]=0;
always @(posedge host_clk)begin result[126+:18]<=result_w[7];outputs[112+:16]<=outputs_w[7];end
end endgenerate
assign pins_r[8]=pins_flat[128+:16];
generate begin:case8
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_CLOCKGEN_snapshot #(.N(4)) cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r && selected_r==4'd8),.state_index(index_r),.state_data(data_r),.state_result(result_w[8]),.sys_clk(host_clk),.StartClockPulse_n(outputs_w[8][0]),.EndClockPulse(outputs_w[8][1]));
`else
assign result_w[8]=0;
cell_CLOCKGEN #(.N(4)) cell_inst(.sys_clk(host_clk),.StartClockPulse_n(outputs_w[8][0]),.EndClockPulse(outputs_w[8][1]));
`endif
assign outputs_w[8][15:2]=0;
always @(posedge host_clk)begin result[144+:18]<=result_w[8];outputs[128+:16]<=outputs_w[8];end
end endgenerate
endmodule
