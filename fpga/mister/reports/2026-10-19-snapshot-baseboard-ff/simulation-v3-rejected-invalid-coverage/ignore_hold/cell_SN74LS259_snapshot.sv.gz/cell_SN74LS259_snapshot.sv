// cell_SN74LS259 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 1 package position(s) across the sixteen boards.
//
// 8-Bit Addressable Latch (TTL). TtlDict:
//   a,CL',15 > a,D,13 > a,EN',14 > a,S1,1 > a,S2,2 > a,S4,3
//   a,Q0,4 > a,Q1,5 > a,Q2,6 > a,Q3,7 > a,Q4,9 > a,Q5,10 > a,Q6,11 > a,Q7,12
//
// With the enable low the addressed latch follows D; clear is active low and
// resets all eight. Only the pins the board wires are declared.

// EDGE-TRIGGERED on the fabric clock with the latch enable as an ENABLE, the
// convention this design uses for every clocked element.
//
// The part is a TRANSPARENT latch: while its enable is asserted the output
// follows the input, which is a combinational path straight through it and
// closes a loop wherever the machine feeds a latch from something downstream
// of it. sys_clk heavily oversamples every signal on the board, so the
// behaviour while transparent is the same to a fabric clock's precision -- and
// unlike a latch it synthesises.

`default_nettype none

module cell_SN74LS259_snapshot (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [1:0] state_index,input wire [17:0] state_data,output reg [17:0] state_result,
    input  wire sys_clk,
    input  wire p1,  // S1
    input  wire p2,  // S2
    input  wire p3,  // S4
    output wire p5,  // Q1
    output wire p7,  // Q3
    input  wire p8,  // (no name in EclDict)
    input  wire p13,  // D
    input  wire p14,  // EN'
    input  wire p15,  // CL'
    input  wire p16// (no name in EclDict)
);

  wire [2:0] sel = {p3, p2, p1};        // S4, S2, S1

  reg [7:0] q;
  assign p5 = q[1];  assign p7 = q[3];

  wire _unused_pins = &{1'b0, p8, p16, 1'b0};
 always @* begin
  state_result=18'b0;
  case(state_index)
   2'd0:state_result={10'b0,{q}};
   default:state_result=18'b0;
  endcase
 end
 always @(posedge state_host_clk)begin
  if(1'b0)begin
   if(state_write)case(state_index)
    2'd0:{q}<=state_data[7:0];
    default:;
   endcase
  end else if(state_advance)begin
begin
    if (!p15)      q <= 8'd0;           // CL'
    else if (!p14) q[sel] <= p13;       // EN' low: the addressed latch follows D
  end
  end
 end
endmodule

`default_nettype wire
