module baseboard_ff_fixture(input wire host_clk,ref_clk,advance,hold,write,
 input wire [3:0] selected,input wire [1:0] index,input wire [17:0] data,
 input wire [15:0] pins[9],output wire [31:0] physical[9],original_state[9],
 output wire [17:0] result[9],output wire [15:0] outputs[9],original_outputs[9]);
begin:case0
cell_SN74LS259_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd0),.state_index(index),.state_data(data),.state_result(result[0]),.sys_clk(ref_clk),.p1(pins[0][0]),.p2(pins[0][1]),.p3(pins[0][2]),.p8(pins[0][7]),.p13(pins[0][12]),.p14(pins[0][13]),.p15(pins[0][14]),.p16(pins[0][15]),.p5(outputs[0][0]),.p7(outputs[0][1]));
cell_SN74LS259 ref_i(.sys_clk(ref_clk),.p1(pins[0][0]),.p2(pins[0][1]),.p3(pins[0][2]),.p8(pins[0][7]),.p13(pins[0][12]),.p14(pins[0][13]),.p15(pins[0][14]),.p16(pins[0][15]),.p5(original_outputs[0][0]),.p7(original_outputs[0][1]));
assign physical[0]={24'b0,{cell_i.q}};
assign original_state[0]={24'b0,{ref_i.q}};
assign outputs[0][15:2]=0;assign original_outputs[0][15:2]=0;
end
begin:case1
cell_SN74LS163_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd1),.state_index(index),.state_data(data),.state_result(result[1]),.sys_clk(ref_clk),.p1(pins[1][0]),.p2(pins[1][1]),.p3(pins[1][2]),.p4(pins[1][3]),.p5(pins[1][4]),.p6(pins[1][5]),.p7(pins[1][6]),.p8(pins[1][7]),.p9(pins[1][8]),.p10(pins[1][9]),.p16(pins[1][15]),.p15(outputs[1][0]));
cell_SN74LS163 ref_i(.sys_clk(ref_clk),.p1(pins[1][0]),.p2(pins[1][1]),.p3(pins[1][2]),.p4(pins[1][3]),.p5(pins[1][4]),.p6(pins[1][5]),.p7(pins[1][6]),.p8(pins[1][7]),.p9(pins[1][8]),.p10(pins[1][9]),.p16(pins[1][15]),.p15(original_outputs[1][0]));
assign physical[1]={27'b0,{cell_i.ck_d,cell_i.q}};
assign original_state[1]={27'b0,{ref_i.ck_d,ref_i.q}};
assign outputs[1][15:1]=0;assign original_outputs[1][15:1]=0;
end
begin:case2
cell_SN74LS175_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd2),.state_index(index),.state_data(data),.state_result(result[2]),.sys_clk(ref_clk),.p1(pins[2][0]),.p4(pins[2][3]),.p5(pins[2][4]),.p8(pins[2][7]),.p9(pins[2][8]),.p16(pins[2][15]),.p2(outputs[2][0]),.p7(outputs[2][1]));
cell_SN74LS175 ref_i(.sys_clk(ref_clk),.p1(pins[2][0]),.p4(pins[2][3]),.p5(pins[2][4]),.p8(pins[2][7]),.p9(pins[2][8]),.p16(pins[2][15]),.p2(original_outputs[2][0]),.p7(original_outputs[2][1]));
assign physical[2]={29'b0,{cell_i.ck_d,cell_i.q}};
assign original_state[2]={29'b0,{ref_i.ck_d,ref_i.q}};
assign outputs[2][15:2]=0;assign original_outputs[2][15:2]=0;
end
begin:case3
cell_SN74LS74_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd3),.state_index(index),.state_data(data),.state_result(result[3]),.sys_clk(ref_clk),.p1(pins[3][0]),.p2(pins[3][1]),.p3(pins[3][2]),.p4(pins[3][3]),.p7(pins[3][6]),.p10(pins[3][9]),.p11(pins[3][10]),.p12(pins[3][11]),.p13(pins[3][12]),.p14(pins[3][13]),.p5(outputs[3][0]),.p6(outputs[3][1]),.p8(outputs[3][2]));
cell_SN74LS74 ref_i(.sys_clk(ref_clk),.p1(pins[3][0]),.p2(pins[3][1]),.p3(pins[3][2]),.p4(pins[3][3]),.p7(pins[3][6]),.p10(pins[3][9]),.p11(pins[3][10]),.p12(pins[3][11]),.p13(pins[3][12]),.p14(pins[3][13]),.p5(original_outputs[3][0]),.p6(original_outputs[3][1]),.p8(original_outputs[3][2]));
assign physical[3]={28'b0,{cell_i.ckb_d,cell_i.cka_d,cell_i.qb,cell_i.qa}};
assign original_state[3]={28'b0,{ref_i.ckb_d,ref_i.cka_d,ref_i.qb,ref_i.qa}};
assign outputs[3][15:3]=0;assign original_outputs[3][15:3]=0;
end
begin:case4
cell_MC1690_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd4),.state_index(index),.state_data(data),.state_result(result[4]),.sys_clk(ref_clk),.p7(pins[4][6]),.p11(pins[4][10]),.p2(outputs[4][0]),.p3(outputs[4][1]));
cell_MC1690 ref_i(.sys_clk(ref_clk),.p7(pins[4][6]),.p11(pins[4][10]),.p2(original_outputs[4][0]),.p3(original_outputs[4][1]));
assign physical[4]={30'b0,{cell_i.ck_d,cell_i.q}};
assign original_state[4]={30'b0,{ref_i.ck_d,ref_i.q}};
assign outputs[4][15:2]=0;assign original_outputs[4][15:2]=0;
end
begin:case5
cell_MC12061_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd5),.state_index(index),.state_data(data),.state_result(result[5]),.sys_clk(ref_clk),.p1(pins[5][0]),.p4(pins[5][3]),.p5(pins[5][4]),.p6(pins[5][5]),.p7(pins[5][6]),.p8(pins[5][7]),.p9(pins[5][8]),.p11(pins[5][10]),.p14(pins[5][13]),.p15(pins[5][14]),.p16(pins[5][15]),.p2(outputs[5][0]),.p3(outputs[5][1]),.p10(outputs[5][2]));
cell_MC12061 ref_i(.sys_clk(ref_clk),.p1(pins[5][0]),.p4(pins[5][3]),.p5(pins[5][4]),.p6(pins[5][5]),.p7(pins[5][6]),.p8(pins[5][7]),.p9(pins[5][8]),.p11(pins[5][10]),.p14(pins[5][13]),.p15(pins[5][14]),.p16(pins[5][15]),.p2(original_outputs[5][0]),.p3(original_outputs[5][1]),.p10(original_outputs[5][2]));
assign physical[5]={29'b0,{cell_i.osc_div}};
assign original_state[5]={29'b0,{ref_i.osc_div}};
assign outputs[5][15:3]=0;assign original_outputs[5][15:3]=0;
end
begin:case6
cell_MC14521B_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd6),.state_index(index),.state_data(data),.state_result(result[6]),.sys_clk(ref_clk),.p2(pins[6][1]),.p3(pins[6][2]),.p5(pins[6][4]),.p6(pins[6][5]),.p8(pins[6][7]),.p16(pins[6][15]),.p13(outputs[6][0]));
cell_MC14521B ref_i(.sys_clk(ref_clk),.p2(pins[6][1]),.p3(pins[6][2]),.p5(pins[6][4]),.p6(pins[6][5]),.p8(pins[6][7]),.p16(pins[6][15]),.p13(original_outputs[6][0]));
assign physical[6]={7'b0,{cell_i.ck_d,cell_i.cnt}};
assign original_state[6]={7'b0,{ref_i.ck_d,ref_i.cnt}};
assign outputs[6][15:1]=0;assign original_outputs[6][15:1]=0;
end
begin:case7
cell_MPQ3303_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd7),.state_index(index),.state_data(data),.state_result(result[7]),.sys_clk(ref_clk),.p2(pins[7][1]),.p6(pins[7][5]),.p9(pins[7][8]),.p13(pins[7][12]),.p1(outputs[7][0]),.p3(outputs[7][1]),.p5(outputs[7][2]),.p7(outputs[7][3]),.p8(outputs[7][4]),.p10(outputs[7][5]),.p12(outputs[7][6]),.p14(outputs[7][7]));
cell_MPQ3303 ref_i(.sys_clk(ref_clk),.p2(pins[7][1]),.p6(pins[7][5]),.p9(pins[7][8]),.p13(pins[7][12]),.p1(original_outputs[7][0]),.p3(original_outputs[7][1]),.p5(original_outputs[7][2]),.p7(original_outputs[7][3]),.p8(original_outputs[7][4]),.p10(original_outputs[7][5]),.p12(original_outputs[7][6]),.p14(original_outputs[7][7]));
assign physical[7]={14'b0,{cell_i.por,cell_i.vco}};
assign original_state[7]={14'b0,{ref_i.por,ref_i.vco}};
assign outputs[7][15:8]=0;assign original_outputs[7][15:8]=0;
end
begin:case8
cell_CLOCKGEN_snapshot #(.N(4)) cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==4'd8),.state_index(index),.state_data(data),.state_result(result[8]),.sys_clk(ref_clk),.StartClockPulse_n(outputs[8][0]),.EndClockPulse(outputs[8][1]));
cell_CLOCKGEN #(.N(4)) ref_i(.sys_clk(ref_clk),.StartClockPulse_n(original_outputs[8][0]),.EndClockPulse(original_outputs[8][1]));
assign physical[8]={30'b0,{cell_i.phase}};
assign original_state[8]={30'b0,{ref_i.phase}};
assign outputs[8][15:2]=0;assign original_outputs[8][15:2]=0;
end
endmodule
