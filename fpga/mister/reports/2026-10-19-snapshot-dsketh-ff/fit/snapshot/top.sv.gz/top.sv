module snapshot_fit(input wire host_clk,advance,hold,write,
 input wire [17:0] data,input wire [11:0] pins,
 output reg [89:0] result,output reg [29:0] outputs);
 reg [32:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,hold,write,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire advance_r,hold_r,write_r;wire [17:0] data_r;wire [11:0] pins_r;
 assign {advance_r,hold_r,write_r,data_r,pins_r}=launch;
 wire [17:0] result_w[5];wire [5:0] outputs_w[5];
generate begin:case0
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MC1650_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r),.state_data(data_r),.state_result(result_w[0]),.sys_clk(host_clk),.p4(pins_r[0]),.p6(pins_r[1]),.p5(pins_r[2]),.p13(pins_r[3]),.p12(pins_r[4]),.p11(pins_r[5]),.p1(1'b0),.p7(1'b0),.p8(1'b0),.p10(1'b0),.p16(1'b1),.p2(outputs_w[0][0]),.p14(outputs_w[0][1]));
`else
assign result_w[0]=0;
cell_MC1650 cell_inst(.sys_clk(host_clk),.p4(pins_r[0]),.p6(pins_r[1]),.p5(pins_r[2]),.p13(pins_r[3]),.p12(pins_r[4]),.p11(pins_r[5]),.p1(1'b0),.p7(1'b0),.p8(1'b0),.p10(1'b0),.p16(1'b1),.p2(outputs_w[0][0]),.p14(outputs_w[0][1]));
`endif
assign outputs_w[0][5:2]=0;
always @(posedge host_clk)begin result[0+:18]<=result_w[0];outputs[0+:6]<=outputs_w[0];end
end endgenerate
generate begin:case1
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_MC10136_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r),.state_data(data_r),.state_result(result_w[1]),.sys_clk(host_clk),.p13(pins_r[0]),.p5(pins_r[1]),.p6(pins_r[2]),.p11(pins_r[3]),.p12(pins_r[4]),.p9(pins_r[5]),.p7(pins_r[6]),.p10(pins_r[7]),.p3(outputs_w[1][3]),.p2(outputs_w[1][2]),.p15(outputs_w[1][1]),.p14(outputs_w[1][0]),.p4(outputs_w[1][4]));
`else
assign result_w[1]=0;
cell_MC10136 cell_inst(.sys_clk(host_clk),.p13(pins_r[0]),.p5(pins_r[1]),.p6(pins_r[2]),.p11(pins_r[3]),.p12(pins_r[4]),.p9(pins_r[5]),.p7(pins_r[6]),.p10(pins_r[7]),.p3(outputs_w[1][3]),.p2(outputs_w[1][2]),.p15(outputs_w[1][1]),.p14(outputs_w[1][0]),.p4(outputs_w[1][4]));
`endif
assign outputs_w[1][5:5]=0;
always @(posedge host_clk)begin result[18+:18]<=result_w[1];outputs[6+:6]<=outputs_w[1];end
end endgenerate
generate begin:case2
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS169_snapshot cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r),.state_data(data_r),.state_result(result_w[2]),.sys_clk(host_clk),.p2(pins_r[0]),.p1(pins_r[1]),.p9(pins_r[2]),.p7(pins_r[3]),.p10(pins_r[4]),.p6(pins_r[5]),.p5(pins_r[6]),.p4(pins_r[7]),.p3(pins_r[8]),.p8(1'b0),.p16(1'b1),.p15(outputs_w[2][0]));
`else
assign result_w[2]=0;
cell_SN74LS169 cell_inst(.sys_clk(host_clk),.p2(pins_r[0]),.p1(pins_r[1]),.p9(pins_r[2]),.p7(pins_r[3]),.p10(pins_r[4]),.p6(pins_r[5]),.p5(pins_r[6]),.p4(pins_r[7]),.p3(pins_r[8]),.p8(1'b0),.p16(1'b1),.p15(outputs_w[2][0]));
`endif
assign outputs_w[2][5:1]=0;
always @(posedge host_clk)begin result[36+:18]<=result_w[2];outputs[12+:6]<=outputs_w[2];end
end endgenerate
generate begin:case3
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS174_snapshot #(.PRECAP(0)) cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r),.state_data(data_r),.state_result(result_w[3]),.sys_clk(host_clk),.p9(pins_r[0]),.p1(pins_r[1]),.p3(pins_r[2]),.p4(pins_r[3]),.p6(pins_r[4]),.p11(pins_r[5]),.p13(pins_r[6]),.p14(pins_r[7]),.p8(1'b0),.p16(1'b1),.p2(outputs_w[3][0]),.p5(outputs_w[3][1]),.p7(outputs_w[3][2]),.p10(outputs_w[3][3]),.p12(outputs_w[3][4]),.p15(outputs_w[3][5]));
`else
assign result_w[3]=0;
cell_SN74LS174 #(.PRECAP(0)) cell_inst(.sys_clk(host_clk),.p9(pins_r[0]),.p1(pins_r[1]),.p3(pins_r[2]),.p4(pins_r[3]),.p6(pins_r[4]),.p11(pins_r[5]),.p13(pins_r[6]),.p14(pins_r[7]),.p8(1'b0),.p16(1'b1),.p2(outputs_w[3][0]),.p5(outputs_w[3][1]),.p7(outputs_w[3][2]),.p10(outputs_w[3][3]),.p12(outputs_w[3][4]),.p15(outputs_w[3][5]));
`endif
always @(posedge host_clk)begin result[54+:18]<=result_w[3];outputs[18+:6]<=outputs_w[3];end
end endgenerate
generate begin:case4
`ifdef SNAPSHOT_BANK_EXPERIMENT
cell_SN74LS174_snapshot #(.PRECAP(1)) cell_inst(.state_host_clk(host_clk),.state_advance(advance_r),.state_hold(hold_r),.state_write(write_r),.state_data(data_r),.state_result(result_w[4]),.sys_clk(host_clk),.p9(pins_r[0]),.p1(pins_r[1]),.p3(pins_r[2]),.p4(pins_r[3]),.p6(pins_r[4]),.p11(pins_r[5]),.p13(pins_r[6]),.p14(pins_r[7]),.p8(1'b0),.p16(1'b1),.p2(outputs_w[4][0]),.p5(outputs_w[4][1]),.p7(outputs_w[4][2]),.p10(outputs_w[4][3]),.p12(outputs_w[4][4]),.p15(outputs_w[4][5]));
`else
assign result_w[4]=0;
cell_SN74LS174 #(.PRECAP(1)) cell_inst(.sys_clk(host_clk),.p9(pins_r[0]),.p1(pins_r[1]),.p3(pins_r[2]),.p4(pins_r[3]),.p6(pins_r[4]),.p11(pins_r[5]),.p13(pins_r[6]),.p14(pins_r[7]),.p8(1'b0),.p16(1'b1),.p2(outputs_w[4][0]),.p5(outputs_w[4][1]),.p7(outputs_w[4][2]),.p10(outputs_w[4][3]),.p12(outputs_w[4][4]),.p15(outputs_w[4][5]));
`endif
always @(posedge host_clk)begin result[72+:18]<=result_w[4];outputs[24+:6]<=outputs_w[4];end
end endgenerate
endmodule
