module dsketh_ff_fixture(input wire host_clk,ref_clk,advance,hold,write,individual,
 input wire [11:0] pins,input wire [17:0] data,restore_data[5],
 output wire [17:0] result[5],physical[5],original_state[5],
 output wire [5:0] outputs[5],original_outputs[5]);
begin:case0
cell_MC1650_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(individual?restore_data[0]:data),.state_result(result[0]),.sys_clk(ref_clk),.p4(pins[0]),.p6(pins[1]),.p5(pins[2]),.p13(pins[3]),.p12(pins[4]),.p11(pins[5]),.p1(1'b0),.p7(1'b0),.p8(1'b0),.p10(1'b0),.p16(1'b1),.p2(outputs[0][0]),.p14(outputs[0][1]));
cell_MC1650 ref_i(.sys_clk(ref_clk),.p4(pins[0]),.p6(pins[1]),.p5(pins[2]),.p13(pins[3]),.p12(pins[4]),.p11(pins[5]),.p1(1'b0),.p7(1'b0),.p8(1'b0),.p10(1'b0),.p16(1'b1),.p2(original_outputs[0][0]),.p14(original_outputs[0][1]));
assign physical[0]={16'b0,{cell_i.qb,cell_i.qa}};
assign original_state[0]={16'b0,{ref_i.qb,ref_i.qa}};
end
assign outputs[0][5:2]=0;assign original_outputs[0][5:2]=0;
begin:case1
cell_MC10136_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(individual?restore_data[1]:data),.state_result(result[1]),.sys_clk(ref_clk),.p13(pins[0]),.p5(pins[1]),.p6(pins[2]),.p11(pins[3]),.p12(pins[4]),.p9(pins[5]),.p7(pins[6]),.p10(pins[7]),.p3(outputs[1][3]),.p2(outputs[1][2]),.p15(outputs[1][1]),.p14(outputs[1][0]),.p4(outputs[1][4]));
cell_MC10136 ref_i(.sys_clk(ref_clk),.p13(pins[0]),.p5(pins[1]),.p6(pins[2]),.p11(pins[3]),.p12(pins[4]),.p9(pins[5]),.p7(pins[6]),.p10(pins[7]),.p3(original_outputs[1][3]),.p2(original_outputs[1][2]),.p15(original_outputs[1][1]),.p14(original_outputs[1][0]),.p4(original_outputs[1][4]));
assign physical[1]={6'b0,{cell_i.ck_d,cell_i.cin_pre,cell_i.sd_pre,cell_i.su_pre,cell_i.d_pre,cell_i.q}};
assign original_state[1]={6'b0,{ref_i.ck_d,ref_i.cin_pre,ref_i.sd_pre,ref_i.su_pre,ref_i.d_pre,ref_i.q}};
end
assign outputs[1][5:5]=0;assign original_outputs[1][5:5]=0;
begin:case2
cell_SN74LS169_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(individual?restore_data[2]:data),.state_result(result[2]),.sys_clk(ref_clk),.p2(pins[0]),.p1(pins[1]),.p9(pins[2]),.p7(pins[3]),.p10(pins[4]),.p6(pins[5]),.p5(pins[6]),.p4(pins[7]),.p3(pins[8]),.p8(1'b0),.p16(1'b1),.p15(outputs[2][0]));
cell_SN74LS169 ref_i(.sys_clk(ref_clk),.p2(pins[0]),.p1(pins[1]),.p9(pins[2]),.p7(pins[3]),.p10(pins[4]),.p6(pins[5]),.p5(pins[6]),.p4(pins[7]),.p3(pins[8]),.p8(1'b0),.p16(1'b1),.p15(original_outputs[2][0]));
assign physical[2]={10'b0,{cell_i.ck_d,cell_i.p10_d,cell_i.p9_d,cell_i.p7_d,cell_i.q}};
assign original_state[2]={10'b0,{ref_i.ck_d,ref_i.p10_d,ref_i.p9_d,ref_i.p7_d,ref_i.q}};
end
assign outputs[2][5:1]=0;assign original_outputs[2][5:1]=0;
begin:case3
cell_SN74LS174_snapshot #(.PRECAP(0)) cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(individual?restore_data[3]:data),.state_result(result[3]),.sys_clk(ref_clk),.p9(pins[0]),.p1(pins[1]),.p3(pins[2]),.p4(pins[3]),.p6(pins[4]),.p11(pins[5]),.p13(pins[6]),.p14(pins[7]),.p8(1'b0),.p16(1'b1),.p2(outputs[3][0]),.p5(outputs[3][1]),.p7(outputs[3][2]),.p10(outputs[3][3]),.p12(outputs[3][4]),.p15(outputs[3][5]));
cell_SN74LS174 #(.PRECAP(0)) ref_i(.sys_clk(ref_clk),.p9(pins[0]),.p1(pins[1]),.p3(pins[2]),.p4(pins[3]),.p6(pins[4]),.p11(pins[5]),.p13(pins[6]),.p14(pins[7]),.p8(1'b0),.p16(1'b1),.p2(original_outputs[3][0]),.p5(original_outputs[3][1]),.p7(original_outputs[3][2]),.p10(original_outputs[3][3]),.p12(original_outputs[3][4]),.p15(original_outputs[3][5]));
assign physical[3]={5'b0,{cell_i.ck_d,cell_i.d_pre,cell_i.q}};
assign original_state[3]={5'b0,{ref_i.ck_d,ref_i.d_pre,ref_i.q}};
end
begin:case4
cell_SN74LS174_snapshot #(.PRECAP(1)) cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(individual?restore_data[4]:data),.state_result(result[4]),.sys_clk(ref_clk),.p9(pins[0]),.p1(pins[1]),.p3(pins[2]),.p4(pins[3]),.p6(pins[4]),.p11(pins[5]),.p13(pins[6]),.p14(pins[7]),.p8(1'b0),.p16(1'b1),.p2(outputs[4][0]),.p5(outputs[4][1]),.p7(outputs[4][2]),.p10(outputs[4][3]),.p12(outputs[4][4]),.p15(outputs[4][5]));
cell_SN74LS174 #(.PRECAP(1)) ref_i(.sys_clk(ref_clk),.p9(pins[0]),.p1(pins[1]),.p3(pins[2]),.p4(pins[3]),.p6(pins[4]),.p11(pins[5]),.p13(pins[6]),.p14(pins[7]),.p8(1'b0),.p16(1'b1),.p2(original_outputs[4][0]),.p5(original_outputs[4][1]),.p7(original_outputs[4][2]),.p10(original_outputs[4][3]),.p12(original_outputs[4][4]),.p15(original_outputs[4][5]));
assign physical[4]={5'b0,{cell_i.ck_d,cell_i.d_pre,cell_i.q}};
assign original_state[4]={5'b0,{ref_i.ck_d,ref_i.d_pre,ref_i.q}};
end
endmodule
