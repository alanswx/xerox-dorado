from pathlib import Path
import json,os,hashlib,shutil,time
base=Path('/home/alans/mister/dorado-cleanup-followup-20261022');base.mkdir(exist_ok=True)
plan=json.loads(Path('/tmp/dorado-cleanup-followup-plan-20261022.json').read_text());(base/'plan.json').write_text(json.dumps(plan,indent=2))
paths=[Path(x['path']) for x in plan]
for p in paths:
 assert p.parent.name=='core' and p.name in ['db','incremental_db'] and p.parents[2]==Path('/home/alans/mister')
 assert p.parents[1].name.startswith('Dorado_') and p.parents[1].name.rsplit('_',1)[-1]<'20261022'
 assert not p.is_symlink()
def in_targets(p):return any(p==x or p.is_relative_to(x) for x in paths)
active=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  comm=(proc/'comm').read_text().strip()
  if 'quartus' in comm:active.append([proc.name,comm])
  for link in [proc/'cwd']+list((proc/'fd').iterdir()):
   try:
    target=Path(os.readlink(link))
    if target.is_absolute() and in_targets(target):active.append([proc.name,str(target)])
   except OSError:pass
 except (OSError,PermissionError):pass
assert not active,active
roots=sorted(set(p.parents[1] for p in paths))
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def protected():
 out={}
 for r in roots:
  for dp,dn,fn in os.walk(r):
   dn[:]=[n for n in dn if not in_targets(Path(dp)/n) and not (Path(dp)/n).is_symlink()]
   for n in fn:
    p=Path(dp)/n
    if p.is_file() and not p.is_symlink():out[str(p)]={'bytes':p.stat().st_size,'sha256':digest(p)}
 return out
before=protected();(base/'protected-before.json').write_text(json.dumps(before,indent=2))
result={'started':time.time(),'free_before':shutil.disk_usage(base).free,'deleted':[]}
for x,p in zip(plan,paths):
 files=[q for q in p.rglob('*') if q.is_file() and not q.is_symlink()]
 total=sum(q.stat().st_size for q in files);assert total==x['bytes']
 shutil.rmtree(p);result['deleted'].append({**x,'files':len(files)})
 print('DELETED',p,total,flush=True)
after=protected();assert before==after
result.update(status='PASS',finished=time.time(),free_after=shutil.disk_usage(base).free,protected_files=len(before),protected_files_hash_identical=True)
(base/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='deleted'},indent=2),flush=True)
