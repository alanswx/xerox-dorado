from pathlib import Path
import os,json,hashlib,gzip,shutil,time,subprocess
base=Path(__file__).resolve().parent
plan=json.loads((base/'local-plan.json').read_text()); root=Path(plan['root']);os.chdir(root)
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def running():
 ps=subprocess.check_output(['ps','-axo','comm=,args=']).decode()
 return [x for x in ps.splitlines() if any(y in x.split(' ',1)[0] for y in ['verilator','clang','cc1','g++']) and str(root) in x]
assert not running(),running()
protected=[root/'build/rtl-executive/alto-executive.rtl']
protected += [p for p in (root/'verilog/verilator/obj_executive').rglob('*') if p.is_file() and not p.is_symlink()]
before={str(p.relative_to(root)):digest(p) for p in protected}
(base/'protected-before.json').write_text(json.dumps(before,indent=2))
original_diff=subprocess.check_output(['git','diff','--binary']);(base/'working-tree-before.diff').write_bytes(original_diff)
result={'started':time.time(),'free_before':shutil.disk_usage(root).free,'deleted':[],'compressed':[]}
def save(): (base/'local-result.json').write_text(json.dumps(result,indent=2))
save()
for x in plan['delete_generated']:
 p=root/x['path'];s=p.lstat();assert not p.is_symlink() and s.st_nlink==1 and s.st_size==x['bytes'] and s.st_mtime_ns==x['mtime_ns'],str(p)
 assert p.suffix in ['.o','.a','.pch','.gch'] and p.is_relative_to(root/'build/rtl-executive')
 p.unlink();result['deleted'].append(x)
save();print('DELETED',len(result['deleted']),sum(x['bytes'] for x in result['deleted']),flush=True)
for i,x in enumerate(plan['compress_logs']):
 p=root/x['path'];s=p.stat();assert s.st_size==x['bytes'] and s.st_mtime_ns==x['mtime_ns']
 out=p.with_name(p.name+'.gz');tmp=out.with_name(out.name+'.cleanup-tmp');assert not out.exists() and not tmp.exists()
 h=hashlib.sha256()
 with p.open('rb') as f,tmp.open('xb') as w,gzip.GzipFile(filename=p.name,mode='wb',fileobj=w,compresslevel=1,mtime=int(s.st_mtime)) as z:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);z.write(b)
 check=hashlib.sha256();length=0
 with gzip.open(tmp,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):check.update(b);length+=len(b)
 assert check.digest()==h.digest() and length==s.st_size
 assert p.stat().st_mtime_ns==s.st_mtime_ns and p.stat().st_size==s.st_size
 os.replace(tmp,out);os.utime(out,ns=(s.st_atime_ns,s.st_mtime_ns));p.unlink()
 result['compressed'].append({**x,'gzip':str(out.relative_to(root)),'gzip_bytes':out.stat().st_size,'original_sha256':h.hexdigest(),'readback_verified':True});save()
 if i%5==0:print('COMPRESSED',i+1,'/',len(plan['compress_logs']),flush=True)
assert {str(p.relative_to(root)):digest(p) for p in protected}==before
assert subprocess.check_output(['git','diff','--binary'])==original_diff
result.update(finished=time.time(),free_after=shutil.disk_usage(root).free,status='PASS',protected_files=len(before),working_tree_diff_unchanged=True)
save();print(json.dumps({k:v for k,v in result.items() if k not in ['deleted','compressed']},indent=2),flush=True)
