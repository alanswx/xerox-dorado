module crc9401_fixture(
input wire host_clk,ref_clk,advance,freeze,held,request,write,individual,
input wire [7:0] pins,input wire [1:0] index,input wire [17:0] data,restore_data[2],
output wire [17:0] result[2],output wire [18:0] physical[2],original_state[2],
output wire [1:0] frozen,done,error,output wire [3:0] outputs,original_outputs);
genvar i;generate for(i=0;i<2;i=i+1)begin:cells
cell_F9401_snapshot #(.PRECAP(i)) candidate(.state_host_clk(host_clk),.state_advance(advance),
.state_freeze(freeze),.state_guest_held(held),.state_request(request),.state_write(write),
.state_index(index),.state_data(individual?restore_data[i]:data),.state_frozen(frozen[i]),.state_done(done[i]),.state_error(error[i]),.state_result(result[i]),.sys_clk(ref_clk),.p1(pins[0]),.p2(pins[1]),.p4(pins[2]),.p3(pins[3]),.p5(pins[4]),.p8(pins[5]),.p10(pins[6]),.p11(pins[7]),.p7(1'b0),.p14(1'b1),.p12(outputs[2*i]),.p13(outputs[2*i+1]));
cell_F9401 #(.PRECAP(i)) original(.sys_clk(ref_clk),.p1(pins[0]),.p2(pins[1]),.p4(pins[2]),.p3(pins[3]),.p5(pins[4]),.p8(pins[5]),.p10(pins[6]),.p11(pins[7]),.p7(1'b0),.p14(1'b1),.p12(original_outputs[2*i]),.p13(original_outputs[2*i+1]));
assign physical[i]={candidate.cwe_pre,candidate.d_pre,candidate.cp_d,candidate.r};
assign original_state[i]={original.cwe_pre,original.d_pre,original.cp_d,original.r};
end endgenerate endmodule
