module jk_fixture(
 input wire host_clk,ref_clk,advance,hold,write,restore_individual,
 input wire [8:0] pins,input wire [17:0] data,
 input wire [6:0] restore_data[4],
 output wire [17:0] result[4],output wire [6:0] candidate_state[4],original_state[4],
 output wire [15:0] outputs,original_outputs);
 genvar i;
 generate for(i=0;i<4;i=i+1)begin:cases
 cell_MC10135_snapshot #(.PRECAP_A(i&1),.PRECAP_B((i>>1)&1)) candidate(
 .state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write),
 .state_data(restore_individual?{11'b0,restore_data[i]}:data),.state_result(result[i]),
 .sys_clk(ref_clk),.p7(pins[0]),.p6(pins[1]),.p10(pins[2]),.p11(pins[3]),
 .p4(pins[4]),.p5(pins[5]),.p13(pins[6]),.p12(pins[7]),.p9(pins[8]),
 .p2(outputs[4*i]),.p3(outputs[4*i+1]),.p15(outputs[4*i+2]),.p14(outputs[4*i+3]));
 cell_MC10135 #(.PRECAP_A(i&1),.PRECAP_B((i>>1)&1)) original(
 .sys_clk(ref_clk),.p7(pins[0]),.p6(pins[1]),.p10(pins[2]),.p11(pins[3]),
 .p4(pins[4]),.p5(pins[5]),.p13(pins[6]),.p12(pins[7]),.p9(pins[8]),
 .p2(original_outputs[4*i]),.p3(original_outputs[4*i+1]),.p15(original_outputs[4*i+2]),.p14(original_outputs[4*i+3]));
 assign candidate_state[i]={candidate.ck_d,candidate.jk_pre,candidate.qb,candidate.qa};
 assign original_state[i]={original.ck_d,original.jk_pre,original.qb,original.qa};
 end endgenerate
endmodule
