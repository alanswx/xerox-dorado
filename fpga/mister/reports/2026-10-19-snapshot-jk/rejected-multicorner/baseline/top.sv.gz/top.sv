module snapshot_fit(
 input wire host_clk,advance,hold,write,input wire [8:0] pins,
 input wire [17:0] data,output reg [71:0] result,output reg [15:0] outputs);
 // Same positive-edge launch/capture shell in both variants:20ns embedded
 // paths at50MHz,2ns max/0ns min virtual I/O; not a full-board timing claim.
 reg [29:0] launch;
 always @(posedge host_clk) launch<={advance,hold,write,pins,data};
 wire step_r,hold_r,write_r;wire [8:0] pins_r;wire [17:0] data_r;
 assign {step_r,hold_r,write_r,pins_r,data_r}=launch;
 wire [71:0] result_w;wire [15:0] outputs_w;
 always @(posedge host_clk)begin result<=result_w;outputs<=outputs_w;end
 genvar i;
 generate for(i=0;i<4;i=i+1)begin:cases
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_MC10135_snapshot #(.PRECAP_A(i&1),.PRECAP_B((i>>1)&1)) cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_hold(hold_r),
 .state_write(write_r),.state_data(data_r),.state_result(result_w[18*i+:18]),
`else
 assign result_w[18*i+:18]=18'b0;
 cell_MC10135 #(.PRECAP_A(i&1),.PRECAP_B((i>>1)&1)) cell_inst(
`endif
 .sys_clk(host_clk),.p7(pins_r[0]),.p6(pins_r[1]),.p10(pins_r[2]),.p11(pins_r[3]),
 .p4(pins_r[4]),.p5(pins_r[5]),.p13(pins_r[6]),.p12(pins_r[7]),.p9(pins_r[8]),
 .p2(outputs_w[4*i]),.p3(outputs_w[4*i+1]),.p15(outputs_w[4*i+2]),.p14(outputs_w[4*i+3]));
 end endgenerate
endmodule
