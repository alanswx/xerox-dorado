module f10145_snapshot_fixture(
 input wire host_clk,ref_clk,advance,input wire [3:0] address,data,
 input wire ce_n,we_n,freeze,held,request,write,
 input wire [4:0] index,input wire [9:0] state_data,
 output wire frozen,done,error,output wire [9:0] result,
 output wire [3:0] q,ref_q,output wire [9:0] window,ref_window,
 output wire [63:0] memory,ref_memory);
 cell_F10145A_snapshot candidate(
 .state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),
 .state_guest_held(held),.state_request(request),.state_write(write),
 .state_index(index),.state_data(state_data),.state_frozen(frozen),
 .state_done(done),.state_error(error),.state_result(result),
 .sys_clk(ref_clk),
 .p10(address[3]),.p9(address[2]),.p7(address[1]),.p6(address[0]),
 .p5(data[0]),.p4(data[1]),.p11(data[2]),.p12(data[3]),
 .p3(ce_n),.p13(we_n),.p2(q[0]),.p1(q[1]),.p15(q[2]),.p14(q[3]),.p8(1'b0));
 cell_F10145A original(.sys_clk(ref_clk),
 .p10(address[3]),.p9(address[2]),.p7(address[1]),.p6(address[0]),
 .p5(data[0]),.p4(data[1]),.p11(data[2]),.p12(data[3]),
 .p3(ce_n),.p13(we_n),.p2(ref_q[0]),.p1(ref_q[1]),.p15(ref_q[2]),.p14(ref_q[3]),.p8(1'b0));
 assign window={candidate.ce_lat,candidate.d_lat,candidate.a_lat,candidate.we_d};
 assign ref_window={original.ce_lat,original.d_lat,original.a_lat,original.we_d};
 genvar i;
 generate for(i=0;i<16;i=i+1)begin: observe
  assign memory[i*4+:4]=candidate.mem[i];
  assign ref_memory[i*4+:4]=original.mem[i];
 end endgenerate
endmodule
