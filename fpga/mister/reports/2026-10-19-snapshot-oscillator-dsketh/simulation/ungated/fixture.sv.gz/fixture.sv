module oscillator_fixture(
input wire host_clk,ref_clk,advance,freeze,held,request,write,individual,
input wire [17:0] restore_data[10],
input wire [1:0] index,input wire [17:0] data,
output wire [17:0] result[10],output wire [32:0] physical[10],original_state[10],
output wire [9:0] frozen,done,error,outputs,original_outputs);
genvar i;
generate for(i=0;i<10;i=i+1)begin:cells
localparam integer SP=i==9?8:i/3==0?2:i/3==1?4:16;
localparam integer FREQ=i==9?23530:i%3==0?10000:i%3==1?20000:50000;
cell_K1115A_snapshot #(.FREQ_KHZ(FREQ),.SYSPER(SP)) candidate(
.state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
.state_request(request),.state_write(write),.state_index(index),.state_data(individual?restore_data[i]:data),
.state_frozen(frozen[i]),.state_done(done[i]),.state_error(error[i]),.state_result(result[i]),
.sys_clk(ref_clk),.p8(outputs[i]),.p7(1'b0),.p14(1'b1));
cell_K1115A #(.FREQ_KHZ(FREQ),.SYSPER(SP)) original(
.sys_clk(ref_clk),.p8(original_outputs[i]),.p7(1'b0),.p14(1'b1));
assign physical[i]={candidate.osc,candidate.acc};
assign original_state[i]={original.osc,original.acc};
end endgenerate
endmodule
