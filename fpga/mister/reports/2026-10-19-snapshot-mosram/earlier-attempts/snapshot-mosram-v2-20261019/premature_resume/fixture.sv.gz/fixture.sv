module mosram_fixture(
 input wire host_clk,ref_clk,advance,freeze,held,
 input wire [1:0] request,write,input wire [7:0] address,
 input wire ras_n,cas_n,we_n,data,
 input wire [16:0] state_index[2],input wire [17:0] state_data[2],
 input wire [15:0] probe_address,
 output wire [1:0] frozen,done,error,q,original_q,original_probe,candidate_probe,
 output wire [17:0] result[2],output wire [22:0] original_history[2],candidate_history[2]);
 genvar k;
 generate for(k=0;k<2;k=k+1)begin:banks
  localparam integer A=14+2*k;
  cell_MosRam original(.sys_clk(ref_clk),.p2(data),.p3(we_n),.p4(ras_n),
    .p5(address[1]),.p6(address[3]),.p7(address[2]),.p9(address[7]),
    .p10(address[6]),.p11(address[5]),.p12(address[4]),.p13(address[0]),
    .p15(cas_n),.p14(original_q[k]),.p1(1'b0),.p8(1'b0),.p16(1'b0));
  defparam original.ADDR_BITS=A;
  cell_MosRam_snapshot #(.ADDR_BITS(A)) candidate(.sys_clk(ref_clk),
    .state_host_clk(host_clk),.state_advance(advance),.state_freeze(freeze),
    .state_guest_held(held),.state_request(request[k]),.state_write(write[k]),
    .state_index(state_index[k][A:0]),.state_data(state_data[k]),
    .state_frozen(frozen[k]),.state_done(done[k]),.state_error(error[k]),.state_result(result[k]),
    .p2(data),.p3(we_n),.p4(ras_n),.p5(address[1]),.p6(address[3]),.p7(address[2]),
    .p9(address[7]),.p10(address[6]),.p11(address[5]),.p12(address[4]),.p13(address[0]),
    .p15(cas_n),.p14(q[k]),.p1(1'b0),.p8(1'b0),.p16(1'b0));
  assign original_history[k]={{(16-A){1'b0}},original.write_data,original.write_pending,
    original.we_d,original.dout_r,original.dout,original.cas_d,original.ras_d,original.col,original.row};
  assign candidate_history[k]={{(16-A){1'b0}},candidate.write_data,candidate.write_pending,
    candidate.we_d,candidate.logical_dout_r,candidate.dout,candidate.cas_d,candidate.ras_d,candidate.col,candidate.row};
  assign original_probe[k]=original.mem[probe_address[A-1:0]];
  assign candidate_probe[k]=candidate.mem[probe_address[A-1:0]];
  integer row;
  initial for(row=0;row<(1<<A);row=row+1)begin
    original.mem[row]=((row*32'd1103515245+32'd12345+32'd7919*k) ^ (row>>3) ^ (row>>7) ^ (row>>11) ^ (row>>15)) & 1;
    candidate.mem[row]=((row*32'd1103515245+32'd12345+32'd7919*k) ^ (row>>3) ^ (row>>7) ^ (row>>11) ^ (row>>15)) & 1;
  end
 end endgenerate
endmodule
