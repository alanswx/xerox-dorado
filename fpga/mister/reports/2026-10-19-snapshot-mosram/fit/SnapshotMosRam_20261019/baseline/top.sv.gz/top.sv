module snapshot_fit(
 input wire host_clk,advance,input wire [7:0] address,
 input wire ras_n,cas_n,we_n,data,freeze,held,request,write,
 input wire [16:0] index,input wire [17:0] state_data,
 output reg [1:0] q,frozen,done,error,output reg [35:0] result);
 // Matched negative-edge external staging; positive-edge embedded neighbors.
 reg [51:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,address,ras_n,cas_n,we_n,data,freeze,held,request,write,index,state_data};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,ras_r,cas_r,we_r,data_r,freeze_r,held_r,request_r,write_r;
 wire [7:0] address_r;wire [16:0] index_r;wire [17:0] state_r;
 assign {step_r,address_r,ras_r,cas_r,we_r,data_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire [1:0] bank_q,bank_frozen,bank_done,bank_error;wire [35:0] bank_result;
 always @(posedge host_clk){q,frozen,done,error,result}<={bank_q,bank_frozen,bank_done,bank_error,bank_result};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_MosRam_snapshot #(.ADDR_BITS(14)) bank_14(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r[14:0]),.state_data(state_r),
 .state_frozen(bank_frozen[0]),.state_done(bank_done[0]),.state_error(bank_error[0]),.state_result(bank_result[0+:18]),
`else
 assign {bank_frozen[0],bank_done[0],bank_error[0],bank_result[0+:18]}=21'b0;
 cell_MosRam #(.ADDR_BITS(14)) bank_14(
`endif
 .sys_clk(host_clk),.p2(data_r),.p3(we_r),.p4(ras_r),.p5(address_r[1]),.p6(address_r[3]),.p7(address_r[2]),
 .p9(address_r[7]),.p10(address_r[6]),.p11(address_r[5]),.p12(address_r[4]),.p13(address_r[0]),
 .p15(cas_r),.p14(bank_q[0]),.p1(1'b0),.p8(1'b0),.p16(1'b0));
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_MosRam_snapshot #(.ADDR_BITS(16)) bank_16(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r[16:0]),.state_data(state_r),
 .state_frozen(bank_frozen[1]),.state_done(bank_done[1]),.state_error(bank_error[1]),.state_result(bank_result[18+:18]),
`else
 assign {bank_frozen[1],bank_done[1],bank_error[1],bank_result[18+:18]}=21'b0;
 cell_MosRam #(.ADDR_BITS(16)) bank_16(
`endif
 .sys_clk(host_clk),.p2(data_r),.p3(we_r),.p4(ras_r),.p5(address_r[1]),.p6(address_r[3]),.p7(address_r[2]),
 .p9(address_r[7]),.p10(address_r[6]),.p11(address_r[5]),.p12(address_r[4]),.p13(address_r[0]),
 .p15(cas_r),.p14(bank_q[1]),.p1(1'b0),.p8(1'b0),.p16(1'b0));
endmodule
