`timescale 1ns/1ps
`default_nettype none
module run_control_reference_adapter(input wire base, input wire [7:0] controls,
 input wire fixture_load,input wire [21:0] fixture_state,
 output wire [21:0] state_q,output wire [6:0] clocks,
 output wire [4:0] enables,output wire [2:0] decoded);
 wire [17:0] pins;
 assign pins[0]=base; // CLK.ca'
 assign pins[1]=1'b1; // CPAddr.0'
 assign pins[2]=1'b1; // CPStrb'
 assign pins[3]=1'b0; // ContA28.sil+7
 assign pins[4]=1'b0; // ContA30.sil+1
 assign pins[5]=controls[1]; // Error'
 assign pins[6]=1'b0; // FreezeBD
 assign pins[7]=1'b0; // GetTLink
 assign pins[8]=controls[3]; // Phase0
 assign pins[9]=~controls[3]; // Phase0'
 assign pins[10]=1'b1; // Phase4'
 assign pins[11]=1'b0; // RWTPCorRWIM
 assign pins[12]=controls[6]; // SetRun
 assign pins[13]=controls[4]; // SetRunRfsh
 assign pins[14]=controls[5]; // SetSS'
 assign pins[15]=controls[0]; // StopAtT1
 assign pins[16]=controls[2]; // preStartCyclea
 assign pins[17]=controls[7]; // rStop
 original_run_control graph(fixture_load,fixture_state,pins,state_q,clocks,enables,decoded);
endmodule
`default_nettype wire
