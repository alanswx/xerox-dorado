`timescale 1ns/1ps
`default_nettype none
module original_run_control(input wire fixture_load,
 input wire [21:0] fixture_state,
 input wire [17:0] pins,
 output wire [21:0] state_q, output wire [6:0] clocks,
 output wire [4:0] enables,output wire [2:0] decoded);
 wire n0; // AlwaysSH
 wire n1; // CLK.ca'
 wire n2; // CLKEnable'a
 wire n3; // CLKEnable'b
 wire n4; // CLKEnable'c
 wire n5; // CPAddr.0'
 wire n6; // CPStrb'
 wire n7; // ClearMemStop
 wire n8; // ContA02.sil+1
 wire n9; // ContA27.sil+1
 wire n10; // ContA27.sil+2
 wire n11; // ContA28.sil+7
 wire n12; // ContA30.sil+1
 wire n13; // ContA31.sil+1
 wire n14; // ContA31.sil+2
 wire n15; // ContA31.sil+3
 wire n16; // ContA31.sil+4
 wire n17; // ContA31.sil+5
 wire n18; // Error'
 wire n19; // FreezeBD
 wire n20; // GND264
 wire n21; // GND266
 wire n22; // GND312
 wire n23; // GND394
 wire n24; // GND396
 wire n25; // GND444
 wire n26; // GND530
 wire n27; // GND544
 wire n28; // GetTLink
 wire n29; // GetTLink'
 wire n30; // MemClkEnable'a
 wire n31; // MemClkEnable'b
 wire n32; // Phase0
 wire n33; // Phase0'
 wire n34; // Phase4'
 wire n35; // RWTPCorRWIM
 wire n36; // Run'
 wire n37; // RunClk'a
 wire n38; // RunClk'b
 wire n39; // RunRefresh
 wire n40; // RunRefresh'
 wire n41; // SCorFreezea
 wire n42; // SCorFreezeb
 wire n43; // SetRun
 wire n44; // SetRun'
 wire n45; // SetRunRfsh
 wire n46; // SetSS'
 wire n47; // Stop
 wire n48; // StopAtT1
 wire n49; // StopAtT1'
 wire n50; // StopRunClock
 wire n51; // TPCIclk'a
 wire n52; // TPCIclk'b
 wire n53; // TPCIclk'c
 wire n54; // TrueAC
 wire n55; // TrueBD
 wire n56; // UseDMD
 wire n57; // WantRunRfsh
 wire n58; // bCLKEnable'a
 wire n59; // bCLKEnable'b
 wire n60; // bCLKEnable'c
 wire n61; // bCLKEnable'd
 wire n62; // bCLKEnable'e
 wire n63; // bCLKEnable'f
 wire n64; // bpreStartC'a
 wire n65; // bpreStartC'b
 wire n66; // bpreStartC'c
 wire n67; // clk2'Ba
 wire n68; // clk2'Bb
 wire n69; // clk2'Bc
 wire n70; // dMemRun
 wire n71; // dRun
 wire n72; // dStartCycle
 wire n73; // dStop
 wire n74; // preCRamClock
 wire n75; // preFH'
 wire n76; // preRunClk'Ba
 wire n77; // preRunClk'Bb
 wire n78; // preRunClk'Bc
 wire n79; // preStartCyclea
 wire n80; // preclk1'Aa
 wire n81; // preclk1'Ca
 wire n82; // preclk1'Da
 wire n83; // preclk2'Aa
 wire n84; // preclk2'Ba
 wire n85; // preclk2'Bb
 wire n86; // preclk2'Bc
 wire n87; // preclk2'Bd
 wire n88; // preclk2'Ca
 wire n89; // preclk2'Da
 wire n90; // prepreclk'a
 wire n91; // prepreclk'b
 wire n92; // prepreclk'c
 wire n93; // prepreclk'd
 wire n94; // prepreclk'e
 wire n95; // rStop
 wire n96; // sPhase0
 assign n20=1'b0;
 assign n21=1'b0;
 assign n22=1'b0;
 assign n23=1'b0;
 assign n24=1'b0;
 assign n25=1'b0;
 assign n26=1'b0;
 assign n27=1'b0;
 assign n1=pins[0];
 assign n5=pins[1];
 assign n6=pins[2];
 assign n11=pins[3];
 assign n12=pins[4];
 assign n18=pins[5];
 assign n19=pins[6];
 assign n28=pins[7];
 assign n32=pins[8];
 assign n33=pins[9];
 assign n34=pins[10];
 assign n35=pins[11];
 assign n43=pins[12];
 assign n45=pins[13];
 assign n46=pins[14];
 assign n48=pins[15];
 assign n79=pins[16];
 assign n95=pins[17];
 wire n0_l05_3;
 assign n0=n0_l05_3;
 wire n2_k02_15;
 wire n2_k01_14;
 assign n2=n2_k02_15 | n2_k01_14;
 wire n3_k02_2;
 wire n3_k01_3;
 assign n3=n3_k02_2 | n3_k01_3;
 wire n4_l02_14;
 wire n4_l02_2;
 assign n4=n4_l02_14 | n4_l02_2;
 wire n7_h03_3;
 assign n7=n7_h03_3;
 wire n8_h03_14;
 assign n8=n8_h03_14;
 wire n9_j05_2;
 assign n9=n9_j05_2;
 wire n10_i04_3;
 assign n10=n10_i04_3;
 wire n13_i03_14;
 assign n13=n13_i03_14;
 wire n14_i03_13;
 assign n14=n14_i03_13;
 wire n15_i03_2;
 assign n15=n15_i03_2;
 wire n16_i03_3;
 assign n16=n16_i03_3;
 wire n17_i03_4;
 assign n17=n17_i03_4;
 wire n29_g05_15;
 assign n29=n29_g05_15;
 wire n30_l04_15;
 wire n30_l03_14;
 assign n30=n30_l04_15 | n30_l03_14;
 wire n31_l04_2;
 wire n31_l03_3;
 assign n31=n31_l04_2 | n31_l03_3;
 wire n36_j04_14;
 assign n36=n36_j04_14;
 wire n37_i06_3;
 assign n37=n37_i06_3;
 wire n38_i06_2;
 assign n38=n38_i06_2;
 wire n39_l06_15;
 assign n39=n39_l06_15;
 wire n40_l06_14;
 assign n40=n40_l06_14;
 wire n41_i06_13;
 assign n41=n41_i06_13;
 wire n42_i06_12;
 assign n42=n42_i06_12;
 wire n44_g05_3;
 assign n44=n44_g05_3;
 wire n47_j04_2;
 assign n47=n47_j04_2;
 wire n49_g05_2;
 assign n49=n49_g05_2;
 wire n50_l05_2;
 assign n50=n50_l05_2;
 wire n51_j06_13;
 assign n51=n51_j06_13;
 wire n52_j06_12;
 assign n52=n52_j06_12;
 wire n53_j06_14;
 assign n53=n53_j06_14;
 wire n54_g05_13;
 assign n54=n54_g05_13;
 wire n55_g05_4;
 assign n55=n55_g05_4;
 wire n56_i04_15;
 assign n56=n56_i04_15;
 wire n57_l05_15;
 assign n57=n57_l05_15;
 wire n58_i05_3;
 assign n58=n58_i05_3;
 wire n59_i05_2;
 assign n59=n59_i05_2;
 wire n60_i05_4;
 assign n60=n60_i05_4;
 wire n61_i05_13;
 assign n61=n61_i05_13;
 wire n62_i05_12;
 assign n62=n62_i05_12;
 wire n63_i05_14;
 assign n63=n63_i05_14;
 wire n64_l08_3;
 assign n64=n64_l08_3;
 wire n65_l08_4;
 assign n65=n65_l08_4;
 wire n66_l08_2;
 assign n66=n66_l08_2;
 wire n67_j06_3;
 assign n67=n67_j06_3;
 wire n68_j06_2;
 assign n68=n68_j06_2;
 wire n69_j06_4;
 assign n69=n69_j06_4;
 wire n70_g04_15;
 wire n70_h03_2;
 assign n70=n70_g04_15 | n70_h03_2;
 wire n71_i03_15;
 assign n71=n71_i03_15;
 wire n72_j05_3;
 assign n72=n72_j05_3;
 wire n73_i04_2;
 wire n73_j05_14;
 assign n73=n73_i04_2 | n73_j05_14;
 wire n74_g12_4;
 assign n74=n74_g12_4;
 wire n75_l06_3;
 assign n75=n75_l06_3;
 wire n76_f13_13;
 assign n76=n76_f13_13;
 wire n77_f13_12;
 assign n77=n77_f13_12;
 wire n78_f13_14;
 assign n78=n78_f13_14;
 wire n80_f13_3;
 assign n80=n80_f13_3;
 wire n81_f13_2;
 assign n81=n81_f13_2;
 wire n82_f13_4;
 assign n82=n82_f13_4;
 wire n83_f12_3;
 assign n83=n83_f12_3;
 wire n84_f12_13;
 assign n84=n84_f12_13;
 wire n85_f12_12;
 assign n85=n85_f12_12;
 wire n86_f12_14;
 assign n86=n86_f12_14;
 wire n87_g12_14;
 assign n87=n87_g12_14;
 wire n88_f12_2;
 assign n88=n88_f12_2;
 wire n89_f12_4;
 assign n89=n89_f12_4;
 wire n90_l01_13;
 assign n90=n90_l01_13;
 wire n91_l01_12;
 assign n91=n91_l01_12;
 wire n92_l01_14;
 assign n92=n92_l01_14;
 wire n93_l01_3;
 assign n93=n93_l01_3;
 wire n94_l01_2;
 assign n94=n94_l01_2;
 wire n96_i04_14;
 assign n96=n96_i04_14;
 cell_SE10210 f12 (.p2(n88_f12_2),.p3(n83_f12_3),.p4(n89_f12_4),.p5(n92),.p6(1'b0),.p7(n60),.p8(1'b0),.p9(n60),.p10(1'b0),.p11(n92),.p12(n85_f12_12),.p13(n84_f12_13),.p14(n86_f12_14),.p15(n20),.p16(1'b0));
 cell_SE10210 f13 (.p2(n81_f13_2),.p3(n80_f13_3),.p4(n82_f13_4),.p5(n75),.p6(n90),.p7(n58),.p8(1'b0),.p9(1'b0),.p10(n50),.p11(n90),.p12(n77_f13_12),.p13(n76_f13_13),.p14(n78_f13_14),.p15(n21),.p16(1'b0));
 cell_MC10104 g04 (.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(n57),.p13(n40),.p15(n70_g04_15),.p16(1'b0));
 cell_MC10195 g05 (.p2(n49_g05_2),.p3(n44_g05_3),.p4(n55_g05_4),.p5(n48),.p6(n43),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p12(n28),.p13(n54_g05_13),.p15(n29_g05_15));
 cell_SE10212 g12 (.p1(1'b0),.p4(n74_g12_4),.p5(n63),.p6(1'b0),.p7(n94),.p8(1'b0),.p9(n94),.p10(1'b0),.p11(n63),.p14(n87_g12_14),.p15(n22),.p16(1'b0));
 cell_MC10103 h03 (.p1(1'b0),.p2(n70_h03_2),.p3(n7_h03_3),.p4(n71),.p5(1'b0),.p6(n95),.p7(n39),.p10(n5),.p11(n6),.p12(1'b0),.p13(1'b0),.p14(n8_h03_14),.p16(1'b0));
 original_MC10176 i03 (.p1(1'b0),.p2(n15_i03_2),.p3(n16_i03_3),.p4(n17_i03_4),.p5(n46),.p6(n15),.p7(n16),.p8(1'b0),.p9(n38),.p10(n43),.p11(n14),.p12(n13),.p13(n14_i03_13),.p14(n13_i03_14),.p15(n71_i03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 cell_MC10104 i04 (.p2(n73_i04_2),.p3(n10_i04_3),.p4(n32),.p5(n48),.p6(n9),.p7(n32),.p10(n49),.p11(n62),.p12(n11),.p13(n43),.p14(n96_i04_14),.p15(n56_i04_15),.p16(1'b0));
 cell_MC10210 i05 (.p1(1'b0),.p2(n59_i05_2),.p3(n58_i05_3),.p4(n60_i05_4),.p5(n47),.p6(n36),.p7(1'b0),.p8(1'b0),.p9(n36),.p10(1'b0),.p11(n47),.p12(n62_i05_12),.p13(n61_i05_13),.p14(n63_i05_14),.p15(n23),.p16(1'b0));
 cell_SE10210 i06 (.p2(n38_i06_2),.p3(n37_i06_3),.p5(1'b0),.p6(1'b0),.p7(n76),.p8(1'b0),.p9(1'b0),.p10(n19),.p11(n79),.p12(n42_i06_12),.p13(n41_i06_13),.p15(n24),.p16(1'b0));
 original_MC10231 j04 (.p1(1'b0),.p2(n47_j04_2),.p4(n95),.p5(1'b0),.p6(n69),.p7(n73),.p8(1'b0),.p9(1'b0),.p10(n71),.p11(n37),.p12(1'b0),.p13(1'b0),.p14(n36_j04_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:2]),.state_q(state_q[6+:2]));
 cell_MC10117 j05 (.p2(n9_j05_2),.p3(n72_j05_3),.p4(n35),.p5(n33),.p6(1'b0),.p7(n34),.p9(1'b0),.p10(n65),.p11(n17),.p12(n65),.p13(n18),.p14(n73_j05_14));
 cell_SE10210 j06 (.p2(n68_j06_2),.p3(n67_j06_3),.p4(n69_j06_4),.p5(1'b0),.p6(n84),.p7(1'b0),.p8(1'b0),.p9(n84),.p10(1'b0),.p11(n12),.p12(n52_j06_12),.p13(n51_j06_13),.p14(n53_j06_14),.p15(n25),.p16(1'b0));
 original_MC10231 k01 (.p1(1'b0),.p3(n3_k01_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n71),.p8(1'b0),.p9(n77),.p10(n71),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n2_k01_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:2]),.state_q(state_q[8+:2]));
 original_MC10231 k02 (.p1(1'b0),.p2(n3_k02_2),.p4(n95),.p5(1'b0),.p6(1'b0),.p7(n73),.p8(1'b0),.p9(n85),.p10(n73),.p11(1'b0),.p12(1'b0),.p13(n95),.p15(n2_k02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[10+:2]),.state_q(state_q[10+:2]));
 cell_SE10210 l01 (.p2(n94_l01_2),.p3(n93_l01_3),.p5(1'b0),.p6(1'b0),.p7(n1),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n1),.p12(n91_l01_12),.p13(n90_l01_13),.p14(n92_l01_14),.p15(n26),.p16(1'b0));
 original_MC10231 l02 (.p1(1'b0),.p2(n4_l02_2),.p4(n95),.p5(1'b0),.p6(n86),.p7(n73),.p8(1'b0),.p9(1'b0),.p10(n71),.p11(n78),.p12(1'b0),.p13(1'b0),.p14(n4_l02_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:2]),.state_q(state_q[12+:2]));
 original_MC10231 l03 (.p1(1'b0),.p3(n31_l03_3),.p4(1'b0),.p5(n39),.p6(1'b0),.p7(n70),.p8(1'b0),.p9(n78),.p10(n70),.p11(1'b0),.p12(n39),.p13(1'b0),.p14(n30_l03_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[14+:2]),.state_q(state_q[14+:2]));
 original_MC10231 l04 (.p1(1'b0),.p2(n31_l04_2),.p4(n7),.p5(1'b0),.p6(1'b0),.p7(n73),.p8(1'b0),.p9(n85),.p10(n73),.p11(1'b0),.p12(1'b0),.p13(n7),.p15(n30_l04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:2]),.state_q(state_q[16+:2]));
 original_MC10231 l05 (.p1(1'b0),.p2(n50_l05_2),.p3(n0_l05_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n0),.p8(1'b0),.p9(n93),.p10(n45),.p11(n50),.p12(1'b0),.p13(1'b0),.p15(n57_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[18+:2]),.state_q(state_q[18+:2]));
 original_SE10231 l06 (.p3(n75_l06_3),.p6(n61),.p7(n79),.p9(n93),.p10(n57),.p11(n50),.p13(1'b0),.p14(n40_l06_14),.p15(n39_l06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:2]),.state_q(state_q[20+:2]));
 cell_MC10211 l08 (.p2(n66_l08_2),.p3(n64_l08_3),.p4(n65_l08_4),.p5(1'b0),.p6(n79),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n27),.p16(1'b0));
 assign clocks[0]=n93;
 assign clocks[1]=n50;
 assign clocks[2]=n78;
 assign clocks[3]=n37;
 assign clocks[4]=n85;
 assign clocks[5]=n69;
 assign clocks[6]=n93 | n61;
 assign enables[0]=n2;
 assign enables[1]=n3;
 assign enables[2]=n4;
 assign enables[3]=n30;
 assign enables[4]=n31;
 assign decoded[0]=n73;
 assign decoded[1]=n70;
 assign decoded[2]=n7;
endmodule
`default_nettype wire
