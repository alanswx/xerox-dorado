from pathlib import Path
import hashlib,json,subprocess,sys
qualified,prepared,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
out.mkdir(parents=True,exist_ok=False)
timed=qualified/'balanced/timed-reference'
files=[prepared/'dorado_r_front_cone.sv',qualified/'executed-inputs/verilog/verilator/tb_r_front_cone.sv',*sorted(timed.glob('*.sv')),*sorted(timed.glob('*.v'))]
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
actions=[]
def run(cmd,log):
 with log.open('w') as stream:code=subprocess.run(list(map(str,cmd)),stdout=stream,stderr=subprocess.STDOUT).returncode
 actions.append(dict(command=list(map(str,cmd)),returncode=code,log=str(log)))
 assert code==0,log
run(['iverilog','-g2012','-s','tb_r_front_cone','-o',out/'test.vvp',*files],out/'compile.log')
run(['vvp',out/'test.vvp'],out/'test.log')
run(['verilator','--binary','--timing','--top-module','tb_r_front_cone','-Wno-fatal','-Wno-PINMISSING','-Wno-TIMESCALEMOD','-Wno-MULTIDRIVEN','--Mdir',out/'obj','-o','test',*files],out/'verilator-compile.log')
run([out/'obj/test'],out/'verilator-test.log')
expected='R_FRONT_CONE PASS checks=4352 raw_function_cases=4096 sampled_Q_cases=256'
for name in ('test.log','verilator-test.log'):assert expected in (out/name).read_text()
for p,digest in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
(out/'results.json').write_text(json.dumps(dict(status='PASS_EXPLICIT_GENERATE_CONE',inputs=hashes,actions=actions,summary=expected,native_qualified=False),indent=2)+'\n')
print('PASS_EXPLICIT_GENERATE_CONE',expected)
