from pathlib import Path
import subprocess,sys
root=Path.cwd();prior=root/'build/rtl-executive/r-front-dev-v2-20261020';out=root/'build/rtl-executive'/sys.argv[1];out.mkdir()
timed=prior/'balanced/timed-reference'
rtl=[root/'verilog/rtl'/n for n in ('dorado_r_front_step.sv','dorado_r_memory_step.sv','dorado_r_address_step.sv','dorado_r_file_ports.sv','dorado_r_port_preview.sv','dorado_processor_capture_step.sv','dorado_r_flags_step.sv','dorado_r_operand_step.sv','dorado_t_parity_step.sv','dorado_t_file_step.sv','dorado_task_capture_step.sv')]
with (out/'compile.log').open('w') as log:
 result=subprocess.run(list(map(str,['iverilog','-g2012','-s','tb_r_front_step','-o',out/'test.vvp',*rtl,root/'verilog/verilator/tb_r_front_step.sv',prior/'dorado_r_front_cone.sv',*sorted(timed.glob('*.sv')),*sorted(timed.glob('*.v'))])),stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
with (out/'test.log').open('w') as log:
 result=subprocess.run(['vvp',str(out/'test.vvp'),'+iterations=0'],stdout=log,stderr=subprocess.STDOUT)
print('R_FRONT_DIRECTED_DEV returncode',result.returncode);print((out/'test.log').read_text()[-5000:])
