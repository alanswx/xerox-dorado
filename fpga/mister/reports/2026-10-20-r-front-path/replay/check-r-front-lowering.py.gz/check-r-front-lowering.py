from pathlib import Path
import hashlib,json,re,subprocess,sys
qualified,prepared,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
out.mkdir(parents=True,exist_ok=False)
raw=(qualified/'dorado_r_front_cone.sv').read_text()
names=re.findall(r'^module (\w+)',raw,re.M)
assert len(names)==len(set(names))
raw=re.sub(r'\b(?:'+'|'.join(map(re.escape,names))+r')\b',lambda m:'original_form_'+m[0],raw)
(out/'hierarchical-cone.sv').write_text(raw)
bench=Path('verilog/verilator/tb_r_front_cone_lowering.sv').resolve()
(out/bench.name).write_bytes(bench.read_bytes())
files=[out/'hierarchical-cone.sv',prepared/'dorado_r_front_cone.sv',out/bench.name]
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
actions=[]
def run(cmd,log):
 with log.open('w') as stream:code=subprocess.run(list(map(str,cmd)),stdout=stream,stderr=subprocess.STDOUT).returncode
 actions.append(dict(command=list(map(str,cmd)),returncode=code,log=str(log)))
 assert code==0,log
run(['iverilog','-g2012','-s','tb_r_front_cone_lowering','-o',out/'test.vvp',*files],out/'compile.log')
run(['vvp',out/'test.vvp'],out/'test.log')
run(['verilator','--binary','--timing','--top-module','tb_r_front_cone_lowering','-Wno-fatal','-Wno-PINMISSING','-Wno-TIMESCALEMOD','-Wno-MULTIDRIVEN','--Mdir',out/'obj','-o','test',*files],out/'verilator-compile.log')
run([out/'obj/test'],out/'verilator-test.log')
expected=re.search(r'^R_FRONT_LOWERING PASS ([^\n]+)$',(out/'test.log').read_text(),re.M)[1]
assert re.search(r'^R_FRONT_LOWERING PASS ([^\n]+)$',(out/'verilator-test.log').read_text(),re.M)[1]==expected
for p,digest in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
(out/'results.json').write_text(json.dumps(dict(status='PASS_R_FRONT_SYNTHESIS_LOWERING',inputs=hashes,actions=actions,summary=expected,native_qualified=False),indent=2)+'\n')
print('PASS_R_FRONT_SYNTHESIS_LOWERING',expected)
