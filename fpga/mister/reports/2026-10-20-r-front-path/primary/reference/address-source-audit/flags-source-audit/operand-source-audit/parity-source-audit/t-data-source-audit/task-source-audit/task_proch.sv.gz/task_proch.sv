`timescale 1ns/1ps
`default_nettype none
module task_proch(input wire fixture_load,input wire [19:0] fixture_state,
 input wire base,start_a,en,input wire [75:0] pins,input wire [3:0] next_raw,input wire priority_n,
 output wire [19:0] state_q,output wire [5:0] clocks,
 output wire [2:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.1a
 wire n9; // BSel.2'a
 wire n10; // BSel.2a
 wire n11; // BSel=2/6
 wire n12; // B_Ext
 wire n13; // B_Ext'
 wire n14; // CLK.ph'
 wire n15; // CLKEnable'c
 wire n16; // Clock0'Da
 wire n17; // Clock0'Dc
 wire n18; // Clock0'Dd
 wire n19; // Clock0En'
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Cd
 wire n23; // Clock1'Da
 wire n24; // Clock1'Dc
 wire n25; // Curr.0'
 wire n26; // Curr.1'
 wire n27; // Curr.2'
 wire n28; // Curr.3'
 wire n29; // Curr=Next'
 wire n30; // CurrLast.0'
 wire n31; // CurrLast.1'
 wire n32; // CurrLast.2'
 wire n33; // CurrLast.3'
 wire n34; // DblClock'Da
 wire n35; // FA=0'b
 wire n36; // FA=1'a
 wire n37; // FA=3'
 wire n38; // FB=3'
 wire n39; // FB=7'
 wire n40; // FC=5'
 wire n41; // FC=6'
 wire n42; // FC=7'
 wire n43; // FF.2'a
 wire n44; // FF.2a
 wire n45; // FF.3'a
 wire n46; // GND132
 wire n47; // GND264
 wire n48; // GND266
 wire n49; // GND312
 wire n50; // GND314
 wire n51; // GND40
 wire n52; // GND420
 wire n53; // GND468
 wire n54; // GND530
 wire n55; // Hold
 wire n56; // Hold'
 wire n57; // Holda
 wire n58; // IOB.Perr'
 wire n59; // IOBout
 wire n60; // LC.0
 wire n61; // LC.1
 wire n62; // LC.1'a
 wire n63; // LC.1a
 wire n64; // LC.2
 wire n65; // Last.0'
 wire n66; // Last.1'
 wire n67; // Last.2'
 wire n68; // Last.3'
 wire n69; // Last=Curr'
 wire n70; // LastNext.0'
 wire n71; // LastNext.1'
 wire n72; // LastNext.2'
 wire n73; // LastNext.3'
 wire n74; // Next.0
 wire n75; // Next.0'
 wire n76; // Next.1
 wire n77; // Next.1'
 wire n78; // Next.2
 wire n79; // Next.2'
 wire n80; // Next.3
 wire n81; // Next.3'
 wire n82; // PRhold
 wire n83; // PreClock0'A
 wire n84; // PreClock0'B
 wire n85; // PreClock0'C
 wire n86; // PreClock0'D
 wire n87; // PreClock1'A
 wire n88; // PreClock1'B
 wire n89; // PreClock1'C
 wire n90; // PreClock1'D
 wire n91; // PreClock1B
 wire n92; // PreDblClock'D
 wire n93; // PreSHCP'A
 wire n94; // PreSHCP'B
 wire n95; // PreSHCP'C
 wire n96; // PreSHCP'Shc
 wire n97; // PreSHSelect'D
 wire n98; // ProcH11.sil+1
 wire n99; // ProcH12.sil+1
 wire n100; // ProcH12.sil+2
 wire n101; // ProcH12.sil+3
 wire n102; // ProcH12.sil+4
 wire n103; // ProcH12.sil+5
 wire n104; // ProcH15.sil+1
 wire n105; // ProcH20.sil+1
 wire n106; // ProcH20.sil+2
 wire n107; // ProcH20.sil+3
 wire n108; // ProcH20.sil+4
 wire n109; // ProcH20.sil+5
 wire n110; // ProcH24.sil+1
 wire n111; // ProcH24.sil+2
 wire n112; // ProcH26.sil+1
 wire n113; // ProcH26.sil+3
 wire n114; // ProcH27.sil+12
 wire n115; // ProcH30.sil+1
 wire n116; // RbSelMd
 wire n117; // RbSelMd'
 wire n118; // RbWriteEn'
 wire n119; // RepeatCurrB
 wire n120; // RepeatCurrC
 wire n121; // RepeatCurrD
 wire n122; // SHCP'C
 wire n123; // StartCycle'a
 wire n124; // TIOAWrite'
 wire n125; // TIOAWriteEn'
 wire n126; // TbSelMd
 wire n127; // TbWriteEn'
 wire n128; // TrueA
 wire n129; // pClock1En'
 wire n130; // ppClk'a
 wire n131; // ppClk'b
 wire n132; // ppClk'c
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n49=1'b0;
 assign n50=1'b0;
 assign n51=1'b0;
 assign n52=1'b0;
 assign n53=1'b0;
 assign n54=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n14=base;
 assign n15=en;
 assign n35=(pins[19:18]!=2'd0);
 assign n36=(pins[19:18]!=2'd1);
 assign n37=(pins[19:18]!=2'd3);
 assign n38=(pins[17:15]!=3'd3);
 assign n39=(pins[17:15]!=3'd7);
 assign n40=(pins[14:12]!=3'd5);
 assign n41=(pins[14:12]!=3'd6);
 assign n42=(pins[14:12]!=3'd7);
 assign n43=~pins[17];
 assign n44=pins[17];
 assign n45=~pins[16];
 assign n57=pins[68];
 assign n59=1'b0;
 assign n60=pins[11];
 assign n61=pins[10];
 assign n64=pins[9];
 assign n74=next_raw[0];
 assign n76=next_raw[1];
 assign n78=next_raw[2];
 assign n80=next_raw[3];
 assign n82=pins[68];
 assign n113=1'b0;
 assign n114=1'b0;
 assign n123=start_a;
 assign n125=1'b1;
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_3;
 assign n8=n8_h24_3;
 wire n9_h24_11;
 assign n9=n9_h24_11;
 wire n10_h24_14;
 assign n10=n10_h24_14;
 wire n11_f18_15;
 assign n11=n11_f18_15;
 wire n12_f19_3;
 assign n12=n12_f19_3;
 wire n13_f19_2;
 assign n13=n13_f19_2;
 wire n16_i18_3;
 assign n16=n16_i18_3;
 wire n17_i18_2;
 assign n17=n17_i18_2;
 wire n18_i18_4;
 assign n18=n18_i18_4;
 wire n19_l01_4;
 assign n19=n19_l01_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_c18_4;
 assign n22=n22_c18_4;
 wire n23_i18_13;
 assign n23=n23_i18_13;
 wire n24_i18_12;
 assign n24=n24_i18_12;
 wire n25_a21_14;
 assign n25=n25_a21_14;
 wire n26_a21_15;
 assign n26=n26_a21_15;
 wire n27_a21_2;
 assign n27=n27_a21_2;
 wire n28_a21_3;
 assign n28=n28_a21_3;
 wire n29_a22_3;
 wire n29_a22_2;
 wire n29_a22_15;
 wire n29_a22_14;
 assign n29=n29_a22_3 | n29_a22_2 | n29_a22_15 | n29_a22_14;
 wire n30_i12_14;
 assign n30=n30_i12_14;
 wire n31_i12_15;
 assign n31=n31_i12_15;
 wire n32_i12_2;
 assign n32=n32_i12_2;
 wire n33_i12_3;
 assign n33=n33_i12_3;
 wire n34_j18_2;
 assign n34=n34_j18_2;
 wire n55_f19_15;
 assign n55=n55_f19_15;
 wire n56_f19_14;
 assign n56=n56_f19_14;
 wire n58_h23_15;
 assign n58=n58_h23_15;
 wire n62_h24_15;
 assign n62=n62_h24_15;
 wire n63_h24_9;
 assign n63=n63_h24_9;
 wire n65_a20_14;
 assign n65=n65_a20_14;
 wire n66_a20_15;
 assign n66=n66_a20_15;
 wire n67_a20_2;
 assign n67=n67_a20_2;
 wire n68_a20_3;
 assign n68=n68_a20_3;
 wire n69_h22_15;
 assign n69=n69_h22_15;
 wire n70_a19_1;
 assign n70=n70_a19_1;
 wire n71_a19_2;
 assign n71=n71_a19_2;
 wire n72_a19_15;
 assign n72=n72_a19_15;
 wire n73_a19_14;
 assign n73=n73_a19_14;
 wire n75_a24_15;
 assign n75=n75_a24_15;
 wire n77_a24_14;
 assign n77=n77_a24_14;
 wire n79_a24_3;
 assign n79=n79_a24_3;
 wire n81_a24_2;
 assign n81=n81_a24_2;
 wire n83_f13_13;
 assign n83=n83_f13_13;
 wire n84_f13_12;
 assign n84=n84_f13_12;
 wire n85_f13_14;
 assign n85=n85_f13_14;
 wire n86_g13_3;
 assign n86=n86_g13_3;
 wire n87_f12_14;
 assign n87=n87_f12_14;
 wire n88_f13_2;
 assign n88=n88_f13_2;
 wire n89_f13_4;
 assign n89=n89_f13_4;
 wire n90_f13_3;
 assign n90=n90_f13_3;
 wire n91_f12_13;
 assign n91=n91_f12_13;
 wire n92_g13_13;
 assign n92=n92_g13_13;
 wire n93_g12_3;
 assign n93=n93_g12_3;
 wire n94_g12_2;
 assign n94=n94_g12_2;
 wire n95_g12_4;
 assign n95=n95_g12_4;
 wire n96_f12_4;
 assign n96=n96_f12_4;
 wire n97_f12_3;
 assign n97=n97_f12_3;
 wire n98_f20_2;
 assign n98=n98_f20_2;
 wire n99_a24_9;
 wire n99_a24_11;
 wire n99_a24_6;
 wire n99_a24_5;
 assign n99=n99_a24_9 | n99_a24_11 | n99_a24_6 | n99_a24_5;
 wire n100_a18_2;
 assign n100=n100_a18_2;
 wire n101_a18_1;
 assign n101=n101_a18_1;
 wire n102_a18_15;
 assign n102=n102_a18_15;
 wire n103_a18_14;
 assign n103=n103_a18_14;
 wire n104_f20_14;
 assign n104=n104_f20_14;
 wire n105_f20_15;
 wire n105_f18_3;
 assign n105=n105_f20_15 | n105_f18_3;
 wire n106_h23_2;
 assign n106=n106_h23_2;
 wire n107_h23_3;
 assign n107=n107_h23_3;
 wire n108_h23_14;
 assign n108=n108_h23_14;
 wire n109_f18_2;
 assign n109=n109_f18_2;
 wire n110_f18_14;
 assign n110=n110_f18_14;
 wire n111_f20_3;
 assign n111=n111_f20_3;
 wire n112_a01_3;
 assign n112=n112_a01_3;
 wire n115_f12_2;
 assign n115=n115_f12_2;
 wire n116_h22_2;
 assign n116=n116_h22_2;
 wire n117_h22_3;
 assign n117=n117_h22_3;
 wire n118_h22_13;
 assign n118=n118_h22_13;
 wire n119_g12_13;
 assign n119=n119_g12_13;
 wire n120_g12_12;
 assign n120=n120_g12_12;
 wire n121_g12_14;
 assign n121=n121_g12_14;
 wire n122_c18_12;
 assign n122=n122_c18_12;
 wire n124_j18_12;
 assign n124=n124_j18_12;
 wire n126_h22_4;
 assign n126=n126_h22_4;
 wire n127_h22_14;
 assign n127=n127_h22_14;
 wire n128_a01_14;
 assign n128=n128_a01_14;
 wire n129_l02_2;
 assign n129=n129_l02_2;
 wire n130_l01_13;
 assign n130=n130_l01_13;
 wire n131_l01_12;
 assign n131=n131_l01_12;
 wire n132_l01_14;
 assign n132=n132_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n112_a01_3),.p4(n1),.p5(1'b0),.p6(n113),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n128_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n101_a18_1),.p2(n100_a18_2),.p3(n71),.p4(n26),.p5(n70),.p6(n25),.p9(n120),.p10(n73),.p11(n28),.p12(n72),.p13(n27),.p14(n103_a18_14),.p15(n102_a18_15));
 cell_MC10158 a19(.p1(n70_a19_1),.p2(n71_a19_2),.p3(n77),.p4(n66),.p5(n75),.p6(n65),.p9(n95),.p10(n81),.p11(n68),.p12(n79),.p13(n67),.p14(n73_a19_14),.p15(n72_a19_15));
 original_MC10141 a20(.p1(n51),.p2(n67_a20_2),.p3(n68_a20_3),.p4(n20),.p5(1'b0),.p6(n28),.p7(1'b0),.p8(1'b0),.p9(n27),.p10(1'b0),.p11(n26),.p12(n25),.p13(1'b0),.p14(n65_a20_14),.p15(n66_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n27_a21_2),.p3(n28_a21_3),.p4(n122),.p5(1'b0),.p6(n81),.p7(n120),.p8(1'b0),.p9(n79),.p10(n120),.p11(n77),.p12(n75),.p13(1'b0),.p14(n25_a21_14),.p15(n26_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n29_a22_2),.p3(n29_a22_3),.p4(n28),.p5(n81),.p6(n79),.p7(n27),.p9(1'b0),.p10(n77),.p11(n26),.p12(n75),.p13(n25),.p14(n29_a22_14),.p15(n29_a22_15));
 cell_MC10101 a24(.p2(n81_a24_2),.p3(n79_a24_3),.p4(n80),.p5(n99_a24_5),.p6(n99_a24_6),.p7(n78),.p9(n99_a24_9),.p10(n76),.p11(n99_a24_11),.p12(1'b0),.p13(n74),.p14(n77_a24_14),.p15(n75_a24_15));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p4(n22_c18_4),.p5(n89),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n95),.p10(1'b0),.p11(1'b0),.p12(n122_c18_12),.p15(n46),.p16(1'b0));
 cell_SE10212 f12(.p1(1'b0),.p2(n115_f12_2),.p3(n97_f12_3),.p4(n96_f12_4),.p5(n129),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n115),.p10(1'b0),.p11(n130),.p13(n91_f12_13),.p14(n87_f12_14),.p15(n47),.p16(1'b0));
 cell_SE10210 f13(.p2(n88_f13_2),.p3(n90_f13_3),.p4(n89_f13_4),.p5(n131),.p6(1'b0),.p7(n115),.p8(1'b0),.p9(n131),.p10(n19),.p11(1'b0),.p12(n84_f13_12),.p13(n83_f13_13),.p14(n85_f13_14),.p15(n48),.p16(1'b0));
 cell_MC10102 f18(.p1(1'b0),.p2(n109_f18_2),.p3(n105_f18_3),.p4(n64),.p5(n107),.p6(n60),.p7(n62),.p10(n44),.p11(n37),.p12(n10),.p13(n7),.p14(n110_f18_14),.p15(n11_f18_15),.p16(1'b0));
 cell_MC1660 f19(.p2(n13_f19_2),.p3(n12_f19_3),.p4(1'b0),.p5(n36),.p6(n45),.p7(n43),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n82),.p14(n56_f19_14),.p15(n55_f19_15));
 cell_MC10100 f20(.p2(n98_f20_2),.p3(n111_f20_3),.p4(n41),.p5(n39),.p6(n42),.p7(n38),.p9(n35),.p10(n41),.p11(n38),.p12(n40),.p13(n39),.p14(n104_f20_14),.p15(n105_f20_15));
 cell_SE10211 g12(.p2(n94_g12_2),.p3(n93_g12_3),.p4(n95_g12_4),.p5(1'b0),.p6(n129),.p7(1'b0),.p9(n0),.p10(n56),.p11(1'b0),.p12(n120_g12_12),.p13(n119_g12_13),.p14(n121_g12_14),.p15(n49),.p16(1'b0));
 cell_SE10210 g13(.p3(n86_g13_3),.p5(n132),.p6(n19),.p7(1'b0),.p8(1'b0),.p9(n132),.p10(1'b0),.p11(1'b0),.p13(n92_g13_13),.p15(n50),.p16(1'b0));
 original_MC10176 h22(.p1(1'b0),.p2(n116_h22_2),.p3(n117_h22_3),.p4(n126_h22_4),.p5(n62),.p6(n63),.p7(n105),.p8(1'b0),.p9(n16),.p10(n108),.p11(n109),.p12(n29),.p13(n118_h22_13),.p14(n127_h22_14),.p15(n69_h22_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_MC10102 h23(.p1(1'b0),.p2(n106_h23_2),.p3(n107_h23_3),.p4(n62),.p5(n64),.p6(n60),.p7(n62),.p10(n60),.p11(n106),.p12(n59),.p13(n114),.p14(n108_h23_14),.p15(n58_h23_15),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n8_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n63_h24_9),.p10(n4),.p11(n9_h24_11),.p12(1'b0),.p13(n61),.p14(n10_h24_14),.p15(n62_h24_15));
 original_MC10141 i12(.p1(1'b0),.p2(n32_i12_2),.p3(n33_i12_3),.p4(n34),.p5(1'b0),.p6(n103),.p7(1'b0),.p8(1'b0),.p9(n102),.p10(1'b0),.p11(n100),.p12(n101),.p13(1'b0),.p14(n30_i12_14),.p15(n31_i12_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_SE10210 i18(.p2(n17_i18_2),.p3(n16_i18_3),.p4(n18_i18_4),.p5(n86),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n90),.p10(1'b0),.p11(1'b0),.p12(n24_i18_12),.p13(n23_i18_13),.p15(n52),.p16(1'b0));
 cell_SE10210 j18(.p2(n34_j18_2),.p5(n92),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n90),.p10(n57),.p11(n125),.p12(n124_j18_12),.p15(n53),.p16(1'b0));
 cell_SE10210 l01(.p4(n19_l01_4),.p5(1'b0),.p6(n123),.p7(1'b0),.p8(1'b0),.p9(n15),.p10(1'b0),.p11(n14),.p12(n131_l01_12),.p13(n130_l01_13),.p14(n132_l01_14),.p15(n54),.p16(1'b0));
 original_SE10231 l02(.p2(n129_l02_2),.p6(n15),.p7(n19),.p9(n14),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n122;
 assign clocks[3]=n16;
 assign clocks[4]=n20;
 assign clocks[5]=n34;
 assign flags[0]=n120;
 assign flags[1]=n55;
 assign flags[2]=n29;
endmodule
`default_nettype wire
