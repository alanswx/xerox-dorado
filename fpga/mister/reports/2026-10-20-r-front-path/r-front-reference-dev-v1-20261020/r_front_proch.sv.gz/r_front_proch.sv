`timescale 1ns/1ps
`default_nettype none
module r_front_proch(input wire fixture_load,input wire [279:0] fixture_state,
 input wire base,start_a,en,input wire [235:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,rb_forward,rb_forward_n,
 output wire [279:0] state_q,output wire [14:0] clocks,
 output wire [26:0] flags);
 wire n0; // ALUCarry
 wire n1; // ASEL.0'
 wire n2; // ASEL.1'
 wire n3; // ASEL.2'
 wire n4; // ASel.0
 wire n5; // ASel.0'
 wire n6; // ASel=2/3'
 wire n7; // ASel=5/7
 wire n8; // ASel=5/7'
 wire n9; // ASel=6/7
 wire n10; // ASel=6/7'
 wire n11; // BCWriteEn'
 wire n12; // BNTGtCT
 wire n13; // BNTGtCT'a
 wire n14; // BSEL.0'
 wire n15; // BSEL.1'
 wire n16; // BSEL.2'
 wire n17; // BSel.0'a
 wire n18; // BSel.0a
 wire n19; // BSel.1'a
 wire n20; // BSel.1a
 wire n21; // BSel.2'a
 wire n22; // BSel.2a
 wire n23; // BSel=2/6
 wire n24; // B_Ext
 wire n25; // B_Ext'
 wire n26; // BumpRSTK
 wire n27; // CLK.ph'
 wire n28; // CLKEnable'c
 wire n29; // Clock0'Bb
 wire n30; // Clock0'Bc
 wire n31; // Clock0'Da
 wire n32; // Clock0'Dc
 wire n33; // Clock0'Dd
 wire n34; // Clock0En'
 wire n35; // Clock1'Ba
 wire n36; // Clock1'Bb
 wire n37; // Clock1'Ca
 wire n38; // Clock1'Cb
 wire n39; // Clock1'Cd
 wire n40; // Clock1'Da
 wire n41; // Clock1'Dc
 wire n42; // Clock1Bd
 wire n43; // Curr.0'
 wire n44; // Curr.1'
 wire n45; // Curr.2'
 wire n46; // Curr.3'
 wire n47; // Curr=Next'
 wire n48; // CurrLast.0'
 wire n49; // CurrLast.1'
 wire n50; // CurrLast.2'
 wire n51; // CurrLast.3'
 wire n52; // DMData
 wire n53; // DMuxData
 wire n54; // DblClock'Da
 wire n55; // DsMd
 wire n56; // DsPd
 wire n57; // DsRd
 wire n58; // FA=0'
 wire n59; // FA=0'a
 wire n60; // FA=0'b
 wire n61; // FA=1'a
 wire n62; // FA=2'a
 wire n63; // FA=3'
 wire n64; // FB=0'
 wire n65; // FB=2'
 wire n66; // FB=3'
 wire n67; // FB=4'
 wire n68; // FB=5'
 wire n69; // FB=6'
 wire n70; // FB=7'
 wire n71; // FC=2/3'
 wire n72; // FC=4/5'
 wire n73; // FC=5'
 wire n74; // FC=6'
 wire n75; // FC=7'
 wire n76; // FF.0
 wire n77; // FF.0a
 wire n78; // FF.0mem
 wire n79; // FF.0mem'
 wire n80; // FF.1
 wire n81; // FF.1a
 wire n82; // FF.1mem
 wire n83; // FF.2
 wire n84; // FF.2'a
 wire n85; // FF.2a
 wire n86; // FF.3
 wire n87; // FF.3'a
 wire n88; // FF.3a
 wire n89; // FF.4
 wire n90; // FF.4a
 wire n91; // FF.5
 wire n92; // FF.5'a
 wire n93; // FF.5a
 wire n94; // FF.6
 wire n95; // FF.6'a
 wire n96; // FF.6a
 wire n97; // FF.7
 wire n98; // FF.7'a
 wire n99; // FF.7a
 wire n100; // FFok'a
 wire n101; // Freeze
 wire n102; // GND132
 wire n103; // GND142
 wire n104; // GND188
 wire n105; // GND264
 wire n106; // GND266
 wire n107; // GND312
 wire n108; // GND314
 wire n109; // GND394
 wire n110; // GND40
 wire n111; // GND420
 wire n112; // GND442
 wire n113; // GND468
 wire n114; // GND500
 wire n115; // GND530
 wire n116; // GND544
 wire n117; // GND546
 wire n118; // Hold
 wire n119; // Hold'
 wire n120; // HoldDly
 wire n121; // Holda
 wire n122; // IOB.Perr'
 wire n123; // IOBout
 wire n124; // LC.0
 wire n125; // LC.1
 wire n126; // LC.1'a
 wire n127; // LC.1a
 wire n128; // LC.2
 wire n129; // Last.0'
 wire n130; // Last.1'
 wire n131; // Last.2'
 wire n132; // Last.3'
 wire n133; // Last=Curr'
 wire n134; // LastNext.0'
 wire n135; // LastNext.1'
 wire n136; // LastNext.2'
 wire n137; // LastNext.3'
 wire n138; // MBBypass
 wire n139; // MBWriteEn'
 wire n140; // Next.0
 wire n141; // Next.0'
 wire n142; // Next.1
 wire n143; // Next.1'
 wire n144; // Next.2
 wire n145; // Next.2'
 wire n146; // Next.3
 wire n147; // Next.3'
 wire n148; // NextMacro
 wire n149; // Overflow'
 wire n150; // PRhold
 wire n151; // Pdata.00
 wire n152; // Pdata.01
 wire n153; // Pdata.02
 wire n154; // Pdata.03
 wire n155; // Pdata.04
 wire n156; // Pdata.05
 wire n157; // Pdata.06
 wire n158; // Pdata.07
 wire n159; // PostClock0'Bc
 wire n160; // PreClock0'A
 wire n161; // PreClock0'B
 wire n162; // PreClock0'C
 wire n163; // PreClock0'D
 wire n164; // PreClock1'A
 wire n165; // PreClock1'B
 wire n166; // PreClock1'C
 wire n167; // PreClock1'D
 wire n168; // PreClock1B
 wire n169; // PreDblClock'D
 wire n170; // PreFA=0
 wire n171; // PreFA=1'
 wire n172; // PreSHCP'A
 wire n173; // PreSHCP'B
 wire n174; // PreSHCP'C
 wire n175; // PreSHCP'Shc
 wire n176; // PreSHSelect'D
 wire n177; // ProcH02.sil+4
 wire n178; // ProcH03.sil+1
 wire n179; // ProcH03.sil+5
 wire n180; // ProcH04.sil+1
 wire n181; // ProcH04.sil+5
 wire n182; // ProcH05.sil+1
 wire n183; // ProcH05.sil+5
 wire n184; // ProcH06.sil+1
 wire n185; // ProcH06.sil+5
 wire n186; // ProcH07.sil+1
 wire n187; // ProcH07.sil+5
 wire n188; // ProcH08.sil+1
 wire n189; // ProcH08.sil+5
 wire n190; // ProcH09.sil+1
 wire n191; // ProcH09.sil+5
 wire n192; // ProcH10.sil+1
 wire n193; // ProcH10.sil+2
 wire n194; // ProcH10.sil+3
 wire n195; // ProcH11.sil+1
 wire n196; // ProcH11.sil+12
 wire n197; // ProcH11.sil+13
 wire n198; // ProcH11.sil+14
 wire n199; // ProcH11.sil+15
 wire n200; // ProcH11.sil+9
 wire n201; // ProcH12.sil+1
 wire n202; // ProcH12.sil+2
 wire n203; // ProcH12.sil+3
 wire n204; // ProcH12.sil+4
 wire n205; // ProcH12.sil+5
 wire n206; // ProcH13.sil+1
 wire n207; // ProcH15.sil+1
 wire n208; // ProcH17.sil+2
 wire n209; // ProcH17.sil+3
 wire n210; // ProcH20.sil+1
 wire n211; // ProcH20.sil+2
 wire n212; // ProcH20.sil+3
 wire n213; // ProcH20.sil+4
 wire n214; // ProcH20.sil+5
 wire n215; // ProcH20.sil+6
 wire n216; // ProcH22.sil+1
 wire n217; // ProcH22.sil+2
 wire n218; // ProcH22.sil+3
 wire n219; // ProcH22.sil+4
 wire n220; // ProcH22.sil+5
 wire n221; // ProcH22.sil+6
 wire n222; // ProcH24.sil+1
 wire n223; // ProcH24.sil+2
 wire n224; // ProcH24.sil+3
 wire n225; // ProcH24.sil+4
 wire n226; // ProcH25.sil+1
 wire n227; // ProcH25.sil+18
 wire n228; // ProcH25.sil+7
 wire n229; // ProcH26.sil+1
 wire n230; // ProcH26.sil+3
 wire n231; // ProcH27.sil+1
 wire n232; // ProcH27.sil+10
 wire n233; // ProcH27.sil+12
 wire n234; // ProcH27.sil+7
 wire n235; // ProcH27.sil+8
 wire n236; // ProcH27.sil+9
 wire n237; // ProcH30.sil+1
 wire n238; // PropCnt'
 wire n239; // R.00
 wire n240; // R.01
 wire n241; // R.02
 wire n242; // R.03
 wire n243; // R.04
 wire n244; // R.05
 wire n245; // R.06
 wire n246; // R.07
 wire n247; // R.Perr'
 wire n248; // RSTK.0
 wire n249; // RSTK.1
 wire n250; // RSTK.2
 wire n251; // RSTK.3
 wire n252; // RbAdr.4'
 wire n253; // RbAdr.5'
 wire n254; // RbAdr.6'
 wire n255; // RbAdr.7'
 wire n256; // RbBypass
 wire n257; // RbBypass'
 wire n258; // RbBypassDly
 wire n259; // RbSelMd
 wire n260; // RbSelMd'
 wire n261; // RbWadr.4
 wire n262; // RbWadr.5
 wire n263; // RbWadr.6
 wire n264; // RbWadr.7
 wire n265; // RbWrite'a
 wire n266; // RbWrite'b
 wire n267; // RbWrite'c
 wire n268; // RbWriteEn'
 wire n269; // RepeatCurrB
 wire n270; // RepeatCurrC
 wire n271; // RepeatCurrD
 wire n272; // RisIFdata
 wire n273; // RmLtZero'
 wire n274; // Rparity
 wire n275; // SHCP'C
 wire n276; // ShiftBitsEn'
 wire n277; // SignIfuData
 wire n278; // StartCycle'a
 wire n279; // T.00
 wire n280; // T.01
 wire n281; // T.02
 wire n282; // T.03
 wire n283; // T.04
 wire n284; // T.05
 wire n285; // T.06
 wire n286; // T.07
 wire n287; // T.Perr'
 wire n288; // TIOAWrite'
 wire n289; // TIOAWriteEn'
 wire n290; // Task2Bk.3'
 wire n291; // Task3Bk.3'
 wire n292; // TbBypass
 wire n293; // TbSelMd
 wire n294; // TbWrite'a
 wire n295; // TbWrite'b
 wire n296; // TbWriteEn'
 wire n297; // TisIFdata
 wire n298; // Tparity
 wire n299; // TrueA
 wire n300; // dMD.00
 wire n301; // dMD.01
 wire n302; // dMD.02
 wire n303; // dMD.03
 wire n304; // dMD.04
 wire n305; // dMD.05
 wire n306; // dMD.06
 wire n307; // dMD.07
 wire n308; // dR.00
 wire n309; // dR.01
 wire n310; // dR.02
 wire n311; // dR.03
 wire n312; // dR.04
 wire n313; // dR.05
 wire n314; // dR.06
 wire n315; // dR.07
 wire n316; // dRm.00
 wire n317; // dRm.01
 wire n318; // dRm.02
 wire n319; // dRm.03
 wire n320; // dRm.04
 wire n321; // dRm.05
 wire n322; // dRm.06
 wire n323; // dRm.07
 wire n324; // dT.00
 wire n325; // dT.01
 wire n326; // dT.02
 wire n327; // dT.03
 wire n328; // dT.04
 wire n329; // dT.05
 wire n330; // dT.06
 wire n331; // dT.07
 wire n332; // dTm.00
 wire n333; // dTm.01
 wire n334; // dTm.02
 wire n335; // dTm.03
 wire n336; // dTm.04
 wire n337; // dTm.05
 wire n338; // dTm.06
 wire n339; // dTm.07
 wire n340; // ddR.00
 wire n341; // pClock1En'
 wire n342; // ppClk'a
 wire n343; // ppClk'b
 wire n344; // ppClk'c
 assign n102=1'b0;
 assign n103=1'b0;
 assign n104=1'b0;
 assign n105=1'b0;
 assign n106=1'b0;
 assign n107=1'b0;
 assign n108=1'b0;
 assign n109=1'b0;
 assign n110=1'b0;
 assign n111=1'b0;
 assign n112=1'b0;
 assign n113=1'b0;
 assign n114=1'b0;
 assign n115=1'b0;
 assign n116=1'b0;
 assign n117=1'b0;
 assign n0=pins[110];
 assign n1=pins[202];
 assign n2=pins[203];
 assign n3=pins[204];
 assign n13=priority_n;
 assign n14=pins[205];
 assign n15=pins[206];
 assign n16=pins[207];
 assign n27=base;
 assign n28=en;
 assign n53=pins[208];
 assign n61=(pins[19:18]!=2'd1);
 assign n73=(pins[14:12]!=3'd5);
 assign n74=(pins[14:12]!=3'd6);
 assign n75=(pins[14:12]!=3'd7);
 assign n76=pins[19];
 assign n80=pins[18];
 assign n83=pins[17];
 assign n86=pins[16];
 assign n89=pins[15];
 assign n91=pins[14];
 assign n94=pins[13];
 assign n97=pins[12];
 assign n100=pins[209];
 assign n101=freeze;
 assign n121=pins[68];
 assign n123=pins[210];
 assign n124=pins[11];
 assign n125=pins[10];
 assign n128=pins[9];
 assign n138=pins[211];
 assign n140=next_raw[0];
 assign n142=next_raw[1];
 assign n144=next_raw[2];
 assign n146=next_raw[3];
 assign n148=pins[212];
 assign n149=pins[111];
 assign n150=pins[68];
 assign n151=pins[76];
 assign n152=pins[77];
 assign n153=pins[78];
 assign n154=pins[79];
 assign n155=pins[80];
 assign n156=pins[81];
 assign n157=pins[82];
 assign n158=pins[83];
 assign n178=pins[128];
 assign n180=pins[129];
 assign n182=pins[130];
 assign n184=pins[131];
 assign n186=pins[132];
 assign n188=pins[133];
 assign n190=pins[134];
 assign n198=pins[145];
 assign n209=pins[181];
 assign n226=pins[213];
 assign n227=pins[214];
 assign n230=pins[215];
 assign n231=pins[143];
 assign n233=pins[216];
 assign n238=pins[180];
 assign n248=pins[172];
 assign n249=pins[173];
 assign n250=pins[174];
 assign n251=pins[175];
 assign n256=rb_forward;
 assign n257=rb_forward_n;
 assign n272=pins[149];
 assign n277=pins[118];
 assign n278=start_a;
 assign n289=pins[217];
 assign n297=pins[117];
 assign n300=pins[92];
 assign n301=pins[93];
 assign n302=pins[94];
 assign n303=pins[95];
 assign n304=pins[96];
 assign n305=pins[97];
 assign n306=pins[98];
 assign n307=pins[99];
 assign n340=pins[127];
 wire n4_b23_2;
 assign n4=n4_b23_2;
 wire n5_b23_5;
 assign n5=n5_b23_5;
 wire n6_b23_3;
 assign n6=n6_b23_3;
 wire n7_b23_15;
 assign n7=n7_b23_15;
 wire n8_b23_9;
 assign n8=n8_b23_9;
 wire n9_b23_14;
 assign n9=n9_b23_14;
 wire n10_b23_11;
 assign n10=n10_b23_11;
 wire n11_g18_2;
 assign n11=n11_g18_2;
 wire n12_a01_2;
 assign n12=n12_a01_2;
 wire n17_h24_5;
 assign n17=n17_h24_5;
 wire n18_h24_2;
 assign n18=n18_h24_2;
 wire n19_h24_6;
 assign n19=n19_h24_6;
 wire n20_h24_3;
 assign n20=n20_h24_3;
 wire n21_h24_11;
 assign n21=n21_h24_11;
 wire n22_h24_14;
 assign n22=n22_h24_14;
 wire n23_f18_15;
 assign n23=n23_f18_15;
 wire n24_f19_3;
 assign n24=n24_f19_3;
 wire n25_f19_2;
 assign n25=n25_f19_2;
 wire n26_g20_2;
 assign n26=n26_g20_2;
 wire n29_k10_4;
 assign n29=n29_k10_4;
 wire n30_k10_2;
 assign n30=n30_k10_2;
 wire n31_i18_3;
 assign n31=n31_i18_3;
 wire n32_i18_2;
 assign n32=n32_i18_2;
 wire n33_i18_4;
 assign n33=n33_i18_4;
 wire n34_l01_4;
 assign n34=n34_l01_4;
 wire n35_i05_3;
 assign n35=n35_i05_3;
 wire n36_i05_4;
 assign n36=n36_i05_4;
 wire n37_c18_3;
 assign n37=n37_c18_3;
 wire n38_c18_2;
 assign n38=n38_c18_2;
 wire n39_c18_4;
 assign n39=n39_c18_4;
 wire n40_i18_13;
 assign n40=n40_i18_13;
 wire n41_i18_12;
 assign n41=n41_i18_12;
 wire n42_i05_2;
 assign n42=n42_i05_2;
 wire n43_a21_14;
 assign n43=n43_a21_14;
 wire n44_a21_15;
 assign n44=n44_a21_15;
 wire n45_a21_2;
 assign n45=n45_a21_2;
 wire n46_a21_3;
 assign n46=n46_a21_3;
 wire n47_a22_3;
 wire n47_a22_2;
 wire n47_a22_15;
 wire n47_a22_14;
 assign n47=n47_a22_3 | n47_a22_2 | n47_a22_15 | n47_a22_14;
 wire n48_i12_14;
 assign n48=n48_i12_14;
 wire n49_i12_15;
 assign n49=n49_i12_15;
 wire n50_i12_2;
 assign n50=n50_i12_2;
 wire n51_i12_3;
 assign n51=n51_i12_3;
 wire n52_h17_2;
 assign n52=n52_h17_2;
 wire n54_j18_2;
 assign n54=n54_j18_2;
 wire n55_l09_2;
 wire n55_l08_3;
 assign n55=n55_l09_2 | n55_l08_3;
 wire n56_l08_12;
 wire n56_l08_2;
 assign n56=n56_l08_12 | n56_l08_2;
 wire n57_l09_3;
 wire n57_l08_13;
 assign n57=n57_l09_3 | n57_l08_13;
 wire n58_c23_4;
 wire n58_d22_2;
 assign n58=n58_c23_4 | n58_d22_2;
 wire n59_d22_3;
 wire n59_c23_3;
 assign n59=n59_d22_3 | n59_c23_3;
 wire n60_c23_2;
 wire n60_d22_4;
 assign n60=n60_c23_2 | n60_d22_4;
 wire n62_c23_12;
 wire n62_d23_11;
 wire n62_d24_14;
 assign n62=n62_c23_12 | n62_d23_11 | n62_d24_14;
 wire n63_d23_2;
 wire n63_d24_3;
 wire n63_c23_14;
 assign n63=n63_d23_2 | n63_d24_3 | n63_c23_14;
 wire n64_e24_6;
 assign n64=n64_e24_6;
 wire n65_e24_4;
 assign n65=n65_e24_4;
 wire n66_e24_3;
 assign n66=n66_e24_3;
 wire n67_e24_13;
 assign n67=n67_e24_13;
 wire n68_e24_12;
 assign n68=n68_e24_12;
 wire n69_e24_11;
 assign n69=n69_e24_11;
 wire n70_e24_10;
 assign n70=n70_e24_10;
 wire n71_f23_15;
 wire n71_f23_11;
 assign n71=n71_f23_15 | n71_f23_11;
 wire n72_f23_14;
 wire n72_f23_9;
 assign n72=n72_f23_14 | n72_f23_9;
 wire n77_d24_6;
 assign n77=n77_d24_6;
 wire n78_d24_5;
 assign n78=n78_d24_5;
 wire n79_d24_2;
 assign n79=n79_d24_2;
 wire n81_d23_6;
 assign n81=n81_d23_6;
 wire n82_d23_5;
 assign n82=n82_d23_5;
 wire n84_e23_2;
 assign n84=n84_e23_2;
 wire n85_e23_5;
 assign n85=n85_e23_5;
 wire n87_e23_3;
 assign n87=n87_e23_3;
 wire n88_e23_6;
 assign n88=n88_e23_6;
 wire n90_e23_11;
 assign n90=n90_e23_11;
 wire n92_e23_15;
 assign n92=n92_e23_15;
 wire n93_e23_9;
 assign n93=n93_e23_9;
 wire n95_f23_2;
 assign n95=n95_f23_2;
 wire n96_f23_5;
 assign n96=n96_f23_5;
 wire n98_f23_3;
 assign n98=n98_f23_3;
 wire n99_f23_6;
 assign n99=n99_f23_6;
 wire n118_f19_15;
 assign n118=n118_f19_15;
 wire n119_f19_14;
 assign n119=n119_f19_14;
 wire n120_g18_15;
 assign n120=n120_g18_15;
 wire n122_h23_15;
 assign n122=n122_h23_15;
 wire n126_h24_15;
 assign n126=n126_h24_15;
 wire n127_h24_9;
 assign n127=n127_h24_9;
 wire n129_a20_14;
 assign n129=n129_a20_14;
 wire n130_a20_15;
 assign n130=n130_a20_15;
 wire n131_a20_2;
 assign n131=n131_a20_2;
 wire n132_a20_3;
 assign n132=n132_a20_3;
 wire n133_h22_15;
 assign n133=n133_h22_15;
 wire n134_a19_1;
 assign n134=n134_a19_1;
 wire n135_a19_2;
 assign n135=n135_a19_2;
 wire n136_a19_15;
 assign n136=n136_a19_15;
 wire n137_a19_14;
 assign n137=n137_a19_14;
 wire n139_g18_3;
 assign n139=n139_g18_3;
 wire n141_a24_15;
 assign n141=n141_a24_15;
 wire n143_a24_14;
 assign n143=n143_a24_14;
 wire n145_a24_3;
 assign n145=n145_a24_3;
 wire n147_a24_2;
 assign n147=n147_a24_2;
 wire n159_k10_12;
 assign n159=n159_k10_12;
 wire n160_f13_13;
 assign n160=n160_f13_13;
 wire n161_f13_12;
 assign n161=n161_f13_12;
 wire n162_f13_14;
 assign n162=n162_f13_14;
 wire n163_g13_3;
 assign n163=n163_g13_3;
 wire n164_f12_14;
 assign n164=n164_f12_14;
 wire n165_f13_2;
 assign n165=n165_f13_2;
 wire n166_f13_4;
 assign n166=n166_f13_4;
 wire n167_f13_3;
 assign n167=n167_f13_3;
 wire n168_f12_13;
 assign n168=n168_f12_13;
 wire n169_g13_13;
 assign n169=n169_g13_13;
 wire n170_d23_15;
 assign n170=n170_d23_15;
 wire n171_d24_11;
 wire n171_d23_3;
 assign n171=n171_d24_11 | n171_d23_3;
 wire n172_g12_3;
 assign n172=n172_g12_3;
 wire n173_g12_2;
 assign n173=n173_g12_2;
 wire n174_g12_4;
 assign n174=n174_g12_4;
 wire n175_f12_4;
 assign n175=n175_f12_4;
 wire n176_f12_3;
 assign n176=n176_f12_3;
 wire n177_l03_2;
 assign n177=n177_l03_2;
 wire n179_l03_1;
 assign n179=n179_l03_1;
 wire n181_l03_15;
 assign n181=n181_l03_15;
 wire n183_l03_14;
 assign n183=n183_l03_14;
 wire n185_l04_2;
 assign n185=n185_l04_2;
 wire n187_l04_1;
 assign n187=n187_l04_1;
 wire n189_l04_15;
 assign n189=n189_l04_15;
 wire n191_l04_14;
 assign n191=n191_l04_14;
 wire n192_l08_14;
 assign n192=n192_l08_14;
 wire n193_l09_4;
 assign n193=n193_l09_4;
 wire n194_l08_4;
 assign n194=n194_l08_4;
 wire n195_f20_2;
 wire n195_h17_15;
 assign n195=n195_f20_2 | n195_h17_15;
 wire n196_g18_14;
 assign n196=n196_g18_14;
 wire n197_g18_13;
 assign n197=n197_g18_13;
 wire n199_d20_14;
 assign n199=n199_d20_14;
 wire n200_g20_15;
 assign n200=n200_g20_15;
 wire n201_a24_9;
 wire n201_a24_11;
 wire n201_a24_6;
 wire n201_a24_5;
 assign n201=n201_a24_9 | n201_a24_11 | n201_a24_6 | n201_a24_5;
 wire n202_a18_2;
 assign n202=n202_a18_2;
 wire n203_a18_1;
 assign n203=n203_a18_1;
 wire n204_a18_15;
 assign n204=n204_a18_15;
 wire n205_a18_14;
 assign n205=n205_a18_14;
 wire n206_d24_9;
 wire n206_d23_14;
 assign n206=n206_d24_9 | n206_d23_14;
 wire n207_f20_14;
 assign n207=n207_f20_14;
 wire n208_h19_2;
 assign n208=n208_h19_2;
 wire n210_f20_15;
 wire n210_f18_3;
 assign n210=n210_f20_15 | n210_f18_3;
 wire n211_h23_2;
 assign n211=n211_h23_2;
 wire n212_h23_3;
 assign n212=n212_h23_3;
 wire n213_h23_14;
 assign n213=n213_h23_14;
 wire n214_f18_2;
 assign n214=n214_f18_2;
 wire n215_l09_12;
 assign n215=n215_l09_12;
 wire n216_h19_15;
 assign n216=n216_h19_15;
 wire n217_h19_9;
 assign n217=n217_h19_9;
 wire n218_k05_14;
 assign n218=n218_k05_14;
 wire n219_k05_15;
 assign n219=n219_k05_15;
 wire n220_k05_2;
 assign n220=n220_k05_2;
 wire n221_k05_1;
 assign n221=n221_k05_1;
 wire n222_f18_14;
 wire n222_d22_14;
 assign n222=n222_f18_14 | n222_d22_14;
 wire n223_f20_3;
 wire n223_d22_13;
 assign n223=n223_f20_3 | n223_d22_13;
 wire n224_d20_2;
 wire n224_d20_3;
 assign n224=n224_d20_2 | n224_d20_3;
 wire n225_g20_3;
 assign n225=n225_g20_3;
 wire n228_h17_14;
 assign n228=n228_h17_14;
 wire n229_a01_3;
 assign n229=n229_a01_3;
 wire n232_g21_15;
 assign n232=n232_g21_15;
 wire n234_i11_2;
 assign n234=n234_i11_2;
 wire n235_k04_2;
 assign n235=n235_k04_2;
 wire n236_g21_2;
 assign n236=n236_g21_2;
 wire n237_f12_2;
 assign n237=n237_f12_2;
 wire n239_g06_1;
 assign n239=n239_g06_1;
 wire n240_g06_2;
 assign n240=n240_g06_2;
 wire n241_g06_15;
 assign n241=n241_g06_15;
 wire n242_g06_14;
 assign n242=n242_g06_14;
 wire n243_g07_1;
 assign n243=n243_g07_1;
 wire n244_g07_2;
 assign n244=n244_g07_2;
 wire n245_g07_15;
 assign n245=n245_g07_15;
 wire n246_g07_14;
 assign n246=n246_g07_14;
 wire n247_c06_2;
 assign n247=n247_c06_2;
 wire n252_k08_15;
 wire n252_k08_2;
 assign n252=n252_k08_15 | n252_k08_2;
 wire n253_k08_14;
 wire n253_k08_3;
 assign n253=n253_k08_14 | n253_k08_3;
 wire n254_k09_2;
 wire n254_k09_15;
 assign n254=n254_k09_2 | n254_k09_15;
 wire n255_k09_3;
 wire n255_k09_14;
 assign n255=n255_k09_3 | n255_k09_14;
 wire n258_l07_15;
 assign n258=n258_l07_15;
 wire n259_h22_2;
 assign n259=n259_h22_2;
 wire n260_h22_3;
 assign n260=n260_h22_3;
 wire n261_l05_2;
 assign n261=n261_l05_2;
 wire n262_l05_3;
 assign n262=n262_l05_3;
 wire n263_l05_4;
 assign n263=n263_l05_4;
 wire n264_l05_13;
 assign n264=n264_l05_13;
 wire n265_j05_13;
 assign n265=n265_j05_13;
 wire n266_j05_12;
 assign n266=n266_j05_12;
 wire n267_j05_14;
 assign n267=n267_j05_14;
 wire n268_h22_13;
 assign n268=n268_h22_13;
 wire n269_g12_13;
 assign n269=n269_g12_13;
 wire n270_g12_12;
 assign n270=n270_g12_12;
 wire n271_g12_14;
 assign n271=n271_g12_14;
 wire n273_l06_3;
 wire n273_l06_14;
 wire n273_l07_3;
 assign n273=n273_l06_3 | n273_l06_14 | n273_l07_3;
 wire n274_g16_14;
 assign n274=n274_g16_14;
 wire n275_c18_12;
 assign n275=n275_c18_12;
 wire n276_g16_2;
 assign n276=n276_g16_2;
 wire n279_i03_1;
 assign n279=n279_i03_1;
 wire n280_i03_2;
 assign n280=n280_i03_2;
 wire n281_i03_15;
 assign n281=n281_i03_15;
 wire n282_i03_14;
 assign n282=n282_i03_14;
 wire n283_i04_1;
 assign n283=n283_i04_1;
 wire n284_i04_2;
 assign n284=n284_i04_2;
 wire n285_i04_15;
 assign n285=n285_i04_15;
 wire n286_i04_14;
 assign n286=n286_i04_14;
 wire n287_d06_2;
 assign n287=n287_d06_2;
 wire n288_j18_12;
 assign n288=n288_j18_12;
 wire n290_l05_14;
 assign n290=n290_l05_14;
 wire n291_l05_15;
 assign n291=n291_l05_15;
 wire n292_g21_3;
 assign n292=n292_g21_3;
 wire n293_h22_4;
 assign n293=n293_h22_4;
 wire n294_j05_3;
 assign n294=n294_j05_3;
 wire n295_j05_2;
 assign n295=n295_j05_2;
 wire n296_h22_14;
 assign n296=n296_h22_14;
 wire n298_g16_15;
 assign n298=n298_g16_15;
 wire n299_a01_14;
 assign n299=n299_a01_14;
 wire n308_g05_1;
 assign n308=n308_g05_1;
 wire n309_g05_2;
 assign n309=n309_g05_2;
 wire n310_g05_15;
 assign n310=n310_g05_15;
 wire n311_g05_14;
 assign n311=n311_g05_14;
 wire n312_h05_1;
 assign n312=n312_h05_1;
 wire n313_h05_2;
 assign n313=n313_h05_2;
 wire n314_h05_15;
 assign n314=n314_h05_15;
 wire n315_h05_14;
 assign n315=n315_h05_14;
 wire n316_j01_1;
 assign n316=n316_j01_1;
 wire n317_j01_2;
 assign n317=n317_j01_2;
 wire n318_j01_15;
 assign n318=n318_j01_15;
 wire n319_j01_14;
 assign n319=n319_j01_14;
 wire n320_j02_1;
 assign n320=n320_j02_1;
 wire n321_j02_2;
 assign n321=n321_j02_2;
 wire n322_j02_15;
 assign n322=n322_j02_15;
 wire n323_j02_14;
 assign n323=n323_j02_14;
 wire n324_j03_1;
 assign n324=n324_j03_1;
 wire n325_j03_2;
 assign n325=n325_j03_2;
 wire n326_j03_15;
 assign n326=n326_j03_15;
 wire n327_j03_14;
 assign n327=n327_j03_14;
 wire n328_j04_1;
 assign n328=n328_j04_1;
 wire n329_j04_2;
 assign n329=n329_j04_2;
 wire n330_j04_15;
 assign n330=n330_j04_15;
 wire n331_j04_14;
 assign n331=n331_j04_14;
 wire n332_k01_1;
 assign n332=n332_k01_1;
 wire n333_k01_2;
 assign n333=n333_k01_2;
 wire n334_k01_15;
 assign n334=n334_k01_15;
 wire n335_k01_14;
 assign n335=n335_k01_14;
 wire n336_k02_1;
 assign n336=n336_k02_1;
 wire n337_k02_2;
 assign n337=n337_k02_2;
 wire n338_k02_15;
 assign n338=n338_k02_15;
 wire n339_k02_14;
 assign n339=n339_k02_14;
 wire n341_l02_2;
 assign n341=n341_l02_2;
 wire n342_l01_13;
 assign n342=n342_l01_13;
 wire n343_l01_12;
 assign n343=n343_l01_12;
 wire n344_l01_14;
 assign n344=n344_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n12_a01_2),.p3(n229_a01_3),.p4(n13),.p5(1'b0),.p6(n230),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n299_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n203_a18_1),.p2(n202_a18_2),.p3(n135),.p4(n44),.p5(n134),.p6(n43),.p9(n270),.p10(n137),.p11(n46),.p12(n136),.p13(n45),.p14(n205_a18_14),.p15(n204_a18_15));
 cell_MC10158 a19(.p1(n134_a19_1),.p2(n135_a19_2),.p3(n143),.p4(n130),.p5(n141),.p6(n129),.p9(n174),.p10(n147),.p11(n132),.p12(n145),.p13(n131),.p14(n137_a19_14),.p15(n136_a19_15));
 original_MC10141 a20(.p1(n110),.p2(n131_a20_2),.p3(n132_a20_3),.p4(n37),.p5(1'b0),.p6(n46),.p7(1'b0),.p8(1'b0),.p9(n45),.p10(1'b0),.p11(n44),.p12(n43),.p13(1'b0),.p14(n129_a20_14),.p15(n130_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n45_a21_2),.p3(n46_a21_3),.p4(n275),.p5(1'b0),.p6(n147),.p7(n270),.p8(1'b0),.p9(n145),.p10(n270),.p11(n143),.p12(n141),.p13(1'b0),.p14(n43_a21_14),.p15(n44_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n47_a22_2),.p3(n47_a22_3),.p4(n46),.p5(n147),.p6(n145),.p7(n45),.p9(1'b0),.p10(n143),.p11(n44),.p12(n141),.p13(n43),.p14(n47_a22_14),.p15(n47_a22_15));
 cell_MC10101 a24(.p2(n147_a24_2),.p3(n145_a24_3),.p4(n146),.p5(n201_a24_5),.p6(n201_a24_6),.p7(n144),.p9(n201_a24_9),.p10(n142),.p11(n201_a24_11),.p12(1'b0),.p13(n140),.p14(n143_a24_14),.p15(n141_a24_15));
 cell_MC10101 b23(.p2(n4_b23_2),.p3(n6_b23_3),.p4(1'b0),.p5(n5_b23_5),.p7(1'b0),.p9(n8_b23_9),.p10(n2),.p11(n10_b23_11),.p12(n1),.p13(n3),.p14(n9_b23_14),.p15(n7_b23_15));
 cell_MC10170 c06(.p1(1'b0),.p2(n247_c06_2),.p3(n274),.p4(n246),.p5(n245),.p6(n244),.p7(n243),.p8(1'b0),.p9(n242),.p10(n241),.p11(n240),.p12(n239),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 c18(.p2(n38_c18_2),.p3(n37_c18_3),.p4(n39_c18_4),.p5(n166),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n174),.p10(1'b0),.p11(1'b0),.p12(n275_c18_12),.p15(n102),.p16(1'b0));
 cell_MC10210 c23(.p1(1'b0),.p2(n60_c23_2),.p3(n59_c23_3),.p4(n58_c23_4),.p5(1'b0),.p6(1'b0),.p7(n100),.p8(1'b0),.p9(n100),.p10(1'b0),.p11(n5),.p12(n62_c23_12),.p14(n63_c23_14),.p15(n103),.p16(1'b0));
 cell_MC10170 d06(.p1(1'b0),.p2(n287_d06_2),.p3(n298),.p4(n286),.p5(n285),.p6(n284),.p7(n283),.p8(1'b0),.p9(n282),.p10(n281),.p11(n280),.p12(n279),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_MC10100 d20(.p2(n224_d20_2),.p3(n224_d20_3),.p4(n73),.p5(n64),.p6(n75),.p7(n64),.p9(n61),.p10(n71),.p11(n66),.p12(1'b0),.p13(1'b0),.p14(n199_d20_14));
 cell_MC10211 d22(.p2(n58_d22_2),.p3(n59_d22_3),.p4(n60_d22_4),.p5(n5),.p6(n170),.p7(1'b0),.p9(n93),.p10(n62),.p11(n68),.p13(n223_d22_13),.p14(n222_d22_14),.p15(n104),.p16(1'b0));
 cell_MC10101 d23(.p2(n63_d23_2),.p3(n171_d23_3),.p4(n100),.p5(n82_d23_5),.p6(n81_d23_6),.p7(1'b0),.p10(1'b0),.p11(n62_d23_11),.p12(n80),.p13(n76),.p14(n206_d23_14),.p15(n170_d23_15));
 cell_MC10101 d24(.p2(n79_d24_2),.p3(n63_d24_3),.p4(n100),.p5(n78_d24_5),.p6(n77_d24_6),.p7(1'b0),.p9(n206_d24_9),.p10(1'b0),.p11(n171_d24_11),.p12(n76),.p13(1'b0),.p14(n62_d24_14));
 cell_MC10101 e23(.p2(n84_e23_2),.p3(n87_e23_3),.p4(n83),.p5(n85_e23_5),.p6(n88_e23_6),.p7(n86),.p9(n93_e23_9),.p10(n89),.p11(n90_e23_11),.p12(1'b0),.p13(n91),.p15(n92_e23_15));
 cell_MC10161 e24(.p2(1'b0),.p3(n66_e24_3),.p4(n65_e24_4),.p6(n64_e24_6),.p7(n89),.p9(n86),.p10(n70_e24_10),.p11(n69_e24_11),.p12(n68_e24_12),.p13(n67_e24_13),.p14(n83),.p15(1'b0));
 cell_SE10212 f12(.p1(1'b0),.p2(n237_f12_2),.p3(n176_f12_3),.p4(n175_f12_4),.p5(n341),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n237),.p10(1'b0),.p11(n342),.p13(n168_f12_13),.p14(n164_f12_14),.p15(n105),.p16(1'b0));
 cell_SE10210 f13(.p2(n165_f13_2),.p3(n167_f13_3),.p4(n166_f13_4),.p5(n343),.p6(1'b0),.p7(n237),.p8(1'b0),.p9(n343),.p10(n34),.p11(1'b0),.p12(n161_f13_12),.p13(n160_f13_13),.p14(n162_f13_14),.p15(n106),.p16(1'b0));
 cell_MC10102 f18(.p1(1'b0),.p2(n214_f18_2),.p3(n210_f18_3),.p4(n128),.p5(n212),.p6(n124),.p7(n126),.p10(n85),.p11(n63),.p12(n22),.p13(n19),.p14(n222_f18_14),.p15(n23_f18_15),.p16(1'b0));
 cell_MC1660 f19(.p2(n25_f19_2),.p3(n24_f19_3),.p4(1'b0),.p5(n61),.p6(n87),.p7(n84),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n150),.p14(n119_f19_14),.p15(n118_f19_15));
 cell_MC10100 f20(.p2(n195_f20_2),.p3(n223_f20_3),.p4(n74),.p5(n70),.p6(n75),.p7(n66),.p9(n60),.p10(n74),.p11(n66),.p12(n73),.p13(n70),.p14(n207_f20_14),.p15(n210_f20_15));
 cell_MC10101 f23(.p2(n95_f23_2),.p3(n98_f23_3),.p4(n94),.p5(n96_f23_5),.p6(n99_f23_6),.p7(n97),.p9(n72_f23_9),.p10(n93),.p11(n71_f23_11),.p12(1'b0),.p13(n96),.p14(n72_f23_14),.p15(n71_f23_15));
 original_MC10173 g05(.p1(n308_g05_1),.p2(n309_g05_2),.p3(n178),.p4(n277),.p5(n340),.p6(n277),.p7(n36),.p9(n272),.p10(n182),.p11(n277),.p12(n180),.p13(n277),.p14(n311_g05_14),.p15(n310_g05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[254+:4]),.state_q(state_q[254+:4]));
 original_MC10173 g06(.p1(n239_g06_1),.p2(n240_g06_2),.p3(n309),.p4(n317),.p5(n308),.p6(n316),.p7(n173),.p9(n258),.p10(n311),.p11(n319),.p12(n310),.p13(n318),.p14(n242_g06_14),.p15(n241_g06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[262+:4]),.state_q(state_q[262+:4]));
 original_MC10173 g07(.p1(n243_g07_1),.p2(n244_g07_2),.p3(n313),.p4(n321),.p5(n312),.p6(n320),.p7(n173),.p9(n258),.p10(n315),.p11(n323),.p12(n314),.p13(n322),.p14(n246_g07_14),.p15(n245_g07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[266+:4]),.state_q(state_q[266+:4]));
 cell_SE10211 g12(.p2(n173_g12_2),.p3(n172_g12_3),.p4(n174_g12_4),.p5(1'b0),.p6(n341),.p7(1'b0),.p9(n12),.p10(n119),.p11(1'b0),.p12(n270_g12_12),.p13(n269_g12_13),.p14(n271_g12_14),.p15(n107),.p16(1'b0));
 cell_SE10210 g13(.p3(n163_g13_3),.p5(n344),.p6(n34),.p7(1'b0),.p8(1'b0),.p9(n344),.p10(1'b0),.p11(1'b0),.p13(n169_g13_13),.p15(n108),.p16(1'b0));
 original_F10000 g16(.p2(n276_g16_2),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n198),.p10(n234),.p11(n231),.p12(1'b0),.p13(n40),.p14(n274_g16_14),.p15(n298_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 original_MC10176 g18(.p1(1'b0),.p2(n11_g18_2),.p3(n139_g18_3),.p5(n195),.p6(n225),.p7(1'b0),.p8(1'b0),.p9(n31),.p10(n0),.p11(n149),.p12(n121),.p13(n197_g18_13),.p14(n196_g18_14),.p15(n120_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10106 g20(.p2(n26_g20_2),.p3(n225_g20_3),.p4(n223),.p5(n222),.p6(n148),.p7(n224),.p9(n84),.p10(n60),.p11(n88),.p12(n133),.p13(n11),.p14(n120),.p15(n200_g20_15));
 cell_MC10106 g21(.p2(n236_g21_2),.p3(n292_g21_3),.p4(n120),.p5(n133),.p6(n296),.p7(n297),.p9(n258),.p10(n272),.p11(n247),.p12(n292),.p13(n297),.p14(n287),.p15(n232_g21_15));
 original_MC10173 h05(.p1(n312_h05_1),.p2(n313_h05_2),.p3(n186),.p4(n277),.p5(n184),.p6(n277),.p7(n36),.p9(n272),.p10(n190),.p11(n277),.p12(n188),.p13(n277),.p14(n315_h05_14),.p15(n314_h05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[258+:4]),.state_q(state_q[258+:4]));
 cell_MC10158 h17(.p2(n52_h17_2),.p3(n53),.p4(n53),.p5(1'b0),.p6(1'b0),.p9(n138),.p10(n227),.p11(n226),.p12(n101),.p13(n101),.p14(n228_h17_14),.p15(n195_h17_15));
 cell_MC10103 h19(.p1(1'b0),.p2(n208_h19_2),.p4(n238),.p5(n209),.p6(1'b0),.p7(1'b0),.p9(n217_h19_9),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n176),.p15(n216_h19_15),.p16(1'b0));
 original_MC10176 h22(.p1(1'b0),.p2(n259_h22_2),.p3(n260_h22_3),.p4(n293_h22_4),.p5(n126),.p6(n127),.p7(n210),.p8(1'b0),.p9(n31),.p10(n213),.p11(n214),.p12(n47),.p13(n268_h22_13),.p14(n296_h22_14),.p15(n133_h22_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_MC10102 h23(.p1(1'b0),.p2(n211_h23_2),.p3(n212_h23_3),.p4(n126),.p5(n128),.p6(n124),.p7(n126),.p10(n124),.p11(n211),.p12(n123),.p13(n233),.p14(n213_h23_14),.p15(n122_h23_15),.p16(1'b0));
 cell_MC10101 h24(.p2(n18_h24_2),.p3(n20_h24_3),.p4(n14),.p5(n17_h24_5),.p6(n19_h24_6),.p7(n15),.p9(n127_h24_9),.p10(n16),.p11(n21_h24_11),.p12(1'b0),.p13(n125),.p14(n22_h24_14),.p15(n126_h24_15));
 original_MC10173 i03(.p1(n279_i03_1),.p2(n280_i03_2),.p3(n325),.p4(n333),.p5(n324),.p6(n332),.p7(n173),.p9(n292),.p10(n327),.p11(n335),.p12(n326),.p13(n334),.p14(n282_i03_14),.p15(n281_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 original_MC10173 i04(.p1(n283_i04_1),.p2(n284_i04_2),.p3(n329),.p4(n337),.p5(n328),.p6(n336),.p7(n173),.p9(n292),.p10(n331),.p11(n339),.p12(n330),.p13(n338),.p14(n286_i04_14),.p15(n285_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 cell_SE10212 i05(.p1(1'b0),.p2(n42_i05_2),.p3(n35_i05_3),.p4(n36_i05_4),.p5(1'b0),.p6(1'b0),.p7(n168),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n109),.p16(1'b0));
 original_F10145A i11(.p2(n234_i11_2),.p3(1'b0),.p4(1'b0),.p5(n235),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(1'b0),.p12(1'b0),.p13(n295),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 original_MC10141 i12(.p1(1'b0),.p2(n50_i12_2),.p3(n51_i12_3),.p4(n54),.p5(1'b0),.p6(n205),.p7(1'b0),.p8(1'b0),.p9(n204),.p10(1'b0),.p11(n202),.p12(n203),.p13(1'b0),.p14(n48_i12_14),.p15(n49_i12_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_SE10210 i18(.p2(n32_i18_2),.p3(n31_i18_3),.p4(n33_i18_4),.p5(n163),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n167),.p10(1'b0),.p11(1'b0),.p12(n41_i18_12),.p13(n40_i18_13),.p15(n111),.p16(1'b0));
 original_MC10173 j01(.p1(n316_j01_1),.p2(n317_j01_2),.p3(n152),.p4(n301),.p5(n151),.p6(n300),.p7(n35),.p9(n259),.p10(n154),.p11(n303),.p12(n153),.p13(n302),.p14(n319_j01_14),.p15(n318_j01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[246+:4]),.state_q(state_q[246+:4]));
 original_MC10173 j02(.p1(n320_j02_1),.p2(n321_j02_2),.p3(n156),.p4(n305),.p5(n155),.p6(n304),.p7(n36),.p9(n259),.p10(n158),.p11(n307),.p12(n157),.p13(n306),.p14(n323_j02_14),.p15(n322_j02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[250+:4]),.state_q(state_q[250+:4]));
 original_MC10173 j03(.p1(n324_j03_1),.p2(n325_j03_2),.p3(n179),.p4(n277),.p5(n177),.p6(n277),.p7(n36),.p9(n297),.p10(n183),.p11(n277),.p12(n181),.p13(n277),.p14(n327_j03_14),.p15(n326_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 original_MC10173 j04(.p1(n328_j04_1),.p2(n329_j04_2),.p3(n187),.p4(n277),.p5(n185),.p6(n277),.p7(n36),.p9(n297),.p10(n191),.p11(n277),.p12(n189),.p13(n277),.p14(n331_j04_14),.p15(n330_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 cell_SE10210 j05(.p2(n295_j05_2),.p3(n294_j05_3),.p5(n161),.p6(n120),.p7(n296),.p8(1'b0),.p9(n161),.p10(n120),.p11(n268),.p12(n266_j05_12),.p13(n265_j05_13),.p14(n267_j05_14),.p15(n112),.p16(1'b0));
 cell_SE10210 j18(.p2(n54_j18_2),.p5(n169),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n167),.p10(n121),.p11(n289),.p12(n288_j18_12),.p15(n113),.p16(1'b0));
 original_MC10173 k01(.p1(n332_k01_1),.p2(n333_k01_2),.p3(n152),.p4(n301),.p5(n151),.p6(n300),.p7(n35),.p9(n293),.p10(n154),.p11(n303),.p12(n153),.p13(n302),.p14(n335_k01_14),.p15(n334_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n336_k02_1),.p2(n337_k02_2),.p3(n156),.p4(n305),.p5(n155),.p6(n304),.p7(n35),.p9(n293),.p10(n158),.p11(n307),.p12(n157),.p13(n306),.p14(n339_k02_14),.p15(n338_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_MC10170 k04(.p1(1'b0),.p2(n235_k04_2),.p3(n299),.p4(n339),.p5(n338),.p6(n337),.p7(n336),.p8(1'b0),.p9(n335),.p10(n334),.p11(n333),.p12(n332),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_MC10158 k05(.p1(n221_k05_1),.p2(n220_k05_2),.p3(n250),.p4(n96),.p5(n251),.p6(n99),.p9(n26),.p10(n248),.p11(n90),.p12(n249),.p13(n93),.p14(n218_k05_14),.p15(n219_k05_15));
 cell_MC1662 k08(.p2(n252_k08_2),.p3(n253_k08_3),.p4(n248),.p5(n217),.p6(n249),.p7(n217),.p10(n216),.p11(n262),.p12(n216),.p13(n261),.p14(n253_k08_14),.p15(n252_k08_15));
 cell_MC1662 k09(.p2(n254_k09_2),.p3(n255_k09_3),.p4(n250),.p5(n217),.p6(n251),.p7(n217),.p10(n216),.p11(n264),.p12(n216),.p13(n263),.p14(n255_k09_14),.p15(n254_k09_15));
 cell_SE10210 k10(.p2(n30_k10_2),.p4(n29_k10_4),.p5(n161),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n30),.p10(1'b0),.p11(1'b0),.p12(n159_k10_12),.p15(n114),.p16(1'b0));
 cell_SE10210 l01(.p4(n34_l01_4),.p5(1'b0),.p6(n278),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n343_l01_12),.p13(n342_l01_13),.p14(n344_l01_14),.p15(n115),.p16(1'b0));
 original_SE10231 l02(.p2(n341_l02_2),.p6(n28),.p7(n34),.p9(n27),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n179_l03_1),.p2(n177_l03_2),.p3(1'b0),.p4(n333),.p5(n332),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(n334),.p12(n335),.p13(n294),.p14(n183_l03_14),.p15(n181_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n187_l04_1),.p2(n185_l04_2),.p3(1'b0),.p4(n337),.p5(n336),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(n338),.p12(n339),.p13(n294),.p14(n191_l04_14),.p15(n189_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 original_MC10176 l05(.p1(1'b0),.p2(n261_l05_2),.p3(n262_l05_3),.p4(n263_l05_4),.p5(n218),.p6(n219),.p7(n220),.p8(1'b0),.p9(n29),.p10(n221),.p11(n51),.p12(n290),.p13(n264_l05_13),.p14(n290_l05_14),.p15(n291_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[274+:6]),.state_q(state_q[274+:6]));
 original_MC1668 l06(.p3(n273_l06_3),.p4(1'b0),.p5(n55),.p6(n300),.p7(n192),.p9(n193),.p11(n151),.p12(n56),.p13(1'b0),.p14(n273_l06_14),.fixture_load(fixture_load),.fixture_state(fixture_state[272+:2]),.state_q(state_q[272+:2]));
 original_MC1668 l07(.p3(n273_l07_3),.p4(1'b0),.p5(n57),.p6(n340),.p7(n194),.p9(n42),.p11(n215),.p12(1'b0),.p13(1'b0),.p15(n258_l07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[270+:2]),.state_q(state_q[270+:2]));
 cell_SE10211 l08(.p2(n56_l08_2),.p3(n55_l08_3),.p4(n194_l08_4),.p5(n256),.p6(n165),.p7(1'b0),.p9(n260),.p10(n165),.p11(n257),.p12(n56_l08_12),.p13(n57_l08_13),.p14(n192_l08_14),.p15(n116),.p16(1'b0));
 cell_SE10211 l09(.p2(n55_l09_2),.p3(n57_l09_3),.p4(n193_l09_4),.p5(n259),.p6(n165),.p7(n257),.p9(n257),.p10(1'b0),.p11(n272),.p12(n215_l09_12),.p15(n117),.p16(1'b0));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n275;
 assign clocks[3]=n31;
 assign clocks[4]=n37;
 assign clocks[5]=n54;
 assign clocks[6]=n35;
 assign clocks[7]=n294;
 assign clocks[8]=n31;
 assign clocks[9]=n40;
 assign clocks[10]=l07.p7;
 assign clocks[11]=l07.p9;
 assign clocks[12]=l06.p7;
 assign clocks[13]=l06.p9;
 assign clocks[14]=l05.p9;
 assign flags[0]=n270;
 assign flags[1]=n118;
 assign flags[2]=n47;
 assign flags[3]=n173;
 assign flags[4]=n292;
 assign flags[5]=n287;
 assign flags[6]=n247;
 assign flags[7]=n232;
 assign flags[8]=n236;
 assign flags[9]=n36;
 assign flags[10]=l07.state_q[0];
 assign flags[11]=n258;
 assign flags[12]=n273;
 assign flags[13]=n252;
 assign flags[14]=n253;
 assign flags[15]=n254;
 assign flags[16]=n255;
 assign flags[17]=n60;
 assign flags[18]=n61;
 assign flags[19]=n62;
 assign flags[20]=n63;
 assign flags[21]=n85;
 assign flags[22]=n225;
 assign flags[23]=n218;
 assign flags[24]=n219;
 assign flags[25]=n220;
 assign flags[26]=n221;
endmodule
`default_nettype wire
