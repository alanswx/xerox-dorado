`timescale 1ns/1ps
module r_file_ports_reference(input wire fixture_load,input wire [9215:0] fixture_state,
 input wire advance,input wire [1:0] write_n,input wire [31:0] address,
 input wire [3:0] select_n,input wire [15:0] write_data,
 output wire [15:0] read_data,output wire [1:0] read_parity,
 output wire [9215:0] state_q,output wire [1:0] generated_parity);
 wire [27:0] hp={1'b0,(write_n[0]|!advance),write_data[7:0],select_n[1:0],address[15:0]};
 wire [27:0] lp={1'b0,(write_n[1]|!advance),write_data[15:8],select_n[3:2],address[31:16]};
 wire [9:0] hf,lf;wire [1:0] hc,lc;
 r_file_ports_proch h(fixture_load,fixture_state[4607:0],1'b0,1'b0,1'b0,hp,state_q[4607:0],hc,hf);
 r_file_ports_procl l(fixture_load,fixture_state[9215:4608],1'b0,1'b0,1'b0,lp,state_q[9215:4608],lc,lf);
 assign read_data={lf[7:0],hf[7:0]};assign read_parity={lf[8],hf[8]};
 assign generated_parity={lf[9],hf[9]};
endmodule
