// Generated physical combinational cone; no sequential clock emulation.

// comb_MC10100 -- Quad 2-Input NOR with Strobe
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 25 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10100 (
    input  wire p4,
    input  wire p5,
    input  wire p9,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p12,
    input  wire p13,
    output wire p15
);

  // Quad 2-Input NOR with STROBE (cells/PARTS.md). Pin 9 is the strobe and
  // it is an input to all four NORs: [G (4 5 9)>(2), (6 7 9)>(3),
  // (10 11 9)>(14), (12 13 9)>(15)]. A high strobe forces every output low,
  // which is what an extra OR input into a NOR does.

  // The COMMON pin feeds EVERY gate. EclDict names it once, on the first
  // gate, and the [G] summary spells it out per gate -- this cell used to
  // wire it into the first gate only. Found by Tim, then by
  // tools/sil_check_cells.py across the whole library.

  assign p2  = ~(p4  | p5  | p9);
  assign p3  = ~(p6  | p7  | p9);
  assign p14 = ~(p10 | p11 | p9);
  assign p15 = ~(p12 | p13 | p9);

endmodule

`default_nettype wire

// comb_MC10101 -- Quad OR/NOR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 54 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10101 (
    input  wire p4,
    input  wire p12,
    output wire p2,
    output wire p5,
    input  wire p7,
    output wire p3,
    output wire p6,
    input  wire p10,
    output wire p14,
    output wire p11,
    input  wire p13,
    output wire p15,
    output wire p9
);

  // Quad OR/NOR with a COMMON INPUT on pin 12 -- the data sheet labels that
  // pin exactly that (DoradoDocs/datasheets/MC10101.pdf), and [G] puts it in
  // every gate: (4 12)>(2 5), (7 12)>(3 6), (10 12)>(11 14), (12 13)>(9 15).
  //
  // Polarity by the confirmed rule: role `OUT` is the inverting output, `o`
  // the non-inverting one. The sheet's own labels agree -- pin 2 is
  // A-bar-OUT, pin 5 is AOUT.

  // The COMMON pin feeds EVERY gate. EclDict names it once, on the first
  // gate, and the [G] summary spells it out per gate -- this cell used to
  // wire it into the first gate only. Found by Tim, then by
  // tools/sil_check_cells.py across the whole library.

  assign p2  = ~(p4  | p12);   assign p5  = (p4  | p12);
  assign p3  = ~(p7  | p12);   assign p6  = (p7  | p12);
  assign p14 = ~(p10 | p12);   assign p11 = (p10 | p12);
  assign p15 = ~(p13 | p12);   assign p9  = (p13 | p12);

endmodule

`default_nettype wire

// comb_MC10102 -- Quad 2-Input NOR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 57 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10102 (
    input  wire p4,
    input  wire p5,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p12,
    input  wire p13,
    output wire p15,
    output wire p9,
    input  wire p1,
    input  wire p16
);

  assign p2 = ~(p4 | p5);
  assign p3 = ~(p6 | p7);
  assign p14 = ~(p10 | p11);
  assign p15 = ~(p12 | p13);
  assign p9 = (p12 | p13);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p1, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC10103 -- Quad 2-Input OR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 51 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

// PIN 9 IS THE ODD ONE, and it was wrong here until 2026-08-16. The MECL
// Pocket Book says of this part: "One of the gates has both OR and NOR
// outputs", and EclDict marks that gate `c,IN,12,13 > c,OUT,9 > c,o,15` --
// two different role letters, so two different senses. This cell gave pins 9
// and 15 the same expression, which cannot be right whichever way round they
// go. Pin 9 is taken as the NOR by the rule documented in
// docs/verilog-handoff.md, which the mirror-image MC10102 supports.

`default_nettype none

module comb_MC10103 (
    input  wire p4,
    input  wire p5,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p12,
    input  wire p13,
    output wire p9,
    output wire p15,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p1,
    input  wire p16
);

  assign p2 = (p4 | p5);
  assign p3 = (p6 | p7);
  assign p9 = ~(p12 | p13);   // see the note above: this gate has BOTH senses
  assign p15 = (p12 | p13);
  assign p14 = (p10 | p11);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p1, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC10104 -- Quad 2-Input AND
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 46 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10104 (
    input  wire p4,
    input  wire p5,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p12,
    input  wire p13,
    output wire p15,
    output wire p9,
    input  wire p16
);

  assign p2 = (p4 & p5);
  assign p3 = (p6 & p7);
  assign p14 = (p10 & p11);
  assign p15 = (p12 & p13);
  // Gate d brings out BOTH senses, and this gave them the same expression --
  // the same fault the handoff records for cell_MC10103, which "gave one
  // gate's two outputs the same expression, which cannot be right for a gate
  // the datasheet says has both". EclDict marks p15 `OUT` and p9 `o`.
  //
  // WHICH way round is not the blanket "OUT is inverting" rule: MC10102 and
  // MC10104 SHARE one dictionary pin block and differ only by part name, so
  // the name decides the function and `o` is its complement -- MC10102 is the
  // NOR (p15 = NOR, p9 = OR) and MC10104 is the AND (p15 = AND, p9 = NAND).
  // PARC's usage agrees: of the eleven packages that use both, eight name
  // them as a complementary pair and seven put the PRIMED name on p9
  // (DispM c12, IFU d15, MemX g13/i20/j17/k19/l17). The eighth, MemX l18,
  // is reversed -- a gate fed already-inverted inputs, named for its
  // function rather than its pin sense, which is the caveat the handoff
  // already records for MC10212.
  assign p9 = ~(p12 & p13);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC10105 -- Triple 2-3-2 Input OR/NOR
//
// Pins: PARC's EclDict/TtlDict.Analyze. Used in 34 package position(s).

//
// POLARITY, confirmed from the datasheets (2026-08-16): EclDict's role `OUT`
// is the INVERTING (NOR) output and `o` the non-inverting (OR) one. Motorola's
// MC10101 sheet labels the four `OUT` pins A-bar-OUT..D-bar-OUT and the four
// `o` pins AOUT..DOUT; MC10212's labels its `OUT` pins 3,4,12,13 with bars and
// its `o` pins 2,14 without. Eight gates, two parts, unanimous. See
// docs/verilog-handoff.md.

`default_nettype none

module comb_MC10105 (
    input  wire p4,
    input  wire p5,
    output wire p3,
    output wire p2,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    output wire p6,
    output wire p7,
    input  wire p12,
    input  wire p13,
    output wire p14,
    output wire p15,
    input  wire p1
);

  // EclDict: a,OUT,3 > a,o,2 | b,OUT,6 > b,o,7 | c,OUT,14 > c,o,15.
  // OUT is the NOR. These were the other way round until the datasheets
  // settled it -- 34 packages, 31 of them in the machine.
  assign p3  = ~(p4 | p5);          assign p2  =  (p4 | p5);
  assign p6  = ~(p9 | p10 | p11);   assign p7  =  (p9 | p10 | p11);
  assign p14 = ~(p12 | p13);        assign p15 =  (p12 | p13);


  wire _unused_pins = &{1'b0, p1, 1'b0};

endmodule

`default_nettype wire

// comb_MC10106 -- Triple 4-3-3 Input NOR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 12 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10106 (
    input  wire p4,
    input  wire p5,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    output wire p2,
    input  wire p12,
    input  wire p13,
    input  wire p14,
    output wire p15
);

  assign p3 = ~(p4 | p5 | p6 | p7);
  assign p2 = ~(p9 | p10 | p11);
  assign p15 = ~(p12 | p13 | p14);

endmodule

`default_nettype wire

// comb_MC10107 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 5 package position(s) across the sixteen boards.
//
// Triple 2-Input Exclusive OR / Exclusive NOR Gate (MECL 10K, DL122 rev 7
// p.257). The data book prints both outputs of each gate:
//
//     3 = (4 * 5bar) + (4bar * 5)      the OR  output -- Exclusive OR
//     2 = (4 * 5)    + (4bar * 5bar)   the NOR output -- Exclusive NOR
//
// Which of the pair is which follows the polarity rule settled from the
// datasheets and recorded in docs/verilog-handoff.md: EclDict's role `OUT` is
// the INVERTING output and `o` the non-inverting one. Here that is
// `a,OUT,2 > a,o,3`, `b,OUT,11 > b,o,10`, `c,OUT,12 > c,o,13`.
//
// [G (4 5)>(2 3), (7 9)>(10 11), (14 15)>(12 13)]

`default_nettype none

module comb_MC10107 (
    output wire p2,  // a_OUT
    output wire p3,  // a_OUTN
    input  wire p4,  // a_IN0
    input  wire p5,  // a_IN1
    input  wire p6,  // (no name in EclDict)
    input  wire p7,  // b_IN0
    input  wire p9,  // b_IN1
    output wire p10,  // b_OUTN
    output wire p11,  // b_OUT
    output wire p12,  // c_OUT
    output wire p13,  // c_OUTN
    input  wire p14,  // c_IN0
    input  wire p15// c_IN1
);

  assign p2  = ~(p4  ^ p5);    assign p3  = p4  ^ p5;
  assign p11 = ~(p7  ^ p9);    assign p10 = p7  ^ p9;
  assign p12 = ~(p14 ^ p15);   assign p13 = p14 ^ p15;
endmodule

`default_nettype wire

// comb_MC10109 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 21 package position(s) across the sixteen boards.
//
// Dual 4-5-Input OR/NOR (MECL 10K), and the datasheet notes it is pin
// compatible with the MECL III MC1660 -- which the dictionary agrees with,
// giving both parts the same roles at the same pins.
//
// EclDict: a,IN,4,5,6,7 > a,OUT,3 > a,o,2
//          b,IN,9,10,11,12,13 > b,OUT,14 > b,o,15
//
// POLARITY, confirmed from the datasheets (2026-08-16): EclDict's role `OUT`
// is the INVERTING (NOR) output and `o` the non-inverting (OR) one. Motorola's
// MC10101 sheet labels the four `OUT` pins A-bar-OUT..D-bar-OUT and the four
// `o` pins AOUT..DOUT; MC10212's labels its `OUT` pins 3,4,12,13 with bars and
// its `o` pins 2,14 without. Eight gates, two parts, unanimous. See
// docs/verilog-handoff.md.

`default_nettype none

module comb_MC10109 (
    output wire p2,  // a_OUTN
    output wire p3,  // a_OUT
    input  wire p4,  // a_IN0
    input  wire p5,  // a_IN1
    input  wire p6,  // a_IN2
    input  wire p7,  // a_IN3
    input  wire p8,  // (no name in EclDict)
    input  wire p9,  // b_IN0
    input  wire p10,  // b_IN1
    input  wire p11,  // b_IN2
    input  wire p12,  // b_IN3
    input  wire p13,  // b_IN4
    output wire p14,  // b_OUT
    output wire p15// b_OUTN
);

  wire a = p4 | p5 | p6 | p7;
  wire b = p9 | p10 | p11 | p12 | p13;
  assign p3  = ~a;   // a_OUT   NOR
  assign p2  =  a;   // a_OUTN  OR
  assign p14 = ~b;   // b_OUT   NOR
  assign p15 =  b;   // b_OUTN  OR

  wire _unused_pins = &{1'b0, p8, 1'b0};
endmodule

`default_nettype wire

// comb_MC10113 -- Quad Exclusive OR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 55 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10113 (
    input  wire p4,
    input  wire p5,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p12,
    input  wire p13,
    output wire p15,
    input  wire p1,
    input  wire p9
);

  // Quad Exclusive OR Gate, MECL 10K, data book DL122 rev 7 p.269:
  //
  //   "The MC10113 is a quad Exclusive OR gate, with an ENABLE COMMON TO ALL
  //    FOUR GATES. The outputs may be wire-ORed together to perform a 4-bit
  //    comparison function (A = B). The enable is ACTIVE LOW."
  //
  // Pin 9 is that enable, and EclDict says so twice: the pin block names it
  // once, on gate a (`a,e,9`), and the gate summary spells it out --
  //
  //   [G (4 5)>2, (6 7)>3, (10 11)>14, (12 13)>15]
  //   [G 9>(2 3 14 15)]
  //
  // -- which is Tim's common-pin trap exactly. It went unnoticed longer than
  // it should have because sil_check_cells only read a part's FIRST [G] line,
  // and the enable is stated in the second.
  //
  // Disabled forces the output LOW, which is what makes the wire-OR
  // comparison work: any bit that differs pulls the shared net high.
  wire en = ~p9;

  assign p2  = en & (p4  ^ p5);
  assign p3  = en & (p6  ^ p7);
  assign p14 = en & (p10 ^ p11);
  assign p15 = en & (p12 ^ p13);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p1, 1'b0};

endmodule

`default_nettype wire

// comb_MC10117 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 28 package position(s) across the sixteen boards.
//
// Dual 2-Wide 2-3-Input OR-AND/OR-AND-INVERT (MECL 10K). Datasheet:
// DoradoDocs/datasheets/MC10117.pdf -- "designed for use in data control,
// such as digital multiplexing or data distribution. Pin 9 is common to both
// gates."
//
// Each half ANDs two OR groups. Pin 9 joins the "2" group of BOTH halves,
// which is what makes it 2-3-input: one group of two, one of three.
//
//   AOUT (15 in the dictionary's terms, pin 2 here) = (A1IN) AND (A2IN)
//        A1IN = pins 4,5      A2IN = pins 6,7 and the common 9
//   BOUT = (B1IN) AND (B2IN)
//        B1IN = pins 12,13    B2IN = pins 10,11 and the common 9
//
// THIS PART SETTLED THE `u`/`v` ROLE LETTERS, which the OR/NOR rule does not
// reach. EclDict gives the second half `c,u,14 > c,v,15`, and the datasheet
// labels pin 14 B-bar-OUT and pin 15 BOUT -- so `u` is the INVERTING output
// and `v` the non-inverting, exactly as `OUT`/`o` are on the first half
// (`b,OUT,3 > b,o,2`, and the sheet has pin 3 barred, pin 2 not).

`default_nettype none

module comb_MC10117 (
    output wire p2,  // a_OUTN
    output wire p3,  // a_OUT
    input  wire p4,  // a
    input  wire p5,  // a
    input  wire p6,  // a_IN0
    input  wire p7,  // a_IN1
    input  wire p9,  // a_C
    input  wire p10,  // e
    input  wire p11,  // e
    input  wire p12,  // s
    input  wire p13,  // s
    output wire p14,  // u
    output wire p15// v
);

  wire a = (p4  | p5) & (p6  | p7  | p9);   // A1IN AND A2IN
  wire b = (p12 | p13) & (p10 | p11 | p9);   // B1IN AND B2IN

  assign p2  =  a;   // AOUT      (role o)
  assign p3  = ~a;   // A-bar-OUT (role OUT)
  assign p15 =  b;   // BOUT      (role v)
  assign p14 = ~b;   // B-bar-OUT (role u)
endmodule

`default_nettype wire

// comb_MC10119 -- 4-Wide 4-3-3-3-Input OR-AND
//
// Pins: PARC's EclDict.Analyze. Function: the logic diagram in
// DoradoDocs/datasheets/Motorola_MECL_DataBook_1978.pdf p.3-16.
// Used in 10 package position(s).
//
// PIN 10 IS SHARED BY TWO OR GROUPS -- the same trap as MC10121, and the
// dictionary says so if you count: it gives pin 10 the role `c' (common)
// while the four groups it names hold only 4+2+3+3 = 12 slots, and the part
// is a 4-3-3-3, which is 13. The thirteenth is pin 10 counted twice. The
// data book's logic diagram draws the junction dot on pin 10 fanning into
// both the (7,9) and the (11,12) gate, and its electrical table lists pin 10's
// input current on its own line -- 310 uA against 245 uA for every other
// input -- because it drives two gates.
//
// Modelling it as a standalone AND term instead (`... & p10') is not a
// near-miss: it forces the whole output low whenever pin 10 is low. On ProcH
// b17/c17 that pin is FA=0', so every microinstruction with FA=0 -- PARC's own
// Nop among them -- drove QshiftL'/QshiftR' asserted, which is PARALLEL ENTRY
// on the MC10141, and Q was reloaded from a dead B bus every cycle.

`default_nettype none

module comb_MC10119 (
    input  wire p3,
    input  wire p4,
    input  wire p5,
    input  wire p6,
    input  wire p7,
    input  wire p9,
    input  wire p11,
    input  wire p12,
    input  wire p13,
    input  wire p14,
    input  wire p15,
    input  wire p10,
    output wire p2
);

  // OR each input group, then AND the groups (the part's own shape).
  assign p2 = (p3 | p4  | p5  | p6 ) & (p7  | p9  | p10) &
              (p10 | p11 | p12)       & (p13 | p14 | p15);


endmodule

`default_nettype wire

// comb_MC10121 -- 4-Wide OR-AND/OR-AND-INVERT
//
// Pins: PARC's EclDict.Analyze. Function: MECL Pocket Book (cells/PARTS.md).
// Used in 44 package position(s).

`default_nettype none

module comb_MC10121 (
    input  wire p7,
    input  wire p9,
    input  wire p11,
    input  wire p12,
    input  wire p4,
    input  wire p5,
    input  wire p6,
    input  wire p13,
    input  wire p14,
    input  wire p15,
    input  wire p10,
    output wire p2,
    output wire p3
);

  // Four 3-input OR groups feeding one AND -- the part's own shape.
  //
  // PIN 10 IS SHARED BY TWO GROUPS, which is Tim's common-pin class again.
  // The data sheet's DIP pin assignment labels it `A2IN, A3IN` (the same way
  // MC10117 labels its pin 9 `A2IN, B2IN`), and EclDict says it the way it
  // always says a common input -- once, under role `c`:
  //
  //   a,IN,7,9 > a,a,11,12 > a,c,10 > a,e,4,5,6 > a,s,13,14,15 > a,OUT,2 > a,o,3
  //
  // so the groups are {4,5,6}, {7,9,10}, {10,11,12}, {13,14,15}. This used to
  // AND pin 10 in as a term of its own, which made the gate false whenever
  // that one input was low -- on ContB l03 that is `IMRHPE'`, and l03 gates
  // the MIR clock.
  wire y = (p4 | p5 | p6) & (p7 | p9 | p10) & (p10 | p11 | p12) & (p13 | p14 | p15);

  // OR-AND on pin 2, OR-AND-INVERT on pin 3 -- and note this is the OPPOSITE
  // of the handoff's "role `OUT` is the INVERTING output" rule, which puts
  // `OUT` on pin 2 here. The rule holds for the OR/NOR family it was derived
  // from and does not generalise; see docs/verilog-handoff.md.
  //
  // Settled from the data book's LOGIC DIAGRAM, by coordinates rather than by
  // eye, because the pin labels' overbars are in a font the PDF does not
  // embed and render as empty boxes. `pdftotext -bbox` puts the label `2` at
  // y=322.8..330.2 pt and `3` at y=332.4..339.8, and rasterising that strip
  // puts the PLAIN output arrow at y=324.9 and the BUBBLED one at y=335.2.
  // Two independent parts were checked the same way; MC10104's gate d has the
  // bubble on pin 9, which is its `o` pin.
  //
  // PARC's own net naming says the reverse and is NOT evidence: nine packages
  // name pin 2 with the primed name, but nine packages also prime pin 9 of an
  // MC10102, whose `OUT` pin 15 is certainly the NOR. A net is named for the
  // sense the designer treats as primary, not for which pin inverts -- the
  // caveat the handoff already records for MC10212.
  assign p2  =  y;
  assign p3 = ~y;


endmodule

`default_nettype wire

// comb_MC10158 -- Quad 2-Input Multiplexer (non-inverting)
//
// Pin numbers/names: PARC's EclDict.Analyze (what ANALYZE used to check the
// boards). Function: Motorola MECL Pocket Book -- see cells/PARTS.md.
// Used in 88 package position(s) across the sixteen Dorado boards.
//
// MECL is positive logic. Unused inputs have on-chip pulldowns (they read
// LOW), which is why the boards leave so many pins unconnected; Verilator
// treats an unconnected input as 0, which matches.
//
// The select POLARITY is confirmed by the MC10159 data sheet
// (DoradoDocs/datasheets/MC10159.pdf), which shares this pinout: SELECT high
// enables D00/D10/D20/D30 (pins 6, 4, 13, 11), low enables D01/D11/D21/D31.
// This part has NO enable -- the dictionary gives it `SB` and no `E'` -- so
// the disabled-outputs-low row of that table does not apply here.
// Historical note, kept because the comment used to ask to VERIFY it: The MECL Pocket
// Book gives the part as "Quad 2-Input Multiplexer" without reproducing the
// truth table here. If a board's behaviour disagrees, this is the line to
// check first, and the inverting sibling MC10159 shares the convention.

`default_nettype none

module comb_MC10158 (
    input  wire p5,  // D0,
    input  wire p3,  // D1,
    input  wire p12,  // D2,
    input  wire p10,  // D3,
    input  wire p6,  // B0,
    input  wire p4,  // B1,
    input  wire p13,  // B2,
    input  wire p11,  // B3,
    input  wire p9,   // SB select,
    output wire p1,  // Q0,
    output wire p2,  // Q1,
    output wire p15,  // Q2,
    output wire p14// Q3
);

  // Quad 2-input multiplexer, NON-inverting outputs.
  // SB selects which input reaches Q; high selects the B inputs.
  assign p1  = p9 ? p6  : p5;
  assign p2  = p9 ? p4  : p3;
  assign p15 = p9 ? p13 : p12;
  assign p14 = p9 ? p11 : p10;

endmodule

`default_nettype wire

// comb_MC10159 -- Quad 2-Input Multiplexer (inverting)
//
// Pin numbers/names: PARC's EclDict.Analyze (what ANALYZE used to check the
// boards). Function: Motorola MECL Pocket Book -- see cells/PARTS.md.
// Used in 67 package position(s) across the sixteen Dorado boards, 25 of
// them on ContA.
//
// MECL is positive logic. Unused inputs have on-chip pulldowns (they read
// LOW), which is why the boards leave so many pins unconnected; Verilator
// treats an unconnected input as 0, which matches.
//
// SETTLED from the data sheet, DoradoDocs/datasheets/MC10159.pdf, whose truth
// table this now matches on all five rows:
//
//     Enable  Select  D0  D1   Q
//        L       L     X   L   H          "Input levels are inverted at the
//        L       L     X   H   L           output"; SELECT high enables D00,
//        L       H     L   X   H           D10, D20, D30 (pins 6, 4, 13, 11)
//        L       H     H   X   L           and low enables D01, D11, D21, D31
//        H       X     X   X   L           (pins 5, 3, 12, 10)
//
// which confirms the select polarity the comment here used to ask to VERIFY:
// SB high does route the B inputs.
//
// THE LAST ROW IS THE ONE THAT WAS WRONG, and it matters more than it looks.
// A DISABLED PART DRIVES ITS OUTPUTS LOW, not high -- that is the whole point
// of an enable on a MECL part, because the outputs are open emitters tied
// together into a wired-OR and a disabled driver has to contribute NOTHING.
// This cell had `~(en & mux)`, which reads 1 when disabled and so jammed every
// bus it sat on to all ones. Found on ContA g22 and i21, which wired-OR into
// TNIA beside the MC10121 Link selectors: those twelve selectors carried
// Link[4:15] EXACTLY RIGHT and the answer was still wrong, because two
// disabled multiplexers were holding eight of the twelve bits high.

`default_nettype none

module comb_MC10159 (
    input  wire p5,  // D0,
    input  wire p3,  // D1,
    input  wire p12,  // D2,
    input  wire p10,  // D3,
    input  wire p6,  // B0,
    input  wire p4,  // B1,
    input  wire p13,  // B2,
    input  wire p11,  // B3,
    input  wire p9,   // SB select,
    input  wire p7,   // E' enable, active LOW,
    output wire p1,  // Q0',
    output wire p2,  // Q1',
    output wire p15,  // Q2',
    output wire p14// Q3'
);

  // Quad 2-input multiplexer, INVERTING outputs, with active-low enable.
  // Disabled, every output is LOW -- see the truth table above.
  wire en = ~p7;
  assign p1  = en & ~(p9 ? p6  : p5);
  assign p2  = en & ~(p9 ? p4  : p3);
  assign p15 = en & ~(p9 ? p13 : p12);
  assign p14 = en & ~(p9 ? p11 : p10);

endmodule

`default_nettype wire

// comb_MC10161 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 21 package position(s) across the sixteen boards.
//
// Binary to 1-8 Decoder (LOW), per cells/PARTS.md. EclDict names every pin,
// so this needs no interpretation of output polarity: `S1`=7, `S2`=9, `S4`=14
// are the binary select with their own weights; `Q0'`..`Q7'` are the eight
// outputs, PRIMED because the part is the low-output variant -- the selected
// line goes LOW and the other seven stay HIGH; `E'` appears at both 2 and 15,
// two active-low enables that must both be low.
//
// Disabled, every output is high. That is the reset state a decoder wants and
// it falls out of the same expression.

`default_nettype none

module comb_MC10161 (
    input  wire p2,  // E'
    output wire p3,  // Q3'
    output wire p4,  // Q2'
    output wire p5,  // Q1'
    output wire p6,  // Q0'
    input  wire p7,  // S1
    input  wire p9,  // S2
    output wire p10,  // Q7'
    output wire p11,  // Q6'
    output wire p12,  // Q5'
    output wire p13,  // Q4'
    input  wire p14,  // S4
    input  wire p15// E'
);

  wire [2:0] sel = {p14, p9, p7};          // S4, S2, S1
  wire       en  = ~(p2 | p15);            // both E' low
  wire [7:0] q   = en ? ~(8'd1 << sel) : 8'hFF;

  assign p6  = q[0];   // Q0'
  assign p5  = q[1];   // Q1'
  assign p4  = q[2];   // Q2'
  assign p3  = q[3];   // Q3'
  assign p13 = q[4];   // Q4'
  assign p12 = q[5];   // Q5'
  assign p11 = q[6];   // Q6'
  assign p10 = q[7];   // Q7'
endmodule

`default_nettype wire

// comb_MC10166 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 6 package position(s) across the sixteen boards.
//
// 5-Bit Magnitude Comparator (MECL 10K, data book DL122 rev 7 p.363).
//
// "Two outputs are provided: A < B and A > B. A = B can be obtained by NORing
// the two outputs with an additional gate. A high level on the enable function
// forces both outputs low."
//
//   TRUTH TABLE
//     E   A vs B          A<B   A>B
//     H   X                L     L
//     L   Word A = Word B  L     L
//     L   Word A > Word B  L     H
//     L   Word A < Word B  H     L
//
// EclDict names the pins X/Y where the data book says A/B, and MSB-FIRST as
// PARC does everywhere: its `X0` is pin 9, which the data book's own pin
// assignment calls A4 -- the most significant bit of the five.
//
//   X0..X4 = 9, 12, 13, 6, 5      (data book A4, A3, A2, A1, A0)
//   Y0..Y4 = 10, 11, 14, 7, 4     (data book B4, B3, B2, B1, B0)
//   X>Y = 2, X<Y = 3, E' = 15

`default_nettype none

module comb_MC10166 (
    output wire p2,  // (no name in EclDict)
    output wire p3,  // X<Y
    input  wire p4,  // Y4
    input  wire p5,  // X4
    input  wire p6,  // X3
    input  wire p7,  // Y3
    input  wire p9,  // X0
    input  wire p10,  // Y0
    input  wire p11,  // Y1
    input  wire p12,  // X1
    input  wire p13,  // X2
    input  wire p14,  // Y2
    input  wire p15// E'
);

  wire [4:0] x = {p9,  p12, p13, p6, p5};   // MSB first
  wire [4:0] y = {p10, p11, p14, p7, p4};
  wire       en = ~p15;                     // E high forces both outputs low

  assign p2 = en & (x > y);                 // X>Y
  assign p3 = en & (x < y);                 // X<Y
endmodule

`default_nettype wire

// comb_MC10170 -- 9-2-Bit Parity Generator/Checker
//
// Pins: PARC's EclDict.Analyze. Function: the Motorola data sheet, 1978 MECL
// book p.123 (DoradoDocs/datasheets/Motorola_MECL_DataBook_1978.pdf):
//
//   "The MC10170/MC10570 is an 11-bit parity circuit, which is segmented into
//    9 data bits and 2 control bits. Output A generates odd parity on 9 bits
//    ... The Control Inputs can be used to expand parity to larger numbers of
//    bits with minimal delay or can be used to generate even parity."
//
//        Sum of D inputs at High Level | Odd Parity A | Even Parity B
//                    Even              |     Low      |     High
//                    Odd               |     High     |     Low
//
// THE CONTROL INPUTS REACH PIN 15 ONLY, and this cell used to XOR them into
// BOTH outputs. EclDict says so in as many words --
//
//     [G (3 4 5 6 7 9 10 11 12)>2]  [G (3 4 5 6 7 9 10 11 12)>15]  [G (13 14)>15]
//
// -- and the cascade is the whole point of the part: ContB j21 feeds j20's
// pin 13 to make an 18-bit check out of two 9-bit ones, and ContA e19 feeds
// e18's pin 14 the same way. With the controls folded into pin 2 as well, the
// LOCAL parity was wrong wherever a package cascades, and eleven of PARC's
// thirteen IRTable microinstructions failed the IM right-half parity check
// that the real machine passes.
//
// Used in 41 package position(s).

`default_nettype none

// Compatibility debt: the old B-output inversion remains the default for
// boards whose dependent parity paths have not yet been reconciled (see
// docs/verilog-handoff.md). It is NOT a physical chip option. DskEth's
// checkers and MemD's storage byte-parity generator select 0, the datasheet
// function, with regressions for their actual board connections. The IM read
// checkers and write-parity generator now also select the physical function;
// the legacy inversion stopped the original Bootstrap at its first address.
// ProcH d13 also selects the physical function: its XOR detects signed
// overflow, and the extra inversion reversed Cedar's signed-jump condition.
module comb_MC10170 #(parameter LEGACY_B_INVERT = 1) (
    input  wire p3,
    input  wire p4,
    input  wire p5,
    input  wire p6,
    input  wire p7,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    input  wire p12,
    input  wire p13,
    input  wire p14,
    output wire p2,
    output wire p15,
    input  wire p1,
    input  wire p8,
    input  wire p16
);

  // Nine data inputs (3-7, 9-12); the two control inputs are 13 and 14.
  wire par9 = p3 ^ p4 ^ p5 ^ p6 ^ p7 ^ p9 ^ p10 ^ p11 ^ p12;
  assign p2  = par9;                       // A: ODD parity, the nine data bits
  // Datasheet logic diagram: no output bubble. The table's EVEN function
  // assumes control 13 HIGH and 14 LOW, which supply the inversion already.
  assign p15 = par9 ^ p13 ^ p14 ^ (LEGACY_B_INVERT != 0);


  // Board-wired pins not named above (power and the like)
  wire _unused_pins = &{1'b0, p1, p8, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC10174 -- Dual 4-to-1 Multiplexer
//
// Pin numbers/names: PARC's EclDict.Analyze (what ANALYZE used to check the
// boards). Function: Motorola MECL Pocket Book -- see cells/PARTS.md.
// Used in 106 package position(s) across the sixteen Dorado boards.
//
// MECL is positive logic. Unused inputs have on-chip pulldowns (they read
// LOW), which is why the boards leave so many pins unconnected; Verilator
// treats an unconnected input as 0, which matches.

`default_nettype none

module comb_MC10174 (
    input  wire p3,   // X0,
    input  wire p5,   // X1,
    input  wire p4,   // X2,
    input  wire p6,   // X3,
    input  wire p13,  // Y0,
    input  wire p11,  // Y1,
    input  wire p12,  // Y2,
    input  wire p10,  // Y3,
    input  wire p7,   // S1 select bit 0,
    input  wire p9,   // S2 select bit 1,
    input  wire p14,  // E' enable, active LOW,
    output wire p2,   // OX,
    output wire p15,// OY,
    // Pins the boards wire that the dictionary does not name --
    // power (VEE/VCC on a 16-pin MECL package) and the like,
    // declared so every board connection lands somewhere.
    input  wire p1,
    input  wire p16
);

  // Dual 4-to-1 multiplexer, common select and common active-low enable.
  wire [1:0] sel = {p9, p7};                       // S2,S1
  wire       en  = ~p14;                           // E' active low
  assign p2  = en & ((sel == 2'd0) ? p3  :
                     (sel == 2'd1) ? p5  :
                     (sel == 2'd2) ? p4  : p6);
  assign p15 = en & ((sel == 2'd0) ? p13 :
                     (sel == 2'd1) ? p11 :
                     (sel == 2'd2) ? p12 : p10);

  wire _unused_pins = &{1'b0, p1, p16, 1'b0};
endmodule

`default_nettype wire

// comb_MC10182 -- 2-Bit Arithmetic Logic Unit / Function Generator
//
// Pin numbers/names: PARC's EclDict.Analyze (what ANALYZE used to check the
// boards). Function: DoradoDocs/datasheets/MC10182.pdf (also in the 1978
// MECL data book) -- 4 logic and 4 arithmetic operations on two 2-bit
// words, full internal carry, group carry propagate/generate for an
// MC10179 second-order lookahead.
//
// Used in 3 package positions across the sixteen boards -- ProcL j17, k17,
// l17 -- which together are THE STACK-POINTER ADDER: StkP + RSTK[1:3]'s
// signed delta into StkWadr, through the i16/i17 MC10173 muxes. Left a
// skeleton, StkP could never adjust: pushes and pops moved nothing, Initial
// arrived at DORETURN with the stack pointer still at its STKINITL value
// (offset 0 = empty), and the underflow check held the machine forever --
// the c01 park, 3.57M microinstructions on one address.
//
// Pin map, dictionary name = datasheet name (dict is MSB-first, so its
// bit 0 is the datasheet's bit 1):
//   dict D0 = A1 (p12), D1 = A0 (p5), E0 = B1 (p11), E1 = B0 (p6)
//   dict H0 = F1 (p14), H1 = F0 (p4)
//   dict CIN = Cn (p13), COUT = Cn+2 (p2)
//   dict F0 = S1 (p9), F1 = S0 (p10), M = M (p7)
//   dict Gg = GG (p3), Pg = PG (p15)
//
// Function select (datasheet, positive logic):
//   S1 S0 | M high (logic)   | M low (arithmetic)
//    L  L | F = A XOR B      | F = A  plus B  plus Cn
//    L  H | F = A XNOR B     | F = ~A plus B  plus Cn
//    H  L | F = A AND B      | F = A  plus ~B plus Cn
//    H  H | F = A OR B       | F = A times 2 (A plus A plus Cn)
//
// All three Dorado positions leave S0, S1 and M unconnected; MECL unused
// inputs read LOW, so the part is a plain 2-bit adder here.

`default_nettype none

module comb_MC10182 (
    input  wire p5,   // A0  (dict D1)
    input  wire p12,  // A1  (dict D0)
    input  wire p6,   // B0  (dict E1)
    input  wire p11,  // B1  (dict E0)
    input  wire p13,  // Cn  (dict CIN)
    input  wire p7,   // M
    input  wire p9,   // S1  (dict F0)
    input  wire p10,  // S0  (dict F1)
    output wire p4,   // F0  (dict H1)
    output wire p14,  // F1  (dict H0)
    output wire p2,   // Cn+2 (dict COUT)
    output wire p3,   // GG  (dict Gg)
    output wire p15,  // PG  (dict Pg)
    // Power pins, declared so every board connection lands somewhere.
    input  wire p1,
    input  wire p8,
    input  wire p16
);

  wire [1:0] A = {p12, p5};
  wire [1:0] B = {p11, p6};

  // Arithmetic operand transforms per (S1,S0); see the table above.
  wire [1:0] Aop = (~p9 & p10) ? ~A : A;
  wire [1:0] Bop = (p9 & ~p10) ? ~B :
                   (p9 &  p10) ?  A : B;

  // Ripple with per-bit propagate/generate, which also yields PG/GG for
  // the MC10179 lookahead exactly as the data sheet defines them.
  wire g0 = Aop[0] & Bop[0], pr0 = Aop[0] | Bop[0];
  wire g1 = Aop[1] & Bop[1], pr1 = Aop[1] | Bop[1];
  wire c1 = g0 | (pr0 & p13);

  wire [1:0] sum = {Aop[1] ^ Bop[1] ^ c1, Aop[0] ^ Bop[0] ^ p13};

  // Logic mode (M high): no carry participates.
  wire [1:0] flog = (~p9 & ~p10) ?  (A ^ B)  :
                    (~p9 &  p10) ? ~(A ^ B)  :
                    ( p9 & ~p10) ?  (A & B)  :
                                    (A | B);

  wire [1:0] F = p7 ? flog : sum;

  assign p4  = F[0];
  assign p14 = F[1];
  // Cn+2 and the group terms are arithmetic-path outputs; the data sheet
  // gates the internal carry on M low. All Dorado positions hold M low.
  assign p2  = ~p7 & (g1 | (pr1 & c1));
  assign p3  = g1 | (pr1 & g0);         // GG
  assign p15 = pr1 & pr0;               // PG

  wire _unused_pins = &{1'b0, p1, p8, p16, 1'b0};
endmodule

`default_nettype wire

// comb_MC10195 -- Hex Inverter/Buffer
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 47 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10195 (
    input  wire p5,
    input  wire p9,
    output wire p2,
    input  wire p6,
    output wire p3,
    input  wire p7,
    output wire p4,
    input  wire p10,
    output wire p13,
    input  wire p11,
    output wire p14,
    input  wire p12,
    output wire p15
);

  // Hex Inverter/Buffer, and it is neither a plain inverter nor a NOR: pin 9
  // SELECTS which. EclDict names that pin twice, `Invert'` and `Buffer`, and
  // the data book's truth table (DL122 rev 7, MC10195) is an XNOR:
  //
  //     A  B  |  Q          A = pin 9, B = the per-gate input
  //     L  L  |  H          A low  -> Q = NOT B   (inverter)
  //     L  H  |  L          A high -> Q = B       (buffer)
  //     H  L  |  L
  //     H  H  |  H
  //
  // [G (5 9)>2, (6 9)>3, (7 9)>4, (9 10)>13, (9 11)>14, (9 12)>15].
  //
  // This cell had pin 9 in the first gate only AND had the function as a NOR.
  assign p2  = ~(p9 ^ p5);
  assign p3  = ~(p9 ^ p6);
  assign p4  = ~(p9 ^ p7);
  assign p13 = ~(p9 ^ p10);
  assign p14 = ~(p9 ^ p11);
  assign p15 = ~(p9 ^ p12);

endmodule

`default_nettype wire

// comb_MC10210 -- High-Speed Dual 3-Input 3-Output OR
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 42 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_MC10210 (
    input  wire p5,
    input  wire p6,
    input  wire p7,
    output wire p2,
    output wire p3,
    output wire p4,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    output wire p12,
    output wire p13,
    output wire p14,
    input  wire p1,
    input  wire p8,
    input  wire p15,
    input  wire p16
);

  assign p2 = (p5 | p6 | p7);
  assign p3 = (p5 | p6 | p7);
  assign p4 = (p5 | p6 | p7);
  assign p12 = (p9 | p10 | p11);
  assign p13 = (p9 | p10 | p11);
  assign p14 = (p9 | p10 | p11);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p1, p8, p15, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC10211 -- High-Speed Dual 3-Input 3-Output NOR
//
// Pins: PARC's EclDict/TtlDict.Analyze. Used in 29 package position(s).

`default_nettype none

module comb_MC10211 (
    input  wire p5,
    input  wire p6,
    input  wire p7,
    output wire p2,
    output wire p3,
    output wire p4,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    output wire p12,
    output wire p13,
    output wire p14,
    input  wire p15,
    input  wire p16
);

  // Same pinout as MC10210 (they share one dictionary block); this is the
  // NOR of the pair, so the three outputs per gate are inverted.
  wire a = ~(p5 | p6 | p7);
  wire b = ~(p9 | p10 | p11);
  assign p2 = a; assign p3 = a; assign p4 = a;
  assign p12 = b; assign p13 = b; assign p14 = b;


  wire _unused_pins = &{1'b0, p15, p16, 1'b0};

endmodule

`default_nettype wire

// comb_MC1660 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 28 package position(s) across the sixteen boards.
//
// Dual 4-Input OR/NOR (MECL III). Function: Motorola MECL Pocket Book,
// see cells/PARTS.md. Gate grouping from EclDict's own pin names:
// a_IN0-3 = 4,5,6,7 -> a outputs 3 and 15; b_IN0-3 = 10,11,12,13 -> b
// outputs 14 and 2.
//
// POLARITY follows the rule cell_MC10101 states and derives: the pin the
// dictionary marks `out` carries the INVERTING (NOR) sense, the pin marked
// `nout` the non-inverting (OR) sense. Here that is p3/p14 = NOR and
// p15/p2 = OR.
//
// The circuit confirms it. BaseBd g05 takes one input (p7) and drives both
// a-outputs: p3 to `BaseBd11.sil+1` and p2 to `+2`, which clock the two
// halves of the MC1690 divider. Those have to be ANTI-PHASE for a two-phase
// clock generator, and opposite senses is exactly what makes them so.
//
// Unused MECL inputs have on-chip pulldowns and read LOW; Verilator drives an
// unconnected input to 0, which matches.

`default_nettype none

module comb_MC1660 (
    output wire p2,  // a_OUTN
    output wire p3,  // a_OUT
    input  wire p4,  // a_IN0
    input  wire p5,  // a_IN1
    input  wire p6,  // a_IN2
    input  wire p7,  // a_IN3
    input  wire p8,  // (no name in EclDict)
    input  wire p10,  // b_IN0
    input  wire p11,  // b_IN1
    input  wire p12,  // b_IN2
    input  wire p13,  // b_IN3
    output wire p14,  // b_OUT
    output wire p15// b_OUTN
);

  wire a = p4 | p5 | p6 | p7;
  wire b = p10 | p11 | p12 | p13;
  // WHICH GATE OWNS WHICH OUTPUT: [G (4 5 6 7)>(2 3), (10 11 12 13)>(14 15)].
  // Gate a drives pins 2 AND 3, gate b drives 14 and 15 -- I had a driving
  // 3 and 15, and b driving 14 and 2, which crossed the two halves. Caught by
  // tools/sil_check_cells.py; it left half the clock generator's fanout stuck.
  assign p3  = ~a;      // a_OUT   (dictionary `out`  = inverting)
  assign p2  =  a;      // a_OUTN  (dictionary `nout` = non-inverting)
  assign p14 = ~b;      // b_OUT
  assign p15 =  b;      // b_OUTN

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p8, 1'b0};
endmodule

`default_nettype wire

// comb_MC1662 -- Quad 2-Input NOR (MECL III)
//
// Pins: PARC's EclDict.Analyze. Used in 33 package position(s), across ContA,
// ContB, IFU, MemC, MemX, ProcH and ProcL.
//
// THIS WAS A COPY OF cell_MC1664 AND COMPUTED OR. MC1662 and MC1664 are a
// complementary pair with the SAME pinout and the same `[G]` summary --
// `(4 5)>2, (6 7)>3, (10 11)>14, (12 13)>15` for both -- and the dictionary
// separates them by role letter alone, which here is exactly what it is for:
//
//     MC1662   a,IN,4,5 > a,OUT,2   ...   OUT -> inverting -> NOR
//     MC1664   a,IN,4,5 > a,o,2     ...   o   -> non-inverting -> OR
//
// `cell_MC1664`'s own comment already says so ("the MECL III pairing where
// MC1662 is the NOR part"); this file had not been given the other half.
// The data book is no help -- the MC1662 sheet was DELETED from DL122 rev 7.
//
// The circuit settles it too. ContB f21/g21/h20 are the IM ADDRESS
// multiplexer: `dRA.nn' = gate(TNIA.mm, SWa) wired-OR gate(SW'a, BNPC.mm)`,
// which is a 2:1 select only if the gate is a NOR. As an OR it degenerates --
// `SW'a` is 1 whenever the machine is not task-switching, so every `dRA'`
// sticks high and IM is addressed at 0 no matter what TNIA holds. That is
// precisely the symptom that led here: every jammed Write-IM landed at IM[0].

`default_nettype none

module comb_MC1662 (
    input  wire p4,
    input  wire p5,
    output wire p2,
    input  wire p6,
    input  wire p7,
    output wire p3,
    input  wire p10,
    input  wire p11,
    output wire p14,
    input  wire p12,
    input  wire p13,
    output wire p15
);

  assign p2  = ~(p4  | p5);
  assign p3  = ~(p6  | p7);
  assign p14 = ~(p10 | p11);
  assign p15 = ~(p12 | p13);


endmodule

`default_nettype wire

// comb_MC1664 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 19 package position(s) across the sixteen boards.
//
// Quad 2-Input OR (MECL III). The FUNCTION comes from the dictionary rather
// than a datasheet: all four gates have a single output each with role `o`,
// and `o` is the non-inverting sense -- so every output is an OR. That also
// matches the MECL III pairing, where MC1662 is the NOR part.
//
// EclDict: a,IN,4,5 > a,o,2 | b,IN,6,7 > b,o,3
//          c,IN,10,11 > c,o,14 | d,IN,12,13 > d,o,15
//
// POLARITY, confirmed from the datasheets (2026-08-16): EclDict's role `OUT`
// is the INVERTING (NOR) output and `o` the non-inverting (OR) one. Motorola's
// MC10101 sheet labels the four `OUT` pins A-bar-OUT..D-bar-OUT and the four
// `o` pins AOUT..DOUT; MC10212's labels its `OUT` pins 3,4,12,13 with bars and
// its `o` pins 2,14 without. Eight gates, two parts, unanimous. See
// docs/verilog-handoff.md.

`default_nettype none

module comb_MC1664 (
    output wire p2,  // a_OUTN
    output wire p3,  // b_OUTN
    input  wire p4,  // a_IN0
    input  wire p5,  // a_IN1
    input  wire p6,  // b_IN0
    input  wire p7,  // b_IN1
    input  wire p10,  // c_IN0
    input  wire p11,  // c_IN1
    input  wire p12,  // d_IN0
    input  wire p13,  // d_IN1
    output wire p14,  // c_OUTN
    output wire p15// d_OUTN
);

  assign p2  = p4  | p5;
  assign p3  = p6  | p7;
  assign p14 = p10 | p11;
  assign p15 = p12 | p13;
endmodule

`default_nettype wire

// comb_SE10210 -- High-Speed Dual 3-Input 3-Output OR (Signetics second source)
//
// Pin numbers and gate grouping: PARC's EclDict.Analyze. Function: Motorola
// MECL Pocket Book (cells/PARTS.md). Used in 162 package position(s).
//
// POLARITY RULE, stated because the dictionary does not encode it: the
// dictionary marks which PINS are outputs, not their sense -- MC10210 and
// MC10211 share one pin block and differ only in function. So polarity comes
// from the PART NAME here. Where a gate brings out BOTH outputs, the pin the
// dictionary marks `OUT` carries the inverting (NOR) sense and the pin marked
// `o` the non-inverting (OR) sense -- read off MC10101 (OR/NOR) against
// MC10102 (NOR-only), which share pin 2.
//
// Unused MECL inputs have on-chip pulldowns and read LOW, which is why the
// boards leave so many unconnected; Verilator drives an unconnected input to
// 0, matching.

`default_nettype none

module comb_SE10210 (
    input  wire p5,
    input  wire p6,
    input  wire p7,
    output wire p2,
    output wire p3,
    output wire p4,
    input  wire p9,
    input  wire p10,
    input  wire p11,
    output wire p12,
    output wire p13,
    output wire p14,
    input  wire p8,
    input  wire p15,
    input  wire p16
);

  assign p2 = (p5 | p6 | p7);
  assign p3 = (p5 | p6 | p7);
  assign p4 = (p5 | p6 | p7);
  assign p12 = (p9 | p10 | p11);
  assign p13 = (p9 | p10 | p11);
  assign p14 = (p9 | p10 | p11);

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p8, p15, p16, 1'b0};

endmodule

`default_nettype wire

// comb_SE10211 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 11 package position(s) across the sixteen boards.
//
// High-Speed Dual 3-Input 3-Output NOR (Signetics second source for the
// Motorola MC10211 -- EclDict's alias table groups `MC111, MC211, SE211`, so
// they are one part in three sockets). Body identical to cell_MC10211.
//
// NO POLARITY AMBIGUITY HERE: the part is NOR-only, so all six outputs carry
// the same, inverting sense and the dictionary's role letters do not have to
// be interpreted. See docs/verilog-handoff.md for the parts where they do.

`default_nettype none

module comb_SE10211 (
    output wire p2,  // (no name in EclDict)
    output wire p3,  // (no name in EclDict)
    output wire p4,  // (no name in EclDict)
    input  wire p5,  // (no name in EclDict)
    input  wire p6,  // (no name in EclDict)
    input  wire p7,  // (no name in EclDict)
    input  wire p9,  // (no name in EclDict)
    input  wire p10,  // (no name in EclDict)
    input  wire p11,  // (no name in EclDict)
    output wire p12,  // (no name in EclDict)
    output wire p13,  // (no name in EclDict)
    output wire p14,  // (no name in EclDict)
    input  wire p15,  // (no name in EclDict)
    input  wire p16// (no name in EclDict)
);

  wire a = ~(p5 | p6 | p7);
  wire b = ~(p9 | p10 | p11);
  assign p2 = a; assign p3 = a; assign p4 = a;
  assign p12 = b; assign p13 = b; assign p14 = b;

  // Board-wired pins the dictionary does not name (power and the like)
  wire _unused_pins = &{1'b0, p15, p16, 1'b0};
endmodule

`default_nettype wire

// comb_SE10212 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 25 package position(s) across the sixteen boards.
//
// High-Speed Dual 3-Input 3-Output OR/NOR (Signetics second
// source for the Motorola MC10212). Built to drive up to
// six transmission lines, which is why the Dorado uses it for clock and
// control distribution: the datasheet calls out "clock distribution
// applications where minimum clock skew is desired".
//
// Each gate gives ONE OR output and TWO NOR outputs -- pins 2 (OR) and 3,4
// (NOR) for the a side, 14 (OR) and 12,13 (NOR) for the b side. Its sibling
// MC10210 is the all-OR version and MC10211 the all-NOR one, and those two
// have IDENTICAL dictionary entries (every output role `OUT`), which is why
// single-sense parts take their polarity from the part name instead.
//
// POLARITY, confirmed from the datasheets (2026-08-16): EclDict's role `OUT`
// is the INVERTING (NOR) output and `o` the non-inverting (OR) one. Motorola's
// MC10101 sheet labels the four `OUT` pins A-bar-OUT..D-bar-OUT and the four
// `o` pins AOUT..DOUT; MC10212's labels its `OUT` pins 3,4,12,13 with bars and
// its `o` pins 2,14 without. Eight gates, two parts, unanimous. See
// docs/verilog-handoff.md.

`default_nettype none

module comb_SE10212 (
    input  wire p1,  // (no name in EclDict)
    output wire p2,  // a_OUTN
    output wire p3,  // a_OUT
    output wire p4,  // a_OUT
    input  wire p5,  // a_IN0
    input  wire p6,  // a_IN1
    input  wire p7,  // a_IN2
    input  wire p8,  // (no name in EclDict)
    input  wire p9,  // b_IN0
    input  wire p10,  // b_IN1
    input  wire p11,  // b_IN2
    output wire p12,  // b_OUT
    output wire p13,  // b_OUT
    output wire p14,  // b_OUTN
    input  wire p15,  // (no name in EclDict)
    input  wire p16// (no name in EclDict)
);

  wire a = p5 | p6 | p7;
  wire b = p9 | p10 | p11;
  assign p3  = ~a;  assign p4  = ~a;   // A-bar-OUT, two of them
  assign p2  =  a;                     // AOUT
  assign p12 = ~b;  assign p13 = ~b;   // B-bar-OUT
  assign p14 =  b;                     // BOUT

  wire _unused_pins = &{1'b0, p1, p8, p15, p16, 1'b0};
endmodule

`default_nettype wire

`default_nettype none
module sampled_F10000(output wire p2,output wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [3:0] fixture_state,output wire [3:0] state_q);
 assign state_q=fixture_state;
 wire clk=p4|p13;
 assign p14=state_q[3];
 assign p15=state_q[2];
 assign p2=state_q[1];
 assign p3=state_q[0];
endmodule
`default_nettype wire

`default_nettype none
module sampled_F10000_gated(output wire p2,output wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [3:0] fixture_state,output wire [3:0] state_q);
 assign state_q=fixture_state;
 wire clk=p4|p13;
 assign p14=state_q[3];
 assign p15=state_q[2];
 assign p2=state_q[1];
 assign p3=state_q[0];
endmodule
`default_nettype wire

`default_nettype none
module sampled_F10145A(output wire p1,output wire p2,input wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p8,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [63:0] fixture_state,output wire [63:0] state_q);
 assign state_q=fixture_state;
 wire [3:0] address={p10,p9,p7,p6};
 assign p2=p3 ? 1'b0 : state_q[4*address];
 assign p1=p3 ? 1'b0 : state_q[4*address+1];
 assign p15=p3 ? 1'b0 : state_q[4*address+2];
 assign p14=p3 ? 1'b0 : state_q[4*address+3];
endmodule
`default_nettype wire

`default_nettype none
module sampled_MC10141(input wire p1,output wire p2,output wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p8,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [3:0] fixture_state,output wire [3:0] state_q);
 assign state_q=fixture_state;
 assign p14=state_q[0];
 assign p15=state_q[1];
 assign p2=state_q[2];
 assign p3=state_q[3];
endmodule
`default_nettype wire

`default_nettype none
module sampled_MC10173(output wire p1,output wire p2,input wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [3:0] fixture_state,output wire [3:0] state_q);
 assign state_q=fixture_state;
 assign p1=state_q[0];
 assign p2=state_q[1];
 assign p15=state_q[2];
 assign p14=state_q[3];
endmodule
`default_nettype wire

`default_nettype none
module sampled_MC10176(input wire p1,output wire p2,output wire p3,output wire p4,input wire p5,input wire p6,input wire p7,input wire p8,input wire p9,input wire p10,input wire p11,input wire p12,output wire p13,output wire p14,output wire p15,input wire p16,input wire fixture_load,input wire [5:0] fixture_state,output wire [5:0] state_q);
 assign state_q=fixture_state;
 assign p2=state_q[0];
 assign p3=state_q[1];
 assign p4=state_q[2];
 assign p13=state_q[3];
 assign p14=state_q[4];
 assign p15=state_q[5];
endmodule
`default_nettype wire

`default_nettype none
module sampled_MC10231(input wire p1,output wire p2,output wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p8,input wire p9,input wire p10,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire p16,input wire fixture_load,input wire [1:0] fixture_state,output wire [1:0] state_q);
 assign state_q=fixture_state;
 wire ca=p9|p6,cb=p9|p11;
 assign p2=state_q[0];
 assign p3=~state_q[0];
 assign p15=state_q[1];
 assign p14=~state_q[1];
endmodule
`default_nettype wire

`default_nettype none
module sampled_MC1668(output wire p2,output wire p3,input wire p4,input wire p5,input wire p6,input wire p7,input wire p9,input wire p11,input wire p12,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [1:0] fixture_state,output wire [1:0] state_q);
 assign state_q=fixture_state;
 assign p2=state_q[0];
 assign p3=~state_q[0];
 assign p15=state_q[1];
 assign p14=~state_q[1];
endmodule
`default_nettype wire

`default_nettype none
module sampled_SE10231(output wire p2,output wire p3,input wire p6,input wire p7,input wire p9,input wire p10,input wire p11,input wire p13,output wire p14,output wire p15,input wire fixture_load,input wire [1:0] fixture_state,output wire [1:0] state_q);
 assign state_q=fixture_state;
 wire ca=p9|p6,cb=p9|p11;
 assign p2=state_q[0];
 assign p3=~state_q[0];
 assign p15=state_q[1];
 assign p14=~state_q[1];
endmodule
`default_nettype wire

`timescale 1ns/1ps
`default_nettype none
module r_front_conta_sampled(input wire fixture_load,input wire [47:0] fixture_state,
 input wire base,start_a,en,input wire [235:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,rb_forward,rb_forward_n,
 output wire [47:0] state_q,output wire [12:0] clocks,
 output wire [13:0] flags);
 wire n0; // 11or10'
 wire n1; // 15/14/11/10
 wire n2; // 15or14'
 wire n3; // 15to12'
 wire n4; // 15to8
 wire n5; // 1andNot3or2'
 wire n6; // 3or2'
 wire n7; // 7or6
 wire n8; // 7or6'
 wire n9; // 7to4
 wire n10; // 7to4'
 wire n11; // AlwaysSH
 wire n12; // BNT.0
 wire n13; // BNT.0'
 wire n14; // BNT.1
 wire n15; // BNT.1'
 wire n16; // BNT.2
 wire n17; // BNT.2'
 wire n18; // BNT.3
 wire n19; // BNT.3'
 wire n20; // BNTGtCT'a
 wire n21; // BNTGtCT'b
 wire n22; // BNextRegsEn'
 wire n23; // Block'
 wire n24; // CAHold
 wire n25; // CAHold'
 wire n26; // CAHoldB
 wire n27; // CAHoldD
 wire n28; // CLK.ca'
 wire n29; // CLKEnable'a
 wire n30; // CLKEnable'b
 wire n31; // CLKEnable'c
 wire n32; // CPAddr.0'
 wire n33; // CPStrb'
 wire n34; // CRamClock
 wire n35; // CTask.0
 wire n36; // CTask.0'
 wire n37; // CTask.1
 wire n38; // CTask.1'
 wire n39; // CTask.2
 wire n40; // CTask.2'
 wire n41; // CTask.3
 wire n42; // CTask.3'
 wire n43; // CTask=0
 wire n44; // ClearMemStop
 wire n45; // ContA02.sil+1
 wire n46; // ContA04.sil+1
 wire n47; // ContA05.sil+4
 wire n48; // ContA25.sil+1
 wire n49; // ContA25.sil+2
 wire n50; // ContA25.sil+3
 wire n51; // ContA25.sil+4
 wire n52; // ContA25.sil+5
 wire n53; // ContA27.sil+1
 wire n54; // ContA27.sil+2
 wire n55; // ContA28.sil+2
 wire n56; // ContA28.sil+3
 wire n57; // ContA28.sil+4
 wire n58; // ContA28.sil+7
 wire n59; // ContA30.sil+1
 wire n60; // ContA31.sil+1
 wire n61; // ContA31.sil+2
 wire n62; // ContA31.sil+3
 wire n63; // ContA31.sil+4
 wire n64; // ContA31.sil+5
 wire n65; // Error'
 wire n66; // FF=TOffIsOK
 wire n67; // FF=TaskingOff
 wire n68; // Freeze
 wire n69; // FreezeAC
 wire n70; // FreezeBD
 wire n71; // GND180
 wire n72; // GND264
 wire n73; // GND266
 wire n74; // GND278
 wire n75; // GND312
 wire n76; // GND314
 wire n77; // GND394
 wire n78; // GND396
 wire n79; // GND398
 wire n80; // GND4
 wire n81; // GND444
 wire n82; // GND446
 wire n83; // GND468
 wire n84; // GND530
 wire n85; // GND544
 wire n86; // GetTLink
 wire n87; // GetTLink'
 wire n88; // Hold
 wire n89; // IsNext.01'
 wire n90; // IsNext.02'
 wire n91; // IsNext.03'
 wire n92; // IsNext.04'
 wire n93; // IsNext.05'
 wire n94; // IsNext.06'
 wire n95; // IsNext.07'
 wire n96; // IsNext.08'
 wire n97; // IsNext.09'
 wire n98; // IsNext.10'
 wire n99; // IsNext.11'
 wire n100; // IsNext.12'
 wire n101; // IsNext.13'
 wire n102; // IsNext.14'
 wire n103; // IsNext.15'
 wire n104; // MemClkEnable'a
 wire n105; // MemClkEnable'b
 wire n106; // MemSH
 wire n107; // MemSH'
 wire n108; // MidasData'
 wire n109; // Next.0
 wire n110; // Next.1
 wire n111; // Next.2
 wire n112; // Next.3
 wire n113; // Next=0
 wire n114; // NoDispatch
 wire n115; // PEnc.0
 wire n116; // PEnc.1
 wire n117; // PEnc.2
 wire n118; // PEnc.3
 wire n119; // PEnc=CT'
 wire n120; // PEncGtTrueNext'
 wire n121; // PEncLtTrueNext'
 wire n122; // Phase0
 wire n123; // Phase0'
 wire n124; // Phase1
 wire n125; // Phase2
 wire n126; // Phase2'
 wire n127; // Phase3
 wire n128; // Phase3'
 wire n129; // Phase4
 wire n130; // Phase4'
 wire n131; // RWTPCorRWIM
 wire n132; // Ready.01
 wire n133; // Ready.02
 wire n134; // Ready.03
 wire n135; // Ready.04
 wire n136; // Ready.05
 wire n137; // Ready.06
 wire n138; // Ready.07
 wire n139; // Ready.08
 wire n140; // Ready.09
 wire n141; // Ready.10
 wire n142; // Ready.11
 wire n143; // Ready.12
 wire n144; // Ready.13
 wire n145; // Ready.14
 wire n146; // Ready.15
 wire n147; // RepeatCur
 wire n148; // RepeatCur'
 wire n149; // RepeatCurB
 wire n150; // RepeatCurC
 wire n151; // RepeatCurD
 wire n152; // Run'
 wire n153; // RunClk'a
 wire n154; // RunClk'b
 wire n155; // RunRefresh
 wire n156; // RunRefresh'
 wire n157; // SC&NoFreeze
 wire n158; // SC&NoFreeze'
 wire n159; // SCorFreezea
 wire n160; // SCorFreezeb
 wire n161; // SetRun
 wire n162; // SetRun'
 wire n163; // SetRunRfsh
 wire n164; // SetSS'
 wire n165; // StartCycle
 wire n166; // StartCycle'
 wire n167; // StartCycle'a
 wire n168; // Stop
 wire n169; // StopAtT1
 wire n170; // StopAtT1'
 wire n171; // StopRunClock
 wire n172; // StopTasks
 wire n173; // Switch'a
 wire n174; // Switch'b
 wire n175; // SwitchDown
 wire n176; // SwitchUp
 wire n177; // SwitchUp'
 wire n178; // Switcha
 wire n179; // Switchb
 wire n180; // TPCBypass
 wire n181; // TPCBypass'
 wire n182; // TPCIclk'a
 wire n183; // TPCIclk'b
 wire n184; // TPCIclk'c
 wire n185; // TWReq.01
 wire n186; // TWReq.02
 wire n187; // TWReq.03
 wire n188; // TWReq.04
 wire n189; // TWReq.05
 wire n190; // TWReq.06
 wire n191; // TWReq.07
 wire n192; // TWReq.08
 wire n193; // TWReq.09
 wire n194; // TWReq.10
 wire n195; // TWReq.11
 wire n196; // TWReq.12
 wire n197; // TWReq.13
 wire n198; // TWReq.14
 wire n199; // TWReq.15
 wire n200; // ToPE.01
 wire n201; // ToPE.02
 wire n202; // ToPE.03
 wire n203; // ToPE.03'
 wire n204; // ToPE.04
 wire n205; // ToPE.05
 wire n206; // ToPE.05'
 wire n207; // ToPE.06
 wire n208; // ToPE.07
 wire n209; // ToPE.07'
 wire n210; // ToPE.08
 wire n211; // ToPE.09
 wire n212; // ToPE.09'
 wire n213; // ToPE.10
 wire n214; // ToPE.11
 wire n215; // ToPE.11'
 wire n216; // ToPE.12
 wire n217; // ToPE.13
 wire n218; // ToPE.13'
 wire n219; // ToPE.14
 wire n220; // ToPE.15
 wire n221; // ToPE.15'
 wire n222; // TrueAC
 wire n223; // TrueBD
 wire n224; // UseDMD
 wire n225; // WIM'
 wire n226; // WTPC'
 wire n227; // WantRunRfsh
 wire n228; // bCLKEnable'a
 wire n229; // bCLKEnable'b
 wire n230; // bCLKEnable'c
 wire n231; // bCLKEnable'd
 wire n232; // bCLKEnable'e
 wire n233; // bCLKEnable'f
 wire n234; // bPEnc.0
 wire n235; // bPEnc.0'
 wire n236; // bPEnc.1
 wire n237; // bPEnc.1'
 wire n238; // bPEnc.2
 wire n239; // bPEnc.2'
 wire n240; // bPEnc.3
 wire n241; // bPEnc.3'
 wire n242; // bSwitchUp'
 wire n243; // bpreStartC'a
 wire n244; // bpreStartC'b
 wire n245; // bpreStartC'c
 wire n246; // brMIRa
 wire n247; // brMIRb
 wire n248; // brMIRc
 wire n249; // clk0'Ba
 wire n250; // clk0'Bb
 wire n251; // clk0'Ca
 wire n252; // clk0'Cb
 wire n253; // clk0'Cc
 wire n254; // clk0'Da
 wire n255; // clk0'Db
 wire n256; // clk0'Dc
 wire n257; // clk1'Ca
 wire n258; // clk1'Cb
 wire n259; // clk2'Ba
 wire n260; // clk2'Bb
 wire n261; // clk2'Bc
 wire n262; // clk2'Bd
 wire n263; // clk2'Be
 wire n264; // clk2'Bf
 wire n265; // dBlock'
 wire n266; // dMemRun
 wire n267; // dRun
 wire n268; // dStartCycle
 wire n269; // dStop
 wire n270; // dSwitch
 wire n271; // dSwitchUp'
 wire n272; // h*fclk0'Ba
 wire n273; // h*fclk0'Bb
 wire n274; // h*fclk0'Da
 wire n275; // h*fclk0'Db
 wire n276; // h*fclk0'Dc
 wire n277; // pNext.0
 wire n278; // pNext.1
 wire n279; // pNext.2
 wire n280; // pNext.3
 wire n281; // preCRamClock
 wire n282; // preFH'
 wire n283; // preRunClk'Ba
 wire n284; // preRunClk'Bb
 wire n285; // preRunClk'Bc
 wire n286; // preStartCyclea
 wire n287; // preclk0'Aa
 wire n288; // preclk0'Ba
 wire n289; // preclk0'Ca
 wire n290; // preclk0'Cb
 wire n291; // preclk0'Da
 wire n292; // preclk1'Aa
 wire n293; // preclk1'Ca
 wire n294; // preclk1'Da
 wire n295; // preclk2'Aa
 wire n296; // preclk2'Ba
 wire n297; // preclk2'Bb
 wire n298; // preclk2'Bc
 wire n299; // preclk2'Bd
 wire n300; // preclk2'Ca
 wire n301; // preclk2'Da
 wire n302; // prepreclk'a
 wire n303; // prepreclk'b
 wire n304; // prepreclk'c
 wire n305; // prepreclk'd
 wire n306; // prepreclk'e
 wire n307; // rCT
 wire n308; // rMIRa
 wire n309; // rStop
 wire n310; // sCTask.0
 wire n311; // sCTask.1
 wire n312; // sCTask.2
 wire n313; // sCTask.3
 wire n314; // sPhase0
 assign n71=1'b0;
 assign n72=1'b0;
 assign n73=1'b0;
 assign n74=1'b0;
 assign n75=1'b0;
 assign n76=1'b0;
 assign n77=1'b0;
 assign n78=1'b0;
 assign n79=1'b0;
 assign n80=1'b0;
 assign n81=1'b0;
 assign n82=1'b0;
 assign n83=1'b0;
 assign n84=1'b0;
 assign n85=1'b0;
 assign n23=pins[67];
 assign n28=base;
 assign n32=1'b1;
 assign n33=1'b1;
 assign n55=1'b0;
 assign n56=1'b0;
 assign n57=1'b0;
 assign n58=1'b0;
 assign n59=1'b0;
 assign n65=pins[3];
 assign n66=1'b0;
 assign n67=1'b0;
 assign n86=1'b0;
 assign n88=pins[69];
 assign n89=pins[50];
 assign n90=pins[51];
 assign n91=pins[52];
 assign n92=pins[53];
 assign n93=pins[54];
 assign n94=pins[55];
 assign n95=pins[56];
 assign n96=pins[57];
 assign n97=pins[58];
 assign n98=pins[59];
 assign n99=pins[60];
 assign n100=pins[61];
 assign n101=pins[62];
 assign n102=pins[63];
 assign n103=pins[64];
 assign n114=pins[0];
 assign n131=pins[1];
 assign n132=pins[35];
 assign n133=pins[36];
 assign n134=pins[37];
 assign n135=pins[38];
 assign n136=pins[39];
 assign n137=pins[40];
 assign n138=pins[41];
 assign n139=pins[42];
 assign n140=pins[43];
 assign n141=pins[44];
 assign n142=pins[45];
 assign n143=pins[46];
 assign n144=pins[47];
 assign n145=pins[48];
 assign n146=pins[49];
 assign n161=pins[6];
 assign n163=pins[4];
 assign n164=pins[5];
 assign n169=pins[2];
 assign n172=pins[65];
 assign n185=pins[20];
 assign n186=pins[21];
 assign n187=pins[22];
 assign n188=pins[23];
 assign n189=pins[24];
 assign n190=pins[25];
 assign n191=pins[26];
 assign n192=pins[27];
 assign n193=pins[28];
 assign n194=pins[29];
 assign n195=pins[30];
 assign n196=pins[31];
 assign n197=pins[32];
 assign n198=pins[33];
 assign n199=pins[34];
 assign n225=pins[8];
 assign n226=1'b1;
 assign n265=pins[66];
 assign n307=pins[70];
 assign n308=1'b0;
 assign n309=pins[7];
 assign n310=pins[71];
 assign n311=pins[72];
 assign n312=pins[73];
 assign n313=pins[74];
 wire n0_e13_15;
 assign n0=n0_e13_15;
 wire n1_e13_9;
 wire n1_d12_2;
 assign n1=n1_e13_9 | n1_d12_2;
 wire n2_d12_3;
 assign n2=n2_d12_3;
 wire n3_c12_3;
 assign n3=n3_c12_3;
 wire n4_c12_15;
 wire n4_c12_2;
 assign n4=n4_c12_15 | n4_c12_2;
 wire n5_d13_9;
 wire n5_d13_14;
 assign n5=n5_d13_9 | n5_d13_14;
 wire n6_d13_15;
 assign n6=n6_d13_15;
 wire n7_g11_9;
 assign n7=n7_g11_9;
 wire n8_g11_15;
 assign n8=n8_g11_15;
 wire n9_d12_15;
 assign n9=n9_d12_15;
 wire n10_d12_14;
 assign n10=n10_d12_14;
 wire n11_l05_3;
 assign n11=n11_l05_3;
 wire n12_h09_14;
 assign n12=n12_h09_14;
 wire n13_h08_14;
 assign n13=n13_h08_14;
 wire n14_h09_15;
 assign n14=n14_h09_15;
 wire n15_h08_15;
 assign n15=n15_h08_15;
 wire n16_h09_2;
 assign n16=n16_h09_2;
 wire n17_h08_2;
 assign n17=n17_h08_2;
 wire n18_h09_3;
 assign n18=n18_h09_3;
 wire n19_h08_3;
 assign n19=n19_h08_3;
 wire n20_a02_13;
 assign n20=n20_a02_13;
 wire n21_a02_12;
 assign n21=n21_a02_12;
 wire n22_h10_2;
 assign n22=n22_h10_2;
 wire n24_f20_15;
 assign n24=n24_f20_15;
 wire n25_f20_14;
 assign n25=n25_f20_14;
 wire n26_f19_2;
 assign n26=n26_f19_2;
 wire n27_f19_4;
 assign n27=n27_f19_4;
 wire n29_k02_15;
 wire n29_k01_14;
 assign n29=n29_k02_15 | n29_k01_14;
 wire n30_k02_2;
 wire n30_k01_3;
 assign n30=n30_k02_2 | n30_k01_3;
 wire n31_l02_14;
 wire n31_l02_2;
 assign n31=n31_l02_14 | n31_l02_2;
 wire n34_j01_3;
 assign n34=n34_j01_3;
 wire n35_j08_15;
 assign n35=n35_j08_15;
 wire n36_j08_14;
 assign n36=n36_j08_14;
 wire n37_j08_2;
 assign n37=n37_j08_2;
 wire n38_j08_3;
 assign n38=n38_j08_3;
 wire n39_j09_15;
 assign n39=n39_j09_15;
 wire n40_j09_14;
 assign n40=n40_j09_14;
 wire n41_j09_2;
 assign n41=n41_j09_2;
 wire n42_j09_3;
 assign n42=n42_j09_3;
 wire n43_j10_14;
 assign n43=n43_j10_14;
 wire n44_h03_3;
 assign n44=n44_h03_3;
 wire n45_h03_14;
 assign n45=n45_h03_14;
 wire n46_d11_15;
 assign n46=n46_d11_15;
 wire n47_g11_2;
 assign n47=n47_g11_2;
 wire n48_h11_3;
 assign n48=n48_h11_3;
 wire n49_i10_2;
 assign n49=n49_i10_2;
 wire n50_i10_3;
 assign n50=n50_i10_3;
 wire n51_h11_2;
 assign n51=n51_h11_2;
 wire n52_g15_2;
 assign n52=n52_g15_2;
 wire n53_j05_2;
 assign n53=n53_j05_2;
 wire n54_i04_3;
 assign n54=n54_i04_3;
 wire n60_i03_14;
 assign n60=n60_i03_14;
 wire n61_i03_13;
 assign n61=n61_i03_13;
 wire n62_i03_2;
 assign n62=n62_i03_2;
 wire n63_i03_3;
 assign n63=n63_i03_3;
 wire n64_i03_4;
 assign n64=n64_i03_4;
 wire n68_i07_14;
 assign n68=n68_i07_14;
 wire n69_i07_13;
 assign n69=n69_i07_13;
 wire n70_i07_12;
 assign n70=n70_i07_12;
 wire n87_g05_15;
 assign n87=n87_g05_15;
 wire n104_l04_15;
 wire n104_l03_14;
 assign n104=n104_l04_15 | n104_l03_14;
 wire n105_l04_2;
 wire n105_l03_3;
 assign n105=n105_l04_2 | n105_l03_3;
 wire n106_k03_3;
 assign n106=n106_k03_3;
 wire n107_k03_2;
 assign n107=n107_k03_2;
 wire n108_f16_14;
 assign n108=n108_f16_14;
 wire n109_h14_14;
 assign n109=n109_h14_14;
 wire n110_h14_15;
 assign n110=n110_h14_15;
 wire n111_h14_2;
 assign n111=n111_h14_2;
 wire n112_h14_1;
 assign n112=n112_h14_1;
 wire n113_j10_3;
 assign n113=n113_j10_3;
 wire n115_e12_11;
 assign n115=n115_e12_11;
 wire n116_g11_3;
 wire n116_g11_14;
 assign n116=n116_g11_3 | n116_g11_14;
 wire n117_g10_3;
 assign n117=n117_g10_3;
 wire n118_f10_3;
 wire n118_f11_3;
 assign n118=n118_f10_3 | n118_f11_3;
 wire n119_j11_3;
 wire n119_j11_2;
 wire n119_j11_15;
 wire n119_j11_14;
 assign n119=n119_j11_3 | n119_j11_2 | n119_j11_15 | n119_j11_14;
 wire n120_g15_14;
 assign n120=n120_g15_14;
 wire n121_g15_15;
 assign n121=n121_g15_15;
 wire n122_l07_15;
 assign n122=n122_l07_15;
 wire n123_l07_14;
 assign n123=n123_l07_14;
 wire n124_l07_2;
 assign n124=n124_l07_2;
 wire n125_k05_15;
 assign n125=n125_k05_15;
 wire n126_k05_14;
 assign n126=n126_k05_14;
 wire n127_k05_2;
 assign n127=n127_k05_2;
 wire n128_k05_3;
 assign n128=n128_k05_3;
 wire n129_j01_15;
 assign n129=n129_j01_15;
 wire n130_j01_14;
 assign n130=n130_j01_14;
 wire n147_f20_3;
 assign n147=n147_f20_3;
 wire n148_f20_2;
 assign n148=n148_f20_2;
 wire n149_f19_13;
 assign n149=n149_f19_13;
 wire n150_f19_12;
 assign n150=n150_f19_12;
 wire n151_f19_14;
 assign n151=n151_f19_14;
 wire n152_j04_14;
 assign n152=n152_j04_14;
 wire n153_i06_3;
 assign n153=n153_i06_3;
 wire n154_i06_2;
 assign n154=n154_i06_2;
 wire n155_l06_15;
 assign n155=n155_l06_15;
 wire n156_l06_14;
 assign n156=n156_l06_14;
 wire n157_k04_2;
 assign n157=n157_k04_2;
 wire n158_k04_3;
 assign n158=n158_k04_3;
 wire n159_i06_13;
 assign n159=n159_i06_13;
 wire n160_i06_12;
 assign n160=n160_i06_12;
 wire n162_g05_3;
 assign n162=n162_g05_3;
 wire n165_k04_15;
 assign n165=n165_k04_15;
 wire n166_k04_14;
 assign n166=n166_k04_14;
 wire n167_k03_14;
 assign n167=n167_k03_14;
 wire n168_j04_2;
 assign n168=n168_j04_2;
 wire n170_g05_2;
 assign n170=n170_g05_2;
 wire n171_l05_2;
 assign n171=n171_l05_2;
 wire n173_f14_14;
 assign n173=n173_f14_14;
 wire n174_f14_3;
 assign n174=n174_f14_3;
 wire n175_g15_3;
 assign n175=n175_g15_3;
 wire n176_f15_14;
 assign n176=n176_f15_14;
 wire n177_f15_15;
 assign n177=n177_f15_15;
 wire n178_f14_15;
 assign n178=n178_f14_15;
 wire n179_f14_2;
 assign n179=n179_f14_2;
 wire n180_f15_2;
 assign n180=n180_f15_2;
 wire n181_f15_3;
 assign n181=n181_f15_3;
 wire n182_j06_13;
 assign n182=n182_j06_13;
 wire n183_j06_12;
 assign n183=n183_j06_12;
 wire n184_j06_14;
 assign n184=n184_j06_14;
 wire n200_a10_2;
 wire n200_a11_2;
 assign n200=n200_a10_2 | n200_a11_2;
 wire n201_a10_3;
 wire n201_a11_3;
 assign n201=n201_a10_3 | n201_a11_3;
 wire n202_a10_14;
 wire n202_a11_14;
 assign n202=n202_a10_14 | n202_a11_14;
 wire n203_d13_2;
 assign n203=n203_d13_2;
 wire n204_a10_15;
 wire n204_a11_15;
 assign n204=n204_a10_15 | n204_a11_15;
 wire n205_b10_2;
 wire n205_b11_2;
 assign n205=n205_b10_2 | n205_b11_2;
 wire n206_d13_3;
 assign n206=n206_d13_3;
 wire n207_b10_3;
 wire n207_b11_3;
 assign n207=n207_b10_3 | n207_b11_3;
 wire n208_b10_14;
 wire n208_b11_14;
 assign n208=n208_b10_14 | n208_b11_14;
 wire n209_e12_2;
 assign n209=n209_e12_2;
 wire n210_b11_15;
 wire n210_b10_15;
 assign n210=n210_b11_15 | n210_b10_15;
 wire n211_c11_2;
 wire n211_c10_2;
 assign n211=n211_c11_2 | n211_c10_2;
 wire n212_e13_14;
 assign n212=n212_e13_14;
 wire n213_c11_3;
 wire n213_c10_3;
 assign n213=n213_c11_3 | n213_c10_3;
 wire n214_c10_14;
 wire n214_c11_14;
 assign n214=n214_c10_14 | n214_c11_14;
 wire n215_e13_3;
 assign n215=n215_e13_3;
 wire n216_c11_15;
 wire n216_c10_15;
 assign n216=n216_c11_15 | n216_c10_15;
 wire n217_d11_2;
 wire n217_d10_2;
 assign n217=n217_d11_2 | n217_d10_2;
 wire n218_e12_3;
 assign n218=n218_e12_3;
 wire n219_d11_3;
 wire n219_d10_3;
 assign n219=n219_d11_3 | n219_d10_3;
 wire n220_d11_14;
 wire n220_d10_14;
 assign n220=n220_d11_14 | n220_d10_14;
 wire n221_e13_2;
 assign n221=n221_e13_2;
 wire n222_g05_13;
 assign n222=n222_g05_13;
 wire n223_g05_4;
 assign n223=n223_g05_4;
 wire n224_i04_15;
 assign n224=n224_i04_15;
 wire n227_l05_15;
 assign n227=n227_l05_15;
 wire n228_i05_3;
 assign n228=n228_i05_3;
 wire n229_i05_2;
 assign n229=n229_i05_2;
 wire n230_i05_4;
 assign n230=n230_i05_4;
 wire n231_i05_13;
 assign n231=n231_i05_13;
 wire n232_i05_12;
 assign n232=n232_i05_12;
 wire n233_i05_14;
 assign n233=n233_i05_14;
 wire n234_i11_5;
 assign n234=n234_i11_5;
 wire n235_i11_2;
 assign n235=n235_i11_2;
 wire n236_i11_6;
 assign n236=n236_i11_6;
 wire n237_i11_3;
 assign n237=n237_i11_3;
 wire n238_i11_11;
 assign n238=n238_i11_11;
 wire n239_i11_14;
 assign n239=n239_i11_14;
 wire n240_i11_9;
 assign n240=n240_i11_9;
 wire n241_i11_15;
 assign n241=n241_i11_15;
 wire n242_a02_14;
 assign n242=n242_a02_14;
 wire n243_l08_3;
 assign n243=n243_l08_3;
 wire n244_l08_4;
 assign n244=n244_l08_4;
 wire n245_l08_2;
 assign n245=n245_l08_2;
 wire n246_a02_3;
 assign n246=n246_a02_3;
 wire n247_a02_2;
 assign n247=n247_a02_2;
 wire n248_a02_4;
 assign n248=n248_a02_4;
 wire n249_j07_13;
 assign n249=n249_j07_13;
 wire n250_j07_12;
 assign n250=n250_j07_12;
 wire n251_d18_3;
 assign n251=n251_d18_3;
 wire n252_d18_2;
 assign n252=n252_d18_2;
 wire n253_d18_4;
 assign n253=n253_d18_4;
 wire n254_j18_3;
 assign n254=n254_j18_3;
 wire n255_j18_2;
 assign n255=n255_j18_2;
 wire n256_j18_4;
 assign n256=n256_j18_4;
 wire n257_d18_13;
 assign n257=n257_d18_13;
 wire n258_d18_12;
 assign n258=n258_d18_12;
 wire n259_j06_3;
 assign n259=n259_j06_3;
 wire n260_j06_2;
 assign n260=n260_j06_2;
 wire n261_j06_4;
 assign n261=n261_j06_4;
 wire n262_i07_3;
 assign n262=n262_i07_3;
 wire n263_i07_2;
 assign n263=n263_i07_2;
 wire n264_i07_4;
 assign n264=n264_i07_4;
 wire n266_g04_15;
 wire n266_h03_2;
 assign n266=n266_g04_15 | n266_h03_2;
 wire n267_i03_15;
 assign n267=n267_i03_15;
 wire n268_j05_3;
 assign n268=n268_j05_3;
 wire n269_i04_2;
 wire n269_j05_14;
 assign n269=n269_i04_2 | n269_j05_14;
 wire n270_f17_14;
 wire n270_f17_3;
 wire n270_f16_3;
 assign n270=n270_f17_14 | n270_f17_3 | n270_f16_3;
 wire n271_f16_2;
 assign n271=n271_f16_2;
 wire n272_j07_3;
 assign n272=n272_j07_3;
 wire n273_j07_2;
 assign n273=n273_j07_2;
 wire n274_j18_13;
 assign n274=n274_j18_13;
 wire n275_j18_12;
 assign n275=n275_j18_12;
 wire n276_j18_14;
 assign n276=n276_j18_14;
 wire n277_h13_14;
 assign n277=n277_h13_14;
 wire n278_h13_15;
 assign n278=n278_h13_15;
 wire n279_h13_2;
 assign n279=n279_h13_2;
 wire n280_h13_1;
 assign n280=n280_h13_1;
 wire n281_g12_4;
 assign n281=n281_g12_4;
 wire n282_l06_3;
 assign n282=n282_l06_3;
 wire n283_f13_13;
 assign n283=n283_f13_13;
 wire n284_f13_12;
 assign n284=n284_f13_12;
 wire n285_f13_14;
 assign n285=n285_f13_14;
 wire n286_k03_15;
 assign n286=n286_k03_15;
 wire n287_g13_3;
 assign n287=n287_g13_3;
 wire n288_g13_2;
 assign n288=n288_g13_2;
 wire n289_g13_13;
 assign n289=n289_g13_13;
 wire n290_g13_12;
 assign n290=n290_g13_12;
 wire n291_g13_4;
 assign n291=n291_g13_4;
 wire n292_f13_3;
 assign n292=n292_f13_3;
 wire n293_f13_2;
 assign n293=n293_f13_2;
 wire n294_f13_4;
 assign n294=n294_f13_4;
 wire n295_f12_3;
 assign n295=n295_f12_3;
 wire n296_f12_13;
 assign n296=n296_f12_13;
 wire n297_f12_12;
 assign n297=n297_f12_12;
 wire n298_f12_14;
 assign n298=n298_f12_14;
 wire n299_g12_14;
 assign n299=n299_g12_14;
 wire n300_f12_2;
 assign n300=n300_f12_2;
 wire n301_f12_4;
 assign n301=n301_f12_4;
 wire n302_l01_13;
 assign n302=n302_l01_13;
 wire n303_l01_12;
 assign n303=n303_l01_12;
 wire n304_l01_14;
 assign n304=n304_l01_14;
 wire n305_l01_3;
 assign n305=n305_l01_3;
 wire n306_l01_2;
 assign n306=n306_l01_2;
 wire n314_i04_14;
 assign n314=n314_i04_14;
 comb_MC10210 a02(.p1(1'b0),.p2(n247_a02_2),.p3(n246_a02_3),.p4(n248_a02_4),.p5(n308),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n177),.p12(n21_a02_12),.p13(n20_a02_13),.p14(n242_a02_14),.p15(n80),.p16(1'b0));
 comb_MC1664 a10(.p2(n200_a10_2),.p3(n201_a10_3),.p4(1'b0),.p5(n185),.p6(1'b0),.p7(n186),.p10(1'b0),.p11(n187),.p12(1'b0),.p13(n188),.p14(n202_a10_14),.p15(n204_a10_15));
 comb_MC10104 a11(.p2(n200_a11_2),.p3(n201_a11_3),.p4(n132),.p5(n89),.p6(n90),.p7(n133),.p10(n134),.p11(n91),.p12(n92),.p13(n135),.p14(n202_a11_14),.p15(n204_a11_15),.p16(1'b0));
 comb_MC1664 b10(.p2(n205_b10_2),.p3(n207_b10_3),.p4(1'b0),.p5(n189),.p6(1'b0),.p7(n190),.p10(1'b0),.p11(n191),.p12(1'b0),.p13(n192),.p14(n208_b10_14),.p15(n210_b10_15));
 comb_MC10104 b11(.p2(n205_b11_2),.p3(n207_b11_3),.p4(n136),.p5(n93),.p6(n94),.p7(n137),.p10(n138),.p11(n95),.p12(n96),.p13(n139),.p14(n208_b11_14),.p15(n210_b11_15),.p16(1'b0));
 comb_MC1664 c10(.p2(n211_c10_2),.p3(n213_c10_3),.p4(1'b0),.p5(n193),.p6(1'b0),.p7(n194),.p10(1'b0),.p11(n195),.p12(1'b0),.p13(n196),.p14(n214_c10_14),.p15(n216_c10_15));
 comb_MC10104 c11(.p2(n211_c11_2),.p3(n213_c11_3),.p4(n140),.p5(n97),.p6(n98),.p7(n141),.p10(n142),.p11(n99),.p12(n100),.p13(n143),.p14(n214_c11_14),.p15(n216_c11_15),.p16(1'b0));
 comb_MC10109 c12(.p2(n4_c12_2),.p3(n3_c12_3),.p4(n216),.p5(n217),.p6(n219),.p7(n220),.p8(1'b0),.p9(n214),.p10(n213),.p11(n211),.p12(n210),.p13(1'b0),.p15(n4_c12_15));
 comb_MC1664 d10(.p2(n217_d10_2),.p3(n219_d10_3),.p4(1'b0),.p5(n197),.p6(1'b0),.p7(n198),.p10(1'b0),.p11(n199),.p12(1'b0),.p13(1'b0),.p14(n220_d10_14));
 comb_MC10104 d11(.p2(n217_d11_2),.p3(n219_d11_3),.p4(n144),.p5(n101),.p6(n102),.p7(n145),.p10(n146),.p11(n103),.p12(n66),.p13(n67),.p14(n220_d11_14),.p15(n46_d11_15),.p16(1'b0));
 comb_MC10109 d12(.p2(n1_d12_2),.p3(n2_d12_3),.p4(1'b0),.p5(n219),.p6(1'b0),.p7(n220),.p8(1'b0),.p9(n208),.p10(n207),.p11(n205),.p12(n204),.p13(1'b0),.p14(n10_d12_14),.p15(n9_d12_15));
 comb_MC10102 d13(.p1(1'b0),.p2(n203_d13_2),.p3(n206_d13_3),.p4(n202),.p5(1'b0),.p6(n205),.p7(1'b0),.p9(n5_d13_9),.p10(n200),.p11(1'b0),.p12(n201),.p13(n202),.p14(n5_d13_14),.p15(n6_d13_15),.p16(1'b0));
 comb_SE10210 d18(.p2(n252_d18_2),.p3(n251_d18_3),.p4(n253_d18_4),.p5(1'b0),.p6(1'b0),.p7(n289),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n293),.p12(n258_d18_12),.p13(n257_d18_13),.p15(n71),.p16(1'b0));
 comb_MC10101 e12(.p2(n209_e12_2),.p3(n218_e12_3),.p4(n208),.p7(n217),.p10(n4),.p11(n115_e12_11),.p12(1'b0),.p13(1'b0));
 comb_MC10102 e13(.p1(1'b0),.p2(n221_e13_2),.p3(n215_e13_3),.p4(n220),.p5(1'b0),.p6(n214),.p7(1'b0),.p9(n1_e13_9),.p10(n211),.p11(1'b0),.p12(n213),.p13(n214),.p14(n212_e13_14),.p15(n0_e13_15),.p16(1'b0));
 comb_MC10121 f10(.p3(n118_f10_3),.p4(n1),.p5(n216),.p6(n212),.p7(n203),.p9(n9),.p10(n4),.p11(n206),.p12(n7),.p13(n215),.p14(n219),.p15(n216));
 comb_MC10121 f11(.p3(n118_f11_3),.p4(n221),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n209),.p10(n4),.p11(n5),.p12(n9),.p13(1'b0),.p14(n218),.p15(n219));
 comb_SE10210 f12(.p2(n300_f12_2),.p3(n295_f12_3),.p4(n301_f12_4),.p5(n304),.p6(1'b0),.p7(n230),.p8(1'b0),.p9(n230),.p10(1'b0),.p11(n304),.p12(n297_f12_12),.p13(n296_f12_13),.p14(n298_f12_14),.p15(n72),.p16(1'b0));
 comb_SE10210 f13(.p2(n293_f13_2),.p3(n292_f13_3),.p4(n294_f13_4),.p5(n282),.p6(n302),.p7(n228),.p8(1'b0),.p9(1'b0),.p10(n171),.p11(n302),.p12(n284_f13_12),.p13(n283_f13_13),.p14(n285_f13_14),.p15(n73),.p16(1'b0));
 sampled_MC10231 f14(.p1(1'b0),.p2(n179_f14_2),.p3(n174_f14_3),.p4(n69),.p5(1'b0),.p6(n172),.p7(n270),.p8(1'b0),.p9(n251),.p10(n270),.p11(n172),.p12(1'b0),.p13(n69),.p14(n173_f14_14),.p15(n178_f14_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[40+:2]),.state_q(state_q[40+:2]));
 sampled_MC10231 f15(.p1(1'b0),.p2(n180_f15_2),.p3(n181_f15_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n52),.p8(1'b0),.p9(n252),.p10(n271),.p11(1'b0),.p12(n69),.p13(1'b0),.p14(n176_f15_14),.p15(n177_f15_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[42+:2]),.state_q(state_q[42+:2]));
 comb_MC1660 f16(.p2(n271_f16_2),.p3(n270_f16_3),.p4(1'b0),.p5(1'b0),.p6(n172),.p7(n120),.p8(1'b0),.p10(n55),.p11(n56),.p12(n57),.p13(1'b0),.p14(n108_f16_14));
 comb_MC1660 f17(.p3(n270_f17_3),.p4(n121),.p5(n149),.p6(n265),.p7(n113),.p8(1'b0),.p10(n43),.p11(n23),.p12(n148),.p13(n121),.p14(n270_f17_14));
 comb_SE10211 f19(.p2(n26_f19_2),.p4(n27_f19_4),.p5(1'b0),.p6(n25),.p7(1'b0),.p9(1'b0),.p10(n25),.p11(n176),.p12(n150_f19_12),.p13(n149_f19_13),.p14(n151_f19_14),.p15(n74),.p16(1'b0));
 comb_MC1660 f20(.p2(n148_f20_2),.p3(n147_f20_3),.p4(n25),.p5(1'b0),.p6(1'b0),.p7(n176),.p8(1'b0),.p10(n88),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n25_f20_14),.p15(n24_f20_15));
 comb_MC10104 g04(.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(n227),.p13(n156),.p15(n266_g04_15),.p16(1'b0));
 comb_MC10195 g05(.p2(n170_g05_2),.p3(n162_g05_3),.p4(n223_g05_4),.p5(n169),.p6(n161),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p12(n86),.p13(n222_g05_13),.p15(n87_g05_15));
 comb_MC10121 g10(.p3(n117_g10_3),.p4(n2),.p5(1'b0),.p6(1'b0),.p7(n6),.p9(n9),.p10(n4),.p11(1'b0),.p12(n8),.p13(n0),.p14(n216),.p15(n217));
 comb_MC10102 g11(.p1(1'b0),.p2(n47_g11_2),.p3(n116_g11_3),.p4(n128),.p5(n226),.p6(n4),.p7(n10),.p9(n7_g11_9),.p10(1'b0),.p11(n3),.p12(n207),.p13(n208),.p14(n116_g11_14),.p15(n8_g11_15),.p16(1'b0));
 comb_SE10212 g12(.p1(1'b0),.p4(n281_g12_4),.p5(n233),.p6(1'b0),.p7(n306),.p8(1'b0),.p9(n306),.p10(1'b0),.p11(n233),.p14(n299_g12_14),.p15(n75),.p16(1'b0));
 comb_SE10210 g13(.p2(n288_g13_2),.p3(n287_g13_3),.p4(n291_g13_4),.p5(n166),.p6(n303),.p7(n229),.p8(1'b0),.p9(n166),.p10(n303),.p11(n229),.p12(n290_g13_12),.p13(n289_g13_13),.p15(n76),.p16(1'b0));
 comb_MC1662 g15(.p2(n52_g15_2),.p3(n175_g15_3),.p4(n119),.p5(n23),.p6(n173),.p7(n176),.p10(n51),.p11(n49),.p12(n48),.p13(n50),.p14(n120_g15_14),.p15(n121_g15_15));
 comb_MC10103 h03(.p1(1'b0),.p2(n266_h03_2),.p3(n44_h03_3),.p4(n267),.p5(1'b0),.p6(n309),.p7(n155),.p10(n32),.p11(n33),.p12(1'b0),.p13(1'b0),.p14(n45_h03_14),.p16(1'b0));
 sampled_MC10141 h08(.p1(1'b0),.p2(n17_h08_2),.p3(n19_h08_3),.p4(n249),.p5(1'b0),.p6(n241),.p7(n22),.p8(1'b0),.p9(n239),.p10(n22),.p11(n237),.p12(n235),.p13(1'b0),.p14(n13_h08_14),.p15(n15_h08_15),.fixture_load(fixture_load),.fixture_state(fixture_state[32+:4]),.state_q(state_q[32+:4]));
 sampled_MC10141 h09(.p1(1'b0),.p2(n16_h09_2),.p3(n18_h09_3),.p4(n250),.p5(1'b0),.p6(n240),.p7(n22),.p8(1'b0),.p9(n238),.p10(n22),.p11(n236),.p12(n234),.p13(1'b0),.p14(n12_h09_14),.p15(n14_h09_15),.fixture_load(fixture_load),.fixture_state(fixture_state[36+:4]),.state_q(state_q[36+:4]));
 comb_MC10166 h10(.p2(n22_h10_2),.p4(1'b0),.p5(1'b0),.p6(n18),.p7(n118),.p9(n12),.p10(n115),.p11(n116),.p12(n14),.p13(n16),.p14(n117),.p15(n148));
 comb_MC10166 h11(.p2(n51_h11_2),.p3(n48_h11_3),.p4(1'b0),.p5(1'b0),.p6(n118),.p7(n280),.p9(n115),.p10(n277),.p11(n278),.p12(n116),.p13(n117),.p14(n279),.p15(n147));
 comb_MC10159 h13(.p1(n280_h13_1),.p2(n279_h13_2),.p3(n40),.p4(n17),.p5(n42),.p6(n19),.p7(1'b0),.p9(n178),.p10(n36),.p11(n13),.p12(n38),.p13(n15),.p14(n277_h13_14),.p15(n278_h13_15));
 comb_MC10159 h14(.p1(n112_h14_1),.p2(n111_h14_2),.p3(n40),.p4(n17),.p5(n42),.p6(n19),.p7(1'b0),.p9(n178),.p10(n36),.p11(n13),.p12(n38),.p13(n15),.p14(n109_h14_14),.p15(n110_h14_15));
 sampled_MC10176 i03(.p1(1'b0),.p2(n62_i03_2),.p3(n63_i03_3),.p4(n64_i03_4),.p5(n164),.p6(n62),.p7(n63),.p8(1'b0),.p9(n154),.p10(n161),.p11(n61),.p12(n60),.p13(n61_i03_13),.p14(n60_i03_14),.p15(n267_i03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 comb_MC10104 i04(.p2(n269_i04_2),.p3(n54_i04_3),.p4(n122),.p5(n169),.p6(n53),.p7(n122),.p10(n170),.p11(n232),.p12(n58),.p13(n161),.p14(n314_i04_14),.p15(n224_i04_15),.p16(1'b0));
 comb_MC10210 i05(.p1(1'b0),.p2(n229_i05_2),.p3(n228_i05_3),.p4(n230_i05_4),.p5(n168),.p6(n152),.p7(1'b0),.p8(1'b0),.p9(n152),.p10(1'b0),.p11(n168),.p12(n232_i05_12),.p13(n231_i05_13),.p14(n233_i05_14),.p15(n77),.p16(1'b0));
 comb_SE10210 i06(.p2(n154_i06_2),.p3(n153_i06_3),.p5(1'b0),.p6(1'b0),.p7(n283),.p8(1'b0),.p9(1'b0),.p10(n70),.p11(n286),.p12(n160_i06_12),.p13(n159_i06_13),.p15(n78),.p16(1'b0));
 comb_SE10210 i07(.p2(n263_i07_2),.p3(n262_i07_3),.p4(n264_i07_4),.p5(1'b0),.p6(1'b0),.p7(n299),.p8(1'b0),.p9(n114),.p10(1'b0),.p11(1'b0),.p12(n70_i07_12),.p13(n69_i07_13),.p14(n68_i07_14),.p15(n79),.p16(1'b0));
 comb_MC10166 i10(.p2(n49_i10_2),.p3(n50_i10_3),.p4(1'b0),.p5(1'b0),.p6(n118),.p7(n41),.p9(n115),.p10(n35),.p11(n37),.p12(n116),.p13(n117),.p14(n39),.p15(n148));
 comb_MC10101 i11(.p2(n235_i11_2),.p3(n237_i11_3),.p4(n115),.p5(n234_i11_5),.p6(n236_i11_6),.p7(n116),.p9(n240_i11_9),.p10(n117),.p11(n238_i11_11),.p12(1'b0),.p13(n118),.p14(n239_i11_14),.p15(n241_i11_15));
 sampled_MC10231 j01(.p1(1'b0),.p3(n34_j01_3),.p4(1'b0),.p5(n225),.p6(n281),.p7(n126),.p8(1'b0),.p9(1'b0),.p10(n127),.p11(n261),.p12(1'b0),.p13(n314),.p14(n130_j01_14),.p15(n129_j01_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:2]),.state_q(state_q[30+:2]));
 sampled_MC10231 j04(.p1(1'b0),.p2(n168_j04_2),.p4(n309),.p5(1'b0),.p6(n261),.p7(n269),.p8(1'b0),.p9(1'b0),.p10(n267),.p11(n153),.p12(1'b0),.p13(1'b0),.p14(n152_j04_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:2]),.state_q(state_q[6+:2]));
 comb_MC10117 j05(.p2(n53_j05_2),.p3(n268_j05_3),.p4(n131),.p5(n123),.p6(1'b0),.p7(n130),.p9(1'b0),.p10(n244),.p11(n64),.p12(n244),.p13(n65),.p14(n269_j05_14));
 comb_SE10210 j06(.p2(n260_j06_2),.p3(n259_j06_3),.p4(n261_j06_4),.p5(1'b0),.p6(n296),.p7(1'b0),.p8(1'b0),.p9(n296),.p10(1'b0),.p11(n59),.p12(n183_j06_12),.p13(n182_j06_13),.p14(n184_j06_14),.p15(n81),.p16(1'b0));
 comb_SE10210 j07(.p2(n273_j07_2),.p3(n272_j07_3),.p5(n70),.p6(n147),.p7(n288),.p8(1'b0),.p9(n288),.p10(1'b0),.p11(1'b0),.p12(n250_j07_12),.p13(n249_j07_13),.p15(n82),.p16(1'b0));
 sampled_MC10231 j08(.p1(1'b0),.p2(n37_j08_2),.p3(n38_j08_3),.p4(n307),.p5(n311),.p6(1'b0),.p7(n278),.p8(1'b0),.p9(n272),.p10(n277),.p11(1'b0),.p12(n310),.p13(n307),.p14(n36_j08_14),.p15(n35_j08_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[44+:2]),.state_q(state_q[44+:2]));
 sampled_MC10231 j09(.p1(1'b0),.p2(n41_j09_2),.p3(n42_j09_3),.p4(n307),.p5(n313),.p6(1'b0),.p7(n280),.p8(1'b0),.p9(n273),.p10(n279),.p11(1'b0),.p12(n312),.p13(n307),.p14(n40_j09_14),.p15(n39_j09_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[46+:2]),.state_q(state_q[46+:2]));
 comb_MC10109 j10(.p3(n113_j10_3),.p4(n280),.p5(n279),.p6(n278),.p7(n277),.p8(1'b0),.p9(1'b0),.p10(n35),.p11(n37),.p12(n41),.p13(n39),.p14(n43_j10_14));
 comb_MC10113 j11(.p1(1'b0),.p2(n119_j11_2),.p3(n119_j11_3),.p4(n241),.p5(n42),.p6(n40),.p7(n239),.p9(1'b0),.p10(n38),.p11(n237),.p12(n36),.p13(n235),.p14(n119_j11_14),.p15(n119_j11_15));
 comb_SE10210 j18(.p2(n255_j18_2),.p3(n254_j18_3),.p4(n256_j18_4),.p5(1'b0),.p6(1'b0),.p7(n291),.p8(1'b0),.p9(n70),.p10(n151),.p11(n291),.p12(n275_j18_12),.p13(n274_j18_13),.p14(n276_j18_14),.p15(n83),.p16(1'b0));
 sampled_MC10231 k01(.p1(1'b0),.p3(n30_k01_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n267),.p8(1'b0),.p9(n284),.p10(n267),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n29_k01_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:2]),.state_q(state_q[8+:2]));
 sampled_MC10231 k02(.p1(1'b0),.p2(n30_k02_2),.p4(n309),.p5(1'b0),.p6(1'b0),.p7(n269),.p8(1'b0),.p9(n297),.p10(n269),.p11(1'b0),.p12(1'b0),.p13(n309),.p15(n29_k02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[10+:2]),.state_q(state_q[10+:2]));
 sampled_MC10231 k03(.p1(1'b0),.p2(n107_k03_2),.p3(n106_k03_3),.p4(1'b0),.p5(1'b0),.p6(n305),.p7(n11),.p8(1'b0),.p9(1'b0),.p10(n268),.p11(n297),.p12(1'b0),.p13(n314),.p14(n167_k03_14),.p15(n286_k03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[22+:2]),.state_q(state_q[22+:2]));
 sampled_MC10231 k04(.p1(1'b0),.p2(n157_k04_2),.p3(n158_k04_3),.p4(n314),.p5(1'b0),.p6(n70),.p7(n268),.p8(1'b0),.p9(n263),.p10(n268),.p11(1'b0),.p12(1'b0),.p13(n314),.p14(n166_k04_14),.p15(n165_k04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[24+:2]),.state_q(state_q[24+:2]));
 sampled_MC10231 k05(.p1(1'b0),.p2(n127_k05_2),.p3(n128_k05_3),.p4(n314),.p5(1'b0),.p6(1'b0),.p7(n125),.p8(1'b0),.p9(n263),.p10(n124),.p11(1'b0),.p12(1'b0),.p13(n314),.p14(n126_k05_14),.p15(n125_k05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:2]),.state_q(state_q[26+:2]));
 comb_SE10210 l01(.p2(n306_l01_2),.p3(n305_l01_3),.p5(1'b0),.p6(1'b0),.p7(n28),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n28),.p12(n303_l01_12),.p13(n302_l01_13),.p14(n304_l01_14),.p15(n84),.p16(1'b0));
 sampled_MC10231 l02(.p1(1'b0),.p2(n31_l02_2),.p4(n309),.p5(1'b0),.p6(n298),.p7(n269),.p8(1'b0),.p9(1'b0),.p10(n267),.p11(n285),.p12(1'b0),.p13(1'b0),.p14(n31_l02_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:2]),.state_q(state_q[12+:2]));
 sampled_MC10231 l03(.p1(1'b0),.p3(n105_l03_3),.p4(1'b0),.p5(n155),.p6(1'b0),.p7(n266),.p8(1'b0),.p9(n285),.p10(n266),.p11(1'b0),.p12(n155),.p13(1'b0),.p14(n104_l03_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[14+:2]),.state_q(state_q[14+:2]));
 sampled_MC10231 l04(.p1(1'b0),.p2(n105_l04_2),.p4(n44),.p5(1'b0),.p6(1'b0),.p7(n269),.p8(1'b0),.p9(n297),.p10(n269),.p11(1'b0),.p12(1'b0),.p13(n44),.p15(n104_l04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:2]),.state_q(state_q[16+:2]));
 sampled_MC10231 l05(.p1(1'b0),.p2(n171_l05_2),.p3(n11_l05_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n11),.p8(1'b0),.p9(n305),.p10(n163),.p11(n171),.p12(1'b0),.p13(1'b0),.p15(n227_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[18+:2]),.state_q(state_q[18+:2]));
 sampled_SE10231 l06(.p3(n282_l06_3),.p6(n231),.p7(n286),.p9(n305),.p10(n227),.p11(n171),.p13(1'b0),.p14(n156_l06_14),.p15(n155_l06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:2]),.state_q(state_q[20+:2]));
 sampled_MC10231 l07(.p1(1'b0),.p2(n124_l07_2),.p4(n314),.p5(1'b0),.p6(1'b0),.p7(n54),.p8(1'b0),.p9(n264),.p10(n165),.p11(1'b0),.p12(n314),.p13(1'b0),.p14(n123_l07_14),.p15(n122_l07_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[28+:2]),.state_q(state_q[28+:2]));
 comb_MC10211 l08(.p2(n245_l08_2),.p3(n243_l08_3),.p4(n244_l08_4),.p5(1'b0),.p6(n286),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n85),.p16(1'b0));
 assign clocks[0]=n305;
 assign clocks[1]=n171;
 assign clocks[2]=n285;
 assign clocks[3]=n153;
 assign clocks[4]=n297;
 assign clocks[5]=n261;
 assign clocks[6]=l06.ca;
 assign clocks[7]=k04.ca;
 assign clocks[8]=n281;
 assign clocks[9]=n249;
 assign clocks[10]=n272;
 assign clocks[11]=n274;
 assign clocks[12]=f14.ca;
 assign flags[0]=n24;
 assign flags[1]=n147;
 assign flags[2]=n70;
 assign flags[3]=n31;
 assign flags[4]=n30;
 assign flags[5]=n167;
 assign flags[6]=n109;
 assign flags[7]=n110;
 assign flags[8]=n111;
 assign flags[9]=n112;
 assign flags[10]=n20;
 assign flags[11]=n178;
 assign flags[12]=n176;
 assign flags[13]=n68;
endmodule
`default_nettype wire

`timescale 1ns/1ps
`default_nettype none
module r_front_proch_sampled(input wire fixture_load,input wire [279:0] fixture_state,
 input wire base,start_a,en,input wire [235:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,rb_forward,rb_forward_n,
 output wire [279:0] state_q,output wire [14:0] clocks,
 output wire [26:0] flags);
 wire n0; // ALUCarry
 wire n1; // ASEL.0'
 wire n2; // ASEL.1'
 wire n3; // ASEL.2'
 wire n4; // ASel.0
 wire n5; // ASel.0'
 wire n6; // ASel=2/3'
 wire n7; // ASel=5/7
 wire n8; // ASel=5/7'
 wire n9; // ASel=6/7
 wire n10; // ASel=6/7'
 wire n11; // BCWriteEn'
 wire n12; // BNTGtCT
 wire n13; // BNTGtCT'a
 wire n14; // BSEL.0'
 wire n15; // BSEL.1'
 wire n16; // BSEL.2'
 wire n17; // BSel.0'a
 wire n18; // BSel.0a
 wire n19; // BSel.1'a
 wire n20; // BSel.1a
 wire n21; // BSel.2'a
 wire n22; // BSel.2a
 wire n23; // BSel=2/6
 wire n24; // B_Ext
 wire n25; // B_Ext'
 wire n26; // BumpRSTK
 wire n27; // CLK.ph'
 wire n28; // CLKEnable'c
 wire n29; // Clock0'Bb
 wire n30; // Clock0'Bc
 wire n31; // Clock0'Da
 wire n32; // Clock0'Dc
 wire n33; // Clock0'Dd
 wire n34; // Clock0En'
 wire n35; // Clock1'Ba
 wire n36; // Clock1'Bb
 wire n37; // Clock1'Ca
 wire n38; // Clock1'Cb
 wire n39; // Clock1'Cd
 wire n40; // Clock1'Da
 wire n41; // Clock1'Dc
 wire n42; // Clock1Bd
 wire n43; // Curr.0'
 wire n44; // Curr.1'
 wire n45; // Curr.2'
 wire n46; // Curr.3'
 wire n47; // Curr=Next'
 wire n48; // CurrLast.0'
 wire n49; // CurrLast.1'
 wire n50; // CurrLast.2'
 wire n51; // CurrLast.3'
 wire n52; // DMData
 wire n53; // DMuxData
 wire n54; // DblClock'Da
 wire n55; // DsMd
 wire n56; // DsPd
 wire n57; // DsRd
 wire n58; // FA=0'
 wire n59; // FA=0'a
 wire n60; // FA=0'b
 wire n61; // FA=1'a
 wire n62; // FA=2'a
 wire n63; // FA=3'
 wire n64; // FB=0'
 wire n65; // FB=2'
 wire n66; // FB=3'
 wire n67; // FB=4'
 wire n68; // FB=5'
 wire n69; // FB=6'
 wire n70; // FB=7'
 wire n71; // FC=2/3'
 wire n72; // FC=4/5'
 wire n73; // FC=5'
 wire n74; // FC=6'
 wire n75; // FC=7'
 wire n76; // FF.0
 wire n77; // FF.0a
 wire n78; // FF.0mem
 wire n79; // FF.0mem'
 wire n80; // FF.1
 wire n81; // FF.1a
 wire n82; // FF.1mem
 wire n83; // FF.2
 wire n84; // FF.2'a
 wire n85; // FF.2a
 wire n86; // FF.3
 wire n87; // FF.3'a
 wire n88; // FF.3a
 wire n89; // FF.4
 wire n90; // FF.4a
 wire n91; // FF.5
 wire n92; // FF.5'a
 wire n93; // FF.5a
 wire n94; // FF.6
 wire n95; // FF.6'a
 wire n96; // FF.6a
 wire n97; // FF.7
 wire n98; // FF.7'a
 wire n99; // FF.7a
 wire n100; // FFok'a
 wire n101; // Freeze
 wire n102; // GND132
 wire n103; // GND142
 wire n104; // GND188
 wire n105; // GND264
 wire n106; // GND266
 wire n107; // GND312
 wire n108; // GND314
 wire n109; // GND394
 wire n110; // GND40
 wire n111; // GND420
 wire n112; // GND442
 wire n113; // GND468
 wire n114; // GND500
 wire n115; // GND530
 wire n116; // GND544
 wire n117; // GND546
 wire n118; // Hold
 wire n119; // Hold'
 wire n120; // HoldDly
 wire n121; // Holda
 wire n122; // IOB.Perr'
 wire n123; // IOBout
 wire n124; // LC.0
 wire n125; // LC.1
 wire n126; // LC.1'a
 wire n127; // LC.1a
 wire n128; // LC.2
 wire n129; // Last.0'
 wire n130; // Last.1'
 wire n131; // Last.2'
 wire n132; // Last.3'
 wire n133; // Last=Curr'
 wire n134; // LastNext.0'
 wire n135; // LastNext.1'
 wire n136; // LastNext.2'
 wire n137; // LastNext.3'
 wire n138; // MBBypass
 wire n139; // MBWriteEn'
 wire n140; // Next.0
 wire n141; // Next.0'
 wire n142; // Next.1
 wire n143; // Next.1'
 wire n144; // Next.2
 wire n145; // Next.2'
 wire n146; // Next.3
 wire n147; // Next.3'
 wire n148; // NextMacro
 wire n149; // Overflow'
 wire n150; // PRhold
 wire n151; // Pdata.00
 wire n152; // Pdata.01
 wire n153; // Pdata.02
 wire n154; // Pdata.03
 wire n155; // Pdata.04
 wire n156; // Pdata.05
 wire n157; // Pdata.06
 wire n158; // Pdata.07
 wire n159; // PostClock0'Bc
 wire n160; // PreClock0'A
 wire n161; // PreClock0'B
 wire n162; // PreClock0'C
 wire n163; // PreClock0'D
 wire n164; // PreClock1'A
 wire n165; // PreClock1'B
 wire n166; // PreClock1'C
 wire n167; // PreClock1'D
 wire n168; // PreClock1B
 wire n169; // PreDblClock'D
 wire n170; // PreFA=0
 wire n171; // PreFA=1'
 wire n172; // PreSHCP'A
 wire n173; // PreSHCP'B
 wire n174; // PreSHCP'C
 wire n175; // PreSHCP'Shc
 wire n176; // PreSHSelect'D
 wire n177; // ProcH02.sil+4
 wire n178; // ProcH03.sil+1
 wire n179; // ProcH03.sil+5
 wire n180; // ProcH04.sil+1
 wire n181; // ProcH04.sil+5
 wire n182; // ProcH05.sil+1
 wire n183; // ProcH05.sil+5
 wire n184; // ProcH06.sil+1
 wire n185; // ProcH06.sil+5
 wire n186; // ProcH07.sil+1
 wire n187; // ProcH07.sil+5
 wire n188; // ProcH08.sil+1
 wire n189; // ProcH08.sil+5
 wire n190; // ProcH09.sil+1
 wire n191; // ProcH09.sil+5
 wire n192; // ProcH10.sil+1
 wire n193; // ProcH10.sil+2
 wire n194; // ProcH10.sil+3
 wire n195; // ProcH11.sil+1
 wire n196; // ProcH11.sil+12
 wire n197; // ProcH11.sil+13
 wire n198; // ProcH11.sil+14
 wire n199; // ProcH11.sil+15
 wire n200; // ProcH11.sil+9
 wire n201; // ProcH12.sil+1
 wire n202; // ProcH12.sil+2
 wire n203; // ProcH12.sil+3
 wire n204; // ProcH12.sil+4
 wire n205; // ProcH12.sil+5
 wire n206; // ProcH13.sil+1
 wire n207; // ProcH15.sil+1
 wire n208; // ProcH17.sil+2
 wire n209; // ProcH17.sil+3
 wire n210; // ProcH20.sil+1
 wire n211; // ProcH20.sil+2
 wire n212; // ProcH20.sil+3
 wire n213; // ProcH20.sil+4
 wire n214; // ProcH20.sil+5
 wire n215; // ProcH20.sil+6
 wire n216; // ProcH22.sil+1
 wire n217; // ProcH22.sil+2
 wire n218; // ProcH22.sil+3
 wire n219; // ProcH22.sil+4
 wire n220; // ProcH22.sil+5
 wire n221; // ProcH22.sil+6
 wire n222; // ProcH24.sil+1
 wire n223; // ProcH24.sil+2
 wire n224; // ProcH24.sil+3
 wire n225; // ProcH24.sil+4
 wire n226; // ProcH25.sil+1
 wire n227; // ProcH25.sil+18
 wire n228; // ProcH25.sil+7
 wire n229; // ProcH26.sil+1
 wire n230; // ProcH26.sil+3
 wire n231; // ProcH27.sil+1
 wire n232; // ProcH27.sil+10
 wire n233; // ProcH27.sil+12
 wire n234; // ProcH27.sil+7
 wire n235; // ProcH27.sil+8
 wire n236; // ProcH27.sil+9
 wire n237; // ProcH30.sil+1
 wire n238; // PropCnt'
 wire n239; // R.00
 wire n240; // R.01
 wire n241; // R.02
 wire n242; // R.03
 wire n243; // R.04
 wire n244; // R.05
 wire n245; // R.06
 wire n246; // R.07
 wire n247; // R.Perr'
 wire n248; // RSTK.0
 wire n249; // RSTK.1
 wire n250; // RSTK.2
 wire n251; // RSTK.3
 wire n252; // RbAdr.4'
 wire n253; // RbAdr.5'
 wire n254; // RbAdr.6'
 wire n255; // RbAdr.7'
 wire n256; // RbBypass
 wire n257; // RbBypass'
 wire n258; // RbBypassDly
 wire n259; // RbSelMd
 wire n260; // RbSelMd'
 wire n261; // RbWadr.4
 wire n262; // RbWadr.5
 wire n263; // RbWadr.6
 wire n264; // RbWadr.7
 wire n265; // RbWrite'a
 wire n266; // RbWrite'b
 wire n267; // RbWrite'c
 wire n268; // RbWriteEn'
 wire n269; // RepeatCurrB
 wire n270; // RepeatCurrC
 wire n271; // RepeatCurrD
 wire n272; // RisIFdata
 wire n273; // RmLtZero'
 wire n274; // Rparity
 wire n275; // SHCP'C
 wire n276; // ShiftBitsEn'
 wire n277; // SignIfuData
 wire n278; // StartCycle'a
 wire n279; // T.00
 wire n280; // T.01
 wire n281; // T.02
 wire n282; // T.03
 wire n283; // T.04
 wire n284; // T.05
 wire n285; // T.06
 wire n286; // T.07
 wire n287; // T.Perr'
 wire n288; // TIOAWrite'
 wire n289; // TIOAWriteEn'
 wire n290; // Task2Bk.3'
 wire n291; // Task3Bk.3'
 wire n292; // TbBypass
 wire n293; // TbSelMd
 wire n294; // TbWrite'a
 wire n295; // TbWrite'b
 wire n296; // TbWriteEn'
 wire n297; // TisIFdata
 wire n298; // Tparity
 wire n299; // TrueA
 wire n300; // dMD.00
 wire n301; // dMD.01
 wire n302; // dMD.02
 wire n303; // dMD.03
 wire n304; // dMD.04
 wire n305; // dMD.05
 wire n306; // dMD.06
 wire n307; // dMD.07
 wire n308; // dR.00
 wire n309; // dR.01
 wire n310; // dR.02
 wire n311; // dR.03
 wire n312; // dR.04
 wire n313; // dR.05
 wire n314; // dR.06
 wire n315; // dR.07
 wire n316; // dRm.00
 wire n317; // dRm.01
 wire n318; // dRm.02
 wire n319; // dRm.03
 wire n320; // dRm.04
 wire n321; // dRm.05
 wire n322; // dRm.06
 wire n323; // dRm.07
 wire n324; // dT.00
 wire n325; // dT.01
 wire n326; // dT.02
 wire n327; // dT.03
 wire n328; // dT.04
 wire n329; // dT.05
 wire n330; // dT.06
 wire n331; // dT.07
 wire n332; // dTm.00
 wire n333; // dTm.01
 wire n334; // dTm.02
 wire n335; // dTm.03
 wire n336; // dTm.04
 wire n337; // dTm.05
 wire n338; // dTm.06
 wire n339; // dTm.07
 wire n340; // ddR.00
 wire n341; // pClock1En'
 wire n342; // ppClk'a
 wire n343; // ppClk'b
 wire n344; // ppClk'c
 assign n102=1'b0;
 assign n103=1'b0;
 assign n104=1'b0;
 assign n105=1'b0;
 assign n106=1'b0;
 assign n107=1'b0;
 assign n108=1'b0;
 assign n109=1'b0;
 assign n110=1'b0;
 assign n111=1'b0;
 assign n112=1'b0;
 assign n113=1'b0;
 assign n114=1'b0;
 assign n115=1'b0;
 assign n116=1'b0;
 assign n117=1'b0;
 assign n0=pins[110];
 assign n1=pins[202];
 assign n2=pins[203];
 assign n3=pins[204];
 assign n13=priority_n;
 assign n14=pins[205];
 assign n15=pins[206];
 assign n16=pins[207];
 assign n27=base;
 assign n28=en;
 assign n53=pins[208];
 assign n61=(pins[19:18]!=2'd1);
 assign n73=(pins[14:12]!=3'd5);
 assign n74=(pins[14:12]!=3'd6);
 assign n75=(pins[14:12]!=3'd7);
 assign n76=pins[19];
 assign n80=pins[18];
 assign n83=pins[17];
 assign n86=pins[16];
 assign n89=pins[15];
 assign n91=pins[14];
 assign n94=pins[13];
 assign n97=pins[12];
 assign n100=pins[209];
 assign n101=freeze;
 assign n121=pins[68];
 assign n123=pins[210];
 assign n124=pins[11];
 assign n125=pins[10];
 assign n128=pins[9];
 assign n138=pins[211];
 assign n140=next_raw[0];
 assign n142=next_raw[1];
 assign n144=next_raw[2];
 assign n146=next_raw[3];
 assign n148=pins[212];
 assign n149=pins[111];
 assign n150=pins[68];
 assign n151=pins[76];
 assign n152=pins[77];
 assign n153=pins[78];
 assign n154=pins[79];
 assign n155=pins[80];
 assign n156=pins[81];
 assign n157=pins[82];
 assign n158=pins[83];
 assign n178=pins[128];
 assign n180=pins[129];
 assign n182=pins[130];
 assign n184=pins[131];
 assign n186=pins[132];
 assign n188=pins[133];
 assign n190=pins[134];
 assign n198=pins[145];
 assign n209=pins[181];
 assign n226=pins[213];
 assign n227=pins[214];
 assign n230=pins[215];
 assign n231=pins[143];
 assign n233=pins[216];
 assign n238=pins[180];
 assign n248=pins[172];
 assign n249=pins[173];
 assign n250=pins[174];
 assign n251=pins[175];
 assign n256=rb_forward;
 assign n257=rb_forward_n;
 assign n272=pins[149];
 assign n277=pins[118];
 assign n278=start_a;
 assign n289=pins[217];
 assign n297=pins[117];
 assign n300=pins[92];
 assign n301=pins[93];
 assign n302=pins[94];
 assign n303=pins[95];
 assign n304=pins[96];
 assign n305=pins[97];
 assign n306=pins[98];
 assign n307=pins[99];
 assign n340=pins[127];
 wire n4_b23_2;
 assign n4=n4_b23_2;
 wire n5_b23_5;
 assign n5=n5_b23_5;
 wire n6_b23_3;
 assign n6=n6_b23_3;
 wire n7_b23_15;
 assign n7=n7_b23_15;
 wire n8_b23_9;
 assign n8=n8_b23_9;
 wire n9_b23_14;
 assign n9=n9_b23_14;
 wire n10_b23_11;
 assign n10=n10_b23_11;
 wire n11_g18_2;
 assign n11=n11_g18_2;
 wire n12_a01_2;
 assign n12=n12_a01_2;
 wire n17_h24_5;
 assign n17=n17_h24_5;
 wire n18_h24_2;
 assign n18=n18_h24_2;
 wire n19_h24_6;
 assign n19=n19_h24_6;
 wire n20_h24_3;
 assign n20=n20_h24_3;
 wire n21_h24_11;
 assign n21=n21_h24_11;
 wire n22_h24_14;
 assign n22=n22_h24_14;
 wire n23_f18_15;
 assign n23=n23_f18_15;
 wire n24_f19_3;
 assign n24=n24_f19_3;
 wire n25_f19_2;
 assign n25=n25_f19_2;
 wire n26_g20_2;
 assign n26=n26_g20_2;
 wire n29_k10_4;
 assign n29=n29_k10_4;
 wire n30_k10_2;
 assign n30=n30_k10_2;
 wire n31_i18_3;
 assign n31=n31_i18_3;
 wire n32_i18_2;
 assign n32=n32_i18_2;
 wire n33_i18_4;
 assign n33=n33_i18_4;
 wire n34_l01_4;
 assign n34=n34_l01_4;
 wire n35_i05_3;
 assign n35=n35_i05_3;
 wire n36_i05_4;
 assign n36=n36_i05_4;
 wire n37_c18_3;
 assign n37=n37_c18_3;
 wire n38_c18_2;
 assign n38=n38_c18_2;
 wire n39_c18_4;
 assign n39=n39_c18_4;
 wire n40_i18_13;
 assign n40=n40_i18_13;
 wire n41_i18_12;
 assign n41=n41_i18_12;
 wire n42_i05_2;
 assign n42=n42_i05_2;
 wire n43_a21_14;
 assign n43=n43_a21_14;
 wire n44_a21_15;
 assign n44=n44_a21_15;
 wire n45_a21_2;
 assign n45=n45_a21_2;
 wire n46_a21_3;
 assign n46=n46_a21_3;
 wire n47_a22_3;
 wire n47_a22_2;
 wire n47_a22_15;
 wire n47_a22_14;
 assign n47=n47_a22_3 | n47_a22_2 | n47_a22_15 | n47_a22_14;
 wire n48_i12_14;
 assign n48=n48_i12_14;
 wire n49_i12_15;
 assign n49=n49_i12_15;
 wire n50_i12_2;
 assign n50=n50_i12_2;
 wire n51_i12_3;
 assign n51=n51_i12_3;
 wire n52_h17_2;
 assign n52=n52_h17_2;
 wire n54_j18_2;
 assign n54=n54_j18_2;
 wire n55_l09_2;
 wire n55_l08_3;
 assign n55=n55_l09_2 | n55_l08_3;
 wire n56_l08_12;
 wire n56_l08_2;
 assign n56=n56_l08_12 | n56_l08_2;
 wire n57_l09_3;
 wire n57_l08_13;
 assign n57=n57_l09_3 | n57_l08_13;
 wire n58_c23_4;
 wire n58_d22_2;
 assign n58=n58_c23_4 | n58_d22_2;
 wire n59_d22_3;
 wire n59_c23_3;
 assign n59=n59_d22_3 | n59_c23_3;
 wire n60_c23_2;
 wire n60_d22_4;
 assign n60=n60_c23_2 | n60_d22_4;
 wire n62_c23_12;
 wire n62_d23_11;
 wire n62_d24_14;
 assign n62=n62_c23_12 | n62_d23_11 | n62_d24_14;
 wire n63_d23_2;
 wire n63_d24_3;
 wire n63_c23_14;
 assign n63=n63_d23_2 | n63_d24_3 | n63_c23_14;
 wire n64_e24_6;
 assign n64=n64_e24_6;
 wire n65_e24_4;
 assign n65=n65_e24_4;
 wire n66_e24_3;
 assign n66=n66_e24_3;
 wire n67_e24_13;
 assign n67=n67_e24_13;
 wire n68_e24_12;
 assign n68=n68_e24_12;
 wire n69_e24_11;
 assign n69=n69_e24_11;
 wire n70_e24_10;
 assign n70=n70_e24_10;
 wire n71_f23_15;
 wire n71_f23_11;
 assign n71=n71_f23_15 | n71_f23_11;
 wire n72_f23_14;
 wire n72_f23_9;
 assign n72=n72_f23_14 | n72_f23_9;
 wire n77_d24_6;
 assign n77=n77_d24_6;
 wire n78_d24_5;
 assign n78=n78_d24_5;
 wire n79_d24_2;
 assign n79=n79_d24_2;
 wire n81_d23_6;
 assign n81=n81_d23_6;
 wire n82_d23_5;
 assign n82=n82_d23_5;
 wire n84_e23_2;
 assign n84=n84_e23_2;
 wire n85_e23_5;
 assign n85=n85_e23_5;
 wire n87_e23_3;
 assign n87=n87_e23_3;
 wire n88_e23_6;
 assign n88=n88_e23_6;
 wire n90_e23_11;
 assign n90=n90_e23_11;
 wire n92_e23_15;
 assign n92=n92_e23_15;
 wire n93_e23_9;
 assign n93=n93_e23_9;
 wire n95_f23_2;
 assign n95=n95_f23_2;
 wire n96_f23_5;
 assign n96=n96_f23_5;
 wire n98_f23_3;
 assign n98=n98_f23_3;
 wire n99_f23_6;
 assign n99=n99_f23_6;
 wire n118_f19_15;
 assign n118=n118_f19_15;
 wire n119_f19_14;
 assign n119=n119_f19_14;
 wire n120_g18_15;
 assign n120=n120_g18_15;
 wire n122_h23_15;
 assign n122=n122_h23_15;
 wire n126_h24_15;
 assign n126=n126_h24_15;
 wire n127_h24_9;
 assign n127=n127_h24_9;
 wire n129_a20_14;
 assign n129=n129_a20_14;
 wire n130_a20_15;
 assign n130=n130_a20_15;
 wire n131_a20_2;
 assign n131=n131_a20_2;
 wire n132_a20_3;
 assign n132=n132_a20_3;
 wire n133_h22_15;
 assign n133=n133_h22_15;
 wire n134_a19_1;
 assign n134=n134_a19_1;
 wire n135_a19_2;
 assign n135=n135_a19_2;
 wire n136_a19_15;
 assign n136=n136_a19_15;
 wire n137_a19_14;
 assign n137=n137_a19_14;
 wire n139_g18_3;
 assign n139=n139_g18_3;
 wire n141_a24_15;
 assign n141=n141_a24_15;
 wire n143_a24_14;
 assign n143=n143_a24_14;
 wire n145_a24_3;
 assign n145=n145_a24_3;
 wire n147_a24_2;
 assign n147=n147_a24_2;
 wire n159_k10_12;
 assign n159=n159_k10_12;
 wire n160_f13_13;
 assign n160=n160_f13_13;
 wire n161_f13_12;
 assign n161=n161_f13_12;
 wire n162_f13_14;
 assign n162=n162_f13_14;
 wire n163_g13_3;
 assign n163=n163_g13_3;
 wire n164_f12_14;
 assign n164=n164_f12_14;
 wire n165_f13_2;
 assign n165=n165_f13_2;
 wire n166_f13_4;
 assign n166=n166_f13_4;
 wire n167_f13_3;
 assign n167=n167_f13_3;
 wire n168_f12_13;
 assign n168=n168_f12_13;
 wire n169_g13_13;
 assign n169=n169_g13_13;
 wire n170_d23_15;
 assign n170=n170_d23_15;
 wire n171_d24_11;
 wire n171_d23_3;
 assign n171=n171_d24_11 | n171_d23_3;
 wire n172_g12_3;
 assign n172=n172_g12_3;
 wire n173_g12_2;
 assign n173=n173_g12_2;
 wire n174_g12_4;
 assign n174=n174_g12_4;
 wire n175_f12_4;
 assign n175=n175_f12_4;
 wire n176_f12_3;
 assign n176=n176_f12_3;
 wire n177_l03_2;
 assign n177=n177_l03_2;
 wire n179_l03_1;
 assign n179=n179_l03_1;
 wire n181_l03_15;
 assign n181=n181_l03_15;
 wire n183_l03_14;
 assign n183=n183_l03_14;
 wire n185_l04_2;
 assign n185=n185_l04_2;
 wire n187_l04_1;
 assign n187=n187_l04_1;
 wire n189_l04_15;
 assign n189=n189_l04_15;
 wire n191_l04_14;
 assign n191=n191_l04_14;
 wire n192_l08_14;
 assign n192=n192_l08_14;
 wire n193_l09_4;
 assign n193=n193_l09_4;
 wire n194_l08_4;
 assign n194=n194_l08_4;
 wire n195_f20_2;
 wire n195_h17_15;
 assign n195=n195_f20_2 | n195_h17_15;
 wire n196_g18_14;
 assign n196=n196_g18_14;
 wire n197_g18_13;
 assign n197=n197_g18_13;
 wire n199_d20_14;
 assign n199=n199_d20_14;
 wire n200_g20_15;
 assign n200=n200_g20_15;
 wire n201_a24_9;
 wire n201_a24_11;
 wire n201_a24_6;
 wire n201_a24_5;
 assign n201=n201_a24_9 | n201_a24_11 | n201_a24_6 | n201_a24_5;
 wire n202_a18_2;
 assign n202=n202_a18_2;
 wire n203_a18_1;
 assign n203=n203_a18_1;
 wire n204_a18_15;
 assign n204=n204_a18_15;
 wire n205_a18_14;
 assign n205=n205_a18_14;
 wire n206_d24_9;
 wire n206_d23_14;
 assign n206=n206_d24_9 | n206_d23_14;
 wire n207_f20_14;
 assign n207=n207_f20_14;
 wire n208_h19_2;
 assign n208=n208_h19_2;
 wire n210_f20_15;
 wire n210_f18_3;
 assign n210=n210_f20_15 | n210_f18_3;
 wire n211_h23_2;
 assign n211=n211_h23_2;
 wire n212_h23_3;
 assign n212=n212_h23_3;
 wire n213_h23_14;
 assign n213=n213_h23_14;
 wire n214_f18_2;
 assign n214=n214_f18_2;
 wire n215_l09_12;
 assign n215=n215_l09_12;
 wire n216_h19_15;
 assign n216=n216_h19_15;
 wire n217_h19_9;
 assign n217=n217_h19_9;
 wire n218_k05_14;
 assign n218=n218_k05_14;
 wire n219_k05_15;
 assign n219=n219_k05_15;
 wire n220_k05_2;
 assign n220=n220_k05_2;
 wire n221_k05_1;
 assign n221=n221_k05_1;
 wire n222_f18_14;
 wire n222_d22_14;
 assign n222=n222_f18_14 | n222_d22_14;
 wire n223_f20_3;
 wire n223_d22_13;
 assign n223=n223_f20_3 | n223_d22_13;
 wire n224_d20_2;
 wire n224_d20_3;
 assign n224=n224_d20_2 | n224_d20_3;
 wire n225_g20_3;
 assign n225=n225_g20_3;
 wire n228_h17_14;
 assign n228=n228_h17_14;
 wire n229_a01_3;
 assign n229=n229_a01_3;
 wire n232_g21_15;
 assign n232=n232_g21_15;
 wire n234_i11_2;
 assign n234=n234_i11_2;
 wire n235_k04_2;
 assign n235=n235_k04_2;
 wire n236_g21_2;
 assign n236=n236_g21_2;
 wire n237_f12_2;
 assign n237=n237_f12_2;
 wire n239_g06_1;
 assign n239=n239_g06_1;
 wire n240_g06_2;
 assign n240=n240_g06_2;
 wire n241_g06_15;
 assign n241=n241_g06_15;
 wire n242_g06_14;
 assign n242=n242_g06_14;
 wire n243_g07_1;
 assign n243=n243_g07_1;
 wire n244_g07_2;
 assign n244=n244_g07_2;
 wire n245_g07_15;
 assign n245=n245_g07_15;
 wire n246_g07_14;
 assign n246=n246_g07_14;
 wire n247_c06_2;
 assign n247=n247_c06_2;
 wire n252_k08_15;
 wire n252_k08_2;
 assign n252=n252_k08_15 | n252_k08_2;
 wire n253_k08_14;
 wire n253_k08_3;
 assign n253=n253_k08_14 | n253_k08_3;
 wire n254_k09_2;
 wire n254_k09_15;
 assign n254=n254_k09_2 | n254_k09_15;
 wire n255_k09_3;
 wire n255_k09_14;
 assign n255=n255_k09_3 | n255_k09_14;
 wire n258_l07_15;
 assign n258=n258_l07_15;
 wire n259_h22_2;
 assign n259=n259_h22_2;
 wire n260_h22_3;
 assign n260=n260_h22_3;
 wire n261_l05_2;
 assign n261=n261_l05_2;
 wire n262_l05_3;
 assign n262=n262_l05_3;
 wire n263_l05_4;
 assign n263=n263_l05_4;
 wire n264_l05_13;
 assign n264=n264_l05_13;
 wire n265_j05_13;
 assign n265=n265_j05_13;
 wire n266_j05_12;
 assign n266=n266_j05_12;
 wire n267_j05_14;
 assign n267=n267_j05_14;
 wire n268_h22_13;
 assign n268=n268_h22_13;
 wire n269_g12_13;
 assign n269=n269_g12_13;
 wire n270_g12_12;
 assign n270=n270_g12_12;
 wire n271_g12_14;
 assign n271=n271_g12_14;
 wire n273_l06_3;
 wire n273_l06_14;
 wire n273_l07_3;
 assign n273=n273_l06_3 | n273_l06_14 | n273_l07_3;
 wire n274_g16_14;
 assign n274=n274_g16_14;
 wire n275_c18_12;
 assign n275=n275_c18_12;
 wire n276_g16_2;
 assign n276=n276_g16_2;
 wire n279_i03_1;
 assign n279=n279_i03_1;
 wire n280_i03_2;
 assign n280=n280_i03_2;
 wire n281_i03_15;
 assign n281=n281_i03_15;
 wire n282_i03_14;
 assign n282=n282_i03_14;
 wire n283_i04_1;
 assign n283=n283_i04_1;
 wire n284_i04_2;
 assign n284=n284_i04_2;
 wire n285_i04_15;
 assign n285=n285_i04_15;
 wire n286_i04_14;
 assign n286=n286_i04_14;
 wire n287_d06_2;
 assign n287=n287_d06_2;
 wire n288_j18_12;
 assign n288=n288_j18_12;
 wire n290_l05_14;
 assign n290=n290_l05_14;
 wire n291_l05_15;
 assign n291=n291_l05_15;
 wire n292_g21_3;
 assign n292=n292_g21_3;
 wire n293_h22_4;
 assign n293=n293_h22_4;
 wire n294_j05_3;
 assign n294=n294_j05_3;
 wire n295_j05_2;
 assign n295=n295_j05_2;
 wire n296_h22_14;
 assign n296=n296_h22_14;
 wire n298_g16_15;
 assign n298=n298_g16_15;
 wire n299_a01_14;
 assign n299=n299_a01_14;
 wire n308_g05_1;
 assign n308=n308_g05_1;
 wire n309_g05_2;
 assign n309=n309_g05_2;
 wire n310_g05_15;
 assign n310=n310_g05_15;
 wire n311_g05_14;
 assign n311=n311_g05_14;
 wire n312_h05_1;
 assign n312=n312_h05_1;
 wire n313_h05_2;
 assign n313=n313_h05_2;
 wire n314_h05_15;
 assign n314=n314_h05_15;
 wire n315_h05_14;
 assign n315=n315_h05_14;
 wire n316_j01_1;
 assign n316=n316_j01_1;
 wire n317_j01_2;
 assign n317=n317_j01_2;
 wire n318_j01_15;
 assign n318=n318_j01_15;
 wire n319_j01_14;
 assign n319=n319_j01_14;
 wire n320_j02_1;
 assign n320=n320_j02_1;
 wire n321_j02_2;
 assign n321=n321_j02_2;
 wire n322_j02_15;
 assign n322=n322_j02_15;
 wire n323_j02_14;
 assign n323=n323_j02_14;
 wire n324_j03_1;
 assign n324=n324_j03_1;
 wire n325_j03_2;
 assign n325=n325_j03_2;
 wire n326_j03_15;
 assign n326=n326_j03_15;
 wire n327_j03_14;
 assign n327=n327_j03_14;
 wire n328_j04_1;
 assign n328=n328_j04_1;
 wire n329_j04_2;
 assign n329=n329_j04_2;
 wire n330_j04_15;
 assign n330=n330_j04_15;
 wire n331_j04_14;
 assign n331=n331_j04_14;
 wire n332_k01_1;
 assign n332=n332_k01_1;
 wire n333_k01_2;
 assign n333=n333_k01_2;
 wire n334_k01_15;
 assign n334=n334_k01_15;
 wire n335_k01_14;
 assign n335=n335_k01_14;
 wire n336_k02_1;
 assign n336=n336_k02_1;
 wire n337_k02_2;
 assign n337=n337_k02_2;
 wire n338_k02_15;
 assign n338=n338_k02_15;
 wire n339_k02_14;
 assign n339=n339_k02_14;
 wire n341_l02_2;
 assign n341=n341_l02_2;
 wire n342_l01_13;
 assign n342=n342_l01_13;
 wire n343_l01_12;
 assign n343=n343_l01_12;
 wire n344_l01_14;
 assign n344=n344_l01_14;
 comb_MC10102 a01(.p1(1'b0),.p2(n12_a01_2),.p3(n229_a01_3),.p4(n13),.p5(1'b0),.p6(n230),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n299_a01_14),.p16(1'b0));
 comb_MC10158 a18(.p1(n203_a18_1),.p2(n202_a18_2),.p3(n135),.p4(n44),.p5(n134),.p6(n43),.p9(n270),.p10(n137),.p11(n46),.p12(n136),.p13(n45),.p14(n205_a18_14),.p15(n204_a18_15));
 comb_MC10158 a19(.p1(n134_a19_1),.p2(n135_a19_2),.p3(n143),.p4(n130),.p5(n141),.p6(n129),.p9(n174),.p10(n147),.p11(n132),.p12(n145),.p13(n131),.p14(n137_a19_14),.p15(n136_a19_15));
 sampled_MC10141 a20(.p1(n110),.p2(n131_a20_2),.p3(n132_a20_3),.p4(n37),.p5(1'b0),.p6(n46),.p7(1'b0),.p8(1'b0),.p9(n45),.p10(1'b0),.p11(n44),.p12(n43),.p13(1'b0),.p14(n129_a20_14),.p15(n130_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 sampled_MC10141 a21(.p1(1'b0),.p2(n45_a21_2),.p3(n46_a21_3),.p4(n275),.p5(1'b0),.p6(n147),.p7(n270),.p8(1'b0),.p9(n145),.p10(n270),.p11(n143),.p12(n141),.p13(1'b0),.p14(n43_a21_14),.p15(n44_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 comb_MC10113 a22(.p1(1'b0),.p2(n47_a22_2),.p3(n47_a22_3),.p4(n46),.p5(n147),.p6(n145),.p7(n45),.p9(1'b0),.p10(n143),.p11(n44),.p12(n141),.p13(n43),.p14(n47_a22_14),.p15(n47_a22_15));
 comb_MC10101 a24(.p2(n147_a24_2),.p3(n145_a24_3),.p4(n146),.p5(n201_a24_5),.p6(n201_a24_6),.p7(n144),.p9(n201_a24_9),.p10(n142),.p11(n201_a24_11),.p12(1'b0),.p13(n140),.p14(n143_a24_14),.p15(n141_a24_15));
 comb_MC10101 b23(.p2(n4_b23_2),.p3(n6_b23_3),.p4(1'b0),.p5(n5_b23_5),.p7(1'b0),.p9(n8_b23_9),.p10(n2),.p11(n10_b23_11),.p12(n1),.p13(n3),.p14(n9_b23_14),.p15(n7_b23_15));
 comb_MC10170 c06(.p1(1'b0),.p2(n247_c06_2),.p3(n274),.p4(n246),.p5(n245),.p6(n244),.p7(n243),.p8(1'b0),.p9(n242),.p10(n241),.p11(n240),.p12(n239),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 comb_SE10210 c18(.p2(n38_c18_2),.p3(n37_c18_3),.p4(n39_c18_4),.p5(n166),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n174),.p10(1'b0),.p11(1'b0),.p12(n275_c18_12),.p15(n102),.p16(1'b0));
 comb_MC10210 c23(.p1(1'b0),.p2(n60_c23_2),.p3(n59_c23_3),.p4(n58_c23_4),.p5(1'b0),.p6(1'b0),.p7(n100),.p8(1'b0),.p9(n100),.p10(1'b0),.p11(n5),.p12(n62_c23_12),.p14(n63_c23_14),.p15(n103),.p16(1'b0));
 comb_MC10170 d06(.p1(1'b0),.p2(n287_d06_2),.p3(n298),.p4(n286),.p5(n285),.p6(n284),.p7(n283),.p8(1'b0),.p9(n282),.p10(n281),.p11(n280),.p12(n279),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 comb_MC10100 d20(.p2(n224_d20_2),.p3(n224_d20_3),.p4(n73),.p5(n64),.p6(n75),.p7(n64),.p9(n61),.p10(n71),.p11(n66),.p12(1'b0),.p13(1'b0),.p14(n199_d20_14));
 comb_MC10211 d22(.p2(n58_d22_2),.p3(n59_d22_3),.p4(n60_d22_4),.p5(n5),.p6(n170),.p7(1'b0),.p9(n93),.p10(n62),.p11(n68),.p13(n223_d22_13),.p14(n222_d22_14),.p15(n104),.p16(1'b0));
 comb_MC10101 d23(.p2(n63_d23_2),.p3(n171_d23_3),.p4(n100),.p5(n82_d23_5),.p6(n81_d23_6),.p7(1'b0),.p10(1'b0),.p11(n62_d23_11),.p12(n80),.p13(n76),.p14(n206_d23_14),.p15(n170_d23_15));
 comb_MC10101 d24(.p2(n79_d24_2),.p3(n63_d24_3),.p4(n100),.p5(n78_d24_5),.p6(n77_d24_6),.p7(1'b0),.p9(n206_d24_9),.p10(1'b0),.p11(n171_d24_11),.p12(n76),.p13(1'b0),.p14(n62_d24_14));
 comb_MC10101 e23(.p2(n84_e23_2),.p3(n87_e23_3),.p4(n83),.p5(n85_e23_5),.p6(n88_e23_6),.p7(n86),.p9(n93_e23_9),.p10(n89),.p11(n90_e23_11),.p12(1'b0),.p13(n91),.p15(n92_e23_15));
 comb_MC10161 e24(.p2(1'b0),.p3(n66_e24_3),.p4(n65_e24_4),.p6(n64_e24_6),.p7(n89),.p9(n86),.p10(n70_e24_10),.p11(n69_e24_11),.p12(n68_e24_12),.p13(n67_e24_13),.p14(n83),.p15(1'b0));
 comb_SE10212 f12(.p1(1'b0),.p2(n237_f12_2),.p3(n176_f12_3),.p4(n175_f12_4),.p5(n341),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n237),.p10(1'b0),.p11(n342),.p13(n168_f12_13),.p14(n164_f12_14),.p15(n105),.p16(1'b0));
 comb_SE10210 f13(.p2(n165_f13_2),.p3(n167_f13_3),.p4(n166_f13_4),.p5(n343),.p6(1'b0),.p7(n237),.p8(1'b0),.p9(n343),.p10(n34),.p11(1'b0),.p12(n161_f13_12),.p13(n160_f13_13),.p14(n162_f13_14),.p15(n106),.p16(1'b0));
 comb_MC10102 f18(.p1(1'b0),.p2(n214_f18_2),.p3(n210_f18_3),.p4(n128),.p5(n212),.p6(n124),.p7(n126),.p10(n85),.p11(n63),.p12(n22),.p13(n19),.p14(n222_f18_14),.p15(n23_f18_15),.p16(1'b0));
 comb_MC1660 f19(.p2(n25_f19_2),.p3(n24_f19_3),.p4(1'b0),.p5(n61),.p6(n87),.p7(n84),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n150),.p14(n119_f19_14),.p15(n118_f19_15));
 comb_MC10100 f20(.p2(n195_f20_2),.p3(n223_f20_3),.p4(n74),.p5(n70),.p6(n75),.p7(n66),.p9(n60),.p10(n74),.p11(n66),.p12(n73),.p13(n70),.p14(n207_f20_14),.p15(n210_f20_15));
 comb_MC10101 f23(.p2(n95_f23_2),.p3(n98_f23_3),.p4(n94),.p5(n96_f23_5),.p6(n99_f23_6),.p7(n97),.p9(n72_f23_9),.p10(n93),.p11(n71_f23_11),.p12(1'b0),.p13(n96),.p14(n72_f23_14),.p15(n71_f23_15));
 sampled_MC10173 g05(.p1(n308_g05_1),.p2(n309_g05_2),.p3(n178),.p4(n277),.p5(n340),.p6(n277),.p7(n36),.p9(n272),.p10(n182),.p11(n277),.p12(n180),.p13(n277),.p14(n311_g05_14),.p15(n310_g05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[254+:4]),.state_q(state_q[254+:4]));
 sampled_MC10173 g06(.p1(n239_g06_1),.p2(n240_g06_2),.p3(n309),.p4(n317),.p5(n308),.p6(n316),.p7(n173),.p9(n258),.p10(n311),.p11(n319),.p12(n310),.p13(n318),.p14(n242_g06_14),.p15(n241_g06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[262+:4]),.state_q(state_q[262+:4]));
 sampled_MC10173 g07(.p1(n243_g07_1),.p2(n244_g07_2),.p3(n313),.p4(n321),.p5(n312),.p6(n320),.p7(n173),.p9(n258),.p10(n315),.p11(n323),.p12(n314),.p13(n322),.p14(n246_g07_14),.p15(n245_g07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[266+:4]),.state_q(state_q[266+:4]));
 comb_SE10211 g12(.p2(n173_g12_2),.p3(n172_g12_3),.p4(n174_g12_4),.p5(1'b0),.p6(n341),.p7(1'b0),.p9(n12),.p10(n119),.p11(1'b0),.p12(n270_g12_12),.p13(n269_g12_13),.p14(n271_g12_14),.p15(n107),.p16(1'b0));
 comb_SE10210 g13(.p3(n163_g13_3),.p5(n344),.p6(n34),.p7(1'b0),.p8(1'b0),.p9(n344),.p10(1'b0),.p11(1'b0),.p13(n169_g13_13),.p15(n108),.p16(1'b0));
 sampled_F10000 g16(.p2(n276_g16_2),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p9(n198),.p10(n234),.p11(n231),.p12(1'b0),.p13(n40),.p14(n274_g16_14),.p15(n298_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 sampled_MC10176 g18(.p1(1'b0),.p2(n11_g18_2),.p3(n139_g18_3),.p5(n195),.p6(n225),.p7(1'b0),.p8(1'b0),.p9(n31),.p10(n0),.p11(n149),.p12(n121),.p13(n197_g18_13),.p14(n196_g18_14),.p15(n120_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 comb_MC10106 g20(.p2(n26_g20_2),.p3(n225_g20_3),.p4(n223),.p5(n222),.p6(n148),.p7(n224),.p9(n84),.p10(n60),.p11(n88),.p12(n133),.p13(n11),.p14(n120),.p15(n200_g20_15));
 comb_MC10106 g21(.p2(n236_g21_2),.p3(n292_g21_3),.p4(n120),.p5(n133),.p6(n296),.p7(n297),.p9(n258),.p10(n272),.p11(n247),.p12(n292),.p13(n297),.p14(n287),.p15(n232_g21_15));
 sampled_MC10173 h05(.p1(n312_h05_1),.p2(n313_h05_2),.p3(n186),.p4(n277),.p5(n184),.p6(n277),.p7(n36),.p9(n272),.p10(n190),.p11(n277),.p12(n188),.p13(n277),.p14(n315_h05_14),.p15(n314_h05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[258+:4]),.state_q(state_q[258+:4]));
 comb_MC10158 h17(.p2(n52_h17_2),.p3(n53),.p4(n53),.p5(1'b0),.p6(1'b0),.p9(n138),.p10(n227),.p11(n226),.p12(n101),.p13(n101),.p14(n228_h17_14),.p15(n195_h17_15));
 comb_MC10103 h19(.p1(1'b0),.p2(n208_h19_2),.p4(n238),.p5(n209),.p6(1'b0),.p7(1'b0),.p9(n217_h19_9),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n176),.p15(n216_h19_15),.p16(1'b0));
 sampled_MC10176 h22(.p1(1'b0),.p2(n259_h22_2),.p3(n260_h22_3),.p4(n293_h22_4),.p5(n126),.p6(n127),.p7(n210),.p8(1'b0),.p9(n31),.p10(n213),.p11(n214),.p12(n47),.p13(n268_h22_13),.p14(n296_h22_14),.p15(n133_h22_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 comb_MC10102 h23(.p1(1'b0),.p2(n211_h23_2),.p3(n212_h23_3),.p4(n126),.p5(n128),.p6(n124),.p7(n126),.p10(n124),.p11(n211),.p12(n123),.p13(n233),.p14(n213_h23_14),.p15(n122_h23_15),.p16(1'b0));
 comb_MC10101 h24(.p2(n18_h24_2),.p3(n20_h24_3),.p4(n14),.p5(n17_h24_5),.p6(n19_h24_6),.p7(n15),.p9(n127_h24_9),.p10(n16),.p11(n21_h24_11),.p12(1'b0),.p13(n125),.p14(n22_h24_14),.p15(n126_h24_15));
 sampled_MC10173 i03(.p1(n279_i03_1),.p2(n280_i03_2),.p3(n325),.p4(n333),.p5(n324),.p6(n332),.p7(n173),.p9(n292),.p10(n327),.p11(n335),.p12(n326),.p13(n334),.p14(n282_i03_14),.p15(n281_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 sampled_MC10173 i04(.p1(n283_i04_1),.p2(n284_i04_2),.p3(n329),.p4(n337),.p5(n328),.p6(n336),.p7(n173),.p9(n292),.p10(n331),.p11(n339),.p12(n330),.p13(n338),.p14(n286_i04_14),.p15(n285_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 comb_SE10212 i05(.p1(1'b0),.p2(n42_i05_2),.p3(n35_i05_3),.p4(n36_i05_4),.p5(1'b0),.p6(1'b0),.p7(n168),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n109),.p16(1'b0));
 sampled_F10145A i11(.p2(n234_i11_2),.p3(1'b0),.p4(1'b0),.p5(n235),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(1'b0),.p12(1'b0),.p13(n295),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 sampled_MC10141 i12(.p1(1'b0),.p2(n50_i12_2),.p3(n51_i12_3),.p4(n54),.p5(1'b0),.p6(n205),.p7(1'b0),.p8(1'b0),.p9(n204),.p10(1'b0),.p11(n202),.p12(n203),.p13(1'b0),.p14(n48_i12_14),.p15(n49_i12_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 comb_SE10210 i18(.p2(n32_i18_2),.p3(n31_i18_3),.p4(n33_i18_4),.p5(n163),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n167),.p10(1'b0),.p11(1'b0),.p12(n41_i18_12),.p13(n40_i18_13),.p15(n111),.p16(1'b0));
 sampled_MC10173 j01(.p1(n316_j01_1),.p2(n317_j01_2),.p3(n152),.p4(n301),.p5(n151),.p6(n300),.p7(n35),.p9(n259),.p10(n154),.p11(n303),.p12(n153),.p13(n302),.p14(n319_j01_14),.p15(n318_j01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[246+:4]),.state_q(state_q[246+:4]));
 sampled_MC10173 j02(.p1(n320_j02_1),.p2(n321_j02_2),.p3(n156),.p4(n305),.p5(n155),.p6(n304),.p7(n36),.p9(n259),.p10(n158),.p11(n307),.p12(n157),.p13(n306),.p14(n323_j02_14),.p15(n322_j02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[250+:4]),.state_q(state_q[250+:4]));
 sampled_MC10173 j03(.p1(n324_j03_1),.p2(n325_j03_2),.p3(n179),.p4(n277),.p5(n177),.p6(n277),.p7(n36),.p9(n297),.p10(n183),.p11(n277),.p12(n181),.p13(n277),.p14(n327_j03_14),.p15(n326_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 sampled_MC10173 j04(.p1(n328_j04_1),.p2(n329_j04_2),.p3(n187),.p4(n277),.p5(n185),.p6(n277),.p7(n36),.p9(n297),.p10(n191),.p11(n277),.p12(n189),.p13(n277),.p14(n331_j04_14),.p15(n330_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 comb_SE10210 j05(.p2(n295_j05_2),.p3(n294_j05_3),.p5(n161),.p6(n120),.p7(n296),.p8(1'b0),.p9(n161),.p10(n120),.p11(n268),.p12(n266_j05_12),.p13(n265_j05_13),.p14(n267_j05_14),.p15(n112),.p16(1'b0));
 comb_SE10210 j18(.p2(n54_j18_2),.p5(n169),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n167),.p10(n121),.p11(n289),.p12(n288_j18_12),.p15(n113),.p16(1'b0));
 sampled_MC10173 k01(.p1(n332_k01_1),.p2(n333_k01_2),.p3(n152),.p4(n301),.p5(n151),.p6(n300),.p7(n35),.p9(n293),.p10(n154),.p11(n303),.p12(n153),.p13(n302),.p14(n335_k01_14),.p15(n334_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 sampled_MC10173 k02(.p1(n336_k02_1),.p2(n337_k02_2),.p3(n156),.p4(n305),.p5(n155),.p6(n304),.p7(n35),.p9(n293),.p10(n158),.p11(n307),.p12(n157),.p13(n306),.p14(n339_k02_14),.p15(n338_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 comb_MC10170 k04(.p1(1'b0),.p2(n235_k04_2),.p3(n299),.p4(n339),.p5(n338),.p6(n337),.p7(n336),.p8(1'b0),.p9(n335),.p10(n334),.p11(n333),.p12(n332),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 comb_MC10158 k05(.p1(n221_k05_1),.p2(n220_k05_2),.p3(n250),.p4(n96),.p5(n251),.p6(n99),.p9(n26),.p10(n248),.p11(n90),.p12(n249),.p13(n93),.p14(n218_k05_14),.p15(n219_k05_15));
 comb_MC1662 k08(.p2(n252_k08_2),.p3(n253_k08_3),.p4(n248),.p5(n217),.p6(n249),.p7(n217),.p10(n216),.p11(n262),.p12(n216),.p13(n261),.p14(n253_k08_14),.p15(n252_k08_15));
 comb_MC1662 k09(.p2(n254_k09_2),.p3(n255_k09_3),.p4(n250),.p5(n217),.p6(n251),.p7(n217),.p10(n216),.p11(n264),.p12(n216),.p13(n263),.p14(n255_k09_14),.p15(n254_k09_15));
 comb_SE10210 k10(.p2(n30_k10_2),.p4(n29_k10_4),.p5(n161),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n30),.p10(1'b0),.p11(1'b0),.p12(n159_k10_12),.p15(n114),.p16(1'b0));
 comb_SE10210 l01(.p4(n34_l01_4),.p5(1'b0),.p6(n278),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n343_l01_12),.p13(n342_l01_13),.p14(n344_l01_14),.p15(n115),.p16(1'b0));
 sampled_SE10231 l02(.p2(n341_l02_2),.p6(n28),.p7(n34),.p9(n27),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 sampled_F10145A l03(.p1(n179_l03_1),.p2(n177_l03_2),.p3(1'b0),.p4(n333),.p5(n332),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(n334),.p12(n335),.p13(n294),.p14(n183_l03_14),.p15(n181_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 sampled_F10145A l04(.p1(n187_l04_1),.p2(n185_l04_2),.p3(1'b0),.p4(n337),.p5(n336),.p6(n51),.p7(n50),.p8(1'b0),.p9(n49),.p10(n48),.p11(n338),.p12(n339),.p13(n294),.p14(n191_l04_14),.p15(n189_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 sampled_MC10176 l05(.p1(1'b0),.p2(n261_l05_2),.p3(n262_l05_3),.p4(n263_l05_4),.p5(n218),.p6(n219),.p7(n220),.p8(1'b0),.p9(n29),.p10(n221),.p11(n51),.p12(n290),.p13(n264_l05_13),.p14(n290_l05_14),.p15(n291_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[274+:6]),.state_q(state_q[274+:6]));
 sampled_MC1668 l06(.p3(n273_l06_3),.p4(1'b0),.p5(n55),.p6(n300),.p7(n192),.p9(n193),.p11(n151),.p12(n56),.p13(1'b0),.p14(n273_l06_14),.fixture_load(fixture_load),.fixture_state(fixture_state[272+:2]),.state_q(state_q[272+:2]));
 sampled_MC1668 l07(.p3(n273_l07_3),.p4(1'b0),.p5(n57),.p6(n340),.p7(n194),.p9(n42),.p11(n215),.p12(1'b0),.p13(1'b0),.p15(n258_l07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[270+:2]),.state_q(state_q[270+:2]));
 comb_SE10211 l08(.p2(n56_l08_2),.p3(n55_l08_3),.p4(n194_l08_4),.p5(n256),.p6(n165),.p7(1'b0),.p9(n260),.p10(n165),.p11(n257),.p12(n56_l08_12),.p13(n57_l08_13),.p14(n192_l08_14),.p15(n116),.p16(1'b0));
 comb_SE10211 l09(.p2(n55_l09_2),.p3(n57_l09_3),.p4(n193_l09_4),.p5(n259),.p6(n165),.p7(n257),.p9(n257),.p10(1'b0),.p11(n272),.p12(n215_l09_12),.p15(n117),.p16(1'b0));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n275;
 assign clocks[3]=n31;
 assign clocks[4]=n37;
 assign clocks[5]=n54;
 assign clocks[6]=n35;
 assign clocks[7]=n294;
 assign clocks[8]=n31;
 assign clocks[9]=n40;
 assign clocks[10]=l07.p7;
 assign clocks[11]=l07.p9;
 assign clocks[12]=l06.p7;
 assign clocks[13]=l06.p9;
 assign clocks[14]=l05.p9;
 assign flags[0]=n270;
 assign flags[1]=n118;
 assign flags[2]=n47;
 assign flags[3]=n173;
 assign flags[4]=n292;
 assign flags[5]=n287;
 assign flags[6]=n247;
 assign flags[7]=n232;
 assign flags[8]=n236;
 assign flags[9]=n36;
 assign flags[10]=l07.state_q[0];
 assign flags[11]=n258;
 assign flags[12]=n273;
 assign flags[13]=n252;
 assign flags[14]=n253;
 assign flags[15]=n254;
 assign flags[16]=n255;
 assign flags[17]=n60;
 assign flags[18]=n61;
 assign flags[19]=n62;
 assign flags[20]=n63;
 assign flags[21]=n85;
 assign flags[22]=n225;
 assign flags[23]=n218;
 assign flags[24]=n219;
 assign flags[25]=n220;
 assign flags[26]=n221;
endmodule
`default_nettype wire

`timescale 1ns/1ps
`default_nettype none
module r_front_procl_sampled(input wire fixture_load,input wire [407:0] fixture_state,
 input wire base,start_a,en,input wire [235:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,rb_forward,rb_forward_n,
 output wire [407:0] state_q,output wire [36:0] clocks,
 output wire [91:0] flags);
 wire n0; // ALUFWriteEn'
 wire n1; // ASEL.0'
 wire n2; // ASEL.1'
 wire n3; // ASEL.2'
 wire n4; // ASel.0
 wire n5; // ASel.0'
 wire n6; // ASel=2/3'
 wire n7; // ASel=5/7
 wire n8; // ASel=5/7'
 wire n9; // ASel=6/7
 wire n10; // ASel=6/7'
 wire n11; // BNTGtCT
 wire n12; // BNTGtCT'a
 wire n13; // BSEL.0'
 wire n14; // BSEL.1'
 wire n15; // BSEL.2'
 wire n16; // BSel.0'a
 wire n17; // BSel.0a
 wire n18; // BSel.1'a
 wire n19; // BSel.2'a
 wire n20; // BSel.2a
 wire n21; // BSel=0'
 wire n22; // B_Ext
 wire n23; // B_Ext'
 wire n24; // BumpRBase
 wire n25; // BumpRSTK
 wire n26; // CLK.pl'
 wire n27; // CLKEnable'b
 wire n28; // CkMdParity'
 wire n29; // Clk0En'
 wire n30; // Clock0'Bd
 wire n31; // Clock0'Da
 wire n32; // Clock0'Db
 wire n33; // Clock0'Dc
 wire n34; // Clock1'Ba
 wire n35; // Clock1'Bb
 wire n36; // Clock1'Ca
 wire n37; // Clock1'Cb
 wire n38; // Clock1'Da
 wire n39; // Clock1'Db
 wire n40; // Clock1'Dc
 wire n41; // Clock1Bd
 wire n42; // Cnt=Zero'
 wire n43; // CntMux.12'
 wire n44; // CntMux.13'
 wire n45; // CntMux.14'
 wire n46; // CntMux.15'
 wire n47; // Curr.0'
 wire n48; // Curr.1'
 wire n49; // Curr.2'
 wire n50; // Curr.3'
 wire n51; // Curr=Next'
 wire n52; // CurrLast.0'
 wire n53; // CurrLast.1'
 wire n54; // CurrLast.2'
 wire n55; // CurrLast.3'
 wire n56; // CurrStkPVal'
 wire n57; // DblClock'Ba
 wire n58; // DblClock'Bc
 wire n59; // DecCnt'
 wire n60; // DsMd
 wire n61; // DsPd
 wire n62; // DsRd
 wire n63; // EMU'
 wire n64; // FA=0'a
 wire n65; // FA=0'b
 wire n66; // FA=1'a
 wire n67; // FA=2'a
 wire n68; // FA=3'
 wire n69; // FB=0'
 wire n70; // FB=2'
 wire n71; // FB=3'
 wire n72; // FB=4'
 wire n73; // FB=5'
 wire n74; // FB=6'
 wire n75; // FB=7'
 wire n76; // FC=0'
 wire n77; // FC=1'
 wire n78; // FC=2'
 wire n79; // FC=2/3'
 wire n80; // FC=3'
 wire n81; // FC=4'
 wire n82; // FC=4/5'
 wire n83; // FC=5'
 wire n84; // FC=6'
 wire n85; // FC=6/7'
 wire n86; // FC=7'
 wire n87; // FF.0
 wire n88; // FF.0a
 wire n89; // FF.0mem'
 wire n90; // FF.1
 wire n91; // FF.1a
 wire n92; // FF.1mem
 wire n93; // FF.2
 wire n94; // FF.2'a
 wire n95; // FF.2a
 wire n96; // FF.3
 wire n97; // FF.3'a
 wire n98; // FF.3a
 wire n99; // FF.4
 wire n100; // FF.4'a
 wire n101; // FF.4a
 wire n102; // FF.5
 wire n103; // FF.5'a
 wire n104; // FF.5a
 wire n105; // FF.6
 wire n106; // FF.6'a
 wire n107; // FF.6a
 wire n108; // FF.7
 wire n109; // FF.7'a
 wire n110; // FF.7a
 wire n111; // FF=030
 wire n112; // FFdly.7
 wire n113; // FFeqMul'
 wire n114; // FFok'b
 wire n115; // FHSelect'D
 wire n116; // Freeze
 wire n117; // GND132
 wire n118; // GND142
 wire n119; // GND264
 wire n120; // GND266
 wire n121; // GND312
 wire n122; // GND314
 wire n123; // GND394
 wire n124; // GND40
 wire n125; // GND420
 wire n126; // GND442
 wire n127; // GND468
 wire n128; // GND500
 wire n129; // GND530
 wire n130; // GND544
 wire n131; // GND546
 wire n132; // GND556
 wire n133; // GND96
 wire n134; // Hold
 wire n135; // Hold'
 wire n136; // HoldDly
 wire n137; // Holda
 wire n138; // IOB.Perr'
 wire n139; // IOBin'
 wire n140; // IOBout
 wire n141; // IOBout'
 wire n142; // IOin'
 wire n143; // IOout'
 wire n144; // IfuData.0
 wire n145; // IfuData.1
 wire n146; // IfuData.2
 wire n147; // IfuData.3
 wire n148; // IfuData.4
 wire n149; // IfuData.5
 wire n150; // IfuData.6
 wire n151; // IfuData.7
 wire n152; // IfuRBaseSel'
 wire n153; // LC.0
 wire n154; // LC.1
 wire n155; // LC.1'a
 wire n156; // LC.1a
 wire n157; // LC.2
 wire n158; // LScopeFH
 wire n159; // Last.0'
 wire n160; // Last.1'
 wire n161; // Last.2'
 wire n162; // Last.3'
 wire n163; // Last=Curr'
 wire n164; // LastNext.0'
 wire n165; // LastNext.1'
 wire n166; // LastNext.2'
 wire n167; // LastNext.3'
 wire n168; // Md.Perr'
 wire n169; // NewStkPVal'
 wire n170; // Next.0
 wire n171; // Next.0'
 wire n172; // Next.1
 wire n173; // Next.1'
 wire n174; // Next.2
 wire n175; // Next.2'
 wire n176; // Next.3
 wire n177; // Next.3'
 wire n178; // NextMacro
 wire n179; // NextMacroDly
 wire n180; // NextMacroDly'
 wire n181; // OVFLerr'
 wire n182; // PRhold
 wire n183; // Pdata.08
 wire n184; // Pdata.09
 wire n185; // Pdata.10
 wire n186; // Pdata.11
 wire n187; // Pdata.12
 wire n188; // Pdata.13
 wire n189; // Pdata.14
 wire n190; // Pdata.15
 wire n191; // PrBlock'
 wire n192; // PrHoldReq
 wire n193; // PreClock0'A
 wire n194; // PreClock0'B
 wire n195; // PreClock0'C
 wire n196; // PreClock0'D
 wire n197; // PreClock1'A
 wire n198; // PreClock1'B
 wire n199; // PreClock1'C
 wire n200; // PreClock1'D
 wire n201; // PreClock1B
 wire n202; // PreDblClock'B
 wire n203; // PreFA=0
 wire n204; // PreFA=0'
 wire n205; // PreFA=1'
 wire n206; // PreSHCP'A
 wire n207; // PreSHCP'B
 wire n208; // PreSHCP'C
 wire n209; // PreSHCP'Shc
 wire n210; // PreSHSelect'D
 wire n211; // ProcL02.sil+1
 wire n212; // ProcL02.sil+5
 wire n213; // ProcL03.sil+1
 wire n214; // ProcL03.sil+5
 wire n215; // ProcL04.sil+1
 wire n216; // ProcL04.sil+5
 wire n217; // ProcL05.sil+1
 wire n218; // ProcL05.sil+5
 wire n219; // ProcL06.sil+1
 wire n220; // ProcL06.sil+5
 wire n221; // ProcL07.sil+1
 wire n222; // ProcL07.sil+5
 wire n223; // ProcL08.sil+1
 wire n224; // ProcL08.sil+5
 wire n225; // ProcL09.sil+4
 wire n226; // ProcL10.sil+1
 wire n227; // ProcL10.sil+2
 wire n228; // ProcL10.sil+3
 wire n229; // ProcL10.sil+4
 wire n230; // ProcL11.sil+1
 wire n231; // ProcL11.sil+2
 wire n232; // ProcL11.sil+3
 wire n233; // ProcL11.sil+5
 wire n234; // ProcL11.sil+7
 wire n235; // ProcL12.sil+1
 wire n236; // ProcL12.sil+2
 wire n237; // ProcL12.sil+3
 wire n238; // ProcL12.sil+4
 wire n239; // ProcL12.sil+5
 wire n240; // ProcL12.sil+6
 wire n241; // ProcL15.sil+1
 wire n242; // ProcL17.sil+10
 wire n243; // ProcL17.sil+3
 wire n244; // ProcL17.sil+8
 wire n245; // ProcL17.sil+9
 wire n246; // ProcL18.sil+10
 wire n247; // ProcL18.sil+9
 wire n248; // ProcL20.sil+1
 wire n249; // ProcL20.sil+3
 wire n250; // ProcL20.sil+4
 wire n251; // ProcL20.sil+5
 wire n252; // ProcL20.sil+6
 wire n253; // ProcL20.sil+7
 wire n254; // ProcL20.sil+8
 wire n255; // ProcL22.sil+1
 wire n256; // ProcL22.sil+2
 wire n257; // ProcL22.sil+3
 wire n258; // ProcL22.sil+4
 wire n259; // ProcL23.sil+1
 wire n260; // ProcL23.sil+10
 wire n261; // ProcL23.sil+11
 wire n262; // ProcL23.sil+12
 wire n263; // ProcL23.sil+13
 wire n264; // ProcL23.sil+14
 wire n265; // ProcL23.sil+15
 wire n266; // ProcL23.sil+16
 wire n267; // ProcL23.sil+17
 wire n268; // ProcL23.sil+18
 wire n269; // ProcL23.sil+2
 wire n270; // ProcL23.sil+3
 wire n271; // ProcL23.sil+4
 wire n272; // ProcL23.sil+5
 wire n273; // ProcL23.sil+6
 wire n274; // ProcL23.sil+7
 wire n275; // ProcL23.sil+8
 wire n276; // ProcL23.sil+9
 wire n277; // ProcL24.sil+1
 wire n278; // ProcL24.sil+10
 wire n279; // ProcL24.sil+11
 wire n280; // ProcL24.sil+12
 wire n281; // ProcL24.sil+13
 wire n282; // ProcL24.sil+14
 wire n283; // ProcL24.sil+2
 wire n284; // ProcL24.sil+3
 wire n285; // ProcL24.sil+4
 wire n286; // ProcL24.sil+5
 wire n287; // ProcL24.sil+6
 wire n288; // ProcL24.sil+7
 wire n289; // ProcL24.sil+8
 wire n290; // ProcL24.sil+9
 wire n291; // ProcL25.sil+1
 wire n292; // ProcL25.sil+10
 wire n293; // ProcL25.sil+11
 wire n294; // ProcL25.sil+12
 wire n295; // ProcL25.sil+13
 wire n296; // ProcL25.sil+14
 wire n297; // ProcL25.sil+15
 wire n298; // ProcL25.sil+16
 wire n299; // ProcL25.sil+17
 wire n300; // ProcL25.sil+18
 wire n301; // ProcL25.sil+19
 wire n302; // ProcL25.sil+2
 wire n303; // ProcL25.sil+20
 wire n304; // ProcL25.sil+3
 wire n305; // ProcL25.sil+4
 wire n306; // ProcL25.sil+5
 wire n307; // ProcL25.sil+6
 wire n308; // ProcL25.sil+7
 wire n309; // ProcL25.sil+8
 wire n310; // ProcL25.sil+9
 wire n311; // ProcL26.sil+1
 wire n312; // ProcL26.sil+3
 wire n313; // ProcL27.sil+1
 wire n314; // ProcL27.sil+10
 wire n315; // ProcL27.sil+11
 wire n316; // ProcL27.sil+3
 wire n317; // ProcL27.sil+4
 wire n318; // ProcL27.sil+5
 wire n319; // ProcL27.sil+6
 wire n320; // ProcL27.sil+7
 wire n321; // ProcL27.sil+8
 wire n322; // ProcL27.sil+9
 wire n323; // ProcL30.sil+1
 wire n324; // Q.14
 wire n325; // QBit'
 wire n326; // R.08
 wire n327; // R.09
 wire n328; // R.10
 wire n329; // R.11
 wire n330; // R.12
 wire n331; // R.13
 wire n332; // R.14
 wire n333; // R.15
 wire n334; // R.Perr'
 wire n335; // RBase.0'
 wire n336; // RBase.1'
 wire n337; // RBase.2'
 wire n338; // RBase.3'
 wire n339; // RBaseBypass'
 wire n340; // RBaseWrite'
 wire n341; // RBaseWriteEn'
 wire n342; // RSTK.0
 wire n343; // RSTK.0'a
 wire n344; // RSTK.0a
 wire n345; // RSTK.1
 wire n346; // RSTK.1'a
 wire n347; // RSTK.1a
 wire n348; // RSTK.2
 wire n349; // RSTK.2'a
 wire n350; // RSTK.2a
 wire n351; // RSTK.3
 wire n352; // RSTK.3'a
 wire n353; // RSTK.3a
 wire n354; // RbAdr.0
 wire n355; // RbAdr.0'
 wire n356; // RbAdr.1
 wire n357; // RbAdr.1'
 wire n358; // RbAdr.2
 wire n359; // RbAdr.2'
 wire n360; // RbAdr.3
 wire n361; // RbAdr.3'
 wire n362; // RbAdr.4'
 wire n363; // RbAdr.5'
 wire n364; // RbAdr.6'
 wire n365; // RbAdr.7'
 wire n366; // RbBypass
 wire n367; // RbBypass'
 wire n368; // RbBypassDly
 wire n369; // RbSelMd
 wire n370; // RbSelMd'
 wire n371; // RbWadr.0'
 wire n372; // RbWadr.1'
 wire n373; // RbWadr.2'
 wire n374; // RbWadr.3'
 wire n375; // RbWadr.4
 wire n376; // RbWadr.5
 wire n377; // RbWadr.6
 wire n378; // RbWadr.7
 wire n379; // RbWrite'a
 wire n380; // RbWrite'b
 wire n381; // RbWrite'c
 wire n382; // RbWriteEn'
 wire n383; // RepeatCurrB
 wire n384; // RepeatCurrC
 wire n385; // RepeatCurrD
 wire n386; // RisIFdata
 wire n387; // RmBypass'
 wire n388; // RmOdd'
 wire n389; // Rparity
 wire n390; // SHCP'C
 wire n391; // SHSelect'C
 wire n392; // SHSelect'D
 wire n393; // SelRBaseWadr'
 wire n394; // SelectRm'a
 wire n395; // SelectRm'b
 wire n396; // SelectStk'a
 wire n397; // SelectStk'b
 wire n398; // SimHoldDis
 wire n399; // SimHoldReq'
 wire n400; // StartCycle'a
 wire n401; // StkAdr.0a
 wire n402; // StkAdr.0b
 wire n403; // StkAdr.1a
 wire n404; // StkAdr.1b
 wire n405; // StkAdr.2a
 wire n406; // StkAdr.2b
 wire n407; // StkAdr.3a
 wire n408; // StkAdr.3b
 wire n409; // StkAdr.4a
 wire n410; // StkAdr.4b
 wire n411; // StkAdr.5a
 wire n412; // StkAdr.5b
 wire n413; // StkAdr.6a
 wire n414; // StkAdr.6b
 wire n415; // StkAdr.7a
 wire n416; // StkAdr.7b
 wire n417; // StkBypass'
 wire n418; // StkError
 wire n419; // StkP.0
 wire n420; // StkP.1
 wire n421; // StkP.2
 wire n422; // StkP.3
 wire n423; // StkP.4
 wire n424; // StkP.5
 wire n425; // StkP.6
 wire n426; // StkP.6'
 wire n427; // StkP.6/7
 wire n428; // StkP.7
 wire n429; // StkP.7'
 wire n430; // StkPMux1
 wire n431; // StkPSave.0
 wire n432; // StkPSave.1
 wire n433; // StkPSave.2
 wire n434; // StkPSave.3
 wire n435; // StkPSave.4
 wire n436; // StkPSave.5
 wire n437; // StkPSave.7
 wire n438; // StkPSaveEn'
 wire n439; // StkPWriteEn'
 wire n440; // StkPsave.6
 wire n441; // StkSel'a
 wire n442; // StkSelSaved
 wire n443; // StkSela
 wire n444; // StkWSel'
 wire n445; // StkWadr.0
 wire n446; // StkWadr.1
 wire n447; // StkWadr.2
 wire n448; // StkWadr.3
 wire n449; // StkWadr.4
 wire n450; // StkWadr.5
 wire n451; // StkWadr.6
 wire n452; // StkWadr.7
 wire n453; // SubTask.0
 wire n454; // SubTask.1
 wire n455; // T.08
 wire n456; // T.09
 wire n457; // T.10
 wire n458; // T.11
 wire n459; // T.12
 wire n460; // T.13
 wire n461; // T.14
 wire n462; // T.15
 wire n463; // T.Perr'
 wire n464; // TbBypass
 wire n465; // TbSelMd
 wire n466; // TbWrite'a
 wire n467; // TbWrite'b
 wire n468; // TbWriteEn'
 wire n469; // TisIFdata
 wire n470; // Tparity
 wire n471; // TrueA
 wire n472; // UFLerr'
 wire n473; // _MD'Dly
 wire n474; // _MDI'
 wire n475; // _MDSaved
 wire n476; // alub.08
 wire n477; // alub.09
 wire n478; // alub.10
 wire n479; // alub.11
 wire n480; // alub.12
 wire n481; // alub.13
 wire n482; // alub.14
 wire n483; // alub.15
 wire n484; // dBmux0
 wire n485; // dBmux1
 wire n486; // dMD.08
 wire n487; // dMD.09
 wire n488; // dMD.10
 wire n489; // dMD.11
 wire n490; // dMD.12
 wire n491; // dMD.13
 wire n492; // dMD.14
 wire n493; // dMD.15
 wire n494; // dPmux1
 wire n495; // dR.08
 wire n496; // dR.09
 wire n497; // dR.10
 wire n498; // dR.11
 wire n499; // dR.12
 wire n500; // dR.13
 wire n501; // dR.14
 wire n502; // dR.15
 wire n503; // dRm.08
 wire n504; // dRm.09
 wire n505; // dRm.10
 wire n506; // dRm.11
 wire n507; // dRm.12
 wire n508; // dRm.13
 wire n509; // dRm.14
 wire n510; // dRm.15
 wire n511; // dT.08
 wire n512; // dT.09
 wire n513; // dT.10
 wire n514; // dT.11
 wire n515; // dT.12
 wire n516; // dT.13
 wire n517; // dT.14
 wire n518; // dT.15
 wire n519; // dTm.08
 wire n520; // dTm.09
 wire n521; // dTm.10
 wire n522; // dTm.11
 wire n523; // dTm.12
 wire n524; // dTm.13
 wire n525; // dTm.14
 wire n526; // dTm.15
 wire n527; // ddR.15
 wire n528; // jcnt
 wire n529; // pClk1En'
 wire n530; // ppClk'a
 wire n531; // ppClk'b
 wire n532; // ppClk'c
 assign n117=1'b0;
 assign n118=1'b0;
 assign n119=1'b0;
 assign n120=1'b0;
 assign n121=1'b0;
 assign n122=1'b0;
 assign n123=1'b0;
 assign n124=1'b0;
 assign n125=1'b0;
 assign n126=1'b0;
 assign n127=1'b0;
 assign n128=1'b0;
 assign n129=1'b0;
 assign n130=1'b0;
 assign n131=1'b0;
 assign n132=1'b0;
 assign n133=1'b0;
 assign n1=pins[202];
 assign n2=pins[203];
 assign n3=pins[204];
 assign n12=priority_n;
 assign n13=pins[205];
 assign n14=pins[206];
 assign n15=pins[207];
 assign n26=base;
 assign n27=en;
 assign n87=pins[19];
 assign n90=pins[18];
 assign n93=pins[17];
 assign n96=pins[16];
 assign n99=pins[15];
 assign n102=pins[14];
 assign n105=pins[13];
 assign n108=pins[12];
 assign n112=pins[218];
 assign n113=(pins[19:12]!=8'o072);
 assign n114=pins[209];
 assign n116=freeze;
 assign n139=pins[219];
 assign n140=pins[210];
 assign n141=pins[220];
 assign n144=pins[119];
 assign n145=pins[120];
 assign n146=pins[121];
 assign n147=pins[122];
 assign n148=pins[123];
 assign n149=pins[124];
 assign n150=pins[125];
 assign n151=pins[126];
 assign n152=pins[187];
 assign n153=pins[11];
 assign n154=pins[10];
 assign n157=pins[9];
 assign n168=pins[183];
 assign n170=next_raw[0];
 assign n172=next_raw[1];
 assign n174=next_raw[2];
 assign n176=next_raw[3];
 assign n178=pins[212];
 assign n182=pins[68];
 assign n183=pins[84];
 assign n184=pins[85];
 assign n185=pins[86];
 assign n186=pins[87];
 assign n187=pins[88];
 assign n188=pins[89];
 assign n189=pins[90];
 assign n190=pins[91];
 assign n191=pins[176];
 assign n211=pins[135];
 assign n213=pins[136];
 assign n215=pins[137];
 assign n217=pins[138];
 assign n219=pins[139];
 assign n221=pins[140];
 assign n223=pins[141];
 assign n242=pins[221];
 assign n245=pins[222];
 assign n253=~pins[225];
 assign n311=pins[223];
 assign n313=pins[144];
 assign n324=pins[179];
 assign n342=pins[172];
 assign n345=pins[173];
 assign n348=pins[174];
 assign n351=pins[175];
 assign n386=pins[151];
 assign n398=pins[224];
 assign n400=start_a;
 assign n453=pins[198];
 assign n454=pins[199];
 assign n469=pins[117];
 assign n473=pins[225];
 assign n474=pins[226];
 assign n476=pins[227];
 assign n477=pins[228];
 assign n478=pins[229];
 assign n479=pins[230];
 assign n480=pins[231];
 assign n481=pins[232];
 assign n482=pins[233];
 assign n483=pins[234];
 assign n486=pins[100];
 assign n487=pins[101];
 assign n488=pins[102];
 assign n489=pins[103];
 assign n490=pins[104];
 assign n491=pins[105];
 assign n492=pins[106];
 assign n493=pins[107];
 assign n527=pins[142];
 assign n528=pins[235];
 wire n0_e19_3;
 assign n0=n0_e19_3;
 wire n4_b23_2;
 assign n4=n4_b23_2;
 wire n5_b23_5;
 assign n5=n5_b23_5;
 wire n6_b23_3;
 assign n6=n6_b23_3;
 wire n7_b23_15;
 assign n7=n7_b23_15;
 wire n8_b23_9;
 assign n8=n8_b23_9;
 wire n9_b23_14;
 assign n9=n9_b23_14;
 wire n10_b23_11;
 assign n10=n10_b23_11;
 wire n11_a01_2;
 assign n11=n11_a01_2;
 wire n16_h24_5;
 assign n16=n16_h24_5;
 wire n17_h24_2;
 assign n17=n17_h24_2;
 wire n18_h24_6;
 assign n18=n18_h24_6;
 wire n19_h24_11;
 assign n19=n19_h24_11;
 wire n20_h24_14;
 assign n20=n20_h24_14;
 wire n21_h24_3;
 wire n21_h23_9;
 assign n21=n21_h24_3 | n21_h23_9;
 wire n22_g21_14;
 assign n22=n22_g21_14;
 wire n23_g21_15;
 assign n23=n23_g21_15;
 wire n24_g20_15;
 assign n24=n24_g20_15;
 wire n25_f22_2;
 assign n25=n25_f22_2;
 wire n28_g19_15;
 assign n28=n28_g19_15;
 wire n29_l01_4;
 assign n29=n29_l01_4;
 wire n30_k10_3;
 assign n30=n30_k10_3;
 wire n31_j18_3;
 assign n31=n31_j18_3;
 wire n32_j18_2;
 assign n32=n32_j18_2;
 wire n33_j18_4;
 assign n33=n33_j18_4;
 wire n34_i05_3;
 assign n34=n34_i05_3;
 wire n35_i05_4;
 assign n35=n35_i05_4;
 wire n36_c18_3;
 assign n36=n36_c18_3;
 wire n37_c18_2;
 assign n37=n37_c18_2;
 wire n38_j18_13;
 assign n38=n38_j18_13;
 wire n39_j18_14;
 assign n39=n39_j18_14;
 wire n40_j18_12;
 assign n40=n40_j18_12;
 wire n41_i05_2;
 assign n41=n41_i05_2;
 wire n42_g22_3;
 assign n42=n42_g22_3;
 wire n43_h11_1;
 assign n43=n43_h11_1;
 wire n44_h11_2;
 assign n44=n44_h11_2;
 wire n45_h11_15;
 assign n45=n45_h11_15;
 wire n46_h11_14;
 assign n46=n46_h11_14;
 wire n47_a21_14;
 assign n47=n47_a21_14;
 wire n48_a21_15;
 assign n48=n48_a21_15;
 wire n49_a21_2;
 assign n49=n49_a21_2;
 wire n50_a21_3;
 assign n50=n50_a21_3;
 wire n51_a22_2;
 wire n51_a22_3;
 wire n51_a22_15;
 wire n51_a22_14;
 assign n51=n51_a22_2 | n51_a22_3 | n51_a22_15 | n51_a22_14;
 wire n52_i14_14;
 assign n52=n52_i14_14;
 wire n53_i14_15;
 assign n53=n53_i14_15;
 wire n54_i14_2;
 assign n54=n54_i14_2;
 wire n55_i14_3;
 assign n55=n55_i14_3;
 wire n56_h18_9;
 assign n56=n56_h18_9;
 wire n57_k10_13;
 assign n57=n57_k10_13;
 wire n58_k10_14;
 assign n58=n58_k10_14;
 wire n59_e19_4;
 assign n59=n59_e19_4;
 wire n60_l09_2;
 wire n60_l08_3;
 assign n60=n60_l09_2 | n60_l08_3;
 wire n61_l08_12;
 wire n61_l08_2;
 assign n61=n61_l08_12 | n61_l08_2;
 wire n62_l09_3;
 wire n62_l08_13;
 assign n62=n62_l09_3 | n62_l08_13;
 wire n63_l11_2;
 assign n63=n63_l11_2;
 wire n64_b24_13;
 wire n64_c23_3;
 assign n64=n64_b24_13 | n64_c23_3;
 wire n65_c23_2;
 wire n65_b24_14;
 assign n65=n65_c23_2 | n65_b24_14;
 wire n66_c23_13;
 wire n66_d24_9;
 wire n66_d23_14;
 assign n66=n66_c23_13 | n66_d24_9 | n66_d23_14;
 wire n67_c23_12;
 wire n67_d23_11;
 wire n67_d24_14;
 assign n67=n67_c23_12 | n67_d23_11 | n67_d24_14;
 wire n68_d23_2;
 wire n68_d24_3;
 wire n68_c23_14;
 assign n68=n68_d23_2 | n68_d24_3 | n68_c23_14;
 wire n69_e24_6;
 assign n69=n69_e24_6;
 wire n70_e24_4;
 assign n70=n70_e24_4;
 wire n71_e24_3;
 assign n71=n71_e24_3;
 wire n72_e24_13;
 assign n72=n72_e24_13;
 wire n73_e24_12;
 assign n73=n73_e24_12;
 wire n74_e24_11;
 assign n74=n74_e24_11;
 wire n75_e24_10;
 assign n75=n75_e24_10;
 wire n76_f24_6;
 assign n76=n76_f24_6;
 wire n77_f24_5;
 assign n77=n77_f24_5;
 wire n78_f24_4;
 assign n78=n78_f24_4;
 wire n79_f23_15;
 wire n79_f23_11;
 assign n79=n79_f23_15 | n79_f23_11;
 wire n80_f24_3;
 assign n80=n80_f24_3;
 wire n81_f24_13;
 assign n81=n81_f24_13;
 wire n82_f23_9;
 wire n82_f23_14;
 assign n82=n82_f23_9 | n82_f23_14;
 wire n83_f24_12;
 assign n83=n83_f24_12;
 wire n84_f24_11;
 assign n84=n84_f24_11;
 wire n85_g22_2;
 assign n85=n85_g22_2;
 wire n86_f24_10;
 assign n86=n86_f24_10;
 wire n88_d24_6;
 assign n88=n88_d24_6;
 wire n89_d24_2;
 assign n89=n89_d24_2;
 wire n91_d23_6;
 assign n91=n91_d23_6;
 wire n92_d23_5;
 assign n92=n92_d23_5;
 wire n94_e23_2;
 assign n94=n94_e23_2;
 wire n95_e23_5;
 assign n95=n95_e23_5;
 wire n97_e23_3;
 assign n97=n97_e23_3;
 wire n98_e23_6;
 assign n98=n98_e23_6;
 wire n100_e23_14;
 assign n100=n100_e23_14;
 wire n101_e23_11;
 assign n101=n101_e23_11;
 wire n103_e23_15;
 assign n103=n103_e23_15;
 wire n104_e23_9;
 assign n104=n104_e23_9;
 wire n106_f23_2;
 assign n106=n106_f23_2;
 wire n107_f23_5;
 assign n107=n107_f23_5;
 wire n109_f23_3;
 assign n109=n109_f23_3;
 wire n110_f23_6;
 assign n110=n110_f23_6;
 wire n111_g16_3;
 assign n111=n111_g16_3;
 wire n115_i18_4;
 assign n115=n115_i18_4;
 wire n134_f19_15;
 assign n134=n134_f19_15;
 wire n135_f19_14;
 assign n135=n135_f19_14;
 wire n136_g18_15;
 assign n136=n136_g18_15;
 wire n137_e19_13;
 assign n137=n137_e19_13;
 wire n138_g23_14;
 assign n138=n138_g23_14;
 wire n142_g23_9;
 assign n142=n142_g23_9;
 wire n143_g22_15;
 assign n143=n143_g22_15;
 wire n155_h24_15;
 assign n155=n155_h24_15;
 wire n156_h24_9;
 assign n156=n156_h24_9;
 wire n158_c18_14;
 assign n158=n158_c18_14;
 wire n159_a20_14;
 assign n159=n159_a20_14;
 wire n160_a20_15;
 assign n160=n160_a20_15;
 wire n161_a20_2;
 assign n161=n161_a20_2;
 wire n162_a20_3;
 assign n162=n162_a20_3;
 wire n163_d17_15;
 assign n163=n163_d17_15;
 wire n164_a19_1;
 assign n164=n164_a19_1;
 wire n165_a19_2;
 assign n165=n165_a19_2;
 wire n166_a19_15;
 assign n166=n166_a19_15;
 wire n167_a19_14;
 assign n167=n167_a19_14;
 wire n169_h18_15;
 assign n169=n169_h18_15;
 wire n171_a24_15;
 assign n171=n171_a24_15;
 wire n173_a24_14;
 assign n173=n173_a24_14;
 wire n175_a24_3;
 assign n175=n175_a24_3;
 wire n177_a24_2;
 assign n177=n177_a24_2;
 wire n179_h14_15;
 assign n179=n179_h14_15;
 wire n180_k15_11;
 assign n180=n180_k15_11;
 wire n181_j19_2;
 assign n181=n181_j19_2;
 wire n192_j20_14;
 wire n192_h20_15;
 wire n192_h17_6;
 assign n192=n192_j20_14 | n192_h20_15 | n192_h17_6;
 wire n193_f13_13;
 assign n193=n193_f13_13;
 wire n194_f13_12;
 assign n194=n194_f13_12;
 wire n195_f13_14;
 assign n195=n195_f13_14;
 wire n196_g13_3;
 assign n196=n196_g13_3;
 wire n197_f12_14;
 assign n197=n197_f12_14;
 wire n198_f13_2;
 assign n198=n198_f13_2;
 wire n199_f13_4;
 assign n199=n199_f13_4;
 wire n200_f13_3;
 assign n200=n200_f13_3;
 wire n201_f12_13;
 assign n201=n201_f12_13;
 wire n202_g13_13;
 assign n202=n202_g13_13;
 wire n203_d23_15;
 assign n203=n203_d23_15;
 wire n204_d23_9;
 assign n204=n204_d23_9;
 wire n205_d24_11;
 wire n205_d23_3;
 assign n205=n205_d24_11 | n205_d23_3;
 wire n206_g12_3;
 assign n206=n206_g12_3;
 wire n207_g12_2;
 assign n207=n207_g12_2;
 wire n208_g12_4;
 assign n208=n208_g12_4;
 wire n209_f12_4;
 assign n209=n209_f12_4;
 wire n210_f12_3;
 assign n210=n210_f12_3;
 wire n212_l03_2;
 assign n212=n212_l03_2;
 wire n214_l03_1;
 assign n214=n214_l03_1;
 wire n216_l03_15;
 assign n216=n216_l03_15;
 wire n218_l03_14;
 assign n218=n218_l03_14;
 wire n220_l04_2;
 assign n220=n220_l04_2;
 wire n222_l04_1;
 assign n222=n222_l04_1;
 wire n224_l04_15;
 assign n224=n224_l04_15;
 wire n225_l04_14;
 assign n225=n225_l04_14;
 wire n226_f20_2;
 assign n226=n226_f20_2;
 wire n227_l08_14;
 assign n227=n227_l08_14;
 wire n228_l09_4;
 assign n228=n228_l09_4;
 wire n229_l08_4;
 assign n229=n229_l08_4;
 wire n230_b24_4;
 assign n230=n230_b24_4;
 wire n231_b24_2;
 assign n231=n231_b24_2;
 wire n232_b24_3;
 assign n232=n232_b24_3;
 wire n233_g20_3;
 assign n233=n233_g20_3;
 wire n234_f20_3;
 assign n234=n234_f20_3;
 wire n235_a24_9;
 wire n235_a24_11;
 wire n235_a24_6;
 wire n235_a24_5;
 assign n235=n235_a24_9 | n235_a24_11 | n235_a24_6 | n235_a24_5;
 wire n236_i15_14;
 assign n236=n236_i15_14;
 wire n237_a18_2;
 assign n237=n237_a18_2;
 wire n238_a18_1;
 assign n238=n238_a18_1;
 wire n239_a18_15;
 assign n239=n239_a18_15;
 wire n240_a18_14;
 assign n240=n240_a18_14;
 wire n241_f20_14;
 assign n241=n241_f20_14;
 wire n243_g22_14;
 assign n243=n243_g22_14;
 wire n244_e21_14;
 assign n244=n244_e21_14;
 wire n246_d20_3;
 assign n246=n246_d20_3;
 wire n247_d20_2;
 assign n247=n247_d20_2;
 wire n248_f20_15;
 wire n248_g23_3;
 assign n248=n248_f20_15 | n248_g23_3;
 wire n249_h23_2;
 assign n249=n249_h23_2;
 wire n250_h23_3;
 assign n250=n250_h23_3;
 wire n251_h23_14;
 assign n251=n251_h23_14;
 wire n252_g23_2;
 assign n252=n252_g23_2;
 wire n254_l09_12;
 assign n254=n254_l09_12;
 wire n255_h20_3;
 wire n255_g20_2;
 assign n255=n255_h20_3 | n255_g20_2;
 wire n256_h14_14;
 assign n256=n256_h14_14;
 wire n257_e21_9;
 assign n257=n257_e21_9;
 wire n258_h20_2;
 assign n258=n258_h20_2;
 wire n259_h17_2;
 assign n259=n259_h17_2;
 wire n260_i11_15;
 wire n260_h12_1;
 wire n260_h13_1;
 wire n260_i19_3;
 assign n260=n260_i11_15 | n260_h12_1 | n260_h13_1 | n260_i19_3;
 wire n261_h16_14;
 assign n261=n261_h16_14;
 wire n262_h16_15;
 assign n262=n262_h16_15;
 wire n263_h16_2;
 assign n263=n263_h16_2;
 wire n264_h16_1;
 assign n264=n264_h16_1;
 wire n265_g14_1;
 assign n265=n265_g14_1;
 wire n266_g14_2;
 assign n266=n266_g14_2;
 wire n267_g14_15;
 assign n267=n267_g14_15;
 wire n268_g14_14;
 assign n268=n268_g14_14;
 wire n269_h17_3;
 assign n269=n269_h17_3;
 wire n270_g15_2;
 assign n270=n270_g15_2;
 wire n271_h12_14;
 wire n271_h13_14;
 assign n271=n271_h12_14 | n271_h13_14;
 wire n272_h12_15;
 wire n272_h13_15;
 assign n272=n272_h12_15 | n272_h13_15;
 wire n273_g15_1;
 assign n273=n273_g15_1;
 wire n274_g15_15;
 assign n274=n274_g15_15;
 wire n275_h13_2;
 wire n275_h12_2;
 wire n275_i11_14;
 assign n275=n275_h13_2 | n275_h12_2 | n275_i11_14;
 wire n276_g15_14;
 assign n276=n276_g15_14;
 wire n277_k19_9;
 wire n277_k19_11;
 wire n277_k19_6;
 assign n277=n277_k19_9 | n277_k19_11 | n277_k19_6;
 wire n278_h17_7;
 assign n278=n278_h17_7;
 wire n279_j20_15;
 assign n279=n279_j20_15;
 wire n280_d20_14;
 assign n280=n280_d20_14;
 wire n281_g16_2;
 assign n281=n281_g16_2;
 wire n282_g21_2;
 assign n282=n282_g21_2;
 wire n283_k20_2;
 wire n283_j20_2;
 assign n283=n283_k20_2 | n283_j20_2;
 wire n284_k19_14;
 wire n284_k19_15;
 wire n284_k19_3;
 wire n284_k19_2;
 wire n284_l19_2;
 assign n284=n284_k19_14 | n284_k19_15 | n284_k19_3 | n284_k19_2 | n284_l19_2;
 wire n285_k19_5;
 wire n285_l19_3;
 assign n285=n285_k19_5 | n285_l19_3;
 wire n286_h18_3;
 assign n286=n286_h18_3;
 wire n287_h18_14;
 assign n287=n287_h18_14;
 wire n288_f22_3;
 assign n288=n288_f22_3;
 wire n289_j17_2;
 assign n289=n289_j17_2;
 wire n290_k17_2;
 assign n290=n290_k17_2;
 wire n291_j13_15;
 wire n291_k14_3;
 assign n291=n291_j13_15 | n291_k14_3;
 wire n292_l17_14;
 assign n292=n292_l17_14;
 wire n293_l17_4;
 assign n293=n293_l17_4;
 wire n294_j16_2;
 wire n294_k16_14;
 assign n294=n294_j16_2 | n294_k16_14;
 wire n295_j16_15;
 wire n295_k16_15;
 assign n295=n295_j16_15 | n295_k16_15;
 wire n296_j15_15;
 wire n296_k16_3;
 assign n296=n296_j15_15 | n296_k16_3;
 wire n297_k18_15;
 assign n297=n297_k18_15;
 wire n298_k18_3;
 assign n298=n298_k18_3;
 wire n299_k18_2;
 assign n299=n299_k18_2;
 wire n300_k18_4;
 assign n300=n300_k18_4;
 wire n301_k18_13;
 assign n301=n301_k18_13;
 wire n302_j14_2;
 wire n302_k14_14;
 assign n302=n302_j14_2 | n302_k14_14;
 wire n303_k18_14;
 assign n303=n303_k18_14;
 wire n304_j15_2;
 wire n304_k16_2;
 assign n304=n304_j15_2 | n304_k16_2;
 wire n305_j14_15;
 wire n305_k14_15;
 assign n305=n305_j14_15 | n305_k14_15;
 wire n306_j13_2;
 wire n306_k14_2;
 assign n306=n306_j13_2 | n306_k14_2;
 wire n307_k17_4;
 assign n307=n307_k17_4;
 wire n308_j17_4;
 assign n308=n308_j17_4;
 wire n309_j17_14;
 assign n309=n309_j17_14;
 wire n310_k17_14;
 assign n310=n310_k17_14;
 wire n312_f22_14;
 assign n312=n312_f22_14;
 wire n314_h17_14;
 assign n314=n314_h17_14;
 wire n315_h19_14;
 assign n315=n315_h19_14;
 wire n316_g18_3;
 assign n316=n316_g18_3;
 wire n317_g18_4;
 assign n317=n317_g18_4;
 wire n318_g18_2;
 assign n318=n318_g18_2;
 wire n319_i13_2;
 assign n319=n319_i13_2;
 wire n320_k04_2;
 assign n320=n320_k04_2;
 wire n321_i19_2;
 assign n321=n321_i19_2;
 wire n322_i19_15;
 assign n322=n322_i19_15;
 wire n323_f12_2;
 assign n323=n323_f12_2;
 wire n325_l11_14;
 assign n325=n325_l11_14;
 wire n326_g06_1;
 assign n326=n326_g06_1;
 wire n327_g06_2;
 assign n327=n327_g06_2;
 wire n328_g06_15;
 assign n328=n328_g06_15;
 wire n329_g06_14;
 assign n329=n329_g06_14;
 wire n330_g07_1;
 assign n330=n330_g07_1;
 wire n331_g07_2;
 assign n331=n331_g07_2;
 wire n332_g07_15;
 assign n332=n332_g07_15;
 wire n333_g07_14;
 assign n333=n333_g07_14;
 wire n334_c06_2;
 assign n334=n334_c06_2;
 wire n335_h14_2;
 assign n335=n335_h14_2;
 wire n336_h14_3;
 assign n336=n336_h14_3;
 wire n337_h14_4;
 assign n337=n337_h14_4;
 wire n338_h14_13;
 assign n338=n338_h14_13;
 wire n339_g19_2;
 wire n339_i10_3;
 assign n339=n339_g19_2 | n339_i10_3;
 wire n340_i18_14;
 assign n340=n340_i18_14;
 wire n341_h19_2;
 assign n341=n341_h19_2;
 wire n343_l05_2;
 assign n343=n343_l05_2;
 wire n344_l05_5;
 assign n344=n344_l05_5;
 wire n346_l05_3;
 assign n346=n346_l05_3;
 wire n347_l05_6;
 assign n347=n347_l05_6;
 wire n349_l05_14;
 assign n349=n349_l05_14;
 wire n350_l05_11;
 assign n350=n350_l05_11;
 wire n352_l05_15;
 assign n352=n352_l05_15;
 wire n353_l05_9;
 assign n353=n353_l05_9;
 wire n354_g10_2;
 assign n354=n354_g10_2;
 wire n355_g10_3;
 assign n355=n355_g10_3;
 wire n356_g10_15;
 assign n356=n356_g10_15;
 wire n357_g10_14;
 assign n357=n357_g10_14;
 wire n358_h10_2;
 assign n358=n358_h10_2;
 wire n359_h10_3;
 assign n359=n359_h10_3;
 wire n360_h10_15;
 assign n360=n360_h10_15;
 wire n361_h10_14;
 assign n361=n361_h10_14;
 wire n362_k08_15;
 wire n362_k08_2;
 assign n362=n362_k08_15 | n362_k08_2;
 wire n363_k08_14;
 wire n363_k08_3;
 assign n363=n363_k08_14 | n363_k08_3;
 wire n364_k09_2;
 wire n364_k09_15;
 assign n364=n364_k09_2 | n364_k09_15;
 wire n365_k09_3;
 wire n365_k09_14;
 assign n365=n365_k09_3 | n365_k09_14;
 wire n366_l10_3;
 assign n366=n366_l10_3;
 wire n367_l10_2;
 assign n367=n367_l10_2;
 wire n368_l07_15;
 assign n368=n368_l07_15;
 wire n369_d17_3;
 assign n369=n369_d17_3;
 wire n370_d17_2;
 assign n370=n370_d17_2;
 wire n371_h15_1;
 assign n371=n371_h15_1;
 wire n372_h15_2;
 assign n372=n372_h15_2;
 wire n373_h15_15;
 assign n373=n373_h15_15;
 wire n374_h15_14;
 assign n374=n374_h15_14;
 wire n375_i15_2;
 assign n375=n375_i15_2;
 wire n376_i15_3;
 assign n376=n376_i15_3;
 wire n377_i15_4;
 assign n377=n377_i15_4;
 wire n378_i15_13;
 assign n378=n378_i15_13;
 wire n379_j05_13;
 assign n379=n379_j05_13;
 wire n380_j05_12;
 assign n380=n380_j05_12;
 wire n381_j05_14;
 assign n381=n381_j05_14;
 wire n382_d17_13;
 assign n382=n382_d17_13;
 wire n383_g12_13;
 assign n383=n383_g12_13;
 wire n384_g12_12;
 assign n384=n384_g12_12;
 wire n385_g12_14;
 assign n385=n385_g12_14;
 wire n387_k12_14;
 wire n387_k13_15;
 wire n387_k15_3;
 wire n387_k13_14;
 wire n387_k13_2;
 wire n387_k13_3;
 wire n387_k12_15;
 wire n387_k12_2;
 wire n387_k12_3;
 assign n387=n387_k12_14 | n387_k13_15 | n387_k15_3 | n387_k13_14 | n387_k13_2 | n387_k13_3 | n387_k12_15 | n387_k12_2 | n387_k12_3;
 wire n388_l06_3;
 wire n388_l06_14;
 wire n388_l07_3;
 assign n388=n388_l06_3 | n388_l06_14 | n388_l07_3;
 wire n389_g16_14;
 assign n389=n389_g16_14;
 wire n390_c18_13;
 assign n390=n390_c18_13;
 wire n391_c18_12;
 assign n391=n391_c18_12;
 wire n392_i18_2;
 assign n392=n392_i18_2;
 wire n393_g19_3;
 assign n393=n393_g19_3;
 wire n394_g09_3;
 assign n394=n394_g09_3;
 wire n395_g09_14;
 assign n395=n395_g09_14;
 wire n396_g09_2;
 assign n396=n396_g09_2;
 wire n397_g09_15;
 assign n397=n397_g09_15;
 wire n399_a01_3;
 assign n399=n399_a01_3;
 wire n401_k11_2;
 assign n401=n401_k11_2;
 wire n402_k11_3;
 assign n402=n402_k11_3;
 wire n403_k11_4;
 assign n403=n403_k11_4;
 wire n404_k11_13;
 assign n404=n404_k11_13;
 wire n405_g08_2;
 assign n405=n405_g08_2;
 wire n406_j11_2;
 assign n406=n406_j11_2;
 wire n407_g08_3;
 assign n407=n407_g08_3;
 wire n408_j11_3;
 assign n408=n408_j11_3;
 wire n409_g08_4;
 assign n409=n409_g08_4;
 wire n410_j11_4;
 assign n410=n410_j11_4;
 wire n411_g08_13;
 assign n411=n411_g08_13;
 wire n412_j11_13;
 assign n412=n412_j11_13;
 wire n413_g08_14;
 assign n413=n413_g08_14;
 wire n414_j11_14;
 assign n414=n414_j11_14;
 wire n415_g08_15;
 assign n415=n415_g08_15;
 wire n416_j11_15;
 assign n416=n416_j11_15;
 wire n417_l13_14;
 wire n417_l13_15;
 wire n417_l13_2;
 wire n417_l13_3;
 wire n417_l12_14;
 wire n417_l12_15;
 wire n417_l12_2;
 wire n417_l12_3;
 assign n417=n417_l13_14 | n417_l13_15 | n417_l13_2 | n417_l13_3 | n417_l12_14 | n417_l12_15 | n417_l12_2 | n417_l12_3;
 wire n418_k15_13;
 assign n418=n418_k15_13;
 wire n419_l14_2;
 assign n419=n419_l14_2;
 wire n420_l14_3;
 assign n420=n420_l14_3;
 wire n421_l14_4;
 assign n421=n421_l14_4;
 wire n422_l14_13;
 assign n422=n422_l14_13;
 wire n423_l14_14;
 assign n423=n423_l14_14;
 wire n424_l14_15;
 assign n424=n424_l14_15;
 wire n425_l15_15;
 assign n425=n425_l15_15;
 wire n426_l15_14;
 assign n426=n426_l15_14;
 wire n427_h19_9;
 assign n427=n427_h19_9;
 wire n428_l15_2;
 assign n428=n428_l15_2;
 wire n429_l15_3;
 assign n429=n429_l15_3;
 wire n430_d20_15;
 assign n430=n430_d20_15;
 wire n431_l16_14;
 assign n431=n431_l16_14;
 wire n432_l16_15;
 assign n432=n432_l16_15;
 wire n433_l16_2;
 assign n433=n433_l16_2;
 wire n434_l16_3;
 assign n434=n434_l16_3;
 wire n435_l18_14;
 assign n435=n435_l18_14;
 wire n436_l18_15;
 assign n436=n436_l18_15;
 wire n437_l18_3;
 assign n437=n437_l18_3;
 wire n438_h18_2;
 assign n438=n438_h18_2;
 wire n439_h19_3;
 assign n439=n439_h19_3;
 wire n440_l18_2;
 assign n440=n440_l18_2;
 wire n441_l10_15;
 assign n441=n441_l10_15;
 wire n442_i15_15;
 assign n442=n442_i15_15;
 wire n443_l10_14;
 assign n443=n443_l10_14;
 wire n444_g18_13;
 assign n444=n444_g18_13;
 wire n445_i16_1;
 assign n445=n445_i16_1;
 wire n446_i16_2;
 assign n446=n446_i16_2;
 wire n447_i16_15;
 assign n447=n447_i16_15;
 wire n448_i16_14;
 assign n448=n448_i16_14;
 wire n449_i17_1;
 assign n449=n449_i17_1;
 wire n450_i17_2;
 assign n450=n450_i17_2;
 wire n451_i17_15;
 assign n451=n451_i17_15;
 wire n452_i17_14;
 assign n452=n452_i17_14;
 wire n455_i03_1;
 assign n455=n455_i03_1;
 wire n456_i03_2;
 assign n456=n456_i03_2;
 wire n457_i03_15;
 assign n457=n457_i03_15;
 wire n458_i03_14;
 assign n458=n458_i03_14;
 wire n459_i04_1;
 assign n459=n459_i04_1;
 wire n460_i04_2;
 assign n460=n460_i04_2;
 wire n461_i04_15;
 assign n461=n461_i04_15;
 wire n462_i04_14;
 assign n462=n462_i04_14;
 wire n463_d06_2;
 assign n463=n463_d06_2;
 wire n464_f19_3;
 assign n464=n464_f19_3;
 wire n465_d17_4;
 assign n465=n465_d17_4;
 wire n466_j05_3;
 assign n466=n466_j05_3;
 wire n467_j05_2;
 assign n467=n467_j05_2;
 wire n468_d17_14;
 assign n468=n468_d17_14;
 wire n470_g16_15;
 assign n470=n470_g16_15;
 wire n471_a01_14;
 assign n471=n471_a01_14;
 wire n472_j19_15;
 assign n472=n472_j19_15;
 wire n475_g18_14;
 assign n475=n475_g18_14;
 wire n484_e21_2;
 assign n484=n484_e21_2;
 wire n485_e21_3;
 assign n485=n485_e21_3;
 wire n494_g20_14;
 assign n494=n494_g20_14;
 wire n495_g05_1;
 assign n495=n495_g05_1;
 wire n496_g05_2;
 assign n496=n496_g05_2;
 wire n497_g05_15;
 assign n497=n497_g05_15;
 wire n498_g05_14;
 assign n498=n498_g05_14;
 wire n499_h05_1;
 assign n499=n499_h05_1;
 wire n500_h05_2;
 assign n500=n500_h05_2;
 wire n501_h05_15;
 assign n501=n501_h05_15;
 wire n502_h05_14;
 assign n502=n502_h05_14;
 wire n503_j01_1;
 assign n503=n503_j01_1;
 wire n504_j01_2;
 assign n504=n504_j01_2;
 wire n505_j01_15;
 assign n505=n505_j01_15;
 wire n506_j01_14;
 assign n506=n506_j01_14;
 wire n507_j02_1;
 assign n507=n507_j02_1;
 wire n508_j02_2;
 assign n508=n508_j02_2;
 wire n509_j02_15;
 assign n509=n509_j02_15;
 wire n510_j02_14;
 assign n510=n510_j02_14;
 wire n511_j03_1;
 assign n511=n511_j03_1;
 wire n512_j03_2;
 assign n512=n512_j03_2;
 wire n513_j03_15;
 assign n513=n513_j03_15;
 wire n514_j03_14;
 assign n514=n514_j03_14;
 wire n515_j04_1;
 assign n515=n515_j04_1;
 wire n516_j04_2;
 assign n516=n516_j04_2;
 wire n517_j04_15;
 assign n517=n517_j04_15;
 wire n518_j04_14;
 assign n518=n518_j04_14;
 wire n519_k01_1;
 assign n519=n519_k01_1;
 wire n520_k01_2;
 assign n520=n520_k01_2;
 wire n521_k01_15;
 assign n521=n521_k01_15;
 wire n522_k01_14;
 assign n522=n522_k01_14;
 wire n523_k02_1;
 assign n523=n523_k02_1;
 wire n524_k02_2;
 assign n524=n524_k02_2;
 wire n525_k02_15;
 assign n525=n525_k02_15;
 wire n526_k02_14;
 assign n526=n526_k02_14;
 wire n529_l02_2;
 assign n529=n529_l02_2;
 wire n530_l01_13;
 assign n530=n530_l01_13;
 wire n531_l01_12;
 assign n531=n531_l01_12;
 wire n532_l01_14;
 assign n532=n532_l01_14;
 comb_MC10102 a01(.p1(1'b0),.p2(n11_a01_2),.p3(n399_a01_3),.p4(n12),.p5(1'b0),.p6(n311),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n471_a01_14),.p16(1'b0));
 comb_MC10158 a18(.p1(n238_a18_1),.p2(n237_a18_2),.p3(n165),.p4(n48),.p5(n164),.p6(n47),.p9(n384),.p10(n167),.p11(n50),.p12(n166),.p13(n49),.p14(n240_a18_14),.p15(n239_a18_15));
 comb_MC10158 a19(.p1(n164_a19_1),.p2(n165_a19_2),.p3(n173),.p4(n160),.p5(n171),.p6(n159),.p9(n208),.p10(n177),.p11(n162),.p12(n175),.p13(n161),.p14(n167_a19_14),.p15(n166_a19_15));
 sampled_MC10141 a20(.p1(n124),.p2(n161_a20_2),.p3(n162_a20_3),.p4(n36),.p5(1'b0),.p6(n50),.p7(1'b0),.p8(1'b0),.p9(n49),.p10(1'b0),.p11(n48),.p12(n47),.p13(1'b0),.p14(n159_a20_14),.p15(n160_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 sampled_MC10141 a21(.p1(1'b0),.p2(n49_a21_2),.p3(n50_a21_3),.p4(n390),.p5(1'b0),.p6(n177),.p7(n384),.p8(1'b0),.p9(n175),.p10(n384),.p11(n173),.p12(n171),.p13(1'b0),.p14(n47_a21_14),.p15(n48_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 comb_MC10113 a22(.p1(1'b0),.p2(n51_a22_2),.p3(n51_a22_3),.p4(n50),.p5(n177),.p6(n175),.p7(n49),.p9(1'b0),.p10(n173),.p11(n48),.p12(n171),.p13(n47),.p14(n51_a22_14),.p15(n51_a22_15));
 comb_MC10101 a24(.p2(n177_a24_2),.p3(n175_a24_3),.p4(n176),.p5(n235_a24_5),.p6(n235_a24_6),.p7(n174),.p9(n235_a24_9),.p10(n172),.p11(n235_a24_11),.p12(1'b0),.p13(n170),.p14(n173_a24_14),.p15(n171_a24_15));
 comb_MC10101 b23(.p2(n4_b23_2),.p3(n6_b23_3),.p4(1'b0),.p5(n5_b23_5),.p7(1'b0),.p9(n8_b23_9),.p10(n2),.p11(n10_b23_11),.p12(n1),.p13(n3),.p14(n9_b23_14),.p15(n7_b23_15));
 comb_MC10211 b24(.p2(n231_b24_2),.p3(n232_b24_3),.p4(n230_b24_4),.p5(n1),.p6(n3),.p7(n2),.p9(n5),.p10(n203),.p11(1'b0),.p13(n64_b24_13),.p14(n65_b24_14),.p15(n133),.p16(1'b0));
 comb_MC10170 c06(.p1(1'b0),.p2(n334_c06_2),.p3(n389),.p4(n333),.p5(n332),.p6(n331),.p7(n330),.p8(1'b0),.p9(n329),.p10(n328),.p11(n327),.p12(n326),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 comb_SE10210 c18(.p2(n37_c18_2),.p3(n36_c18_3),.p5(n199),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n208),.p10(1'b0),.p11(1'b0),.p12(n391_c18_12),.p13(n390_c18_13),.p14(n158_c18_14),.p15(n117),.p16(1'b0));
 comb_MC10210 c23(.p1(1'b0),.p2(n65_c23_2),.p3(n64_c23_3),.p5(1'b0),.p6(1'b0),.p7(n114),.p8(1'b0),.p9(n114),.p10(1'b0),.p11(n5),.p12(n67_c23_12),.p13(n66_c23_13),.p14(n68_c23_14),.p15(n118),.p16(1'b0));
 comb_MC10170 d06(.p1(1'b0),.p2(n463_d06_2),.p3(n470),.p4(n462),.p5(n461),.p6(n460),.p7(n459),.p8(1'b0),.p9(n458),.p10(n457),.p11(n456),.p12(n455),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 sampled_MC10176 d17(.p1(1'b0),.p2(n370_d17_2),.p3(n369_d17_3),.p4(n465_d17_4),.p5(n156),.p6(n155),.p7(n248),.p8(1'b0),.p9(n390),.p10(n251),.p11(n252),.p12(n51),.p13(n382_d17_13),.p14(n468_d17_14),.p15(n163_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 comb_MC10100 d20(.p2(n247_d20_2),.p3(n246_d20_3),.p4(n83),.p5(n73),.p6(n85),.p7(n73),.p9(n66),.p10(n82),.p11(n72),.p12(n83),.p13(n72),.p14(n280_d20_14),.p15(n430_d20_15));
 comb_MC10101 d23(.p2(n68_d23_2),.p3(n205_d23_3),.p4(n114),.p5(n92_d23_5),.p6(n91_d23_6),.p7(1'b0),.p9(n204_d23_9),.p10(1'b0),.p11(n67_d23_11),.p12(n90),.p13(n87),.p14(n66_d23_14),.p15(n203_d23_15));
 comb_MC10101 d24(.p2(n89_d24_2),.p3(n68_d24_3),.p4(n114),.p6(n88_d24_6),.p7(1'b0),.p9(n66_d24_9),.p10(1'b0),.p11(n205_d24_11),.p12(n87),.p13(1'b0),.p14(n67_d24_14));
 comb_MC10195 e19(.p3(n0_e19_3),.p4(n59_e19_4),.p5(1'b0),.p6(n233),.p7(n528),.p9(1'b0),.p10(n135),.p11(1'b0),.p12(1'b0),.p13(n137_e19_13));
 comb_MC10102 e21(.p1(1'b0),.p2(n484_e21_2),.p3(n485_e21_3),.p4(n18),.p5(n17),.p6(n19),.p7(n17),.p9(n257_e21_9),.p10(n76),.p11(n101),.p12(n51),.p13(n391),.p14(n244_e21_14),.p16(1'b0));
 comb_MC10101 e23(.p2(n94_e23_2),.p3(n97_e23_3),.p4(n93),.p5(n95_e23_5),.p6(n98_e23_6),.p7(n96),.p9(n104_e23_9),.p10(n99),.p11(n101_e23_11),.p12(1'b0),.p13(n102),.p14(n100_e23_14),.p15(n103_e23_15));
 comb_MC10161 e24(.p2(1'b0),.p3(n71_e24_3),.p4(n70_e24_4),.p6(n69_e24_6),.p7(n99),.p9(n96),.p10(n75_e24_10),.p11(n74_e24_11),.p12(n73_e24_12),.p13(n72_e24_13),.p14(n93),.p15(1'b0));
 comb_SE10212 f12(.p1(1'b0),.p2(n323_f12_2),.p3(n210_f12_3),.p4(n209_f12_4),.p5(n529),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n323),.p10(1'b0),.p11(n530),.p13(n201_f12_13),.p14(n197_f12_14),.p15(n119),.p16(1'b0));
 comb_SE10210 f13(.p2(n198_f13_2),.p3(n200_f13_3),.p4(n199_f13_4),.p5(n531),.p6(1'b0),.p7(n323),.p8(1'b0),.p9(n531),.p10(n29),.p11(1'b0),.p12(n194_f13_12),.p13(n193_f13_13),.p14(n195_f13_14),.p15(n120),.p16(1'b0));
 comb_MC1660 f19(.p3(n464_f19_3),.p4(n136),.p5(n163),.p6(n468),.p7(n469),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n182),.p14(n135_f19_14),.p15(n134_f19_15));
 comb_MC10100 f20(.p2(n226_f20_2),.p3(n234_f20_3),.p4(n84),.p5(n70),.p6(n82),.p7(n70),.p9(n65),.p10(n84),.p11(n71),.p12(n83),.p13(n75),.p14(n241_f20_14),.p15(n248_f20_15));
 comb_MC10100 f22(.p2(n25_f22_2),.p3(n288_f22_3),.p4(n94),.p5(n98),.p6(n70),.p7(n86),.p9(n65),.p10(n71),.p11(n76),.p12(1'b0),.p13(1'b0),.p14(n312_f22_14));
 comb_MC10101 f23(.p2(n106_f23_2),.p3(n109_f23_3),.p4(n105),.p5(n107_f23_5),.p6(n110_f23_6),.p7(n108),.p9(n82_f23_9),.p10(n104),.p11(n79_f23_11),.p12(1'b0),.p13(n107),.p14(n82_f23_14),.p15(n79_f23_15));
 comb_MC10161 f24(.p2(1'b0),.p3(n80_f24_3),.p4(n78_f24_4),.p5(n77_f24_5),.p6(n76_f24_6),.p7(n108),.p9(n105),.p10(n86_f24_10),.p11(n84_f24_11),.p12(n83_f24_12),.p13(n81_f24_13),.p14(n102),.p15(1'b0));
 sampled_MC10173 g05(.p1(n495_g05_1),.p2(n496_g05_2),.p3(n213),.p4(n145),.p5(n211),.p6(n144),.p7(n35),.p9(n386),.p10(n217),.p11(n147),.p12(n215),.p13(n146),.p14(n498_g05_14),.p15(n497_g05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[254+:4]),.state_q(state_q[254+:4]));
 sampled_MC10173 g06(.p1(n326_g06_1),.p2(n327_g06_2),.p3(n496),.p4(n504),.p5(n495),.p6(n503),.p7(n207),.p9(n368),.p10(n498),.p11(n506),.p12(n497),.p13(n505),.p14(n329_g06_14),.p15(n328_g06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[262+:4]),.state_q(state_q[262+:4]));
 sampled_MC10173 g07(.p1(n330_g07_1),.p2(n331_g07_2),.p3(n500),.p4(n508),.p5(n499),.p6(n507),.p7(n207),.p9(n368),.p10(n502),.p11(n510),.p12(n501),.p13(n509),.p14(n333_g07_14),.p15(n332_g07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[266+:4]),.state_q(state_q[266+:4]));
 sampled_MC10176 g08(.p1(1'b0),.p2(n405_g08_2),.p3(n407_g08_3),.p4(n409_g08_4),.p5(n302),.p6(n305),.p7(n304),.p8(1'b0),.p9(n57),.p10(n296),.p11(n294),.p12(n295),.p13(n411_g08_13),.p14(n413_g08_14),.p15(n415_g08_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[290+:6]),.state_q(state_q[290+:6]));
 comb_MC10117 g09(.p2(n396_g09_2),.p3(n394_g09_3),.p4(n392),.p5(n444),.p6(n115),.p7(n63),.p9(n191),.p10(n115),.p11(n63),.p12(n444),.p13(n392),.p14(n395_g09_14),.p15(n397_g09_15));
 sampled_MC10231 g10(.p1(1'b0),.p2(n354_g10_2),.p3(n355_g10_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n271),.p8(1'b0),.p9(n57),.p10(n272),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n357_g10_14),.p15(n356_g10_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[274+:2]),.state_q(state_q[274+:2]));
 comb_SE10211 g12(.p2(n207_g12_2),.p3(n206_g12_3),.p4(n208_g12_4),.p5(1'b0),.p6(n529),.p7(1'b0),.p9(n11),.p10(n135),.p11(1'b0),.p12(n384_g12_12),.p13(n383_g12_13),.p14(n385_g12_14),.p15(n121),.p16(1'b0));
 comb_SE10210 g13(.p3(n196_g13_3),.p5(n532),.p6(n29),.p7(1'b0),.p8(1'b0),.p9(n532),.p10(1'b0),.p11(1'b0),.p13(n202_g13_13),.p15(n122),.p16(1'b0));
 sampled_MC10173 g14(.p1(n265_g14_1),.p2(n266_g14_2),.p3(n44),.p4(n471),.p5(n43),.p6(n471),.p7(n31),.p9(n178),.p10(n46),.p11(n152),.p12(n45),.p13(n471),.p14(n268_g14_14),.p15(n267_g14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[308+:4]),.state_q(state_q[308+:4]));
 sampled_F10145A g15(.p1(n273_g15_1),.p2(n270_g15_2),.p3(1'b0),.p4(n266),.p5(n265),.p6(n167),.p7(n166),.p8(1'b0),.p9(n165),.p10(n164),.p11(n267),.p12(n268),.p13(n340),.p14(n276_g15_14),.p15(n274_g15_15),.fixture_load(fixture_load),.fixture_state(fixture_state[312+:64]),.state_q(state_q[312+:64]));
 sampled_F10000 g16(.p2(n281_g16_2),.p3(n111_g16_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n312),.p9(n439),.p10(n319),.p11(n313),.p12(1'b0),.p13(n38),.p14(n389_g16_14),.p15(n470_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 sampled_MC10176 g18(.p1(1'b0),.p2(n318_g18_2),.p3(n316_g18_3),.p4(n317_g18_4),.p5(n314),.p6(n321),.p7(n322),.p8(1'b0),.p9(n32),.p10(n282),.p11(n253),.p12(n137),.p13(n444_g18_13),.p14(n475_g18_14),.p15(n136_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 comb_MC10117 g19(.p2(n339_g19_2),.p3(n393_g19_3),.p4(n11),.p5(n135),.p6(n341),.p7(n257),.p9(n134),.p10(1'b0),.p11(n474),.p12(n473),.p13(n136),.p15(n28_g19_15));
 comb_MC10100 g20(.p2(n255_g20_2),.p3(n233_g20_3),.p4(n98),.p5(n95),.p6(n78),.p7(n74),.p9(n67),.p10(n75),.p11(1'b0),.p12(n97),.p13(n95),.p14(n494_g20_14),.p15(n24_g20_15));
 comb_MC10109 g21(.p2(n282_g21_2),.p4(n24),.p5(n25),.p6(n441),.p7(1'b0),.p8(1'b0),.p9(n205),.p10(n5),.p11(n97),.p12(n94),.p13(n114),.p14(n22_g21_14),.p15(n23_g21_15));
 comb_MC10103 g22(.p1(1'b0),.p2(n85_g22_2),.p3(n42_g22_3),.p4(n106),.p5(n103),.p6(n245),.p7(n242),.p10(n59),.p11(n245),.p12(n141),.p13(n134),.p14(n243_g22_14),.p15(n143_g22_15),.p16(1'b0));
 comb_MC10102 g23(.p1(1'b0),.p2(n252_g23_2),.p3(n248_g23_3),.p4(n157),.p5(n250),.p6(n153),.p7(n155),.p9(n142_g23_9),.p10(n140),.p11(n315),.p12(n134),.p13(n139),.p14(n138_g23_14),.p16(1'b0));
 sampled_MC10173 h05(.p1(n499_h05_1),.p2(n500_h05_2),.p3(n221),.p4(n149),.p5(n219),.p6(n148),.p7(n35),.p9(n386),.p10(n527),.p11(n151),.p12(n223),.p13(n150),.p14(n502_h05_14),.p15(n501_h05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[258+:4]),.state_q(state_q[258+:4]));
 sampled_MC10231 h10(.p1(1'b0),.p2(n358_h10_2),.p3(n359_h10_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n275),.p8(1'b0),.p9(n57),.p10(n260),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n361_h10_14),.p15(n360_h10_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[276+:2]),.state_q(state_q[276+:2]));
 comb_MC10159 h11(.p1(n43_h11_1),.p2(n44_h11_2),.p3(n481),.p4(n104),.p5(n480),.p6(n101),.p7(1'b0),.p9(n88),.p10(n483),.p11(n110),.p12(n482),.p13(n107),.p14(n46_h11_14),.p15(n45_h11_15));
 comb_MC10159 h12(.p1(n260_h12_1),.p2(n275_h12_2),.p3(n274),.p4(n373),.p5(n276),.p6(n374),.p7(n393),.p9(n392),.p10(n270),.p11(n371),.p12(n273),.p13(n372),.p14(n271_h12_14),.p15(n272_h12_15));
 comb_MC10159 h13(.p1(n260_h13_1),.p2(n275_h13_2),.p3(n45),.p4(n337),.p5(n46),.p6(n338),.p7(n339),.p9(n383),.p10(n43),.p11(n335),.p12(n44),.p13(n336),.p14(n271_h13_14),.p15(n272_h13_15));
 sampled_MC10176 h14(.p1(1'b0),.p2(n335_h14_2),.p3(n336_h14_3),.p4(n337_h14_4),.p5(n355),.p6(n357),.p7(n359),.p8(1'b0),.p9(n38),.p10(n361),.p11(n255),.p12(n178),.p13(n338_h14_13),.p14(n256_h14_14),.p15(n179_h14_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[376+:6]),.state_q(state_q[376+:6]));
 sampled_MC10173 h15(.p1(n371_h15_1),.p2(n372_h15_2),.p3(n336),.p4(n103),.p5(n335),.p6(n100),.p7(n31),.p9(n24),.p10(n338),.p11(n109),.p12(n337),.p13(n106),.p14(n374_h15_14),.p15(n373_h15_15),.fixture_load(fixture_load),.fixture_state(fixture_state[304+:4]),.state_q(state_q[304+:4]));
 comb_MC10159 h16(.p1(n264_h16_1),.p2(n263_h16_2),.p3(n349),.p4(n106),.p5(n352),.p6(n109),.p7(1'b0),.p9(n25),.p10(n343),.p11(n100),.p12(n346),.p13(n103),.p14(n261_h16_14),.p15(n262_h16_15));
 comb_MC10105 h17(.p1(1'b0),.p2(n259_h17_2),.p3(n269_h17_3),.p4(1'b0),.p5(n210),.p6(n192_h17_6),.p7(n278_h17_7),.p9(n441),.p10(n284),.p11(n347),.p12(n28),.p13(n168),.p14(n314_h17_14));
 comb_MC10103 h18(.p1(1'b0),.p2(n438_h18_2),.p3(n286_h18_3),.p4(n137),.p5(n180),.p6(n443),.p7(n392),.p9(n56_h18_9),.p10(n430),.p11(n392),.p12(n182),.p13(n281),.p14(n287_h18_14),.p15(n169_h18_15),.p16(1'b0));
 comb_MC10102 h19(.p1(1'b0),.p2(n341_h19_2),.p3(n439_h19_3),.p4(n256),.p5(n179),.p6(n280),.p7(n443),.p9(n427_h19_9),.p10(n142),.p11(n112),.p12(n428),.p13(n425),.p14(n315_h19_14),.p16(1'b0));
 comb_MC10106 h20(.p2(n258_h20_2),.p3(n255_h20_3),.p4(1'b0),.p5(n85),.p6(n69),.p7(n66),.p9(n392),.p10(n116),.p11(n385),.p12(n398),.p13(1'b0),.p14(n399),.p15(n192_h20_15));
 comb_MC10102 h23(.p1(1'b0),.p2(n249_h23_2),.p3(n250_h23_3),.p4(n155),.p5(n157),.p6(n153),.p7(n155),.p9(n21_h23_9),.p10(n153),.p11(n249),.p12(n17),.p13(n20),.p14(n251_h23_14),.p16(1'b0));
 comb_MC10101 h24(.p2(n17_h24_2),.p3(n21_h24_3),.p4(n13),.p5(n16_h24_5),.p6(n18_h24_6),.p7(n14),.p9(n156_h24_9),.p10(n15),.p11(n19_h24_11),.p12(1'b0),.p13(n154),.p14(n20_h24_14),.p15(n155_h24_15));
 sampled_MC10173 i03(.p1(n455_i03_1),.p2(n456_i03_2),.p3(n512),.p4(n520),.p5(n511),.p6(n519),.p7(n207),.p9(n464),.p10(n514),.p11(n522),.p12(n513),.p13(n521),.p14(n458_i03_14),.p15(n457_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 sampled_MC10173 i04(.p1(n459_i04_1),.p2(n460_i04_2),.p3(n516),.p4(n524),.p5(n515),.p6(n523),.p7(n207),.p9(n464),.p10(n518),.p11(n526),.p12(n517),.p13(n525),.p14(n462_i04_14),.p15(n461_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 comb_SE10212 i05(.p1(1'b0),.p2(n41_i05_2),.p3(n34_i05_3),.p4(n35_i05_4),.p5(1'b0),.p6(1'b0),.p7(n201),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n123),.p16(1'b0));
 comb_MC10102 i10(.p1(1'b0),.p3(n339_i10_3),.p4(1'b0),.p5(1'b0),.p6(n134),.p7(n180),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p16(1'b0));
 comb_MC10158 i11(.p3(1'b0),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p9(n258),.p10(1'b0),.p11(n453),.p12(1'b0),.p13(n454),.p14(n275_i11_14),.p15(n260_i11_15));
 sampled_F10145A i13(.p2(n319_i13_2),.p3(1'b0),.p4(1'b0),.p5(n320),.p6(n55),.p7(n54),.p8(1'b0),.p9(n53),.p10(n52),.p11(1'b0),.p12(1'b0),.p13(n467),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 sampled_MC10141 i14(.p1(1'b0),.p2(n54_i14_2),.p3(n55_i14_3),.p4(n58),.p5(1'b0),.p6(n240),.p7(1'b0),.p8(1'b0),.p9(n239),.p10(1'b0),.p11(n237),.p12(n238),.p13(1'b0),.p14(n52_i14_14),.p15(n53_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 sampled_MC10176 i15(.p1(1'b0),.p2(n375_i15_2),.p3(n376_i15_3),.p4(n377_i15_4),.p5(n261),.p6(n262),.p7(n263),.p8(1'b0),.p9(n31),.p10(n264),.p11(n443),.p12(n236),.p13(n378_i15_13),.p14(n236_i15_14),.p15(n442_i15_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[278+:6]),.state_q(state_q[278+:6]));
 sampled_MC10173 i16(.p1(n445_i16_1),.p2(n446_i16_2),.p3(n420),.p4(n420),.p5(n419),.p6(n419),.p7(n31),.p9(n288),.p10(n422),.p11(n293),.p12(n421),.p13(n292),.p14(n448_i16_14),.p15(n447_i16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[390+:4]),.state_q(state_q[390+:4]));
 sampled_MC10173 i17(.p1(n449_i17_1),.p2(n450_i17_2),.p3(n424),.p4(n307),.p5(n423),.p6(n310),.p7(n31),.p9(n288),.p10(n428),.p11(n308),.p12(n425),.p13(n309),.p14(n452_i17_14),.p15(n451_i17_15),.fixture_load(fixture_load),.fixture_state(fixture_state[394+:4]),.state_q(state_q[394+:4]));
 comb_SE10212 i18(.p1(1'b0),.p2(n392_i18_2),.p4(n115_i18_4),.p5(1'b0),.p6(1'b0),.p7(n210),.p8(1'b0),.p9(n341),.p10(n137),.p11(n200),.p14(n340_i18_14),.p15(n125),.p16(1'b0));
 comb_MC10106 i19(.p2(n321_i19_2),.p3(n260_i19_3),.p4(n51),.p5(n438),.p6(n392),.p7(n152),.p9(n368),.p10(n386),.p11(n334),.p12(n464),.p13(n469),.p14(n463),.p15(n322_i19_15));
 sampled_MC10173 j01(.p1(n503_j01_1),.p2(n504_j01_2),.p3(n184),.p4(n487),.p5(n183),.p6(n486),.p7(n34),.p9(n369),.p10(n186),.p11(n489),.p12(n185),.p13(n488),.p14(n506_j01_14),.p15(n505_j01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[246+:4]),.state_q(state_q[246+:4]));
 sampled_MC10173 j02(.p1(n507_j02_1),.p2(n508_j02_2),.p3(n188),.p4(n491),.p5(n187),.p6(n490),.p7(n35),.p9(n369),.p10(n190),.p11(n493),.p12(n189),.p13(n492),.p14(n510_j02_14),.p15(n509_j02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[250+:4]),.state_q(state_q[250+:4]));
 sampled_MC10173 j03(.p1(n511_j03_1),.p2(n512_j03_2),.p3(n214),.p4(n145),.p5(n212),.p6(n144),.p7(n35),.p9(n469),.p10(n218),.p11(n147),.p12(n216),.p13(n146),.p14(n514_j03_14),.p15(n513_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 sampled_MC10173 j04(.p1(n515_j04_1),.p2(n516_j04_2),.p3(n222),.p4(n149),.p5(n220),.p6(n148),.p7(n35),.p9(n469),.p10(n225),.p11(n151),.p12(n224),.p13(n150),.p14(n518_j04_14),.p15(n517_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 comb_SE10210 j05(.p2(n467_j05_2),.p3(n466_j05_3),.p5(n194),.p6(n136),.p7(n468),.p8(1'b0),.p9(n194),.p10(n136),.p11(n382),.p12(n380_j05_12),.p13(n379_j05_13),.p14(n381_j05_14),.p15(n126),.p16(1'b0));
 sampled_MC10176 j11(.p1(1'b0),.p2(n406_j11_2),.p3(n408_j11_3),.p4(n410_j11_4),.p5(n302),.p6(n305),.p7(n304),.p8(1'b0),.p9(n58),.p10(n296),.p11(n294),.p12(n295),.p13(n412_j11_13),.p14(n414_j11_14),.p15(n416_j11_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[296+:6]),.state_q(state_q[296+:6]));
 comb_MC10174 j13(.p1(1'b0),.p2(n306_j13_2),.p3(n476),.p4(n419),.p5(n431),.p6(n445),.p7(n287),.p9(n286),.p10(n446),.p11(n432),.p12(n420),.p13(n477),.p14(n169),.p15(n291_j13_15),.p16(1'b0));
 comb_MC10174 j14(.p1(1'b0),.p2(n302_j14_2),.p3(n478),.p4(n292),.p5(n433),.p6(n447),.p7(n287),.p9(n286),.p10(n448),.p11(n434),.p12(n293),.p13(n479),.p14(n169),.p15(n305_j14_15),.p16(1'b0));
 comb_MC10174 j15(.p1(1'b0),.p2(n304_j15_2),.p3(n480),.p4(n310),.p5(n435),.p6(n449),.p7(n287),.p9(n286),.p10(n450),.p11(n436),.p12(n307),.p13(n481),.p14(n169),.p15(n296_j15_15),.p16(1'b0));
 comb_MC10174 j16(.p1(1'b0),.p2(n294_j16_2),.p3(n482),.p4(n309),.p5(n440),.p6(n451),.p7(n287),.p9(n286),.p10(n452),.p11(n437),.p12(n308),.p13(n483),.p14(n169),.p15(n295_j16_15),.p16(1'b0));
 comb_MC10182 j17(.p1(1'b0),.p2(n289_j17_2),.p4(n308_j17_4),.p5(n428),.p6(n353),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n350),.p12(n425),.p13(1'b0),.p14(n309_j17_14),.p16(1'b0));
 comb_SE10210 j18(.p2(n32_j18_2),.p3(n31_j18_3),.p4(n33_j18_4),.p5(n196),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n200),.p10(1'b0),.p11(1'b0),.p12(n40_j18_12),.p13(n38_j18_13),.p14(n39_j18_14),.p15(n127),.p16(1'b0));
 sampled_MC10231 j19(.p1(1'b0),.p2(n181_j19_2),.p4(1'b0),.p5(1'b0),.p6(n439),.p7(n278),.p8(1'b0),.p9(n33),.p10(n279),.p11(n439),.p12(1'b0),.p13(1'b0),.p15(n472_j19_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[406+:2]),.state_q(state_q[406+:2]));
 comb_MC10117 j20(.p2(n283_j20_2),.p4(n427),.p5(n343),.p6(1'b0),.p7(n343),.p9(n346),.p10(n285),.p11(n277),.p12(n277),.p13(n283),.p14(n192_j20_14),.p15(n279_j20_15));
 sampled_MC10173 k01(.p1(n519_k01_1),.p2(n520_k01_2),.p3(n184),.p4(n487),.p5(n183),.p6(n486),.p7(n34),.p9(n465),.p10(n186),.p11(n489),.p12(n185),.p13(n488),.p14(n522_k01_14),.p15(n521_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 sampled_MC10173 k02(.p1(n523_k02_1),.p2(n524_k02_2),.p3(n188),.p4(n491),.p5(n187),.p6(n490),.p7(n34),.p9(n465),.p10(n190),.p11(n493),.p12(n189),.p13(n492),.p14(n526_k02_14),.p15(n525_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 comb_MC10170 k04(.p1(1'b0),.p2(n320_k04_2),.p3(n471),.p4(n526),.p5(n525),.p6(n524),.p7(n523),.p8(1'b0),.p9(n522),.p10(n521),.p11(n520),.p12(n519),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 comb_MC1662 k08(.p2(n362_k08_2),.p3(n363_k08_3),.p4(n342),.p5(n269),.p6(n345),.p7(n269),.p10(n259),.p11(n376),.p12(n259),.p13(n375),.p14(n363_k08_14),.p15(n362_k08_15));
 comb_MC1662 k09(.p2(n364_k09_2),.p3(n365_k09_3),.p4(n348),.p5(n269),.p6(n351),.p7(n269),.p10(n259),.p11(n378),.p12(n259),.p13(n377),.p14(n365_k09_14),.p15(n364_k09_15));
 comb_SE10210 k10(.p3(n30_k10_3),.p5(n194),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n202),.p13(n57_k10_13),.p14(n58_k10_14),.p15(n128),.p16(1'b0));
 sampled_MC10176 k11(.p1(1'b0),.p2(n401_k11_2),.p3(n402_k11_3),.p4(n403_k11_4),.p5(n306),.p6(n306),.p7(n291),.p8(1'b0),.p9(n58),.p10(n291),.p11(1'b0),.p12(1'b0),.p13(n404_k11_13),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[284+:6]),.state_q(state_q[284+:6]));
 comb_MC10113 k12(.p1(1'b0),.p2(n387_k12_2),.p3(n387_k12_3),.p4(n361),.p5(n374),.p6(n373),.p7(n359),.p9(n443),.p10(n372),.p11(n357),.p12(n371),.p13(n355),.p14(n387_k12_14),.p15(n387_k12_15));
 comb_MC10113 k13(.p1(1'b0),.p2(n387_k13_2),.p3(n387_k13_3),.p4(n353),.p5(n378),.p6(n377),.p7(n350),.p9(n443),.p10(n376),.p11(n347),.p12(n375),.p13(n344),.p14(n387_k13_14),.p15(n387_k13_15));
 comb_MC10101 k14(.p2(n306_k14_2),.p3(n291_k14_3),.p4(n299),.p7(n298),.p10(n300),.p12(n56),.p13(n301),.p14(n302_k14_14),.p15(n305_k14_15));
 comb_MC10107 k15(.p3(n387_k15_3),.p4(n444),.p5(n441),.p6(1'b0),.p7(n179),.p9(1'b0),.p11(n180_k15_11),.p13(n418_k15_13),.p14(n279),.p15(n278));
 comb_MC10101 k16(.p2(n304_k16_2),.p3(n296_k16_3),.p4(n303),.p7(n297),.p10(n426),.p12(n56),.p13(n429),.p14(n294_k16_14),.p15(n295_k16_15));
 comb_MC10182 k17(.p1(1'b0),.p2(n290_k17_2),.p4(n307_k17_4),.p5(n424),.p6(n347),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n347),.p12(n423),.p13(n289),.p14(n310_k17_14),.p16(1'b0));
 comb_MC10195 k18(.p2(n299_k18_2),.p3(n298_k18_3),.p4(n300_k18_4),.p5(n419),.p6(n420),.p7(n421),.p9(1'b0),.p10(n422),.p11(n423),.p12(n424),.p13(n301_k18_13),.p14(n303_k18_14),.p15(n297_k18_15));
 comb_MC10101 k19(.p2(n284_k19_2),.p3(n284_k19_3),.p4(n424),.p5(n285_k19_5),.p6(n277_k19_6),.p7(n423),.p9(n277_k19_9),.p10(n422),.p11(n277_k19_11),.p12(n441),.p13(n421),.p14(n284_k19_14),.p15(n284_k19_15));
 comb_MC10119 k20(.p2(n283_k20_2),.p3(n350),.p4(n427),.p5(n346),.p6(n353),.p7(n425),.p9(1'b0),.p10(n424),.p11(1'b0),.p12(n350),.p13(n428),.p14(n424),.p15(n353));
 comb_SE10210 l01(.p4(n29_l01_4),.p5(1'b0),.p6(n400),.p7(1'b0),.p8(1'b0),.p9(n27),.p10(1'b0),.p11(n26),.p12(n531_l01_12),.p13(n530_l01_13),.p14(n532_l01_14),.p15(n129),.p16(1'b0));
 sampled_SE10231 l02(.p2(n529_l02_2),.p6(n27),.p7(n29),.p9(n26),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 sampled_F10145A l03(.p1(n214_l03_1),.p2(n212_l03_2),.p3(1'b0),.p4(n520),.p5(n519),.p6(n55),.p7(n54),.p8(1'b0),.p9(n53),.p10(n52),.p11(n521),.p12(n522),.p13(n466),.p14(n218_l03_14),.p15(n216_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 sampled_F10145A l04(.p1(n222_l04_1),.p2(n220_l04_2),.p3(1'b0),.p4(n524),.p5(n523),.p6(n55),.p7(n54),.p8(1'b0),.p9(n53),.p10(n52),.p11(n525),.p12(n526),.p13(n466),.p14(n225_l04_14),.p15(n224_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 comb_MC10101 l05(.p2(n343_l05_2),.p3(n346_l05_3),.p4(n342),.p5(n344_l05_5),.p6(n347_l05_6),.p7(n345),.p9(n353_l05_9),.p10(n348),.p11(n350_l05_11),.p12(1'b0),.p13(n351),.p14(n349_l05_14),.p15(n352_l05_15));
 sampled_MC1668 l06(.p3(n388_l06_3),.p4(1'b0),.p5(n60),.p6(n493),.p7(n227),.p9(n228),.p11(n190),.p12(n61),.p13(1'b0),.p14(n388_l06_14),.fixture_load(fixture_load),.fixture_state(fixture_state[272+:2]),.state_q(state_q[272+:2]));
 sampled_MC1668 l07(.p3(n388_l07_3),.p4(1'b0),.p5(n62),.p6(n527),.p7(n229),.p9(n41),.p11(n254),.p12(1'b0),.p13(1'b0),.p15(n368_l07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[270+:2]),.state_q(state_q[270+:2]));
 comb_SE10211 l08(.p2(n61_l08_2),.p3(n60_l08_3),.p4(n229_l08_4),.p5(n366),.p6(n198),.p7(1'b0),.p9(n370),.p10(n198),.p11(n367),.p12(n61_l08_12),.p13(n62_l08_13),.p14(n227_l08_14),.p15(n130),.p16(1'b0));
 comb_SE10211 l09(.p2(n60_l09_2),.p3(n62_l09_3),.p4(n228_l09_4),.p5(n369),.p6(n198),.p7(n367),.p9(n367),.p10(1'b0),.p11(n386),.p12(n254_l09_12),.p15(n131),.p16(1'b0));
 comb_MC1660 l10(.p2(n367_l10_2),.p3(n366_l10_3),.p4(n136),.p5(n382),.p6(n387),.p7(n417),.p8(1'b0),.p10(n63),.p11(1'b0),.p12(1'b0),.p13(n191),.p14(n443_l10_14),.p15(n441_l10_15));
 sampled_MC10231 l11(.p1(1'b0),.p2(n63_l11_2),.p4(1'b0),.p5(1'b0),.p6(n383),.p7(n235),.p8(1'b0),.p9(n30),.p10(n324),.p11(n113),.p12(1'b0),.p13(1'b0),.p14(n325_l11_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[302+:2]),.state_q(state_q[302+:2]));
 comb_MC10113 l12(.p1(1'b0),.p2(n417_l12_2),.p3(n417_l12_3),.p4(n422),.p5(n448),.p6(n447),.p7(n421),.p9(n441),.p10(n446),.p11(n420),.p12(n445),.p13(n419),.p14(n417_l12_14),.p15(n417_l12_15));
 comb_MC10113 l13(.p1(1'b0),.p2(n417_l13_2),.p3(n417_l13_3),.p4(n428),.p5(n452),.p6(n451),.p7(n425),.p9(n441),.p10(n450),.p11(n424),.p12(n449),.p13(n423),.p14(n417_l13_14),.p15(n417_l13_15));
 sampled_MC10176 l14(.p1(n132),.p2(n419_l14_2),.p3(n420_l14_3),.p4(n421_l14_4),.p5(n306),.p6(n291),.p7(n302),.p8(1'b0),.p9(n32),.p10(n305),.p11(n304),.p12(n296),.p13(n422_l14_13),.p14(n423_l14_14),.p15(n424_l14_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[382+:6]),.state_q(state_q[382+:6]));
 sampled_MC10231 l15(.p1(n132),.p2(n428_l15_2),.p3(n429_l15_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n295),.p8(1'b0),.p9(n32),.p10(n294),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n426_l15_14),.p15(n425_l15_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[388+:2]),.state_q(state_q[388+:2]));
 sampled_F10000_gated l16(.p2(n433_l16_2),.p3(n434_l16_3),.p4(n438),.p5(1'b0),.p6(1'b0),.p7(n422),.p9(n421),.p10(n420),.p11(n419),.p12(1'b0),.p13(n39),.p14(n431_l16_14),.p15(n432_l16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[398+:4]),.state_q(state_q[398+:4]));
 comb_MC10182 l17(.p1(1'b0),.p4(n293_l17_4),.p5(n422),.p6(n347),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n347),.p12(n421),.p13(n290),.p14(n292_l17_14),.p16(1'b0));
 sampled_F10000_gated l18(.p2(n440_l18_2),.p3(n437_l18_3),.p4(n438),.p5(1'b0),.p6(1'b0),.p7(n428),.p9(n425),.p10(n424),.p11(n423),.p12(1'b0),.p13(n39),.p14(n435_l18_14),.p15(n436_l18_15),.fixture_load(fixture_load),.fixture_state(fixture_state[402+:4]),.state_q(state_q[402+:4]));
 comb_MC10121 l19(.p2(n284_l19_2),.p3(n285_l19_3),.p4(n349),.p5(n429),.p6(n352),.p7(1'b0),.p9(n426),.p10(n349),.p11(1'b0),.p12(n426),.p13(n352),.p14(n429),.p15(n426));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n390;
 assign clocks[3]=n194;
 assign clocks[4]=n36;
 assign clocks[5]=n58;
 assign clocks[6]=n34;
 assign clocks[7]=n466;
 assign clocks[8]=n32;
 assign clocks[9]=n38;
 assign clocks[10]=l07.p7;
 assign clocks[11]=l07.p9;
 assign clocks[12]=l06.p7;
 assign clocks[13]=l06.p9;
 assign clocks[14]=g10.ca;
 assign clocks[15]=g10.cb;
 assign clocks[16]=h10.ca;
 assign clocks[17]=h10.cb;
 assign clocks[18]=i15.p9;
 assign clocks[19]=k11.p9;
 assign clocks[20]=g08.p9;
 assign clocks[21]=j11.p9;
 assign clocks[22]=l11.ca;
 assign clocks[23]=l11.cb;
 assign clocks[24]=h15.p7;
 assign clocks[25]=g14.p7;
 assign clocks[26]=g15.p13;
 assign clocks[27]=h14.p9;
 assign clocks[28]=l14.p9;
 assign clocks[29]=l15.ca;
 assign clocks[30]=l15.cb;
 assign clocks[31]=i16.p7;
 assign clocks[32]=i17.p7;
 assign clocks[33]=l16.clk;
 assign clocks[34]=l18.clk;
 assign clocks[35]=j19.ca;
 assign clocks[36]=j19.cb;
 assign flags[0]=n384;
 assign flags[1]=n134;
 assign flags[2]=n51;
 assign flags[3]=n207;
 assign flags[4]=n464;
 assign flags[5]=n463;
 assign flags[6]=n334;
 assign flags[7]=n322;
 assign flags[8]=n321;
 assign flags[9]=n35;
 assign flags[10]=l07.state_q[0];
 assign flags[11]=n368;
 assign flags[12]=n388;
 assign flags[13]=n354;
 assign flags[14]=n356;
 assign flags[15]=n358;
 assign flags[16]=n360;
 assign flags[17]=n355;
 assign flags[18]=n357;
 assign flags[19]=n359;
 assign flags[20]=n361;
 assign flags[21]=n362;
 assign flags[22]=n363;
 assign flags[23]=n364;
 assign flags[24]=n365;
 assign flags[25]=n401;
 assign flags[26]=n403;
 assign flags[27]=n405;
 assign flags[28]=n407;
 assign flags[29]=n409;
 assign flags[30]=n411;
 assign flags[31]=n413;
 assign flags[32]=n415;
 assign flags[33]=n402;
 assign flags[34]=n404;
 assign flags[35]=n406;
 assign flags[36]=n408;
 assign flags[37]=n410;
 assign flags[38]=n412;
 assign flags[39]=n414;
 assign flags[40]=n416;
 assign flags[41]=n394;
 assign flags[42]=n396;
 assign flags[43]=n395;
 assign flags[44]=n397;
 assign flags[45]=n366;
 assign flags[46]=n367;
 assign flags[47]=n443;
 assign flags[48]=n441;
 assign flags[49]=n65;
 assign flags[50]=n66;
 assign flags[51]=n67;
 assign flags[52]=n68;
 assign flags[53]=n137;
 assign flags[54]=n282;
 assign flags[55]=n253;
 assign flags[56]=n439;
 assign flags[57]=n312;
 assign flags[58]=n438;
 assign flags[59]=n270;
 assign flags[60]=n273;
 assign flags[61]=n274;
 assign flags[62]=n276;
 assign flags[63]=n261;
 assign flags[64]=n262;
 assign flags[65]=n263;
 assign flags[66]=n264;
 assign flags[67]=n306;
 assign flags[68]=n291;
 assign flags[69]=n302;
 assign flags[70]=n305;
 assign flags[71]=n304;
 assign flags[72]=n296;
 assign flags[73]=n294;
 assign flags[74]=n295;
 assign flags[75]=n387;
 assign flags[76]=n417;
 assign flags[77]=n28;
 assign flags[78]=n284;
 assign flags[79]=n341;
 assign flags[80]=n335;
 assign flags[81]=n336;
 assign flags[82]=n337;
 assign flags[83]=n338;
 assign flags[84]=n43;
 assign flags[85]=n44;
 assign flags[86]=n45;
 assign flags[87]=n46;
 assign flags[88]=n393;
 assign flags[89]=n339;
 assign flags[90]=n258;
 assign flags[91]=n24;
endmodule
`default_nettype wire

`timescale 1ns/1ps
module dorado_r_front_cone(input wire [735:0] state_q,
 input wire base,input wire [235:0] pins,output wire [735:0] sampled_q,
 output wire [56:0] clocks,output wire [8:0] flags,output wire [3:0] next_raw,
 output wire [1:0] write_n,latch_n,output wire [1:0] hold_clocks,t_latch_n,bypass,parity_clocks,output wire [3:0] parity_ok,faults,output wire [1:0] r_read_n,r_visible_n,output wire [3:0] r_flags,output wire [1:0] rm_flags_n,output wire [31:0] address,output wire [3:0] select_n,output wire [1:0] forwarded_bypass,output wire [201:0] source_pins,output wire [7:0] fa_n,output wire [43:0] front_data);
 wire fixture_load=0;
 wire [2:0] bases;
 comb_MC10210 base_fanout(.p7(base),.p11(base),.p5(1'b0),.p6(1'b0),.p9(1'b0),.p10(1'b0),
   .p2(bases[2]),.p12(bases[1]),.p13(bases[0]));
 wire [12:0] cc;wire [14:0] ch;wire [36:0] cl;wire [13:0] fc;wire [26:0] fh;wire [91:0] fl;
 wire en_h=fc[3],en_l=fc[4],start_a=fc[5],priority_n=fc[10];
 wire freeze=fc[13];
 wire rb_forward=fl[45],rb_forward_n=fl[46];
 wire [279:0] sh,ih;wire [407:0] sl,il;
 assign ih[19:0]={state_q[83:80],state_q[47:32]};
 assign il[19:0]={state_q[87:84],state_q[63:48]};
 assign ih[33:20]={state_q[107:100],state_q[93:88]};
 assign il[33:20]={state_q[115:108],state_q[99:94]};
 assign {sampled_q[83:80],sampled_q[47:32]}=sh[19:0];
 assign {sampled_q[87:84],sampled_q[63:48]}=sl[19:0];
 assign {sampled_q[107:100],sampled_q[93:88]}=sh[33:20];
 assign {sampled_q[115:108],sampled_q[99:94]}=sl[33:20];
 assign ih[177:162]={state_q[395:388],state_q[379:372]};
 assign il[177:162]={state_q[403:396],state_q[387:380]};
 assign {sampled_q[395:388],sampled_q[379:372]}=sh[177:162];
 assign {sampled_q[403:396],sampled_q[387:380]}=sl[177:162];
 for(genvar i=0;i<16;i=i+1) begin: map_t_file
   assign ih[34+4*i+:4]=state_q[116+16*i+:4];
   assign ih[98+4*i+:4]=state_q[120+16*i+:4];
   assign il[34+4*i+:4]=state_q[124+16*i+:4];
   assign il[98+4*i+:4]=state_q[128+16*i+:4];
   assign sampled_q[116+16*i+:4]=sh[34+4*i+:4];
   assign sampled_q[120+16*i+:4]=sh[98+4*i+:4];
   assign sampled_q[124+16*i+:4]=sl[34+4*i+:4];
   assign sampled_q[128+16*i+:4]=sl[98+4*i+:4];
 end
 r_front_conta_sampled c(fixture_load,{state_q[79:64],state_q[31:0]},bases[2],1'b0,1'b0,
   pins,next_raw,priority_n,freeze,rb_forward,rb_forward_n,{sampled_q[79:64],sampled_q[31:0]},cc,fc);
 r_front_proch_sampled h(fixture_load,ih,bases[1],start_a,en_h,pins,next_raw,priority_n,freeze,rb_forward,rb_forward_n,sh,ch,fh);
 r_front_procl_sampled l(fixture_load,il,bases[0],start_a,en_l,pins,next_raw,priority_n,freeze,rb_forward,rb_forward_n,sl,cl,fl);
 assign next_raw=fc[9:6];
 assign clocks={cl[36:25],cl[24:14],ch[14],cl[13:12],ch[13:12],cl[11:10],ch[11:10],cl[5],ch[5],cc[12],cc[11:9],cl[4:0],ch[4:0],cc[8:0]};
 assign flags={fl[2:0],fh[2:0],fc[2:0]};
 assign t_latch_n={fl[3],fh[3]};assign bypass={fl[4],fh[4]};
 assign latch_n={cl[6],ch[6]};assign write_n={cl[7],ch[7]};assign hold_clocks={cl[8],ch[8]};
 assign ih[241:178]=state_q[467:404];assign il[241:178]=state_q[531:468];
 assign ih[245:242]=state_q[535:532];assign il[245:242]=state_q[539:536];
 assign sampled_q[467:404]=sh[241:178];assign sampled_q[531:468]=sl[241:178];
 assign sampled_q[535:532]=sh[245:242];assign sampled_q[539:536]=sl[245:242];
 assign parity_clocks={cl[9],ch[9]};
 assign parity_ok={fl[6],fl[5],fh[6],fh[5]};assign faults={fl[8],fl[7],fh[8],fh[7]};
 assign ih[253:246]=state_q[547:540];assign il[253:246]=state_q[555:548];
 assign ih[261:254]=state_q[563:556];assign il[261:254]=state_q[571:564];
 assign ih[269:262]=state_q[579:572];assign il[269:262]=state_q[587:580];
 assign ih[271:270]=state_q[589:588];assign il[271:270]=state_q[591:590];
 assign sampled_q[547:540]=sh[253:246];assign sampled_q[555:548]=sl[253:246];
 assign sampled_q[563:556]=sh[261:254];assign sampled_q[571:564]=sl[261:254];
 assign sampled_q[579:572]=sh[269:262];assign sampled_q[587:580]=sl[269:262];
 assign sampled_q[589:588]=sh[271:270];assign sampled_q[591:590]=sl[271:270];
 assign r_read_n={fl[9],fh[9]};assign r_visible_n={fl[3],fh[3]};
 assign r_flags={fl[11:10],fh[11:10]};
 assign ih[273:272]=state_q[593:592];assign il[273:272]=state_q[595:594];
 assign sampled_q[593:592]=sh[273:272];assign sampled_q[595:594]=sl[273:272];
 assign rm_flags_n={fl[12],fh[12]};

 assign ih[279:274]=state_q[601:596];assign sampled_q[601:596]=sh[279:274];
 assign il[307:274]=state_q[635:602];assign sampled_q[635:602]=sl[307:274];
 assign address[7:0]={fl[13],fl[14],fl[15],fl[16],fh[13],fh[14],fh[15],fh[16]};
 assign address[15:8]={fl[25],fl[26],fl[27],fl[28],fl[29],fl[30],fl[31],fl[32]};
 assign address[23:16]={fl[17],fl[18],fl[19],fl[20],fl[21],fl[22],fl[23],fl[24]};
 assign address[31:24]={fl[33],fl[34],fl[35],fl[36],fl[37],fl[38],fl[39],fl[40]};
 assign select_n={fl[44],fl[43],fl[42],fl[41]};
 assign forwarded_bypass={fl[46],fl[45]};
 assign il[407:308]=state_q[735:636];assign sampled_q[735:636]=sl[407:308];
 assign fa_n={fl[52:49],fh[20:17]};
 assign source_pins[0]=pins[0];
 assign source_pins[1]=pins[1];
 assign source_pins[2]=pins[2];
 assign source_pins[3]=pins[3];
 assign source_pins[4]=pins[4];
 assign source_pins[5]=pins[5];
 assign source_pins[6]=pins[6];
 assign source_pins[7]=pins[7];
 assign source_pins[8]=pins[8];
 assign source_pins[9]=pins[9];
 assign source_pins[10]=pins[10];
 assign source_pins[11]=pins[11];
 assign source_pins[12]=pins[12];
 assign source_pins[13]=pins[13];
 assign source_pins[14]=pins[14];
 assign source_pins[15]=pins[15];
 assign source_pins[16]=pins[16];
 assign source_pins[17]=fh[21];
 assign source_pins[18]=pins[18];
 assign source_pins[19]=pins[19];
 assign source_pins[20]=pins[20];
 assign source_pins[21]=pins[21];
 assign source_pins[22]=pins[22];
 assign source_pins[23]=pins[23];
 assign source_pins[24]=pins[24];
 assign source_pins[25]=pins[25];
 assign source_pins[26]=pins[26];
 assign source_pins[27]=pins[27];
 assign source_pins[28]=pins[28];
 assign source_pins[29]=pins[29];
 assign source_pins[30]=pins[30];
 assign source_pins[31]=pins[31];
 assign source_pins[32]=pins[32];
 assign source_pins[33]=pins[33];
 assign source_pins[34]=pins[34];
 assign source_pins[35]=pins[35];
 assign source_pins[36]=pins[36];
 assign source_pins[37]=pins[37];
 assign source_pins[38]=pins[38];
 assign source_pins[39]=pins[39];
 assign source_pins[40]=pins[40];
 assign source_pins[41]=pins[41];
 assign source_pins[42]=pins[42];
 assign source_pins[43]=pins[43];
 assign source_pins[44]=pins[44];
 assign source_pins[45]=pins[45];
 assign source_pins[46]=pins[46];
 assign source_pins[47]=pins[47];
 assign source_pins[48]=pins[48];
 assign source_pins[49]=pins[49];
 assign source_pins[50]=pins[50];
 assign source_pins[51]=pins[51];
 assign source_pins[52]=pins[52];
 assign source_pins[53]=pins[53];
 assign source_pins[54]=pins[54];
 assign source_pins[55]=pins[55];
 assign source_pins[56]=pins[56];
 assign source_pins[57]=pins[57];
 assign source_pins[58]=pins[58];
 assign source_pins[59]=pins[59];
 assign source_pins[60]=pins[60];
 assign source_pins[61]=pins[61];
 assign source_pins[62]=pins[62];
 assign source_pins[63]=pins[63];
 assign source_pins[64]=pins[64];
 assign source_pins[65]=pins[65];
 assign source_pins[66]=pins[66];
 assign source_pins[67]=pins[67];
 assign source_pins[68]=fl[53];
 assign source_pins[69]=pins[69];
 assign source_pins[70]=pins[70];
 assign source_pins[71]=pins[71];
 assign source_pins[72]=pins[72];
 assign source_pins[73]=pins[73];
 assign source_pins[74]=pins[74];
 assign source_pins[75]=pins[75];
 assign source_pins[76]=pins[76];
 assign source_pins[77]=pins[77];
 assign source_pins[78]=pins[78];
 assign source_pins[79]=pins[79];
 assign source_pins[80]=pins[80];
 assign source_pins[81]=pins[81];
 assign source_pins[82]=pins[82];
 assign source_pins[83]=pins[83];
 assign source_pins[84]=pins[84];
 assign source_pins[85]=pins[85];
 assign source_pins[86]=pins[86];
 assign source_pins[87]=pins[87];
 assign source_pins[88]=pins[88];
 assign source_pins[89]=pins[89];
 assign source_pins[90]=pins[90];
 assign source_pins[91]=pins[91];
 assign source_pins[92]=pins[92];
 assign source_pins[93]=pins[93];
 assign source_pins[94]=pins[94];
 assign source_pins[95]=pins[95];
 assign source_pins[96]=pins[96];
 assign source_pins[97]=pins[97];
 assign source_pins[98]=pins[98];
 assign source_pins[99]=pins[99];
 assign source_pins[100]=pins[100];
 assign source_pins[101]=pins[101];
 assign source_pins[102]=pins[102];
 assign source_pins[103]=pins[103];
 assign source_pins[104]=pins[104];
 assign source_pins[105]=pins[105];
 assign source_pins[106]=pins[106];
 assign source_pins[107]=pins[107];
 assign source_pins[108]=pins[108];
 assign source_pins[109]=fh[22];
 assign source_pins[110]=pins[110];
 assign source_pins[111]=pins[111];
 assign source_pins[112]=pins[112];
 assign source_pins[113]=pins[113];
 assign source_pins[114]=pins[114];
 assign source_pins[115]=fl[54];
 assign source_pins[116]=fl[55];
 assign source_pins[117]=pins[117];
 assign source_pins[118]=pins[118];
 assign source_pins[119]=pins[119];
 assign source_pins[120]=pins[120];
 assign source_pins[121]=pins[121];
 assign source_pins[122]=pins[122];
 assign source_pins[123]=pins[123];
 assign source_pins[124]=pins[124];
 assign source_pins[125]=pins[125];
 assign source_pins[126]=pins[126];
 assign source_pins[127]=pins[127];
 assign source_pins[128]=pins[128];
 assign source_pins[129]=pins[129];
 assign source_pins[130]=pins[130];
 assign source_pins[131]=pins[131];
 assign source_pins[132]=pins[132];
 assign source_pins[133]=pins[133];
 assign source_pins[134]=pins[134];
 assign source_pins[135]=pins[135];
 assign source_pins[136]=pins[136];
 assign source_pins[137]=pins[137];
 assign source_pins[138]=pins[138];
 assign source_pins[139]=pins[139];
 assign source_pins[140]=pins[140];
 assign source_pins[141]=pins[141];
 assign source_pins[142]=pins[142];
 assign source_pins[143]=pins[143];
 assign source_pins[144]=pins[144];
 assign source_pins[145]=pins[145];
 assign source_pins[146]=fl[56];
 assign source_pins[147]=fl[57];
 assign source_pins[148]=pins[148];
 assign source_pins[149]=pins[149];
 assign source_pins[150]=pins[150];
 assign source_pins[151]=pins[151];
 assign source_pins[152]=fh[23];
 assign source_pins[153]=fh[24];
 assign source_pins[154]=fh[25];
 assign source_pins[155]=fh[26];
 assign source_pins[156]=fl[59];
 assign source_pins[157]=fl[60];
 assign source_pins[158]=fl[61];
 assign source_pins[159]=fl[62];
 assign source_pins[160]=fl[63];
 assign source_pins[161]=fl[64];
 assign source_pins[162]=fl[65];
 assign source_pins[163]=fl[66];
 assign source_pins[164]=fl[67];
 assign source_pins[165]=fl[68];
 assign source_pins[166]=fl[69];
 assign source_pins[167]=fl[70];
 assign source_pins[168]=fl[71];
 assign source_pins[169]=fl[72];
 assign source_pins[170]=fl[73];
 assign source_pins[171]=fl[74];
 assign source_pins[172]=pins[172];
 assign source_pins[173]=pins[173];
 assign source_pins[174]=pins[174];
 assign source_pins[175]=pins[175];
 assign source_pins[176]=pins[176];
 assign source_pins[177]=fl[75];
 assign source_pins[178]=fl[76];
 assign source_pins[179]=pins[179];
 assign source_pins[180]=pins[180];
 assign source_pins[181]=pins[181];
 assign source_pins[182]=fl[77];
 assign source_pins[183]=pins[183];
 assign source_pins[184]=fl[78];
 assign source_pins[185]=fl[79];
 assign source_pins[186]=fl[58];
 assign source_pins[187]=pins[187];
 assign source_pins[188]=fl[80];
 assign source_pins[189]=fl[81];
 assign source_pins[190]=fl[82];
 assign source_pins[191]=fl[83];
 assign source_pins[192]=fl[84];
 assign source_pins[193]=fl[85];
 assign source_pins[194]=fl[86];
 assign source_pins[195]=fl[87];
 assign source_pins[196]=fl[88];
 assign source_pins[197]=fl[89];
 assign source_pins[198]=pins[198];
 assign source_pins[199]=pins[199];
 assign source_pins[200]=fl[90];
 assign source_pins[201]=fl[91];
 assign front_data[0+:4]=l.g14.p9 ? {l.g14.p11,l.g14.p13,l.g14.p4,l.g14.p6} : {l.g14.p10,l.g14.p12,l.g14.p3,l.g14.p5};
 assign front_data[4+:4]={l.g15.p12,l.g15.p11,l.g15.p4,l.g15.p5};
 assign front_data[8+:4]={l.g15.p10,l.g15.p9,l.g15.p7,l.g15.p6};
 assign front_data[12+:6]={l.h14.p12,l.h14.p11,l.h14.p10,l.h14.p7,l.h14.p6,l.h14.p5};
 assign front_data[18+:6]={l.l14.p12,l.l14.p11,l.l14.p10,l.l14.p7,l.l14.p6,l.l14.p5};
 assign front_data[24+:2]={l.l15.p10,l.l15.p7};
 assign front_data[26+:4]=l.i16.p9 ? {l.i16.p11,l.i16.p13,l.i16.p4,l.i16.p6} : {l.i16.p10,l.i16.p12,l.i16.p3,l.i16.p5};
 assign front_data[30+:4]=l.i17.p9 ? {l.i17.p11,l.i17.p13,l.i17.p4,l.i17.p6} : {l.i17.p10,l.i17.p12,l.i17.p3,l.i17.p5};
 assign front_data[34+:4]={l.l16.p11,l.l16.p10,l.l16.p9,l.l16.p7};
 assign front_data[38+:4]={l.l18.p11,l.l18.p10,l.l18.p9,l.l18.p7};
 assign front_data[42+:2]={l.j19.p10,l.j19.p7};
endmodule
