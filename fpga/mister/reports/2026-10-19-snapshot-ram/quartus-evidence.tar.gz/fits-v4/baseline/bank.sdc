create_clock -name bank_clock -period 20.000 [get_ports clk]
derive_clock_uncertainty
set_input_delay -clock bank_clock -max 2.000 [remove_from_collection [all_inputs] [get_ports clk]]
set_input_delay -clock bank_clock -min 0.000 [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay -clock bank_clock -max 2.000 [all_outputs]
set_output_delay -clock bank_clock -min 0.000 [all_outputs]
