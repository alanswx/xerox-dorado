module snapshot_fit(
 input wire clk, input wire [9:0] address,
 input wire [33:0] data,input wire ce_n,we_n,
 output wire [33:0] q,
 input wire freeze,request,write,input wire [5:0] slice,
 input wire [10:0] word_index,input wire state_data,
 output wire frozen,done,error,result);
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_bank bank(clk,address,data,ce_n,we_n,q,
   freeze,frozen,request,write,slice,word_index,state_data,done,error,result);
`else
 assign frozen=0;assign done=0;assign error=0;assign result=0;
 genvar i;
 generate for(i=0;i<34;i=i+1)begin: original
   cell_F10415A bit_cell(clk,address[9],address[8],address[7],address[6],
     address[5],address[4],address[3],address[2],address[1],address[0],
     data[i],ce_n,we_n,q[i]);
 end endgenerate
`endif
endmodule
