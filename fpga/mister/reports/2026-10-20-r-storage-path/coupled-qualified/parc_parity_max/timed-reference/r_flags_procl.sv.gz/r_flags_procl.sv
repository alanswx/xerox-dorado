`timescale 1ns/1ps
`default_nettype none
module r_flags_procl(input wire fixture_load,input wire [273:0] fixture_state,
 input wire base,start_a,en,input wire [151:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,
 output wire [273:0] state_q,output wire [13:0] clocks,
 output wire [12:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock0'Bd
 wire n15; // Clock0'Da
 wire n16; // Clock0'Db
 wire n17; // Clock0'Dc
 wire n18; // Clock1'Ba
 wire n19; // Clock1'Bb
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Da
 wire n23; // Clock1'Db
 wire n24; // Clock1'Dc
 wire n25; // Clock1Bd
 wire n26; // Curr.0'
 wire n27; // Curr.1'
 wire n28; // Curr.2'
 wire n29; // Curr.3'
 wire n30; // Curr=Next'
 wire n31; // CurrLast.0'
 wire n32; // CurrLast.1'
 wire n33; // CurrLast.2'
 wire n34; // CurrLast.3'
 wire n35; // DblClock'Ba
 wire n36; // DblClock'Bc
 wire n37; // DsMd
 wire n38; // DsPd
 wire n39; // DsRd
 wire n40; // FA=0'b
 wire n41; // FB=2'
 wire n42; // FB=3'
 wire n43; // FB=7'
 wire n44; // FC=4/5'
 wire n45; // FC=5'
 wire n46; // FC=6'
 wire n47; // FF=030
 wire n48; // GND132
 wire n49; // GND264
 wire n50; // GND266
 wire n51; // GND312
 wire n52; // GND314
 wire n53; // GND394
 wire n54; // GND40
 wire n55; // GND442
 wire n56; // GND468
 wire n57; // GND500
 wire n58; // GND530
 wire n59; // GND544
 wire n60; // GND546
 wire n61; // Hold
 wire n62; // Hold'
 wire n63; // HoldDly
 wire n64; // Holda
 wire n65; // IOB.Perr'
 wire n66; // IOBin'
 wire n67; // IOBout
 wire n68; // IOin'
 wire n69; // IfuData.0
 wire n70; // IfuData.1
 wire n71; // IfuData.2
 wire n72; // IfuData.3
 wire n73; // IfuData.4
 wire n74; // IfuData.5
 wire n75; // IfuData.6
 wire n76; // IfuData.7
 wire n77; // IfuRBaseSel'
 wire n78; // LC.0
 wire n79; // LC.1
 wire n80; // LC.1'a
 wire n81; // LC.1a
 wire n82; // LC.2
 wire n83; // LScopeFH
 wire n84; // Last.0'
 wire n85; // Last.1'
 wire n86; // Last.2'
 wire n87; // Last.3'
 wire n88; // Last=Curr'
 wire n89; // LastNext.0'
 wire n90; // LastNext.1'
 wire n91; // LastNext.2'
 wire n92; // LastNext.3'
 wire n93; // Next.0
 wire n94; // Next.0'
 wire n95; // Next.1
 wire n96; // Next.1'
 wire n97; // Next.2
 wire n98; // Next.2'
 wire n99; // Next.3
 wire n100; // Next.3'
 wire n101; // PRhold
 wire n102; // Pdata.08
 wire n103; // Pdata.09
 wire n104; // Pdata.10
 wire n105; // Pdata.11
 wire n106; // Pdata.12
 wire n107; // Pdata.13
 wire n108; // Pdata.14
 wire n109; // Pdata.15
 wire n110; // PreClock0'A
 wire n111; // PreClock0'B
 wire n112; // PreClock0'C
 wire n113; // PreClock0'D
 wire n114; // PreClock1'A
 wire n115; // PreClock1'B
 wire n116; // PreClock1'C
 wire n117; // PreClock1'D
 wire n118; // PreClock1B
 wire n119; // PreDblClock'B
 wire n120; // PreSHCP'A
 wire n121; // PreSHCP'B
 wire n122; // PreSHCP'C
 wire n123; // PreSHCP'Shc
 wire n124; // PreSHSelect'D
 wire n125; // ProcL02.sil+1
 wire n126; // ProcL02.sil+5
 wire n127; // ProcL03.sil+1
 wire n128; // ProcL03.sil+5
 wire n129; // ProcL04.sil+1
 wire n130; // ProcL04.sil+5
 wire n131; // ProcL05.sil+1
 wire n132; // ProcL05.sil+5
 wire n133; // ProcL06.sil+1
 wire n134; // ProcL06.sil+5
 wire n135; // ProcL07.sil+1
 wire n136; // ProcL07.sil+5
 wire n137; // ProcL08.sil+1
 wire n138; // ProcL08.sil+5
 wire n139; // ProcL09.sil+4
 wire n140; // ProcL10.sil+1
 wire n141; // ProcL10.sil+2
 wire n142; // ProcL10.sil+3
 wire n143; // ProcL10.sil+4
 wire n144; // ProcL11.sil+7
 wire n145; // ProcL12.sil+1
 wire n146; // ProcL12.sil+3
 wire n147; // ProcL12.sil+4
 wire n148; // ProcL12.sil+5
 wire n149; // ProcL12.sil+6
 wire n150; // ProcL15.sil+1
 wire n151; // ProcL20.sil+1
 wire n152; // ProcL20.sil+3
 wire n153; // ProcL20.sil+4
 wire n154; // ProcL20.sil+5
 wire n155; // ProcL20.sil+6
 wire n156; // ProcL20.sil+7
 wire n157; // ProcL20.sil+8
 wire n158; // ProcL23.sil+10
 wire n159; // ProcL24.sil+13
 wire n160; // ProcL24.sil+14
 wire n161; // ProcL26.sil+1
 wire n162; // ProcL26.sil+3
 wire n163; // ProcL27.sil+1
 wire n164; // ProcL27.sil+10
 wire n165; // ProcL27.sil+11
 wire n166; // ProcL27.sil+3
 wire n167; // ProcL27.sil+4
 wire n168; // ProcL27.sil+5
 wire n169; // ProcL27.sil+6
 wire n170; // ProcL27.sil+7
 wire n171; // ProcL27.sil+8
 wire n172; // ProcL27.sil+9
 wire n173; // ProcL30.sil+1
 wire n174; // R.08
 wire n175; // R.09
 wire n176; // R.10
 wire n177; // R.11
 wire n178; // R.12
 wire n179; // R.13
 wire n180; // R.14
 wire n181; // R.15
 wire n182; // R.Perr'
 wire n183; // RbBypass
 wire n184; // RbBypass'
 wire n185; // RbBypassDly
 wire n186; // RbSelMd
 wire n187; // RbSelMd'
 wire n188; // RbWrite'a
 wire n189; // RbWrite'b
 wire n190; // RbWrite'c
 wire n191; // RbWriteEn'
 wire n192; // RepeatCurrB
 wire n193; // RepeatCurrC
 wire n194; // RepeatCurrD
 wire n195; // RisIFdata
 wire n196; // RmOdd'
 wire n197; // Rparity
 wire n198; // SHCP'C
 wire n199; // SHSelect'C
 wire n200; // SHSelect'D
 wire n201; // SimHoldReq'
 wire n202; // StartCycle'a
 wire n203; // StkPSaveEn'
 wire n204; // StkPWriteEn'
 wire n205; // StkWSel'
 wire n206; // T.08
 wire n207; // T.09
 wire n208; // T.10
 wire n209; // T.11
 wire n210; // T.12
 wire n211; // T.13
 wire n212; // T.14
 wire n213; // T.15
 wire n214; // T.Perr'
 wire n215; // TbBypass
 wire n216; // TbSelMd
 wire n217; // TbWrite'a
 wire n218; // TbWrite'b
 wire n219; // TbWriteEn'
 wire n220; // TisIFdata
 wire n221; // Tparity
 wire n222; // TrueA
 wire n223; // _MDSaved
 wire n224; // dMD.08
 wire n225; // dMD.09
 wire n226; // dMD.10
 wire n227; // dMD.11
 wire n228; // dMD.12
 wire n229; // dMD.13
 wire n230; // dMD.14
 wire n231; // dMD.15
 wire n232; // dR.08
 wire n233; // dR.09
 wire n234; // dR.10
 wire n235; // dR.11
 wire n236; // dR.12
 wire n237; // dR.13
 wire n238; // dR.14
 wire n239; // dR.15
 wire n240; // dRm.08
 wire n241; // dRm.09
 wire n242; // dRm.10
 wire n243; // dRm.11
 wire n244; // dRm.12
 wire n245; // dRm.13
 wire n246; // dRm.14
 wire n247; // dRm.15
 wire n248; // dT.08
 wire n249; // dT.09
 wire n250; // dT.10
 wire n251; // dT.11
 wire n252; // dT.12
 wire n253; // dT.13
 wire n254; // dT.14
 wire n255; // dT.15
 wire n256; // dTm.08
 wire n257; // dTm.09
 wire n258; // dTm.10
 wire n259; // dTm.11
 wire n260; // dTm.12
 wire n261; // dTm.13
 wire n262; // dTm.14
 wire n263; // dTm.15
 wire n264; // ddR.15
 wire n265; // pClk1En'
 wire n266; // ppClk'a
 wire n267; // ppClk'b
 wire n268; // ppClk'c
 assign n48=1'b0;
 assign n49=1'b0;
 assign n50=1'b0;
 assign n51=1'b0;
 assign n52=1'b0;
 assign n53=1'b0;
 assign n54=1'b0;
 assign n55=1'b0;
 assign n56=1'b0;
 assign n57=1'b0;
 assign n58=1'b0;
 assign n59=1'b0;
 assign n60=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n40=(pins[19:18]!=2'd0);
 assign n41=(pins[17:15]!=3'd2);
 assign n42=(pins[17:15]!=3'd3);
 assign n43=(pins[17:15]!=3'd7);
 assign n44=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n45=(pins[14:12]!=3'd5);
 assign n46=(pins[14:12]!=3'd6);
 assign n64=pins[68];
 assign n66=1'b0;
 assign n67=1'b0;
 assign n69=pins[119];
 assign n70=pins[120];
 assign n71=pins[121];
 assign n72=pins[122];
 assign n73=pins[123];
 assign n74=pins[124];
 assign n75=pins[125];
 assign n76=pins[126];
 assign n77=1'b1;
 assign n78=pins[11];
 assign n79=pins[10];
 assign n82=pins[9];
 assign n93=next_raw[0];
 assign n95=next_raw[1];
 assign n97=next_raw[2];
 assign n99=next_raw[3];
 assign n101=pins[68];
 assign n102=pins[84];
 assign n103=pins[85];
 assign n104=pins[86];
 assign n105=pins[87];
 assign n106=pins[88];
 assign n107=pins[89];
 assign n108=pins[90];
 assign n109=pins[91];
 assign n125=pins[135];
 assign n127=pins[136];
 assign n129=pins[137];
 assign n131=pins[138];
 assign n133=pins[139];
 assign n135=pins[140];
 assign n137=pins[141];
 assign n156=pins[116];
 assign n160=pins[115];
 assign n161=1'b0;
 assign n162=pins[147];
 assign n163=pins[144];
 assign n164=pins[112];
 assign n165=1'b0;
 assign n183=pins[150];
 assign n184=~pins[150];
 assign n195=pins[151];
 assign n200=1'b0;
 assign n202=start_a;
 assign n203=1'b1;
 assign n204=pins[146];
 assign n220=pins[117];
 assign n224=pins[100];
 assign n225=pins[101];
 assign n226=pins[102];
 assign n227=pins[103];
 assign n228=pins[104];
 assign n229=pins[105];
 assign n230=pins[106];
 assign n231=pins[107];
 assign n264=pins[142];
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_k10_3;
 assign n14=n14_k10_3;
 wire n15_j18_3;
 assign n15=n15_j18_3;
 wire n16_j18_2;
 assign n16=n16_j18_2;
 wire n17_j18_4;
 assign n17=n17_j18_4;
 wire n18_i05_3;
 assign n18=n18_i05_3;
 wire n19_i05_4;
 assign n19=n19_i05_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_j18_13;
 assign n22=n22_j18_13;
 wire n23_j18_14;
 assign n23=n23_j18_14;
 wire n24_j18_12;
 assign n24=n24_j18_12;
 wire n25_i05_2;
 assign n25=n25_i05_2;
 wire n26_a21_14;
 assign n26=n26_a21_14;
 wire n27_a21_15;
 assign n27=n27_a21_15;
 wire n28_a21_2;
 assign n28=n28_a21_2;
 wire n29_a21_3;
 assign n29=n29_a21_3;
 wire n30_a22_2;
 wire n30_a22_3;
 wire n30_a22_15;
 wire n30_a22_14;
 assign n30=n30_a22_2 | n30_a22_3 | n30_a22_15 | n30_a22_14;
 wire n31_i14_14;
 assign n31=n31_i14_14;
 wire n32_i14_15;
 assign n32=n32_i14_15;
 wire n33_i14_2;
 assign n33=n33_i14_2;
 wire n34_i14_3;
 assign n34=n34_i14_3;
 wire n35_k10_13;
 assign n35=n35_k10_13;
 wire n36_k10_14;
 assign n36=n36_k10_14;
 wire n37_l09_2;
 wire n37_l08_3;
 assign n37=n37_l09_2 | n37_l08_3;
 wire n38_l08_12;
 wire n38_l08_2;
 assign n38=n38_l08_12 | n38_l08_2;
 wire n39_l09_3;
 wire n39_l08_13;
 assign n39=n39_l09_3 | n39_l08_13;
 wire n47_g16_3;
 assign n47=n47_g16_3;
 wire n61_f19_15;
 assign n61=n61_f19_15;
 wire n62_f19_14;
 assign n62=n62_f19_14;
 wire n63_g18_15;
 assign n63=n63_g18_15;
 wire n65_g23_14;
 assign n65=n65_g23_14;
 wire n68_g23_9;
 assign n68=n68_g23_9;
 wire n80_h24_15;
 assign n80=n80_h24_15;
 wire n81_h24_9;
 assign n81=n81_h24_9;
 wire n83_c18_14;
 assign n83=n83_c18_14;
 wire n84_a20_14;
 assign n84=n84_a20_14;
 wire n85_a20_15;
 assign n85=n85_a20_15;
 wire n86_a20_2;
 assign n86=n86_a20_2;
 wire n87_a20_3;
 assign n87=n87_a20_3;
 wire n88_d17_15;
 assign n88=n88_d17_15;
 wire n89_a19_1;
 assign n89=n89_a19_1;
 wire n90_a19_2;
 assign n90=n90_a19_2;
 wire n91_a19_15;
 assign n91=n91_a19_15;
 wire n92_a19_14;
 assign n92=n92_a19_14;
 wire n94_a24_15;
 assign n94=n94_a24_15;
 wire n96_a24_14;
 assign n96=n96_a24_14;
 wire n98_a24_3;
 assign n98=n98_a24_3;
 wire n100_a24_2;
 assign n100=n100_a24_2;
 wire n110_f13_13;
 assign n110=n110_f13_13;
 wire n111_f13_12;
 assign n111=n111_f13_12;
 wire n112_f13_14;
 assign n112=n112_f13_14;
 wire n113_g13_3;
 assign n113=n113_g13_3;
 wire n114_f12_14;
 assign n114=n114_f12_14;
 wire n115_f13_2;
 assign n115=n115_f13_2;
 wire n116_f13_4;
 assign n116=n116_f13_4;
 wire n117_f13_3;
 assign n117=n117_f13_3;
 wire n118_f12_13;
 assign n118=n118_f12_13;
 wire n119_g13_13;
 assign n119=n119_g13_13;
 wire n120_g12_3;
 assign n120=n120_g12_3;
 wire n121_g12_2;
 assign n121=n121_g12_2;
 wire n122_g12_4;
 assign n122=n122_g12_4;
 wire n123_f12_4;
 assign n123=n123_f12_4;
 wire n124_f12_3;
 assign n124=n124_f12_3;
 wire n126_l03_2;
 assign n126=n126_l03_2;
 wire n128_l03_1;
 assign n128=n128_l03_1;
 wire n130_l03_15;
 assign n130=n130_l03_15;
 wire n132_l03_14;
 assign n132=n132_l03_14;
 wire n134_l04_2;
 assign n134=n134_l04_2;
 wire n136_l04_1;
 assign n136=n136_l04_1;
 wire n138_l04_15;
 assign n138=n138_l04_15;
 wire n139_l04_14;
 assign n139=n139_l04_14;
 wire n140_f20_2;
 assign n140=n140_f20_2;
 wire n141_l08_14;
 assign n141=n141_l08_14;
 wire n142_l09_4;
 assign n142=n142_l09_4;
 wire n143_l08_4;
 assign n143=n143_l08_4;
 wire n144_f20_3;
 assign n144=n144_f20_3;
 wire n145_a24_9;
 wire n145_a24_11;
 wire n145_a24_6;
 wire n145_a24_5;
 assign n145=n145_a24_9 | n145_a24_11 | n145_a24_6 | n145_a24_5;
 wire n146_a18_2;
 assign n146=n146_a18_2;
 wire n147_a18_1;
 assign n147=n147_a18_1;
 wire n148_a18_15;
 assign n148=n148_a18_15;
 wire n149_a18_14;
 assign n149=n149_a18_14;
 wire n150_f20_14;
 assign n150=n150_f20_14;
 wire n151_f20_15;
 wire n151_g23_3;
 assign n151=n151_f20_15 | n151_g23_3;
 wire n152_h23_2;
 assign n152=n152_h23_2;
 wire n153_h23_3;
 assign n153=n153_h23_3;
 wire n154_h23_14;
 assign n154=n154_h23_14;
 wire n155_g23_2;
 assign n155=n155_g23_2;
 wire n157_l09_12;
 assign n157=n157_l09_12;
 wire n158_i19_3;
 assign n158=n158_i19_3;
 wire n159_g16_2;
 assign n159=n159_g16_2;
 wire n166_g18_3;
 assign n166=n166_g18_3;
 wire n167_g18_4;
 assign n167=n167_g18_4;
 wire n168_g18_2;
 assign n168=n168_g18_2;
 wire n169_i13_2;
 assign n169=n169_i13_2;
 wire n170_k04_2;
 assign n170=n170_k04_2;
 wire n171_i19_2;
 assign n171=n171_i19_2;
 wire n172_i19_15;
 assign n172=n172_i19_15;
 wire n173_f12_2;
 assign n173=n173_f12_2;
 wire n174_g06_1;
 assign n174=n174_g06_1;
 wire n175_g06_2;
 assign n175=n175_g06_2;
 wire n176_g06_15;
 assign n176=n176_g06_15;
 wire n177_g06_14;
 assign n177=n177_g06_14;
 wire n178_g07_1;
 assign n178=n178_g07_1;
 wire n179_g07_2;
 assign n179=n179_g07_2;
 wire n180_g07_15;
 assign n180=n180_g07_15;
 wire n181_g07_14;
 assign n181=n181_g07_14;
 wire n182_c06_2;
 assign n182=n182_c06_2;
 wire n185_l07_15;
 assign n185=n185_l07_15;
 wire n186_d17_3;
 assign n186=n186_d17_3;
 wire n187_d17_2;
 assign n187=n187_d17_2;
 wire n188_j05_13;
 assign n188=n188_j05_13;
 wire n189_j05_12;
 assign n189=n189_j05_12;
 wire n190_j05_14;
 assign n190=n190_j05_14;
 wire n191_d17_13;
 assign n191=n191_d17_13;
 wire n192_g12_13;
 assign n192=n192_g12_13;
 wire n193_g12_12;
 assign n193=n193_g12_12;
 wire n194_g12_14;
 assign n194=n194_g12_14;
 wire n196_l06_3;
 wire n196_l06_14;
 wire n196_l07_3;
 assign n196=n196_l06_3 | n196_l06_14 | n196_l07_3;
 wire n197_g16_14;
 assign n197=n197_g16_14;
 wire n198_c18_13;
 assign n198=n198_c18_13;
 wire n199_c18_12;
 assign n199=n199_c18_12;
 wire n201_a01_3;
 assign n201=n201_a01_3;
 wire n205_g18_13;
 assign n205=n205_g18_13;
 wire n206_i03_1;
 assign n206=n206_i03_1;
 wire n207_i03_2;
 assign n207=n207_i03_2;
 wire n208_i03_15;
 assign n208=n208_i03_15;
 wire n209_i03_14;
 assign n209=n209_i03_14;
 wire n210_i04_1;
 assign n210=n210_i04_1;
 wire n211_i04_2;
 assign n211=n211_i04_2;
 wire n212_i04_15;
 assign n212=n212_i04_15;
 wire n213_i04_14;
 assign n213=n213_i04_14;
 wire n214_d06_2;
 assign n214=n214_d06_2;
 wire n215_f19_3;
 assign n215=n215_f19_3;
 wire n216_d17_4;
 assign n216=n216_d17_4;
 wire n217_j05_3;
 assign n217=n217_j05_3;
 wire n218_j05_2;
 assign n218=n218_j05_2;
 wire n219_d17_14;
 assign n219=n219_d17_14;
 wire n221_g16_15;
 assign n221=n221_g16_15;
 wire n222_a01_14;
 assign n222=n222_a01_14;
 wire n223_g18_14;
 assign n223=n223_g18_14;
 wire n232_g05_1;
 assign n232=n232_g05_1;
 wire n233_g05_2;
 assign n233=n233_g05_2;
 wire n234_g05_15;
 assign n234=n234_g05_15;
 wire n235_g05_14;
 assign n235=n235_g05_14;
 wire n236_h05_1;
 assign n236=n236_h05_1;
 wire n237_h05_2;
 assign n237=n237_h05_2;
 wire n238_h05_15;
 assign n238=n238_h05_15;
 wire n239_h05_14;
 assign n239=n239_h05_14;
 wire n240_j01_1;
 assign n240=n240_j01_1;
 wire n241_j01_2;
 assign n241=n241_j01_2;
 wire n242_j01_15;
 assign n242=n242_j01_15;
 wire n243_j01_14;
 assign n243=n243_j01_14;
 wire n244_j02_1;
 assign n244=n244_j02_1;
 wire n245_j02_2;
 assign n245=n245_j02_2;
 wire n246_j02_15;
 assign n246=n246_j02_15;
 wire n247_j02_14;
 assign n247=n247_j02_14;
 wire n248_j03_1;
 assign n248=n248_j03_1;
 wire n249_j03_2;
 assign n249=n249_j03_2;
 wire n250_j03_15;
 assign n250=n250_j03_15;
 wire n251_j03_14;
 assign n251=n251_j03_14;
 wire n252_j04_1;
 assign n252=n252_j04_1;
 wire n253_j04_2;
 assign n253=n253_j04_2;
 wire n254_j04_15;
 assign n254=n254_j04_15;
 wire n255_j04_14;
 assign n255=n255_j04_14;
 wire n256_k01_1;
 assign n256=n256_k01_1;
 wire n257_k01_2;
 assign n257=n257_k01_2;
 wire n258_k01_15;
 assign n258=n258_k01_15;
 wire n259_k01_14;
 assign n259=n259_k01_14;
 wire n260_k02_1;
 assign n260=n260_k02_1;
 wire n261_k02_2;
 assign n261=n261_k02_2;
 wire n262_k02_15;
 assign n262=n262_k02_15;
 wire n263_k02_14;
 assign n263=n263_k02_14;
 wire n265_l02_2;
 assign n265=n265_l02_2;
 wire n266_l01_13;
 assign n266=n266_l01_13;
 wire n267_l01_12;
 assign n267=n267_l01_12;
 wire n268_l01_14;
 assign n268=n268_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n201_a01_3),.p4(n1),.p5(1'b0),.p6(n161),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n222_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n147_a18_1),.p2(n146_a18_2),.p3(n90),.p4(n27),.p5(n89),.p6(n26),.p9(n193),.p10(n92),.p11(n29),.p12(n91),.p13(n28),.p14(n149_a18_14),.p15(n148_a18_15));
 cell_MC10158 a19(.p1(n89_a19_1),.p2(n90_a19_2),.p3(n96),.p4(n85),.p5(n94),.p6(n84),.p9(n122),.p10(n100),.p11(n87),.p12(n98),.p13(n86),.p14(n92_a19_14),.p15(n91_a19_15));
 original_MC10141 a20(.p1(n54),.p2(n86_a20_2),.p3(n87_a20_3),.p4(n20),.p5(1'b0),.p6(n29),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n26),.p13(1'b0),.p14(n84_a20_14),.p15(n85_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n28_a21_2),.p3(n29_a21_3),.p4(n198),.p5(1'b0),.p6(n100),.p7(n193),.p8(1'b0),.p9(n98),.p10(n193),.p11(n96),.p12(n94),.p13(1'b0),.p14(n26_a21_14),.p15(n27_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n30_a22_2),.p3(n30_a22_3),.p4(n29),.p5(n100),.p6(n98),.p7(n28),.p9(1'b0),.p10(n96),.p11(n27),.p12(n94),.p13(n26),.p14(n30_a22_14),.p15(n30_a22_15));
 cell_MC10101 a24(.p2(n100_a24_2),.p3(n98_a24_3),.p4(n99),.p5(n145_a24_5),.p6(n145_a24_6),.p7(n97),.p9(n145_a24_9),.p10(n95),.p11(n145_a24_11),.p12(1'b0),.p13(n93),.p14(n96_a24_14),.p15(n94_a24_15));
 cell_MC10170 c06(.p1(1'b0),.p2(n182_c06_2),.p3(n197),.p4(n181),.p5(n180),.p6(n179),.p7(n178),.p8(1'b0),.p9(n177),.p10(n176),.p11(n175),.p12(n174),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p5(n116),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n122),.p10(1'b0),.p11(1'b0),.p12(n199_c18_12),.p13(n198_c18_13),.p14(n83_c18_14),.p15(n48),.p16(1'b0));
 cell_MC10170 d06(.p1(1'b0),.p2(n214_d06_2),.p3(n221),.p4(n213),.p5(n212),.p6(n211),.p7(n210),.p8(1'b0),.p9(n209),.p10(n208),.p11(n207),.p12(n206),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n187_d17_2),.p3(n186_d17_3),.p4(n216_d17_4),.p5(n81),.p6(n80),.p7(n151),.p8(1'b0),.p9(n198),.p10(n154),.p11(n155),.p12(n30),.p13(n191_d17_13),.p14(n219_d17_14),.p15(n88_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n173_f12_2),.p3(n124_f12_3),.p4(n123_f12_4),.p5(n265),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n173),.p10(1'b0),.p11(n266),.p13(n118_f12_13),.p14(n114_f12_14),.p15(n49),.p16(1'b0));
 cell_SE10210 f13(.p2(n115_f13_2),.p3(n117_f13_3),.p4(n116_f13_4),.p5(n267),.p6(1'b0),.p7(n173),.p8(1'b0),.p9(n267),.p10(n13),.p11(1'b0),.p12(n111_f13_12),.p13(n110_f13_13),.p14(n112_f13_14),.p15(n50),.p16(1'b0));
 cell_MC1660 f19(.p3(n215_f19_3),.p4(n63),.p5(n88),.p6(n219),.p7(n220),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n101),.p14(n62_f19_14),.p15(n61_f19_15));
 cell_MC10100 f20(.p2(n140_f20_2),.p3(n144_f20_3),.p4(n46),.p5(n41),.p6(n44),.p7(n41),.p9(n40),.p10(n46),.p11(n42),.p12(n45),.p13(n43),.p14(n150_f20_14),.p15(n151_f20_15));
 original_MC10173 g05(.p1(n232_g05_1),.p2(n233_g05_2),.p3(n127),.p4(n70),.p5(n125),.p6(n69),.p7(n19),.p9(n195),.p10(n131),.p11(n72),.p12(n129),.p13(n71),.p14(n235_g05_14),.p15(n234_g05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[254+:4]),.state_q(state_q[254+:4]));
 original_MC10173 g06(.p1(n174_g06_1),.p2(n175_g06_2),.p3(n233),.p4(n241),.p5(n232),.p6(n240),.p7(n121),.p9(n185),.p10(n235),.p11(n243),.p12(n234),.p13(n242),.p14(n177_g06_14),.p15(n176_g06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[262+:4]),.state_q(state_q[262+:4]));
 original_MC10173 g07(.p1(n178_g07_1),.p2(n179_g07_2),.p3(n237),.p4(n245),.p5(n236),.p6(n244),.p7(n121),.p9(n185),.p10(n239),.p11(n247),.p12(n238),.p13(n246),.p14(n181_g07_14),.p15(n180_g07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[266+:4]),.state_q(state_q[266+:4]));
 cell_SE10211 g12(.p2(n121_g12_2),.p3(n120_g12_3),.p4(n122_g12_4),.p5(1'b0),.p6(n265),.p7(1'b0),.p9(n0),.p10(n62),.p11(1'b0),.p12(n193_g12_12),.p13(n192_g12_13),.p14(n194_g12_14),.p15(n51),.p16(1'b0));
 cell_SE10210 g13(.p3(n113_g13_3),.p5(n268),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n268),.p10(1'b0),.p11(1'b0),.p13(n119_g13_13),.p15(n52),.p16(1'b0));
 original_F10000 g16(.p2(n159_g16_2),.p3(n47_g16_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n162),.p9(n204),.p10(n169),.p11(n163),.p12(1'b0),.p13(n22),.p14(n197_g16_14),.p15(n221_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 original_MC10176 g18(.p1(1'b0),.p2(n168_g18_2),.p3(n166_g18_3),.p4(n167_g18_4),.p5(n164),.p6(n171),.p7(n172),.p8(1'b0),.p9(n16),.p10(n160),.p11(n156),.p12(n64),.p13(n205_g18_13),.p14(n223_g18_14),.p15(n63_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10102 g23(.p1(1'b0),.p2(n155_g23_2),.p3(n151_g23_3),.p4(n82),.p5(n153),.p6(n78),.p7(n80),.p9(n68_g23_9),.p10(n67),.p11(n165),.p12(n61),.p13(n66),.p14(n65_g23_14),.p16(1'b0));
 original_MC10173 h05(.p1(n236_h05_1),.p2(n237_h05_2),.p3(n135),.p4(n74),.p5(n133),.p6(n73),.p7(n19),.p9(n195),.p10(n264),.p11(n76),.p12(n137),.p13(n75),.p14(n239_h05_14),.p15(n238_h05_15),.fixture_load(fixture_load),.fixture_state(fixture_state[258+:4]),.state_q(state_q[258+:4]));
 cell_MC10102 h23(.p1(1'b0),.p2(n152_h23_2),.p3(n153_h23_3),.p4(n80),.p5(n82),.p6(n78),.p7(n80),.p9(n10_h23_9),.p10(n78),.p11(n152),.p12(n6),.p13(n9),.p14(n154_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n81_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n79),.p14(n9_h24_14),.p15(n80_h24_15));
 original_MC10173 i03(.p1(n206_i03_1),.p2(n207_i03_2),.p3(n249),.p4(n257),.p5(n248),.p6(n256),.p7(n121),.p9(n215),.p10(n251),.p11(n259),.p12(n250),.p13(n258),.p14(n209_i03_14),.p15(n208_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 original_MC10173 i04(.p1(n210_i04_1),.p2(n211_i04_2),.p3(n253),.p4(n261),.p5(n252),.p6(n260),.p7(n121),.p9(n215),.p10(n255),.p11(n263),.p12(n254),.p13(n262),.p14(n213_i04_14),.p15(n212_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 cell_SE10212 i05(.p1(1'b0),.p2(n25_i05_2),.p3(n18_i05_3),.p4(n19_i05_4),.p5(1'b0),.p6(1'b0),.p7(n118),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n53),.p16(1'b0));
 original_F10145A i13(.p2(n169_i13_2),.p3(1'b0),.p4(1'b0),.p5(n170),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(1'b0),.p12(1'b0),.p13(n218),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 original_MC10141 i14(.p1(1'b0),.p2(n33_i14_2),.p3(n34_i14_3),.p4(n36),.p5(1'b0),.p6(n149),.p7(1'b0),.p8(1'b0),.p9(n148),.p10(1'b0),.p11(n146),.p12(n147),.p13(1'b0),.p14(n31_i14_14),.p15(n32_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_MC10106 i19(.p2(n171_i19_2),.p3(n158_i19_3),.p4(n30),.p5(n203),.p6(n200),.p7(n77),.p9(n185),.p10(n195),.p11(n182),.p12(n215),.p13(n220),.p14(n214),.p15(n172_i19_15));
 original_MC10173 j01(.p1(n240_j01_1),.p2(n241_j01_2),.p3(n103),.p4(n225),.p5(n102),.p6(n224),.p7(n18),.p9(n186),.p10(n105),.p11(n227),.p12(n104),.p13(n226),.p14(n243_j01_14),.p15(n242_j01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[246+:4]),.state_q(state_q[246+:4]));
 original_MC10173 j02(.p1(n244_j02_1),.p2(n245_j02_2),.p3(n107),.p4(n229),.p5(n106),.p6(n228),.p7(n19),.p9(n186),.p10(n109),.p11(n231),.p12(n108),.p13(n230),.p14(n247_j02_14),.p15(n246_j02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[250+:4]),.state_q(state_q[250+:4]));
 original_MC10173 j03(.p1(n248_j03_1),.p2(n249_j03_2),.p3(n128),.p4(n70),.p5(n126),.p6(n69),.p7(n19),.p9(n220),.p10(n132),.p11(n72),.p12(n130),.p13(n71),.p14(n251_j03_14),.p15(n250_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 original_MC10173 j04(.p1(n252_j04_1),.p2(n253_j04_2),.p3(n136),.p4(n74),.p5(n134),.p6(n73),.p7(n19),.p9(n220),.p10(n139),.p11(n76),.p12(n138),.p13(n75),.p14(n255_j04_14),.p15(n254_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 cell_SE10210 j05(.p2(n218_j05_2),.p3(n217_j05_3),.p5(n111),.p6(n63),.p7(n219),.p8(1'b0),.p9(n111),.p10(n63),.p11(n191),.p12(n189_j05_12),.p13(n188_j05_13),.p14(n190_j05_14),.p15(n55),.p16(1'b0));
 cell_SE10210 j18(.p2(n16_j18_2),.p3(n15_j18_3),.p4(n17_j18_4),.p5(n113),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n117),.p10(1'b0),.p11(1'b0),.p12(n24_j18_12),.p13(n22_j18_13),.p14(n23_j18_14),.p15(n56),.p16(1'b0));
 original_MC10173 k01(.p1(n256_k01_1),.p2(n257_k01_2),.p3(n103),.p4(n225),.p5(n102),.p6(n224),.p7(n18),.p9(n216),.p10(n105),.p11(n227),.p12(n104),.p13(n226),.p14(n259_k01_14),.p15(n258_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n260_k02_1),.p2(n261_k02_2),.p3(n107),.p4(n229),.p5(n106),.p6(n228),.p7(n18),.p9(n216),.p10(n109),.p11(n231),.p12(n108),.p13(n230),.p14(n263_k02_14),.p15(n262_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_MC10170 k04(.p1(1'b0),.p2(n170_k04_2),.p3(n222),.p4(n263),.p5(n262),.p6(n261),.p7(n260),.p8(1'b0),.p9(n259),.p10(n258),.p11(n257),.p12(n256),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 k10(.p3(n14_k10_3),.p5(n111),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n119),.p13(n35_k10_13),.p14(n36_k10_14),.p15(n57),.p16(1'b0));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n202),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n267_l01_12),.p13(n266_l01_13),.p14(n268_l01_14),.p15(n58),.p16(1'b0));
 original_SE10231 l02(.p2(n265_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n128_l03_1),.p2(n126_l03_2),.p3(1'b0),.p4(n257),.p5(n256),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n258),.p12(n259),.p13(n217),.p14(n132_l03_14),.p15(n130_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n136_l04_1),.p2(n134_l04_2),.p3(1'b0),.p4(n261),.p5(n260),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n262),.p12(n263),.p13(n217),.p14(n139_l04_14),.p15(n138_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 original_MC1668 l06(.p3(n196_l06_3),.p4(1'b0),.p5(n37),.p6(n231),.p7(n141),.p9(n142),.p11(n109),.p12(n38),.p13(1'b0),.p14(n196_l06_14),.fixture_load(fixture_load),.fixture_state(fixture_state[272+:2]),.state_q(state_q[272+:2]));
 original_MC1668 l07(.p3(n196_l07_3),.p4(1'b0),.p5(n39),.p6(n264),.p7(n143),.p9(n25),.p11(n157),.p12(1'b0),.p13(1'b0),.p15(n185_l07_15),.fixture_load(fixture_load),.fixture_state(fixture_state[270+:2]),.state_q(state_q[270+:2]));
 cell_SE10211 l08(.p2(n38_l08_2),.p3(n37_l08_3),.p4(n143_l08_4),.p5(n183),.p6(n115),.p7(1'b0),.p9(n187),.p10(n115),.p11(n184),.p12(n38_l08_12),.p13(n39_l08_13),.p14(n141_l08_14),.p15(n59),.p16(1'b0));
 cell_SE10211 l09(.p2(n37_l09_2),.p3(n39_l09_3),.p4(n142_l09_4),.p5(n186),.p6(n115),.p7(n184),.p9(n184),.p10(1'b0),.p11(n195),.p12(n157_l09_12),.p15(n60),.p16(1'b0));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n198;
 assign clocks[3]=n111;
 assign clocks[4]=n20;
 assign clocks[5]=n36;
 assign clocks[6]=n18;
 assign clocks[7]=n217;
 assign clocks[8]=n16;
 assign clocks[9]=n22;
 assign clocks[10]=l07.p7;
 assign clocks[11]=l07.p9;
 assign clocks[12]=l06.p7;
 assign clocks[13]=l06.p9;
 assign flags[0]=n193;
 assign flags[1]=n61;
 assign flags[2]=n30;
 assign flags[3]=n121;
 assign flags[4]=n215;
 assign flags[5]=n214;
 assign flags[6]=n182;
 assign flags[7]=n172;
 assign flags[8]=n171;
 assign flags[9]=n19;
 assign flags[10]=l07.state_q[0];
 assign flags[11]=n185;
 assign flags[12]=n196;
endmodule
`default_nettype wire
