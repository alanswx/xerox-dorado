module clock_fit(input wire host_clk,input wire [938:0] pins,
 output reg [708:0] result);
 // Fixture input staging avoids treating a virtual package pin as the
 // evaluator's launch register. The evaluator still has a full 15ns path
 // from launch to result; the new staging path has a stricter half period.
 reg [938:0] input_stage;
 reg [938:0] launch;
 always @(negedge host_clk) input_stage<=pins;
 always @(posedge host_clk) launch<=input_stage;
 wire [595:0] q,next_q;
 wire before_clock,after_clock;
 wire [151:0] before_controls,after_controls;
 wire [32:0] events,repeated;
 wire [1:0] write_n,latch_n,t_latch_n,bypass;
 wire [3:0] parity_ok,faults,r_flags;
 wire [1:0] r_read_n,r_visible_n;wire [1:0] rm_flags_n;wire advance;wire [31:0] address;wire [3:0] select_n;wire [1:0] r_write_n,file_read_parity;wire [15:0] file_read_data;
 wire unsettled;
 assign {q,before_clock,after_clock,before_controls,after_controls,address,select_n,advance}=launch;
 dorado_r_storage_step evaluator(host_clk,advance,q,before_clock,after_clock,
   before_controls,after_controls,address,select_n,next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,r_write_n,file_read_data,file_read_parity);
 always @(posedge host_clk) result<={next_q,events,repeated,unsettled,write_n,latch_n,t_latch_n,bypass,parity_ok,faults,r_read_n,r_visible_n,r_flags,rm_flags_n,r_write_n,file_read_data,file_read_parity};
endmodule
