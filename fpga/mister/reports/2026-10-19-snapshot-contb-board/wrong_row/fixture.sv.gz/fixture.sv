module contb_snapshot_fixture(
 input wire host_clk,run,
 input wire [101:0] stimulus,
 input wire freeze,held,request,write,
 input wire [13:0] state_index,input wire [17:0] state_data,
 output wire frozen,done,error,output wire [17:0] result,
 output wire [70:0] original_outputs,candidate_outputs,
 output wire advance,
 output wire [79:0] addresses,
 output wire [143:0] data_bits,original_raw,candidate_raw,
 output wire [7:0] ce_n,we_n);
 // Logical altclkctrl falling-edge enable behavior. Analog insertion/skew
 // remains a separate routed whole-core timing requirement.
 reg enabled=0;
 always @(negedge host_clk) enabled <= run;
 wire guest_clk=host_clk & enabled;
 assign advance=enabled;
 wire original_ALUF_0__drv;
 wire original_ALUF_1__drv;
 wire original_ALUF_2__drv;
 wire original_ALUF_3__drv;
 wire original_ASEL_0__drv;
 wire original_ASEL_0_p___drv;
 wire original_ASEL_0_p_a__drv;
 wire original_ASEL_0_p_mem__drv;
 wire original_ASEL_1_p___drv;
 wire original_ASEL_2_p___drv;
 wire original_BNPC_04__drv;
 wire original_BNPC_05__drv;
 wire original_BNPC_06__drv;
 wire original_BNPC_07__drv;
 wire original_BNPC_08__drv;
 wire original_BNPC_09__drv;
 wire original_BNPC_10__drv;
 wire original_BNPC_11__drv;
 wire original_BNPC_12__drv;
 wire original_BNPC_13__drv;
 wire original_BNPC_14__drv;
 wire original_BNPC_15__drv;
 wire original_BSEL_0_p___drv;
 wire original_BSEL_1_p___drv;
 wire original_BSEL_2_p___drv;
 wire original_CBTempSense__drv;
 wire original_CPIn_0__drv;
 wire original_CPIn_1__drv;
 wire original_CPIn_2__drv;
 wire original_CPIn_3__drv;
 wire original_DMuxData__drv;
 wire original_Error_p___drv;
 wire original_IMLHPE_p___drv;
 wire original_IMLHPEDly__drv;
 wire original_IMRHPEDly__drv;
 wire original_LC_0__drv;
 wire original_LC_1__drv;
 wire original_LC_2__drv;
 wire original_RSTK_0__drv;
 wire original_RSTK_1__drv;
 wire original_RSTK_2__drv;
 wire original_RSTK_3__drv;
 wire original_StopMIRClk__drv;
 wire original_dBlock_p___drv;
 wire original_dFF_0__drv;
 wire original_dFF_1__drv;
 wire original_dFF_2__drv;
 wire original_dFF_3__drv;
 wire original_dFF_4__drv;
 wire original_dFF_5__drv;
 wire original_dFF_6__drv;
 wire original_dFF_7__drv;
 wire original_dIMOut_07__drv;
 wire original_dIMOut_08__drv;
 wire original_dIMOut_09__drv;
 wire original_dIMOut_10__drv;
 wire original_dIMOut_11__drv;
 wire original_dIMOut_12__drv;
 wire original_dIMOut_13__drv;
 wire original_dIMOut_14__drv;
 wire original_dIMOut_15__drv;
 wire original_dIMRH__drv;
 wire original_dJCN_0__drv;
 wire original_dJCN_1__drv;
 wire original_dJCN_2__drv;
 wire original_dJCN_3__drv;
 wire original_dJCN_4__drv;
 wire original_dJCN_5__drv;
 wire original_dJCN_6__drv;
 wire original_dJCN_7__drv;
 wire original_rMIRa__drv;
 ContB_m_Rev_m_Cd #(.SYSPER(4)) original (
  .sys_clk(guest_clk),
  .ALUF_0(stimulus[0] | original_ALUF_0__drv),
  .ALUF_1(stimulus[1] | original_ALUF_1__drv),
  .ALUF_2(stimulus[2] | original_ALUF_2__drv),
  .ALUF_3(stimulus[3] | original_ALUF_3__drv),
  .BMux_00(stimulus[4]),
  .BMux_01(stimulus[5]),
  .BMux_02(stimulus[6]),
  .BMux_03(stimulus[7]),
  .BMux_04(stimulus[8]),
  .BMux_05(stimulus[9]),
  .BMux_06(stimulus[10]),
  .BMux_07(stimulus[11]),
  .BMux_08(stimulus[12]),
  .BMux_09(stimulus[13]),
  .BMux_10(stimulus[14]),
  .BMux_11(stimulus[15]),
  .BMux_12(stimulus[16]),
  .BMux_13(stimulus[17]),
  .BMux_14(stimulus[18]),
  .BMux_15(stimulus[19]),
  .BMux_16(stimulus[20]),
  .BMux_17(stimulus[21]),
  .BNPC_02(stimulus[22]),
  .BNPC_03(stimulus[23]),
  .BNPC_04(stimulus[24] | original_BNPC_04__drv),
  .BNPC_05(stimulus[25] | original_BNPC_05__drv),
  .BNPC_06(stimulus[26] | original_BNPC_06__drv),
  .BNPC_07(stimulus[27] | original_BNPC_07__drv),
  .BNPC_08(stimulus[28] | original_BNPC_08__drv),
  .BNPC_09(stimulus[29] | original_BNPC_09__drv),
  .BNPC_10(stimulus[30] | original_BNPC_10__drv),
  .BNPC_11(stimulus[31] | original_BNPC_11__drv),
  .BNPC_12(stimulus[32] | original_BNPC_12__drv),
  .BNPC_13(stimulus[33] | original_BNPC_13__drv),
  .BNPC_14(stimulus[34] | original_BNPC_14__drv),
  .BNPC_15(stimulus[35] | original_BNPC_15__drv),
  .BNTGtCT_p_a(stimulus[36]),
  .CBHold(stimulus[37]),
  .CBTempSense(stimulus[38] | original_CBTempSense__drv),
  .CLK_cb_p_(stimulus[39]),
  .CLKEnable_p_a(stimulus[40]),
  .CPAddr_0_p_(stimulus[41]),
  .CPAddr_1_p_(stimulus[42]),
  .CPAddr_2_p_(stimulus[43]),
  .CPOut_0(stimulus[44]),
  .CPOut_1(stimulus[45]),
  .CPOut_2(stimulus[46]),
  .CPOut_3(stimulus[47]),
  .CPOut_8(stimulus[48]),
  .CPStrb_p_(stimulus[49]),
  .CRamClock(stimulus[50]),
  .DMuxClk(stimulus[51]),
  .DMuxData(stimulus[52] | original_DMuxData__drv),
  .DoCBr(stimulus[53]),
  .IMLHPE_p_(stimulus[54] | original_IMLHPE_p___drv),
  .IMLHPEDly(stimulus[55] | original_IMLHPEDly__drv),
  .IMRHPE_p_(stimulus[56]),
  .IMRHPEDly(stimulus[57] | original_IMRHPEDly__drv),
  .IOPE(stimulus[58]),
  .LC_0(stimulus[59] | original_LC_0__drv),
  .LC_1(stimulus[60] | original_LC_1__drv),
  .LC_2(stimulus[61] | original_LC_2__drv),
  .MdPE(stimulus[62]),
  .MemPE(stimulus[63]),
  .RamPE(stimulus[64]),
  .SW(stimulus[65]),
  .StartCycle_p_a(stimulus[66]),
  .TNIA_02(stimulus[67]),
  .TNIA_03(stimulus[68]),
  .TNIA_04(stimulus[69]),
  .TNIA_05(stimulus[70]),
  .TNIA_06(stimulus[71]),
  .TNIA_07(stimulus[72]),
  .TNIA_08(stimulus[73]),
  .TNIA_09(stimulus[74]),
  .TNIA_10(stimulus[75]),
  .TNIA_11(stimulus[76]),
  .TNIA_12(stimulus[77]),
  .TNIA_13(stimulus[78]),
  .TNIA_14(stimulus[79]),
  .TNIA_15(stimulus[80]),
  .TempRef(stimulus[81]),
  .UseDMD(stimulus[82]),
  .dBlock_p_(stimulus[83] | original_dBlock_p___drv),
  .dFF_0(stimulus[84] | original_dFF_0__drv),
  .dFF_1(stimulus[85] | original_dFF_1__drv),
  .dFF_2(stimulus[86] | original_dFF_2__drv),
  .dFF_3(stimulus[87] | original_dFF_3__drv),
  .dFF_4(stimulus[88] | original_dFF_4__drv),
  .dFF_5(stimulus[89] | original_dFF_5__drv),
  .dFF_6(stimulus[90] | original_dFF_6__drv),
  .dFF_7(stimulus[91] | original_dFF_7__drv),
  .dIMRH(stimulus[92] | original_dIMRH__drv),
  .dJCN_0(stimulus[93] | original_dJCN_0__drv),
  .dJCN_1(stimulus[94] | original_dJCN_1__drv),
  .dJCN_2(stimulus[95] | original_dJCN_2__drv),
  .dJCN_3(stimulus[96] | original_dJCN_3__drv),
  .dJCN_4(stimulus[97] | original_dJCN_4__drv),
  .dJCN_5(stimulus[98] | original_dJCN_5__drv),
  .dJCN_6(stimulus[99] | original_dJCN_6__drv),
  .dJCN_7(stimulus[100] | original_dJCN_7__drv),
  .rMIRa(stimulus[101] | original_rMIRa__drv),
  .ALUF_0__drv(original_ALUF_0__drv),
  .ALUF_1__drv(original_ALUF_1__drv),
  .ALUF_2__drv(original_ALUF_2__drv),
  .ALUF_3__drv(original_ALUF_3__drv),
  .ASEL_0__drv(original_ASEL_0__drv),
  .ASEL_0_p___drv(original_ASEL_0_p___drv),
  .ASEL_0_p_a__drv(original_ASEL_0_p_a__drv),
  .ASEL_0_p_mem__drv(original_ASEL_0_p_mem__drv),
  .ASEL_1_p___drv(original_ASEL_1_p___drv),
  .ASEL_2_p___drv(original_ASEL_2_p___drv),
  .BNPC_04__drv(original_BNPC_04__drv),
  .BNPC_05__drv(original_BNPC_05__drv),
  .BNPC_06__drv(original_BNPC_06__drv),
  .BNPC_07__drv(original_BNPC_07__drv),
  .BNPC_08__drv(original_BNPC_08__drv),
  .BNPC_09__drv(original_BNPC_09__drv),
  .BNPC_10__drv(original_BNPC_10__drv),
  .BNPC_11__drv(original_BNPC_11__drv),
  .BNPC_12__drv(original_BNPC_12__drv),
  .BNPC_13__drv(original_BNPC_13__drv),
  .BNPC_14__drv(original_BNPC_14__drv),
  .BNPC_15__drv(original_BNPC_15__drv),
  .BSEL_0_p___drv(original_BSEL_0_p___drv),
  .BSEL_1_p___drv(original_BSEL_1_p___drv),
  .BSEL_2_p___drv(original_BSEL_2_p___drv),
  .CBTempSense__drv(original_CBTempSense__drv),
  .CPIn_0__drv(original_CPIn_0__drv),
  .CPIn_1__drv(original_CPIn_1__drv),
  .CPIn_2__drv(original_CPIn_2__drv),
  .CPIn_3__drv(original_CPIn_3__drv),
  .DMuxData__drv(original_DMuxData__drv),
  .Error_p___drv(original_Error_p___drv),
  .IMLHPE_p___drv(original_IMLHPE_p___drv),
  .IMLHPEDly__drv(original_IMLHPEDly__drv),
  .IMRHPEDly__drv(original_IMRHPEDly__drv),
  .LC_0__drv(original_LC_0__drv),
  .LC_1__drv(original_LC_1__drv),
  .LC_2__drv(original_LC_2__drv),
  .RSTK_0__drv(original_RSTK_0__drv),
  .RSTK_1__drv(original_RSTK_1__drv),
  .RSTK_2__drv(original_RSTK_2__drv),
  .RSTK_3__drv(original_RSTK_3__drv),
  .StopMIRClk__drv(original_StopMIRClk__drv),
  .dBlock_p___drv(original_dBlock_p___drv),
  .dFF_0__drv(original_dFF_0__drv),
  .dFF_1__drv(original_dFF_1__drv),
  .dFF_2__drv(original_dFF_2__drv),
  .dFF_3__drv(original_dFF_3__drv),
  .dFF_4__drv(original_dFF_4__drv),
  .dFF_5__drv(original_dFF_5__drv),
  .dFF_6__drv(original_dFF_6__drv),
  .dFF_7__drv(original_dFF_7__drv),
  .dIMOut_07__drv(original_dIMOut_07__drv),
  .dIMOut_08__drv(original_dIMOut_08__drv),
  .dIMOut_09__drv(original_dIMOut_09__drv),
  .dIMOut_10__drv(original_dIMOut_10__drv),
  .dIMOut_11__drv(original_dIMOut_11__drv),
  .dIMOut_12__drv(original_dIMOut_12__drv),
  .dIMOut_13__drv(original_dIMOut_13__drv),
  .dIMOut_14__drv(original_dIMOut_14__drv),
  .dIMOut_15__drv(original_dIMOut_15__drv),
  .dIMRH__drv(original_dIMRH__drv),
  .dJCN_0__drv(original_dJCN_0__drv),
  .dJCN_1__drv(original_dJCN_1__drv),
  .dJCN_2__drv(original_dJCN_2__drv),
  .dJCN_3__drv(original_dJCN_3__drv),
  .dJCN_4__drv(original_dJCN_4__drv),
  .dJCN_5__drv(original_dJCN_5__drv),
  .dJCN_6__drv(original_dJCN_6__drv),
  .dJCN_7__drv(original_dJCN_7__drv),
  .rMIRa__drv(original_rMIRa__drv)
 );
 assign original_outputs = {original_rMIRa__drv, original_dJCN_7__drv, original_dJCN_6__drv, original_dJCN_5__drv, original_dJCN_4__drv, original_dJCN_3__drv, original_dJCN_2__drv, original_dJCN_1__drv, original_dJCN_0__drv, original_dIMRH__drv, original_dIMOut_15__drv, original_dIMOut_14__drv, original_dIMOut_13__drv, original_dIMOut_12__drv, original_dIMOut_11__drv, original_dIMOut_10__drv, original_dIMOut_09__drv, original_dIMOut_08__drv, original_dIMOut_07__drv, original_dFF_7__drv, original_dFF_6__drv, original_dFF_5__drv, original_dFF_4__drv, original_dFF_3__drv, original_dFF_2__drv, original_dFF_1__drv, original_dFF_0__drv, original_dBlock_p___drv, original_StopMIRClk__drv, original_RSTK_3__drv, original_RSTK_2__drv, original_RSTK_1__drv, original_RSTK_0__drv, original_LC_2__drv, original_LC_1__drv, original_LC_0__drv, original_IMRHPEDly__drv, original_IMLHPEDly__drv, original_IMLHPE_p___drv, original_Error_p___drv, original_DMuxData__drv, original_CPIn_3__drv, original_CPIn_2__drv, original_CPIn_1__drv, original_CPIn_0__drv, original_CBTempSense__drv, original_BSEL_2_p___drv, original_BSEL_1_p___drv, original_BSEL_0_p___drv, original_BNPC_15__drv, original_BNPC_14__drv, original_BNPC_13__drv, original_BNPC_12__drv, original_BNPC_11__drv, original_BNPC_10__drv, original_BNPC_09__drv, original_BNPC_08__drv, original_BNPC_07__drv, original_BNPC_06__drv, original_BNPC_05__drv, original_BNPC_04__drv, original_ASEL_2_p___drv, original_ASEL_1_p___drv, original_ASEL_0_p_mem__drv, original_ASEL_0_p_a__drv, original_ASEL_0_p___drv, original_ASEL_0__drv, original_ALUF_3__drv, original_ALUF_2__drv, original_ALUF_1__drv, original_ALUF_0__drv};
 wire candidate_ALUF_0__drv;
 wire candidate_ALUF_1__drv;
 wire candidate_ALUF_2__drv;
 wire candidate_ALUF_3__drv;
 wire candidate_ASEL_0__drv;
 wire candidate_ASEL_0_p___drv;
 wire candidate_ASEL_0_p_a__drv;
 wire candidate_ASEL_0_p_mem__drv;
 wire candidate_ASEL_1_p___drv;
 wire candidate_ASEL_2_p___drv;
 wire candidate_BNPC_04__drv;
 wire candidate_BNPC_05__drv;
 wire candidate_BNPC_06__drv;
 wire candidate_BNPC_07__drv;
 wire candidate_BNPC_08__drv;
 wire candidate_BNPC_09__drv;
 wire candidate_BNPC_10__drv;
 wire candidate_BNPC_11__drv;
 wire candidate_BNPC_12__drv;
 wire candidate_BNPC_13__drv;
 wire candidate_BNPC_14__drv;
 wire candidate_BNPC_15__drv;
 wire candidate_BSEL_0_p___drv;
 wire candidate_BSEL_1_p___drv;
 wire candidate_BSEL_2_p___drv;
 wire candidate_CBTempSense__drv;
 wire candidate_CPIn_0__drv;
 wire candidate_CPIn_1__drv;
 wire candidate_CPIn_2__drv;
 wire candidate_CPIn_3__drv;
 wire candidate_DMuxData__drv;
 wire candidate_Error_p___drv;
 wire candidate_IMLHPE_p___drv;
 wire candidate_IMLHPEDly__drv;
 wire candidate_IMRHPEDly__drv;
 wire candidate_LC_0__drv;
 wire candidate_LC_1__drv;
 wire candidate_LC_2__drv;
 wire candidate_RSTK_0__drv;
 wire candidate_RSTK_1__drv;
 wire candidate_RSTK_2__drv;
 wire candidate_RSTK_3__drv;
 wire candidate_StopMIRClk__drv;
 wire candidate_dBlock_p___drv;
 wire candidate_dFF_0__drv;
 wire candidate_dFF_1__drv;
 wire candidate_dFF_2__drv;
 wire candidate_dFF_3__drv;
 wire candidate_dFF_4__drv;
 wire candidate_dFF_5__drv;
 wire candidate_dFF_6__drv;
 wire candidate_dFF_7__drv;
 wire candidate_dIMOut_07__drv;
 wire candidate_dIMOut_08__drv;
 wire candidate_dIMOut_09__drv;
 wire candidate_dIMOut_10__drv;
 wire candidate_dIMOut_11__drv;
 wire candidate_dIMOut_12__drv;
 wire candidate_dIMOut_13__drv;
 wire candidate_dIMOut_14__drv;
 wire candidate_dIMOut_15__drv;
 wire candidate_dIMRH__drv;
 wire candidate_dJCN_0__drv;
 wire candidate_dJCN_1__drv;
 wire candidate_dJCN_2__drv;
 wire candidate_dJCN_3__drv;
 wire candidate_dJCN_4__drv;
 wire candidate_dJCN_5__drv;
 wire candidate_dJCN_6__drv;
 wire candidate_dJCN_7__drv;
 wire candidate_rMIRa__drv;
 ContB_snapshot_experiment #(.SYSPER(4)) candidate (
  .sys_clk(guest_clk),
  .ALUF_0(stimulus[0] | candidate_ALUF_0__drv),
  .ALUF_1(stimulus[1] | candidate_ALUF_1__drv),
  .ALUF_2(stimulus[2] | candidate_ALUF_2__drv),
  .ALUF_3(stimulus[3] | candidate_ALUF_3__drv),
  .BMux_00(stimulus[4]),
  .BMux_01(stimulus[5]),
  .BMux_02(stimulus[6]),
  .BMux_03(stimulus[7]),
  .BMux_04(stimulus[8]),
  .BMux_05(stimulus[9]),
  .BMux_06(stimulus[10]),
  .BMux_07(stimulus[11]),
  .BMux_08(stimulus[12]),
  .BMux_09(stimulus[13]),
  .BMux_10(stimulus[14]),
  .BMux_11(stimulus[15]),
  .BMux_12(stimulus[16]),
  .BMux_13(stimulus[17]),
  .BMux_14(stimulus[18]),
  .BMux_15(stimulus[19]),
  .BMux_16(stimulus[20]),
  .BMux_17(stimulus[21]),
  .BNPC_02(stimulus[22]),
  .BNPC_03(stimulus[23]),
  .BNPC_04(stimulus[24] | candidate_BNPC_04__drv),
  .BNPC_05(stimulus[25] | candidate_BNPC_05__drv),
  .BNPC_06(stimulus[26] | candidate_BNPC_06__drv),
  .BNPC_07(stimulus[27] | candidate_BNPC_07__drv),
  .BNPC_08(stimulus[28] | candidate_BNPC_08__drv),
  .BNPC_09(stimulus[29] | candidate_BNPC_09__drv),
  .BNPC_10(stimulus[30] | candidate_BNPC_10__drv),
  .BNPC_11(stimulus[31] | candidate_BNPC_11__drv),
  .BNPC_12(stimulus[32] | candidate_BNPC_12__drv),
  .BNPC_13(stimulus[33] | candidate_BNPC_13__drv),
  .BNPC_14(stimulus[34] | candidate_BNPC_14__drv),
  .BNPC_15(stimulus[35] | candidate_BNPC_15__drv),
  .BNTGtCT_p_a(stimulus[36]),
  .CBHold(stimulus[37]),
  .CBTempSense(stimulus[38] | candidate_CBTempSense__drv),
  .CLK_cb_p_(stimulus[39]),
  .CLKEnable_p_a(stimulus[40]),
  .CPAddr_0_p_(stimulus[41]),
  .CPAddr_1_p_(stimulus[42]),
  .CPAddr_2_p_(stimulus[43]),
  .CPOut_0(stimulus[44]),
  .CPOut_1(stimulus[45]),
  .CPOut_2(stimulus[46]),
  .CPOut_3(stimulus[47]),
  .CPOut_8(stimulus[48]),
  .CPStrb_p_(stimulus[49]),
  .CRamClock(stimulus[50]),
  .DMuxClk(stimulus[51]),
  .DMuxData(stimulus[52] | candidate_DMuxData__drv),
  .DoCBr(stimulus[53]),
  .IMLHPE_p_(stimulus[54] | candidate_IMLHPE_p___drv),
  .IMLHPEDly(stimulus[55] | candidate_IMLHPEDly__drv),
  .IMRHPE_p_(stimulus[56]),
  .IMRHPEDly(stimulus[57] | candidate_IMRHPEDly__drv),
  .IOPE(stimulus[58]),
  .LC_0(stimulus[59] | candidate_LC_0__drv),
  .LC_1(stimulus[60] | candidate_LC_1__drv),
  .LC_2(stimulus[61] | candidate_LC_2__drv),
  .MdPE(stimulus[62]),
  .MemPE(stimulus[63]),
  .RamPE(stimulus[64]),
  .SW(stimulus[65]),
  .StartCycle_p_a(stimulus[66]),
  .TNIA_02(stimulus[67]),
  .TNIA_03(stimulus[68]),
  .TNIA_04(stimulus[69]),
  .TNIA_05(stimulus[70]),
  .TNIA_06(stimulus[71]),
  .TNIA_07(stimulus[72]),
  .TNIA_08(stimulus[73]),
  .TNIA_09(stimulus[74]),
  .TNIA_10(stimulus[75]),
  .TNIA_11(stimulus[76]),
  .TNIA_12(stimulus[77]),
  .TNIA_13(stimulus[78]),
  .TNIA_14(stimulus[79]),
  .TNIA_15(stimulus[80]),
  .TempRef(stimulus[81]),
  .UseDMD(stimulus[82]),
  .dBlock_p_(stimulus[83] | candidate_dBlock_p___drv),
  .dFF_0(stimulus[84] | candidate_dFF_0__drv),
  .dFF_1(stimulus[85] | candidate_dFF_1__drv),
  .dFF_2(stimulus[86] | candidate_dFF_2__drv),
  .dFF_3(stimulus[87] | candidate_dFF_3__drv),
  .dFF_4(stimulus[88] | candidate_dFF_4__drv),
  .dFF_5(stimulus[89] | candidate_dFF_5__drv),
  .dFF_6(stimulus[90] | candidate_dFF_6__drv),
  .dFF_7(stimulus[91] | candidate_dFF_7__drv),
  .dIMRH(stimulus[92] | candidate_dIMRH__drv),
  .dJCN_0(stimulus[93] | candidate_dJCN_0__drv),
  .dJCN_1(stimulus[94] | candidate_dJCN_1__drv),
  .dJCN_2(stimulus[95] | candidate_dJCN_2__drv),
  .dJCN_3(stimulus[96] | candidate_dJCN_3__drv),
  .dJCN_4(stimulus[97] | candidate_dJCN_4__drv),
  .dJCN_5(stimulus[98] | candidate_dJCN_5__drv),
  .dJCN_6(stimulus[99] | candidate_dJCN_6__drv),
  .dJCN_7(stimulus[100] | candidate_dJCN_7__drv),
  .rMIRa(stimulus[101] | candidate_rMIRa__drv),
  .ALUF_0__drv(candidate_ALUF_0__drv),
  .ALUF_1__drv(candidate_ALUF_1__drv),
  .ALUF_2__drv(candidate_ALUF_2__drv),
  .ALUF_3__drv(candidate_ALUF_3__drv),
  .ASEL_0__drv(candidate_ASEL_0__drv),
  .ASEL_0_p___drv(candidate_ASEL_0_p___drv),
  .ASEL_0_p_a__drv(candidate_ASEL_0_p_a__drv),
  .ASEL_0_p_mem__drv(candidate_ASEL_0_p_mem__drv),
  .ASEL_1_p___drv(candidate_ASEL_1_p___drv),
  .ASEL_2_p___drv(candidate_ASEL_2_p___drv),
  .BNPC_04__drv(candidate_BNPC_04__drv),
  .BNPC_05__drv(candidate_BNPC_05__drv),
  .BNPC_06__drv(candidate_BNPC_06__drv),
  .BNPC_07__drv(candidate_BNPC_07__drv),
  .BNPC_08__drv(candidate_BNPC_08__drv),
  .BNPC_09__drv(candidate_BNPC_09__drv),
  .BNPC_10__drv(candidate_BNPC_10__drv),
  .BNPC_11__drv(candidate_BNPC_11__drv),
  .BNPC_12__drv(candidate_BNPC_12__drv),
  .BNPC_13__drv(candidate_BNPC_13__drv),
  .BNPC_14__drv(candidate_BNPC_14__drv),
  .BNPC_15__drv(candidate_BNPC_15__drv),
  .BSEL_0_p___drv(candidate_BSEL_0_p___drv),
  .BSEL_1_p___drv(candidate_BSEL_1_p___drv),
  .BSEL_2_p___drv(candidate_BSEL_2_p___drv),
  .CBTempSense__drv(candidate_CBTempSense__drv),
  .CPIn_0__drv(candidate_CPIn_0__drv),
  .CPIn_1__drv(candidate_CPIn_1__drv),
  .CPIn_2__drv(candidate_CPIn_2__drv),
  .CPIn_3__drv(candidate_CPIn_3__drv),
  .DMuxData__drv(candidate_DMuxData__drv),
  .Error_p___drv(candidate_Error_p___drv),
  .IMLHPE_p___drv(candidate_IMLHPE_p___drv),
  .IMLHPEDly__drv(candidate_IMLHPEDly__drv),
  .IMRHPEDly__drv(candidate_IMRHPEDly__drv),
  .LC_0__drv(candidate_LC_0__drv),
  .LC_1__drv(candidate_LC_1__drv),
  .LC_2__drv(candidate_LC_2__drv),
  .RSTK_0__drv(candidate_RSTK_0__drv),
  .RSTK_1__drv(candidate_RSTK_1__drv),
  .RSTK_2__drv(candidate_RSTK_2__drv),
  .RSTK_3__drv(candidate_RSTK_3__drv),
  .StopMIRClk__drv(candidate_StopMIRClk__drv),
  .dBlock_p___drv(candidate_dBlock_p___drv),
  .dFF_0__drv(candidate_dFF_0__drv),
  .dFF_1__drv(candidate_dFF_1__drv),
  .dFF_2__drv(candidate_dFF_2__drv),
  .dFF_3__drv(candidate_dFF_3__drv),
  .dFF_4__drv(candidate_dFF_4__drv),
  .dFF_5__drv(candidate_dFF_5__drv),
  .dFF_6__drv(candidate_dFF_6__drv),
  .dFF_7__drv(candidate_dFF_7__drv),
  .dIMOut_07__drv(candidate_dIMOut_07__drv),
  .dIMOut_08__drv(candidate_dIMOut_08__drv),
  .dIMOut_09__drv(candidate_dIMOut_09__drv),
  .dIMOut_10__drv(candidate_dIMOut_10__drv),
  .dIMOut_11__drv(candidate_dIMOut_11__drv),
  .dIMOut_12__drv(candidate_dIMOut_12__drv),
  .dIMOut_13__drv(candidate_dIMOut_13__drv),
  .dIMOut_14__drv(candidate_dIMOut_14__drv),
  .dIMOut_15__drv(candidate_dIMOut_15__drv),
  .dIMRH__drv(candidate_dIMRH__drv),
  .dJCN_0__drv(candidate_dJCN_0__drv),
  .dJCN_1__drv(candidate_dJCN_1__drv),
  .dJCN_2__drv(candidate_dJCN_2__drv),
  .dJCN_3__drv(candidate_dJCN_3__drv),
  .dJCN_4__drv(candidate_dJCN_4__drv),
  .dJCN_5__drv(candidate_dJCN_5__drv),
  .dJCN_6__drv(candidate_dJCN_6__drv),
  .dJCN_7__drv(candidate_dJCN_7__drv),
  .rMIRa__drv(candidate_rMIRa__drv),
  .state_host_clk(host_clk),
  .state_guest_advance(enabled),
  .state_freeze(freeze),
  .state_guest_held(held),
  .state_frozen(frozen),
  .state_request(request),
  .state_write(write),
  .state_index(state_index),
  .state_data(state_data),
  .state_done(done),
  .state_error(error),
  .state_result(result)
 );
 assign candidate_outputs = {candidate_rMIRa__drv, candidate_dJCN_7__drv, candidate_dJCN_6__drv, candidate_dJCN_5__drv, candidate_dJCN_4__drv, candidate_dJCN_3__drv, candidate_dJCN_2__drv, candidate_dJCN_1__drv, candidate_dJCN_0__drv, candidate_dIMRH__drv, candidate_dIMOut_15__drv, candidate_dIMOut_14__drv, candidate_dIMOut_13__drv, candidate_dIMOut_12__drv, candidate_dIMOut_11__drv, candidate_dIMOut_10__drv, candidate_dIMOut_09__drv, candidate_dIMOut_08__drv, candidate_dIMOut_07__drv, candidate_dFF_7__drv, candidate_dFF_6__drv, candidate_dFF_5__drv, candidate_dFF_4__drv, candidate_dFF_3__drv, candidate_dFF_2__drv, candidate_dFF_1__drv, candidate_dFF_0__drv, candidate_dBlock_p___drv, candidate_StopMIRClk__drv, candidate_RSTK_3__drv, candidate_RSTK_2__drv, candidate_RSTK_1__drv, candidate_RSTK_0__drv, candidate_LC_2__drv, candidate_LC_1__drv, candidate_LC_0__drv, candidate_IMRHPEDly__drv, candidate_IMLHPEDly__drv, candidate_IMLHPE_p___drv, candidate_Error_p___drv, candidate_DMuxData__drv, candidate_CPIn_3__drv, candidate_CPIn_2__drv, candidate_CPIn_1__drv, candidate_CPIn_0__drv, candidate_CBTempSense__drv, candidate_BSEL_2_p___drv, candidate_BSEL_1_p___drv, candidate_BSEL_0_p___drv, candidate_BNPC_15__drv, candidate_BNPC_14__drv, candidate_BNPC_13__drv, candidate_BNPC_12__drv, candidate_BNPC_11__drv, candidate_BNPC_10__drv, candidate_BNPC_09__drv, candidate_BNPC_08__drv, candidate_BNPC_07__drv, candidate_BNPC_06__drv, candidate_BNPC_05__drv, candidate_BNPC_04__drv, candidate_ASEL_2_p___drv, candidate_ASEL_1_p___drv, candidate_ASEL_0_p_mem__drv, candidate_ASEL_0_p_a__drv, candidate_ASEL_0_p___drv, candidate_ASEL_0__drv, candidate_ALUF_3__drv, candidate_ALUF_2__drv, candidate_ALUF_1__drv, candidate_ALUF_0__drv};
 integer row;
 initial begin
 for(row=0;row<1024;row=row+1) begin
 original.u_a06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 0) & 1;
 candidate.snapshot_bank_0.bits[0].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 0) & 1;
 original.u_b06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 1) & 1;
 candidate.snapshot_bank_0.bits[1].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 1) & 1;
 original.u_c06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 2) & 1;
 candidate.snapshot_bank_0.bits[2].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 2) & 1;
 original.u_d06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 3) & 1;
 candidate.snapshot_bank_0.bits[3].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 3) & 1;
 original.u_f06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 4) & 1;
 candidate.snapshot_bank_0.bits[4].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 4) & 1;
 original.u_g06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 5) & 1;
 candidate.snapshot_bank_0.bits[5].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 5) & 1;
 original.u_h06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 6) & 1;
 candidate.snapshot_bank_0.bits[6].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 6) & 1;
 original.u_i06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 7) & 1;
 candidate.snapshot_bank_0.bits[7].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 7) & 1;
 original.u_i10.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 8) & 1;
 candidate.snapshot_bank_0.bits[8].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 8) & 1;
 original.u_j06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 9) & 1;
 candidate.snapshot_bank_0.bits[9].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 9) & 1;
 original.u_j10.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 10) & 1;
 candidate.snapshot_bank_0.bits[10].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 10) & 1;
 original.u_j16.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 11) & 1;
 candidate.snapshot_bank_0.bits[11].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 11) & 1;
 original.u_k06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 12) & 1;
 candidate.snapshot_bank_0.bits[12].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 12) & 1;
 original.u_k10.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 13) & 1;
 candidate.snapshot_bank_0.bits[13].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 13) & 1;
 original.u_k16.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 14) & 1;
 candidate.snapshot_bank_0.bits[14].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 14) & 1;
 original.u_l06.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 15) & 1;
 candidate.snapshot_bank_0.bits[15].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 15) & 1;
 original.u_l10.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 16) & 1;
 candidate.snapshot_bank_0.bits[16].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 16) & 1;
 original.u_l16.mem[row] = ((row*32'd1103515245 + 32'd12345) >> 17) & 1;
 candidate.snapshot_bank_0.bits[17].mem[row] = ((row*32'd1103515245 + 32'd12345) >> 17) & 1;
 original.u_a10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 0) & 1;
 candidate.snapshot_bank_1.bits[0].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 0) & 1;
 original.u_a16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 1) & 1;
 candidate.snapshot_bank_1.bits[1].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 1) & 1;
 original.u_b10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 2) & 1;
 candidate.snapshot_bank_1.bits[2].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 2) & 1;
 original.u_b16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 3) & 1;
 candidate.snapshot_bank_1.bits[3].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 3) & 1;
 original.u_c10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 4) & 1;
 candidate.snapshot_bank_1.bits[4].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 4) & 1;
 original.u_c16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 5) & 1;
 candidate.snapshot_bank_1.bits[5].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 5) & 1;
 original.u_d10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 6) & 1;
 candidate.snapshot_bank_1.bits[6].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 6) & 1;
 original.u_d16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 7) & 1;
 candidate.snapshot_bank_1.bits[7].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 7) & 1;
 original.u_e06.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 8) & 1;
 candidate.snapshot_bank_1.bits[8].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 8) & 1;
 original.u_e10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 9) & 1;
 candidate.snapshot_bank_1.bits[9].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 9) & 1;
 original.u_e16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 10) & 1;
 candidate.snapshot_bank_1.bits[10].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 10) & 1;
 original.u_f10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 11) & 1;
 candidate.snapshot_bank_1.bits[11].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 11) & 1;
 original.u_f16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 12) & 1;
 candidate.snapshot_bank_1.bits[12].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 12) & 1;
 original.u_g10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 13) & 1;
 candidate.snapshot_bank_1.bits[13].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 13) & 1;
 original.u_g16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 14) & 1;
 candidate.snapshot_bank_1.bits[14].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 14) & 1;
 original.u_h10.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 15) & 1;
 candidate.snapshot_bank_1.bits[15].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 15) & 1;
 original.u_h16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 16) & 1;
 candidate.snapshot_bank_1.bits[16].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 16) & 1;
 original.u_i16.mem[row] = ((row*32'd1103515245 + 32'd20264) >> 17) & 1;
 candidate.snapshot_bank_1.bits[17].mem[row] = ((row*32'd1103515245 + 32'd20264) >> 17) & 1;
 original.u_a07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 0) & 1;
 candidate.snapshot_bank_2.bits[0].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 0) & 1;
 original.u_b07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 1) & 1;
 candidate.snapshot_bank_2.bits[1].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 1) & 1;
 original.u_c07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 2) & 1;
 candidate.snapshot_bank_2.bits[2].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 2) & 1;
 original.u_d07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 3) & 1;
 candidate.snapshot_bank_2.bits[3].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 3) & 1;
 original.u_f07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 4) & 1;
 candidate.snapshot_bank_2.bits[4].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 4) & 1;
 original.u_g07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 5) & 1;
 candidate.snapshot_bank_2.bits[5].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 5) & 1;
 original.u_h07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 6) & 1;
 candidate.snapshot_bank_2.bits[6].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 6) & 1;
 original.u_i07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 7) & 1;
 candidate.snapshot_bank_2.bits[7].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 7) & 1;
 original.u_i11.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 8) & 1;
 candidate.snapshot_bank_2.bits[8].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 8) & 1;
 original.u_j07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 9) & 1;
 candidate.snapshot_bank_2.bits[9].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 9) & 1;
 original.u_j11.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 10) & 1;
 candidate.snapshot_bank_2.bits[10].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 10) & 1;
 original.u_j17.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 11) & 1;
 candidate.snapshot_bank_2.bits[11].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 11) & 1;
 original.u_k07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 12) & 1;
 candidate.snapshot_bank_2.bits[12].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 12) & 1;
 original.u_k11.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 13) & 1;
 candidate.snapshot_bank_2.bits[13].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 13) & 1;
 original.u_k17.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 14) & 1;
 candidate.snapshot_bank_2.bits[14].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 14) & 1;
 original.u_l07.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 15) & 1;
 candidate.snapshot_bank_2.bits[15].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 15) & 1;
 original.u_l11.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 16) & 1;
 candidate.snapshot_bank_2.bits[16].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 16) & 1;
 original.u_l17.mem[row] = ((row*32'd1103515245 + 32'd28183) >> 17) & 1;
 candidate.snapshot_bank_2.bits[17].mem[row] = ((row*32'd1103515245 + 32'd28183) >> 17) & 1;
 original.u_a11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 0) & 1;
 candidate.snapshot_bank_3.bits[0].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 0) & 1;
 original.u_a17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 1) & 1;
 candidate.snapshot_bank_3.bits[1].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 1) & 1;
 original.u_b11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 2) & 1;
 candidate.snapshot_bank_3.bits[2].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 2) & 1;
 original.u_b17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 3) & 1;
 candidate.snapshot_bank_3.bits[3].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 3) & 1;
 original.u_c11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 4) & 1;
 candidate.snapshot_bank_3.bits[4].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 4) & 1;
 original.u_c17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 5) & 1;
 candidate.snapshot_bank_3.bits[5].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 5) & 1;
 original.u_d11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 6) & 1;
 candidate.snapshot_bank_3.bits[6].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 6) & 1;
 original.u_d17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 7) & 1;
 candidate.snapshot_bank_3.bits[7].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 7) & 1;
 original.u_e07.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 8) & 1;
 candidate.snapshot_bank_3.bits[8].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 8) & 1;
 original.u_e11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 9) & 1;
 candidate.snapshot_bank_3.bits[9].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 9) & 1;
 original.u_e17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 10) & 1;
 candidate.snapshot_bank_3.bits[10].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 10) & 1;
 original.u_f11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 11) & 1;
 candidate.snapshot_bank_3.bits[11].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 11) & 1;
 original.u_f17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 12) & 1;
 candidate.snapshot_bank_3.bits[12].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 12) & 1;
 original.u_g11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 13) & 1;
 candidate.snapshot_bank_3.bits[13].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 13) & 1;
 original.u_g17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 14) & 1;
 candidate.snapshot_bank_3.bits[14].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 14) & 1;
 original.u_h11.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 15) & 1;
 candidate.snapshot_bank_3.bits[15].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 15) & 1;
 original.u_h17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 16) & 1;
 candidate.snapshot_bank_3.bits[16].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 16) & 1;
 original.u_i17.mem[row] = ((row*32'd1103515245 + 32'd36102) >> 17) & 1;
 candidate.snapshot_bank_3.bits[17].mem[row] = ((row*32'd1103515245 + 32'd36102) >> 17) & 1;
 original.u_a08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 0) & 1;
 candidate.snapshot_bank_4.bits[0].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 0) & 1;
 original.u_b08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 1) & 1;
 candidate.snapshot_bank_4.bits[1].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 1) & 1;
 original.u_c08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 2) & 1;
 candidate.snapshot_bank_4.bits[2].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 2) & 1;
 original.u_d08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 3) & 1;
 candidate.snapshot_bank_4.bits[3].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 3) & 1;
 original.u_f08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 4) & 1;
 candidate.snapshot_bank_4.bits[4].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 4) & 1;
 original.u_g08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 5) & 1;
 candidate.snapshot_bank_4.bits[5].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 5) & 1;
 original.u_h08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 6) & 1;
 candidate.snapshot_bank_4.bits[6].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 6) & 1;
 original.u_i08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 7) & 1;
 candidate.snapshot_bank_4.bits[7].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 7) & 1;
 original.u_i14.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 8) & 1;
 candidate.snapshot_bank_4.bits[8].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 8) & 1;
 original.u_j08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 9) & 1;
 candidate.snapshot_bank_4.bits[9].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 9) & 1;
 original.u_j14.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 10) & 1;
 candidate.snapshot_bank_4.bits[10].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 10) & 1;
 original.u_j18.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 11) & 1;
 candidate.snapshot_bank_4.bits[11].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 11) & 1;
 original.u_k08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 12) & 1;
 candidate.snapshot_bank_4.bits[12].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 12) & 1;
 original.u_k14.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 13) & 1;
 candidate.snapshot_bank_4.bits[13].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 13) & 1;
 original.u_k18.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 14) & 1;
 candidate.snapshot_bank_4.bits[14].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 14) & 1;
 original.u_l08.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 15) & 1;
 candidate.snapshot_bank_4.bits[15].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 15) & 1;
 original.u_l14.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 16) & 1;
 candidate.snapshot_bank_4.bits[16].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 16) & 1;
 original.u_l18.mem[row] = ((row*32'd1103515245 + 32'd44021) >> 17) & 1;
 candidate.snapshot_bank_4.bits[17].mem[row] = ((row*32'd1103515245 + 32'd44021) >> 17) & 1;
 original.u_a14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 0) & 1;
 candidate.snapshot_bank_5.bits[0].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 0) & 1;
 original.u_a18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 1) & 1;
 candidate.snapshot_bank_5.bits[1].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 1) & 1;
 original.u_b14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 2) & 1;
 candidate.snapshot_bank_5.bits[2].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 2) & 1;
 original.u_b18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 3) & 1;
 candidate.snapshot_bank_5.bits[3].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 3) & 1;
 original.u_c14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 4) & 1;
 candidate.snapshot_bank_5.bits[4].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 4) & 1;
 original.u_c18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 5) & 1;
 candidate.snapshot_bank_5.bits[5].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 5) & 1;
 original.u_d14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 6) & 1;
 candidate.snapshot_bank_5.bits[6].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 6) & 1;
 original.u_d18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 7) & 1;
 candidate.snapshot_bank_5.bits[7].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 7) & 1;
 original.u_e08.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 8) & 1;
 candidate.snapshot_bank_5.bits[8].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 8) & 1;
 original.u_e14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 9) & 1;
 candidate.snapshot_bank_5.bits[9].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 9) & 1;
 original.u_e18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 10) & 1;
 candidate.snapshot_bank_5.bits[10].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 10) & 1;
 original.u_f14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 11) & 1;
 candidate.snapshot_bank_5.bits[11].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 11) & 1;
 original.u_f18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 12) & 1;
 candidate.snapshot_bank_5.bits[12].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 12) & 1;
 original.u_g14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 13) & 1;
 candidate.snapshot_bank_5.bits[13].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 13) & 1;
 original.u_g18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 14) & 1;
 candidate.snapshot_bank_5.bits[14].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 14) & 1;
 original.u_h14.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 15) & 1;
 candidate.snapshot_bank_5.bits[15].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 15) & 1;
 original.u_h18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 16) & 1;
 candidate.snapshot_bank_5.bits[16].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 16) & 1;
 original.u_i18.mem[row] = ((row*32'd1103515245 + 32'd51940) >> 17) & 1;
 candidate.snapshot_bank_5.bits[17].mem[row] = ((row*32'd1103515245 + 32'd51940) >> 17) & 1;
 original.u_a09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 0) & 1;
 candidate.snapshot_bank_6.bits[0].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 0) & 1;
 original.u_b09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 1) & 1;
 candidate.snapshot_bank_6.bits[1].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 1) & 1;
 original.u_c09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 2) & 1;
 candidate.snapshot_bank_6.bits[2].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 2) & 1;
 original.u_d09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 3) & 1;
 candidate.snapshot_bank_6.bits[3].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 3) & 1;
 original.u_f09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 4) & 1;
 candidate.snapshot_bank_6.bits[4].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 4) & 1;
 original.u_g09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 5) & 1;
 candidate.snapshot_bank_6.bits[5].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 5) & 1;
 original.u_h09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 6) & 1;
 candidate.snapshot_bank_6.bits[6].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 6) & 1;
 original.u_i09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 7) & 1;
 candidate.snapshot_bank_6.bits[7].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 7) & 1;
 original.u_i15.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 8) & 1;
 candidate.snapshot_bank_6.bits[8].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 8) & 1;
 original.u_j09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 9) & 1;
 candidate.snapshot_bank_6.bits[9].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 9) & 1;
 original.u_j15.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 10) & 1;
 candidate.snapshot_bank_6.bits[10].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 10) & 1;
 original.u_j19.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 11) & 1;
 candidate.snapshot_bank_6.bits[11].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 11) & 1;
 original.u_k09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 12) & 1;
 candidate.snapshot_bank_6.bits[12].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 12) & 1;
 original.u_k15.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 13) & 1;
 candidate.snapshot_bank_6.bits[13].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 13) & 1;
 original.u_k19.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 14) & 1;
 candidate.snapshot_bank_6.bits[14].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 14) & 1;
 original.u_l09.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 15) & 1;
 candidate.snapshot_bank_6.bits[15].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 15) & 1;
 original.u_l15.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 16) & 1;
 candidate.snapshot_bank_6.bits[16].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 16) & 1;
 original.u_l19.mem[row] = ((row*32'd1103515245 + 32'd59859) >> 17) & 1;
 candidate.snapshot_bank_6.bits[17].mem[row] = ((row*32'd1103515245 + 32'd59859) >> 17) & 1;
 original.u_a15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 0) & 1;
 candidate.snapshot_bank_7.bits[0].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 0) & 1;
 original.u_a19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 1) & 1;
 candidate.snapshot_bank_7.bits[1].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 1) & 1;
 original.u_b15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 2) & 1;
 candidate.snapshot_bank_7.bits[2].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 2) & 1;
 original.u_b19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 3) & 1;
 candidate.snapshot_bank_7.bits[3].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 3) & 1;
 original.u_c15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 4) & 1;
 candidate.snapshot_bank_7.bits[4].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 4) & 1;
 original.u_c19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 5) & 1;
 candidate.snapshot_bank_7.bits[5].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 5) & 1;
 original.u_d15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 6) & 1;
 candidate.snapshot_bank_7.bits[6].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 6) & 1;
 original.u_d19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 7) & 1;
 candidate.snapshot_bank_7.bits[7].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 7) & 1;
 original.u_e09.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 8) & 1;
 candidate.snapshot_bank_7.bits[8].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 8) & 1;
 original.u_e15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 9) & 1;
 candidate.snapshot_bank_7.bits[9].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 9) & 1;
 original.u_e19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 10) & 1;
 candidate.snapshot_bank_7.bits[10].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 10) & 1;
 original.u_f15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 11) & 1;
 candidate.snapshot_bank_7.bits[11].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 11) & 1;
 original.u_f19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 12) & 1;
 candidate.snapshot_bank_7.bits[12].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 12) & 1;
 original.u_g15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 13) & 1;
 candidate.snapshot_bank_7.bits[13].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 13) & 1;
 original.u_g19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 14) & 1;
 candidate.snapshot_bank_7.bits[14].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 14) & 1;
 original.u_h15.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 15) & 1;
 candidate.snapshot_bank_7.bits[15].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 15) & 1;
 original.u_h19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 16) & 1;
 candidate.snapshot_bank_7.bits[16].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 16) & 1;
 original.u_i19.mem[row] = ((row*32'd1103515245 + 32'd67778) >> 17) & 1;
 candidate.snapshot_bank_7.bits[17].mem[row] = ((row*32'd1103515245 + 32'd67778) >> 17) & 1;
 end
 end
 assign addresses[0+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[0] = original.CS0_p_ACa;
 assign we_n[0] = original.WEL_p_Aa;
 assign candidate_raw[0+:18] = candidate.snapshot_bank_0.logical_q;
 assign data_bits[0] = original.RBMux_13;
 assign original_raw[0] = original.u_a06.dout_r;
 assign data_bits[1] = original.RBMux_14;
 assign original_raw[1] = original.u_b06.dout_r;
 assign data_bits[2] = original.RBMux_15;
 assign original_raw[2] = original.u_c06.dout_r;
 assign data_bits[3] = original.RBMuxP;
 assign original_raw[3] = original.u_d06.dout_r;
 assign data_bits[4] = original.RBMux_07;
 assign original_raw[4] = original.u_f06.dout_r;
 assign data_bits[5] = original.RBMux_08;
 assign original_raw[5] = original.u_g06.dout_r;
 assign data_bits[6] = original.RBMux_09;
 assign original_raw[6] = original.u_h06.dout_r;
 assign data_bits[7] = original.MidasOrRSTK_2;
 assign original_raw[7] = original.u_i06.dout_r;
 assign data_bits[8] = original.RBMux_03;
 assign original_raw[8] = original.u_i10.dout_r;
 assign data_bits[9] = original.RBMux_00;
 assign original_raw[9] = original.u_j06.dout_r;
 assign data_bits[10] = original.RBMux_04;
 assign original_raw[10] = original.u_j10.dout_r;
 assign data_bits[11] = original.RBMux_10;
 assign original_raw[11] = original.u_j16.dout_r;
 assign data_bits[12] = original.RBMux_01;
 assign original_raw[12] = original.u_k06.dout_r;
 assign data_bits[13] = original.RBMux_05;
 assign original_raw[13] = original.u_k10.dout_r;
 assign data_bits[14] = original.RBMux_11;
 assign original_raw[14] = original.u_k16.dout_r;
 assign data_bits[15] = original.RBMux_02;
 assign original_raw[15] = original.u_l06.dout_r;
 assign data_bits[16] = original.RBMux_06;
 assign original_raw[16] = original.u_l10.dout_r;
 assign data_bits[17] = original.RBMux_12;
 assign original_raw[17] = original.u_l16.dout_r;
 assign addresses[10+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[1] = original.CS0_p_ACa;
 assign we_n[1] = original.WER_p_Aa;
 assign candidate_raw[18+:18] = candidate.snapshot_bank_1.logical_q;
 assign data_bits[18] = original.RBMux_00;
 assign original_raw[18] = original.u_a10.dout_r;
 assign data_bits[19] = original.RBMux_04;
 assign original_raw[19] = original.u_a16.dout_r;
 assign data_bits[20] = original.RBMux_01;
 assign original_raw[20] = original.u_b10.dout_r;
 assign data_bits[21] = original.RBMux_05;
 assign original_raw[21] = original.u_b16.dout_r;
 assign data_bits[22] = original.RBMux_02;
 assign original_raw[22] = original.u_c10.dout_r;
 assign data_bits[23] = original.RBMux_06;
 assign original_raw[23] = original.u_c16.dout_r;
 assign data_bits[24] = original.RBMux_03;
 assign original_raw[24] = original.u_d10.dout_r;
 assign data_bits[25] = original.RBMux_07;
 assign original_raw[25] = original.u_d16.dout_r;
 assign data_bits[26] = original.RBMux_08;
 assign original_raw[26] = original.u_e06.dout_r;
 assign data_bits[27] = original.RBMux_09;
 assign original_raw[27] = original.u_e10.dout_r;
 assign data_bits[28] = original.RBMuxP;
 assign original_raw[28] = original.u_e16.dout_r;
 assign data_bits[29] = original.RBMux_10;
 assign original_raw[29] = original.u_f10.dout_r;
 assign data_bits[30] = original.ContB04_sil_pl_1;
 assign original_raw[30] = original.u_f16.dout_r;
 assign data_bits[31] = original.RBMux_11;
 assign original_raw[31] = original.u_g10.dout_r;
 assign data_bits[32] = original.RBMux_13;
 assign original_raw[32] = original.u_g16.dout_r;
 assign data_bits[33] = original.RBMux_12;
 assign original_raw[33] = original.u_h10.dout_r;
 assign data_bits[34] = original.RBMux_14;
 assign original_raw[34] = original.u_h16.dout_r;
 assign data_bits[35] = original.RBMux_15;
 assign original_raw[35] = original.u_i16.dout_r;
 assign addresses[20+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[2] = original.CS1_p_ACa;
 assign we_n[2] = original.WEL_p_Aa;
 assign candidate_raw[36+:18] = candidate.snapshot_bank_2.logical_q;
 assign data_bits[36] = original.RBMux_13;
 assign original_raw[36] = original.u_a07.dout_r;
 assign data_bits[37] = original.RBMux_14;
 assign original_raw[37] = original.u_b07.dout_r;
 assign data_bits[38] = original.RBMux_15;
 assign original_raw[38] = original.u_c07.dout_r;
 assign data_bits[39] = original.RBMuxP;
 assign original_raw[39] = original.u_d07.dout_r;
 assign data_bits[40] = original.RBMux_07;
 assign original_raw[40] = original.u_f07.dout_r;
 assign data_bits[41] = original.RBMux_08;
 assign original_raw[41] = original.u_g07.dout_r;
 assign data_bits[42] = original.RBMux_09;
 assign original_raw[42] = original.u_h07.dout_r;
 assign data_bits[43] = original.MidasOrRSTK_2;
 assign original_raw[43] = original.u_i07.dout_r;
 assign data_bits[44] = original.RBMux_03;
 assign original_raw[44] = original.u_i11.dout_r;
 assign data_bits[45] = original.RBMux_00;
 assign original_raw[45] = original.u_j07.dout_r;
 assign data_bits[46] = original.RBMux_04;
 assign original_raw[46] = original.u_j11.dout_r;
 assign data_bits[47] = original.RBMux_10;
 assign original_raw[47] = original.u_j17.dout_r;
 assign data_bits[48] = original.RBMux_01;
 assign original_raw[48] = original.u_k07.dout_r;
 assign data_bits[49] = original.RBMux_05;
 assign original_raw[49] = original.u_k11.dout_r;
 assign data_bits[50] = original.RBMux_11;
 assign original_raw[50] = original.u_k17.dout_r;
 assign data_bits[51] = original.RBMux_02;
 assign original_raw[51] = original.u_l07.dout_r;
 assign data_bits[52] = original.RBMux_06;
 assign original_raw[52] = original.u_l11.dout_r;
 assign data_bits[53] = original.RBMux_12;
 assign original_raw[53] = original.u_l17.dout_r;
 assign addresses[30+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[3] = original.CS1_p_ACa;
 assign we_n[3] = original.WER_p_Aa;
 assign candidate_raw[54+:18] = candidate.snapshot_bank_3.logical_q;
 assign data_bits[54] = original.RBMux_00;
 assign original_raw[54] = original.u_a11.dout_r;
 assign data_bits[55] = original.RBMux_04;
 assign original_raw[55] = original.u_a17.dout_r;
 assign data_bits[56] = original.RBMux_01;
 assign original_raw[56] = original.u_b11.dout_r;
 assign data_bits[57] = original.RBMux_05;
 assign original_raw[57] = original.u_b17.dout_r;
 assign data_bits[58] = original.RBMux_02;
 assign original_raw[58] = original.u_c11.dout_r;
 assign data_bits[59] = original.RBMux_06;
 assign original_raw[59] = original.u_c17.dout_r;
 assign data_bits[60] = original.RBMux_03;
 assign original_raw[60] = original.u_d11.dout_r;
 assign data_bits[61] = original.RBMux_07;
 assign original_raw[61] = original.u_d17.dout_r;
 assign data_bits[62] = original.RBMux_08;
 assign original_raw[62] = original.u_e07.dout_r;
 assign data_bits[63] = original.RBMux_09;
 assign original_raw[63] = original.u_e11.dout_r;
 assign data_bits[64] = original.RBMuxP;
 assign original_raw[64] = original.u_e17.dout_r;
 assign data_bits[65] = original.RBMux_10;
 assign original_raw[65] = original.u_f11.dout_r;
 assign data_bits[66] = original.ContB04_sil_pl_1;
 assign original_raw[66] = original.u_f17.dout_r;
 assign data_bits[67] = original.RBMux_11;
 assign original_raw[67] = original.u_g11.dout_r;
 assign data_bits[68] = original.RBMux_13;
 assign original_raw[68] = original.u_g17.dout_r;
 assign data_bits[69] = original.RBMux_12;
 assign original_raw[69] = original.u_h11.dout_r;
 assign data_bits[70] = original.RBMux_14;
 assign original_raw[70] = original.u_h17.dout_r;
 assign data_bits[71] = original.RBMux_15;
 assign original_raw[71] = original.u_i17.dout_r;
 assign addresses[40+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[4] = original.CS2_p_ACa;
 assign we_n[4] = original.WEL_p_Aa;
 assign candidate_raw[72+:18] = candidate.snapshot_bank_4.logical_q;
 assign data_bits[72] = original.RBMux_13;
 assign original_raw[72] = original.u_a08.dout_r;
 assign data_bits[73] = original.RBMux_14;
 assign original_raw[73] = original.u_b08.dout_r;
 assign data_bits[74] = original.RBMux_15;
 assign original_raw[74] = original.u_c08.dout_r;
 assign data_bits[75] = original.RBMuxP;
 assign original_raw[75] = original.u_d08.dout_r;
 assign data_bits[76] = original.RBMux_07;
 assign original_raw[76] = original.u_f08.dout_r;
 assign data_bits[77] = original.RBMux_08;
 assign original_raw[77] = original.u_g08.dout_r;
 assign data_bits[78] = original.RBMux_09;
 assign original_raw[78] = original.u_h08.dout_r;
 assign data_bits[79] = original.MidasOrRSTK_2;
 assign original_raw[79] = original.u_i08.dout_r;
 assign data_bits[80] = original.RBMux_03;
 assign original_raw[80] = original.u_i14.dout_r;
 assign data_bits[81] = original.RBMux_00;
 assign original_raw[81] = original.u_j08.dout_r;
 assign data_bits[82] = original.RBMux_04;
 assign original_raw[82] = original.u_j14.dout_r;
 assign data_bits[83] = original.RBMux_10;
 assign original_raw[83] = original.u_j18.dout_r;
 assign data_bits[84] = original.RBMux_01;
 assign original_raw[84] = original.u_k08.dout_r;
 assign data_bits[85] = original.RBMux_05;
 assign original_raw[85] = original.u_k14.dout_r;
 assign data_bits[86] = original.RBMux_11;
 assign original_raw[86] = original.u_k18.dout_r;
 assign data_bits[87] = original.RBMux_02;
 assign original_raw[87] = original.u_l08.dout_r;
 assign data_bits[88] = original.RBMux_06;
 assign original_raw[88] = original.u_l14.dout_r;
 assign data_bits[89] = original.RBMux_12;
 assign original_raw[89] = original.u_l18.dout_r;
 assign addresses[50+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[5] = original.CS2_p_ACa;
 assign we_n[5] = original.WER_p_Ca;
 assign candidate_raw[90+:18] = candidate.snapshot_bank_5.logical_q;
 assign data_bits[90] = original.RBMux_00;
 assign original_raw[90] = original.u_a14.dout_r;
 assign data_bits[91] = original.RBMux_04;
 assign original_raw[91] = original.u_a18.dout_r;
 assign data_bits[92] = original.RBMux_01;
 assign original_raw[92] = original.u_b14.dout_r;
 assign data_bits[93] = original.RBMux_05;
 assign original_raw[93] = original.u_b18.dout_r;
 assign data_bits[94] = original.RBMux_02;
 assign original_raw[94] = original.u_c14.dout_r;
 assign data_bits[95] = original.RBMux_06;
 assign original_raw[95] = original.u_c18.dout_r;
 assign data_bits[96] = original.RBMux_03;
 assign original_raw[96] = original.u_d14.dout_r;
 assign data_bits[97] = original.RBMux_07;
 assign original_raw[97] = original.u_d18.dout_r;
 assign data_bits[98] = original.RBMux_08;
 assign original_raw[98] = original.u_e08.dout_r;
 assign data_bits[99] = original.RBMux_09;
 assign original_raw[99] = original.u_e14.dout_r;
 assign data_bits[100] = original.RBMuxP;
 assign original_raw[100] = original.u_e18.dout_r;
 assign data_bits[101] = original.RBMux_10;
 assign original_raw[101] = original.u_f14.dout_r;
 assign data_bits[102] = original.ContB04_sil_pl_1;
 assign original_raw[102] = original.u_f18.dout_r;
 assign data_bits[103] = original.RBMux_11;
 assign original_raw[103] = original.u_g14.dout_r;
 assign data_bits[104] = original.RBMux_13;
 assign original_raw[104] = original.u_g18.dout_r;
 assign data_bits[105] = original.RBMux_12;
 assign original_raw[105] = original.u_h14.dout_r;
 assign data_bits[106] = original.RBMux_14;
 assign original_raw[106] = original.u_h18.dout_r;
 assign data_bits[107] = original.RBMux_15;
 assign original_raw[107] = original.u_i18.dout_r;
 assign addresses[60+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[6] = original.CS3_p_ACa;
 assign we_n[6] = original.WEL_p_Aa;
 assign candidate_raw[108+:18] = candidate.snapshot_bank_6.logical_q;
 assign data_bits[108] = original.RBMux_13;
 assign original_raw[108] = original.u_a09.dout_r;
 assign data_bits[109] = original.RBMux_14;
 assign original_raw[109] = original.u_b09.dout_r;
 assign data_bits[110] = original.RBMux_15;
 assign original_raw[110] = original.u_c09.dout_r;
 assign data_bits[111] = original.RBMuxP;
 assign original_raw[111] = original.u_d09.dout_r;
 assign data_bits[112] = original.RBMux_07;
 assign original_raw[112] = original.u_f09.dout_r;
 assign data_bits[113] = original.RBMux_08;
 assign original_raw[113] = original.u_g09.dout_r;
 assign data_bits[114] = original.RBMux_09;
 assign original_raw[114] = original.u_h09.dout_r;
 assign data_bits[115] = original.MidasOrRSTK_2;
 assign original_raw[115] = original.u_i09.dout_r;
 assign data_bits[116] = original.RBMux_03;
 assign original_raw[116] = original.u_i15.dout_r;
 assign data_bits[117] = original.RBMux_00;
 assign original_raw[117] = original.u_j09.dout_r;
 assign data_bits[118] = original.RBMux_04;
 assign original_raw[118] = original.u_j15.dout_r;
 assign data_bits[119] = original.RBMux_10;
 assign original_raw[119] = original.u_j19.dout_r;
 assign data_bits[120] = original.RBMux_01;
 assign original_raw[120] = original.u_k09.dout_r;
 assign data_bits[121] = original.RBMux_05;
 assign original_raw[121] = original.u_k15.dout_r;
 assign data_bits[122] = original.RBMux_11;
 assign original_raw[122] = original.u_k19.dout_r;
 assign data_bits[123] = original.RBMux_02;
 assign original_raw[123] = original.u_l09.dout_r;
 assign data_bits[124] = original.RBMux_06;
 assign original_raw[124] = original.u_l15.dout_r;
 assign data_bits[125] = original.RBMux_12;
 assign original_raw[125] = original.u_l19.dout_r;
 assign addresses[70+:10] = {original.RA_01a, original.RA_02a, original.RA_03a, original.RA_04a, original.RA_05a, original.RA_06a, original.RA_07a, original.RA_08a, original.RA_09a, original.RA_10a};
 assign ce_n[7] = original.CS3_p_ACa;
 assign we_n[7] = original.WER_p_Ca;
 assign candidate_raw[126+:18] = candidate.snapshot_bank_7.logical_q;
 assign data_bits[126] = original.RBMux_00;
 assign original_raw[126] = original.u_a15.dout_r;
 assign data_bits[127] = original.RBMux_04;
 assign original_raw[127] = original.u_a19.dout_r;
 assign data_bits[128] = original.RBMux_01;
 assign original_raw[128] = original.u_b15.dout_r;
 assign data_bits[129] = original.RBMux_05;
 assign original_raw[129] = original.u_b19.dout_r;
 assign data_bits[130] = original.RBMux_02;
 assign original_raw[130] = original.u_c15.dout_r;
 assign data_bits[131] = original.RBMux_06;
 assign original_raw[131] = original.u_c19.dout_r;
 assign data_bits[132] = original.RBMux_03;
 assign original_raw[132] = original.u_d15.dout_r;
 assign data_bits[133] = original.RBMux_07;
 assign original_raw[133] = original.u_d19.dout_r;
 assign data_bits[134] = original.RBMux_08;
 assign original_raw[134] = original.u_e09.dout_r;
 assign data_bits[135] = original.RBMux_09;
 assign original_raw[135] = original.u_e15.dout_r;
 assign data_bits[136] = original.RBMuxP;
 assign original_raw[136] = original.u_e19.dout_r;
 assign data_bits[137] = original.RBMux_10;
 assign original_raw[137] = original.u_f15.dout_r;
 assign data_bits[138] = original.ContB04_sil_pl_1;
 assign original_raw[138] = original.u_f19.dout_r;
 assign data_bits[139] = original.RBMux_11;
 assign original_raw[139] = original.u_g15.dout_r;
 assign data_bits[140] = original.RBMux_13;
 assign original_raw[140] = original.u_g19.dout_r;
 assign data_bits[141] = original.RBMux_12;
 assign original_raw[141] = original.u_h15.dout_r;
 assign data_bits[142] = original.RBMux_14;
 assign original_raw[142] = original.u_h19.dout_r;
 assign data_bits[143] = original.RBMux_15;
 assign original_raw[143] = original.u_i19.dout_r;
endmodule
