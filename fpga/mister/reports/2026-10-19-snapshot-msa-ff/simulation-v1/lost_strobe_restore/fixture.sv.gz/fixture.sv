module msa_ff_fixture(input wire host_clk,ref_clk,advance,hold,write,
 input wire [2:0] selected,input wire [17:0] data,
 input wire [31:0] pins[4],output wire [17:0] physical[4],original_state[4],result[4],
 output wire [15:0] outputs[4],original_outputs[4]);
begin:case0
cell_SN74166_msa_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==3'd0),.state_data(data),.state_result(result[0]),.sys_clk(ref_clk),.p2(pins[0][1]),.p3(pins[0][2]),.p4(pins[0][3]),.p5(pins[0][4]),.p10(pins[0][9]),.p11(pins[0][10]),.p12(pins[0][11]),.p14(pins[0][13]),.p1(pins[0][0]),.p15(pins[0][14]),.p6(pins[0][5]),.p7(pins[0][6]),.p9(pins[0][8]),.p8(pins[0][7]),.p16(pins[0][15]),.p13(outputs[0][0]));
cell_SN74166 ref_i(.sys_clk(ref_clk),.p2(pins[0][1]),.p3(pins[0][2]),.p4(pins[0][3]),.p5(pins[0][4]),.p10(pins[0][9]),.p11(pins[0][10]),.p12(pins[0][11]),.p14(pins[0][13]),.p1(pins[0][0]),.p15(pins[0][14]),.p6(pins[0][5]),.p7(pins[0][6]),.p9(pins[0][8]),.p8(pins[0][7]),.p16(pins[0][15]),.p13(original_outputs[0][0]));
assign physical[0]={{9{1'b0}},{cell_i.ck_d,cell_i.q}};
assign original_state[0]={{9{1'b0}},{ref_i.ck_d,ref_i.q}};
assign outputs[0][15:1]=0;assign original_outputs[0][15:1]=0;
end
begin:case1
cell_SN74S174_msa_snapshot cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==3'd1),.state_data(data),.state_result(result[1]),.sys_clk(ref_clk),.p1(pins[1][0]),.p3(pins[1][2]),.p4(pins[1][3]),.p6(pins[1][5]),.p8(pins[1][7]),.p9(pins[1][8]),.p11(pins[1][10]),.p13(pins[1][12]),.p14(pins[1][13]),.p16(pins[1][15]),.p2(outputs[1][0]),.p5(outputs[1][1]),.p7(outputs[1][2]),.p10(outputs[1][3]),.p12(outputs[1][4]),.p15(outputs[1][5]));
cell_SN74S174 ref_i(.sys_clk(ref_clk),.p1(pins[1][0]),.p3(pins[1][2]),.p4(pins[1][3]),.p6(pins[1][5]),.p8(pins[1][7]),.p9(pins[1][8]),.p11(pins[1][10]),.p13(pins[1][12]),.p14(pins[1][13]),.p16(pins[1][15]),.p2(original_outputs[1][0]),.p5(original_outputs[1][1]),.p7(original_outputs[1][2]),.p10(original_outputs[1][3]),.p12(original_outputs[1][4]),.p15(original_outputs[1][5]));
assign physical[1]={{11{1'b0}},{cell_i.ck_d,cell_i.q}};
assign original_state[1]={{11{1'b0}},{ref_i.ck_d,ref_i.q}};
assign outputs[1][15:6]=0;assign original_outputs[1][15:6]=0;
end
begin:case2
cell_MK4096P_addr_msa_snapshot #(.ROW_BITS(7)) cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==3'd2),.state_data(data),.state_result(result[2]),.sys_clk(ref_clk),.p4(pins[2][3]),.p15(pins[2][14]),.a(pins[2][22:16]),.addr(outputs[2][13:0]));
cell_MK4096P_addr #(.ROW_BITS(7)) ref_i(.sys_clk(ref_clk),.p4(pins[2][3]),.p15(pins[2][14]),.a(pins[2][22:16]),.addr(original_outputs[2][13:0]));
assign physical[2]={{2{1'b0}},{cell_i.cas_d,cell_i.ras_d,cell_i.col,cell_i.row}};
assign original_state[2]={{2{1'b0}},{ref_i.cas_d,ref_i.ras_d,ref_i.col,ref_i.row}};
assign outputs[2][15:14]=0;assign original_outputs[2][15:14]=0;
end
begin:case3
cell_MK4096P_addr_msa_snapshot #(.ROW_BITS(8)) cell_i(.state_host_clk(host_clk),.state_advance(advance),.state_hold(hold),.state_write(write && selected==3'd3),.state_data(data),.state_result(result[3]),.sys_clk(ref_clk),.p4(pins[3][3]),.p15(pins[3][14]),.a(pins[3][23:16]),.addr(outputs[3][15:0]));
cell_MK4096P_addr #(.ROW_BITS(8)) ref_i(.sys_clk(ref_clk),.p4(pins[3][3]),.p15(pins[3][14]),.a(pins[3][23:16]),.addr(original_outputs[3][15:0]));
assign physical[3]={{0{1'b0}},{cell_i.cas_d,cell_i.ras_d,cell_i.col,cell_i.row}};
assign original_state[3]={{0{1'b0}},{ref_i.cas_d,ref_i.ras_d,ref_i.col,ref_i.row}};
end
endmodule
