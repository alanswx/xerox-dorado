`timescale 1ns/1ps
`default_nettype none
module t_file_procl(input wire fixture_load,input wire [177:0] fixture_state,
 input wire base,start_a,en,input wire [126:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,
 output wire [177:0] state_q,output wire [8:0] clocks,
 output wire [4:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock0'Bd
 wire n15; // Clock0'Da
 wire n16; // Clock0'Db
 wire n17; // Clock0'Dc
 wire n18; // Clock1'Ba
 wire n19; // Clock1'Bb
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Da
 wire n23; // Clock1'Db
 wire n24; // Clock1'Dc
 wire n25; // Clock1Bd
 wire n26; // Curr.0'
 wire n27; // Curr.1'
 wire n28; // Curr.2'
 wire n29; // Curr.3'
 wire n30; // Curr=Next'
 wire n31; // CurrLast.0'
 wire n32; // CurrLast.1'
 wire n33; // CurrLast.2'
 wire n34; // CurrLast.3'
 wire n35; // DblClock'Ba
 wire n36; // DblClock'Bc
 wire n37; // FA=0'b
 wire n38; // FB=2'
 wire n39; // FB=3'
 wire n40; // FB=7'
 wire n41; // FC=4/5'
 wire n42; // FC=5'
 wire n43; // FC=6'
 wire n44; // GND132
 wire n45; // GND264
 wire n46; // GND266
 wire n47; // GND312
 wire n48; // GND314
 wire n49; // GND394
 wire n50; // GND40
 wire n51; // GND442
 wire n52; // GND468
 wire n53; // GND500
 wire n54; // GND530
 wire n55; // Hold
 wire n56; // Hold'
 wire n57; // HoldDly
 wire n58; // Holda
 wire n59; // IOB.Perr'
 wire n60; // IOBin'
 wire n61; // IOBout
 wire n62; // IOin'
 wire n63; // IfuData.0
 wire n64; // IfuData.1
 wire n65; // IfuData.2
 wire n66; // IfuData.3
 wire n67; // IfuData.4
 wire n68; // IfuData.5
 wire n69; // IfuData.6
 wire n70; // IfuData.7
 wire n71; // LC.0
 wire n72; // LC.1
 wire n73; // LC.1'a
 wire n74; // LC.1a
 wire n75; // LC.2
 wire n76; // LScopeFH
 wire n77; // Last.0'
 wire n78; // Last.1'
 wire n79; // Last.2'
 wire n80; // Last.3'
 wire n81; // Last=Curr'
 wire n82; // LastNext.0'
 wire n83; // LastNext.1'
 wire n84; // LastNext.2'
 wire n85; // LastNext.3'
 wire n86; // Next.0
 wire n87; // Next.0'
 wire n88; // Next.1
 wire n89; // Next.1'
 wire n90; // Next.2
 wire n91; // Next.2'
 wire n92; // Next.3
 wire n93; // Next.3'
 wire n94; // PRhold
 wire n95; // Pdata.08
 wire n96; // Pdata.09
 wire n97; // Pdata.10
 wire n98; // Pdata.11
 wire n99; // Pdata.12
 wire n100; // Pdata.13
 wire n101; // Pdata.14
 wire n102; // Pdata.15
 wire n103; // PreClock0'A
 wire n104; // PreClock0'B
 wire n105; // PreClock0'C
 wire n106; // PreClock0'D
 wire n107; // PreClock1'A
 wire n108; // PreClock1'B
 wire n109; // PreClock1'C
 wire n110; // PreClock1'D
 wire n111; // PreClock1B
 wire n112; // PreDblClock'B
 wire n113; // PreSHCP'A
 wire n114; // PreSHCP'B
 wire n115; // PreSHCP'C
 wire n116; // PreSHCP'Shc
 wire n117; // PreSHSelect'D
 wire n118; // ProcL02.sil+5
 wire n119; // ProcL03.sil+5
 wire n120; // ProcL04.sil+5
 wire n121; // ProcL05.sil+5
 wire n122; // ProcL06.sil+5
 wire n123; // ProcL07.sil+5
 wire n124; // ProcL08.sil+5
 wire n125; // ProcL09.sil+4
 wire n126; // ProcL10.sil+1
 wire n127; // ProcL11.sil+7
 wire n128; // ProcL12.sil+1
 wire n129; // ProcL12.sil+3
 wire n130; // ProcL12.sil+4
 wire n131; // ProcL12.sil+5
 wire n132; // ProcL12.sil+6
 wire n133; // ProcL15.sil+1
 wire n134; // ProcL20.sil+1
 wire n135; // ProcL20.sil+3
 wire n136; // ProcL20.sil+4
 wire n137; // ProcL20.sil+5
 wire n138; // ProcL20.sil+6
 wire n139; // ProcL20.sil+7
 wire n140; // ProcL24.sil+14
 wire n141; // ProcL26.sil+1
 wire n142; // ProcL27.sil+10
 wire n143; // ProcL27.sil+11
 wire n144; // ProcL27.sil+3
 wire n145; // ProcL27.sil+4
 wire n146; // ProcL27.sil+5
 wire n147; // ProcL27.sil+8
 wire n148; // ProcL27.sil+9
 wire n149; // ProcL30.sil+1
 wire n150; // RbSelMd
 wire n151; // RbSelMd'
 wire n152; // RbWrite'a
 wire n153; // RbWrite'b
 wire n154; // RbWrite'c
 wire n155; // RbWriteEn'
 wire n156; // RepeatCurrB
 wire n157; // RepeatCurrC
 wire n158; // RepeatCurrD
 wire n159; // SHCP'C
 wire n160; // SHSelect'C
 wire n161; // SimHoldReq'
 wire n162; // StartCycle'a
 wire n163; // StkWSel'
 wire n164; // T.08
 wire n165; // T.09
 wire n166; // T.10
 wire n167; // T.11
 wire n168; // T.12
 wire n169; // T.13
 wire n170; // T.14
 wire n171; // T.15
 wire n172; // TbBypass
 wire n173; // TbSelMd
 wire n174; // TbWrite'a
 wire n175; // TbWrite'b
 wire n176; // TbWriteEn'
 wire n177; // TisIFdata
 wire n178; // TrueA
 wire n179; // _MDSaved
 wire n180; // dMD.08
 wire n181; // dMD.09
 wire n182; // dMD.10
 wire n183; // dMD.11
 wire n184; // dMD.12
 wire n185; // dMD.13
 wire n186; // dMD.14
 wire n187; // dMD.15
 wire n188; // dT.08
 wire n189; // dT.09
 wire n190; // dT.10
 wire n191; // dT.11
 wire n192; // dT.12
 wire n193; // dT.13
 wire n194; // dT.14
 wire n195; // dT.15
 wire n196; // dTm.08
 wire n197; // dTm.09
 wire n198; // dTm.10
 wire n199; // dTm.11
 wire n200; // dTm.12
 wire n201; // dTm.13
 wire n202; // dTm.14
 wire n203; // dTm.15
 wire n204; // pClk1En'
 wire n205; // ppClk'a
 wire n206; // ppClk'b
 wire n207; // ppClk'c
 assign n44=1'b0;
 assign n45=1'b0;
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n49=1'b0;
 assign n50=1'b0;
 assign n51=1'b0;
 assign n52=1'b0;
 assign n53=1'b0;
 assign n54=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n37=(pins[19:18]!=2'd0);
 assign n38=(pins[17:15]!=3'd2);
 assign n39=(pins[17:15]!=3'd3);
 assign n40=(pins[17:15]!=3'd7);
 assign n41=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n42=(pins[14:12]!=3'd5);
 assign n43=(pins[14:12]!=3'd6);
 assign n58=pins[68];
 assign n60=1'b0;
 assign n61=1'b0;
 assign n63=pins[119];
 assign n64=pins[120];
 assign n65=pins[121];
 assign n66=pins[122];
 assign n67=pins[123];
 assign n68=pins[124];
 assign n69=pins[125];
 assign n70=pins[126];
 assign n71=pins[11];
 assign n72=pins[10];
 assign n75=pins[9];
 assign n86=next_raw[0];
 assign n88=next_raw[1];
 assign n90=next_raw[2];
 assign n92=next_raw[3];
 assign n94=pins[68];
 assign n95=pins[84];
 assign n96=pins[85];
 assign n97=pins[86];
 assign n98=pins[87];
 assign n99=pins[88];
 assign n100=pins[89];
 assign n101=pins[90];
 assign n102=pins[91];
 assign n139=pins[116];
 assign n140=pins[115];
 assign n141=1'b0;
 assign n142=pins[112];
 assign n143=1'b0;
 assign n147=pins[113];
 assign n148=pins[114];
 assign n162=start_a;
 assign n177=pins[117];
 assign n180=pins[100];
 assign n181=pins[101];
 assign n182=pins[102];
 assign n183=pins[103];
 assign n184=pins[104];
 assign n185=pins[105];
 assign n186=pins[106];
 assign n187=pins[107];
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_k10_3;
 assign n14=n14_k10_3;
 wire n15_j18_3;
 assign n15=n15_j18_3;
 wire n16_j18_2;
 assign n16=n16_j18_2;
 wire n17_j18_4;
 assign n17=n17_j18_4;
 wire n18_i05_3;
 assign n18=n18_i05_3;
 wire n19_i05_4;
 assign n19=n19_i05_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_j18_13;
 assign n22=n22_j18_13;
 wire n23_j18_14;
 assign n23=n23_j18_14;
 wire n24_j18_12;
 assign n24=n24_j18_12;
 wire n25_i05_2;
 assign n25=n25_i05_2;
 wire n26_a21_14;
 assign n26=n26_a21_14;
 wire n27_a21_15;
 assign n27=n27_a21_15;
 wire n28_a21_2;
 assign n28=n28_a21_2;
 wire n29_a21_3;
 assign n29=n29_a21_3;
 wire n30_a22_2;
 wire n30_a22_3;
 wire n30_a22_15;
 wire n30_a22_14;
 assign n30=n30_a22_2 | n30_a22_3 | n30_a22_15 | n30_a22_14;
 wire n31_i14_14;
 assign n31=n31_i14_14;
 wire n32_i14_15;
 assign n32=n32_i14_15;
 wire n33_i14_2;
 assign n33=n33_i14_2;
 wire n34_i14_3;
 assign n34=n34_i14_3;
 wire n35_k10_13;
 assign n35=n35_k10_13;
 wire n36_k10_14;
 assign n36=n36_k10_14;
 wire n55_f19_15;
 assign n55=n55_f19_15;
 wire n56_f19_14;
 assign n56=n56_f19_14;
 wire n57_g18_15;
 assign n57=n57_g18_15;
 wire n59_g23_14;
 assign n59=n59_g23_14;
 wire n62_g23_9;
 assign n62=n62_g23_9;
 wire n73_h24_15;
 assign n73=n73_h24_15;
 wire n74_h24_9;
 assign n74=n74_h24_9;
 wire n76_c18_14;
 assign n76=n76_c18_14;
 wire n77_a20_14;
 assign n77=n77_a20_14;
 wire n78_a20_15;
 assign n78=n78_a20_15;
 wire n79_a20_2;
 assign n79=n79_a20_2;
 wire n80_a20_3;
 assign n80=n80_a20_3;
 wire n81_d17_15;
 assign n81=n81_d17_15;
 wire n82_a19_1;
 assign n82=n82_a19_1;
 wire n83_a19_2;
 assign n83=n83_a19_2;
 wire n84_a19_15;
 assign n84=n84_a19_15;
 wire n85_a19_14;
 assign n85=n85_a19_14;
 wire n87_a24_15;
 assign n87=n87_a24_15;
 wire n89_a24_14;
 assign n89=n89_a24_14;
 wire n91_a24_3;
 assign n91=n91_a24_3;
 wire n93_a24_2;
 assign n93=n93_a24_2;
 wire n103_f13_13;
 assign n103=n103_f13_13;
 wire n104_f13_12;
 assign n104=n104_f13_12;
 wire n105_f13_14;
 assign n105=n105_f13_14;
 wire n106_g13_3;
 assign n106=n106_g13_3;
 wire n107_f12_14;
 assign n107=n107_f12_14;
 wire n108_f13_2;
 assign n108=n108_f13_2;
 wire n109_f13_4;
 assign n109=n109_f13_4;
 wire n110_f13_3;
 assign n110=n110_f13_3;
 wire n111_f12_13;
 assign n111=n111_f12_13;
 wire n112_g13_13;
 assign n112=n112_g13_13;
 wire n113_g12_3;
 assign n113=n113_g12_3;
 wire n114_g12_2;
 assign n114=n114_g12_2;
 wire n115_g12_4;
 assign n115=n115_g12_4;
 wire n116_f12_4;
 assign n116=n116_f12_4;
 wire n117_f12_3;
 assign n117=n117_f12_3;
 wire n118_l03_2;
 assign n118=n118_l03_2;
 wire n119_l03_1;
 assign n119=n119_l03_1;
 wire n120_l03_15;
 assign n120=n120_l03_15;
 wire n121_l03_14;
 assign n121=n121_l03_14;
 wire n122_l04_2;
 assign n122=n122_l04_2;
 wire n123_l04_1;
 assign n123=n123_l04_1;
 wire n124_l04_15;
 assign n124=n124_l04_15;
 wire n125_l04_14;
 assign n125=n125_l04_14;
 wire n126_f20_2;
 assign n126=n126_f20_2;
 wire n127_f20_3;
 assign n127=n127_f20_3;
 wire n128_a24_9;
 wire n128_a24_11;
 wire n128_a24_6;
 wire n128_a24_5;
 assign n128=n128_a24_9 | n128_a24_11 | n128_a24_6 | n128_a24_5;
 wire n129_a18_2;
 assign n129=n129_a18_2;
 wire n130_a18_1;
 assign n130=n130_a18_1;
 wire n131_a18_15;
 assign n131=n131_a18_15;
 wire n132_a18_14;
 assign n132=n132_a18_14;
 wire n133_f20_14;
 assign n133=n133_f20_14;
 wire n134_f20_15;
 wire n134_g23_3;
 assign n134=n134_f20_15 | n134_g23_3;
 wire n135_h23_2;
 assign n135=n135_h23_2;
 wire n136_h23_3;
 assign n136=n136_h23_3;
 wire n137_h23_14;
 assign n137=n137_h23_14;
 wire n138_g23_2;
 assign n138=n138_g23_2;
 wire n144_g18_3;
 assign n144=n144_g18_3;
 wire n145_g18_4;
 assign n145=n145_g18_4;
 wire n146_g18_2;
 assign n146=n146_g18_2;
 wire n149_f12_2;
 assign n149=n149_f12_2;
 wire n150_d17_3;
 assign n150=n150_d17_3;
 wire n151_d17_2;
 assign n151=n151_d17_2;
 wire n152_j05_13;
 assign n152=n152_j05_13;
 wire n153_j05_12;
 assign n153=n153_j05_12;
 wire n154_j05_14;
 assign n154=n154_j05_14;
 wire n155_d17_13;
 assign n155=n155_d17_13;
 wire n156_g12_13;
 assign n156=n156_g12_13;
 wire n157_g12_12;
 assign n157=n157_g12_12;
 wire n158_g12_14;
 assign n158=n158_g12_14;
 wire n159_c18_13;
 assign n159=n159_c18_13;
 wire n160_c18_12;
 assign n160=n160_c18_12;
 wire n161_a01_3;
 assign n161=n161_a01_3;
 wire n163_g18_13;
 assign n163=n163_g18_13;
 wire n164_i03_1;
 assign n164=n164_i03_1;
 wire n165_i03_2;
 assign n165=n165_i03_2;
 wire n166_i03_15;
 assign n166=n166_i03_15;
 wire n167_i03_14;
 assign n167=n167_i03_14;
 wire n168_i04_1;
 assign n168=n168_i04_1;
 wire n169_i04_2;
 assign n169=n169_i04_2;
 wire n170_i04_15;
 assign n170=n170_i04_15;
 wire n171_i04_14;
 assign n171=n171_i04_14;
 wire n172_f19_3;
 assign n172=n172_f19_3;
 wire n173_d17_4;
 assign n173=n173_d17_4;
 wire n174_j05_3;
 assign n174=n174_j05_3;
 wire n175_j05_2;
 assign n175=n175_j05_2;
 wire n176_d17_14;
 assign n176=n176_d17_14;
 wire n178_a01_14;
 assign n178=n178_a01_14;
 wire n179_g18_14;
 assign n179=n179_g18_14;
 wire n188_j03_1;
 assign n188=n188_j03_1;
 wire n189_j03_2;
 assign n189=n189_j03_2;
 wire n190_j03_15;
 assign n190=n190_j03_15;
 wire n191_j03_14;
 assign n191=n191_j03_14;
 wire n192_j04_1;
 assign n192=n192_j04_1;
 wire n193_j04_2;
 assign n193=n193_j04_2;
 wire n194_j04_15;
 assign n194=n194_j04_15;
 wire n195_j04_14;
 assign n195=n195_j04_14;
 wire n196_k01_1;
 assign n196=n196_k01_1;
 wire n197_k01_2;
 assign n197=n197_k01_2;
 wire n198_k01_15;
 assign n198=n198_k01_15;
 wire n199_k01_14;
 assign n199=n199_k01_14;
 wire n200_k02_1;
 assign n200=n200_k02_1;
 wire n201_k02_2;
 assign n201=n201_k02_2;
 wire n202_k02_15;
 assign n202=n202_k02_15;
 wire n203_k02_14;
 assign n203=n203_k02_14;
 wire n204_l02_2;
 assign n204=n204_l02_2;
 wire n205_l01_13;
 assign n205=n205_l01_13;
 wire n206_l01_12;
 assign n206=n206_l01_12;
 wire n207_l01_14;
 assign n207=n207_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n161_a01_3),.p4(n1),.p5(1'b0),.p6(n141),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n178_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n130_a18_1),.p2(n129_a18_2),.p3(n83),.p4(n27),.p5(n82),.p6(n26),.p9(n157),.p10(n85),.p11(n29),.p12(n84),.p13(n28),.p14(n132_a18_14),.p15(n131_a18_15));
 cell_MC10158 a19(.p1(n82_a19_1),.p2(n83_a19_2),.p3(n89),.p4(n78),.p5(n87),.p6(n77),.p9(n115),.p10(n93),.p11(n80),.p12(n91),.p13(n79),.p14(n85_a19_14),.p15(n84_a19_15));
 original_MC10141 a20(.p1(n50),.p2(n79_a20_2),.p3(n80_a20_3),.p4(n20),.p5(1'b0),.p6(n29),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n26),.p13(1'b0),.p14(n77_a20_14),.p15(n78_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n28_a21_2),.p3(n29_a21_3),.p4(n159),.p5(1'b0),.p6(n93),.p7(n157),.p8(1'b0),.p9(n91),.p10(n157),.p11(n89),.p12(n87),.p13(1'b0),.p14(n26_a21_14),.p15(n27_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n30_a22_2),.p3(n30_a22_3),.p4(n29),.p5(n93),.p6(n91),.p7(n28),.p9(1'b0),.p10(n89),.p11(n27),.p12(n87),.p13(n26),.p14(n30_a22_14),.p15(n30_a22_15));
 cell_MC10101 a24(.p2(n93_a24_2),.p3(n91_a24_3),.p4(n92),.p5(n128_a24_5),.p6(n128_a24_6),.p7(n90),.p9(n128_a24_9),.p10(n88),.p11(n128_a24_11),.p12(1'b0),.p13(n86),.p14(n89_a24_14),.p15(n87_a24_15));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p5(n109),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n115),.p10(1'b0),.p11(1'b0),.p12(n160_c18_12),.p13(n159_c18_13),.p14(n76_c18_14),.p15(n44),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n151_d17_2),.p3(n150_d17_3),.p4(n173_d17_4),.p5(n74),.p6(n73),.p7(n134),.p8(1'b0),.p9(n159),.p10(n137),.p11(n138),.p12(n30),.p13(n155_d17_13),.p14(n176_d17_14),.p15(n81_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n149_f12_2),.p3(n117_f12_3),.p4(n116_f12_4),.p5(n204),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n149),.p10(1'b0),.p11(n205),.p13(n111_f12_13),.p14(n107_f12_14),.p15(n45),.p16(1'b0));
 cell_SE10210 f13(.p2(n108_f13_2),.p3(n110_f13_3),.p4(n109_f13_4),.p5(n206),.p6(1'b0),.p7(n149),.p8(1'b0),.p9(n206),.p10(n13),.p11(1'b0),.p12(n104_f13_12),.p13(n103_f13_13),.p14(n105_f13_14),.p15(n46),.p16(1'b0));
 cell_MC1660 f19(.p3(n172_f19_3),.p4(n57),.p5(n81),.p6(n176),.p7(n177),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n94),.p14(n56_f19_14),.p15(n55_f19_15));
 cell_MC10100 f20(.p2(n126_f20_2),.p3(n127_f20_3),.p4(n43),.p5(n38),.p6(n41),.p7(n38),.p9(n37),.p10(n43),.p11(n39),.p12(n42),.p13(n40),.p14(n133_f20_14),.p15(n134_f20_15));
 cell_SE10211 g12(.p2(n114_g12_2),.p3(n113_g12_3),.p4(n115_g12_4),.p5(1'b0),.p6(n204),.p7(1'b0),.p9(n0),.p10(n56),.p11(1'b0),.p12(n157_g12_12),.p13(n156_g12_13),.p14(n158_g12_14),.p15(n47),.p16(1'b0));
 cell_SE10210 g13(.p3(n106_g13_3),.p5(n207),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n207),.p10(1'b0),.p11(1'b0),.p13(n112_g13_13),.p15(n48),.p16(1'b0));
 original_MC10176 g18(.p1(1'b0),.p2(n146_g18_2),.p3(n144_g18_3),.p4(n145_g18_4),.p5(n142),.p6(n147),.p7(n148),.p8(1'b0),.p9(n16),.p10(n140),.p11(n139),.p12(n58),.p13(n163_g18_13),.p14(n179_g18_14),.p15(n57_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10102 g23(.p1(1'b0),.p2(n138_g23_2),.p3(n134_g23_3),.p4(n75),.p5(n136),.p6(n71),.p7(n73),.p9(n62_g23_9),.p10(n61),.p11(n143),.p12(n55),.p13(n60),.p14(n59_g23_14),.p16(1'b0));
 cell_MC10102 h23(.p1(1'b0),.p2(n135_h23_2),.p3(n136_h23_3),.p4(n73),.p5(n75),.p6(n71),.p7(n73),.p9(n10_h23_9),.p10(n71),.p11(n135),.p12(n6),.p13(n9),.p14(n137_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n74_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n72),.p14(n9_h24_14),.p15(n73_h24_15));
 original_MC10173 i03(.p1(n164_i03_1),.p2(n165_i03_2),.p3(n189),.p4(n197),.p5(n188),.p6(n196),.p7(n114),.p9(n172),.p10(n191),.p11(n199),.p12(n190),.p13(n198),.p14(n167_i03_14),.p15(n166_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 original_MC10173 i04(.p1(n168_i04_1),.p2(n169_i04_2),.p3(n193),.p4(n201),.p5(n192),.p6(n200),.p7(n114),.p9(n172),.p10(n195),.p11(n203),.p12(n194),.p13(n202),.p14(n171_i04_14),.p15(n170_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 cell_SE10212 i05(.p1(1'b0),.p2(n25_i05_2),.p3(n18_i05_3),.p4(n19_i05_4),.p5(1'b0),.p6(1'b0),.p7(n111),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n49),.p16(1'b0));
 original_MC10141 i14(.p1(1'b0),.p2(n33_i14_2),.p3(n34_i14_3),.p4(n36),.p5(1'b0),.p6(n132),.p7(1'b0),.p8(1'b0),.p9(n131),.p10(1'b0),.p11(n129),.p12(n130),.p13(1'b0),.p14(n31_i14_14),.p15(n32_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 original_MC10173 j03(.p1(n188_j03_1),.p2(n189_j03_2),.p3(n119),.p4(n64),.p5(n118),.p6(n63),.p7(n19),.p9(n177),.p10(n121),.p11(n66),.p12(n120),.p13(n65),.p14(n191_j03_14),.p15(n190_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 original_MC10173 j04(.p1(n192_j04_1),.p2(n193_j04_2),.p3(n123),.p4(n68),.p5(n122),.p6(n67),.p7(n19),.p9(n177),.p10(n125),.p11(n70),.p12(n124),.p13(n69),.p14(n195_j04_14),.p15(n194_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 cell_SE10210 j05(.p2(n175_j05_2),.p3(n174_j05_3),.p5(n104),.p6(n57),.p7(n176),.p8(1'b0),.p9(n104),.p10(n57),.p11(n155),.p12(n153_j05_12),.p13(n152_j05_13),.p14(n154_j05_14),.p15(n51),.p16(1'b0));
 cell_SE10210 j18(.p2(n16_j18_2),.p3(n15_j18_3),.p4(n17_j18_4),.p5(n106),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n110),.p10(1'b0),.p11(1'b0),.p12(n24_j18_12),.p13(n22_j18_13),.p14(n23_j18_14),.p15(n52),.p16(1'b0));
 original_MC10173 k01(.p1(n196_k01_1),.p2(n197_k01_2),.p3(n96),.p4(n181),.p5(n95),.p6(n180),.p7(n18),.p9(n173),.p10(n98),.p11(n183),.p12(n97),.p13(n182),.p14(n199_k01_14),.p15(n198_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n200_k02_1),.p2(n201_k02_2),.p3(n100),.p4(n185),.p5(n99),.p6(n184),.p7(n18),.p9(n173),.p10(n102),.p11(n187),.p12(n101),.p13(n186),.p14(n203_k02_14),.p15(n202_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_SE10210 k10(.p3(n14_k10_3),.p5(n104),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n112),.p13(n35_k10_13),.p14(n36_k10_14),.p15(n53),.p16(1'b0));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n162),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n206_l01_12),.p13(n205_l01_13),.p14(n207_l01_14),.p15(n54),.p16(1'b0));
 original_SE10231 l02(.p2(n204_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n119_l03_1),.p2(n118_l03_2),.p3(1'b0),.p4(n197),.p5(n196),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n198),.p12(n199),.p13(n174),.p14(n121_l03_14),.p15(n120_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n123_l04_1),.p2(n122_l04_2),.p3(1'b0),.p4(n201),.p5(n200),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n202),.p12(n203),.p13(n174),.p14(n125_l04_14),.p15(n124_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n159;
 assign clocks[3]=n104;
 assign clocks[4]=n20;
 assign clocks[5]=n36;
 assign clocks[6]=n18;
 assign clocks[7]=n174;
 assign clocks[8]=n16;
 assign flags[0]=n157;
 assign flags[1]=n55;
 assign flags[2]=n30;
 assign flags[3]=n114;
 assign flags[4]=n172;
endmodule
`default_nettype wire
