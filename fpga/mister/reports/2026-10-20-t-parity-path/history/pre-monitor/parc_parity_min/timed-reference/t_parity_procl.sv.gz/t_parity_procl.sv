`timescale 1ns/1ps
`default_nettype none
module t_parity_procl(input wire fixture_load,input wire [245:0] fixture_state,
 input wire base,start_a,en,input wire [151:0] pins,input wire [3:0] next_raw,input wire priority_n,freeze,
 output wire [245:0] state_q,output wire [9:0] clocks,
 output wire [8:0] flags);
 wire n0; // BNTGtCT
 wire n1; // BNTGtCT'a
 wire n2; // BSEL.0'
 wire n3; // BSEL.1'
 wire n4; // BSEL.2'
 wire n5; // BSel.0'a
 wire n6; // BSel.0a
 wire n7; // BSel.1'a
 wire n8; // BSel.2'a
 wire n9; // BSel.2a
 wire n10; // BSel=0'
 wire n11; // CLK.pl'
 wire n12; // CLKEnable'b
 wire n13; // Clk0En'
 wire n14; // Clock0'Bd
 wire n15; // Clock0'Da
 wire n16; // Clock0'Db
 wire n17; // Clock0'Dc
 wire n18; // Clock1'Ba
 wire n19; // Clock1'Bb
 wire n20; // Clock1'Ca
 wire n21; // Clock1'Cb
 wire n22; // Clock1'Da
 wire n23; // Clock1'Db
 wire n24; // Clock1'Dc
 wire n25; // Clock1Bd
 wire n26; // Curr.0'
 wire n27; // Curr.1'
 wire n28; // Curr.2'
 wire n29; // Curr.3'
 wire n30; // Curr=Next'
 wire n31; // CurrLast.0'
 wire n32; // CurrLast.1'
 wire n33; // CurrLast.2'
 wire n34; // CurrLast.3'
 wire n35; // DblClock'Ba
 wire n36; // DblClock'Bc
 wire n37; // FA=0'b
 wire n38; // FB=2'
 wire n39; // FB=3'
 wire n40; // FB=7'
 wire n41; // FC=4/5'
 wire n42; // FC=5'
 wire n43; // FC=6'
 wire n44; // FF=030
 wire n45; // GND132
 wire n46; // GND264
 wire n47; // GND266
 wire n48; // GND312
 wire n49; // GND314
 wire n50; // GND394
 wire n51; // GND40
 wire n52; // GND442
 wire n53; // GND468
 wire n54; // GND500
 wire n55; // GND530
 wire n56; // Hold
 wire n57; // Hold'
 wire n58; // HoldDly
 wire n59; // Holda
 wire n60; // IOB.Perr'
 wire n61; // IOBin'
 wire n62; // IOBout
 wire n63; // IOin'
 wire n64; // IfuData.0
 wire n65; // IfuData.1
 wire n66; // IfuData.2
 wire n67; // IfuData.3
 wire n68; // IfuData.4
 wire n69; // IfuData.5
 wire n70; // IfuData.6
 wire n71; // IfuData.7
 wire n72; // IfuRBaseSel'
 wire n73; // LC.0
 wire n74; // LC.1
 wire n75; // LC.1'a
 wire n76; // LC.1a
 wire n77; // LC.2
 wire n78; // LScopeFH
 wire n79; // Last.0'
 wire n80; // Last.1'
 wire n81; // Last.2'
 wire n82; // Last.3'
 wire n83; // Last=Curr'
 wire n84; // LastNext.0'
 wire n85; // LastNext.1'
 wire n86; // LastNext.2'
 wire n87; // LastNext.3'
 wire n88; // Next.0
 wire n89; // Next.0'
 wire n90; // Next.1
 wire n91; // Next.1'
 wire n92; // Next.2
 wire n93; // Next.2'
 wire n94; // Next.3
 wire n95; // Next.3'
 wire n96; // PRhold
 wire n97; // Pdata.08
 wire n98; // Pdata.09
 wire n99; // Pdata.10
 wire n100; // Pdata.11
 wire n101; // Pdata.12
 wire n102; // Pdata.13
 wire n103; // Pdata.14
 wire n104; // Pdata.15
 wire n105; // PreClock0'A
 wire n106; // PreClock0'B
 wire n107; // PreClock0'C
 wire n108; // PreClock0'D
 wire n109; // PreClock1'A
 wire n110; // PreClock1'B
 wire n111; // PreClock1'C
 wire n112; // PreClock1'D
 wire n113; // PreClock1B
 wire n114; // PreDblClock'B
 wire n115; // PreSHCP'A
 wire n116; // PreSHCP'B
 wire n117; // PreSHCP'C
 wire n118; // PreSHCP'Shc
 wire n119; // PreSHSelect'D
 wire n120; // ProcL02.sil+5
 wire n121; // ProcL03.sil+5
 wire n122; // ProcL04.sil+5
 wire n123; // ProcL05.sil+5
 wire n124; // ProcL06.sil+5
 wire n125; // ProcL07.sil+5
 wire n126; // ProcL08.sil+5
 wire n127; // ProcL09.sil+4
 wire n128; // ProcL10.sil+1
 wire n129; // ProcL11.sil+7
 wire n130; // ProcL12.sil+1
 wire n131; // ProcL12.sil+3
 wire n132; // ProcL12.sil+4
 wire n133; // ProcL12.sil+5
 wire n134; // ProcL12.sil+6
 wire n135; // ProcL15.sil+1
 wire n136; // ProcL20.sil+1
 wire n137; // ProcL20.sil+3
 wire n138; // ProcL20.sil+4
 wire n139; // ProcL20.sil+5
 wire n140; // ProcL20.sil+6
 wire n141; // ProcL20.sil+7
 wire n142; // ProcL23.sil+10
 wire n143; // ProcL24.sil+13
 wire n144; // ProcL24.sil+14
 wire n145; // ProcL26.sil+1
 wire n146; // ProcL26.sil+3
 wire n147; // ProcL27.sil+1
 wire n148; // ProcL27.sil+10
 wire n149; // ProcL27.sil+11
 wire n150; // ProcL27.sil+3
 wire n151; // ProcL27.sil+4
 wire n152; // ProcL27.sil+5
 wire n153; // ProcL27.sil+6
 wire n154; // ProcL27.sil+7
 wire n155; // ProcL27.sil+8
 wire n156; // ProcL27.sil+9
 wire n157; // ProcL30.sil+1
 wire n158; // R.08
 wire n159; // R.09
 wire n160; // R.10
 wire n161; // R.11
 wire n162; // R.12
 wire n163; // R.13
 wire n164; // R.14
 wire n165; // R.15
 wire n166; // R.Perr'
 wire n167; // RbBypassDly
 wire n168; // RbSelMd
 wire n169; // RbSelMd'
 wire n170; // RbWrite'a
 wire n171; // RbWrite'b
 wire n172; // RbWrite'c
 wire n173; // RbWriteEn'
 wire n174; // RepeatCurrB
 wire n175; // RepeatCurrC
 wire n176; // RepeatCurrD
 wire n177; // RisIFdata
 wire n178; // Rparity
 wire n179; // SHCP'C
 wire n180; // SHSelect'C
 wire n181; // SHSelect'D
 wire n182; // SimHoldReq'
 wire n183; // StartCycle'a
 wire n184; // StkPSaveEn'
 wire n185; // StkPWriteEn'
 wire n186; // StkWSel'
 wire n187; // T.08
 wire n188; // T.09
 wire n189; // T.10
 wire n190; // T.11
 wire n191; // T.12
 wire n192; // T.13
 wire n193; // T.14
 wire n194; // T.15
 wire n195; // T.Perr'
 wire n196; // TbBypass
 wire n197; // TbSelMd
 wire n198; // TbWrite'a
 wire n199; // TbWrite'b
 wire n200; // TbWriteEn'
 wire n201; // TisIFdata
 wire n202; // Tparity
 wire n203; // TrueA
 wire n204; // _MDSaved
 wire n205; // dMD.08
 wire n206; // dMD.09
 wire n207; // dMD.10
 wire n208; // dMD.11
 wire n209; // dMD.12
 wire n210; // dMD.13
 wire n211; // dMD.14
 wire n212; // dMD.15
 wire n213; // dT.08
 wire n214; // dT.09
 wire n215; // dT.10
 wire n216; // dT.11
 wire n217; // dT.12
 wire n218; // dT.13
 wire n219; // dT.14
 wire n220; // dT.15
 wire n221; // dTm.08
 wire n222; // dTm.09
 wire n223; // dTm.10
 wire n224; // dTm.11
 wire n225; // dTm.12
 wire n226; // dTm.13
 wire n227; // dTm.14
 wire n228; // dTm.15
 wire n229; // pClk1En'
 wire n230; // ppClk'a
 wire n231; // ppClk'b
 wire n232; // ppClk'c
 assign n45=1'b0;
 assign n46=1'b0;
 assign n47=1'b0;
 assign n48=1'b0;
 assign n49=1'b0;
 assign n50=1'b0;
 assign n51=1'b0;
 assign n52=1'b0;
 assign n53=1'b0;
 assign n54=1'b0;
 assign n55=1'b0;
 assign n1=priority_n;
 assign n2=1'b0;
 assign n3=1'b0;
 assign n4=1'b0;
 assign n11=base;
 assign n12=en;
 assign n37=(pins[19:18]!=2'd0);
 assign n38=(pins[17:15]!=3'd2);
 assign n39=(pins[17:15]!=3'd3);
 assign n40=(pins[17:15]!=3'd7);
 assign n41=((pins[14:12]!=3'd4)&&(pins[14:12]!=3'd5));
 assign n42=(pins[14:12]!=3'd5);
 assign n43=(pins[14:12]!=3'd6);
 assign n59=pins[68];
 assign n61=1'b0;
 assign n62=1'b0;
 assign n64=pins[119];
 assign n65=pins[120];
 assign n66=pins[121];
 assign n67=pins[122];
 assign n68=pins[123];
 assign n69=pins[124];
 assign n70=pins[125];
 assign n71=pins[126];
 assign n72=1'b1;
 assign n73=pins[11];
 assign n74=pins[10];
 assign n77=pins[9];
 assign n88=next_raw[0];
 assign n90=next_raw[1];
 assign n92=next_raw[2];
 assign n94=next_raw[3];
 assign n96=pins[68];
 assign n97=pins[84];
 assign n98=pins[85];
 assign n99=pins[86];
 assign n100=pins[87];
 assign n101=pins[88];
 assign n102=pins[89];
 assign n103=pins[90];
 assign n104=pins[91];
 assign n141=pins[116];
 assign n144=pins[115];
 assign n145=1'b0;
 assign n146=pins[147];
 assign n147=pins[144];
 assign n148=pins[112];
 assign n149=1'b0;
 assign n158=pins[135];
 assign n159=pins[136];
 assign n160=pins[137];
 assign n161=pins[138];
 assign n162=pins[139];
 assign n163=pins[140];
 assign n164=pins[141];
 assign n165=pins[142];
 assign n167=pins[150];
 assign n177=pins[151];
 assign n181=1'b0;
 assign n183=start_a;
 assign n184=1'b1;
 assign n185=pins[146];
 assign n201=pins[117];
 assign n205=pins[100];
 assign n206=pins[101];
 assign n207=pins[102];
 assign n208=pins[103];
 assign n209=pins[104];
 assign n210=pins[105];
 assign n211=pins[106];
 assign n212=pins[107];
 wire n0_a01_2;
 assign n0=n0_a01_2;
 wire n5_h24_5;
 assign n5=n5_h24_5;
 wire n6_h24_2;
 assign n6=n6_h24_2;
 wire n7_h24_6;
 assign n7=n7_h24_6;
 wire n8_h24_11;
 assign n8=n8_h24_11;
 wire n9_h24_14;
 assign n9=n9_h24_14;
 wire n10_h24_3;
 wire n10_h23_9;
 assign n10=n10_h24_3 | n10_h23_9;
 wire n13_l01_4;
 assign n13=n13_l01_4;
 wire n14_k10_3;
 assign n14=n14_k10_3;
 wire n15_j18_3;
 assign n15=n15_j18_3;
 wire n16_j18_2;
 assign n16=n16_j18_2;
 wire n17_j18_4;
 assign n17=n17_j18_4;
 wire n18_i05_3;
 assign n18=n18_i05_3;
 wire n19_i05_4;
 assign n19=n19_i05_4;
 wire n20_c18_3;
 assign n20=n20_c18_3;
 wire n21_c18_2;
 assign n21=n21_c18_2;
 wire n22_j18_13;
 assign n22=n22_j18_13;
 wire n23_j18_14;
 assign n23=n23_j18_14;
 wire n24_j18_12;
 assign n24=n24_j18_12;
 wire n25_i05_2;
 assign n25=n25_i05_2;
 wire n26_a21_14;
 assign n26=n26_a21_14;
 wire n27_a21_15;
 assign n27=n27_a21_15;
 wire n28_a21_2;
 assign n28=n28_a21_2;
 wire n29_a21_3;
 assign n29=n29_a21_3;
 wire n30_a22_2;
 wire n30_a22_3;
 wire n30_a22_15;
 wire n30_a22_14;
 assign n30=n30_a22_2 | n30_a22_3 | n30_a22_15 | n30_a22_14;
 wire n31_i14_14;
 assign n31=n31_i14_14;
 wire n32_i14_15;
 assign n32=n32_i14_15;
 wire n33_i14_2;
 assign n33=n33_i14_2;
 wire n34_i14_3;
 assign n34=n34_i14_3;
 wire n35_k10_13;
 assign n35=n35_k10_13;
 wire n36_k10_14;
 assign n36=n36_k10_14;
 wire n44_g16_3;
 assign n44=n44_g16_3;
 wire n56_f19_15;
 assign n56=n56_f19_15;
 wire n57_f19_14;
 assign n57=n57_f19_14;
 wire n58_g18_15;
 assign n58=n58_g18_15;
 wire n60_g23_14;
 assign n60=n60_g23_14;
 wire n63_g23_9;
 assign n63=n63_g23_9;
 wire n75_h24_15;
 assign n75=n75_h24_15;
 wire n76_h24_9;
 assign n76=n76_h24_9;
 wire n78_c18_14;
 assign n78=n78_c18_14;
 wire n79_a20_14;
 assign n79=n79_a20_14;
 wire n80_a20_15;
 assign n80=n80_a20_15;
 wire n81_a20_2;
 assign n81=n81_a20_2;
 wire n82_a20_3;
 assign n82=n82_a20_3;
 wire n83_d17_15;
 assign n83=n83_d17_15;
 wire n84_a19_1;
 assign n84=n84_a19_1;
 wire n85_a19_2;
 assign n85=n85_a19_2;
 wire n86_a19_15;
 assign n86=n86_a19_15;
 wire n87_a19_14;
 assign n87=n87_a19_14;
 wire n89_a24_15;
 assign n89=n89_a24_15;
 wire n91_a24_14;
 assign n91=n91_a24_14;
 wire n93_a24_3;
 assign n93=n93_a24_3;
 wire n95_a24_2;
 assign n95=n95_a24_2;
 wire n105_f13_13;
 assign n105=n105_f13_13;
 wire n106_f13_12;
 assign n106=n106_f13_12;
 wire n107_f13_14;
 assign n107=n107_f13_14;
 wire n108_g13_3;
 assign n108=n108_g13_3;
 wire n109_f12_14;
 assign n109=n109_f12_14;
 wire n110_f13_2;
 assign n110=n110_f13_2;
 wire n111_f13_4;
 assign n111=n111_f13_4;
 wire n112_f13_3;
 assign n112=n112_f13_3;
 wire n113_f12_13;
 assign n113=n113_f12_13;
 wire n114_g13_13;
 assign n114=n114_g13_13;
 wire n115_g12_3;
 assign n115=n115_g12_3;
 wire n116_g12_2;
 assign n116=n116_g12_2;
 wire n117_g12_4;
 assign n117=n117_g12_4;
 wire n118_f12_4;
 assign n118=n118_f12_4;
 wire n119_f12_3;
 assign n119=n119_f12_3;
 wire n120_l03_2;
 assign n120=n120_l03_2;
 wire n121_l03_1;
 assign n121=n121_l03_1;
 wire n122_l03_15;
 assign n122=n122_l03_15;
 wire n123_l03_14;
 assign n123=n123_l03_14;
 wire n124_l04_2;
 assign n124=n124_l04_2;
 wire n125_l04_1;
 assign n125=n125_l04_1;
 wire n126_l04_15;
 assign n126=n126_l04_15;
 wire n127_l04_14;
 assign n127=n127_l04_14;
 wire n128_f20_2;
 assign n128=n128_f20_2;
 wire n129_f20_3;
 assign n129=n129_f20_3;
 wire n130_a24_9;
 wire n130_a24_11;
 wire n130_a24_6;
 wire n130_a24_5;
 assign n130=n130_a24_9 | n130_a24_11 | n130_a24_6 | n130_a24_5;
 wire n131_a18_2;
 assign n131=n131_a18_2;
 wire n132_a18_1;
 assign n132=n132_a18_1;
 wire n133_a18_15;
 assign n133=n133_a18_15;
 wire n134_a18_14;
 assign n134=n134_a18_14;
 wire n135_f20_14;
 assign n135=n135_f20_14;
 wire n136_f20_15;
 wire n136_g23_3;
 assign n136=n136_f20_15 | n136_g23_3;
 wire n137_h23_2;
 assign n137=n137_h23_2;
 wire n138_h23_3;
 assign n138=n138_h23_3;
 wire n139_h23_14;
 assign n139=n139_h23_14;
 wire n140_g23_2;
 assign n140=n140_g23_2;
 wire n142_i19_3;
 assign n142=n142_i19_3;
 wire n143_g16_2;
 assign n143=n143_g16_2;
 wire n150_g18_3;
 assign n150=n150_g18_3;
 wire n151_g18_4;
 assign n151=n151_g18_4;
 wire n152_g18_2;
 assign n152=n152_g18_2;
 wire n153_i13_2;
 assign n153=n153_i13_2;
 wire n154_k04_2;
 assign n154=n154_k04_2;
 wire n155_i19_2;
 assign n155=n155_i19_2;
 wire n156_i19_15;
 assign n156=n156_i19_15;
 wire n157_f12_2;
 assign n157=n157_f12_2;
 wire n166_c06_2;
 assign n166=n166_c06_2;
 wire n168_d17_3;
 assign n168=n168_d17_3;
 wire n169_d17_2;
 assign n169=n169_d17_2;
 wire n170_j05_13;
 assign n170=n170_j05_13;
 wire n171_j05_12;
 assign n171=n171_j05_12;
 wire n172_j05_14;
 assign n172=n172_j05_14;
 wire n173_d17_13;
 assign n173=n173_d17_13;
 wire n174_g12_13;
 assign n174=n174_g12_13;
 wire n175_g12_12;
 assign n175=n175_g12_12;
 wire n176_g12_14;
 assign n176=n176_g12_14;
 wire n178_g16_14;
 assign n178=n178_g16_14;
 wire n179_c18_13;
 assign n179=n179_c18_13;
 wire n180_c18_12;
 assign n180=n180_c18_12;
 wire n182_a01_3;
 assign n182=n182_a01_3;
 wire n186_g18_13;
 assign n186=n186_g18_13;
 wire n187_i03_1;
 assign n187=n187_i03_1;
 wire n188_i03_2;
 assign n188=n188_i03_2;
 wire n189_i03_15;
 assign n189=n189_i03_15;
 wire n190_i03_14;
 assign n190=n190_i03_14;
 wire n191_i04_1;
 assign n191=n191_i04_1;
 wire n192_i04_2;
 assign n192=n192_i04_2;
 wire n193_i04_15;
 assign n193=n193_i04_15;
 wire n194_i04_14;
 assign n194=n194_i04_14;
 wire n195_d06_2;
 assign n195=n195_d06_2;
 wire n196_f19_3;
 assign n196=n196_f19_3;
 wire n197_d17_4;
 assign n197=n197_d17_4;
 wire n198_j05_3;
 assign n198=n198_j05_3;
 wire n199_j05_2;
 assign n199=n199_j05_2;
 wire n200_d17_14;
 assign n200=n200_d17_14;
 wire n202_g16_15;
 assign n202=n202_g16_15;
 wire n203_a01_14;
 assign n203=n203_a01_14;
 wire n204_g18_14;
 assign n204=n204_g18_14;
 wire n213_j03_1;
 assign n213=n213_j03_1;
 wire n214_j03_2;
 assign n214=n214_j03_2;
 wire n215_j03_15;
 assign n215=n215_j03_15;
 wire n216_j03_14;
 assign n216=n216_j03_14;
 wire n217_j04_1;
 assign n217=n217_j04_1;
 wire n218_j04_2;
 assign n218=n218_j04_2;
 wire n219_j04_15;
 assign n219=n219_j04_15;
 wire n220_j04_14;
 assign n220=n220_j04_14;
 wire n221_k01_1;
 assign n221=n221_k01_1;
 wire n222_k01_2;
 assign n222=n222_k01_2;
 wire n223_k01_15;
 assign n223=n223_k01_15;
 wire n224_k01_14;
 assign n224=n224_k01_14;
 wire n225_k02_1;
 assign n225=n225_k02_1;
 wire n226_k02_2;
 assign n226=n226_k02_2;
 wire n227_k02_15;
 assign n227=n227_k02_15;
 wire n228_k02_14;
 assign n228=n228_k02_14;
 wire n229_l02_2;
 assign n229=n229_l02_2;
 wire n230_l01_13;
 assign n230=n230_l01_13;
 wire n231_l01_12;
 assign n231=n231_l01_12;
 wire n232_l01_14;
 assign n232=n232_l01_14;
 cell_MC10102 a01(.p1(1'b0),.p2(n0_a01_2),.p3(n182_a01_3),.p4(n1),.p5(1'b0),.p6(n145),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n203_a01_14),.p16(1'b0));
 cell_MC10158 a18(.p1(n132_a18_1),.p2(n131_a18_2),.p3(n85),.p4(n27),.p5(n84),.p6(n26),.p9(n175),.p10(n87),.p11(n29),.p12(n86),.p13(n28),.p14(n134_a18_14),.p15(n133_a18_15));
 cell_MC10158 a19(.p1(n84_a19_1),.p2(n85_a19_2),.p3(n91),.p4(n80),.p5(n89),.p6(n79),.p9(n117),.p10(n95),.p11(n82),.p12(n93),.p13(n81),.p14(n87_a19_14),.p15(n86_a19_15));
 original_MC10141 a20(.p1(n51),.p2(n81_a20_2),.p3(n82_a20_3),.p4(n20),.p5(1'b0),.p6(n29),.p7(1'b0),.p8(1'b0),.p9(n28),.p10(1'b0),.p11(n27),.p12(n26),.p13(1'b0),.p14(n79_a20_14),.p15(n80_a20_15),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:4]),.state_q(state_q[12+:4]));
 original_MC10141 a21(.p1(1'b0),.p2(n28_a21_2),.p3(n29_a21_3),.p4(n179),.p5(1'b0),.p6(n95),.p7(n175),.p8(1'b0),.p9(n93),.p10(n175),.p11(n91),.p12(n89),.p13(1'b0),.p14(n26_a21_14),.p15(n27_a21_15),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:4]),.state_q(state_q[8+:4]));
 cell_MC10113 a22(.p1(1'b0),.p2(n30_a22_2),.p3(n30_a22_3),.p4(n29),.p5(n95),.p6(n93),.p7(n28),.p9(1'b0),.p10(n91),.p11(n27),.p12(n89),.p13(n26),.p14(n30_a22_14),.p15(n30_a22_15));
 cell_MC10101 a24(.p2(n95_a24_2),.p3(n93_a24_3),.p4(n94),.p5(n130_a24_5),.p6(n130_a24_6),.p7(n92),.p9(n130_a24_9),.p10(n90),.p11(n130_a24_11),.p12(1'b0),.p13(n88),.p14(n91_a24_14),.p15(n89_a24_15));
 cell_MC10170 c06(.p1(1'b0),.p2(n166_c06_2),.p3(n178),.p4(n165),.p5(n164),.p6(n163),.p7(n162),.p8(1'b0),.p9(n161),.p10(n160),.p11(n159),.p12(n158),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 c18(.p2(n21_c18_2),.p3(n20_c18_3),.p5(n111),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n117),.p10(1'b0),.p11(1'b0),.p12(n180_c18_12),.p13(n179_c18_13),.p14(n78_c18_14),.p15(n45),.p16(1'b0));
 cell_MC10170 d06(.p1(1'b0),.p2(n195_d06_2),.p3(n202),.p4(n194),.p5(n193),.p6(n192),.p7(n191),.p8(1'b0),.p9(n190),.p10(n189),.p11(n188),.p12(n187),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 original_MC10176 d17(.p1(1'b0),.p2(n169_d17_2),.p3(n168_d17_3),.p4(n197_d17_4),.p5(n76),.p6(n75),.p7(n136),.p8(1'b0),.p9(n179),.p10(n139),.p11(n140),.p12(n30),.p13(n173_d17_13),.p14(n200_d17_14),.p15(n83_d17_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[2+:6]),.state_q(state_q[2+:6]));
 cell_SE10212 f12(.p1(1'b0),.p2(n157_f12_2),.p3(n119_f12_3),.p4(n118_f12_4),.p5(n229),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n157),.p10(1'b0),.p11(n230),.p13(n113_f12_13),.p14(n109_f12_14),.p15(n46),.p16(1'b0));
 cell_SE10210 f13(.p2(n110_f13_2),.p3(n112_f13_3),.p4(n111_f13_4),.p5(n231),.p6(1'b0),.p7(n157),.p8(1'b0),.p9(n231),.p10(n13),.p11(1'b0),.p12(n106_f13_12),.p13(n105_f13_13),.p14(n107_f13_14),.p15(n47),.p16(1'b0));
 cell_MC1660 f19(.p3(n196_f19_3),.p4(n58),.p5(n83),.p6(n200),.p7(n201),.p8(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(n96),.p14(n57_f19_14),.p15(n56_f19_15));
 cell_MC10100 f20(.p2(n128_f20_2),.p3(n129_f20_3),.p4(n43),.p5(n38),.p6(n41),.p7(n38),.p9(n37),.p10(n43),.p11(n39),.p12(n42),.p13(n40),.p14(n135_f20_14),.p15(n136_f20_15));
 cell_SE10211 g12(.p2(n116_g12_2),.p3(n115_g12_3),.p4(n117_g12_4),.p5(1'b0),.p6(n229),.p7(1'b0),.p9(n0),.p10(n57),.p11(1'b0),.p12(n175_g12_12),.p13(n174_g12_13),.p14(n176_g12_14),.p15(n48),.p16(1'b0));
 cell_SE10210 g13(.p3(n108_g13_3),.p5(n232),.p6(n13),.p7(1'b0),.p8(1'b0),.p9(n232),.p10(1'b0),.p11(1'b0),.p13(n114_g13_13),.p15(n49),.p16(1'b0));
 original_F10000 g16(.p2(n143_g16_2),.p3(n44_g16_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n146),.p9(n185),.p10(n153),.p11(n147),.p12(1'b0),.p13(n22),.p14(n178_g16_14),.p15(n202_g16_15),.fixture_load(fixture_load),.fixture_state(fixture_state[242+:4]),.state_q(state_q[242+:4]));
 original_MC10176 g18(.p1(1'b0),.p2(n152_g18_2),.p3(n150_g18_3),.p4(n151_g18_4),.p5(n148),.p6(n155),.p7(n156),.p8(1'b0),.p9(n16),.p10(n144),.p11(n141),.p12(n59),.p13(n186_g18_13),.p14(n204_g18_14),.p15(n58_g18_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:6]),.state_q(state_q[20+:6]));
 cell_MC10102 g23(.p1(1'b0),.p2(n140_g23_2),.p3(n136_g23_3),.p4(n77),.p5(n138),.p6(n73),.p7(n75),.p9(n63_g23_9),.p10(n62),.p11(n149),.p12(n56),.p13(n61),.p14(n60_g23_14),.p16(1'b0));
 cell_MC10102 h23(.p1(1'b0),.p2(n137_h23_2),.p3(n138_h23_3),.p4(n75),.p5(n77),.p6(n73),.p7(n75),.p9(n10_h23_9),.p10(n73),.p11(n137),.p12(n6),.p13(n9),.p14(n139_h23_14),.p16(1'b0));
 cell_MC10101 h24(.p2(n6_h24_2),.p3(n10_h24_3),.p4(n2),.p5(n5_h24_5),.p6(n7_h24_6),.p7(n3),.p9(n76_h24_9),.p10(n4),.p11(n8_h24_11),.p12(1'b0),.p13(n74),.p14(n9_h24_14),.p15(n75_h24_15));
 original_MC10173 i03(.p1(n187_i03_1),.p2(n188_i03_2),.p3(n214),.p4(n222),.p5(n213),.p6(n221),.p7(n116),.p9(n196),.p10(n216),.p11(n224),.p12(n215),.p13(n223),.p14(n190_i03_14),.p15(n189_i03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[170+:4]),.state_q(state_q[170+:4]));
 original_MC10173 i04(.p1(n191_i04_1),.p2(n192_i04_2),.p3(n218),.p4(n226),.p5(n217),.p6(n225),.p7(n116),.p9(n196),.p10(n220),.p11(n228),.p12(n219),.p13(n227),.p14(n194_i04_14),.p15(n193_i04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[174+:4]),.state_q(state_q[174+:4]));
 cell_SE10212 i05(.p1(1'b0),.p2(n25_i05_2),.p3(n18_i05_3),.p4(n19_i05_4),.p5(1'b0),.p6(1'b0),.p7(n113),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n50),.p16(1'b0));
 original_F10145A i13(.p2(n153_i13_2),.p3(1'b0),.p4(1'b0),.p5(n154),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(1'b0),.p12(1'b0),.p13(n199),.fixture_load(fixture_load),.fixture_state(fixture_state[178+:64]),.state_q(state_q[178+:64]));
 original_MC10141 i14(.p1(1'b0),.p2(n33_i14_2),.p3(n34_i14_3),.p4(n36),.p5(1'b0),.p6(n134),.p7(1'b0),.p8(1'b0),.p9(n133),.p10(1'b0),.p11(n131),.p12(n132),.p13(1'b0),.p14(n31_i14_14),.p15(n32_i14_15),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:4]),.state_q(state_q[16+:4]));
 cell_MC10106 i19(.p2(n155_i19_2),.p3(n142_i19_3),.p4(n30),.p5(n184),.p6(n181),.p7(n72),.p9(n167),.p10(n177),.p11(n166),.p12(n196),.p13(n201),.p14(n195),.p15(n156_i19_15));
 original_MC10173 j03(.p1(n213_j03_1),.p2(n214_j03_2),.p3(n121),.p4(n65),.p5(n120),.p6(n64),.p7(n19),.p9(n201),.p10(n123),.p11(n67),.p12(n122),.p13(n66),.p14(n216_j03_14),.p15(n215_j03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[162+:4]),.state_q(state_q[162+:4]));
 original_MC10173 j04(.p1(n217_j04_1),.p2(n218_j04_2),.p3(n125),.p4(n69),.p5(n124),.p6(n68),.p7(n19),.p9(n201),.p10(n127),.p11(n71),.p12(n126),.p13(n70),.p14(n220_j04_14),.p15(n219_j04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[166+:4]),.state_q(state_q[166+:4]));
 cell_SE10210 j05(.p2(n199_j05_2),.p3(n198_j05_3),.p5(n106),.p6(n58),.p7(n200),.p8(1'b0),.p9(n106),.p10(n58),.p11(n173),.p12(n171_j05_12),.p13(n170_j05_13),.p14(n172_j05_14),.p15(n52),.p16(1'b0));
 cell_SE10210 j18(.p2(n16_j18_2),.p3(n15_j18_3),.p4(n17_j18_4),.p5(n108),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(n112),.p10(1'b0),.p11(1'b0),.p12(n24_j18_12),.p13(n22_j18_13),.p14(n23_j18_14),.p15(n53),.p16(1'b0));
 original_MC10173 k01(.p1(n221_k01_1),.p2(n222_k01_2),.p3(n98),.p4(n206),.p5(n97),.p6(n205),.p7(n18),.p9(n197),.p10(n100),.p11(n208),.p12(n99),.p13(n207),.p14(n224_k01_14),.p15(n223_k01_15),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:4]),.state_q(state_q[26+:4]));
 original_MC10173 k02(.p1(n225_k02_1),.p2(n226_k02_2),.p3(n102),.p4(n210),.p5(n101),.p6(n209),.p7(n18),.p9(n197),.p10(n104),.p11(n212),.p12(n103),.p13(n211),.p14(n228_k02_14),.p15(n227_k02_15),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:4]),.state_q(state_q[30+:4]));
 cell_MC10170 k04(.p1(1'b0),.p2(n154_k04_2),.p3(n203),.p4(n228),.p5(n227),.p6(n226),.p7(n225),.p8(1'b0),.p9(n224),.p10(n223),.p11(n222),.p12(n221),.p13(1'b0),.p14(1'b0),.p16(1'b0));
 cell_SE10210 k10(.p3(n14_k10_3),.p5(n106),.p6(1'b0),.p7(1'b0),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n114),.p13(n35_k10_13),.p14(n36_k10_14),.p15(n54),.p16(1'b0));
 cell_SE10210 l01(.p4(n13_l01_4),.p5(1'b0),.p6(n183),.p7(1'b0),.p8(1'b0),.p9(n12),.p10(1'b0),.p11(n11),.p12(n231_l01_12),.p13(n230_l01_13),.p14(n232_l01_14),.p15(n55),.p16(1'b0));
 original_SE10231 l02(.p2(n229_l02_2),.p6(n12),.p7(n13),.p9(n11),.p10(1'b0),.p11(1'b0),.p13(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:2]),.state_q(state_q[0+:2]));
 original_F10145A l03(.p1(n121_l03_1),.p2(n120_l03_2),.p3(1'b0),.p4(n222),.p5(n221),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n223),.p12(n224),.p13(n198),.p14(n123_l03_14),.p15(n122_l03_15),.fixture_load(fixture_load),.fixture_state(fixture_state[34+:64]),.state_q(state_q[34+:64]));
 original_F10145A l04(.p1(n125_l04_1),.p2(n124_l04_2),.p3(1'b0),.p4(n226),.p5(n225),.p6(n34),.p7(n33),.p8(1'b0),.p9(n32),.p10(n31),.p11(n227),.p12(n228),.p13(n198),.p14(n127_l04_14),.p15(n126_l04_15),.fixture_load(fixture_load),.fixture_state(fixture_state[98+:64]),.state_q(state_q[98+:64]));
 assign clocks[0]=l02.ca;
 assign clocks[1]=l02.cb;
 assign clocks[2]=n179;
 assign clocks[3]=n106;
 assign clocks[4]=n20;
 assign clocks[5]=n36;
 assign clocks[6]=n18;
 assign clocks[7]=n198;
 assign clocks[8]=n16;
 assign clocks[9]=n22;
 assign flags[0]=n175;
 assign flags[1]=n56;
 assign flags[2]=n30;
 assign flags[3]=n116;
 assign flags[4]=n196;
 assign flags[5]=n195;
 assign flags[6]=n166;
 assign flags[7]=n156;
 assign flags[8]=n155;
endmodule
`default_nettype wire
