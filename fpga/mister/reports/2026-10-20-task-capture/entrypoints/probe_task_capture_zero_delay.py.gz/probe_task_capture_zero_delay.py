#!/usr/bin/env python3
"""Probe simulator-dependent zero-delay scheduling; never a qualification gate."""
import argparse,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--qualified',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
q=a.qualified.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);inputs=q/'executed-inputs';record=json.loads((q/'results.json').read_text())
for name,digest in record['inputs'].items():assert hashlib.sha256((inputs/name).read_bytes()).hexdigest()==digest,name
cells={'verilog/cells/cell_MC10210.v'}
for b in record['reference']['boards']:cells.update(b['combinational_sources'])
support=[inputs/'verilog/verilator/tb_task_capture_step.sv',inputs/'verilog/verilator/run_control_original_ff.sv',inputs/'verilog/verilator/processor_capture_original_ff.sv',*sorted((q/'reference').glob('*.sv')),*[inputs/n for n in sorted(cells)]]
source=q/'balanced/live_task_source/dorado_task_capture_step.sv';rtl=out/source.name;rtl.write_bytes(source.read_bytes())
rows=[]
def execute(command,log):
 with log.open('w')as f:code=subprocess.run([str(x)for x in command],stdout=f,stderr=subprocess.STDOUT).returncode
 row=dict(command=[str(x)for x in command],returncode=code,log=str(log));rows.append(row);return row
execute(['iverilog','-g2012','-s','tb_task_capture_step','-o',out/'test.vvp',rtl,*support],out/'iverilog-compile.log');assert rows[-1]['returncode']==0
execute(['vvp',out/'test.vvp'],out/'iverilog-test.log')
execute(['verilator','--binary','--timing','--top-module','tb_task_capture_step','-Wno-fatal','-Wno-PINMISSING','-Wno-TIMESCALEMOD','-Wno-MULTIDRIVEN','--Mdir',out/'obj','-o','test',rtl,*support],out/'verilator-compile.log');assert rows[-1]['returncode']==0
execute([out/'obj/test'],out/'verilator-test.log')
observations={}
for simulator in ['iverilog','verilator']:
 text=(out/(simulator+'-test.log')).read_text();m=re.search(r'task state mismatch (q=[^\n]*)',text)
 observations[simulator]=m[1]if m else text.splitlines()[0]
result=dict(scope=__doc__,status='ZERO_DELAY_DIAGNOSTIC_ONLY',qualified_inputs=record['inputs'],evaluator_sha256=hashlib.sha256(rtl.read_bytes()).hexdigest(),actions=rows,observations=observations,simulators_disagree=observations['iverilog']!=observations['verilator'],native_qualified=False)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],'simulators_disagree=',result['simulators_disagree']);print(observations)
