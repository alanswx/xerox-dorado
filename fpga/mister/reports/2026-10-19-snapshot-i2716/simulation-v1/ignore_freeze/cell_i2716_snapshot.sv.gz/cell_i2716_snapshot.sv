// cell_i2716 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 8 package position(s) across the sixteen boards.
//
// 2K x 8 EPROM. PARC's TtlDict gives the pinout:
//
//   i2716, i2758
//   a,A0,19 > a,A1,22 > a,A2,23 > a,A3,1 > a,A4,2 > a,A5,3 > a,A6,4
//   a,A7,5  > a,A8,6  > a,A9,7  > a,A10,8
//   a,CS',20 > a,PD',18 > a,VPP,21
//   a,Q0,9 > a,Q1,10 > a,Q2,11 > a,Q3,13 > a,Q4,14 > a,Q5,15 > a,Q6,16 > a,Q7,17
//
// Eight sockets on the BaseBoard (b60 b61 c60 c61 e60 f60 h61 i61), chip-
// selected by `Rom0'`..`Rom7'` from the SN74LS138 at g11 and addressed over
// the MICROCODE bus -- every socket takes `MCA.00` on A10, not a 6502 address
// line. These are the store the BaseBoard shifts into the Dorado at boot.
//
// CONTENTS ARE NOT WIRED IN YET, and the reason is worth stating: we HOLD the
// dumps (`firmware/`, five 2048-byte images from Nov 1987) and the C
// emulator's memory map says where they live -- C-08/C-10 at 0xC000-0xCFFF,
// C-12 at 0xD000-0xD7FF, B-08/B-10 at 0xF000-0xFFFF (dorado/include/
// baseboard.h) -- but which SOCKET holds which image needs the RSA.0-2
// decode traced back to whatever drives it. Eight sockets, five images: three
// are empty, and guessing which would be worse than leaving it.
//
// INIT_FILE is here so that mapping is a one-line change per socket when it
// is established, the same way the PROM packages are wired.

`default_nettype none

module cell_i2716_snapshot #(
    parameter INIT_FILE = ""
) (
    input wire state_host_clk,state_advance,state_freeze,state_guest_held,state_request,state_write,
    input wire [1:0] state_index,input wire [17:0] state_data,
    output reg state_frozen=1'b0,state_done=1'b0,state_error=1'b0,
    output reg [17:0] state_result,
    input  wire sys_clk,
    input  wire p1,  // A3
    input  wire p2,  // A4
    input  wire p3,  // A5
    input  wire p4,  // A6
    input  wire p5,  // A7
    input  wire p6,  // A8
    input  wire p7,  // A9
    input  wire p8,  // A10
    output wire p9,  // Q0
    output wire p10,  // Q1
    output wire p11,  // Q2
    input  wire p12,  // (no name in EclDict)
    output wire p13,  // Q3
    output wire p14,  // Q4
    output wire p15,  // Q5
    output wire p16,  // Q6
    output wire p17,  // Q7
    input  wire p18,  // PD'
    input  wire p19,  // A0
    input  wire p20,  // CS'
    input  wire p21,  // VPP
    input  wire p22,  // A1
    input  wire p23,  // A2
    input  wire p24// (no name in EclDict)
);

  // ADDRESS ORDER. EclDict/TtlDict name these MSB-FIRST, as everywhere in this
  // machine: PARC's `A0` is pin 19, which the 2716 data sheet calls A10 -- the
  // most significant bit -- and PARC's `A10` is pin 8, the sheet's A0. So the
  // vector below runs pin 19 down to pin 8, most significant first.
  //
  // It is worth being exact even while INIT_FILE is empty: unlike the RAM
  // cells, where any self-consistent order works because the same board writes
  // and reads, a ROM is compared against an IMAGE and a reversed address would
  // scramble it silently.
  wire [10:0] a = {p19, p22, p23, p1, p2, p3, p4, p5, p6, p7, p8};

  reg [7:0] mem [0:2047];
  initial if (INIT_FILE != "") $readmemh(INIT_FILE, mem);

  // SYNCHRONOUS READ, which is both the FPGA form of a ROM (a block RAM has
  // a registered output; a combinational one costs LUTs it should not) and,
  // as it turns out, the only form that works here.
  //
  // The BaseBoard enables these from `MCClk'`, so a 2716 drives only while
  // the 6502's phase 2 is high -- and the processor latches the byte as that
  // phase FALLS. On the real board the '138 and the 2716 take tens of
  // nanoseconds to let go, which is exactly the data hold the part needs. In
  // zero-delay RTL a combinational output vanishes in the same instant the
  // CPU latches: the reset vector was read correctly off the bus, 0xA7 then
  // 0xF3, and the processor still started at 0x0000 every time. One fabric
  // clock of registered output supplies the hold.
  reg [7:0] d;
  reg       en_q;
  

  // PARC numbers these MSB-first (its `A0` is pin 19, the data sheet's A10),
  // but the DATA pins land the same way round as the data sheet: pin 9 is O0.
  // The board is what crosses the bus -- pin 9 goes to `MCD.7` -- so the
  // stored byte is bit-reversed and this mapping stays straight. See
  // tools/firmware_eproms.py.
  assign {p17, p16, p15, p14, p13, p11, p10, p9} = en_q ? d : 8'h00;

  wire _unused_pins = &{1'b0, p12, p21, p24, 1'b0};   // GND, VPP, VCC

  wire state_hold=state_freeze && state_guest_held;
  wire state_accept=state_hold && state_frozen && state_request;
  wire state_valid=state_index==2'b00;
  always @(posedge state_host_clk)begin
    state_frozen<=state_hold;state_done<=state_accept;state_error<=state_accept && !state_valid;
    if(state_accept)begin
      state_result<=18'b0;
      if(state_valid)begin
        if(state_write){en_q,d}<=state_data[8:0];
        else state_result<={9'b0,en_q,d};
      end
    end
    if(state_advance)begin
begin
    d    <= mem[a];
    en_q <= ~p20 & ~p18;                  // CS' and PD' both low
  end
    end
  end
endmodule

`default_nettype wire
