module snapshot_fit(
 input wire host_clk,input wire [7:0] advance,ce_n,pd_n,freeze,held,request,write,
 input wire [87:0] address,input wire [143:0] state_data,input wire [15:0] word_index,
 output reg [63:0] q,output reg [143:0] result,output reg [7:0] frozen,done,error);

 reg [37:0] launch_0;
 always @(negedge host_clk)launch_0<=
  {advance[0],address[0+:11],ce_n[0],pd_n[0],freeze[0],held[0],request[0],write[0],word_index[0+:2],state_data[0+:18]};
 wire step_0,ce_0,pd_0,freeze_0,held_0,request_0,write_0;
 wire [10:0] address_0;wire [1:0] word_0;wire [17:0] state_0;
 assign {step_0,address_0,ce_0,pd_0,freeze_0,held_0,request_0,write_0,word_0,state_0}=launch_0;
 wire [7:0] q_0;wire [17:0] result_0;wire frozen_0,done_0,error_0;
 always @(negedge host_clk)
  {q[0+:8],frozen[0],done[0],error[0],result[0+:18]}<=
  {q_0,frozen_0,done_0,error_0,result_0};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("")) rom_b60(
 .state_host_clk(host_clk),.state_advance(step_0),.state_freeze(freeze_0),.state_guest_held(held_0),
 .state_request(request_0),.state_write(write_0),.state_index(word_0),.state_data(state_0),
 .state_frozen(frozen_0),.state_done(done_0),.state_error(error_0),.state_result(result_0),
`else
 assign {frozen_0,done_0,error_0,result_0}=21'b0;
 cell_i2716 #(.INIT_FILE("")) rom_b60(
`endif
 .sys_clk(host_clk),.p19(address_0[10]),.p22(address_0[9]),.p23(address_0[8]),.p1(address_0[7]),.p2(address_0[6]),.p3(address_0[5]),
 .p4(address_0[4]),.p5(address_0[3]),.p6(address_0[2]),.p7(address_0[1]),.p8(address_0[0]),.p20(ce_0),.p18(pd_0),
 .p9(q_0[0]),.p10(q_0[1]),.p11(q_0[2]),.p13(q_0[3]),.p14(q_0[4]),.p15(q_0[5]),.p16(q_0[6]),.p17(q_0[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_1;
 always @(negedge host_clk)launch_1<=
  {advance[1],address[11+:11],ce_n[1],pd_n[1],freeze[1],held[1],request[1],write[1],word_index[2+:2],state_data[18+:18]};
 wire step_1,ce_1,pd_1,freeze_1,held_1,request_1,write_1;
 wire [10:0] address_1;wire [1:0] word_1;wire [17:0] state_1;
 assign {step_1,address_1,ce_1,pd_1,freeze_1,held_1,request_1,write_1,word_1,state_1}=launch_1;
 wire [7:0] q_1;wire [17:0] result_1;wire frozen_1,done_1,error_1;
 always @(negedge host_clk)
  {q[8+:8],frozen[1],done[1],error[1],result[18+:18]}<=
  {q_1,frozen_1,done_1,error_1,result_1};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-b61.mem")) rom_b61(
 .state_host_clk(host_clk),.state_advance(step_1),.state_freeze(freeze_1),.state_guest_held(held_1),
 .state_request(request_1),.state_write(write_1),.state_index(word_1),.state_data(state_1),
 .state_frozen(frozen_1),.state_done(done_1),.state_error(error_1),.state_result(result_1),
`else
 assign {frozen_1,done_1,error_1,result_1}=21'b0;
 cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-b61.mem")) rom_b61(
`endif
 .sys_clk(host_clk),.p19(address_1[10]),.p22(address_1[9]),.p23(address_1[8]),.p1(address_1[7]),.p2(address_1[6]),.p3(address_1[5]),
 .p4(address_1[4]),.p5(address_1[3]),.p6(address_1[2]),.p7(address_1[1]),.p8(address_1[0]),.p20(ce_1),.p18(pd_1),
 .p9(q_1[0]),.p10(q_1[1]),.p11(q_1[2]),.p13(q_1[3]),.p14(q_1[4]),.p15(q_1[5]),.p16(q_1[6]),.p17(q_1[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_2;
 always @(negedge host_clk)launch_2<=
  {advance[2],address[22+:11],ce_n[2],pd_n[2],freeze[2],held[2],request[2],write[2],word_index[4+:2],state_data[36+:18]};
 wire step_2,ce_2,pd_2,freeze_2,held_2,request_2,write_2;
 wire [10:0] address_2;wire [1:0] word_2;wire [17:0] state_2;
 assign {step_2,address_2,ce_2,pd_2,freeze_2,held_2,request_2,write_2,word_2,state_2}=launch_2;
 wire [7:0] q_2;wire [17:0] result_2;wire frozen_2,done_2,error_2;
 always @(negedge host_clk)
  {q[16+:8],frozen[2],done[2],error[2],result[36+:18]}<=
  {q_2,frozen_2,done_2,error_2,result_2};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("")) rom_c60(
 .state_host_clk(host_clk),.state_advance(step_2),.state_freeze(freeze_2),.state_guest_held(held_2),
 .state_request(request_2),.state_write(write_2),.state_index(word_2),.state_data(state_2),
 .state_frozen(frozen_2),.state_done(done_2),.state_error(error_2),.state_result(result_2),
`else
 assign {frozen_2,done_2,error_2,result_2}=21'b0;
 cell_i2716 #(.INIT_FILE("")) rom_c60(
`endif
 .sys_clk(host_clk),.p19(address_2[10]),.p22(address_2[9]),.p23(address_2[8]),.p1(address_2[7]),.p2(address_2[6]),.p3(address_2[5]),
 .p4(address_2[4]),.p5(address_2[3]),.p6(address_2[2]),.p7(address_2[1]),.p8(address_2[0]),.p20(ce_2),.p18(pd_2),
 .p9(q_2[0]),.p10(q_2[1]),.p11(q_2[2]),.p13(q_2[3]),.p14(q_2[4]),.p15(q_2[5]),.p16(q_2[6]),.p17(q_2[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_3;
 always @(negedge host_clk)launch_3<=
  {advance[3],address[33+:11],ce_n[3],pd_n[3],freeze[3],held[3],request[3],write[3],word_index[6+:2],state_data[54+:18]};
 wire step_3,ce_3,pd_3,freeze_3,held_3,request_3,write_3;
 wire [10:0] address_3;wire [1:0] word_3;wire [17:0] state_3;
 assign {step_3,address_3,ce_3,pd_3,freeze_3,held_3,request_3,write_3,word_3,state_3}=launch_3;
 wire [7:0] q_3;wire [17:0] result_3;wire frozen_3,done_3,error_3;
 always @(negedge host_clk)
  {q[24+:8],frozen[3],done[3],error[3],result[54+:18]}<=
  {q_3,frozen_3,done_3,error_3,result_3};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-c61.mem")) rom_c61(
 .state_host_clk(host_clk),.state_advance(step_3),.state_freeze(freeze_3),.state_guest_held(held_3),
 .state_request(request_3),.state_write(write_3),.state_index(word_3),.state_data(state_3),
 .state_frozen(frozen_3),.state_done(done_3),.state_error(error_3),.state_result(result_3),
`else
 assign {frozen_3,done_3,error_3,result_3}=21'b0;
 cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-c61.mem")) rom_c61(
`endif
 .sys_clk(host_clk),.p19(address_3[10]),.p22(address_3[9]),.p23(address_3[8]),.p1(address_3[7]),.p2(address_3[6]),.p3(address_3[5]),
 .p4(address_3[4]),.p5(address_3[3]),.p6(address_3[2]),.p7(address_3[1]),.p8(address_3[0]),.p20(ce_3),.p18(pd_3),
 .p9(q_3[0]),.p10(q_3[1]),.p11(q_3[2]),.p13(q_3[3]),.p14(q_3[4]),.p15(q_3[5]),.p16(q_3[6]),.p17(q_3[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_4;
 always @(negedge host_clk)launch_4<=
  {advance[4],address[44+:11],ce_n[4],pd_n[4],freeze[4],held[4],request[4],write[4],word_index[8+:2],state_data[72+:18]};
 wire step_4,ce_4,pd_4,freeze_4,held_4,request_4,write_4;
 wire [10:0] address_4;wire [1:0] word_4;wire [17:0] state_4;
 assign {step_4,address_4,ce_4,pd_4,freeze_4,held_4,request_4,write_4,word_4,state_4}=launch_4;
 wire [7:0] q_4;wire [17:0] result_4;wire frozen_4,done_4,error_4;
 always @(negedge host_clk)
  {q[32+:8],frozen[4],done[4],error[4],result[72+:18]}<=
  {q_4,frozen_4,done_4,error_4,result_4};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-e60.mem")) rom_e60(
 .state_host_clk(host_clk),.state_advance(step_4),.state_freeze(freeze_4),.state_guest_held(held_4),
 .state_request(request_4),.state_write(write_4),.state_index(word_4),.state_data(state_4),
 .state_frozen(frozen_4),.state_done(done_4),.state_error(error_4),.state_result(result_4),
`else
 assign {frozen_4,done_4,error_4,result_4}=21'b0;
 cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-e60.mem")) rom_e60(
`endif
 .sys_clk(host_clk),.p19(address_4[10]),.p22(address_4[9]),.p23(address_4[8]),.p1(address_4[7]),.p2(address_4[6]),.p3(address_4[5]),
 .p4(address_4[4]),.p5(address_4[3]),.p6(address_4[2]),.p7(address_4[1]),.p8(address_4[0]),.p20(ce_4),.p18(pd_4),
 .p9(q_4[0]),.p10(q_4[1]),.p11(q_4[2]),.p13(q_4[3]),.p14(q_4[4]),.p15(q_4[5]),.p16(q_4[6]),.p17(q_4[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_5;
 always @(negedge host_clk)launch_5<=
  {advance[5],address[55+:11],ce_n[5],pd_n[5],freeze[5],held[5],request[5],write[5],word_index[10+:2],state_data[90+:18]};
 wire step_5,ce_5,pd_5,freeze_5,held_5,request_5,write_5;
 wire [10:0] address_5;wire [1:0] word_5;wire [17:0] state_5;
 assign {step_5,address_5,ce_5,pd_5,freeze_5,held_5,request_5,write_5,word_5,state_5}=launch_5;
 wire [7:0] q_5;wire [17:0] result_5;wire frozen_5,done_5,error_5;
 always @(negedge host_clk)
  {q[40+:8],frozen[5],done[5],error[5],result[90+:18]}<=
  {q_5,frozen_5,done_5,error_5,result_5};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-f60.mem")) rom_f60(
 .state_host_clk(host_clk),.state_advance(step_5),.state_freeze(freeze_5),.state_guest_held(held_5),
 .state_request(request_5),.state_write(write_5),.state_index(word_5),.state_data(state_5),
 .state_frozen(frozen_5),.state_done(done_5),.state_error(error_5),.state_result(result_5),
`else
 assign {frozen_5,done_5,error_5,result_5}=21'b0;
 cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-f60.mem")) rom_f60(
`endif
 .sys_clk(host_clk),.p19(address_5[10]),.p22(address_5[9]),.p23(address_5[8]),.p1(address_5[7]),.p2(address_5[6]),.p3(address_5[5]),
 .p4(address_5[4]),.p5(address_5[3]),.p6(address_5[2]),.p7(address_5[1]),.p8(address_5[0]),.p20(ce_5),.p18(pd_5),
 .p9(q_5[0]),.p10(q_5[1]),.p11(q_5[2]),.p13(q_5[3]),.p14(q_5[4]),.p15(q_5[5]),.p16(q_5[6]),.p17(q_5[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_6;
 always @(negedge host_clk)launch_6<=
  {advance[6],address[66+:11],ce_n[6],pd_n[6],freeze[6],held[6],request[6],write[6],word_index[12+:2],state_data[108+:18]};
 wire step_6,ce_6,pd_6,freeze_6,held_6,request_6,write_6;
 wire [10:0] address_6;wire [1:0] word_6;wire [17:0] state_6;
 assign {step_6,address_6,ce_6,pd_6,freeze_6,held_6,request_6,write_6,word_6,state_6}=launch_6;
 wire [7:0] q_6;wire [17:0] result_6;wire frozen_6,done_6,error_6;
 always @(negedge host_clk)
  {q[48+:8],frozen[6],done[6],error[6],result[108+:18]}<=
  {q_6,frozen_6,done_6,error_6,result_6};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("")) rom_h61(
 .state_host_clk(host_clk),.state_advance(step_6),.state_freeze(freeze_6),.state_guest_held(held_6),
 .state_request(request_6),.state_write(write_6),.state_index(word_6),.state_data(state_6),
 .state_frozen(frozen_6),.state_done(done_6),.state_error(error_6),.state_result(result_6),
`else
 assign {frozen_6,done_6,error_6,result_6}=21'b0;
 cell_i2716 #(.INIT_FILE("")) rom_h61(
`endif
 .sys_clk(host_clk),.p19(address_6[10]),.p22(address_6[9]),.p23(address_6[8]),.p1(address_6[7]),.p2(address_6[6]),.p3(address_6[5]),
 .p4(address_6[4]),.p5(address_6[3]),.p6(address_6[2]),.p7(address_6[1]),.p8(address_6[0]),.p20(ce_6),.p18(pd_6),
 .p9(q_6[0]),.p10(q_6[1]),.p11(q_6[2]),.p13(q_6[3]),.p14(q_6[4]),.p15(q_6[5]),.p16(q_6[6]),.p17(q_6[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));

 reg [37:0] launch_7;
 always @(negedge host_clk)launch_7<=
  {advance[7],address[77+:11],ce_n[7],pd_n[7],freeze[7],held[7],request[7],write[7],word_index[14+:2],state_data[126+:18]};
 wire step_7,ce_7,pd_7,freeze_7,held_7,request_7,write_7;
 wire [10:0] address_7;wire [1:0] word_7;wire [17:0] state_7;
 assign {step_7,address_7,ce_7,pd_7,freeze_7,held_7,request_7,write_7,word_7,state_7}=launch_7;
 wire [7:0] q_7;wire [17:0] result_7;wire frozen_7,done_7,error_7;
 always @(negedge host_clk)
  {q[56+:8],frozen[7],done[7],error[7],result[126+:18]}<=
  {q_7,frozen_7,done_7,error_7,result_7};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_i2716_snapshot #(.INIT_FILE("")) rom_i61(
 .state_host_clk(host_clk),.state_advance(step_7),.state_freeze(freeze_7),.state_guest_held(held_7),
 .state_request(request_7),.state_write(write_7),.state_index(word_7),.state_data(state_7),
 .state_frozen(frozen_7),.state_done(done_7),.state_error(error_7),.state_result(result_7),
`else
 assign {frozen_7,done_7,error_7,result_7}=21'b0;
 cell_i2716 #(.INIT_FILE("")) rom_i61(
`endif
 .sys_clk(host_clk),.p19(address_7[10]),.p22(address_7[9]),.p23(address_7[8]),.p1(address_7[7]),.p2(address_7[6]),.p3(address_7[5]),
 .p4(address_7[4]),.p5(address_7[3]),.p6(address_7[2]),.p7(address_7[1]),.p8(address_7[0]),.p20(ce_7),.p18(pd_7),
 .p9(q_7[0]),.p10(q_7[1]),.p11(q_7[2]),.p13(q_7[3]),.p14(q_7[4]),.p15(q_7[5]),.p16(q_7[6]),.p17(q_7[7]),
 .p12(1'b0),.p21(1'b1),.p24(1'b1));
endmodule
