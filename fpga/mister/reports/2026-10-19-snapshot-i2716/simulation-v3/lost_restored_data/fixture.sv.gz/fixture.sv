// Four-state oracle: empty sockets remain unknown, not an invented zero ROM.
module i2716_fixture;
 reg host=0,ref_clk=0,advance=0,freeze=0,held=0,request=0,write=0;
 reg [10:0] address=0;reg [7:0] cs_n=0,pd_n=0;
 reg [4:0] index=0;reg [17:0] data=0;
 wire [7:0] frozen,done,error;
 wire [7:0] q[0:7],original_q[0:7],expected_word[0:7];
 wire [8:0] raw[0:7],original_raw[0:7];wire [17:0] result[0:7];
 reg [8:0] model[0:7],saved[0:7];
 reg was_frozen=0;
 integer edges=0,holds=0,accepted=0,writes=0,late=0;
 reg [31:0] seed=32'h27160072;
 function [31:0] random_word;
  begin seed=seed^(seed<<13);seed=seed^(seed>>17);seed=seed^(seed<<5);random_word=seed;end
 endfunction
reg [7:0] oracle_0[0:2047];
 initial if(""!="")$readmemh("",oracle_0);
 assign expected_word[0]=oracle_0[address];
 assign raw[0]={candidate_0.en_q,candidate_0.logical_d};
 assign original_raw[0]={original_0.en_q,original_0.d};
cell_i2716_snapshot #(.INIT_FILE("")) candidate_0(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd0),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[0]),.state_done(done[0]),.state_error(error[0]),.state_result(result[0]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[0]),.p18(pd_n[0]),
 .p9(q[0][0]),.p10(q[0][1]),.p11(q[0][2]),.p13(q[0][3]),.p14(q[0][4]),
 .p15(q[0][5]),.p16(q[0][6]),.p17(q[0][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("")) original_0(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[0]),.p18(pd_n[0]),
 .p9(original_q[0][0]),.p10(original_q[0][1]),.p11(original_q[0][2]),.p13(original_q[0][3]),.p14(original_q[0][4]),
 .p15(original_q[0][5]),.p16(original_q[0][6]),.p17(original_q[0][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_1[0:2047];
 initial if("verilog/proms/eprom/BaseBd-b61.mem"!="")$readmemh("verilog/proms/eprom/BaseBd-b61.mem",oracle_1);
 assign expected_word[1]=oracle_1[address];
 assign raw[1]={candidate_1.en_q,candidate_1.logical_d};
 assign original_raw[1]={original_1.en_q,original_1.d};
cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-b61.mem")) candidate_1(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd1),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[1]),.state_done(done[1]),.state_error(error[1]),.state_result(result[1]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[1]),.p18(pd_n[1]),
 .p9(q[1][0]),.p10(q[1][1]),.p11(q[1][2]),.p13(q[1][3]),.p14(q[1][4]),
 .p15(q[1][5]),.p16(q[1][6]),.p17(q[1][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-b61.mem")) original_1(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[1]),.p18(pd_n[1]),
 .p9(original_q[1][0]),.p10(original_q[1][1]),.p11(original_q[1][2]),.p13(original_q[1][3]),.p14(original_q[1][4]),
 .p15(original_q[1][5]),.p16(original_q[1][6]),.p17(original_q[1][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_2[0:2047];
 initial if(""!="")$readmemh("",oracle_2);
 assign expected_word[2]=oracle_2[address];
 assign raw[2]={candidate_2.en_q,candidate_2.logical_d};
 assign original_raw[2]={original_2.en_q,original_2.d};
cell_i2716_snapshot #(.INIT_FILE("")) candidate_2(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd2),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[2]),.state_done(done[2]),.state_error(error[2]),.state_result(result[2]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[2]),.p18(pd_n[2]),
 .p9(q[2][0]),.p10(q[2][1]),.p11(q[2][2]),.p13(q[2][3]),.p14(q[2][4]),
 .p15(q[2][5]),.p16(q[2][6]),.p17(q[2][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("")) original_2(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[2]),.p18(pd_n[2]),
 .p9(original_q[2][0]),.p10(original_q[2][1]),.p11(original_q[2][2]),.p13(original_q[2][3]),.p14(original_q[2][4]),
 .p15(original_q[2][5]),.p16(original_q[2][6]),.p17(original_q[2][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_3[0:2047];
 initial if("verilog/proms/eprom/BaseBd-c61.mem"!="")$readmemh("verilog/proms/eprom/BaseBd-c61.mem",oracle_3);
 assign expected_word[3]=oracle_3[address];
 assign raw[3]={candidate_3.en_q,candidate_3.logical_d};
 assign original_raw[3]={original_3.en_q,original_3.d};
cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-c61.mem")) candidate_3(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd3),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[3]),.state_done(done[3]),.state_error(error[3]),.state_result(result[3]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[3]),.p18(pd_n[3]),
 .p9(q[3][0]),.p10(q[3][1]),.p11(q[3][2]),.p13(q[3][3]),.p14(q[3][4]),
 .p15(q[3][5]),.p16(q[3][6]),.p17(q[3][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-c61.mem")) original_3(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[3]),.p18(pd_n[3]),
 .p9(original_q[3][0]),.p10(original_q[3][1]),.p11(original_q[3][2]),.p13(original_q[3][3]),.p14(original_q[3][4]),
 .p15(original_q[3][5]),.p16(original_q[3][6]),.p17(original_q[3][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_4[0:2047];
 initial if("verilog/proms/eprom/BaseBd-e60.mem"!="")$readmemh("verilog/proms/eprom/BaseBd-e60.mem",oracle_4);
 assign expected_word[4]=oracle_4[address];
 assign raw[4]={candidate_4.en_q,candidate_4.logical_d};
 assign original_raw[4]={original_4.en_q,original_4.d};
cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-e60.mem")) candidate_4(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd4),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[4]),.state_done(done[4]),.state_error(error[4]),.state_result(result[4]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[4]),.p18(pd_n[4]),
 .p9(q[4][0]),.p10(q[4][1]),.p11(q[4][2]),.p13(q[4][3]),.p14(q[4][4]),
 .p15(q[4][5]),.p16(q[4][6]),.p17(q[4][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-e60.mem")) original_4(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[4]),.p18(pd_n[4]),
 .p9(original_q[4][0]),.p10(original_q[4][1]),.p11(original_q[4][2]),.p13(original_q[4][3]),.p14(original_q[4][4]),
 .p15(original_q[4][5]),.p16(original_q[4][6]),.p17(original_q[4][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_5[0:2047];
 initial if("verilog/proms/eprom/BaseBd-f60.mem"!="")$readmemh("verilog/proms/eprom/BaseBd-f60.mem",oracle_5);
 assign expected_word[5]=oracle_5[address];
 assign raw[5]={candidate_5.en_q,candidate_5.logical_d};
 assign original_raw[5]={original_5.en_q,original_5.d};
cell_i2716_snapshot #(.INIT_FILE("verilog/proms/eprom/BaseBd-f60.mem")) candidate_5(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd5),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[5]),.state_done(done[5]),.state_error(error[5]),.state_result(result[5]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[5]),.p18(pd_n[5]),
 .p9(q[5][0]),.p10(q[5][1]),.p11(q[5][2]),.p13(q[5][3]),.p14(q[5][4]),
 .p15(q[5][5]),.p16(q[5][6]),.p17(q[5][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("verilog/proms/eprom/BaseBd-f60.mem")) original_5(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[5]),.p18(pd_n[5]),
 .p9(original_q[5][0]),.p10(original_q[5][1]),.p11(original_q[5][2]),.p13(original_q[5][3]),.p14(original_q[5][4]),
 .p15(original_q[5][5]),.p16(original_q[5][6]),.p17(original_q[5][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_6[0:2047];
 initial if(""!="")$readmemh("",oracle_6);
 assign expected_word[6]=oracle_6[address];
 assign raw[6]={candidate_6.en_q,candidate_6.logical_d};
 assign original_raw[6]={original_6.en_q,original_6.d};
cell_i2716_snapshot #(.INIT_FILE("")) candidate_6(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd6),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[6]),.state_done(done[6]),.state_error(error[6]),.state_result(result[6]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[6]),.p18(pd_n[6]),
 .p9(q[6][0]),.p10(q[6][1]),.p11(q[6][2]),.p13(q[6][3]),.p14(q[6][4]),
 .p15(q[6][5]),.p16(q[6][6]),.p17(q[6][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("")) original_6(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[6]),.p18(pd_n[6]),
 .p9(original_q[6][0]),.p10(original_q[6][1]),.p11(original_q[6][2]),.p13(original_q[6][3]),.p14(original_q[6][4]),
 .p15(original_q[6][5]),.p16(original_q[6][6]),.p17(original_q[6][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
reg [7:0] oracle_7[0:2047];
 initial if(""!="")$readmemh("",oracle_7);
 assign expected_word[7]=oracle_7[address];
 assign raw[7]={candidate_7.en_q,candidate_7.logical_d};
 assign original_raw[7]={original_7.en_q,original_7.d};
cell_i2716_snapshot #(.INIT_FILE("")) candidate_7(
 .state_host_clk(host),.state_advance(advance),.state_freeze(freeze),.state_guest_held(held),
 .state_request(request && index[4:2]==3'd7),.state_write(write),.state_index(index[1:0]),.state_data(data),
 .state_frozen(frozen[7]),.state_done(done[7]),.state_error(error[7]),.state_result(result[7]),
 .sys_clk(host),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[7]),.p18(pd_n[7]),
 .p9(q[7][0]),.p10(q[7][1]),.p11(q[7][2]),.p13(q[7][3]),.p14(q[7][4]),
 .p15(q[7][5]),.p16(q[7][6]),.p17(q[7][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));
cell_i2716 #(.INIT_FILE("")) original_7(
 .sys_clk(ref_clk),.p19(address[10]),.p22(address[9]),.p23(address[8]),.p1(address[7]),.p2(address[6]),.p3(address[5]),
 .p4(address[4]),.p5(address[3]),.p6(address[2]),.p7(address[1]),.p8(address[0]),.p20(cs_n[7]),.p18(pd_n[7]),
 .p9(original_q[7][0]),.p10(original_q[7][1]),.p11(original_q[7][2]),.p13(original_q[7][3]),.p14(original_q[7][4]),
 .p15(original_q[7][5]),.p16(original_q[7][6]),.p17(original_q[7][7]),.p12(1'b0),.p21(1'b1),.p24(1'b1));

 task tick(input do_reference,input compare_reference);
  reg hold,accept,valid;reg [8:0] previous;reg [7:0] expected_q;
  integer k,bank;
  begin
   host=0;ref_clk=0;#1;
   hold=freeze&&held;accept=hold&&was_frozen&&request;valid=index[1:0]==0;bank=index[4:2];previous=model[bank];
   if(accept&&valid&&write)model[bank]=data[8:0];
   if(!hold&&advance)for(k=0;k<8;k=k+1)model[k]={~cs_n[k]&~pd_n[k],expected_word[k]};
   if(!hold&&advance&&do_reference)ref_clk=1;
   host=1;#1;edges=edges+1;if(hold)holds=holds+1;if(accept)accepted=accepted+1;if(accept&&valid&&write)writes=writes+1;
   if(frozen!==(hold?8'hff:8'h00)||done!==(accept?(8'b1<<bank):8'b0)||error!==((accept&&!valid)?(8'b1<<bank):8'b0))$fatal(1,"2716 handshake differs at %0d",edges);
   for(k=0;k<8;k=k+1)begin
    expected_q=model[k][8]?model[k][7:0]:8'b0;
    if(raw[k]!==model[k])$fatal(1,"2716 raw pipeline differs at %0d bank%0d",edges,k);
    if(q[k]!==expected_q)$fatal(1,"2716 output differs at %0d bank%0d",edges,k);
    if(compare_reference&&(original_raw[k]!==model[k]||original_q[k]!==expected_q))$fatal(1,"2716 untouched original differs at %0d bank%0d",edges,k);
   end
   if(accept&&result[bank]!==((valid&&!write)?{9'b0,previous}:18'b0))$fatal(1,"2716 response/padding differs at %0d",edges);
   was_frozen=hold;#1;host=0;ref_clk=0;#1;
  end
 endtask
 task pins;
  begin address=random_word()&2047;cs_n=random_word();pd_n=random_word();advance=random_word()&1;end
 endtask
 task access(input integer bank,input integer row,input wr,input [17:0] value);
  begin pins();late=late+1;index=(bank<<2)|row;request=1;write=wr;data=value;tick(0,0);request=0;end
 endtask
 task random_steps(input integer count,input do_reference,input compare_reference);
  integer n;
  begin for(n=0;n<count;n=n+1)begin pins();request=random_word()&1;write=random_word()&1;index=random_word()&31;data=random_word();tick(do_reference,compare_reference);end request=0;end
 endtask
 integer a,b,k,n,cs,pd;
 initial begin
  #1;
  // Every real image address and empty-socket X is read through original pins.
  advance=1;cs_n=0;pd_n=0;
  for(a=0;a<2048;a=a+1)begin address=a;tick(1,1);end
  for(cs=0;cs<256;cs=cs+1)for(pd=0;pd<4;pd=pd+1)begin
   cs_n=cs;pd_n=pd==0?0:pd==1?8'hff:pd==2?8'h55:8'haa;address=random_word()&2047;advance=1;tick(1,1);
   advance=0;cs_n=~cs_n;pd_n=~pd_n;address=random_word()&2047;tick(1,1);
  end
  random_steps(5000,1,1);
  // Freeze alone and held alone do not stop ordinary advancement.
  freeze=1;held=0;random_steps(127,1,1);freeze=0;held=1;random_steps(127,1,1);held=0;
  advance=1;address=39;cs_n=0;pd_n=0;tick(1,1);advance=0;address=713;tick(1,1);
  for(k=0;k<8;k=k+1)saved[k]=model[k];
  freeze=1;held=1;request=1;write=1;index=0;data=18'h3ffff;tick(0,1);request=0;
  for(k=0;k<8;k=k+1)access(k,0,1,0);
  for(b=0;b<72;b=b+1)begin access(b/9,0,1,18'b1<<(b%9));access(b/9,0,0,0);access(b/9,0,1,0);end
  for(k=0;k<8;k=k+1)begin
   access(k,0,1,18'h3fe00);access(k,0,0,0);
   for(a=1;a<4;a=a+1)begin access(k,a,1,18'h3ffff);access(k,a,0,0);end
   // Also preserve X/Z data in the nine pipeline bits exactly in four-state RTL.
   access(k,0,1,18'b0000000001xz10zx01);access(k,0,0,0);
   access(k,0,1,{9'b0,saved[k]});
  end
  freeze=0;held=0;request=1;write=1;index=0;data=0;advance=0;tick(1,1);request=0;advance=1;tick(1,1);
  random_steps(1000,1,1);
  for(k=0;k<8;k=k+1)saved[k]=model[k];
  freeze=1;held=1;request=0;tick(0,1);
  freeze=0;held=0;random_steps(2000,0,0);
  freeze=1;held=1;request=0;tick(0,0);
  for(k=0;k<8;k=k+1)begin access(k,0,1,{9'b0,saved[k]});access(k,0,0,0);end
  freeze=0;held=0;request=1;write=1;advance=0;index=0;data=18'h3ffff;tick(1,1);
  request=0;advance=1;tick(1,1);random_steps(20000,1,1);
  // Re-read every ROM address after all state writes; ROM is immutable.
  advance=1;cs_n=0;pd_n=0;
  for(a=0;a<2048;a=a+1)begin address=a;tick(1,1);end
  $display("I2716 PASS: %0d host/%0d held/%0d accepted/%0d writes/%0d late changes;72bits/all32indices/allROMaddresses/emptyX/unknown-state/freeze/restore/firstedge/20000more",edges,holds,accepted,writes,late);
  $finish;
 end
endmodule
