# Only the added virtual capacity contract ports; all real clocks/IO unchanged.
set capacity_clock [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}]
if {[get_collection_size $capacity_clock]!=1} {error "Expected native 50MHz host clock"}
set capacity_inputs [get_ports {CAPACITY_SERVICES_HELD[*] CAPACITY_TRANSPORT_RESET}]
if {[get_collection_size $capacity_inputs]!=6} {error "Expected six virtual capacity inputs"}
set_input_delay -clock $capacity_clock -max 2.000 $capacity_inputs
set_input_delay -clock $capacity_clock -min 0.000 $capacity_inputs
set_output_delay -clock $capacity_clock -max 2.000 [get_ports CAPACITY_MEMORY_DRAINED]
set_output_delay -clock $capacity_clock -min 0.000 [get_ports CAPACITY_MEMORY_DRAINED]
