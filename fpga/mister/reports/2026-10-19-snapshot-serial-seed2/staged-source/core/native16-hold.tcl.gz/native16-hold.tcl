project_open Dorado
foreach model {fast slow} {
 create_timing_netlist -model $model
 read_sdc
 update_timing_netlist
 report_timing -hold -npaths 40 -detail full_path -file native16-hold-$model.rpt
 delete_timing_netlist
}
project_close
