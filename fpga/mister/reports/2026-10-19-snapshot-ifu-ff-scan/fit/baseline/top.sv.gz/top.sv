module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [78:0] stimulus,
 input wire freeze,held,request,write,input wire [17:0] index,
 input wire [17:0] state_data,output reg [82:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Matched positive-edge launch/capture:20ns embedded paths at50MHz, both variants.
 reg [120:0] launch;
 always @(posedge host_clk)
  launch<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [78:0] stimulus_r;wire [17:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [82:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_CrryEvCntA__drv;
wire bank_DMuxData__drv;
wire bank_EnableFG_p___drv;
wire bank_GDv_p___drv;
wire bank_GLd_p___drv;
wire bank_GenOut_00__drv;
wire bank_GenOut_01__drv;
wire bank_GenOut_02__drv;
wire bank_GenOut_03__drv;
wire bank_GenOut_04__drv;
wire bank_GenOut_05__drv;
wire bank_GenOut_06__drv;
wire bank_GenOut_07__drv;
wire bank_GenOut_08__drv;
wire bank_GenOut_09__drv;
wire bank_GenOut_10__drv;
wire bank_GenOut_11__drv;
wire bank_GenOut_12__drv;
wire bank_GenOut_13__drv;
wire bank_GenOut_14__drv;
wire bank_GenOut_15__drv;
wire bank_IfuAck__drv;
wire bank_IfuAddr_04_p___drv;
wire bank_IfuAddr_05_p___drv;
wire bank_IfuAddr_06_p___drv;
wire bank_IfuAddr_07_p___drv;
wire bank_IfuAddr_08_p___drv;
wire bank_IfuAddr_09_p___drv;
wire bank_IfuAddr_10_p___drv;
wire bank_IfuAddr_11_p___drv;
wire bank_IfuAddr_12_p___drv;
wire bank_IfuAddr_13_p___drv;
wire bank_IfuData_0__drv;
wire bank_IfuData_1__drv;
wire bank_IfuData_2__drv;
wire bank_IfuData_3__drv;
wire bank_IfuData_4__drv;
wire bank_IfuData_5__drv;
wire bank_IfuData_6__drv;
wire bank_IfuData_7__drv;
wire bank_IfuFaultInEc2__drv;
wire bank_IfuRBaseSel_p___drv;
wire bank_MAR_00_p___drv;
wire bank_MAR_01_p___drv;
wire bank_MAR_02_p___drv;
wire bank_MAR_03_p___drv;
wire bank_MAR_04_p___drv;
wire bank_MAR_05_p___drv;
wire bank_MAR_06_p___drv;
wire bank_MAR_07_p___drv;
wire bank_MAR_08_p___drv;
wire bank_MAR_09_p___drv;
wire bank_MAR_10_p___drv;
wire bank_MAR_11_p___drv;
wire bank_MAR_12_p___drv;
wire bank_MAR_13_p___drv;
wire bank_MAR_14_p___drv;
wire bank_MAR_15_p___drv;
wire bank_MemBM_0__drv;
wire bank_MemBM_1__drv;
wire bank_MemBM34__drv;
wire bank_PcFG_15__drv;
wire bank_RefOutstanding_p___drv;
wire bank_SignIfuData__drv;
wire bank_TWReq_02__drv;
wire bank_WantIfuHold_p___drv;
wire bank_WantIfuRef_p___drv;
assign bank_q={bank_WantIfuRef_p___drv,bank_WantIfuHold_p___drv,bank_TWReq_02__drv,bank_SignIfuData__drv,bank_RefOutstanding_p___drv,bank_PcFG_15__drv,bank_MemBM34__drv,bank_MemBM_1__drv,bank_MemBM_0__drv,bank_MAR_15_p___drv,bank_MAR_14_p___drv,bank_MAR_13_p___drv,bank_MAR_12_p___drv,bank_MAR_11_p___drv,bank_MAR_10_p___drv,bank_MAR_09_p___drv,bank_MAR_08_p___drv,bank_MAR_07_p___drv,bank_MAR_06_p___drv,bank_MAR_05_p___drv,bank_MAR_04_p___drv,bank_MAR_03_p___drv,bank_MAR_02_p___drv,bank_MAR_01_p___drv,bank_MAR_00_p___drv,bank_IfuRBaseSel_p___drv,bank_IfuFaultInEc2__drv,bank_IfuData_7__drv,bank_IfuData_6__drv,bank_IfuData_5__drv,bank_IfuData_4__drv,bank_IfuData_3__drv,bank_IfuData_2__drv,bank_IfuData_1__drv,bank_IfuData_0__drv,bank_IfuAddr_13_p___drv,bank_IfuAddr_12_p___drv,bank_IfuAddr_11_p___drv,bank_IfuAddr_10_p___drv,bank_IfuAddr_09_p___drv,bank_IfuAddr_08_p___drv,bank_IfuAddr_07_p___drv,bank_IfuAddr_06_p___drv,bank_IfuAddr_05_p___drv,bank_IfuAddr_04_p___drv,bank_IfuAck__drv,bank_GenOut_15__drv,bank_GenOut_14__drv,bank_GenOut_13__drv,bank_GenOut_12__drv,bank_GenOut_11__drv,bank_GenOut_10__drv,bank_GenOut_09__drv,bank_GenOut_08__drv,bank_GenOut_07__drv,bank_GenOut_06__drv,bank_GenOut_05__drv,bank_GenOut_04__drv,bank_GenOut_03__drv,bank_GenOut_02__drv,bank_GenOut_01__drv,bank_GenOut_00__drv,bank_GLd_p___drv,bank_GDv_p___drv,bank_EnableFG_p___drv,bank_DMuxData__drv,bank_CrryEvCntA__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 IFU_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 IFU_m_Rev_m_Ch #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.ASEL_0_p_(stimulus_r[0]),
.BMux_00(stimulus_r[1] | bank_BMux_00__drv),
.BMux_01(stimulus_r[2] | bank_BMux_01__drv),
.BMux_02(stimulus_r[3] | bank_BMux_02__drv),
.BMux_03(stimulus_r[4] | bank_BMux_03__drv),
.BMux_04(stimulus_r[5] | bank_BMux_04__drv),
.BMux_05(stimulus_r[6] | bank_BMux_05__drv),
.BMux_06(stimulus_r[7] | bank_BMux_06__drv),
.BMux_07(stimulus_r[8] | bank_BMux_07__drv),
.BMux_08(stimulus_r[9] | bank_BMux_08__drv),
.BMux_09(stimulus_r[10] | bank_BMux_09__drv),
.BMux_10(stimulus_r[11] | bank_BMux_10__drv),
.BMux_11(stimulus_r[12] | bank_BMux_11__drv),
.BMux_12(stimulus_r[13] | bank_BMux_12__drv),
.BMux_13(stimulus_r[14] | bank_BMux_13__drv),
.BMux_14(stimulus_r[15] | bank_BMux_14__drv),
.BMux_15(stimulus_r[16] | bank_BMux_15__drv),
.CLK_ifu_p_(stimulus_r[17]),
.CLKEnable_p_a(stimulus_r[18]),
.CountMiss(stimulus_r[19]),
.DMuxClk(stimulus_r[20]),
.DMuxData(stimulus_r[21] | bank_DMuxData__drv),
.EmuOrFT_p_(stimulus_r[22]),
.EnableFG_p_(stimulus_r[23] | bank_EnableFG_p___drv),
.EventA(stimulus_r[24]),
.EventB(stimulus_r[25]),
.EventC(stimulus_r[26]),
.EventD(stimulus_r[27]),
.EventE(stimulus_r[28]),
.FA_eq_1_p_(stimulus_r[29]),
.FF_2(stimulus_r[30]),
.FF_3(stimulus_r[31]),
.FF_4(stimulus_r[32]),
.FF_5(stimulus_r[33]),
.FF_6(stimulus_r[34]),
.FF_7(stimulus_r[35]),
.FG_0(stimulus_r[36]),
.FG_1(stimulus_r[37]),
.FG_2(stimulus_r[38]),
.FG_3(stimulus_r[39]),
.FG_4(stimulus_r[40]),
.FG_5(stimulus_r[41]),
.FG_6(stimulus_r[42]),
.FG_7(stimulus_r[43]),
.FG_8(stimulus_r[44]),
.GDv_p_(stimulus_r[45] | bank_GDv_p___drv),
.GLd_p_(stimulus_r[46] | bank_GLd_p___drv),
.GenIn_00(stimulus_r[47]),
.GenIn_01(stimulus_r[48]),
.GenIn_02(stimulus_r[49]),
.GenIn_03(stimulus_r[50]),
.GenIn_04(stimulus_r[51]),
.GenIn_05(stimulus_r[52]),
.GenIn_06(stimulus_r[53]),
.GenIn_07(stimulus_r[54]),
.GenIn_08(stimulus_r[55]),
.GenIn_09(stimulus_r[56]),
.GenIn_10(stimulus_r[57]),
.GenIn_11(stimulus_r[58]),
.GenIn_12(stimulus_r[59]),
.GenIn_13(stimulus_r[60]),
.GenIn_14(stimulus_r[61]),
.GenIn_15(stimulus_r[62]),
.IOReset(stimulus_r[63]),
.IfuAWantsDifHit_p_(stimulus_r[64]),
.IfuAck(stimulus_r[65] | bank_IfuAck__drv),
.IfuFaultInEc2(stimulus_r[66] | bank_IfuFaultInEc2__drv),
.IfuHold(stimulus_r[67]),
.IfuNextMacro_p_(stimulus_r[68]),
.IfuStartMap_p_(stimulus_r[69]),
.MakeF_u_D(stimulus_r[70]),
.MemClkEn_p_a(stimulus_r[71]),
.MemSH(stimulus_r[72]),
.NextData_p_(stimulus_r[73]),
.Pendulum(stimulus_r[74]),
.RefOutstanding_p_(stimulus_r[75] | bank_RefOutstanding_p___drv),
.TempRef(stimulus_r[76]),
.WantIfuHold_p_(stimulus_r[77] | bank_WantIfuHold_p___drv),
.WantIfuRef_p_(stimulus_r[78] | bank_WantIfuRef_p___drv),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.CrryEvCntA__drv(bank_CrryEvCntA__drv),
.DMuxData__drv(bank_DMuxData__drv),
.EnableFG_p___drv(bank_EnableFG_p___drv),
.GDv_p___drv(bank_GDv_p___drv),
.GLd_p___drv(bank_GLd_p___drv),
.GenOut_00__drv(bank_GenOut_00__drv),
.GenOut_01__drv(bank_GenOut_01__drv),
.GenOut_02__drv(bank_GenOut_02__drv),
.GenOut_03__drv(bank_GenOut_03__drv),
.GenOut_04__drv(bank_GenOut_04__drv),
.GenOut_05__drv(bank_GenOut_05__drv),
.GenOut_06__drv(bank_GenOut_06__drv),
.GenOut_07__drv(bank_GenOut_07__drv),
.GenOut_08__drv(bank_GenOut_08__drv),
.GenOut_09__drv(bank_GenOut_09__drv),
.GenOut_10__drv(bank_GenOut_10__drv),
.GenOut_11__drv(bank_GenOut_11__drv),
.GenOut_12__drv(bank_GenOut_12__drv),
.GenOut_13__drv(bank_GenOut_13__drv),
.GenOut_14__drv(bank_GenOut_14__drv),
.GenOut_15__drv(bank_GenOut_15__drv),
.IfuAck__drv(bank_IfuAck__drv),
.IfuAddr_04_p___drv(bank_IfuAddr_04_p___drv),
.IfuAddr_05_p___drv(bank_IfuAddr_05_p___drv),
.IfuAddr_06_p___drv(bank_IfuAddr_06_p___drv),
.IfuAddr_07_p___drv(bank_IfuAddr_07_p___drv),
.IfuAddr_08_p___drv(bank_IfuAddr_08_p___drv),
.IfuAddr_09_p___drv(bank_IfuAddr_09_p___drv),
.IfuAddr_10_p___drv(bank_IfuAddr_10_p___drv),
.IfuAddr_11_p___drv(bank_IfuAddr_11_p___drv),
.IfuAddr_12_p___drv(bank_IfuAddr_12_p___drv),
.IfuAddr_13_p___drv(bank_IfuAddr_13_p___drv),
.IfuData_0__drv(bank_IfuData_0__drv),
.IfuData_1__drv(bank_IfuData_1__drv),
.IfuData_2__drv(bank_IfuData_2__drv),
.IfuData_3__drv(bank_IfuData_3__drv),
.IfuData_4__drv(bank_IfuData_4__drv),
.IfuData_5__drv(bank_IfuData_5__drv),
.IfuData_6__drv(bank_IfuData_6__drv),
.IfuData_7__drv(bank_IfuData_7__drv),
.IfuFaultInEc2__drv(bank_IfuFaultInEc2__drv),
.IfuRBaseSel_p___drv(bank_IfuRBaseSel_p___drv),
.MAR_00_p___drv(bank_MAR_00_p___drv),
.MAR_01_p___drv(bank_MAR_01_p___drv),
.MAR_02_p___drv(bank_MAR_02_p___drv),
.MAR_03_p___drv(bank_MAR_03_p___drv),
.MAR_04_p___drv(bank_MAR_04_p___drv),
.MAR_05_p___drv(bank_MAR_05_p___drv),
.MAR_06_p___drv(bank_MAR_06_p___drv),
.MAR_07_p___drv(bank_MAR_07_p___drv),
.MAR_08_p___drv(bank_MAR_08_p___drv),
.MAR_09_p___drv(bank_MAR_09_p___drv),
.MAR_10_p___drv(bank_MAR_10_p___drv),
.MAR_11_p___drv(bank_MAR_11_p___drv),
.MAR_12_p___drv(bank_MAR_12_p___drv),
.MAR_13_p___drv(bank_MAR_13_p___drv),
.MAR_14_p___drv(bank_MAR_14_p___drv),
.MAR_15_p___drv(bank_MAR_15_p___drv),
.MemBM_0__drv(bank_MemBM_0__drv),
.MemBM_1__drv(bank_MemBM_1__drv),
.MemBM34__drv(bank_MemBM34__drv),
.PcFG_15__drv(bank_PcFG_15__drv),
.RefOutstanding_p___drv(bank_RefOutstanding_p___drv),
.SignIfuData__drv(bank_SignIfuData__drv),
.TWReq_02__drv(bank_TWReq_02__drv),
.WantIfuHold_p___drv(bank_WantIfuHold_p___drv),
.WantIfuRef_p___drv(bank_WantIfuRef_p___drv)
);
endmodule
