module address_fixture;
 reg clk=0,advance=0,hold=0,write=0,p4=0,p15=0;reg [17:0] state_data=0;reg [7:0] a=0;
 wire [15:0] addr8,ref8;wire [13:0] addr7,ref7;
 wire [17:0] state8,refstate8,state7,refstate7;wire change8,change7;
 integer seed=32'h1650866a,checks=0;reg [15:0] before8;reg [13:0] before7;reg expected8,expected7;
 dorado_serial_MSA__cell_MK4096P_addr_msa_snapshot #(.ROW_BITS(8)) dut8(.state_host_clk(clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(state_data),
 .state_result(state8),.sys_clk(clk),.p4(p4),.p15(p15),.a(a),.addr(addr8),.addr_will_change(change8));
 original_address_helper #(.ROW_BITS(8)) ref_dut8(.state_host_clk(clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(state_data),
 .state_result(refstate8),.sys_clk(clk),.p4(p4),.p15(p15),.a(a),.addr(ref8));
 dorado_serial_MSA__cell_MK4096P_addr_msa_snapshot #(.ROW_BITS(7)) dut7(.state_host_clk(clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(state_data),
 .state_result(state7),.sys_clk(clk),.p4(p4),.p15(p15),.a(a[6:0]),.addr(addr7),.addr_will_change(change7));
 original_address_helper #(.ROW_BITS(7)) ref_dut7(.state_host_clk(clk),.state_advance(advance),.state_hold(hold),.state_write(write),.state_data(state_data),
 .state_result(refstate7),.sys_clk(clk),.p4(p4),.p15(p15),.a(a[6:0]),.addr(ref7));
 task same;
  if({addr8,addr7,state8,state7}!=={ref8,ref7,refstate8,refstate7})$fatal(1,"original address state differs");
 endtask
 initial begin
  for(integer n=0;n<12000;n=n+1)begin
   clk=0;hold=1;write=1;state_data=$random(seed);advance=0;#1;clk=1;#1;same;
   clk=0;hold=0;write=0;advance=1;p4=$random(seed);p15=$random(seed);
   case(n%5)
    0:a=ref8[7:0];
    1:a=ref8[15:8];
    2:a={1'b0,ref7[6:0]};
    3:a={1'b0,ref7[13:7]};
    4:a=$random(seed);
   endcase
   #1;before8=ref8;before7=ref7;expected8=change8;expected7=change7;
   clk=1;#1;same;
   if((ref8!=before8)!==expected8 || (ref7!=before7)!==expected7)$fatal(1,"address change prediction differs");
   checks=checks+1;
  end
  $display("ADDRESS PREDICTION PASS independent_states=%0d geometries=7/8",checks);$finish;
 end
endmodule
