module msa_board_fixture(
 input wire clk,ref_clk,advance,freeze,held,global_hold,global_abort,system_reset,request,write,reset,
 input wire [23:0] state_index,input wire [17:0] state_data,input wire [46:0] stimulus,
 input wire [15:0] req_ready,rsp_valid,input wire [15:0] rsp_data[16],
 output wire [15:0] req_valid,req_write,rsp_ready,ref_req_valid,ref_req_write,ref_rsp_ready,
 output wire [15:0] req_addr[16],req_data[16],ref_req_addr[16],ref_req_data[16],
 output wire storage_ready,ref_storage_ready,ready,frozen,done,error,hold_required,fault,drained,
 output wire [15:0] helper_frozen,output wire busy,scan_step,
 output wire [17:0] result,output wire [18:0] dut_outputs,reference_outputs,
 output wire [1649:0] dut_state,reference_state);
 wire reference_machine_clk=ref_clk && advance;
 wire candidate_machine_clk=clk && advance;
wire reference_EcIn_0__drv;
wire reference_EcIn_1__drv;
wire reference_M0__drv;
wire reference_Sin_00__drv;
wire reference_Sin_01__drv;
wire reference_Sin_02__drv;
wire reference_Sin_03__drv;
wire reference_Sin_04__drv;
wire reference_Sin_05__drv;
wire reference_Sin_06__drv;
wire reference_Sin_07__drv;
wire reference_Sin_08__drv;
wire reference_Sin_09__drv;
wire reference_Sin_10__drv;
wire reference_Sin_11__drv;
wire reference_Sin_12__drv;
wire reference_Sin_13__drv;
wire reference_Sin_14__drv;
wire reference_Sin_15__drv;
wire [255:0] reference_req_addr_bus;
assign ref_req_addr[0]=reference_req_addr_bus[0+:16];
assign ref_req_addr[1]=reference_req_addr_bus[16+:16];
assign ref_req_addr[2]=reference_req_addr_bus[32+:16];
assign ref_req_addr[3]=reference_req_addr_bus[48+:16];
assign ref_req_addr[4]=reference_req_addr_bus[64+:16];
assign ref_req_addr[5]=reference_req_addr_bus[80+:16];
assign ref_req_addr[6]=reference_req_addr_bus[96+:16];
assign ref_req_addr[7]=reference_req_addr_bus[112+:16];
assign ref_req_addr[8]=reference_req_addr_bus[128+:16];
assign ref_req_addr[9]=reference_req_addr_bus[144+:16];
assign ref_req_addr[10]=reference_req_addr_bus[160+:16];
assign ref_req_addr[11]=reference_req_addr_bus[176+:16];
assign ref_req_addr[12]=reference_req_addr_bus[192+:16];
assign ref_req_addr[13]=reference_req_addr_bus[208+:16];
assign ref_req_addr[14]=reference_req_addr_bus[224+:16];
assign ref_req_addr[15]=reference_req_addr_bus[240+:16];
wire [255:0] reference_req_data_bus;
assign ref_req_data[0]=reference_req_data_bus[0+:16];
assign ref_req_data[1]=reference_req_data_bus[16+:16];
assign ref_req_data[2]=reference_req_data_bus[32+:16];
assign ref_req_data[3]=reference_req_data_bus[48+:16];
assign ref_req_data[4]=reference_req_data_bus[64+:16];
assign ref_req_data[5]=reference_req_data_bus[80+:16];
assign ref_req_data[6]=reference_req_data_bus[96+:16];
assign ref_req_data[7]=reference_req_data_bus[112+:16];
assign ref_req_data[8]=reference_req_data_bus[128+:16];
assign ref_req_data[9]=reference_req_data_bus[144+:16];
assign ref_req_data[10]=reference_req_data_bus[160+:16];
assign ref_req_data[11]=reference_req_data_bus[176+:16];
assign ref_req_data[12]=reference_req_data_bus[192+:16];
assign ref_req_data[13]=reference_req_data_bus[208+:16];
assign ref_req_data[14]=reference_req_data_bus[224+:16];
assign ref_req_data[15]=reference_req_data_bus[240+:16];
wire [255:0] reference_rsp_data_bus;
assign reference_rsp_data_bus[0+:16]=rsp_data[0];
assign reference_rsp_data_bus[16+:16]=rsp_data[1];
assign reference_rsp_data_bus[32+:16]=rsp_data[2];
assign reference_rsp_data_bus[48+:16]=rsp_data[3];
assign reference_rsp_data_bus[64+:16]=rsp_data[4];
assign reference_rsp_data_bus[80+:16]=rsp_data[5];
assign reference_rsp_data_bus[96+:16]=rsp_data[6];
assign reference_rsp_data_bus[112+:16]=rsp_data[7];
assign reference_rsp_data_bus[128+:16]=rsp_data[8];
assign reference_rsp_data_bus[144+:16]=rsp_data[9];
assign reference_rsp_data_bus[160+:16]=rsp_data[10];
assign reference_rsp_data_bus[176+:16]=rsp_data[11];
assign reference_rsp_data_bus[192+:16]=rsp_data[12];
assign reference_rsp_data_bus[208+:16]=rsp_data[13];
assign reference_rsp_data_bus[224+:16]=rsp_data[14];
assign reference_rsp_data_bus[240+:16]=rsp_data[15];
msa_ddram #(.SYSPER(4)) reference(
.sys_clk(reference_machine_clk),
.storage_clk(ref_clk),
.storage_reset(reset),
.storage_ready(ref_storage_ready),
.CLK_ms0Even_p_(stimulus[0]),
.ChipsAre16k(stimulus[1]),
.ChipsAre4k(stimulus[2]),
.ChipsAre64K(stimulus[3]),
.EcOut_0(stimulus[4]),
.EcOut_1(stimulus[5]),
.EcOut_4(stimulus[6]),
.EcOut_5(stimulus[7]),
.LoadEcOut_p_(stimulus[8]),
.LoadSinE(stimulus[9]),
.LoadSoutE_p_(stimulus[10]),
.Mb0(stimulus[11]),
.MemAd_1(stimulus[12]),
.MemAd_2(stimulus[13]),
.MemAd_3(stimulus[14]),
.MemAd_4(stimulus[15]),
.MemAd_5(stimulus[16]),
.MemAd_6(stimulus[17]),
.MemAd_7(stimulus[18]),
.MemAd_8(stimulus[19]),
.MemCASa(stimulus[20]),
.MemCASb(stimulus[21]),
.MemRASa(stimulus[22]),
.MemRASb(stimulus[23]),
.MemWEa(stimulus[24]),
.MemWEb(stimulus[25]),
.Mod0SinEn_p_(stimulus[26]),
.Mod0StrEn_p_(stimulus[27]),
.ShiftEcOut(stimulus[28]),
.ShiftSinE(stimulus[29]),
.ShiftSoutE(stimulus[30]),
.Sout_00(stimulus[31]),
.Sout_01(stimulus[32]),
.Sout_02(stimulus[33]),
.Sout_03(stimulus[34]),
.Sout_04(stimulus[35]),
.Sout_05(stimulus[36]),
.Sout_06(stimulus[37]),
.Sout_07(stimulus[38]),
.Sout_08(stimulus[39]),
.Sout_09(stimulus[40]),
.Sout_10(stimulus[41]),
.Sout_11(stimulus[42]),
.Sout_12(stimulus[43]),
.Sout_13(stimulus[44]),
.Sout_14(stimulus[45]),
.Sout_15(stimulus[46]),
.EcIn_0__drv(reference_EcIn_0__drv),
.EcIn_1__drv(reference_EcIn_1__drv),
.M0__drv(reference_M0__drv),
.Sin_00__drv(reference_Sin_00__drv),
.Sin_01__drv(reference_Sin_01__drv),
.Sin_02__drv(reference_Sin_02__drv),
.Sin_03__drv(reference_Sin_03__drv),
.Sin_04__drv(reference_Sin_04__drv),
.Sin_05__drv(reference_Sin_05__drv),
.Sin_06__drv(reference_Sin_06__drv),
.Sin_07__drv(reference_Sin_07__drv),
.Sin_08__drv(reference_Sin_08__drv),
.Sin_09__drv(reference_Sin_09__drv),
.Sin_10__drv(reference_Sin_10__drv),
.Sin_11__drv(reference_Sin_11__drv),
.Sin_12__drv(reference_Sin_12__drv),
.Sin_13__drv(reference_Sin_13__drv),
.Sin_14__drv(reference_Sin_14__drv),
.Sin_15__drv(reference_Sin_15__drv),
.storage_req_addr(reference_req_addr_bus),
.storage_req_data(reference_req_data_bus),
.storage_rsp_data(reference_rsp_data_bus),
.storage_req_ready(req_ready),
.storage_rsp_valid(rsp_valid),
.storage_req_valid(ref_req_valid),
.storage_req_write(ref_req_write),
.storage_rsp_ready(ref_rsp_ready)
);
assign reference_outputs={reference_Sin_15__drv,reference_Sin_14__drv,reference_Sin_13__drv,reference_Sin_12__drv,reference_Sin_11__drv,reference_Sin_10__drv,reference_Sin_09__drv,reference_Sin_08__drv,reference_Sin_07__drv,reference_Sin_06__drv,reference_Sin_05__drv,reference_Sin_04__drv,reference_Sin_03__drv,reference_Sin_02__drv,reference_Sin_01__drv,reference_Sin_00__drv,reference_M0__drv,reference_EcIn_1__drv,reference_EcIn_0__drv};
wire dut_EcIn_0__drv;
wire dut_EcIn_1__drv;
wire dut_M0__drv;
wire dut_Sin_00__drv;
wire dut_Sin_01__drv;
wire dut_Sin_02__drv;
wire dut_Sin_03__drv;
wire dut_Sin_04__drv;
wire dut_Sin_05__drv;
wire dut_Sin_06__drv;
wire dut_Sin_07__drv;
wire dut_Sin_08__drv;
wire dut_Sin_09__drv;
wire dut_Sin_10__drv;
wire dut_Sin_11__drv;
wire dut_Sin_12__drv;
wire dut_Sin_13__drv;
wire dut_Sin_14__drv;
wire dut_Sin_15__drv;
wire [255:0] dut_req_addr_bus;
assign req_addr[0]=dut_req_addr_bus[0+:16];
assign req_addr[1]=dut_req_addr_bus[16+:16];
assign req_addr[2]=dut_req_addr_bus[32+:16];
assign req_addr[3]=dut_req_addr_bus[48+:16];
assign req_addr[4]=dut_req_addr_bus[64+:16];
assign req_addr[5]=dut_req_addr_bus[80+:16];
assign req_addr[6]=dut_req_addr_bus[96+:16];
assign req_addr[7]=dut_req_addr_bus[112+:16];
assign req_addr[8]=dut_req_addr_bus[128+:16];
assign req_addr[9]=dut_req_addr_bus[144+:16];
assign req_addr[10]=dut_req_addr_bus[160+:16];
assign req_addr[11]=dut_req_addr_bus[176+:16];
assign req_addr[12]=dut_req_addr_bus[192+:16];
assign req_addr[13]=dut_req_addr_bus[208+:16];
assign req_addr[14]=dut_req_addr_bus[224+:16];
assign req_addr[15]=dut_req_addr_bus[240+:16];
wire [255:0] dut_req_data_bus;
assign req_data[0]=dut_req_data_bus[0+:16];
assign req_data[1]=dut_req_data_bus[16+:16];
assign req_data[2]=dut_req_data_bus[32+:16];
assign req_data[3]=dut_req_data_bus[48+:16];
assign req_data[4]=dut_req_data_bus[64+:16];
assign req_data[5]=dut_req_data_bus[80+:16];
assign req_data[6]=dut_req_data_bus[96+:16];
assign req_data[7]=dut_req_data_bus[112+:16];
assign req_data[8]=dut_req_data_bus[128+:16];
assign req_data[9]=dut_req_data_bus[144+:16];
assign req_data[10]=dut_req_data_bus[160+:16];
assign req_data[11]=dut_req_data_bus[176+:16];
assign req_data[12]=dut_req_data_bus[192+:16];
assign req_data[13]=dut_req_data_bus[208+:16];
assign req_data[14]=dut_req_data_bus[224+:16];
assign req_data[15]=dut_req_data_bus[240+:16];
wire [255:0] dut_rsp_data_bus;
assign dut_rsp_data_bus[0+:16]=rsp_data[0];
assign dut_rsp_data_bus[16+:16]=rsp_data[1];
assign dut_rsp_data_bus[32+:16]=rsp_data[2];
assign dut_rsp_data_bus[48+:16]=rsp_data[3];
assign dut_rsp_data_bus[64+:16]=rsp_data[4];
assign dut_rsp_data_bus[80+:16]=rsp_data[5];
assign dut_rsp_data_bus[96+:16]=rsp_data[6];
assign dut_rsp_data_bus[112+:16]=rsp_data[7];
assign dut_rsp_data_bus[128+:16]=rsp_data[8];
assign dut_rsp_data_bus[144+:16]=rsp_data[9];
assign dut_rsp_data_bus[160+:16]=rsp_data[10];
assign dut_rsp_data_bus[176+:16]=rsp_data[11];
assign dut_rsp_data_bus[192+:16]=rsp_data[12];
assign dut_rsp_data_bus[208+:16]=rsp_data[13];
assign dut_rsp_data_bus[224+:16]=rsp_data[14];
assign dut_rsp_data_bus[240+:16]=rsp_data[15];
dorado_serial_MSA #(.SYSPER(4)) dut(
.sys_clk(candidate_machine_clk),
.storage_clk(clk),
.storage_reset(reset),
.storage_ready(storage_ready),
.CLK_ms0Even_p_(stimulus[0]),
.ChipsAre16k(stimulus[1]),
.ChipsAre4k(stimulus[2]),
.ChipsAre64K(stimulus[3]),
.EcOut_0(stimulus[4]),
.EcOut_1(stimulus[5]),
.EcOut_4(stimulus[6]),
.EcOut_5(stimulus[7]),
.LoadEcOut_p_(stimulus[8]),
.LoadSinE(stimulus[9]),
.LoadSoutE_p_(stimulus[10]),
.Mb0(stimulus[11]),
.MemAd_1(stimulus[12]),
.MemAd_2(stimulus[13]),
.MemAd_3(stimulus[14]),
.MemAd_4(stimulus[15]),
.MemAd_5(stimulus[16]),
.MemAd_6(stimulus[17]),
.MemAd_7(stimulus[18]),
.MemAd_8(stimulus[19]),
.MemCASa(stimulus[20]),
.MemCASb(stimulus[21]),
.MemRASa(stimulus[22]),
.MemRASb(stimulus[23]),
.MemWEa(stimulus[24]),
.MemWEb(stimulus[25]),
.Mod0SinEn_p_(stimulus[26]),
.Mod0StrEn_p_(stimulus[27]),
.ShiftEcOut(stimulus[28]),
.ShiftSinE(stimulus[29]),
.ShiftSoutE(stimulus[30]),
.Sout_00(stimulus[31]),
.Sout_01(stimulus[32]),
.Sout_02(stimulus[33]),
.Sout_03(stimulus[34]),
.Sout_04(stimulus[35]),
.Sout_05(stimulus[36]),
.Sout_06(stimulus[37]),
.Sout_07(stimulus[38]),
.Sout_08(stimulus[39]),
.Sout_09(stimulus[40]),
.Sout_10(stimulus[41]),
.Sout_11(stimulus[42]),
.Sout_12(stimulus[43]),
.Sout_13(stimulus[44]),
.Sout_14(stimulus[45]),
.Sout_15(stimulus[46]),
.EcIn_0__drv(dut_EcIn_0__drv),
.EcIn_1__drv(dut_EcIn_1__drv),
.M0__drv(dut_M0__drv),
.Sin_00__drv(dut_Sin_00__drv),
.Sin_01__drv(dut_Sin_01__drv),
.Sin_02__drv(dut_Sin_02__drv),
.Sin_03__drv(dut_Sin_03__drv),
.Sin_04__drv(dut_Sin_04__drv),
.Sin_05__drv(dut_Sin_05__drv),
.Sin_06__drv(dut_Sin_06__drv),
.Sin_07__drv(dut_Sin_07__drv),
.Sin_08__drv(dut_Sin_08__drv),
.Sin_09__drv(dut_Sin_09__drv),
.Sin_10__drv(dut_Sin_10__drv),
.Sin_11__drv(dut_Sin_11__drv),
.Sin_12__drv(dut_Sin_12__drv),
.Sin_13__drv(dut_Sin_13__drv),
.Sin_14__drv(dut_Sin_14__drv),
.Sin_15__drv(dut_Sin_15__drv),
.storage_req_addr(dut_req_addr_bus),
.storage_req_data(dut_req_data_bus),
.storage_rsp_data(dut_rsp_data_bus),
.storage_req_ready(req_ready),
.storage_rsp_valid(rsp_valid),
.storage_req_valid(req_valid),
.storage_req_write(req_write),
.storage_rsp_ready(rsp_ready),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_global_hold(global_hold),
.state_global_abort(global_abort),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(state_index),
.state_data(state_data),
.state_scan_hold_required(hold_required),
.state_scan_fault(fault),
.state_memory_drained(drained),
.state_ready(ready),
.state_frozen(frozen),
.state_done(done),
.state_error(error),
.state_result(result)
);
assign dut_outputs={dut_Sin_15__drv,dut_Sin_14__drv,dut_Sin_13__drv,dut_Sin_12__drv,dut_Sin_11__drv,dut_Sin_10__drv,dut_Sin_09__drv,dut_Sin_08__drv,dut_Sin_07__drv,dut_Sin_06__drv,dut_Sin_05__drv,dut_Sin_04__drv,dut_Sin_03__drv,dut_Sin_02__drv,dut_Sin_01__drv,dut_Sin_00__drv,dut_M0__drv,dut_EcIn_1__drv,dut_EcIn_0__drv};
assign helper_frozen=dut.state_storage_frozen;assign busy=dut.scan_busy;assign scan_step=dut.scan_step;
assign dut_state[0+:1]=dut.u_a01.ck_d;
assign reference_state[0+:1]=reference.u_a01.ck_d;
assign dut_state[1+:4]=dut.u_a01.d_pre;
assign reference_state[1+:4]=reference.u_a01.d_pre;
assign dut_state[5+:1]=dut.u_a01.dl_pre;
assign reference_state[5+:1]=reference.u_a01.dl_pre;
assign dut_state[6+:1]=dut.u_a01.dr_pre;
assign reference_state[6+:1]=reference.u_a01.dr_pre;
assign dut_state[7+:4]=dut.u_a01.q;
assign reference_state[7+:4]=reference.u_a01.q;
assign dut_state[11+:2]=dut.u_a01.s_pre;
assign reference_state[11+:2]=reference.u_a01.s_pre;
assign dut_state[13+:1]=dut.u_a03.ck_d;
assign reference_state[13+:1]=reference.u_a03.ck_d;
assign dut_state[14+:6]=dut.u_a03.q;
assign reference_state[14+:6]=reference.u_a03.q;
assign dut_state[20+:1]=dut.u_a04.ck_d;
assign reference_state[20+:1]=reference.u_a04.ck_d;
assign dut_state[21+:6]=dut.u_a04.q;
assign reference_state[21+:6]=reference.u_a04.q;
assign dut_state[27+:1]=dut.u_a05.ck_d;
assign reference_state[27+:1]=reference.u_a05.ck_d;
assign dut_state[28+:6]=dut.u_a05.q;
assign reference_state[28+:6]=reference.u_a05.q;
assign dut_state[34+:1]=dut.u_a13.ck_d;
assign reference_state[34+:1]=reference.u_a13.ck_d;
assign dut_state[35+:8]=dut.u_a13.q;
assign reference_state[35+:8]=reference.u_a13.q;
assign dut_state[43+:1]=dut.u_a14.ck_d;
assign reference_state[43+:1]=reference.u_a14.ck_d;
assign dut_state[44+:8]=dut.u_a14.q;
assign reference_state[44+:8]=reference.u_a14.q;
assign dut_state[52+:1]=dut.u_a22.ck_d;
assign reference_state[52+:1]=reference.u_a22.ck_d;
assign dut_state[53+:6]=dut.u_a22.q;
assign reference_state[53+:6]=reference.u_a22.q;
assign dut_state[59+:1]=dut.u_a23.ck_d;
assign reference_state[59+:1]=reference.u_a23.ck_d;
assign dut_state[60+:6]=dut.u_a23.q;
assign reference_state[60+:6]=reference.u_a23.q;
assign dut_state[66+:1]=dut.u_a24.ck_d;
assign reference_state[66+:1]=reference.u_a24.ck_d;
assign dut_state[67+:6]=dut.u_a24.q;
assign reference_state[67+:6]=reference.u_a24.q;
assign dut_state[73+:1]=dut.u_a26.ck_d;
assign reference_state[73+:1]=reference.u_a26.ck_d;
assign dut_state[74+:4]=dut.u_a26.d_pre;
assign reference_state[74+:4]=reference.u_a26.d_pre;
assign dut_state[78+:1]=dut.u_a26.dl_pre;
assign reference_state[78+:1]=reference.u_a26.dl_pre;
assign dut_state[79+:1]=dut.u_a26.dr_pre;
assign reference_state[79+:1]=reference.u_a26.dr_pre;
assign dut_state[80+:4]=dut.u_a26.q;
assign reference_state[80+:4]=reference.u_a26.q;
assign dut_state[84+:2]=dut.u_a26.s_pre;
assign reference_state[84+:2]=reference.u_a26.s_pre;
assign dut_state[86+:1]=dut.u_b01.ck_d;
assign reference_state[86+:1]=reference.u_b01.ck_d;
assign dut_state[87+:6]=dut.u_b01.d_pre;
assign reference_state[87+:6]=reference.u_b01.d_pre;
assign dut_state[93+:6]=dut.u_b01.q;
assign reference_state[93+:6]=reference.u_b01.q;
assign dut_state[99+:1]=dut.u_b03.ck_d;
assign reference_state[99+:1]=reference.u_b03.ck_d;
assign dut_state[100+:6]=dut.u_b03.q;
assign reference_state[100+:6]=reference.u_b03.q;
assign dut_state[106+:1]=dut.u_b13.ck_d;
assign reference_state[106+:1]=reference.u_b13.ck_d;
assign dut_state[107+:8]=dut.u_b13.q;
assign reference_state[107+:8]=reference.u_b13.q;
assign dut_state[115+:1]=dut.u_b14.ck_d;
assign reference_state[115+:1]=reference.u_b14.ck_d;
assign dut_state[116+:8]=dut.u_b14.q;
assign reference_state[116+:8]=reference.u_b14.q;
assign dut_state[124+:1]=dut.u_b24.ck_d;
assign reference_state[124+:1]=reference.u_b24.ck_d;
assign dut_state[125+:6]=dut.u_b24.q;
assign reference_state[125+:6]=reference.u_b24.q;
assign dut_state[131+:1]=dut.u_b26.ck_d;
assign reference_state[131+:1]=reference.u_b26.ck_d;
assign dut_state[132+:6]=dut.u_b26.d_pre;
assign reference_state[132+:6]=reference.u_b26.d_pre;
assign dut_state[138+:6]=dut.u_b26.q;
assign reference_state[138+:6]=reference.u_b26.q;
assign dut_state[144+:1]=dut.u_c01.ck_d;
assign reference_state[144+:1]=reference.u_c01.ck_d;
assign dut_state[145+:6]=dut.u_c01.d_pre;
assign reference_state[145+:6]=reference.u_c01.d_pre;
assign dut_state[151+:6]=dut.u_c01.q;
assign reference_state[151+:6]=reference.u_c01.q;
assign dut_state[157+:1]=dut.u_c03.ck_d;
assign reference_state[157+:1]=reference.u_c03.ck_d;
assign dut_state[158+:6]=dut.u_c03.q;
assign reference_state[158+:6]=reference.u_c03.q;
assign dut_state[164+:1]=dut.u_c13.ck_d;
assign reference_state[164+:1]=reference.u_c13.ck_d;
assign dut_state[165+:8]=dut.u_c13.q;
assign reference_state[165+:8]=reference.u_c13.q;
assign dut_state[173+:1]=dut.u_c14.ck_d;
assign reference_state[173+:1]=reference.u_c14.ck_d;
assign dut_state[174+:8]=dut.u_c14.q;
assign reference_state[174+:8]=reference.u_c14.q;
assign dut_state[182+:1]=dut.u_c24.ck_d;
assign reference_state[182+:1]=reference.u_c24.ck_d;
assign dut_state[183+:6]=dut.u_c24.q;
assign reference_state[183+:6]=reference.u_c24.q;
assign dut_state[189+:1]=dut.u_c26.ck_d;
assign reference_state[189+:1]=reference.u_c26.ck_d;
assign dut_state[190+:6]=dut.u_c26.d_pre;
assign reference_state[190+:6]=reference.u_c26.d_pre;
assign dut_state[196+:6]=dut.u_c26.q;
assign reference_state[196+:6]=reference.u_c26.q;
assign dut_state[202+:1]=dut.u_d03.ck_d;
assign reference_state[202+:1]=reference.u_d03.ck_d;
assign dut_state[203+:6]=dut.u_d03.q;
assign reference_state[203+:6]=reference.u_d03.q;
assign dut_state[209+:1]=dut.u_d13.ck_d;
assign reference_state[209+:1]=reference.u_d13.ck_d;
assign dut_state[210+:8]=dut.u_d13.q;
assign reference_state[210+:8]=reference.u_d13.q;
assign dut_state[218+:1]=dut.u_d14.ck_d;
assign reference_state[218+:1]=reference.u_d14.ck_d;
assign dut_state[219+:8]=dut.u_d14.q;
assign reference_state[219+:8]=reference.u_d14.q;
assign dut_state[227+:1]=dut.u_d24.ck_d;
assign reference_state[227+:1]=reference.u_d24.ck_d;
assign dut_state[228+:6]=dut.u_d24.q;
assign reference_state[228+:6]=reference.u_d24.q;
assign dut_state[234+:1]=dut.u_dram_addr_0.cas_d;
assign reference_state[234+:1]=reference.u_dram_addr_0.cas_d;
assign dut_state[235+:8]=dut.u_dram_addr_0.col;
assign reference_state[235+:8]=reference.u_dram_addr_0.col;
assign dut_state[243+:1]=dut.u_dram_addr_0.ras_d;
assign reference_state[243+:1]=reference.u_dram_addr_0.ras_d;
assign dut_state[244+:8]=dut.u_dram_addr_0.row;
assign reference_state[244+:8]=reference.u_dram_addr_0.row;
assign dut_state[252+:1]=dut.u_dram_addr_1.cas_d;
assign reference_state[252+:1]=reference.u_dram_addr_1.cas_d;
assign dut_state[253+:8]=dut.u_dram_addr_1.col;
assign reference_state[253+:8]=reference.u_dram_addr_1.col;
assign dut_state[261+:1]=dut.u_dram_addr_1.ras_d;
assign reference_state[261+:1]=reference.u_dram_addr_1.ras_d;
assign dut_state[262+:8]=dut.u_dram_addr_1.row;
assign reference_state[262+:8]=reference.u_dram_addr_1.row;
assign dut_state[270+:1]=dut.u_dram_addr_10.cas_d;
assign reference_state[270+:1]=reference.u_dram_addr_10.cas_d;
assign dut_state[271+:8]=dut.u_dram_addr_10.col;
assign reference_state[271+:8]=reference.u_dram_addr_10.col;
assign dut_state[279+:1]=dut.u_dram_addr_10.ras_d;
assign reference_state[279+:1]=reference.u_dram_addr_10.ras_d;
assign dut_state[280+:8]=dut.u_dram_addr_10.row;
assign reference_state[280+:8]=reference.u_dram_addr_10.row;
assign dut_state[288+:1]=dut.u_dram_addr_11.cas_d;
assign reference_state[288+:1]=reference.u_dram_addr_11.cas_d;
assign dut_state[289+:8]=dut.u_dram_addr_11.col;
assign reference_state[289+:8]=reference.u_dram_addr_11.col;
assign dut_state[297+:1]=dut.u_dram_addr_11.ras_d;
assign reference_state[297+:1]=reference.u_dram_addr_11.ras_d;
assign dut_state[298+:8]=dut.u_dram_addr_11.row;
assign reference_state[298+:8]=reference.u_dram_addr_11.row;
assign dut_state[306+:1]=dut.u_dram_addr_12.cas_d;
assign reference_state[306+:1]=reference.u_dram_addr_12.cas_d;
assign dut_state[307+:8]=dut.u_dram_addr_12.col;
assign reference_state[307+:8]=reference.u_dram_addr_12.col;
assign dut_state[315+:1]=dut.u_dram_addr_12.ras_d;
assign reference_state[315+:1]=reference.u_dram_addr_12.ras_d;
assign dut_state[316+:8]=dut.u_dram_addr_12.row;
assign reference_state[316+:8]=reference.u_dram_addr_12.row;
assign dut_state[324+:1]=dut.u_dram_addr_13.cas_d;
assign reference_state[324+:1]=reference.u_dram_addr_13.cas_d;
assign dut_state[325+:8]=dut.u_dram_addr_13.col;
assign reference_state[325+:8]=reference.u_dram_addr_13.col;
assign dut_state[333+:1]=dut.u_dram_addr_13.ras_d;
assign reference_state[333+:1]=reference.u_dram_addr_13.ras_d;
assign dut_state[334+:8]=dut.u_dram_addr_13.row;
assign reference_state[334+:8]=reference.u_dram_addr_13.row;
assign dut_state[342+:1]=dut.u_dram_addr_14.cas_d;
assign reference_state[342+:1]=reference.u_dram_addr_14.cas_d;
assign dut_state[343+:8]=dut.u_dram_addr_14.col;
assign reference_state[343+:8]=reference.u_dram_addr_14.col;
assign dut_state[351+:1]=dut.u_dram_addr_14.ras_d;
assign reference_state[351+:1]=reference.u_dram_addr_14.ras_d;
assign dut_state[352+:8]=dut.u_dram_addr_14.row;
assign reference_state[352+:8]=reference.u_dram_addr_14.row;
assign dut_state[360+:1]=dut.u_dram_addr_15.cas_d;
assign reference_state[360+:1]=reference.u_dram_addr_15.cas_d;
assign dut_state[361+:8]=dut.u_dram_addr_15.col;
assign reference_state[361+:8]=reference.u_dram_addr_15.col;
assign dut_state[369+:1]=dut.u_dram_addr_15.ras_d;
assign reference_state[369+:1]=reference.u_dram_addr_15.ras_d;
assign dut_state[370+:8]=dut.u_dram_addr_15.row;
assign reference_state[370+:8]=reference.u_dram_addr_15.row;
assign dut_state[378+:1]=dut.u_dram_addr_2.cas_d;
assign reference_state[378+:1]=reference.u_dram_addr_2.cas_d;
assign dut_state[379+:8]=dut.u_dram_addr_2.col;
assign reference_state[379+:8]=reference.u_dram_addr_2.col;
assign dut_state[387+:1]=dut.u_dram_addr_2.ras_d;
assign reference_state[387+:1]=reference.u_dram_addr_2.ras_d;
assign dut_state[388+:8]=dut.u_dram_addr_2.row;
assign reference_state[388+:8]=reference.u_dram_addr_2.row;
assign dut_state[396+:1]=dut.u_dram_addr_3.cas_d;
assign reference_state[396+:1]=reference.u_dram_addr_3.cas_d;
assign dut_state[397+:8]=dut.u_dram_addr_3.col;
assign reference_state[397+:8]=reference.u_dram_addr_3.col;
assign dut_state[405+:1]=dut.u_dram_addr_3.ras_d;
assign reference_state[405+:1]=reference.u_dram_addr_3.ras_d;
assign dut_state[406+:8]=dut.u_dram_addr_3.row;
assign reference_state[406+:8]=reference.u_dram_addr_3.row;
assign dut_state[414+:1]=dut.u_dram_addr_4.cas_d;
assign reference_state[414+:1]=reference.u_dram_addr_4.cas_d;
assign dut_state[415+:8]=dut.u_dram_addr_4.col;
assign reference_state[415+:8]=reference.u_dram_addr_4.col;
assign dut_state[423+:1]=dut.u_dram_addr_4.ras_d;
assign reference_state[423+:1]=reference.u_dram_addr_4.ras_d;
assign dut_state[424+:8]=dut.u_dram_addr_4.row;
assign reference_state[424+:8]=reference.u_dram_addr_4.row;
assign dut_state[432+:1]=dut.u_dram_addr_5.cas_d;
assign reference_state[432+:1]=reference.u_dram_addr_5.cas_d;
assign dut_state[433+:8]=dut.u_dram_addr_5.col;
assign reference_state[433+:8]=reference.u_dram_addr_5.col;
assign dut_state[441+:1]=dut.u_dram_addr_5.ras_d;
assign reference_state[441+:1]=reference.u_dram_addr_5.ras_d;
assign dut_state[442+:8]=dut.u_dram_addr_5.row;
assign reference_state[442+:8]=reference.u_dram_addr_5.row;
assign dut_state[450+:1]=dut.u_dram_addr_6.cas_d;
assign reference_state[450+:1]=reference.u_dram_addr_6.cas_d;
assign dut_state[451+:8]=dut.u_dram_addr_6.col;
assign reference_state[451+:8]=reference.u_dram_addr_6.col;
assign dut_state[459+:1]=dut.u_dram_addr_6.ras_d;
assign reference_state[459+:1]=reference.u_dram_addr_6.ras_d;
assign dut_state[460+:8]=dut.u_dram_addr_6.row;
assign reference_state[460+:8]=reference.u_dram_addr_6.row;
assign dut_state[468+:1]=dut.u_dram_addr_7.cas_d;
assign reference_state[468+:1]=reference.u_dram_addr_7.cas_d;
assign dut_state[469+:8]=dut.u_dram_addr_7.col;
assign reference_state[469+:8]=reference.u_dram_addr_7.col;
assign dut_state[477+:1]=dut.u_dram_addr_7.ras_d;
assign reference_state[477+:1]=reference.u_dram_addr_7.ras_d;
assign dut_state[478+:8]=dut.u_dram_addr_7.row;
assign reference_state[478+:8]=reference.u_dram_addr_7.row;
assign dut_state[486+:1]=dut.u_dram_addr_8.cas_d;
assign reference_state[486+:1]=reference.u_dram_addr_8.cas_d;
assign dut_state[487+:8]=dut.u_dram_addr_8.col;
assign reference_state[487+:8]=reference.u_dram_addr_8.col;
assign dut_state[495+:1]=dut.u_dram_addr_8.ras_d;
assign reference_state[495+:1]=reference.u_dram_addr_8.ras_d;
assign dut_state[496+:8]=dut.u_dram_addr_8.row;
assign reference_state[496+:8]=reference.u_dram_addr_8.row;
assign dut_state[504+:1]=dut.u_dram_addr_9.cas_d;
assign reference_state[504+:1]=reference.u_dram_addr_9.cas_d;
assign dut_state[505+:8]=dut.u_dram_addr_9.col;
assign reference_state[505+:8]=reference.u_dram_addr_9.col;
assign dut_state[513+:1]=dut.u_dram_addr_9.ras_d;
assign reference_state[513+:1]=reference.u_dram_addr_9.ras_d;
assign dut_state[514+:8]=dut.u_dram_addr_9.row;
assign reference_state[514+:8]=reference.u_dram_addr_9.row;
assign dut_state[522+:1]=dut.u_e02.ck_d;
assign reference_state[522+:1]=reference.u_e02.ck_d;
assign dut_state[523+:6]=dut.u_e02.d_pre;
assign reference_state[523+:6]=reference.u_e02.d_pre;
assign dut_state[529+:6]=dut.u_e02.q;
assign reference_state[529+:6]=reference.u_e02.q;
assign dut_state[535+:1]=dut.u_e03.ck_d;
assign reference_state[535+:1]=reference.u_e03.ck_d;
assign dut_state[536+:8]=dut.u_e03.q;
assign reference_state[536+:8]=reference.u_e03.q;
assign dut_state[544+:1]=dut.u_e24.ck_d;
assign reference_state[544+:1]=reference.u_e24.ck_d;
assign dut_state[545+:8]=dut.u_e24.q;
assign reference_state[545+:8]=reference.u_e24.q;
assign dut_state[553+:1]=dut.u_f01.ck_d;
assign reference_state[553+:1]=reference.u_f01.ck_d;
assign dut_state[554+:6]=dut.u_f01.d_pre;
assign reference_state[554+:6]=reference.u_f01.d_pre;
assign dut_state[560+:6]=dut.u_f01.q;
assign reference_state[560+:6]=reference.u_f01.q;
assign dut_state[566+:1]=dut.u_f03.ck_d;
assign reference_state[566+:1]=reference.u_f03.ck_d;
assign dut_state[567+:8]=dut.u_f03.q;
assign reference_state[567+:8]=reference.u_f03.q;
assign dut_state[575+:1]=dut.u_f24.ck_d;
assign reference_state[575+:1]=reference.u_f24.ck_d;
assign dut_state[576+:8]=dut.u_f24.q;
assign reference_state[576+:8]=reference.u_f24.q;
assign dut_state[584+:1]=dut.u_f26.ck_d;
assign reference_state[584+:1]=reference.u_f26.ck_d;
assign dut_state[585+:6]=dut.u_f26.d_pre;
assign reference_state[585+:6]=reference.u_f26.d_pre;
assign dut_state[591+:6]=dut.u_f26.q;
assign reference_state[591+:6]=reference.u_f26.q;
assign dut_state[597+:1]=dut.u_g01.ck_d;
assign reference_state[597+:1]=reference.u_g01.ck_d;
assign dut_state[598+:4]=dut.u_g01.q;
assign reference_state[598+:4]=reference.u_g01.q;
assign dut_state[602+:6]=dut.u_g01.setup_pre;
assign reference_state[602+:6]=reference.u_g01.setup_pre;
assign dut_state[608+:1]=dut.u_g03.ck_d;
assign reference_state[608+:1]=reference.u_g03.ck_d;
assign dut_state[609+:6]=dut.u_g03.q;
assign reference_state[609+:6]=reference.u_g03.q;
assign dut_state[615+:1]=dut.u_g13.ck_d;
assign reference_state[615+:1]=reference.u_g13.ck_d;
assign dut_state[616+:8]=dut.u_g13.q;
assign reference_state[616+:8]=reference.u_g13.q;
assign dut_state[624+:1]=dut.u_g14.ck_d;
assign reference_state[624+:1]=reference.u_g14.ck_d;
assign dut_state[625+:8]=dut.u_g14.q;
assign reference_state[625+:8]=reference.u_g14.q;
assign dut_state[633+:1]=dut.u_g24.ck_d;
assign reference_state[633+:1]=reference.u_g24.ck_d;
assign dut_state[634+:6]=dut.u_g24.q;
assign reference_state[634+:6]=reference.u_g24.q;
assign dut_state[640+:1]=dut.u_g26.ck_d;
assign reference_state[640+:1]=reference.u_g26.ck_d;
assign dut_state[641+:4]=dut.u_g26.q;
assign reference_state[641+:4]=reference.u_g26.q;
assign dut_state[645+:6]=dut.u_g26.setup_pre;
assign reference_state[645+:6]=reference.u_g26.setup_pre;
assign dut_state[651+:1]=dut.u_h02.ck_d;
assign reference_state[651+:1]=reference.u_h02.ck_d;
assign dut_state[652+:6]=dut.u_h02.d_pre;
assign reference_state[652+:6]=reference.u_h02.d_pre;
assign dut_state[658+:6]=dut.u_h02.q;
assign reference_state[658+:6]=reference.u_h02.q;
assign dut_state[664+:1]=dut.u_h03.ck_d;
assign reference_state[664+:1]=reference.u_h03.ck_d;
assign dut_state[665+:6]=dut.u_h03.q;
assign reference_state[665+:6]=reference.u_h03.q;
assign dut_state[671+:1]=dut.u_h13.ck_d;
assign reference_state[671+:1]=reference.u_h13.ck_d;
assign dut_state[672+:8]=dut.u_h13.q;
assign reference_state[672+:8]=reference.u_h13.q;
assign dut_state[680+:1]=dut.u_h14.ck_d;
assign reference_state[680+:1]=reference.u_h14.ck_d;
assign dut_state[681+:8]=dut.u_h14.q;
assign reference_state[681+:8]=reference.u_h14.q;
assign dut_state[689+:1]=dut.u_h24.ck_d;
assign reference_state[689+:1]=reference.u_h24.ck_d;
assign dut_state[690+:6]=dut.u_h24.q;
assign reference_state[690+:6]=reference.u_h24.q;
assign dut_state[696+:1]=dut.u_i03.ck_d;
assign reference_state[696+:1]=reference.u_i03.ck_d;
assign dut_state[697+:6]=dut.u_i03.q;
assign reference_state[697+:6]=reference.u_i03.q;
assign dut_state[703+:1]=dut.u_i13.ck_d;
assign reference_state[703+:1]=reference.u_i13.ck_d;
assign dut_state[704+:8]=dut.u_i13.q;
assign reference_state[704+:8]=reference.u_i13.q;
assign dut_state[712+:1]=dut.u_i14.ck_d;
assign reference_state[712+:1]=reference.u_i14.ck_d;
assign dut_state[713+:8]=dut.u_i14.q;
assign reference_state[713+:8]=reference.u_i14.q;
assign dut_state[721+:1]=dut.u_i24.ck_d;
assign reference_state[721+:1]=reference.u_i24.ck_d;
assign dut_state[722+:6]=dut.u_i24.q;
assign reference_state[722+:6]=reference.u_i24.q;
assign dut_state[728+:1]=dut.u_j01.ck_d;
assign reference_state[728+:1]=reference.u_j01.ck_d;
assign dut_state[729+:6]=dut.u_j01.d_pre;
assign reference_state[729+:6]=reference.u_j01.d_pre;
assign dut_state[735+:6]=dut.u_j01.q;
assign reference_state[735+:6]=reference.u_j01.q;
assign dut_state[741+:1]=dut.u_j03.ck_d;
assign reference_state[741+:1]=reference.u_j03.ck_d;
assign dut_state[742+:6]=dut.u_j03.q;
assign reference_state[742+:6]=reference.u_j03.q;
assign dut_state[748+:1]=dut.u_j04.ck_d;
assign reference_state[748+:1]=reference.u_j04.ck_d;
assign dut_state[749+:6]=dut.u_j04.q;
assign reference_state[749+:6]=reference.u_j04.q;
assign dut_state[755+:1]=dut.u_j05.ck_d;
assign reference_state[755+:1]=reference.u_j05.ck_d;
assign dut_state[756+:6]=dut.u_j05.q;
assign reference_state[756+:6]=reference.u_j05.q;
assign dut_state[762+:1]=dut.u_j13.ck_d;
assign reference_state[762+:1]=reference.u_j13.ck_d;
assign dut_state[763+:8]=dut.u_j13.q;
assign reference_state[763+:8]=reference.u_j13.q;
assign dut_state[771+:1]=dut.u_j14.ck_d;
assign reference_state[771+:1]=reference.u_j14.ck_d;
assign dut_state[772+:8]=dut.u_j14.q;
assign reference_state[772+:8]=reference.u_j14.q;
assign dut_state[780+:1]=dut.u_j22.ck_d;
assign reference_state[780+:1]=reference.u_j22.ck_d;
assign dut_state[781+:6]=dut.u_j22.q;
assign reference_state[781+:6]=reference.u_j22.q;
assign dut_state[787+:1]=dut.u_j23.ck_d;
assign reference_state[787+:1]=reference.u_j23.ck_d;
assign dut_state[788+:6]=dut.u_j23.q;
assign reference_state[788+:6]=reference.u_j23.q;
assign dut_state[794+:1]=dut.u_j24.ck_d;
assign reference_state[794+:1]=reference.u_j24.ck_d;
assign dut_state[795+:6]=dut.u_j24.q;
assign reference_state[795+:6]=reference.u_j24.q;
assign dut_state[801+:1]=dut.u_j26.ck_d;
assign reference_state[801+:1]=reference.u_j26.ck_d;
assign dut_state[802+:6]=dut.u_j26.d_pre;
assign reference_state[802+:6]=reference.u_j26.d_pre;
assign dut_state[808+:6]=dut.u_j26.q;
assign reference_state[808+:6]=reference.u_j26.q;
assign dut_state[814+:1]=dut.u_k01.ck_d;
assign reference_state[814+:1]=reference.u_k01.ck_d;
assign dut_state[815+:6]=dut.u_k01.d_pre;
assign reference_state[815+:6]=reference.u_k01.d_pre;
assign dut_state[821+:6]=dut.u_k01.q;
assign reference_state[821+:6]=reference.u_k01.q;
assign dut_state[827+:1]=dut.u_k26.ck_d;
assign reference_state[827+:1]=reference.u_k26.ck_d;
assign dut_state[828+:6]=dut.u_k26.d_pre;
assign reference_state[828+:6]=reference.u_k26.d_pre;
assign dut_state[834+:6]=dut.u_k26.q;
assign reference_state[834+:6]=reference.u_k26.q;
assign dut_state[840+:1]=dut.u_l01.ck_d;
assign reference_state[840+:1]=reference.u_l01.ck_d;
assign dut_state[841+:4]=dut.u_l01.d_pre;
assign reference_state[841+:4]=reference.u_l01.d_pre;
assign dut_state[845+:1]=dut.u_l01.dl_pre;
assign reference_state[845+:1]=reference.u_l01.dl_pre;
assign dut_state[846+:1]=dut.u_l01.dr_pre;
assign reference_state[846+:1]=reference.u_l01.dr_pre;
assign dut_state[847+:4]=dut.u_l01.q;
assign reference_state[847+:4]=reference.u_l01.q;
assign dut_state[851+:2]=dut.u_l01.s_pre;
assign reference_state[851+:2]=reference.u_l01.s_pre;
assign dut_state[853+:1]=dut.u_l26.ck_d;
assign reference_state[853+:1]=reference.u_l26.ck_d;
assign dut_state[854+:4]=dut.u_l26.d_pre;
assign reference_state[854+:4]=reference.u_l26.d_pre;
assign dut_state[858+:1]=dut.u_l26.dl_pre;
assign reference_state[858+:1]=reference.u_l26.dl_pre;
assign dut_state[859+:1]=dut.u_l26.dr_pre;
assign reference_state[859+:1]=reference.u_l26.dr_pre;
assign dut_state[860+:4]=dut.u_l26.q;
assign reference_state[860+:4]=reference.u_l26.q;
assign dut_state[864+:2]=dut.u_l26.s_pre;
assign reference_state[864+:2]=reference.u_l26.s_pre;
assign dut_state[866+:16]=dut.u_storage_0.cache_data;
assign reference_state[866+:16]=reference.u_storage_0.read_value;
assign dut_state[882+:1]=dut.u_storage_0.cache_valid;
assign reference_state[882+:1]=reference.u_storage_0.hit;
assign dut_state[883+:1]=dut.u_storage_0.cas_d;
assign reference_state[883+:1]=reference.u_storage_0.cas_d;
assign dut_state[884+:12]=dut.u_storage_0.data_out;
assign reference_state[884+:12]=reference.u_storage_0.data_out;
assign dut_state[896+:12]=dut.u_storage_0.read_pipe;
assign reference_state[896+:12]=reference.u_storage_0.read_pipe;
assign dut_state[908+:1]=dut.u_storage_0.waiting;
assign reference_state[908+:1]=reference.u_storage_0.waiting;
assign dut_state[909+:1]=dut.u_storage_0.we_d;
assign reference_state[909+:1]=reference.u_storage_0.we_d;
assign dut_state[910+:12]=dut.u_storage_0.write_data;
assign reference_state[910+:12]=reference.u_storage_0.write_data;
assign dut_state[922+:1]=dut.u_storage_0.write_done;
assign reference_state[922+:1]=reference.u_storage_0.write_done;
assign dut_state[923+:1]=dut.u_storage_0.write_pending;
assign reference_state[923+:1]=reference.u_storage_0.write_pending;
assign dut_state[924+:16]=dut.u_storage_1.cache_data;
assign reference_state[924+:16]=reference.u_storage_1.read_value;
assign dut_state[940+:1]=dut.u_storage_1.cache_valid;
assign reference_state[940+:1]=reference.u_storage_1.hit;
assign dut_state[941+:1]=dut.u_storage_1.cas_d;
assign reference_state[941+:1]=reference.u_storage_1.cas_d;
assign dut_state[942+:12]=dut.u_storage_1.data_out;
assign reference_state[942+:12]=reference.u_storage_1.data_out;
assign dut_state[954+:12]=dut.u_storage_1.read_pipe;
assign reference_state[954+:12]=reference.u_storage_1.read_pipe;
assign dut_state[966+:1]=dut.u_storage_1.waiting;
assign reference_state[966+:1]=reference.u_storage_1.waiting;
assign dut_state[967+:1]=dut.u_storage_1.we_d;
assign reference_state[967+:1]=reference.u_storage_1.we_d;
assign dut_state[968+:12]=dut.u_storage_1.write_data;
assign reference_state[968+:12]=reference.u_storage_1.write_data;
assign dut_state[980+:1]=dut.u_storage_1.write_done;
assign reference_state[980+:1]=reference.u_storage_1.write_done;
assign dut_state[981+:1]=dut.u_storage_1.write_pending;
assign reference_state[981+:1]=reference.u_storage_1.write_pending;
assign dut_state[982+:16]=dut.u_storage_10.cache_data;
assign reference_state[982+:16]=reference.u_storage_10.read_value;
assign dut_state[998+:1]=dut.u_storage_10.cache_valid;
assign reference_state[998+:1]=reference.u_storage_10.hit;
assign dut_state[999+:1]=dut.u_storage_10.cas_d;
assign reference_state[999+:1]=reference.u_storage_10.cas_d;
assign dut_state[1000+:8]=dut.u_storage_10.data_out;
assign reference_state[1000+:8]=reference.u_storage_10.data_out;
assign dut_state[1008+:8]=dut.u_storage_10.read_pipe;
assign reference_state[1008+:8]=reference.u_storage_10.read_pipe;
assign dut_state[1016+:1]=dut.u_storage_10.waiting;
assign reference_state[1016+:1]=reference.u_storage_10.waiting;
assign dut_state[1017+:1]=dut.u_storage_10.we_d;
assign reference_state[1017+:1]=reference.u_storage_10.we_d;
assign dut_state[1018+:8]=dut.u_storage_10.write_data;
assign reference_state[1018+:8]=reference.u_storage_10.write_data;
assign dut_state[1026+:1]=dut.u_storage_10.write_done;
assign reference_state[1026+:1]=reference.u_storage_10.write_done;
assign dut_state[1027+:1]=dut.u_storage_10.write_pending;
assign reference_state[1027+:1]=reference.u_storage_10.write_pending;
assign dut_state[1028+:16]=dut.u_storage_11.cache_data;
assign reference_state[1028+:16]=reference.u_storage_11.read_value;
assign dut_state[1044+:1]=dut.u_storage_11.cache_valid;
assign reference_state[1044+:1]=reference.u_storage_11.hit;
assign dut_state[1045+:1]=dut.u_storage_11.cas_d;
assign reference_state[1045+:1]=reference.u_storage_11.cas_d;
assign dut_state[1046+:8]=dut.u_storage_11.data_out;
assign reference_state[1046+:8]=reference.u_storage_11.data_out;
assign dut_state[1054+:8]=dut.u_storage_11.read_pipe;
assign reference_state[1054+:8]=reference.u_storage_11.read_pipe;
assign dut_state[1062+:1]=dut.u_storage_11.waiting;
assign reference_state[1062+:1]=reference.u_storage_11.waiting;
assign dut_state[1063+:1]=dut.u_storage_11.we_d;
assign reference_state[1063+:1]=reference.u_storage_11.we_d;
assign dut_state[1064+:8]=dut.u_storage_11.write_data;
assign reference_state[1064+:8]=reference.u_storage_11.write_data;
assign dut_state[1072+:1]=dut.u_storage_11.write_done;
assign reference_state[1072+:1]=reference.u_storage_11.write_done;
assign dut_state[1073+:1]=dut.u_storage_11.write_pending;
assign reference_state[1073+:1]=reference.u_storage_11.write_pending;
assign dut_state[1074+:16]=dut.u_storage_12.cache_data;
assign reference_state[1074+:16]=reference.u_storage_12.read_value;
assign dut_state[1090+:1]=dut.u_storage_12.cache_valid;
assign reference_state[1090+:1]=reference.u_storage_12.hit;
assign dut_state[1091+:1]=dut.u_storage_12.cas_d;
assign reference_state[1091+:1]=reference.u_storage_12.cas_d;
assign dut_state[1092+:8]=dut.u_storage_12.data_out;
assign reference_state[1092+:8]=reference.u_storage_12.data_out;
assign dut_state[1100+:8]=dut.u_storage_12.read_pipe;
assign reference_state[1100+:8]=reference.u_storage_12.read_pipe;
assign dut_state[1108+:1]=dut.u_storage_12.waiting;
assign reference_state[1108+:1]=reference.u_storage_12.waiting;
assign dut_state[1109+:1]=dut.u_storage_12.we_d;
assign reference_state[1109+:1]=reference.u_storage_12.we_d;
assign dut_state[1110+:8]=dut.u_storage_12.write_data;
assign reference_state[1110+:8]=reference.u_storage_12.write_data;
assign dut_state[1118+:1]=dut.u_storage_12.write_done;
assign reference_state[1118+:1]=reference.u_storage_12.write_done;
assign dut_state[1119+:1]=dut.u_storage_12.write_pending;
assign reference_state[1119+:1]=reference.u_storage_12.write_pending;
assign dut_state[1120+:16]=dut.u_storage_13.cache_data;
assign reference_state[1120+:16]=reference.u_storage_13.read_value;
assign dut_state[1136+:1]=dut.u_storage_13.cache_valid;
assign reference_state[1136+:1]=reference.u_storage_13.hit;
assign dut_state[1137+:1]=dut.u_storage_13.cas_d;
assign reference_state[1137+:1]=reference.u_storage_13.cas_d;
assign dut_state[1138+:8]=dut.u_storage_13.data_out;
assign reference_state[1138+:8]=reference.u_storage_13.data_out;
assign dut_state[1146+:8]=dut.u_storage_13.read_pipe;
assign reference_state[1146+:8]=reference.u_storage_13.read_pipe;
assign dut_state[1154+:1]=dut.u_storage_13.waiting;
assign reference_state[1154+:1]=reference.u_storage_13.waiting;
assign dut_state[1155+:1]=dut.u_storage_13.we_d;
assign reference_state[1155+:1]=reference.u_storage_13.we_d;
assign dut_state[1156+:8]=dut.u_storage_13.write_data;
assign reference_state[1156+:8]=reference.u_storage_13.write_data;
assign dut_state[1164+:1]=dut.u_storage_13.write_done;
assign reference_state[1164+:1]=reference.u_storage_13.write_done;
assign dut_state[1165+:1]=dut.u_storage_13.write_pending;
assign reference_state[1165+:1]=reference.u_storage_13.write_pending;
assign dut_state[1166+:16]=dut.u_storage_14.cache_data;
assign reference_state[1166+:16]=reference.u_storage_14.read_value;
assign dut_state[1182+:1]=dut.u_storage_14.cache_valid;
assign reference_state[1182+:1]=reference.u_storage_14.hit;
assign dut_state[1183+:1]=dut.u_storage_14.cas_d;
assign reference_state[1183+:1]=reference.u_storage_14.cas_d;
assign dut_state[1184+:12]=dut.u_storage_14.data_out;
assign reference_state[1184+:12]=reference.u_storage_14.data_out;
assign dut_state[1196+:12]=dut.u_storage_14.read_pipe;
assign reference_state[1196+:12]=reference.u_storage_14.read_pipe;
assign dut_state[1208+:1]=dut.u_storage_14.waiting;
assign reference_state[1208+:1]=reference.u_storage_14.waiting;
assign dut_state[1209+:1]=dut.u_storage_14.we_d;
assign reference_state[1209+:1]=reference.u_storage_14.we_d;
assign dut_state[1210+:12]=dut.u_storage_14.write_data;
assign reference_state[1210+:12]=reference.u_storage_14.write_data;
assign dut_state[1222+:1]=dut.u_storage_14.write_done;
assign reference_state[1222+:1]=reference.u_storage_14.write_done;
assign dut_state[1223+:1]=dut.u_storage_14.write_pending;
assign reference_state[1223+:1]=reference.u_storage_14.write_pending;
assign dut_state[1224+:16]=dut.u_storage_15.cache_data;
assign reference_state[1224+:16]=reference.u_storage_15.read_value;
assign dut_state[1240+:1]=dut.u_storage_15.cache_valid;
assign reference_state[1240+:1]=reference.u_storage_15.hit;
assign dut_state[1241+:1]=dut.u_storage_15.cas_d;
assign reference_state[1241+:1]=reference.u_storage_15.cas_d;
assign dut_state[1242+:12]=dut.u_storage_15.data_out;
assign reference_state[1242+:12]=reference.u_storage_15.data_out;
assign dut_state[1254+:12]=dut.u_storage_15.read_pipe;
assign reference_state[1254+:12]=reference.u_storage_15.read_pipe;
assign dut_state[1266+:1]=dut.u_storage_15.waiting;
assign reference_state[1266+:1]=reference.u_storage_15.waiting;
assign dut_state[1267+:1]=dut.u_storage_15.we_d;
assign reference_state[1267+:1]=reference.u_storage_15.we_d;
assign dut_state[1268+:12]=dut.u_storage_15.write_data;
assign reference_state[1268+:12]=reference.u_storage_15.write_data;
assign dut_state[1280+:1]=dut.u_storage_15.write_done;
assign reference_state[1280+:1]=reference.u_storage_15.write_done;
assign dut_state[1281+:1]=dut.u_storage_15.write_pending;
assign reference_state[1281+:1]=reference.u_storage_15.write_pending;
assign dut_state[1282+:16]=dut.u_storage_2.cache_data;
assign reference_state[1282+:16]=reference.u_storage_2.read_value;
assign dut_state[1298+:1]=dut.u_storage_2.cache_valid;
assign reference_state[1298+:1]=reference.u_storage_2.hit;
assign dut_state[1299+:1]=dut.u_storage_2.cas_d;
assign reference_state[1299+:1]=reference.u_storage_2.cas_d;
assign dut_state[1300+:8]=dut.u_storage_2.data_out;
assign reference_state[1300+:8]=reference.u_storage_2.data_out;
assign dut_state[1308+:8]=dut.u_storage_2.read_pipe;
assign reference_state[1308+:8]=reference.u_storage_2.read_pipe;
assign dut_state[1316+:1]=dut.u_storage_2.waiting;
assign reference_state[1316+:1]=reference.u_storage_2.waiting;
assign dut_state[1317+:1]=dut.u_storage_2.we_d;
assign reference_state[1317+:1]=reference.u_storage_2.we_d;
assign dut_state[1318+:8]=dut.u_storage_2.write_data;
assign reference_state[1318+:8]=reference.u_storage_2.write_data;
assign dut_state[1326+:1]=dut.u_storage_2.write_done;
assign reference_state[1326+:1]=reference.u_storage_2.write_done;
assign dut_state[1327+:1]=dut.u_storage_2.write_pending;
assign reference_state[1327+:1]=reference.u_storage_2.write_pending;
assign dut_state[1328+:16]=dut.u_storage_3.cache_data;
assign reference_state[1328+:16]=reference.u_storage_3.read_value;
assign dut_state[1344+:1]=dut.u_storage_3.cache_valid;
assign reference_state[1344+:1]=reference.u_storage_3.hit;
assign dut_state[1345+:1]=dut.u_storage_3.cas_d;
assign reference_state[1345+:1]=reference.u_storage_3.cas_d;
assign dut_state[1346+:8]=dut.u_storage_3.data_out;
assign reference_state[1346+:8]=reference.u_storage_3.data_out;
assign dut_state[1354+:8]=dut.u_storage_3.read_pipe;
assign reference_state[1354+:8]=reference.u_storage_3.read_pipe;
assign dut_state[1362+:1]=dut.u_storage_3.waiting;
assign reference_state[1362+:1]=reference.u_storage_3.waiting;
assign dut_state[1363+:1]=dut.u_storage_3.we_d;
assign reference_state[1363+:1]=reference.u_storage_3.we_d;
assign dut_state[1364+:8]=dut.u_storage_3.write_data;
assign reference_state[1364+:8]=reference.u_storage_3.write_data;
assign dut_state[1372+:1]=dut.u_storage_3.write_done;
assign reference_state[1372+:1]=reference.u_storage_3.write_done;
assign dut_state[1373+:1]=dut.u_storage_3.write_pending;
assign reference_state[1373+:1]=reference.u_storage_3.write_pending;
assign dut_state[1374+:16]=dut.u_storage_4.cache_data;
assign reference_state[1374+:16]=reference.u_storage_4.read_value;
assign dut_state[1390+:1]=dut.u_storage_4.cache_valid;
assign reference_state[1390+:1]=reference.u_storage_4.hit;
assign dut_state[1391+:1]=dut.u_storage_4.cas_d;
assign reference_state[1391+:1]=reference.u_storage_4.cas_d;
assign dut_state[1392+:8]=dut.u_storage_4.data_out;
assign reference_state[1392+:8]=reference.u_storage_4.data_out;
assign dut_state[1400+:8]=dut.u_storage_4.read_pipe;
assign reference_state[1400+:8]=reference.u_storage_4.read_pipe;
assign dut_state[1408+:1]=dut.u_storage_4.waiting;
assign reference_state[1408+:1]=reference.u_storage_4.waiting;
assign dut_state[1409+:1]=dut.u_storage_4.we_d;
assign reference_state[1409+:1]=reference.u_storage_4.we_d;
assign dut_state[1410+:8]=dut.u_storage_4.write_data;
assign reference_state[1410+:8]=reference.u_storage_4.write_data;
assign dut_state[1418+:1]=dut.u_storage_4.write_done;
assign reference_state[1418+:1]=reference.u_storage_4.write_done;
assign dut_state[1419+:1]=dut.u_storage_4.write_pending;
assign reference_state[1419+:1]=reference.u_storage_4.write_pending;
assign dut_state[1420+:16]=dut.u_storage_5.cache_data;
assign reference_state[1420+:16]=reference.u_storage_5.read_value;
assign dut_state[1436+:1]=dut.u_storage_5.cache_valid;
assign reference_state[1436+:1]=reference.u_storage_5.hit;
assign dut_state[1437+:1]=dut.u_storage_5.cas_d;
assign reference_state[1437+:1]=reference.u_storage_5.cas_d;
assign dut_state[1438+:8]=dut.u_storage_5.data_out;
assign reference_state[1438+:8]=reference.u_storage_5.data_out;
assign dut_state[1446+:8]=dut.u_storage_5.read_pipe;
assign reference_state[1446+:8]=reference.u_storage_5.read_pipe;
assign dut_state[1454+:1]=dut.u_storage_5.waiting;
assign reference_state[1454+:1]=reference.u_storage_5.waiting;
assign dut_state[1455+:1]=dut.u_storage_5.we_d;
assign reference_state[1455+:1]=reference.u_storage_5.we_d;
assign dut_state[1456+:8]=dut.u_storage_5.write_data;
assign reference_state[1456+:8]=reference.u_storage_5.write_data;
assign dut_state[1464+:1]=dut.u_storage_5.write_done;
assign reference_state[1464+:1]=reference.u_storage_5.write_done;
assign dut_state[1465+:1]=dut.u_storage_5.write_pending;
assign reference_state[1465+:1]=reference.u_storage_5.write_pending;
assign dut_state[1466+:16]=dut.u_storage_6.cache_data;
assign reference_state[1466+:16]=reference.u_storage_6.read_value;
assign dut_state[1482+:1]=dut.u_storage_6.cache_valid;
assign reference_state[1482+:1]=reference.u_storage_6.hit;
assign dut_state[1483+:1]=dut.u_storage_6.cas_d;
assign reference_state[1483+:1]=reference.u_storage_6.cas_d;
assign dut_state[1484+:8]=dut.u_storage_6.data_out;
assign reference_state[1484+:8]=reference.u_storage_6.data_out;
assign dut_state[1492+:8]=dut.u_storage_6.read_pipe;
assign reference_state[1492+:8]=reference.u_storage_6.read_pipe;
assign dut_state[1500+:1]=dut.u_storage_6.waiting;
assign reference_state[1500+:1]=reference.u_storage_6.waiting;
assign dut_state[1501+:1]=dut.u_storage_6.we_d;
assign reference_state[1501+:1]=reference.u_storage_6.we_d;
assign dut_state[1502+:8]=dut.u_storage_6.write_data;
assign reference_state[1502+:8]=reference.u_storage_6.write_data;
assign dut_state[1510+:1]=dut.u_storage_6.write_done;
assign reference_state[1510+:1]=reference.u_storage_6.write_done;
assign dut_state[1511+:1]=dut.u_storage_6.write_pending;
assign reference_state[1511+:1]=reference.u_storage_6.write_pending;
assign dut_state[1512+:16]=dut.u_storage_7.cache_data;
assign reference_state[1512+:16]=reference.u_storage_7.read_value;
assign dut_state[1528+:1]=dut.u_storage_7.cache_valid;
assign reference_state[1528+:1]=reference.u_storage_7.hit;
assign dut_state[1529+:1]=dut.u_storage_7.cas_d;
assign reference_state[1529+:1]=reference.u_storage_7.cas_d;
assign dut_state[1530+:8]=dut.u_storage_7.data_out;
assign reference_state[1530+:8]=reference.u_storage_7.data_out;
assign dut_state[1538+:8]=dut.u_storage_7.read_pipe;
assign reference_state[1538+:8]=reference.u_storage_7.read_pipe;
assign dut_state[1546+:1]=dut.u_storage_7.waiting;
assign reference_state[1546+:1]=reference.u_storage_7.waiting;
assign dut_state[1547+:1]=dut.u_storage_7.we_d;
assign reference_state[1547+:1]=reference.u_storage_7.we_d;
assign dut_state[1548+:8]=dut.u_storage_7.write_data;
assign reference_state[1548+:8]=reference.u_storage_7.write_data;
assign dut_state[1556+:1]=dut.u_storage_7.write_done;
assign reference_state[1556+:1]=reference.u_storage_7.write_done;
assign dut_state[1557+:1]=dut.u_storage_7.write_pending;
assign reference_state[1557+:1]=reference.u_storage_7.write_pending;
assign dut_state[1558+:16]=dut.u_storage_8.cache_data;
assign reference_state[1558+:16]=reference.u_storage_8.read_value;
assign dut_state[1574+:1]=dut.u_storage_8.cache_valid;
assign reference_state[1574+:1]=reference.u_storage_8.hit;
assign dut_state[1575+:1]=dut.u_storage_8.cas_d;
assign reference_state[1575+:1]=reference.u_storage_8.cas_d;
assign dut_state[1576+:8]=dut.u_storage_8.data_out;
assign reference_state[1576+:8]=reference.u_storage_8.data_out;
assign dut_state[1584+:8]=dut.u_storage_8.read_pipe;
assign reference_state[1584+:8]=reference.u_storage_8.read_pipe;
assign dut_state[1592+:1]=dut.u_storage_8.waiting;
assign reference_state[1592+:1]=reference.u_storage_8.waiting;
assign dut_state[1593+:1]=dut.u_storage_8.we_d;
assign reference_state[1593+:1]=reference.u_storage_8.we_d;
assign dut_state[1594+:8]=dut.u_storage_8.write_data;
assign reference_state[1594+:8]=reference.u_storage_8.write_data;
assign dut_state[1602+:1]=dut.u_storage_8.write_done;
assign reference_state[1602+:1]=reference.u_storage_8.write_done;
assign dut_state[1603+:1]=dut.u_storage_8.write_pending;
assign reference_state[1603+:1]=reference.u_storage_8.write_pending;
assign dut_state[1604+:16]=dut.u_storage_9.cache_data;
assign reference_state[1604+:16]=reference.u_storage_9.read_value;
assign dut_state[1620+:1]=dut.u_storage_9.cache_valid;
assign reference_state[1620+:1]=reference.u_storage_9.hit;
assign dut_state[1621+:1]=dut.u_storage_9.cas_d;
assign reference_state[1621+:1]=reference.u_storage_9.cas_d;
assign dut_state[1622+:8]=dut.u_storage_9.data_out;
assign reference_state[1622+:8]=reference.u_storage_9.data_out;
assign dut_state[1630+:8]=dut.u_storage_9.read_pipe;
assign reference_state[1630+:8]=reference.u_storage_9.read_pipe;
assign dut_state[1638+:1]=dut.u_storage_9.waiting;
assign reference_state[1638+:1]=reference.u_storage_9.waiting;
assign dut_state[1639+:1]=dut.u_storage_9.we_d;
assign reference_state[1639+:1]=reference.u_storage_9.we_d;
assign dut_state[1640+:8]=dut.u_storage_9.write_data;
assign reference_state[1640+:8]=reference.u_storage_9.write_data;
assign dut_state[1648+:1]=dut.u_storage_9.write_done;
assign reference_state[1648+:1]=reference.u_storage_9.write_done;
assign dut_state[1649+:1]=dut.u_storage_9.write_pending;
assign reference_state[1649+:1]=reference.u_storage_9.write_pending;
endmodule
