module snapshot_fit(
 input wire host_clk,advance,freeze,held,global_hold,global_abort,system_reset,request,write,reset,
 input wire [23:0] index,input wire [17:0] data,input wire [46:0] pins,
 input wire [15:0] req_ready,rsp_valid,input wire [255:0] rsp_data,
 output reg [604:0] outputs);
 reg [385:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,global_hold,global_abort,system_reset,request,write,reset,index,data,pins,req_ready,rsp_valid,rsp_data};
 always @(posedge host_clk)launch<=input_stage;
 wire advance_r,freeze_r,held_r,global_hold_r,global_abort_r,system_reset_r,request_r,write_r,reset_r;
 wire [23:0] index_r;wire [17:0] data_r;wire [46:0] pins_r;
 wire [15:0] req_ready_r,rsp_valid_r;wire [255:0] rsp_data_r;
 assign {advance_r,freeze_r,held_r,global_hold_r,global_abort_r,system_reset_r,request_r,write_r,reset_r,index_r,data_r,pins_r,req_ready_r,rsp_valid_r,rsp_data_r}=launch;
 reg actual_advance=0;
 always @(negedge host_clk)actual_advance<=advance_r;
 wire storage_ready,ready,frozen,done,error,hold_required,fault,drained;wire [17:0] result;
 wire [15:0] req_valid,req_write,rsp_ready;wire [255:0] req_addr,req_data;
 wire normal_EcIn_0__drv;
 wire normal_EcIn_1__drv;
 wire normal_M0__drv;
 wire normal_Sin_00__drv;
 wire normal_Sin_01__drv;
 wire normal_Sin_02__drv;
 wire normal_Sin_03__drv;
 wire normal_Sin_04__drv;
 wire normal_Sin_05__drv;
 wire normal_Sin_06__drv;
 wire normal_Sin_07__drv;
 wire normal_Sin_08__drv;
 wire normal_Sin_09__drv;
 wire normal_Sin_10__drv;
 wire normal_Sin_11__drv;
 wire normal_Sin_12__drv;
 wire normal_Sin_13__drv;
 wire normal_Sin_14__drv;
 wire normal_Sin_15__drv;
 dorado_serial_MSA #(.SYSPER(4)) board(
.sys_clk(host_clk),
.storage_clk(host_clk),
.storage_reset(reset_r),
.storage_ready(storage_ready),
.storage_req_ready(req_ready_r),
.storage_rsp_valid(rsp_valid_r),
.storage_rsp_data(rsp_data_r),
.storage_req_valid(req_valid),
.storage_req_write(req_write),
.storage_rsp_ready(rsp_ready),
.storage_req_addr(req_addr),
.storage_req_data(req_data),
.state_guest_advance(actual_advance),
.state_freeze(freeze_r),
.state_guest_held(held_r),
.state_global_hold(global_hold_r),
.state_global_abort(global_abort_r),
.state_system_reset(system_reset_r),
.state_request(request_r),
.state_write(write_r),
.state_index(index_r),
.state_data(data_r),
.state_ready(ready),
.state_frozen(frozen),
.state_done(done),
.state_error(error),
.state_scan_hold_required(hold_required),
.state_scan_fault(fault),
.state_memory_drained(drained),
.state_result(result),
.CLK_ms0Even_p_(pins_r[0]),
.ChipsAre16k(pins_r[1]),
.ChipsAre4k(pins_r[2]),
.ChipsAre64K(pins_r[3]),
.EcOut_0(pins_r[4]),
.EcOut_1(pins_r[5]),
.EcOut_4(pins_r[6]),
.EcOut_5(pins_r[7]),
.LoadEcOut_p_(pins_r[8]),
.LoadSinE(pins_r[9]),
.LoadSoutE_p_(pins_r[10]),
.Mb0(pins_r[11]),
.MemAd_1(pins_r[12]),
.MemAd_2(pins_r[13]),
.MemAd_3(pins_r[14]),
.MemAd_4(pins_r[15]),
.MemAd_5(pins_r[16]),
.MemAd_6(pins_r[17]),
.MemAd_7(pins_r[18]),
.MemAd_8(pins_r[19]),
.MemCASa(pins_r[20]),
.MemCASb(pins_r[21]),
.MemRASa(pins_r[22]),
.MemRASb(pins_r[23]),
.MemWEa(pins_r[24]),
.MemWEb(pins_r[25]),
.Mod0SinEn_p_(pins_r[26]),
.Mod0StrEn_p_(pins_r[27]),
.ShiftEcOut(pins_r[28]),
.ShiftSinE(pins_r[29]),
.ShiftSoutE(pins_r[30]),
.Sout_00(pins_r[31]),
.Sout_01(pins_r[32]),
.Sout_02(pins_r[33]),
.Sout_03(pins_r[34]),
.Sout_04(pins_r[35]),
.Sout_05(pins_r[36]),
.Sout_06(pins_r[37]),
.Sout_07(pins_r[38]),
.Sout_08(pins_r[39]),
.Sout_09(pins_r[40]),
.Sout_10(pins_r[41]),
.Sout_11(pins_r[42]),
.Sout_12(pins_r[43]),
.Sout_13(pins_r[44]),
.Sout_14(pins_r[45]),
.Sout_15(pins_r[46]),
.EcIn_0__drv(normal_EcIn_0__drv),
.EcIn_1__drv(normal_EcIn_1__drv),
.M0__drv(normal_M0__drv),
.Sin_00__drv(normal_Sin_00__drv),
.Sin_01__drv(normal_Sin_01__drv),
.Sin_02__drv(normal_Sin_02__drv),
.Sin_03__drv(normal_Sin_03__drv),
.Sin_04__drv(normal_Sin_04__drv),
.Sin_05__drv(normal_Sin_05__drv),
.Sin_06__drv(normal_Sin_06__drv),
.Sin_07__drv(normal_Sin_07__drv),
.Sin_08__drv(normal_Sin_08__drv),
.Sin_09__drv(normal_Sin_09__drv),
.Sin_10__drv(normal_Sin_10__drv),
.Sin_11__drv(normal_Sin_11__drv),
.Sin_12__drv(normal_Sin_12__drv),
.Sin_13__drv(normal_Sin_13__drv),
.Sin_14__drv(normal_Sin_14__drv),
.Sin_15__drv(normal_Sin_15__drv)
);
 always @(posedge host_clk)outputs<={{normal_Sin_15__drv,normal_Sin_14__drv,normal_Sin_13__drv,normal_Sin_12__drv,normal_Sin_11__drv,normal_Sin_10__drv,normal_Sin_09__drv,normal_Sin_08__drv,normal_Sin_07__drv,normal_Sin_06__drv,normal_Sin_05__drv,normal_Sin_04__drv,normal_Sin_03__drv,normal_Sin_02__drv,normal_Sin_01__drv,normal_Sin_00__drv,normal_M0__drv,normal_EcIn_1__drv,normal_EcIn_0__drv},storage_ready,ready,frozen,done,error,hold_required,fault,drained,result,req_valid,req_write,rsp_ready,req_addr,req_data};
endmodule
