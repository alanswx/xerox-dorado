module storage_snapshot_fixture(
 input wire clk,ref_clk,advance,hold,scan_step,serial_in,
 input wire selected,reset,input wire [15:0] probe_addr,input wire [1:0] ras_n,cas_n,we_n,req_ready,rsp_valid,
 input wire [15:0] next_addr[2],data_in[2],rsp_data[2],
 output wire [1:0] ready,req_valid,req_write,rsp_ready,frozen,drained,serial_out,
 output wire [1:0] ref_ready,ref_req_valid,ref_req_write,ref_rsp_ready,
 output wire [15:0] req_addr[2],req_data[2],data_out[2],ref_req_addr[2],ref_req_data[2],ref_data_out[2],chip_data_out[2],
 output wire [15:0] chip_word[2],output wire [127:0] physical[2],original_state[2]);
 wire reference_machine_clk=ref_clk && advance;
begin:case0
 reg [15:0] addr=0,reference_addr=0;
 always @(posedge clk)if(advance && !hold)addr<=next_addr[0];
 always @(posedge reference_machine_clk)reference_addr<=next_addr[0];
 dorado_storage_group_compact #(.ADDR_BITS(16),.WIDTH(8)) dut(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step && selected==1'd0),.state_serial_in(serial_in),
 .state_serial_out(serial_out[0]),.state_frozen(frozen[0]),.state_drain_ready(drained[0]),
 .host_clk(clk),.machine_clk(reference_machine_clk),.reset(reset),
 .addr_will_change(next_addr[0]!=addr),.ras_n(ras_n[0]),.cas_n(cas_n[0]),.we_n(we_n[0]),.addr(addr),.data_in(data_in[0][7:0]),
 .data_out(data_out[0][7:0]),.ready(ready[0]),.req_valid(req_valid[0]),.req_write(req_write[0]),
 .req_addr(req_addr[0]),.req_data(req_data[0]),.req_ready(req_ready[0]),
 .rsp_valid(rsp_valid[0]),.rsp_ready(rsp_ready[0]),.rsp_data(rsp_data[0]));
 dorado_storage_group #(.ADDR_BITS(16),.WIDTH(8)) reference(
 .host_clk(ref_clk),.machine_clk(reference_machine_clk),.reset(reset),
 .ras_n(ras_n[0]),.cas_n(cas_n[0]),.we_n(we_n[0]),.addr(reference_addr),.data_in(data_in[0][7:0]),
 .data_out(ref_data_out[0][7:0]),.ready(ref_ready[0]),.req_valid(ref_req_valid[0]),.req_write(ref_req_write[0]),
 .req_addr(ref_req_addr[0]),.req_data(ref_req_data[0]),.req_ready(req_ready[0]),
 .rsp_valid(rsp_valid[0]),.rsp_ready(ref_rsp_ready[0]),.rsp_data(rsp_data[0]));
 for(genvar b=0;b<8;b++)begin:chip
 cell_MK4096P_6 #(.ADDR_BITS(16)) original(.sys_clk(reference_machine_clk),.p2(data_in[0][b]),.p3(we_n[0]),
 .p4(ras_n[0]),.p15(cas_n[0]),.addr_i(reference_addr),.p14(chip_data_out[0][b]),
 .p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0));
 initial for(integer a=0;a<65536;a++)original.mem[a]=0;
 assign chip_word[0][b]=original.mem[probe_addr];
 end
 assign physical[0]={82'b0,{dut.cache_data,dut.waiting,dut.write_done,dut.cache_valid,dut.data_out,dut.read_pipe,dut.write_data,dut.write_pending,dut.we_d,dut.cas_d}};
 assign original_state[0]={82'b0,{reference.read_value,reference.waiting,reference.write_done,reference.hit,reference.data_out,reference.read_pipe,reference.write_data,reference.write_pending,reference.we_d,reference.cas_d}};
 assign data_out[0][15:8]=0;
 assign ref_data_out[0][15:8]=0;
 assign chip_data_out[0][15:8]=0;
 assign chip_word[0][15:8]=0;
end
begin:case1
 reg [15:0] addr=0,reference_addr=0;
 always @(posedge clk)if(advance && !hold)addr<=next_addr[1];
 always @(posedge reference_machine_clk)reference_addr<=next_addr[1];
 dorado_storage_group_compact #(.ADDR_BITS(16),.WIDTH(12)) dut(
 .state_guest_advance(advance),.state_hold(hold),.state_scan_step(scan_step && selected==1'd1),.state_serial_in(serial_in),
 .state_serial_out(serial_out[1]),.state_frozen(frozen[1]),.state_drain_ready(drained[1]),
 .host_clk(clk),.machine_clk(reference_machine_clk),.reset(reset),
 .addr_will_change(next_addr[1]!=addr),.ras_n(ras_n[1]),.cas_n(cas_n[1]),.we_n(we_n[1]),.addr(addr),.data_in(data_in[1][11:0]),
 .data_out(data_out[1][11:0]),.ready(ready[1]),.req_valid(req_valid[1]),.req_write(req_write[1]),
 .req_addr(req_addr[1]),.req_data(req_data[1]),.req_ready(req_ready[1]),
 .rsp_valid(rsp_valid[1]),.rsp_ready(rsp_ready[1]),.rsp_data(rsp_data[1]));
 dorado_storage_group #(.ADDR_BITS(16),.WIDTH(12)) reference(
 .host_clk(ref_clk),.machine_clk(reference_machine_clk),.reset(reset),
 .ras_n(ras_n[1]),.cas_n(cas_n[1]),.we_n(we_n[1]),.addr(reference_addr),.data_in(data_in[1][11:0]),
 .data_out(ref_data_out[1][11:0]),.ready(ref_ready[1]),.req_valid(ref_req_valid[1]),.req_write(ref_req_write[1]),
 .req_addr(ref_req_addr[1]),.req_data(ref_req_data[1]),.req_ready(req_ready[1]),
 .rsp_valid(rsp_valid[1]),.rsp_ready(ref_rsp_ready[1]),.rsp_data(rsp_data[1]));
 for(genvar b=0;b<12;b++)begin:chip
 cell_MK4096P_6 #(.ADDR_BITS(16)) original(.sys_clk(reference_machine_clk),.p2(data_in[1][b]),.p3(we_n[1]),
 .p4(ras_n[1]),.p15(cas_n[1]),.addr_i(reference_addr),.p14(chip_data_out[1][b]),
 .p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(1'b0),.p13(1'b0));
 initial for(integer a=0;a<65536;a++)original.mem[a]=0;
 assign chip_word[1][b]=original.mem[probe_addr];
 end
 assign physical[1]={70'b0,{dut.cache_data,dut.waiting,dut.write_done,dut.cache_valid,dut.data_out,dut.read_pipe,dut.write_data,dut.write_pending,dut.we_d,dut.cas_d}};
 assign original_state[1]={70'b0,{reference.read_value,reference.waiting,reference.write_done,reference.hit,reference.data_out,reference.read_pipe,reference.write_data,reference.write_pending,reference.we_d,reference.cas_d}};
 assign data_out[1][15:12]=0;
 assign ref_data_out[1][15:12]=0;
 assign chip_data_out[1][15:12]=0;
 assign chip_word[1][15:12]=0;
end
endmodule
