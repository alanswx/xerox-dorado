create_clock -name host_clock -period 15.000 [get_ports host_clk]
derive_clock_uncertainty
set_input_delay -clock host_clock -max 2.000 [get_ports {pins[*]}]
set_input_delay -clock host_clock -min 0.000 [get_ports {pins[*]}]
set_output_delay -clock host_clock -max 2.000 [get_ports {result[*]}]
set_output_delay -clock host_clock -min 0.000 [get_ports {result[*]}]
