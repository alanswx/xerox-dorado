`timescale 1ns/1ps
`default_nettype none
module capture_conta(input wire fixture_load,input wire [31:0] fixture_state,
 input wire base,start_a,en,input wire [27:0] pins,
 output wire [31:0] state_q,output wire [11:0] clocks,
 output wire [5:0] flags);
 wire n0; // AlwaysSH
 wire n1; // CAHold
 wire n2; // CAHold'
 wire n3; // CAHoldB
 wire n4; // CAHoldD
 wire n5; // CLK.ca'
 wire n6; // CLKEnable'a
 wire n7; // CLKEnable'b
 wire n8; // CLKEnable'c
 wire n9; // CPAddr.0'
 wire n10; // CPStrb'
 wire n11; // CRamClock
 wire n12; // ClearMemStop
 wire n13; // ContA02.sil+1
 wire n14; // ContA27.sil+1
 wire n15; // ContA27.sil+2
 wire n16; // ContA28.sil+7
 wire n17; // ContA30.sil+1
 wire n18; // ContA31.sil+1
 wire n19; // ContA31.sil+2
 wire n20; // ContA31.sil+3
 wire n21; // ContA31.sil+4
 wire n22; // ContA31.sil+5
 wire n23; // Error'
 wire n24; // Freeze
 wire n25; // FreezeAC
 wire n26; // FreezeBD
 wire n27; // GND264
 wire n28; // GND266
 wire n29; // GND278
 wire n30; // GND312
 wire n31; // GND314
 wire n32; // GND394
 wire n33; // GND396
 wire n34; // GND398
 wire n35; // GND444
 wire n36; // GND446
 wire n37; // GND468
 wire n38; // GND530
 wire n39; // GND544
 wire n40; // GetTLink
 wire n41; // GetTLink'
 wire n42; // Hold
 wire n43; // MemClkEnable'a
 wire n44; // MemClkEnable'b
 wire n45; // MemSH
 wire n46; // MemSH'
 wire n47; // NoDispatch
 wire n48; // Phase0
 wire n49; // Phase0'
 wire n50; // Phase1
 wire n51; // Phase2
 wire n52; // Phase2'
 wire n53; // Phase3
 wire n54; // Phase3'
 wire n55; // Phase4
 wire n56; // Phase4'
 wire n57; // RWTPCorRWIM
 wire n58; // RepeatCur
 wire n59; // RepeatCur'
 wire n60; // RepeatCurB
 wire n61; // RepeatCurC
 wire n62; // RepeatCurD
 wire n63; // Run'
 wire n64; // RunClk'a
 wire n65; // RunClk'b
 wire n66; // RunRefresh
 wire n67; // RunRefresh'
 wire n68; // SC&NoFreeze
 wire n69; // SC&NoFreeze'
 wire n70; // SCorFreezea
 wire n71; // SCorFreezeb
 wire n72; // SetRun
 wire n73; // SetRun'
 wire n74; // SetRunRfsh
 wire n75; // SetSS'
 wire n76; // StartCycle
 wire n77; // StartCycle'
 wire n78; // StartCycle'a
 wire n79; // Stop
 wire n80; // StopAtT1
 wire n81; // StopAtT1'
 wire n82; // StopRunClock
 wire n83; // SwitchUp
 wire n84; // TPCIclk'a
 wire n85; // TPCIclk'b
 wire n86; // TPCIclk'c
 wire n87; // TrueAC
 wire n88; // TrueBD
 wire n89; // UseDMD
 wire n90; // WIM'
 wire n91; // WantRunRfsh
 wire n92; // bCLKEnable'a
 wire n93; // bCLKEnable'b
 wire n94; // bCLKEnable'c
 wire n95; // bCLKEnable'd
 wire n96; // bCLKEnable'e
 wire n97; // bCLKEnable'f
 wire n98; // bpreStartC'a
 wire n99; // bpreStartC'b
 wire n100; // bpreStartC'c
 wire n101; // clk0'Ba
 wire n102; // clk0'Bb
 wire n103; // clk0'Da
 wire n104; // clk0'Db
 wire n105; // clk0'Dc
 wire n106; // clk2'Ba
 wire n107; // clk2'Bb
 wire n108; // clk2'Bc
 wire n109; // clk2'Bd
 wire n110; // clk2'Be
 wire n111; // clk2'Bf
 wire n112; // dMemRun
 wire n113; // dRun
 wire n114; // dStartCycle
 wire n115; // dStop
 wire n116; // h*fclk0'Ba
 wire n117; // h*fclk0'Bb
 wire n118; // h*fclk0'Da
 wire n119; // h*fclk0'Db
 wire n120; // h*fclk0'Dc
 wire n121; // preCRamClock
 wire n122; // preFH'
 wire n123; // preRunClk'Ba
 wire n124; // preRunClk'Bb
 wire n125; // preRunClk'Bc
 wire n126; // preStartCyclea
 wire n127; // preclk0'Aa
 wire n128; // preclk0'Ba
 wire n129; // preclk0'Ca
 wire n130; // preclk0'Cb
 wire n131; // preclk0'Da
 wire n132; // preclk1'Aa
 wire n133; // preclk1'Ca
 wire n134; // preclk1'Da
 wire n135; // preclk2'Aa
 wire n136; // preclk2'Ba
 wire n137; // preclk2'Bb
 wire n138; // preclk2'Bc
 wire n139; // preclk2'Bd
 wire n140; // preclk2'Ca
 wire n141; // preclk2'Da
 wire n142; // prepreclk'a
 wire n143; // prepreclk'b
 wire n144; // prepreclk'c
 wire n145; // prepreclk'd
 wire n146; // prepreclk'e
 wire n147; // rStop
 wire n148; // sPhase0
 assign n27=1'b0;
 assign n28=1'b0;
 assign n29=1'b0;
 assign n30=1'b0;
 assign n31=1'b0;
 assign n32=1'b0;
 assign n33=1'b0;
 assign n34=1'b0;
 assign n35=1'b0;
 assign n36=1'b0;
 assign n37=1'b0;
 assign n38=1'b0;
 assign n39=1'b0;
 assign n5=base;
 assign n9=1'b1;
 assign n10=1'b1;
 assign n16=1'b0;
 assign n17=1'b0;
 assign n23=pins[3];
 assign n40=1'b0;
 assign n42=pins[26];
 assign n47=pins[0];
 assign n57=pins[1];
 assign n72=pins[6];
 assign n74=pins[4];
 assign n75=pins[5];
 assign n80=pins[2];
 assign n83=pins[27];
 assign n90=pins[8];
 assign n147=pins[7];
 wire n0_l05_3;
 assign n0=n0_l05_3;
 wire n1_f20_15;
 assign n1=n1_f20_15;
 wire n2_f20_14;
 assign n2=n2_f20_14;
 wire n3_f19_2;
 assign n3=n3_f19_2;
 wire n4_f19_4;
 assign n4=n4_f19_4;
 wire n6_k02_15;
 wire n6_k01_14;
 assign n6=n6_k02_15 | n6_k01_14;
 wire n7_k02_2;
 wire n7_k01_3;
 assign n7=n7_k02_2 | n7_k01_3;
 wire n8_l02_14;
 wire n8_l02_2;
 assign n8=n8_l02_14 | n8_l02_2;
 wire n11_j01_3;
 assign n11=n11_j01_3;
 wire n12_h03_3;
 assign n12=n12_h03_3;
 wire n13_h03_14;
 assign n13=n13_h03_14;
 wire n14_j05_2;
 assign n14=n14_j05_2;
 wire n15_i04_3;
 assign n15=n15_i04_3;
 wire n18_i03_14;
 assign n18=n18_i03_14;
 wire n19_i03_13;
 assign n19=n19_i03_13;
 wire n20_i03_2;
 assign n20=n20_i03_2;
 wire n21_i03_3;
 assign n21=n21_i03_3;
 wire n22_i03_4;
 assign n22=n22_i03_4;
 wire n24_i07_14;
 assign n24=n24_i07_14;
 wire n25_i07_13;
 assign n25=n25_i07_13;
 wire n26_i07_12;
 assign n26=n26_i07_12;
 wire n41_g05_15;
 assign n41=n41_g05_15;
 wire n43_l04_15;
 wire n43_l03_14;
 assign n43=n43_l04_15 | n43_l03_14;
 wire n44_l04_2;
 wire n44_l03_3;
 assign n44=n44_l04_2 | n44_l03_3;
 wire n45_k03_3;
 assign n45=n45_k03_3;
 wire n46_k03_2;
 assign n46=n46_k03_2;
 wire n48_l07_15;
 assign n48=n48_l07_15;
 wire n49_l07_14;
 assign n49=n49_l07_14;
 wire n50_l07_2;
 assign n50=n50_l07_2;
 wire n51_k05_15;
 assign n51=n51_k05_15;
 wire n52_k05_14;
 assign n52=n52_k05_14;
 wire n53_k05_2;
 assign n53=n53_k05_2;
 wire n54_k05_3;
 assign n54=n54_k05_3;
 wire n55_j01_15;
 assign n55=n55_j01_15;
 wire n56_j01_14;
 assign n56=n56_j01_14;
 wire n58_f20_3;
 assign n58=n58_f20_3;
 wire n59_f20_2;
 assign n59=n59_f20_2;
 wire n60_f19_13;
 assign n60=n60_f19_13;
 wire n61_f19_12;
 assign n61=n61_f19_12;
 wire n62_f19_14;
 assign n62=n62_f19_14;
 wire n63_j04_14;
 assign n63=n63_j04_14;
 wire n64_i06_3;
 assign n64=n64_i06_3;
 wire n65_i06_2;
 assign n65=n65_i06_2;
 wire n66_l06_15;
 assign n66=n66_l06_15;
 wire n67_l06_14;
 assign n67=n67_l06_14;
 wire n68_k04_2;
 assign n68=n68_k04_2;
 wire n69_k04_3;
 assign n69=n69_k04_3;
 wire n70_i06_13;
 assign n70=n70_i06_13;
 wire n71_i06_12;
 assign n71=n71_i06_12;
 wire n73_g05_3;
 assign n73=n73_g05_3;
 wire n76_k04_15;
 assign n76=n76_k04_15;
 wire n77_k04_14;
 assign n77=n77_k04_14;
 wire n78_k03_14;
 assign n78=n78_k03_14;
 wire n79_j04_2;
 assign n79=n79_j04_2;
 wire n81_g05_2;
 assign n81=n81_g05_2;
 wire n82_l05_2;
 assign n82=n82_l05_2;
 wire n84_j06_13;
 assign n84=n84_j06_13;
 wire n85_j06_12;
 assign n85=n85_j06_12;
 wire n86_j06_14;
 assign n86=n86_j06_14;
 wire n87_g05_13;
 assign n87=n87_g05_13;
 wire n88_g05_4;
 assign n88=n88_g05_4;
 wire n89_i04_15;
 assign n89=n89_i04_15;
 wire n91_l05_15;
 assign n91=n91_l05_15;
 wire n92_i05_3;
 assign n92=n92_i05_3;
 wire n93_i05_2;
 assign n93=n93_i05_2;
 wire n94_i05_4;
 assign n94=n94_i05_4;
 wire n95_i05_13;
 assign n95=n95_i05_13;
 wire n96_i05_12;
 assign n96=n96_i05_12;
 wire n97_i05_14;
 assign n97=n97_i05_14;
 wire n98_l08_3;
 assign n98=n98_l08_3;
 wire n99_l08_4;
 assign n99=n99_l08_4;
 wire n100_l08_2;
 assign n100=n100_l08_2;
 wire n101_j07_13;
 assign n101=n101_j07_13;
 wire n102_j07_12;
 assign n102=n102_j07_12;
 wire n103_j18_3;
 assign n103=n103_j18_3;
 wire n104_j18_2;
 assign n104=n104_j18_2;
 wire n105_j18_4;
 assign n105=n105_j18_4;
 wire n106_j06_3;
 assign n106=n106_j06_3;
 wire n107_j06_2;
 assign n107=n107_j06_2;
 wire n108_j06_4;
 assign n108=n108_j06_4;
 wire n109_i07_3;
 assign n109=n109_i07_3;
 wire n110_i07_2;
 assign n110=n110_i07_2;
 wire n111_i07_4;
 assign n111=n111_i07_4;
 wire n112_g04_15;
 wire n112_h03_2;
 assign n112=n112_g04_15 | n112_h03_2;
 wire n113_i03_15;
 assign n113=n113_i03_15;
 wire n114_j05_3;
 assign n114=n114_j05_3;
 wire n115_i04_2;
 wire n115_j05_14;
 assign n115=n115_i04_2 | n115_j05_14;
 wire n116_j07_3;
 assign n116=n116_j07_3;
 wire n117_j07_2;
 assign n117=n117_j07_2;
 wire n118_j18_13;
 assign n118=n118_j18_13;
 wire n119_j18_12;
 assign n119=n119_j18_12;
 wire n120_j18_14;
 assign n120=n120_j18_14;
 wire n121_g12_4;
 assign n121=n121_g12_4;
 wire n122_l06_3;
 assign n122=n122_l06_3;
 wire n123_f13_13;
 assign n123=n123_f13_13;
 wire n124_f13_12;
 assign n124=n124_f13_12;
 wire n125_f13_14;
 assign n125=n125_f13_14;
 wire n126_k03_15;
 assign n126=n126_k03_15;
 wire n127_g13_3;
 assign n127=n127_g13_3;
 wire n128_g13_2;
 assign n128=n128_g13_2;
 wire n129_g13_13;
 assign n129=n129_g13_13;
 wire n130_g13_12;
 assign n130=n130_g13_12;
 wire n131_g13_4;
 assign n131=n131_g13_4;
 wire n132_f13_3;
 assign n132=n132_f13_3;
 wire n133_f13_2;
 assign n133=n133_f13_2;
 wire n134_f13_4;
 assign n134=n134_f13_4;
 wire n135_f12_3;
 assign n135=n135_f12_3;
 wire n136_f12_13;
 assign n136=n136_f12_13;
 wire n137_f12_12;
 assign n137=n137_f12_12;
 wire n138_f12_14;
 assign n138=n138_f12_14;
 wire n139_g12_14;
 assign n139=n139_g12_14;
 wire n140_f12_2;
 assign n140=n140_f12_2;
 wire n141_f12_4;
 assign n141=n141_f12_4;
 wire n142_l01_13;
 assign n142=n142_l01_13;
 wire n143_l01_12;
 assign n143=n143_l01_12;
 wire n144_l01_14;
 assign n144=n144_l01_14;
 wire n145_l01_3;
 assign n145=n145_l01_3;
 wire n146_l01_2;
 assign n146=n146_l01_2;
 wire n148_i04_14;
 assign n148=n148_i04_14;
 cell_SE10210 f12(.p2(n140_f12_2),.p3(n135_f12_3),.p4(n141_f12_4),.p5(n144),.p6(1'b0),.p7(n94),.p8(1'b0),.p9(n94),.p10(1'b0),.p11(n144),.p12(n137_f12_12),.p13(n136_f12_13),.p14(n138_f12_14),.p15(n27),.p16(1'b0));
 cell_SE10210 f13(.p2(n133_f13_2),.p3(n132_f13_3),.p4(n134_f13_4),.p5(n122),.p6(n142),.p7(n92),.p8(1'b0),.p9(1'b0),.p10(n82),.p11(n142),.p12(n124_f13_12),.p13(n123_f13_13),.p14(n125_f13_14),.p15(n28),.p16(1'b0));
 cell_SE10211 f19(.p2(n3_f19_2),.p4(n4_f19_4),.p5(1'b0),.p6(n2),.p7(1'b0),.p9(1'b0),.p10(n2),.p11(n83),.p12(n61_f19_12),.p13(n60_f19_13),.p14(n62_f19_14),.p15(n29),.p16(1'b0));
 cell_MC1660 f20(.p2(n59_f20_2),.p3(n58_f20_3),.p4(n2),.p5(1'b0),.p6(1'b0),.p7(n83),.p8(1'b0),.p10(n42),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n2_f20_14),.p15(n1_f20_15));
 cell_MC10104 g04(.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(1'b0),.p10(1'b0),.p11(1'b0),.p12(n91),.p13(n67),.p15(n112_g04_15),.p16(1'b0));
 cell_MC10195 g05(.p2(n81_g05_2),.p3(n73_g05_3),.p4(n88_g05_4),.p5(n80),.p6(n72),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p12(n40),.p13(n87_g05_13),.p15(n41_g05_15));
 cell_SE10212 g12(.p1(1'b0),.p4(n121_g12_4),.p5(n97),.p6(1'b0),.p7(n146),.p8(1'b0),.p9(n146),.p10(1'b0),.p11(n97),.p14(n139_g12_14),.p15(n30),.p16(1'b0));
 cell_SE10210 g13(.p2(n128_g13_2),.p3(n127_g13_3),.p4(n131_g13_4),.p5(n77),.p6(n143),.p7(n93),.p8(1'b0),.p9(n77),.p10(n143),.p11(n93),.p12(n130_g13_12),.p13(n129_g13_13),.p15(n31),.p16(1'b0));
 cell_MC10103 h03(.p1(1'b0),.p2(n112_h03_2),.p3(n12_h03_3),.p4(n113),.p5(1'b0),.p6(n147),.p7(n66),.p10(n9),.p11(n10),.p12(1'b0),.p13(1'b0),.p14(n13_h03_14),.p16(1'b0));
 original_MC10176 i03(.p1(1'b0),.p2(n20_i03_2),.p3(n21_i03_3),.p4(n22_i03_4),.p5(n75),.p6(n20),.p7(n21),.p8(1'b0),.p9(n65),.p10(n72),.p11(n19),.p12(n18),.p13(n19_i03_13),.p14(n18_i03_14),.p15(n113_i03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[0+:6]),.state_q(state_q[0+:6]));
 cell_MC10104 i04(.p2(n115_i04_2),.p3(n15_i04_3),.p4(n48),.p5(n80),.p6(n14),.p7(n48),.p10(n81),.p11(n96),.p12(n16),.p13(n72),.p14(n148_i04_14),.p15(n89_i04_15),.p16(1'b0));
 cell_MC10210 i05(.p1(1'b0),.p2(n93_i05_2),.p3(n92_i05_3),.p4(n94_i05_4),.p5(n79),.p6(n63),.p7(1'b0),.p8(1'b0),.p9(n63),.p10(1'b0),.p11(n79),.p12(n96_i05_12),.p13(n95_i05_13),.p14(n97_i05_14),.p15(n32),.p16(1'b0));
 cell_SE10210 i06(.p2(n65_i06_2),.p3(n64_i06_3),.p5(1'b0),.p6(1'b0),.p7(n123),.p8(1'b0),.p9(1'b0),.p10(n26),.p11(n126),.p12(n71_i06_12),.p13(n70_i06_13),.p15(n33),.p16(1'b0));
 cell_SE10210 i07(.p2(n110_i07_2),.p3(n109_i07_3),.p4(n111_i07_4),.p5(1'b0),.p6(1'b0),.p7(n139),.p8(1'b0),.p9(n47),.p10(1'b0),.p11(1'b0),.p12(n26_i07_12),.p13(n25_i07_13),.p14(n24_i07_14),.p15(n34),.p16(1'b0));
 original_MC10231 j01(.p1(1'b0),.p3(n11_j01_3),.p4(1'b0),.p5(n90),.p6(n121),.p7(n52),.p8(1'b0),.p9(1'b0),.p10(n53),.p11(n108),.p12(1'b0),.p13(n148),.p14(n56_j01_14),.p15(n55_j01_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[30+:2]),.state_q(state_q[30+:2]));
 original_MC10231 j04(.p1(1'b0),.p2(n79_j04_2),.p4(n147),.p5(1'b0),.p6(n108),.p7(n115),.p8(1'b0),.p9(1'b0),.p10(n113),.p11(n64),.p12(1'b0),.p13(1'b0),.p14(n63_j04_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[6+:2]),.state_q(state_q[6+:2]));
 cell_MC10117 j05(.p2(n14_j05_2),.p3(n114_j05_3),.p4(n57),.p5(n49),.p6(1'b0),.p7(n56),.p9(1'b0),.p10(n99),.p11(n22),.p12(n99),.p13(n23),.p14(n115_j05_14));
 cell_SE10210 j06(.p2(n107_j06_2),.p3(n106_j06_3),.p4(n108_j06_4),.p5(1'b0),.p6(n136),.p7(1'b0),.p8(1'b0),.p9(n136),.p10(1'b0),.p11(n17),.p12(n85_j06_12),.p13(n84_j06_13),.p14(n86_j06_14),.p15(n35),.p16(1'b0));
 cell_SE10210 j07(.p2(n117_j07_2),.p3(n116_j07_3),.p5(n26),.p6(n58),.p7(n128),.p8(1'b0),.p9(n128),.p10(1'b0),.p11(1'b0),.p12(n102_j07_12),.p13(n101_j07_13),.p15(n36),.p16(1'b0));
 cell_SE10210 j18(.p2(n104_j18_2),.p3(n103_j18_3),.p4(n105_j18_4),.p5(1'b0),.p6(1'b0),.p7(n131),.p8(1'b0),.p9(n26),.p10(n62),.p11(n131),.p12(n119_j18_12),.p13(n118_j18_13),.p14(n120_j18_14),.p15(n37),.p16(1'b0));
 original_MC10231 k01(.p1(1'b0),.p3(n7_k01_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n113),.p8(1'b0),.p9(n124),.p10(n113),.p11(1'b0),.p12(1'b0),.p13(1'b0),.p14(n6_k01_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[8+:2]),.state_q(state_q[8+:2]));
 original_MC10231 k02(.p1(1'b0),.p2(n7_k02_2),.p4(n147),.p5(1'b0),.p6(1'b0),.p7(n115),.p8(1'b0),.p9(n137),.p10(n115),.p11(1'b0),.p12(1'b0),.p13(n147),.p15(n6_k02_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[10+:2]),.state_q(state_q[10+:2]));
 original_MC10231 k03(.p1(1'b0),.p2(n46_k03_2),.p3(n45_k03_3),.p4(1'b0),.p5(1'b0),.p6(n145),.p7(n0),.p8(1'b0),.p9(1'b0),.p10(n114),.p11(n137),.p12(1'b0),.p13(n148),.p14(n78_k03_14),.p15(n126_k03_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[22+:2]),.state_q(state_q[22+:2]));
 original_MC10231 k04(.p1(1'b0),.p2(n68_k04_2),.p3(n69_k04_3),.p4(n148),.p5(1'b0),.p6(n26),.p7(n114),.p8(1'b0),.p9(n110),.p10(n114),.p11(1'b0),.p12(1'b0),.p13(n148),.p14(n77_k04_14),.p15(n76_k04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[24+:2]),.state_q(state_q[24+:2]));
 original_MC10231 k05(.p1(1'b0),.p2(n53_k05_2),.p3(n54_k05_3),.p4(n148),.p5(1'b0),.p6(1'b0),.p7(n51),.p8(1'b0),.p9(n110),.p10(n50),.p11(1'b0),.p12(1'b0),.p13(n148),.p14(n52_k05_14),.p15(n51_k05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[26+:2]),.state_q(state_q[26+:2]));
 cell_SE10210 l01(.p2(n146_l01_2),.p3(n145_l01_3),.p5(1'b0),.p6(1'b0),.p7(n5),.p8(1'b0),.p9(1'b0),.p10(1'b0),.p11(n5),.p12(n143_l01_12),.p13(n142_l01_13),.p14(n144_l01_14),.p15(n38),.p16(1'b0));
 original_MC10231 l02(.p1(1'b0),.p2(n8_l02_2),.p4(n147),.p5(1'b0),.p6(n138),.p7(n115),.p8(1'b0),.p9(1'b0),.p10(n113),.p11(n125),.p12(1'b0),.p13(1'b0),.p14(n8_l02_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[12+:2]),.state_q(state_q[12+:2]));
 original_MC10231 l03(.p1(1'b0),.p3(n44_l03_3),.p4(1'b0),.p5(n66),.p6(1'b0),.p7(n112),.p8(1'b0),.p9(n125),.p10(n112),.p11(1'b0),.p12(n66),.p13(1'b0),.p14(n43_l03_14),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[14+:2]),.state_q(state_q[14+:2]));
 original_MC10231 l04(.p1(1'b0),.p2(n44_l04_2),.p4(n12),.p5(1'b0),.p6(1'b0),.p7(n115),.p8(1'b0),.p9(n137),.p10(n115),.p11(1'b0),.p12(1'b0),.p13(n12),.p15(n43_l04_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[16+:2]),.state_q(state_q[16+:2]));
 original_MC10231 l05(.p1(1'b0),.p2(n82_l05_2),.p3(n0_l05_3),.p4(1'b0),.p5(1'b0),.p6(1'b0),.p7(n0),.p8(1'b0),.p9(n145),.p10(n74),.p11(n82),.p12(1'b0),.p13(1'b0),.p15(n91_l05_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[18+:2]),.state_q(state_q[18+:2]));
 original_SE10231 l06(.p3(n122_l06_3),.p6(n95),.p7(n126),.p9(n145),.p10(n91),.p11(n82),.p13(1'b0),.p14(n67_l06_14),.p15(n66_l06_15),.fixture_load(fixture_load),.fixture_state(fixture_state[20+:2]),.state_q(state_q[20+:2]));
 original_MC10231 l07(.p1(1'b0),.p2(n50_l07_2),.p4(n148),.p5(1'b0),.p6(1'b0),.p7(n15),.p8(1'b0),.p9(n111),.p10(n76),.p11(1'b0),.p12(n148),.p13(1'b0),.p14(n49_l07_14),.p15(n48_l07_15),.p16(1'b0),.fixture_load(fixture_load),.fixture_state(fixture_state[28+:2]),.state_q(state_q[28+:2]));
 cell_MC10211 l08(.p2(n100_l08_2),.p3(n98_l08_3),.p4(n99_l08_4),.p5(1'b0),.p6(n126),.p7(1'b0),.p9(1'b0),.p10(1'b0),.p11(1'b0),.p15(n39),.p16(1'b0));
 assign clocks[0]=n145;
 assign clocks[1]=n82;
 assign clocks[2]=n125;
 assign clocks[3]=n64;
 assign clocks[4]=n137;
 assign clocks[5]=n108;
 assign clocks[6]=l06.ca;
 assign clocks[7]=k04.ca;
 assign clocks[8]=n121;
 assign clocks[9]=n101;
 assign clocks[10]=n116;
 assign clocks[11]=n118;
 assign flags[0]=n1;
 assign flags[1]=n58;
 assign flags[2]=n26;
 assign flags[3]=n8;
 assign flags[4]=n7;
 assign flags[5]=n78;
endmodule
`default_nettype wire
