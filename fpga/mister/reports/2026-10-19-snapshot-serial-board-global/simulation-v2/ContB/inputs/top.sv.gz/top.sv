module snapshot_fit(
 input wire host_clk,run,system_reset,input wire [101:0] stimulus,
 input wire freeze,held,request,write,input wire [14:0] state_index,
 input wire [17:0] state_data,
 output reg [70:0] board_outputs,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 reg run_r;
 always @(posedge host_clk) run_r <= run;
 reg enabled;
 always @(negedge host_clk) enabled <= run_r;
 wire guest_clk;
 altclkctrl #(.clock_type("Global Clock"),.ena_register_mode("falling edge"),
              .intended_device_family("Cyclone V")) machine_clock
   (.inclk({3'b000,host_clk}),.clkselect(2'b00),.ena(run_r),.outclk(guest_clk));
 reg [101:0] pins;
 reg [37:0] admin;
 always @(negedge host_clk) begin
   pins <= stimulus;
   admin <= {system_reset,freeze,held,request,write,state_index,state_data};
 end
 wire system_reset_r,freeze_r,held_r,request_r,write_r;
 wire [14:0] index_r;wire [17:0] data_r;
 assign {system_reset_r,freeze_r,held_r,request_r,write_r,index_r,data_r}=admin;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 always @(negedge host_clk)
   {frozen,done,error,result,scan_hold_required,scan_fault} <= {bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};
 wire ALUF_0__drv;
 wire ALUF_1__drv;
 wire ALUF_2__drv;
 wire ALUF_3__drv;
 wire ASEL_0__drv;
 wire ASEL_0_p___drv;
 wire ASEL_0_p_a__drv;
 wire ASEL_0_p_mem__drv;
 wire ASEL_1_p___drv;
 wire ASEL_2_p___drv;
 wire BNPC_04__drv;
 wire BNPC_05__drv;
 wire BNPC_06__drv;
 wire BNPC_07__drv;
 wire BNPC_08__drv;
 wire BNPC_09__drv;
 wire BNPC_10__drv;
 wire BNPC_11__drv;
 wire BNPC_12__drv;
 wire BNPC_13__drv;
 wire BNPC_14__drv;
 wire BNPC_15__drv;
 wire BSEL_0_p___drv;
 wire BSEL_1_p___drv;
 wire BSEL_2_p___drv;
 wire CBTempSense__drv;
 wire CPIn_0__drv;
 wire CPIn_1__drv;
 wire CPIn_2__drv;
 wire CPIn_3__drv;
 wire DMuxData__drv;
 wire Error_p___drv;
 wire IMLHPE_p___drv;
 wire IMLHPEDly__drv;
 wire IMRHPEDly__drv;
 wire LC_0__drv;
 wire LC_1__drv;
 wire LC_2__drv;
 wire RSTK_0__drv;
 wire RSTK_1__drv;
 wire RSTK_2__drv;
 wire RSTK_3__drv;
 wire StopMIRClk__drv;
 wire dBlock_p___drv;
 wire dFF_0__drv;
 wire dFF_1__drv;
 wire dFF_2__drv;
 wire dFF_3__drv;
 wire dFF_4__drv;
 wire dFF_5__drv;
 wire dFF_6__drv;
 wire dFF_7__drv;
 wire dIMOut_07__drv;
 wire dIMOut_08__drv;
 wire dIMOut_09__drv;
 wire dIMOut_10__drv;
 wire dIMOut_11__drv;
 wire dIMOut_12__drv;
 wire dIMOut_13__drv;
 wire dIMOut_14__drv;
 wire dIMOut_15__drv;
 wire dIMRH__drv;
 wire dJCN_0__drv;
 wire dJCN_1__drv;
 wire dJCN_2__drv;
 wire dJCN_3__drv;
 wire dJCN_4__drv;
 wire dJCN_5__drv;
 wire dJCN_6__drv;
 wire dJCN_7__drv;
 wire rMIRa__drv;
 always @(negedge host_clk) board_outputs <= {rMIRa__drv, dJCN_7__drv, dJCN_6__drv, dJCN_5__drv, dJCN_4__drv, dJCN_3__drv, dJCN_2__drv, dJCN_1__drv, dJCN_0__drv, dIMRH__drv, dIMOut_15__drv, dIMOut_14__drv, dIMOut_13__drv, dIMOut_12__drv, dIMOut_11__drv, dIMOut_10__drv, dIMOut_09__drv, dIMOut_08__drv, dIMOut_07__drv, dFF_7__drv, dFF_6__drv, dFF_5__drv, dFF_4__drv, dFF_3__drv, dFF_2__drv, dFF_1__drv, dFF_0__drv, dBlock_p___drv, StopMIRClk__drv, RSTK_3__drv, RSTK_2__drv, RSTK_1__drv, RSTK_0__drv, LC_2__drv, LC_1__drv, LC_0__drv, IMRHPEDly__drv, IMLHPEDly__drv, IMLHPE_p___drv, Error_p___drv, DMuxData__drv, CPIn_3__drv, CPIn_2__drv, CPIn_1__drv, CPIn_0__drv, CBTempSense__drv, BSEL_2_p___drv, BSEL_1_p___drv, BSEL_0_p___drv, BNPC_15__drv, BNPC_14__drv, BNPC_13__drv, BNPC_12__drv, BNPC_11__drv, BNPC_10__drv, BNPC_09__drv, BNPC_08__drv, BNPC_07__drv, BNPC_06__drv, BNPC_05__drv, BNPC_04__drv, ASEL_2_p___drv, ASEL_1_p___drv, ASEL_0_p_mem__drv, ASEL_0_p_a__drv, ASEL_0_p___drv, ASEL_0__drv, ALUF_3__drv, ALUF_2__drv, ALUF_1__drv, ALUF_0__drv};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 ContB_full_snapshot_experiment #(.SYSPER(4)) board (
 .state_system_reset(system_reset_r),.state_scan_hold_required(bank_scan_hold),.state_scan_fault(bank_scan_fault),
 .state_host_clk(host_clk),.state_guest_advance(enabled),
 .state_freeze(freeze_r),.state_guest_held(held_r),
 .state_frozen(bank_frozen),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(data_r),.state_done(bank_done),
 .state_error(bank_error),.state_result(bank_result),
`else
 assign bank_frozen=0;assign bank_done=0;assign bank_error=0;assign bank_result=0;
 ContB_m_Rev_m_Cd #(.SYSPER(4)) board (
`endif
 .sys_clk(guest_clk),
 .ALUF_0(pins[0] | ALUF_0__drv),
 .ALUF_1(pins[1] | ALUF_1__drv),
 .ALUF_2(pins[2] | ALUF_2__drv),
 .ALUF_3(pins[3] | ALUF_3__drv),
 .BMux_00(pins[4]),
 .BMux_01(pins[5]),
 .BMux_02(pins[6]),
 .BMux_03(pins[7]),
 .BMux_04(pins[8]),
 .BMux_05(pins[9]),
 .BMux_06(pins[10]),
 .BMux_07(pins[11]),
 .BMux_08(pins[12]),
 .BMux_09(pins[13]),
 .BMux_10(pins[14]),
 .BMux_11(pins[15]),
 .BMux_12(pins[16]),
 .BMux_13(pins[17]),
 .BMux_14(pins[18]),
 .BMux_15(pins[19]),
 .BMux_16(pins[20]),
 .BMux_17(pins[21]),
 .BNPC_02(pins[22]),
 .BNPC_03(pins[23]),
 .BNPC_04(pins[24] | BNPC_04__drv),
 .BNPC_05(pins[25] | BNPC_05__drv),
 .BNPC_06(pins[26] | BNPC_06__drv),
 .BNPC_07(pins[27] | BNPC_07__drv),
 .BNPC_08(pins[28] | BNPC_08__drv),
 .BNPC_09(pins[29] | BNPC_09__drv),
 .BNPC_10(pins[30] | BNPC_10__drv),
 .BNPC_11(pins[31] | BNPC_11__drv),
 .BNPC_12(pins[32] | BNPC_12__drv),
 .BNPC_13(pins[33] | BNPC_13__drv),
 .BNPC_14(pins[34] | BNPC_14__drv),
 .BNPC_15(pins[35] | BNPC_15__drv),
 .BNTGtCT_p_a(pins[36]),
 .CBHold(pins[37]),
 .CBTempSense(pins[38] | CBTempSense__drv),
 .CLK_cb_p_(pins[39]),
 .CLKEnable_p_a(pins[40]),
 .CPAddr_0_p_(pins[41]),
 .CPAddr_1_p_(pins[42]),
 .CPAddr_2_p_(pins[43]),
 .CPOut_0(pins[44]),
 .CPOut_1(pins[45]),
 .CPOut_2(pins[46]),
 .CPOut_3(pins[47]),
 .CPOut_8(pins[48]),
 .CPStrb_p_(pins[49]),
 .CRamClock(pins[50]),
 .DMuxClk(pins[51]),
 .DMuxData(pins[52] | DMuxData__drv),
 .DoCBr(pins[53]),
 .IMLHPE_p_(pins[54] | IMLHPE_p___drv),
 .IMLHPEDly(pins[55] | IMLHPEDly__drv),
 .IMRHPE_p_(pins[56]),
 .IMRHPEDly(pins[57] | IMRHPEDly__drv),
 .IOPE(pins[58]),
 .LC_0(pins[59] | LC_0__drv),
 .LC_1(pins[60] | LC_1__drv),
 .LC_2(pins[61] | LC_2__drv),
 .MdPE(pins[62]),
 .MemPE(pins[63]),
 .RamPE(pins[64]),
 .SW(pins[65]),
 .StartCycle_p_a(pins[66]),
 .TNIA_02(pins[67]),
 .TNIA_03(pins[68]),
 .TNIA_04(pins[69]),
 .TNIA_05(pins[70]),
 .TNIA_06(pins[71]),
 .TNIA_07(pins[72]),
 .TNIA_08(pins[73]),
 .TNIA_09(pins[74]),
 .TNIA_10(pins[75]),
 .TNIA_11(pins[76]),
 .TNIA_12(pins[77]),
 .TNIA_13(pins[78]),
 .TNIA_14(pins[79]),
 .TNIA_15(pins[80]),
 .TempRef(pins[81]),
 .UseDMD(pins[82]),
 .dBlock_p_(pins[83] | dBlock_p___drv),
 .dFF_0(pins[84] | dFF_0__drv),
 .dFF_1(pins[85] | dFF_1__drv),
 .dFF_2(pins[86] | dFF_2__drv),
 .dFF_3(pins[87] | dFF_3__drv),
 .dFF_4(pins[88] | dFF_4__drv),
 .dFF_5(pins[89] | dFF_5__drv),
 .dFF_6(pins[90] | dFF_6__drv),
 .dFF_7(pins[91] | dFF_7__drv),
 .dIMRH(pins[92] | dIMRH__drv),
 .dJCN_0(pins[93] | dJCN_0__drv),
 .dJCN_1(pins[94] | dJCN_1__drv),
 .dJCN_2(pins[95] | dJCN_2__drv),
 .dJCN_3(pins[96] | dJCN_3__drv),
 .dJCN_4(pins[97] | dJCN_4__drv),
 .dJCN_5(pins[98] | dJCN_5__drv),
 .dJCN_6(pins[99] | dJCN_6__drv),
 .dJCN_7(pins[100] | dJCN_7__drv),
 .rMIRa(pins[101] | rMIRa__drv),
 .ALUF_0__drv(ALUF_0__drv),
 .ALUF_1__drv(ALUF_1__drv),
 .ALUF_2__drv(ALUF_2__drv),
 .ALUF_3__drv(ALUF_3__drv),
 .ASEL_0__drv(ASEL_0__drv),
 .ASEL_0_p___drv(ASEL_0_p___drv),
 .ASEL_0_p_a__drv(ASEL_0_p_a__drv),
 .ASEL_0_p_mem__drv(ASEL_0_p_mem__drv),
 .ASEL_1_p___drv(ASEL_1_p___drv),
 .ASEL_2_p___drv(ASEL_2_p___drv),
 .BNPC_04__drv(BNPC_04__drv),
 .BNPC_05__drv(BNPC_05__drv),
 .BNPC_06__drv(BNPC_06__drv),
 .BNPC_07__drv(BNPC_07__drv),
 .BNPC_08__drv(BNPC_08__drv),
 .BNPC_09__drv(BNPC_09__drv),
 .BNPC_10__drv(BNPC_10__drv),
 .BNPC_11__drv(BNPC_11__drv),
 .BNPC_12__drv(BNPC_12__drv),
 .BNPC_13__drv(BNPC_13__drv),
 .BNPC_14__drv(BNPC_14__drv),
 .BNPC_15__drv(BNPC_15__drv),
 .BSEL_0_p___drv(BSEL_0_p___drv),
 .BSEL_1_p___drv(BSEL_1_p___drv),
 .BSEL_2_p___drv(BSEL_2_p___drv),
 .CBTempSense__drv(CBTempSense__drv),
 .CPIn_0__drv(CPIn_0__drv),
 .CPIn_1__drv(CPIn_1__drv),
 .CPIn_2__drv(CPIn_2__drv),
 .CPIn_3__drv(CPIn_3__drv),
 .DMuxData__drv(DMuxData__drv),
 .Error_p___drv(Error_p___drv),
 .IMLHPE_p___drv(IMLHPE_p___drv),
 .IMLHPEDly__drv(IMLHPEDly__drv),
 .IMRHPEDly__drv(IMRHPEDly__drv),
 .LC_0__drv(LC_0__drv),
 .LC_1__drv(LC_1__drv),
 .LC_2__drv(LC_2__drv),
 .RSTK_0__drv(RSTK_0__drv),
 .RSTK_1__drv(RSTK_1__drv),
 .RSTK_2__drv(RSTK_2__drv),
 .RSTK_3__drv(RSTK_3__drv),
 .StopMIRClk__drv(StopMIRClk__drv),
 .dBlock_p___drv(dBlock_p___drv),
 .dFF_0__drv(dFF_0__drv),
 .dFF_1__drv(dFF_1__drv),
 .dFF_2__drv(dFF_2__drv),
 .dFF_3__drv(dFF_3__drv),
 .dFF_4__drv(dFF_4__drv),
 .dFF_5__drv(dFF_5__drv),
 .dFF_6__drv(dFF_6__drv),
 .dFF_7__drv(dFF_7__drv),
 .dIMOut_07__drv(dIMOut_07__drv),
 .dIMOut_08__drv(dIMOut_08__drv),
 .dIMOut_09__drv(dIMOut_09__drv),
 .dIMOut_10__drv(dIMOut_10__drv),
 .dIMOut_11__drv(dIMOut_11__drv),
 .dIMOut_12__drv(dIMOut_12__drv),
 .dIMOut_13__drv(dIMOut_13__drv),
 .dIMOut_14__drv(dIMOut_14__drv),
 .dIMOut_15__drv(dIMOut_15__drv),
 .dIMRH__drv(dIMRH__drv),
 .dJCN_0__drv(dJCN_0__drv),
 .dJCN_1__drv(dJCN_1__drv),
 .dJCN_2__drv(dJCN_2__drv),
 .dJCN_3__drv(dJCN_3__drv),
 .dJCN_4__drv(dJCN_4__drv),
 .dJCN_5__drv(dJCN_5__drv),
 .dJCN_6__drv(dJCN_6__drv),
 .dJCN_7__drv(dJCN_7__drv),
 .rMIRa__drv(rMIRa__drv)
 );
endmodule
