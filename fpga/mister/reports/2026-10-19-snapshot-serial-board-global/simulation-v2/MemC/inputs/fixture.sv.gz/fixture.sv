module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [124:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [86:0] reference_outputs,dut_outputs,
 output wire [2213:0] reference_state,dut_state,
 output wire [83:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire reference_AfreeOrEc_p_b__drv;
wire reference_AwantsDifHit_p___drv;
wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_CBHold__drv;
wire reference_CacheRef_p___drv;
wire reference_CacheRefInEc1__drv;
wire reference_DMuxData__drv;
wire reference_Dad_00__drv;
wire reference_Dad_01__drv;
wire reference_Dbuf_u__p___drv;
wire reference_DirtyIoFetchInA_p___drv;
wire reference_DisHold__drv;
wire reference_EcKeepsAbusy__drv;
wire reference_FastD_u_Dbuf__drv;
wire reference_Hita__drv;
wire reference_Hold__drv;
wire reference_IOHold__drv;
wire reference_IfuAck__drv;
wire reference_IfuHold__drv;
wire reference_IfuRefInEc1__drv;
wire reference_IoFetchInA_p___drv;
wire reference_IoStoreInA__drv;
wire reference_MXHold__drv;
wire reference_MakeF_u_D__drv;
wire reference_MapAd_0__drv;
wire reference_MapAd_1__drv;
wire reference_MapAd_2__drv;
wire reference_MapAd_3__drv;
wire reference_MapAd_4__drv;
wire reference_MapAd_5__drv;
wire reference_MapAd_6__drv;
wire reference_MapAd_7__drv;
wire reference_MapAd_8__drv;
wire reference_Map_u_InPair_p___drv;
wire reference_McrD_u__p___drv;
wire reference_Mcr_u__p___drv;
wire reference_MemAd_5__drv;
wire reference_MemAd_6__drv;
wire reference_MemAd_7__drv;
wire reference_MemAd_8__drv;
wire reference_PRhold__drv;
wire reference_PairFull_p___drv;
wire reference_PrivRefInPair__drv;
wire reference_ProcSrn_u__p___drv;
wire reference_ReadInA_p___drv;
wire reference_StartMap_p___drv;
wire reference_Store_u_InA_p___drv;
wire reference_Store_u_InEc1_p___drv;
wire reference_TagInEc1__drv;
wire reference_UseAsrn__drv;
wire reference_VicIfMiss_p___drv;
wire reference_VicInPair_p___drv;
wire reference_VicOrFS1C__drv;
wire reference__u_Config__drv;
wire reference__u_FaultInfo__drv;
wire reference__u_MDdly_p___drv;
wire reference__u_Pipe2__drv;
wire reference__u_Pipe3__drv;
wire reference__u_Pipe4__drv;
wire reference_dDad_02__drv;
wire reference_dDad_03__drv;
wire reference_dDad_04__drv;
wire reference_dDad_05__drv;
wire reference_dDad_06__drv;
wire reference_dDad_07__drv;
wire reference_dDad_08__drv;
wire reference_dDad_09__drv;
wire reference_dDad_10__drv;
wire reference_dDad_11__drv;
wire reference_dDad_12__drv;
wire reference_dDad_13__drv;
wire reference_dHitPerr__drv;
MemC_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ASEL_0(stimulus[0]),
.ASEL_0_p_mem(stimulus[1]),
.ASEL_1_p_(stimulus[2]),
.ASEL_2_p_(stimulus[3]),
.AcanhaveMap_p_(stimulus[4]),
.AfreeOrEc_p_b(stimulus[5] | reference_AfreeOrEc_p_b__drv),
.At_eq_Curt_p_(stimulus[6]),
.AwantsDifHit_p_(stimulus[7] | reference_AwantsDifHit_p___drv),
.BMux_04(stimulus[8] | reference_BMux_04__drv),
.BMux_05(stimulus[9] | reference_BMux_05__drv),
.BMux_06(stimulus[10] | reference_BMux_06__drv),
.BMux_07(stimulus[11] | reference_BMux_07__drv),
.BMux_08(stimulus[12] | reference_BMux_08__drv),
.BMux_09(stimulus[13] | reference_BMux_09__drv),
.BMux_10(stimulus[14] | reference_BMux_10__drv),
.BMux_11(stimulus[15] | reference_BMux_11__drv),
.BMux_12(stimulus[16] | reference_BMux_12__drv),
.BMux_13(stimulus[17] | reference_BMux_13__drv),
.BMux_14(stimulus[18] | reference_BMux_14__drv),
.BMux_15(stimulus[19] | reference_BMux_15__drv),
.CHoldReq(stimulus[20]),
.CLK_mc_p_(stimulus[21]),
.CLKEnable_p_b(stimulus[22]),
.CacheRef_p_(stimulus[23] | reference_CacheRef_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | reference_DMuxData__drv),
.DdataGood_p_(stimulus[26]),
.DisHold(stimulus[27] | reference_DisHold__drv),
.EcDcomingForCt_p_(stimulus[28]),
.EcKeepsAbusy(stimulus[29] | reference_EcKeepsAbusy__drv),
.EcWantsA(stimulus[30]),
.EmuOrFT_p_(stimulus[31]),
.ExtHoldReq(stimulus[32]),
.FA_eq_1_p_(stimulus[33]),
.FF_0mem_p_(stimulus[34]),
.FF_1mem(stimulus[35]),
.FF_2(stimulus[36]),
.FF_3(stimulus[37]),
.FF_4(stimulus[38]),
.FF_5(stimulus[39]),
.FF_6(stimulus[40]),
.FF_7(stimulus[41]),
.FastD_u_Dbuf(stimulus[42] | reference_FastD_u_Dbuf__drv),
.Hita(stimulus[43] | reference_Hita__drv),
.Hold(stimulus[44] | reference_Hold__drv),
.HoldMapBuf(stimulus[45]),
.IfuData_0(stimulus[46]),
.IfuData_1(stimulus[47]),
.IfuData_2(stimulus[48]),
.IfuData_3(stimulus[49]),
.IfuData_4(stimulus[50]),
.IfuData_5(stimulus[51]),
.IfuData_6(stimulus[52]),
.IfuData_7(stimulus[53]),
.IoStoreInA(stimulus[54] | reference_IoStoreInA__drv),
.LdPipeVAdly_p_(stimulus[55]),
.MAR_00_p_(stimulus[56]),
.MAR_01_p_(stimulus[57]),
.MAR_02_p_(stimulus[58]),
.MAR_03_p_(stimulus[59]),
.MAR_04_p_(stimulus[60]),
.MAR_05_p_(stimulus[61]),
.MAR_06_p_(stimulus[62]),
.MAR_07_p_(stimulus[63]),
.MAR_08_p_(stimulus[64]),
.MAR_09_p_(stimulus[65]),
.MAR_10_p_(stimulus[66]),
.MAR_11_p_(stimulus[67]),
.MAR_12_p_(stimulus[68]),
.MAR_13_p_(stimulus[69]),
.MAR_14_p_(stimulus[70]),
.MAR_15_p_(stimulus[71]),
.MDMtag_p_(stimulus[72]),
.MXHold(stimulus[73] | reference_MXHold__drv),
.MakeD_u_CD(stimulus[74]),
.MakeD_u_Dbuf(stimulus[75]),
.MakeF_u_D(stimulus[76] | reference_MakeF_u_D__drv),
.MapAd_0(stimulus[77] | reference_MapAd_0__drv),
.MapAd_1(stimulus[78] | reference_MapAd_1__drv),
.MapAd_2(stimulus[79] | reference_MapAd_2__drv),
.MapAd_3(stimulus[80] | reference_MapAd_3__drv),
.MapAd_4(stimulus[81] | reference_MapAd_4__drv),
.MapAd_5(stimulus[82] | reference_MapAd_5__drv),
.MapAd_6(stimulus[83] | reference_MapAd_6__drv),
.MapAd_7(stimulus[84] | reference_MapAd_7__drv),
.MapAd_8(stimulus[85] | reference_MapAd_8__drv),
.MapRfsh_p_(stimulus[86]),
.MapTroubleInEc1(stimulus[87]),
.MapWait_m_D(stimulus[88]),
.Map_u_InPair_p_(stimulus[89] | reference_Map_u_InPair_p___drv),
.Mcr_u__p_(stimulus[90] | reference_Mcr_u__p___drv),
.MemBase_0(stimulus[91]),
.MemBase_1(stimulus[92]),
.MemBase_2(stimulus[93]),
.MemBase_3(stimulus[94]),
.MemBase_4(stimulus[95]),
.MemClkEnable_p_a(stimulus[96]),
.MemRfsh(stimulus[97]),
.MemSH(stimulus[98]),
.PairFull_p_(stimulus[99] | reference_PairFull_p___drv),
.PrHoldReq(stimulus[100]),
.PrivRefInPair(stimulus[101] | reference_PrivRefInPair__drv),
.ProcTag(stimulus[102]),
.ProcTagInA(stimulus[103]),
.RefOutstanding_p_(stimulus[104]),
.STfree_p_(stimulus[105]),
.StartMap_p_(stimulus[106] | reference_StartMap_p___drv),
.Store_u_InA_p_(stimulus[107] | reference_Store_u_InA_p___drv),
.Transport_p_(stimulus[108]),
.UseAsrn(stimulus[109] | reference_UseAsrn__drv),
.VicIfMiss_p_(stimulus[110] | reference_VicIfMiss_p___drv),
.VicInPair_p_(stimulus[111] | reference_VicInPair_p___drv),
.VicOrFS1C(stimulus[112] | reference_VicOrFS1C__drv),
.WPinEc1(stimulus[113]),
.WantIfuRef_p_(stimulus[114]),
.XWantsPipe(stimulus[115]),
._u_MD(stimulus[116]),
._u_MDI(stimulus[117]),
._u_MDI_p_(stimulus[118]),
._u_MDdly_p_(stimulus[119] | reference__u_MDdly_p___drv),
.dPipe02Ad_0(stimulus[120]),
.dPipe02Ad_1(stimulus[121]),
.dPipe02Ad_2(stimulus[122]),
.dPipe02Ad_3(stimulus[123]),
.preMCSb(stimulus[124]),
.AfreeOrEc_p_b__drv(reference_AfreeOrEc_p_b__drv),
.AwantsDifHit_p___drv(reference_AwantsDifHit_p___drv),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.CBHold__drv(reference_CBHold__drv),
.CacheRef_p___drv(reference_CacheRef_p___drv),
.CacheRefInEc1__drv(reference_CacheRefInEc1__drv),
.DMuxData__drv(reference_DMuxData__drv),
.Dad_00__drv(reference_Dad_00__drv),
.Dad_01__drv(reference_Dad_01__drv),
.Dbuf_u__p___drv(reference_Dbuf_u__p___drv),
.DirtyIoFetchInA_p___drv(reference_DirtyIoFetchInA_p___drv),
.DisHold__drv(reference_DisHold__drv),
.EcKeepsAbusy__drv(reference_EcKeepsAbusy__drv),
.FastD_u_Dbuf__drv(reference_FastD_u_Dbuf__drv),
.Hita__drv(reference_Hita__drv),
.Hold__drv(reference_Hold__drv),
.IOHold__drv(reference_IOHold__drv),
.IfuAck__drv(reference_IfuAck__drv),
.IfuHold__drv(reference_IfuHold__drv),
.IfuRefInEc1__drv(reference_IfuRefInEc1__drv),
.IoFetchInA_p___drv(reference_IoFetchInA_p___drv),
.IoStoreInA__drv(reference_IoStoreInA__drv),
.MXHold__drv(reference_MXHold__drv),
.MakeF_u_D__drv(reference_MakeF_u_D__drv),
.MapAd_0__drv(reference_MapAd_0__drv),
.MapAd_1__drv(reference_MapAd_1__drv),
.MapAd_2__drv(reference_MapAd_2__drv),
.MapAd_3__drv(reference_MapAd_3__drv),
.MapAd_4__drv(reference_MapAd_4__drv),
.MapAd_5__drv(reference_MapAd_5__drv),
.MapAd_6__drv(reference_MapAd_6__drv),
.MapAd_7__drv(reference_MapAd_7__drv),
.MapAd_8__drv(reference_MapAd_8__drv),
.Map_u_InPair_p___drv(reference_Map_u_InPair_p___drv),
.McrD_u__p___drv(reference_McrD_u__p___drv),
.Mcr_u__p___drv(reference_Mcr_u__p___drv),
.MemAd_5__drv(reference_MemAd_5__drv),
.MemAd_6__drv(reference_MemAd_6__drv),
.MemAd_7__drv(reference_MemAd_7__drv),
.MemAd_8__drv(reference_MemAd_8__drv),
.PRhold__drv(reference_PRhold__drv),
.PairFull_p___drv(reference_PairFull_p___drv),
.PrivRefInPair__drv(reference_PrivRefInPair__drv),
.ProcSrn_u__p___drv(reference_ProcSrn_u__p___drv),
.ReadInA_p___drv(reference_ReadInA_p___drv),
.StartMap_p___drv(reference_StartMap_p___drv),
.Store_u_InA_p___drv(reference_Store_u_InA_p___drv),
.Store_u_InEc1_p___drv(reference_Store_u_InEc1_p___drv),
.TagInEc1__drv(reference_TagInEc1__drv),
.UseAsrn__drv(reference_UseAsrn__drv),
.VicIfMiss_p___drv(reference_VicIfMiss_p___drv),
.VicInPair_p___drv(reference_VicInPair_p___drv),
.VicOrFS1C__drv(reference_VicOrFS1C__drv),
._u_Config__drv(reference__u_Config__drv),
._u_FaultInfo__drv(reference__u_FaultInfo__drv),
._u_MDdly_p___drv(reference__u_MDdly_p___drv),
._u_Pipe2__drv(reference__u_Pipe2__drv),
._u_Pipe3__drv(reference__u_Pipe3__drv),
._u_Pipe4__drv(reference__u_Pipe4__drv),
.dDad_02__drv(reference_dDad_02__drv),
.dDad_03__drv(reference_dDad_03__drv),
.dDad_04__drv(reference_dDad_04__drv),
.dDad_05__drv(reference_dDad_05__drv),
.dDad_06__drv(reference_dDad_06__drv),
.dDad_07__drv(reference_dDad_07__drv),
.dDad_08__drv(reference_dDad_08__drv),
.dDad_09__drv(reference_dDad_09__drv),
.dDad_10__drv(reference_dDad_10__drv),
.dDad_11__drv(reference_dDad_11__drv),
.dDad_12__drv(reference_dDad_12__drv),
.dDad_13__drv(reference_dDad_13__drv),
.dHitPerr__drv(reference_dHitPerr__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_dHitPerr__drv,reference_dDad_13__drv,reference_dDad_12__drv,reference_dDad_11__drv,reference_dDad_10__drv,reference_dDad_09__drv,reference_dDad_08__drv,reference_dDad_07__drv,reference_dDad_06__drv,reference_dDad_05__drv,reference_dDad_04__drv,reference_dDad_03__drv,reference_dDad_02__drv,reference__u_Pipe4__drv,reference__u_Pipe3__drv,reference__u_Pipe2__drv,reference__u_MDdly_p___drv,reference__u_FaultInfo__drv,reference__u_Config__drv,reference_VicOrFS1C__drv,reference_VicInPair_p___drv,reference_VicIfMiss_p___drv,reference_UseAsrn__drv,reference_TagInEc1__drv,reference_Store_u_InEc1_p___drv,reference_Store_u_InA_p___drv,reference_StartMap_p___drv,reference_ReadInA_p___drv,reference_ProcSrn_u__p___drv,reference_PrivRefInPair__drv,reference_PairFull_p___drv,reference_PRhold__drv,reference_MemAd_8__drv,reference_MemAd_7__drv,reference_MemAd_6__drv,reference_MemAd_5__drv,reference_Mcr_u__p___drv,reference_McrD_u__p___drv,reference_Map_u_InPair_p___drv,reference_MapAd_8__drv,reference_MapAd_7__drv,reference_MapAd_6__drv,reference_MapAd_5__drv,reference_MapAd_4__drv,reference_MapAd_3__drv,reference_MapAd_2__drv,reference_MapAd_1__drv,reference_MapAd_0__drv,reference_MakeF_u_D__drv,reference_MXHold__drv,reference_IoStoreInA__drv,reference_IoFetchInA_p___drv,reference_IfuRefInEc1__drv,reference_IfuHold__drv,reference_IfuAck__drv,reference_IOHold__drv,reference_Hold__drv,reference_Hita__drv,reference_FastD_u_Dbuf__drv,reference_EcKeepsAbusy__drv,reference_DisHold__drv,reference_DirtyIoFetchInA_p___drv,reference_Dbuf_u__p___drv,reference_Dad_01__drv,reference_Dad_00__drv,reference_DMuxData__drv,reference_CacheRefInEc1__drv,reference_CacheRef_p___drv,reference_CBHold__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv,reference_AwantsDifHit_p___drv,reference_AfreeOrEc_p_b__drv};
assign reference_state[0+:1]=reference.clk1B;
assign reference_state[1+:1]=reference.clk1_p_B;
assign reference_state[2+:1]=reference.clk1_p_Da;
assign reference_state[3+:1]=reference.clk1_p_Db;
assign reference_state[4+:1]=reference.clk1_p_Dc;
assign reference_state[5+:4]=reference.u__h_1c42.q;
assign reference_state[9+:4]=reference.u__h_1c43.q;
assign reference_state[13+:4]=reference.u__h_1f42.q;
assign reference_state[17+:4]=reference.u__h_1i42.q;
assign reference_state[21+:4]=reference.u__h_5b42.q;
assign reference_state[25+:4]=reference.u__h_5b43.q;
assign reference_state[29+:4]=reference.u__h_5e42.q;
assign reference_state[33+:4]=reference.u__h_5h42.q;
assign reference_state[37+:1]=reference.u_a14.cka_d;
assign reference_state[38+:1]=reference.u_a14.ckb_d;
assign reference_state[39+:1]=reference.u_a14.qa;
assign reference_state[40+:1]=reference.u_a14.qb;
assign reference_state[41+:1]=reference.u_a15.cka_d;
assign reference_state[42+:1]=reference.u_a15.ckb_d;
assign reference_state[43+:1]=reference.u_a15.qa;
assign reference_state[44+:1]=reference.u_a15.qb;
assign reference_state[45+:1]=reference.u_b03.ck_d;
assign reference_state[46+:6]=reference.u_b03.d_pre;
assign reference_state[52+:6]=reference.u_b03.q;
assign reference_state[58+:1]=reference.u_b05.ck_d;
assign reference_state[59+:6]=reference.u_b05.d_pre;
assign reference_state[65+:6]=reference.u_b05.q;
assign reference_state[71+:1]=reference.u_b14.cka_d;
assign reference_state[72+:1]=reference.u_b14.ckb_d;
assign reference_state[73+:1]=reference.u_b14.qa;
assign reference_state[74+:1]=reference.u_b14.qb;
assign reference_state[75+:1]=reference.u_b15.cka_d;
assign reference_state[76+:1]=reference.u_b15.ckb_d;
assign reference_state[77+:1]=reference.u_b15.qa;
assign reference_state[78+:1]=reference.u_b15.qb;
assign reference_state[79+:1]=reference.u_c14.cka_d;
assign reference_state[80+:1]=reference.u_c14.ckb_d;
assign reference_state[81+:1]=reference.u_c14.qa;
assign reference_state[82+:1]=reference.u_c14.qb;
assign reference_state[83+:1]=reference.u_c15.cka_d;
assign reference_state[84+:1]=reference.u_c15.ckb_d;
assign reference_state[85+:1]=reference.u_c15.qa;
assign reference_state[86+:1]=reference.u_c15.qb;
assign reference_state[87+:1]=reference.u_c17.cka_d;
assign reference_state[88+:1]=reference.u_c17.ckb_d;
assign reference_state[89+:1]=reference.u_c17.d_pre_a;
assign reference_state[90+:1]=reference.u_c17.d_pre_b;
assign reference_state[91+:1]=reference.u_c17.qa;
assign reference_state[92+:1]=reference.u_c17.qb;
assign reference_state[93+:1]=reference.u_d02.ck_d;
assign reference_state[94+:6]=reference.u_d02.d_pre;
assign reference_state[100+:6]=reference.u_d02.q;
assign reference_state[106+:4]=reference.u_d05.q;
assign reference_state[110+:4]=reference.u_d06.a_lat;
assign reference_state[114+:1]=reference.u_d06.ce_lat;
assign reference_state[115+:4]=reference.u_d06.d_lat;
assign reference_state[119+:64]={reference.u_d06.mem[15],reference.u_d06.mem[14],reference.u_d06.mem[13],reference.u_d06.mem[12],reference.u_d06.mem[11],reference.u_d06.mem[10],reference.u_d06.mem[9],reference.u_d06.mem[8],reference.u_d06.mem[7],reference.u_d06.mem[6],reference.u_d06.mem[5],reference.u_d06.mem[4],reference.u_d06.mem[3],reference.u_d06.mem[2],reference.u_d06.mem[1],reference.u_d06.mem[0]};
assign reference_state[183+:1]=reference.u_d06.we_d;
assign reference_state[184+:4]=reference.u_d07.a_lat;
assign reference_state[188+:1]=reference.u_d07.ce_lat;
assign reference_state[189+:4]=reference.u_d07.d_lat;
assign reference_state[193+:64]={reference.u_d07.mem[15],reference.u_d07.mem[14],reference.u_d07.mem[13],reference.u_d07.mem[12],reference.u_d07.mem[11],reference.u_d07.mem[10],reference.u_d07.mem[9],reference.u_d07.mem[8],reference.u_d07.mem[7],reference.u_d07.mem[6],reference.u_d07.mem[5],reference.u_d07.mem[4],reference.u_d07.mem[3],reference.u_d07.mem[2],reference.u_d07.mem[1],reference.u_d07.mem[0]};
assign reference_state[257+:1]=reference.u_d07.we_d;
assign reference_state[258+:1]=reference.u_d14.cka_d;
assign reference_state[259+:1]=reference.u_d14.ckb_d;
assign reference_state[260+:1]=reference.u_d14.qa;
assign reference_state[261+:1]=reference.u_d14.qb;
assign reference_state[262+:1]=reference.u_d15.cka_d;
assign reference_state[263+:1]=reference.u_d15.ckb_d;
assign reference_state[264+:1]=reference.u_d15.qa;
assign reference_state[265+:1]=reference.u_d15.qb;
assign reference_state[266+:1]=reference.u_d17.cka_d;
assign reference_state[267+:1]=reference.u_d17.ckb_d;
assign reference_state[268+:1]=reference.u_d17.d_pre_a;
assign reference_state[269+:1]=reference.u_d17.d_pre_b;
assign reference_state[270+:1]=reference.u_d17.qa;
assign reference_state[271+:1]=reference.u_d17.qb;
assign reference_state[272+:1]=reference.u_e03.ck_d;
assign reference_state[273+:6]=reference.u_e03.d_pre;
assign reference_state[279+:6]=reference.u_e03.q;
assign reference_state[285+:4]=reference.u_e05.q;
assign reference_state[289+:4]=reference.u_e06.a_lat;
assign reference_state[293+:1]=reference.u_e06.ce_lat;
assign reference_state[294+:4]=reference.u_e06.d_lat;
assign reference_state[298+:64]={reference.u_e06.mem[15],reference.u_e06.mem[14],reference.u_e06.mem[13],reference.u_e06.mem[12],reference.u_e06.mem[11],reference.u_e06.mem[10],reference.u_e06.mem[9],reference.u_e06.mem[8],reference.u_e06.mem[7],reference.u_e06.mem[6],reference.u_e06.mem[5],reference.u_e06.mem[4],reference.u_e06.mem[3],reference.u_e06.mem[2],reference.u_e06.mem[1],reference.u_e06.mem[0]};
assign reference_state[362+:1]=reference.u_e06.we_d;
assign reference_state[363+:4]=reference.u_e07.a_lat;
assign reference_state[367+:1]=reference.u_e07.ce_lat;
assign reference_state[368+:4]=reference.u_e07.d_lat;
assign reference_state[372+:64]={reference.u_e07.mem[15],reference.u_e07.mem[14],reference.u_e07.mem[13],reference.u_e07.mem[12],reference.u_e07.mem[11],reference.u_e07.mem[10],reference.u_e07.mem[9],reference.u_e07.mem[8],reference.u_e07.mem[7],reference.u_e07.mem[6],reference.u_e07.mem[5],reference.u_e07.mem[4],reference.u_e07.mem[3],reference.u_e07.mem[2],reference.u_e07.mem[1],reference.u_e07.mem[0]};
assign reference_state[436+:1]=reference.u_e07.we_d;
assign reference_state[437+:1]=reference.u_e14.cka_d;
assign reference_state[438+:1]=reference.u_e14.ckb_d;
assign reference_state[439+:1]=reference.u_e14.d_pre_a;
assign reference_state[440+:1]=reference.u_e14.d_pre_b;
assign reference_state[441+:1]=reference.u_e14.qa;
assign reference_state[442+:1]=reference.u_e14.qb;
assign reference_state[443+:1]=reference.u_e22.cka_d;
assign reference_state[444+:1]=reference.u_e22.ckb_d;
assign reference_state[445+:1]=reference.u_e22.d_pre_a;
assign reference_state[446+:1]=reference.u_e22.d_pre_b;
assign reference_state[447+:1]=reference.u_e22.qa;
assign reference_state[448+:1]=reference.u_e22.qb;
assign reference_state[449+:1]=reference.u_e23.cka_d;
assign reference_state[450+:1]=reference.u_e23.ckb_d;
assign reference_state[451+:1]=reference.u_e23.d_pre_a;
assign reference_state[452+:1]=reference.u_e23.d_pre_b;
assign reference_state[453+:1]=reference.u_e23.qa;
assign reference_state[454+:1]=reference.u_e23.qb;
assign reference_state[455+:5]=reference.u_f05.q;
assign reference_state[460+:4]=reference.u_f06.a_lat;
assign reference_state[464+:1]=reference.u_f06.ce_lat;
assign reference_state[465+:4]=reference.u_f06.d_lat;
assign reference_state[469+:64]={reference.u_f06.mem[15],reference.u_f06.mem[14],reference.u_f06.mem[13],reference.u_f06.mem[12],reference.u_f06.mem[11],reference.u_f06.mem[10],reference.u_f06.mem[9],reference.u_f06.mem[8],reference.u_f06.mem[7],reference.u_f06.mem[6],reference.u_f06.mem[5],reference.u_f06.mem[4],reference.u_f06.mem[3],reference.u_f06.mem[2],reference.u_f06.mem[1],reference.u_f06.mem[0]};
assign reference_state[533+:1]=reference.u_f06.we_d;
assign reference_state[534+:4]=reference.u_f07.a_lat;
assign reference_state[538+:1]=reference.u_f07.ce_lat;
assign reference_state[539+:4]=reference.u_f07.d_lat;
assign reference_state[543+:64]={reference.u_f07.mem[15],reference.u_f07.mem[14],reference.u_f07.mem[13],reference.u_f07.mem[12],reference.u_f07.mem[11],reference.u_f07.mem[10],reference.u_f07.mem[9],reference.u_f07.mem[8],reference.u_f07.mem[7],reference.u_f07.mem[6],reference.u_f07.mem[5],reference.u_f07.mem[4],reference.u_f07.mem[3],reference.u_f07.mem[2],reference.u_f07.mem[1],reference.u_f07.mem[0]};
assign reference_state[607+:1]=reference.u_f07.we_d;
assign reference_state[608+:1]=reference.u_f08.ck_d;
assign reference_state[609+:6]=reference.u_f08.d_pre;
assign reference_state[615+:6]=reference.u_f08.q;
assign reference_state[621+:4]=reference.u_g02.a_lat;
assign reference_state[625+:1]=reference.u_g02.ce_lat;
assign reference_state[626+:4]=reference.u_g02.d_lat;
assign reference_state[630+:64]={reference.u_g02.mem[15],reference.u_g02.mem[14],reference.u_g02.mem[13],reference.u_g02.mem[12],reference.u_g02.mem[11],reference.u_g02.mem[10],reference.u_g02.mem[9],reference.u_g02.mem[8],reference.u_g02.mem[7],reference.u_g02.mem[6],reference.u_g02.mem[5],reference.u_g02.mem[4],reference.u_g02.mem[3],reference.u_g02.mem[2],reference.u_g02.mem[1],reference.u_g02.mem[0]};
assign reference_state[694+:1]=reference.u_g02.we_d;
assign reference_state[695+:4]=reference.u_g03.a_lat;
assign reference_state[699+:1]=reference.u_g03.ce_lat;
assign reference_state[700+:4]=reference.u_g03.d_lat;
assign reference_state[704+:64]={reference.u_g03.mem[15],reference.u_g03.mem[14],reference.u_g03.mem[13],reference.u_g03.mem[12],reference.u_g03.mem[11],reference.u_g03.mem[10],reference.u_g03.mem[9],reference.u_g03.mem[8],reference.u_g03.mem[7],reference.u_g03.mem[6],reference.u_g03.mem[5],reference.u_g03.mem[4],reference.u_g03.mem[3],reference.u_g03.mem[2],reference.u_g03.mem[1],reference.u_g03.mem[0]};
assign reference_state[768+:1]=reference.u_g03.we_d;
assign reference_state[769+:1]=reference.u_g09.ck_d;
assign reference_state[770+:6]=reference.u_g09.d_pre;
assign reference_state[776+:6]=reference.u_g09.q;
assign reference_state[782+:1]=reference.u_g14.cka_d;
assign reference_state[783+:1]=reference.u_g14.ckb_d;
assign reference_state[784+:1]=reference.u_g14.d_pre_a;
assign reference_state[785+:1]=reference.u_g14.d_pre_b;
assign reference_state[786+:1]=reference.u_g14.qa;
assign reference_state[787+:1]=reference.u_g14.qb;
assign reference_state[788+:1]=reference.u_g17.cka_d;
assign reference_state[789+:1]=reference.u_g17.ckb_d;
assign reference_state[790+:1]=reference.u_g17.d_pre_a;
assign reference_state[791+:1]=reference.u_g17.d_pre_b;
assign reference_state[792+:1]=reference.u_g17.qa;
assign reference_state[793+:1]=reference.u_g17.qb;
assign reference_state[794+:4]=reference.u_g22.q;
assign reference_state[798+:4]=reference.u_g24.q;
assign reference_state[802+:4]=reference.u_h02.a_lat;
assign reference_state[806+:1]=reference.u_h02.ce_lat;
assign reference_state[807+:4]=reference.u_h02.d_lat;
assign reference_state[811+:64]={reference.u_h02.mem[15],reference.u_h02.mem[14],reference.u_h02.mem[13],reference.u_h02.mem[12],reference.u_h02.mem[11],reference.u_h02.mem[10],reference.u_h02.mem[9],reference.u_h02.mem[8],reference.u_h02.mem[7],reference.u_h02.mem[6],reference.u_h02.mem[5],reference.u_h02.mem[4],reference.u_h02.mem[3],reference.u_h02.mem[2],reference.u_h02.mem[1],reference.u_h02.mem[0]};
assign reference_state[875+:1]=reference.u_h02.we_d;
assign reference_state[876+:4]=reference.u_h03.a_lat;
assign reference_state[880+:1]=reference.u_h03.ce_lat;
assign reference_state[881+:4]=reference.u_h03.d_lat;
assign reference_state[885+:64]={reference.u_h03.mem[15],reference.u_h03.mem[14],reference.u_h03.mem[13],reference.u_h03.mem[12],reference.u_h03.mem[11],reference.u_h03.mem[10],reference.u_h03.mem[9],reference.u_h03.mem[8],reference.u_h03.mem[7],reference.u_h03.mem[6],reference.u_h03.mem[5],reference.u_h03.mem[4],reference.u_h03.mem[3],reference.u_h03.mem[2],reference.u_h03.mem[1],reference.u_h03.mem[0]};
assign reference_state[949+:1]=reference.u_h03.we_d;
assign reference_state[950+:5]=reference.u_h05.q;
assign reference_state[955+:4]=reference.u_h06.a_lat;
assign reference_state[959+:1]=reference.u_h06.ce_lat;
assign reference_state[960+:4]=reference.u_h06.d_lat;
assign reference_state[964+:64]={reference.u_h06.mem[15],reference.u_h06.mem[14],reference.u_h06.mem[13],reference.u_h06.mem[12],reference.u_h06.mem[11],reference.u_h06.mem[10],reference.u_h06.mem[9],reference.u_h06.mem[8],reference.u_h06.mem[7],reference.u_h06.mem[6],reference.u_h06.mem[5],reference.u_h06.mem[4],reference.u_h06.mem[3],reference.u_h06.mem[2],reference.u_h06.mem[1],reference.u_h06.mem[0]};
assign reference_state[1028+:1]=reference.u_h06.we_d;
assign reference_state[1029+:4]=reference.u_h07.a_lat;
assign reference_state[1033+:1]=reference.u_h07.ce_lat;
assign reference_state[1034+:4]=reference.u_h07.d_lat;
assign reference_state[1038+:64]={reference.u_h07.mem[15],reference.u_h07.mem[14],reference.u_h07.mem[13],reference.u_h07.mem[12],reference.u_h07.mem[11],reference.u_h07.mem[10],reference.u_h07.mem[9],reference.u_h07.mem[8],reference.u_h07.mem[7],reference.u_h07.mem[6],reference.u_h07.mem[5],reference.u_h07.mem[4],reference.u_h07.mem[3],reference.u_h07.mem[2],reference.u_h07.mem[1],reference.u_h07.mem[0]};
assign reference_state[1102+:1]=reference.u_h07.we_d;
assign reference_state[1103+:1]=reference.u_h22.ck_d;
assign reference_state[1104+:6]=reference.u_h22.d_pre;
assign reference_state[1110+:6]=reference.u_h22.q;
assign reference_state[1116+:4]=reference.u_h24.q;
assign reference_state[1120+:4]=reference.u_i02.a_lat;
assign reference_state[1124+:1]=reference.u_i02.ce_lat;
assign reference_state[1125+:4]=reference.u_i02.d_lat;
assign reference_state[1129+:64]={reference.u_i02.mem[15],reference.u_i02.mem[14],reference.u_i02.mem[13],reference.u_i02.mem[12],reference.u_i02.mem[11],reference.u_i02.mem[10],reference.u_i02.mem[9],reference.u_i02.mem[8],reference.u_i02.mem[7],reference.u_i02.mem[6],reference.u_i02.mem[5],reference.u_i02.mem[4],reference.u_i02.mem[3],reference.u_i02.mem[2],reference.u_i02.mem[1],reference.u_i02.mem[0]};
assign reference_state[1193+:1]=reference.u_i02.we_d;
assign reference_state[1194+:4]=reference.u_i03.a_lat;
assign reference_state[1198+:1]=reference.u_i03.ce_lat;
assign reference_state[1199+:4]=reference.u_i03.d_lat;
assign reference_state[1203+:64]={reference.u_i03.mem[15],reference.u_i03.mem[14],reference.u_i03.mem[13],reference.u_i03.mem[12],reference.u_i03.mem[11],reference.u_i03.mem[10],reference.u_i03.mem[9],reference.u_i03.mem[8],reference.u_i03.mem[7],reference.u_i03.mem[6],reference.u_i03.mem[5],reference.u_i03.mem[4],reference.u_i03.mem[3],reference.u_i03.mem[2],reference.u_i03.mem[1],reference.u_i03.mem[0]};
assign reference_state[1267+:1]=reference.u_i03.we_d;
assign reference_state[1268+:5]=reference.u_i05.q;
assign reference_state[1273+:4]=reference.u_i06.a_lat;
assign reference_state[1277+:1]=reference.u_i06.ce_lat;
assign reference_state[1278+:4]=reference.u_i06.d_lat;
assign reference_state[1282+:64]={reference.u_i06.mem[15],reference.u_i06.mem[14],reference.u_i06.mem[13],reference.u_i06.mem[12],reference.u_i06.mem[11],reference.u_i06.mem[10],reference.u_i06.mem[9],reference.u_i06.mem[8],reference.u_i06.mem[7],reference.u_i06.mem[6],reference.u_i06.mem[5],reference.u_i06.mem[4],reference.u_i06.mem[3],reference.u_i06.mem[2],reference.u_i06.mem[1],reference.u_i06.mem[0]};
assign reference_state[1346+:1]=reference.u_i06.we_d;
assign reference_state[1347+:4]=reference.u_i07.a_lat;
assign reference_state[1351+:1]=reference.u_i07.ce_lat;
assign reference_state[1352+:4]=reference.u_i07.d_lat;
assign reference_state[1356+:64]={reference.u_i07.mem[15],reference.u_i07.mem[14],reference.u_i07.mem[13],reference.u_i07.mem[12],reference.u_i07.mem[11],reference.u_i07.mem[10],reference.u_i07.mem[9],reference.u_i07.mem[8],reference.u_i07.mem[7],reference.u_i07.mem[6],reference.u_i07.mem[5],reference.u_i07.mem[4],reference.u_i07.mem[3],reference.u_i07.mem[2],reference.u_i07.mem[1],reference.u_i07.mem[0]};
assign reference_state[1420+:1]=reference.u_i07.we_d;
assign reference_state[1421+:1]=reference.u_i10.ck_d;
assign reference_state[1422+:4]=reference.u_i10.d_pre;
assign reference_state[1426+:1]=reference.u_i10.dl_pre;
assign reference_state[1427+:1]=reference.u_i10.dr_pre;
assign reference_state[1428+:4]=reference.u_i10.q;
assign reference_state[1432+:2]=reference.u_i10.s_pre;
assign reference_state[1434+:4]=reference.u_i14.a_lat;
assign reference_state[1438+:1]=reference.u_i14.ce_lat;
assign reference_state[1439+:4]=reference.u_i14.d_lat;
assign reference_state[1443+:64]={reference.u_i14.mem[15],reference.u_i14.mem[14],reference.u_i14.mem[13],reference.u_i14.mem[12],reference.u_i14.mem[11],reference.u_i14.mem[10],reference.u_i14.mem[9],reference.u_i14.mem[8],reference.u_i14.mem[7],reference.u_i14.mem[6],reference.u_i14.mem[5],reference.u_i14.mem[4],reference.u_i14.mem[3],reference.u_i14.mem[2],reference.u_i14.mem[1],reference.u_i14.mem[0]};
assign reference_state[1507+:1]=reference.u_i14.we_d;
assign reference_state[1508+:1]=reference.u_i15.ck_d;
assign reference_state[1509+:6]=reference.u_i15.d_pre;
assign reference_state[1515+:6]=reference.u_i15.q;
assign reference_state[1521+:1]=reference.u_i20.ck_d;
assign reference_state[1522+:6]=reference.u_i20.d_pre;
assign reference_state[1528+:6]=reference.u_i20.q;
assign reference_state[1534+:1]=reference.u_i21.ck_d;
assign reference_state[1535+:6]=reference.u_i21.d_pre;
assign reference_state[1541+:6]=reference.u_i21.q;
assign reference_state[1547+:4]=reference.u_i23.q;
assign reference_state[1551+:1]=reference.u_j02.ck_d;
assign reference_state[1552+:6]=reference.u_j02.d_pre;
assign reference_state[1558+:6]=reference.u_j02.q;
assign reference_state[1564+:1]=reference.u_j03.ck_d;
assign reference_state[1565+:6]=reference.u_j03.d_pre;
assign reference_state[1571+:6]=reference.u_j03.q;
assign reference_state[1577+:5]=reference.u_j05.q;
assign reference_state[1582+:4]=reference.u_j06.a_lat;
assign reference_state[1586+:1]=reference.u_j06.ce_lat;
assign reference_state[1587+:4]=reference.u_j06.d_lat;
assign reference_state[1591+:64]={reference.u_j06.mem[15],reference.u_j06.mem[14],reference.u_j06.mem[13],reference.u_j06.mem[12],reference.u_j06.mem[11],reference.u_j06.mem[10],reference.u_j06.mem[9],reference.u_j06.mem[8],reference.u_j06.mem[7],reference.u_j06.mem[6],reference.u_j06.mem[5],reference.u_j06.mem[4],reference.u_j06.mem[3],reference.u_j06.mem[2],reference.u_j06.mem[1],reference.u_j06.mem[0]};
assign reference_state[1655+:1]=reference.u_j06.we_d;
assign reference_state[1656+:4]=reference.u_j07.a_lat;
assign reference_state[1660+:1]=reference.u_j07.ce_lat;
assign reference_state[1661+:4]=reference.u_j07.d_lat;
assign reference_state[1665+:64]={reference.u_j07.mem[15],reference.u_j07.mem[14],reference.u_j07.mem[13],reference.u_j07.mem[12],reference.u_j07.mem[11],reference.u_j07.mem[10],reference.u_j07.mem[9],reference.u_j07.mem[8],reference.u_j07.mem[7],reference.u_j07.mem[6],reference.u_j07.mem[5],reference.u_j07.mem[4],reference.u_j07.mem[3],reference.u_j07.mem[2],reference.u_j07.mem[1],reference.u_j07.mem[0]};
assign reference_state[1729+:1]=reference.u_j07.we_d;
assign reference_state[1730+:1]=reference.u_j15.cka_d;
assign reference_state[1731+:1]=reference.u_j15.ckb_d;
assign reference_state[1732+:1]=reference.u_j15.d_pre_a;
assign reference_state[1733+:1]=reference.u_j15.d_pre_b;
assign reference_state[1734+:1]=reference.u_j15.qa;
assign reference_state[1735+:1]=reference.u_j15.qb;
assign reference_state[1736+:1]=reference.u_j21.ck_d;
assign reference_state[1737+:6]=reference.u_j21.d_pre;
assign reference_state[1743+:6]=reference.u_j21.q;
assign reference_state[1749+:1]=reference.u_k01.ck_d;
assign reference_state[1750+:4]=reference.u_k01.q;
assign reference_state[1754+:6]=reference.u_k01.setup_pre;
assign reference_state[1760+:1]=reference.u_k02.ck_d;
assign reference_state[1761+:4]=reference.u_k02.d_pre;
assign reference_state[1765+:1]=reference.u_k02.dl_pre;
assign reference_state[1766+:1]=reference.u_k02.dr_pre;
assign reference_state[1767+:4]=reference.u_k02.q;
assign reference_state[1771+:2]=reference.u_k02.s_pre;
assign reference_state[1773+:4]=reference.u_k03.a_lat;
assign reference_state[1777+:1]=reference.u_k03.ce_lat;
assign reference_state[1778+:4]=reference.u_k03.d_lat;
assign reference_state[1782+:64]={reference.u_k03.mem[15],reference.u_k03.mem[14],reference.u_k03.mem[13],reference.u_k03.mem[12],reference.u_k03.mem[11],reference.u_k03.mem[10],reference.u_k03.mem[9],reference.u_k03.mem[8],reference.u_k03.mem[7],reference.u_k03.mem[6],reference.u_k03.mem[5],reference.u_k03.mem[4],reference.u_k03.mem[3],reference.u_k03.mem[2],reference.u_k03.mem[1],reference.u_k03.mem[0]};
assign reference_state[1846+:1]=reference.u_k03.we_d;
assign reference_state[1847+:1]=reference.u_k04.ck_d;
assign reference_state[1848+:6]=reference.u_k04.d_pre;
assign reference_state[1854+:6]=reference.u_k04.q;
assign reference_state[1860+:4]=reference.u_k06.a_lat;
assign reference_state[1864+:1]=reference.u_k06.ce_lat;
assign reference_state[1865+:4]=reference.u_k06.d_lat;
assign reference_state[1869+:64]={reference.u_k06.mem[15],reference.u_k06.mem[14],reference.u_k06.mem[13],reference.u_k06.mem[12],reference.u_k06.mem[11],reference.u_k06.mem[10],reference.u_k06.mem[9],reference.u_k06.mem[8],reference.u_k06.mem[7],reference.u_k06.mem[6],reference.u_k06.mem[5],reference.u_k06.mem[4],reference.u_k06.mem[3],reference.u_k06.mem[2],reference.u_k06.mem[1],reference.u_k06.mem[0]};
assign reference_state[1933+:1]=reference.u_k06.we_d;
assign reference_state[1934+:4]=reference.u_k07.a_lat;
assign reference_state[1938+:1]=reference.u_k07.ce_lat;
assign reference_state[1939+:4]=reference.u_k07.d_lat;
assign reference_state[1943+:64]={reference.u_k07.mem[15],reference.u_k07.mem[14],reference.u_k07.mem[13],reference.u_k07.mem[12],reference.u_k07.mem[11],reference.u_k07.mem[10],reference.u_k07.mem[9],reference.u_k07.mem[8],reference.u_k07.mem[7],reference.u_k07.mem[6],reference.u_k07.mem[5],reference.u_k07.mem[4],reference.u_k07.mem[3],reference.u_k07.mem[2],reference.u_k07.mem[1],reference.u_k07.mem[0]};
assign reference_state[2007+:1]=reference.u_k07.we_d;
assign reference_state[2008+:1]=reference.u_k08.ck_d;
assign reference_state[2009+:6]=reference.u_k08.d_pre;
assign reference_state[2015+:6]=reference.u_k08.q;
assign reference_state[2021+:1]=reference.u_k09.ck_d;
assign reference_state[2022+:6]=reference.u_k09.d_pre;
assign reference_state[2028+:6]=reference.u_k09.q;
assign reference_state[2034+:4]=reference.u_k12.q;
assign reference_state[2038+:1]=reference.u_k13.ck_d;
assign reference_state[2039+:4]=reference.u_k13.jk_pre;
assign reference_state[2043+:1]=reference.u_k13.qa;
assign reference_state[2044+:1]=reference.u_k13.qb;
assign reference_state[2045+:1]=reference.u_k21.ck_d;
assign reference_state[2046+:6]=reference.u_k21.d_pre;
assign reference_state[2052+:6]=reference.u_k21.q;
assign reference_state[2058+:1]=reference.u_k24.ck_d;
assign reference_state[2059+:6]=reference.u_k24.d_pre;
assign reference_state[2065+:6]=reference.u_k24.q;
assign reference_state[2071+:1]=reference.u_l02.cka_d;
assign reference_state[2072+:1]=reference.u_l02.ckb_d;
assign reference_state[2073+:1]=reference.u_l02.d_pre_a;
assign reference_state[2074+:1]=reference.u_l02.d_pre_b;
assign reference_state[2075+:1]=reference.u_l02.qa;
assign reference_state[2076+:1]=reference.u_l02.qb;
assign reference_state[2077+:1]=reference.u_l03.ck_d;
assign reference_state[2078+:4]=reference.u_l03.q;
assign reference_state[2082+:6]=reference.u_l03.setup_pre;
assign reference_state[2088+:4]=reference.u_l04.a_lat;
assign reference_state[2092+:1]=reference.u_l04.ce_lat;
assign reference_state[2093+:4]=reference.u_l04.d_lat;
assign reference_state[2097+:64]={reference.u_l04.mem[15],reference.u_l04.mem[14],reference.u_l04.mem[13],reference.u_l04.mem[12],reference.u_l04.mem[11],reference.u_l04.mem[10],reference.u_l04.mem[9],reference.u_l04.mem[8],reference.u_l04.mem[7],reference.u_l04.mem[6],reference.u_l04.mem[5],reference.u_l04.mem[4],reference.u_l04.mem[3],reference.u_l04.mem[2],reference.u_l04.mem[1],reference.u_l04.mem[0]};
assign reference_state[2161+:1]=reference.u_l04.we_d;
assign reference_state[2162+:1]=reference.u_l07.ck_d;
assign reference_state[2163+:6]=reference.u_l07.d_pre;
assign reference_state[2169+:6]=reference.u_l07.q;
assign reference_state[2175+:1]=reference.u_l09.ck_d;
assign reference_state[2176+:6]=reference.u_l09.d_pre;
assign reference_state[2182+:6]=reference.u_l09.q;
assign reference_state[2188+:1]=reference.u_l13.ck_d;
assign reference_state[2189+:6]=reference.u_l13.d_pre;
assign reference_state[2195+:6]=reference.u_l13.q;
assign reference_state[2201+:1]=reference.u_l24.ck_d;
assign reference_state[2202+:6]=reference.u_l24.d_pre;
assign reference_state[2208+:6]=reference.u_l24.q;
assign reference_probe[0+:4]=reference.u_a08.mem[0+(probe_index%256)];
assign reference_probe[4+:4]=reference.u_a10.mem[0+(probe_index%256)];
assign reference_probe[8+:4]=reference.u_a12.mem[0+(probe_index%256)];
assign reference_probe[12+:4]=reference.u_a18.mem[0+(probe_index%256)];
assign reference_probe[16+:4]=reference.u_a20.mem[0+(probe_index%256)];
assign reference_probe[20+:4]=reference.u_b08.mem[0+(probe_index%256)];
assign reference_probe[24+:4]=reference.u_b10.mem[0+(probe_index%256)];
assign reference_probe[28+:4]=reference.u_b12.mem[0+(probe_index%256)];
assign reference_probe[32+:4]=reference.u_b18.mem[0+(probe_index%256)];
assign reference_probe[36+:4]=reference.u_b20.mem[0+(probe_index%256)];
assign reference_probe[40+:4]=reference.u_c08.mem[0+(probe_index%256)];
assign reference_probe[44+:4]=reference.u_c10.mem[0+(probe_index%256)];
assign reference_probe[48+:4]=reference.u_c12.mem[0+(probe_index%256)];
assign reference_probe[52+:4]=reference.u_c18.mem[0+(probe_index%256)];
assign reference_probe[56+:4]=reference.u_c20.mem[0+(probe_index%256)];
assign reference_probe[60+:4]=reference.u_c22.mem[0+(probe_index%256)];
assign reference_probe[64+:4]=reference.u_d08.mem[0+(probe_index%256)];
assign reference_probe[68+:4]=reference.u_d10.mem[0+(probe_index%256)];
assign reference_probe[72+:4]=reference.u_d12.mem[0+(probe_index%256)];
assign reference_probe[76+:4]=reference.u_d18.mem[0+(probe_index%256)];
assign reference_probe[80+:4]=reference.u_d20.mem[0+(probe_index%256)];
wire dut_AfreeOrEc_p_b__drv;
wire dut_AwantsDifHit_p___drv;
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_CBHold__drv;
wire dut_CacheRef_p___drv;
wire dut_CacheRefInEc1__drv;
wire dut_DMuxData__drv;
wire dut_Dad_00__drv;
wire dut_Dad_01__drv;
wire dut_Dbuf_u__p___drv;
wire dut_DirtyIoFetchInA_p___drv;
wire dut_DisHold__drv;
wire dut_EcKeepsAbusy__drv;
wire dut_FastD_u_Dbuf__drv;
wire dut_Hita__drv;
wire dut_Hold__drv;
wire dut_IOHold__drv;
wire dut_IfuAck__drv;
wire dut_IfuHold__drv;
wire dut_IfuRefInEc1__drv;
wire dut_IoFetchInA_p___drv;
wire dut_IoStoreInA__drv;
wire dut_MXHold__drv;
wire dut_MakeF_u_D__drv;
wire dut_MapAd_0__drv;
wire dut_MapAd_1__drv;
wire dut_MapAd_2__drv;
wire dut_MapAd_3__drv;
wire dut_MapAd_4__drv;
wire dut_MapAd_5__drv;
wire dut_MapAd_6__drv;
wire dut_MapAd_7__drv;
wire dut_MapAd_8__drv;
wire dut_Map_u_InPair_p___drv;
wire dut_McrD_u__p___drv;
wire dut_Mcr_u__p___drv;
wire dut_MemAd_5__drv;
wire dut_MemAd_6__drv;
wire dut_MemAd_7__drv;
wire dut_MemAd_8__drv;
wire dut_PRhold__drv;
wire dut_PairFull_p___drv;
wire dut_PrivRefInPair__drv;
wire dut_ProcSrn_u__p___drv;
wire dut_ReadInA_p___drv;
wire dut_StartMap_p___drv;
wire dut_Store_u_InA_p___drv;
wire dut_Store_u_InEc1_p___drv;
wire dut_TagInEc1__drv;
wire dut_UseAsrn__drv;
wire dut_VicIfMiss_p___drv;
wire dut_VicInPair_p___drv;
wire dut_VicOrFS1C__drv;
wire dut__u_Config__drv;
wire dut__u_FaultInfo__drv;
wire dut__u_MDdly_p___drv;
wire dut__u_Pipe2__drv;
wire dut__u_Pipe3__drv;
wire dut__u_Pipe4__drv;
wire dut_dDad_02__drv;
wire dut_dDad_03__drv;
wire dut_dDad_04__drv;
wire dut_dDad_05__drv;
wire dut_dDad_06__drv;
wire dut_dDad_07__drv;
wire dut_dDad_08__drv;
wire dut_dDad_09__drv;
wire dut_dDad_10__drv;
wire dut_dDad_11__drv;
wire dut_dDad_12__drv;
wire dut_dDad_13__drv;
wire dut_dHitPerr__drv;
dorado_serial_MemC #(.SYSPER(4)) dut(
.sys_clk(clk),
.ASEL_0(stimulus[0]),
.ASEL_0_p_mem(stimulus[1]),
.ASEL_1_p_(stimulus[2]),
.ASEL_2_p_(stimulus[3]),
.AcanhaveMap_p_(stimulus[4]),
.AfreeOrEc_p_b(stimulus[5] | dut_AfreeOrEc_p_b__drv),
.At_eq_Curt_p_(stimulus[6]),
.AwantsDifHit_p_(stimulus[7] | dut_AwantsDifHit_p___drv),
.BMux_04(stimulus[8] | dut_BMux_04__drv),
.BMux_05(stimulus[9] | dut_BMux_05__drv),
.BMux_06(stimulus[10] | dut_BMux_06__drv),
.BMux_07(stimulus[11] | dut_BMux_07__drv),
.BMux_08(stimulus[12] | dut_BMux_08__drv),
.BMux_09(stimulus[13] | dut_BMux_09__drv),
.BMux_10(stimulus[14] | dut_BMux_10__drv),
.BMux_11(stimulus[15] | dut_BMux_11__drv),
.BMux_12(stimulus[16] | dut_BMux_12__drv),
.BMux_13(stimulus[17] | dut_BMux_13__drv),
.BMux_14(stimulus[18] | dut_BMux_14__drv),
.BMux_15(stimulus[19] | dut_BMux_15__drv),
.CHoldReq(stimulus[20]),
.CLK_mc_p_(stimulus[21]),
.CLKEnable_p_b(stimulus[22]),
.CacheRef_p_(stimulus[23] | dut_CacheRef_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | dut_DMuxData__drv),
.DdataGood_p_(stimulus[26]),
.DisHold(stimulus[27] | dut_DisHold__drv),
.EcDcomingForCt_p_(stimulus[28]),
.EcKeepsAbusy(stimulus[29] | dut_EcKeepsAbusy__drv),
.EcWantsA(stimulus[30]),
.EmuOrFT_p_(stimulus[31]),
.ExtHoldReq(stimulus[32]),
.FA_eq_1_p_(stimulus[33]),
.FF_0mem_p_(stimulus[34]),
.FF_1mem(stimulus[35]),
.FF_2(stimulus[36]),
.FF_3(stimulus[37]),
.FF_4(stimulus[38]),
.FF_5(stimulus[39]),
.FF_6(stimulus[40]),
.FF_7(stimulus[41]),
.FastD_u_Dbuf(stimulus[42] | dut_FastD_u_Dbuf__drv),
.Hita(stimulus[43] | dut_Hita__drv),
.Hold(stimulus[44] | dut_Hold__drv),
.HoldMapBuf(stimulus[45]),
.IfuData_0(stimulus[46]),
.IfuData_1(stimulus[47]),
.IfuData_2(stimulus[48]),
.IfuData_3(stimulus[49]),
.IfuData_4(stimulus[50]),
.IfuData_5(stimulus[51]),
.IfuData_6(stimulus[52]),
.IfuData_7(stimulus[53]),
.IoStoreInA(stimulus[54] | dut_IoStoreInA__drv),
.LdPipeVAdly_p_(stimulus[55]),
.MAR_00_p_(stimulus[56]),
.MAR_01_p_(stimulus[57]),
.MAR_02_p_(stimulus[58]),
.MAR_03_p_(stimulus[59]),
.MAR_04_p_(stimulus[60]),
.MAR_05_p_(stimulus[61]),
.MAR_06_p_(stimulus[62]),
.MAR_07_p_(stimulus[63]),
.MAR_08_p_(stimulus[64]),
.MAR_09_p_(stimulus[65]),
.MAR_10_p_(stimulus[66]),
.MAR_11_p_(stimulus[67]),
.MAR_12_p_(stimulus[68]),
.MAR_13_p_(stimulus[69]),
.MAR_14_p_(stimulus[70]),
.MAR_15_p_(stimulus[71]),
.MDMtag_p_(stimulus[72]),
.MXHold(stimulus[73] | dut_MXHold__drv),
.MakeD_u_CD(stimulus[74]),
.MakeD_u_Dbuf(stimulus[75]),
.MakeF_u_D(stimulus[76] | dut_MakeF_u_D__drv),
.MapAd_0(stimulus[77] | dut_MapAd_0__drv),
.MapAd_1(stimulus[78] | dut_MapAd_1__drv),
.MapAd_2(stimulus[79] | dut_MapAd_2__drv),
.MapAd_3(stimulus[80] | dut_MapAd_3__drv),
.MapAd_4(stimulus[81] | dut_MapAd_4__drv),
.MapAd_5(stimulus[82] | dut_MapAd_5__drv),
.MapAd_6(stimulus[83] | dut_MapAd_6__drv),
.MapAd_7(stimulus[84] | dut_MapAd_7__drv),
.MapAd_8(stimulus[85] | dut_MapAd_8__drv),
.MapRfsh_p_(stimulus[86]),
.MapTroubleInEc1(stimulus[87]),
.MapWait_m_D(stimulus[88]),
.Map_u_InPair_p_(stimulus[89] | dut_Map_u_InPair_p___drv),
.Mcr_u__p_(stimulus[90] | dut_Mcr_u__p___drv),
.MemBase_0(stimulus[91]),
.MemBase_1(stimulus[92]),
.MemBase_2(stimulus[93]),
.MemBase_3(stimulus[94]),
.MemBase_4(stimulus[95]),
.MemClkEnable_p_a(stimulus[96]),
.MemRfsh(stimulus[97]),
.MemSH(stimulus[98]),
.PairFull_p_(stimulus[99] | dut_PairFull_p___drv),
.PrHoldReq(stimulus[100]),
.PrivRefInPair(stimulus[101] | dut_PrivRefInPair__drv),
.ProcTag(stimulus[102]),
.ProcTagInA(stimulus[103]),
.RefOutstanding_p_(stimulus[104]),
.STfree_p_(stimulus[105]),
.StartMap_p_(stimulus[106] | dut_StartMap_p___drv),
.Store_u_InA_p_(stimulus[107] | dut_Store_u_InA_p___drv),
.Transport_p_(stimulus[108]),
.UseAsrn(stimulus[109] | dut_UseAsrn__drv),
.VicIfMiss_p_(stimulus[110] | dut_VicIfMiss_p___drv),
.VicInPair_p_(stimulus[111] | dut_VicInPair_p___drv),
.VicOrFS1C(stimulus[112] | dut_VicOrFS1C__drv),
.WPinEc1(stimulus[113]),
.WantIfuRef_p_(stimulus[114]),
.XWantsPipe(stimulus[115]),
._u_MD(stimulus[116]),
._u_MDI(stimulus[117]),
._u_MDI_p_(stimulus[118]),
._u_MDdly_p_(stimulus[119] | dut__u_MDdly_p___drv),
.dPipe02Ad_0(stimulus[120]),
.dPipe02Ad_1(stimulus[121]),
.dPipe02Ad_2(stimulus[122]),
.dPipe02Ad_3(stimulus[123]),
.preMCSb(stimulus[124]),
.AfreeOrEc_p_b__drv(dut_AfreeOrEc_p_b__drv),
.AwantsDifHit_p___drv(dut_AwantsDifHit_p___drv),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.CBHold__drv(dut_CBHold__drv),
.CacheRef_p___drv(dut_CacheRef_p___drv),
.CacheRefInEc1__drv(dut_CacheRefInEc1__drv),
.DMuxData__drv(dut_DMuxData__drv),
.Dad_00__drv(dut_Dad_00__drv),
.Dad_01__drv(dut_Dad_01__drv),
.Dbuf_u__p___drv(dut_Dbuf_u__p___drv),
.DirtyIoFetchInA_p___drv(dut_DirtyIoFetchInA_p___drv),
.DisHold__drv(dut_DisHold__drv),
.EcKeepsAbusy__drv(dut_EcKeepsAbusy__drv),
.FastD_u_Dbuf__drv(dut_FastD_u_Dbuf__drv),
.Hita__drv(dut_Hita__drv),
.Hold__drv(dut_Hold__drv),
.IOHold__drv(dut_IOHold__drv),
.IfuAck__drv(dut_IfuAck__drv),
.IfuHold__drv(dut_IfuHold__drv),
.IfuRefInEc1__drv(dut_IfuRefInEc1__drv),
.IoFetchInA_p___drv(dut_IoFetchInA_p___drv),
.IoStoreInA__drv(dut_IoStoreInA__drv),
.MXHold__drv(dut_MXHold__drv),
.MakeF_u_D__drv(dut_MakeF_u_D__drv),
.MapAd_0__drv(dut_MapAd_0__drv),
.MapAd_1__drv(dut_MapAd_1__drv),
.MapAd_2__drv(dut_MapAd_2__drv),
.MapAd_3__drv(dut_MapAd_3__drv),
.MapAd_4__drv(dut_MapAd_4__drv),
.MapAd_5__drv(dut_MapAd_5__drv),
.MapAd_6__drv(dut_MapAd_6__drv),
.MapAd_7__drv(dut_MapAd_7__drv),
.MapAd_8__drv(dut_MapAd_8__drv),
.Map_u_InPair_p___drv(dut_Map_u_InPair_p___drv),
.McrD_u__p___drv(dut_McrD_u__p___drv),
.Mcr_u__p___drv(dut_Mcr_u__p___drv),
.MemAd_5__drv(dut_MemAd_5__drv),
.MemAd_6__drv(dut_MemAd_6__drv),
.MemAd_7__drv(dut_MemAd_7__drv),
.MemAd_8__drv(dut_MemAd_8__drv),
.PRhold__drv(dut_PRhold__drv),
.PairFull_p___drv(dut_PairFull_p___drv),
.PrivRefInPair__drv(dut_PrivRefInPair__drv),
.ProcSrn_u__p___drv(dut_ProcSrn_u__p___drv),
.ReadInA_p___drv(dut_ReadInA_p___drv),
.StartMap_p___drv(dut_StartMap_p___drv),
.Store_u_InA_p___drv(dut_Store_u_InA_p___drv),
.Store_u_InEc1_p___drv(dut_Store_u_InEc1_p___drv),
.TagInEc1__drv(dut_TagInEc1__drv),
.UseAsrn__drv(dut_UseAsrn__drv),
.VicIfMiss_p___drv(dut_VicIfMiss_p___drv),
.VicInPair_p___drv(dut_VicInPair_p___drv),
.VicOrFS1C__drv(dut_VicOrFS1C__drv),
._u_Config__drv(dut__u_Config__drv),
._u_FaultInfo__drv(dut__u_FaultInfo__drv),
._u_MDdly_p___drv(dut__u_MDdly_p___drv),
._u_Pipe2__drv(dut__u_Pipe2__drv),
._u_Pipe3__drv(dut__u_Pipe3__drv),
._u_Pipe4__drv(dut__u_Pipe4__drv),
.dDad_02__drv(dut_dDad_02__drv),
.dDad_03__drv(dut_dDad_03__drv),
.dDad_04__drv(dut_dDad_04__drv),
.dDad_05__drv(dut_dDad_05__drv),
.dDad_06__drv(dut_dDad_06__drv),
.dDad_07__drv(dut_dDad_07__drv),
.dDad_08__drv(dut_dDad_08__drv),
.dDad_09__drv(dut_dDad_09__drv),
.dDad_10__drv(dut_dDad_10__drv),
.dDad_11__drv(dut_dDad_11__drv),
.dDad_12__drv(dut_dDad_12__drv),
.dDad_13__drv(dut_dDad_13__drv),
.dHitPerr__drv(dut_dHitPerr__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_dHitPerr__drv,dut_dDad_13__drv,dut_dDad_12__drv,dut_dDad_11__drv,dut_dDad_10__drv,dut_dDad_09__drv,dut_dDad_08__drv,dut_dDad_07__drv,dut_dDad_06__drv,dut_dDad_05__drv,dut_dDad_04__drv,dut_dDad_03__drv,dut_dDad_02__drv,dut__u_Pipe4__drv,dut__u_Pipe3__drv,dut__u_Pipe2__drv,dut__u_MDdly_p___drv,dut__u_FaultInfo__drv,dut__u_Config__drv,dut_VicOrFS1C__drv,dut_VicInPair_p___drv,dut_VicIfMiss_p___drv,dut_UseAsrn__drv,dut_TagInEc1__drv,dut_Store_u_InEc1_p___drv,dut_Store_u_InA_p___drv,dut_StartMap_p___drv,dut_ReadInA_p___drv,dut_ProcSrn_u__p___drv,dut_PrivRefInPair__drv,dut_PairFull_p___drv,dut_PRhold__drv,dut_MemAd_8__drv,dut_MemAd_7__drv,dut_MemAd_6__drv,dut_MemAd_5__drv,dut_Mcr_u__p___drv,dut_McrD_u__p___drv,dut_Map_u_InPair_p___drv,dut_MapAd_8__drv,dut_MapAd_7__drv,dut_MapAd_6__drv,dut_MapAd_5__drv,dut_MapAd_4__drv,dut_MapAd_3__drv,dut_MapAd_2__drv,dut_MapAd_1__drv,dut_MapAd_0__drv,dut_MakeF_u_D__drv,dut_MXHold__drv,dut_IoStoreInA__drv,dut_IoFetchInA_p___drv,dut_IfuRefInEc1__drv,dut_IfuHold__drv,dut_IfuAck__drv,dut_IOHold__drv,dut_Hold__drv,dut_Hita__drv,dut_FastD_u_Dbuf__drv,dut_EcKeepsAbusy__drv,dut_DisHold__drv,dut_DirtyIoFetchInA_p___drv,dut_Dbuf_u__p___drv,dut_Dad_01__drv,dut_Dad_00__drv,dut_DMuxData__drv,dut_CacheRefInEc1__drv,dut_CacheRef_p___drv,dut_CBHold__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv,dut_AwantsDifHit_p___drv,dut_AfreeOrEc_p_b__drv};
assign dut_state[0+:1]=dut.clk1B;
assign dut_state[1+:1]=dut.clk1_p_B;
assign dut_state[2+:1]=dut.clk1_p_Da;
assign dut_state[3+:1]=dut.clk1_p_Db;
assign dut_state[4+:1]=dut.clk1_p_Dc;
assign dut_state[5+:4]=dut.u__h_1c42.q;
assign dut_state[9+:4]=dut.u__h_1c43.q;
assign dut_state[13+:4]=dut.u__h_1f42.q;
assign dut_state[17+:4]=dut.u__h_1i42.q;
assign dut_state[21+:4]=dut.u__h_5b42.q;
assign dut_state[25+:4]=dut.u__h_5b43.q;
assign dut_state[29+:4]=dut.u__h_5e42.q;
assign dut_state[33+:4]=dut.u__h_5h42.q;
assign dut_state[37+:1]=dut.u_a14.cka_d;
assign dut_state[38+:1]=dut.u_a14.ckb_d;
assign dut_state[39+:1]=dut.u_a14.qa;
assign dut_state[40+:1]=dut.u_a14.qb;
assign dut_state[41+:1]=dut.u_a15.cka_d;
assign dut_state[42+:1]=dut.u_a15.ckb_d;
assign dut_state[43+:1]=dut.u_a15.qa;
assign dut_state[44+:1]=dut.u_a15.qb;
assign dut_state[45+:1]=dut.u_b03.ck_d;
assign dut_state[46+:6]=dut.u_b03.d_pre;
assign dut_state[52+:6]=dut.u_b03.q;
assign dut_state[58+:1]=dut.u_b05.ck_d;
assign dut_state[59+:6]=dut.u_b05.d_pre;
assign dut_state[65+:6]=dut.u_b05.q;
assign dut_state[71+:1]=dut.u_b14.cka_d;
assign dut_state[72+:1]=dut.u_b14.ckb_d;
assign dut_state[73+:1]=dut.u_b14.qa;
assign dut_state[74+:1]=dut.u_b14.qb;
assign dut_state[75+:1]=dut.u_b15.cka_d;
assign dut_state[76+:1]=dut.u_b15.ckb_d;
assign dut_state[77+:1]=dut.u_b15.qa;
assign dut_state[78+:1]=dut.u_b15.qb;
assign dut_state[79+:1]=dut.u_c14.cka_d;
assign dut_state[80+:1]=dut.u_c14.ckb_d;
assign dut_state[81+:1]=dut.u_c14.qa;
assign dut_state[82+:1]=dut.u_c14.qb;
assign dut_state[83+:1]=dut.u_c15.cka_d;
assign dut_state[84+:1]=dut.u_c15.ckb_d;
assign dut_state[85+:1]=dut.u_c15.qa;
assign dut_state[86+:1]=dut.u_c15.qb;
assign dut_state[87+:1]=dut.u_c17.cka_d;
assign dut_state[88+:1]=dut.u_c17.ckb_d;
assign dut_state[89+:1]=dut.u_c17.d_pre_a;
assign dut_state[90+:1]=dut.u_c17.d_pre_b;
assign dut_state[91+:1]=dut.u_c17.qa;
assign dut_state[92+:1]=dut.u_c17.qb;
assign dut_state[93+:1]=dut.u_d02.ck_d;
assign dut_state[94+:6]=dut.u_d02.d_pre;
assign dut_state[100+:6]=dut.u_d02.q;
assign dut_state[106+:4]=dut.u_d05.q;
assign dut_state[110+:4]=dut.u_d06.a_lat;
assign dut_state[114+:1]=dut.u_d06.ce_lat;
assign dut_state[115+:4]=dut.u_d06.d_lat;
assign dut_state[119+:64]={dut.u_d06.mem[15],dut.u_d06.mem[14],dut.u_d06.mem[13],dut.u_d06.mem[12],dut.u_d06.mem[11],dut.u_d06.mem[10],dut.u_d06.mem[9],dut.u_d06.mem[8],dut.u_d06.mem[7],dut.u_d06.mem[6],dut.u_d06.mem[5],dut.u_d06.mem[4],dut.u_d06.mem[3],dut.u_d06.mem[2],dut.u_d06.mem[1],dut.u_d06.mem[0]};
assign dut_state[183+:1]=dut.u_d06.we_d;
assign dut_state[184+:4]=dut.u_d07.a_lat;
assign dut_state[188+:1]=dut.u_d07.ce_lat;
assign dut_state[189+:4]=dut.u_d07.d_lat;
assign dut_state[193+:64]={dut.u_d07.mem[15],dut.u_d07.mem[14],dut.u_d07.mem[13],dut.u_d07.mem[12],dut.u_d07.mem[11],dut.u_d07.mem[10],dut.u_d07.mem[9],dut.u_d07.mem[8],dut.u_d07.mem[7],dut.u_d07.mem[6],dut.u_d07.mem[5],dut.u_d07.mem[4],dut.u_d07.mem[3],dut.u_d07.mem[2],dut.u_d07.mem[1],dut.u_d07.mem[0]};
assign dut_state[257+:1]=dut.u_d07.we_d;
assign dut_state[258+:1]=dut.u_d14.cka_d;
assign dut_state[259+:1]=dut.u_d14.ckb_d;
assign dut_state[260+:1]=dut.u_d14.qa;
assign dut_state[261+:1]=dut.u_d14.qb;
assign dut_state[262+:1]=dut.u_d15.cka_d;
assign dut_state[263+:1]=dut.u_d15.ckb_d;
assign dut_state[264+:1]=dut.u_d15.qa;
assign dut_state[265+:1]=dut.u_d15.qb;
assign dut_state[266+:1]=dut.u_d17.cka_d;
assign dut_state[267+:1]=dut.u_d17.ckb_d;
assign dut_state[268+:1]=dut.u_d17.d_pre_a;
assign dut_state[269+:1]=dut.u_d17.d_pre_b;
assign dut_state[270+:1]=dut.u_d17.qa;
assign dut_state[271+:1]=dut.u_d17.qb;
assign dut_state[272+:1]=dut.u_e03.ck_d;
assign dut_state[273+:6]=dut.u_e03.d_pre;
assign dut_state[279+:6]=dut.u_e03.q;
assign dut_state[285+:4]=dut.u_e05.q;
assign dut_state[289+:4]=dut.u_e06.a_lat;
assign dut_state[293+:1]=dut.u_e06.ce_lat;
assign dut_state[294+:4]=dut.u_e06.d_lat;
assign dut_state[298+:64]={dut.u_e06.mem[15],dut.u_e06.mem[14],dut.u_e06.mem[13],dut.u_e06.mem[12],dut.u_e06.mem[11],dut.u_e06.mem[10],dut.u_e06.mem[9],dut.u_e06.mem[8],dut.u_e06.mem[7],dut.u_e06.mem[6],dut.u_e06.mem[5],dut.u_e06.mem[4],dut.u_e06.mem[3],dut.u_e06.mem[2],dut.u_e06.mem[1],dut.u_e06.mem[0]};
assign dut_state[362+:1]=dut.u_e06.we_d;
assign dut_state[363+:4]=dut.u_e07.a_lat;
assign dut_state[367+:1]=dut.u_e07.ce_lat;
assign dut_state[368+:4]=dut.u_e07.d_lat;
assign dut_state[372+:64]={dut.u_e07.mem[15],dut.u_e07.mem[14],dut.u_e07.mem[13],dut.u_e07.mem[12],dut.u_e07.mem[11],dut.u_e07.mem[10],dut.u_e07.mem[9],dut.u_e07.mem[8],dut.u_e07.mem[7],dut.u_e07.mem[6],dut.u_e07.mem[5],dut.u_e07.mem[4],dut.u_e07.mem[3],dut.u_e07.mem[2],dut.u_e07.mem[1],dut.u_e07.mem[0]};
assign dut_state[436+:1]=dut.u_e07.we_d;
assign dut_state[437+:1]=dut.u_e14.cka_d;
assign dut_state[438+:1]=dut.u_e14.ckb_d;
assign dut_state[439+:1]=dut.u_e14.d_pre_a;
assign dut_state[440+:1]=dut.u_e14.d_pre_b;
assign dut_state[441+:1]=dut.u_e14.qa;
assign dut_state[442+:1]=dut.u_e14.qb;
assign dut_state[443+:1]=dut.u_e22.cka_d;
assign dut_state[444+:1]=dut.u_e22.ckb_d;
assign dut_state[445+:1]=dut.u_e22.d_pre_a;
assign dut_state[446+:1]=dut.u_e22.d_pre_b;
assign dut_state[447+:1]=dut.u_e22.qa;
assign dut_state[448+:1]=dut.u_e22.qb;
assign dut_state[449+:1]=dut.u_e23.cka_d;
assign dut_state[450+:1]=dut.u_e23.ckb_d;
assign dut_state[451+:1]=dut.u_e23.d_pre_a;
assign dut_state[452+:1]=dut.u_e23.d_pre_b;
assign dut_state[453+:1]=dut.u_e23.qa;
assign dut_state[454+:1]=dut.u_e23.qb;
assign dut_state[455+:5]=dut.u_f05.q;
assign dut_state[460+:4]=dut.u_f06.a_lat;
assign dut_state[464+:1]=dut.u_f06.ce_lat;
assign dut_state[465+:4]=dut.u_f06.d_lat;
assign dut_state[469+:64]={dut.u_f06.mem[15],dut.u_f06.mem[14],dut.u_f06.mem[13],dut.u_f06.mem[12],dut.u_f06.mem[11],dut.u_f06.mem[10],dut.u_f06.mem[9],dut.u_f06.mem[8],dut.u_f06.mem[7],dut.u_f06.mem[6],dut.u_f06.mem[5],dut.u_f06.mem[4],dut.u_f06.mem[3],dut.u_f06.mem[2],dut.u_f06.mem[1],dut.u_f06.mem[0]};
assign dut_state[533+:1]=dut.u_f06.we_d;
assign dut_state[534+:4]=dut.u_f07.a_lat;
assign dut_state[538+:1]=dut.u_f07.ce_lat;
assign dut_state[539+:4]=dut.u_f07.d_lat;
assign dut_state[543+:64]={dut.u_f07.mem[15],dut.u_f07.mem[14],dut.u_f07.mem[13],dut.u_f07.mem[12],dut.u_f07.mem[11],dut.u_f07.mem[10],dut.u_f07.mem[9],dut.u_f07.mem[8],dut.u_f07.mem[7],dut.u_f07.mem[6],dut.u_f07.mem[5],dut.u_f07.mem[4],dut.u_f07.mem[3],dut.u_f07.mem[2],dut.u_f07.mem[1],dut.u_f07.mem[0]};
assign dut_state[607+:1]=dut.u_f07.we_d;
assign dut_state[608+:1]=dut.u_f08.ck_d;
assign dut_state[609+:6]=dut.u_f08.d_pre;
assign dut_state[615+:6]=dut.u_f08.q;
assign dut_state[621+:4]=dut.u_g02.a_lat;
assign dut_state[625+:1]=dut.u_g02.ce_lat;
assign dut_state[626+:4]=dut.u_g02.d_lat;
assign dut_state[630+:64]={dut.u_g02.mem[15],dut.u_g02.mem[14],dut.u_g02.mem[13],dut.u_g02.mem[12],dut.u_g02.mem[11],dut.u_g02.mem[10],dut.u_g02.mem[9],dut.u_g02.mem[8],dut.u_g02.mem[7],dut.u_g02.mem[6],dut.u_g02.mem[5],dut.u_g02.mem[4],dut.u_g02.mem[3],dut.u_g02.mem[2],dut.u_g02.mem[1],dut.u_g02.mem[0]};
assign dut_state[694+:1]=dut.u_g02.we_d;
assign dut_state[695+:4]=dut.u_g03.a_lat;
assign dut_state[699+:1]=dut.u_g03.ce_lat;
assign dut_state[700+:4]=dut.u_g03.d_lat;
assign dut_state[704+:64]={dut.u_g03.mem[15],dut.u_g03.mem[14],dut.u_g03.mem[13],dut.u_g03.mem[12],dut.u_g03.mem[11],dut.u_g03.mem[10],dut.u_g03.mem[9],dut.u_g03.mem[8],dut.u_g03.mem[7],dut.u_g03.mem[6],dut.u_g03.mem[5],dut.u_g03.mem[4],dut.u_g03.mem[3],dut.u_g03.mem[2],dut.u_g03.mem[1],dut.u_g03.mem[0]};
assign dut_state[768+:1]=dut.u_g03.we_d;
assign dut_state[769+:1]=dut.u_g09.ck_d;
assign dut_state[770+:6]=dut.u_g09.d_pre;
assign dut_state[776+:6]=dut.u_g09.q;
assign dut_state[782+:1]=dut.u_g14.cka_d;
assign dut_state[783+:1]=dut.u_g14.ckb_d;
assign dut_state[784+:1]=dut.u_g14.d_pre_a;
assign dut_state[785+:1]=dut.u_g14.d_pre_b;
assign dut_state[786+:1]=dut.u_g14.qa;
assign dut_state[787+:1]=dut.u_g14.qb;
assign dut_state[788+:1]=dut.u_g17.cka_d;
assign dut_state[789+:1]=dut.u_g17.ckb_d;
assign dut_state[790+:1]=dut.u_g17.d_pre_a;
assign dut_state[791+:1]=dut.u_g17.d_pre_b;
assign dut_state[792+:1]=dut.u_g17.qa;
assign dut_state[793+:1]=dut.u_g17.qb;
assign dut_state[794+:4]=dut.u_g22.q;
assign dut_state[798+:4]=dut.u_g24.q;
assign dut_state[802+:4]=dut.u_h02.a_lat;
assign dut_state[806+:1]=dut.u_h02.ce_lat;
assign dut_state[807+:4]=dut.u_h02.d_lat;
assign dut_state[811+:64]={dut.u_h02.mem[15],dut.u_h02.mem[14],dut.u_h02.mem[13],dut.u_h02.mem[12],dut.u_h02.mem[11],dut.u_h02.mem[10],dut.u_h02.mem[9],dut.u_h02.mem[8],dut.u_h02.mem[7],dut.u_h02.mem[6],dut.u_h02.mem[5],dut.u_h02.mem[4],dut.u_h02.mem[3],dut.u_h02.mem[2],dut.u_h02.mem[1],dut.u_h02.mem[0]};
assign dut_state[875+:1]=dut.u_h02.we_d;
assign dut_state[876+:4]=dut.u_h03.a_lat;
assign dut_state[880+:1]=dut.u_h03.ce_lat;
assign dut_state[881+:4]=dut.u_h03.d_lat;
assign dut_state[885+:64]={dut.u_h03.mem[15],dut.u_h03.mem[14],dut.u_h03.mem[13],dut.u_h03.mem[12],dut.u_h03.mem[11],dut.u_h03.mem[10],dut.u_h03.mem[9],dut.u_h03.mem[8],dut.u_h03.mem[7],dut.u_h03.mem[6],dut.u_h03.mem[5],dut.u_h03.mem[4],dut.u_h03.mem[3],dut.u_h03.mem[2],dut.u_h03.mem[1],dut.u_h03.mem[0]};
assign dut_state[949+:1]=dut.u_h03.we_d;
assign dut_state[950+:5]=dut.u_h05.q;
assign dut_state[955+:4]=dut.u_h06.a_lat;
assign dut_state[959+:1]=dut.u_h06.ce_lat;
assign dut_state[960+:4]=dut.u_h06.d_lat;
assign dut_state[964+:64]={dut.u_h06.mem[15],dut.u_h06.mem[14],dut.u_h06.mem[13],dut.u_h06.mem[12],dut.u_h06.mem[11],dut.u_h06.mem[10],dut.u_h06.mem[9],dut.u_h06.mem[8],dut.u_h06.mem[7],dut.u_h06.mem[6],dut.u_h06.mem[5],dut.u_h06.mem[4],dut.u_h06.mem[3],dut.u_h06.mem[2],dut.u_h06.mem[1],dut.u_h06.mem[0]};
assign dut_state[1028+:1]=dut.u_h06.we_d;
assign dut_state[1029+:4]=dut.u_h07.a_lat;
assign dut_state[1033+:1]=dut.u_h07.ce_lat;
assign dut_state[1034+:4]=dut.u_h07.d_lat;
assign dut_state[1038+:64]={dut.u_h07.mem[15],dut.u_h07.mem[14],dut.u_h07.mem[13],dut.u_h07.mem[12],dut.u_h07.mem[11],dut.u_h07.mem[10],dut.u_h07.mem[9],dut.u_h07.mem[8],dut.u_h07.mem[7],dut.u_h07.mem[6],dut.u_h07.mem[5],dut.u_h07.mem[4],dut.u_h07.mem[3],dut.u_h07.mem[2],dut.u_h07.mem[1],dut.u_h07.mem[0]};
assign dut_state[1102+:1]=dut.u_h07.we_d;
assign dut_state[1103+:1]=dut.u_h22.ck_d;
assign dut_state[1104+:6]=dut.u_h22.d_pre;
assign dut_state[1110+:6]=dut.u_h22.q;
assign dut_state[1116+:4]=dut.u_h24.q;
assign dut_state[1120+:4]=dut.u_i02.a_lat;
assign dut_state[1124+:1]=dut.u_i02.ce_lat;
assign dut_state[1125+:4]=dut.u_i02.d_lat;
assign dut_state[1129+:64]={dut.u_i02.mem[15],dut.u_i02.mem[14],dut.u_i02.mem[13],dut.u_i02.mem[12],dut.u_i02.mem[11],dut.u_i02.mem[10],dut.u_i02.mem[9],dut.u_i02.mem[8],dut.u_i02.mem[7],dut.u_i02.mem[6],dut.u_i02.mem[5],dut.u_i02.mem[4],dut.u_i02.mem[3],dut.u_i02.mem[2],dut.u_i02.mem[1],dut.u_i02.mem[0]};
assign dut_state[1193+:1]=dut.u_i02.we_d;
assign dut_state[1194+:4]=dut.u_i03.a_lat;
assign dut_state[1198+:1]=dut.u_i03.ce_lat;
assign dut_state[1199+:4]=dut.u_i03.d_lat;
assign dut_state[1203+:64]={dut.u_i03.mem[15],dut.u_i03.mem[14],dut.u_i03.mem[13],dut.u_i03.mem[12],dut.u_i03.mem[11],dut.u_i03.mem[10],dut.u_i03.mem[9],dut.u_i03.mem[8],dut.u_i03.mem[7],dut.u_i03.mem[6],dut.u_i03.mem[5],dut.u_i03.mem[4],dut.u_i03.mem[3],dut.u_i03.mem[2],dut.u_i03.mem[1],dut.u_i03.mem[0]};
assign dut_state[1267+:1]=dut.u_i03.we_d;
assign dut_state[1268+:5]=dut.u_i05.q;
assign dut_state[1273+:4]=dut.u_i06.a_lat;
assign dut_state[1277+:1]=dut.u_i06.ce_lat;
assign dut_state[1278+:4]=dut.u_i06.d_lat;
assign dut_state[1282+:64]={dut.u_i06.mem[15],dut.u_i06.mem[14],dut.u_i06.mem[13],dut.u_i06.mem[12],dut.u_i06.mem[11],dut.u_i06.mem[10],dut.u_i06.mem[9],dut.u_i06.mem[8],dut.u_i06.mem[7],dut.u_i06.mem[6],dut.u_i06.mem[5],dut.u_i06.mem[4],dut.u_i06.mem[3],dut.u_i06.mem[2],dut.u_i06.mem[1],dut.u_i06.mem[0]};
assign dut_state[1346+:1]=dut.u_i06.we_d;
assign dut_state[1347+:4]=dut.u_i07.a_lat;
assign dut_state[1351+:1]=dut.u_i07.ce_lat;
assign dut_state[1352+:4]=dut.u_i07.d_lat;
assign dut_state[1356+:64]={dut.u_i07.mem[15],dut.u_i07.mem[14],dut.u_i07.mem[13],dut.u_i07.mem[12],dut.u_i07.mem[11],dut.u_i07.mem[10],dut.u_i07.mem[9],dut.u_i07.mem[8],dut.u_i07.mem[7],dut.u_i07.mem[6],dut.u_i07.mem[5],dut.u_i07.mem[4],dut.u_i07.mem[3],dut.u_i07.mem[2],dut.u_i07.mem[1],dut.u_i07.mem[0]};
assign dut_state[1420+:1]=dut.u_i07.we_d;
assign dut_state[1421+:1]=dut.u_i10.ck_d;
assign dut_state[1422+:4]=dut.u_i10.d_pre;
assign dut_state[1426+:1]=dut.u_i10.dl_pre;
assign dut_state[1427+:1]=dut.u_i10.dr_pre;
assign dut_state[1428+:4]=dut.u_i10.q;
assign dut_state[1432+:2]=dut.u_i10.s_pre;
assign dut_state[1434+:4]=dut.u_i14.a_lat;
assign dut_state[1438+:1]=dut.u_i14.ce_lat;
assign dut_state[1439+:4]=dut.u_i14.d_lat;
assign dut_state[1443+:64]={dut.u_i14.mem[15],dut.u_i14.mem[14],dut.u_i14.mem[13],dut.u_i14.mem[12],dut.u_i14.mem[11],dut.u_i14.mem[10],dut.u_i14.mem[9],dut.u_i14.mem[8],dut.u_i14.mem[7],dut.u_i14.mem[6],dut.u_i14.mem[5],dut.u_i14.mem[4],dut.u_i14.mem[3],dut.u_i14.mem[2],dut.u_i14.mem[1],dut.u_i14.mem[0]};
assign dut_state[1507+:1]=dut.u_i14.we_d;
assign dut_state[1508+:1]=dut.u_i15.ck_d;
assign dut_state[1509+:6]=dut.u_i15.d_pre;
assign dut_state[1515+:6]=dut.u_i15.q;
assign dut_state[1521+:1]=dut.u_i20.ck_d;
assign dut_state[1522+:6]=dut.u_i20.d_pre;
assign dut_state[1528+:6]=dut.u_i20.q;
assign dut_state[1534+:1]=dut.u_i21.ck_d;
assign dut_state[1535+:6]=dut.u_i21.d_pre;
assign dut_state[1541+:6]=dut.u_i21.q;
assign dut_state[1547+:4]=dut.u_i23.q;
assign dut_state[1551+:1]=dut.u_j02.ck_d;
assign dut_state[1552+:6]=dut.u_j02.d_pre;
assign dut_state[1558+:6]=dut.u_j02.q;
assign dut_state[1564+:1]=dut.u_j03.ck_d;
assign dut_state[1565+:6]=dut.u_j03.d_pre;
assign dut_state[1571+:6]=dut.u_j03.q;
assign dut_state[1577+:5]=dut.u_j05.q;
assign dut_state[1582+:4]=dut.u_j06.a_lat;
assign dut_state[1586+:1]=dut.u_j06.ce_lat;
assign dut_state[1587+:4]=dut.u_j06.d_lat;
assign dut_state[1591+:64]={dut.u_j06.mem[15],dut.u_j06.mem[14],dut.u_j06.mem[13],dut.u_j06.mem[12],dut.u_j06.mem[11],dut.u_j06.mem[10],dut.u_j06.mem[9],dut.u_j06.mem[8],dut.u_j06.mem[7],dut.u_j06.mem[6],dut.u_j06.mem[5],dut.u_j06.mem[4],dut.u_j06.mem[3],dut.u_j06.mem[2],dut.u_j06.mem[1],dut.u_j06.mem[0]};
assign dut_state[1655+:1]=dut.u_j06.we_d;
assign dut_state[1656+:4]=dut.u_j07.a_lat;
assign dut_state[1660+:1]=dut.u_j07.ce_lat;
assign dut_state[1661+:4]=dut.u_j07.d_lat;
assign dut_state[1665+:64]={dut.u_j07.mem[15],dut.u_j07.mem[14],dut.u_j07.mem[13],dut.u_j07.mem[12],dut.u_j07.mem[11],dut.u_j07.mem[10],dut.u_j07.mem[9],dut.u_j07.mem[8],dut.u_j07.mem[7],dut.u_j07.mem[6],dut.u_j07.mem[5],dut.u_j07.mem[4],dut.u_j07.mem[3],dut.u_j07.mem[2],dut.u_j07.mem[1],dut.u_j07.mem[0]};
assign dut_state[1729+:1]=dut.u_j07.we_d;
assign dut_state[1730+:1]=dut.u_j15.cka_d;
assign dut_state[1731+:1]=dut.u_j15.ckb_d;
assign dut_state[1732+:1]=dut.u_j15.d_pre_a;
assign dut_state[1733+:1]=dut.u_j15.d_pre_b;
assign dut_state[1734+:1]=dut.u_j15.qa;
assign dut_state[1735+:1]=dut.u_j15.qb;
assign dut_state[1736+:1]=dut.u_j21.ck_d;
assign dut_state[1737+:6]=dut.u_j21.d_pre;
assign dut_state[1743+:6]=dut.u_j21.q;
assign dut_state[1749+:1]=dut.u_k01.ck_d;
assign dut_state[1750+:4]=dut.u_k01.q;
assign dut_state[1754+:6]=dut.u_k01.setup_pre;
assign dut_state[1760+:1]=dut.u_k02.ck_d;
assign dut_state[1761+:4]=dut.u_k02.d_pre;
assign dut_state[1765+:1]=dut.u_k02.dl_pre;
assign dut_state[1766+:1]=dut.u_k02.dr_pre;
assign dut_state[1767+:4]=dut.u_k02.q;
assign dut_state[1771+:2]=dut.u_k02.s_pre;
assign dut_state[1773+:4]=dut.u_k03.a_lat;
assign dut_state[1777+:1]=dut.u_k03.ce_lat;
assign dut_state[1778+:4]=dut.u_k03.d_lat;
assign dut_state[1782+:64]={dut.u_k03.mem[15],dut.u_k03.mem[14],dut.u_k03.mem[13],dut.u_k03.mem[12],dut.u_k03.mem[11],dut.u_k03.mem[10],dut.u_k03.mem[9],dut.u_k03.mem[8],dut.u_k03.mem[7],dut.u_k03.mem[6],dut.u_k03.mem[5],dut.u_k03.mem[4],dut.u_k03.mem[3],dut.u_k03.mem[2],dut.u_k03.mem[1],dut.u_k03.mem[0]};
assign dut_state[1846+:1]=dut.u_k03.we_d;
assign dut_state[1847+:1]=dut.u_k04.ck_d;
assign dut_state[1848+:6]=dut.u_k04.d_pre;
assign dut_state[1854+:6]=dut.u_k04.q;
assign dut_state[1860+:4]=dut.u_k06.a_lat;
assign dut_state[1864+:1]=dut.u_k06.ce_lat;
assign dut_state[1865+:4]=dut.u_k06.d_lat;
assign dut_state[1869+:64]={dut.u_k06.mem[15],dut.u_k06.mem[14],dut.u_k06.mem[13],dut.u_k06.mem[12],dut.u_k06.mem[11],dut.u_k06.mem[10],dut.u_k06.mem[9],dut.u_k06.mem[8],dut.u_k06.mem[7],dut.u_k06.mem[6],dut.u_k06.mem[5],dut.u_k06.mem[4],dut.u_k06.mem[3],dut.u_k06.mem[2],dut.u_k06.mem[1],dut.u_k06.mem[0]};
assign dut_state[1933+:1]=dut.u_k06.we_d;
assign dut_state[1934+:4]=dut.u_k07.a_lat;
assign dut_state[1938+:1]=dut.u_k07.ce_lat;
assign dut_state[1939+:4]=dut.u_k07.d_lat;
assign dut_state[1943+:64]={dut.u_k07.mem[15],dut.u_k07.mem[14],dut.u_k07.mem[13],dut.u_k07.mem[12],dut.u_k07.mem[11],dut.u_k07.mem[10],dut.u_k07.mem[9],dut.u_k07.mem[8],dut.u_k07.mem[7],dut.u_k07.mem[6],dut.u_k07.mem[5],dut.u_k07.mem[4],dut.u_k07.mem[3],dut.u_k07.mem[2],dut.u_k07.mem[1],dut.u_k07.mem[0]};
assign dut_state[2007+:1]=dut.u_k07.we_d;
assign dut_state[2008+:1]=dut.u_k08.ck_d;
assign dut_state[2009+:6]=dut.u_k08.d_pre;
assign dut_state[2015+:6]=dut.u_k08.q;
assign dut_state[2021+:1]=dut.u_k09.ck_d;
assign dut_state[2022+:6]=dut.u_k09.d_pre;
assign dut_state[2028+:6]=dut.u_k09.q;
assign dut_state[2034+:4]=dut.u_k12.q;
assign dut_state[2038+:1]=dut.u_k13.ck_d;
assign dut_state[2039+:4]=dut.u_k13.jk_pre;
assign dut_state[2043+:1]=dut.u_k13.qa;
assign dut_state[2044+:1]=dut.u_k13.qb;
assign dut_state[2045+:1]=dut.u_k21.ck_d;
assign dut_state[2046+:6]=dut.u_k21.d_pre;
assign dut_state[2052+:6]=dut.u_k21.q;
assign dut_state[2058+:1]=dut.u_k24.ck_d;
assign dut_state[2059+:6]=dut.u_k24.d_pre;
assign dut_state[2065+:6]=dut.u_k24.q;
assign dut_state[2071+:1]=dut.u_l02.cka_d;
assign dut_state[2072+:1]=dut.u_l02.ckb_d;
assign dut_state[2073+:1]=dut.u_l02.d_pre_a;
assign dut_state[2074+:1]=dut.u_l02.d_pre_b;
assign dut_state[2075+:1]=dut.u_l02.qa;
assign dut_state[2076+:1]=dut.u_l02.qb;
assign dut_state[2077+:1]=dut.u_l03.ck_d;
assign dut_state[2078+:4]=dut.u_l03.q;
assign dut_state[2082+:6]=dut.u_l03.setup_pre;
assign dut_state[2088+:4]=dut.u_l04.a_lat;
assign dut_state[2092+:1]=dut.u_l04.ce_lat;
assign dut_state[2093+:4]=dut.u_l04.d_lat;
assign dut_state[2097+:64]={dut.u_l04.mem[15],dut.u_l04.mem[14],dut.u_l04.mem[13],dut.u_l04.mem[12],dut.u_l04.mem[11],dut.u_l04.mem[10],dut.u_l04.mem[9],dut.u_l04.mem[8],dut.u_l04.mem[7],dut.u_l04.mem[6],dut.u_l04.mem[5],dut.u_l04.mem[4],dut.u_l04.mem[3],dut.u_l04.mem[2],dut.u_l04.mem[1],dut.u_l04.mem[0]};
assign dut_state[2161+:1]=dut.u_l04.we_d;
assign dut_state[2162+:1]=dut.u_l07.ck_d;
assign dut_state[2163+:6]=dut.u_l07.d_pre;
assign dut_state[2169+:6]=dut.u_l07.q;
assign dut_state[2175+:1]=dut.u_l09.ck_d;
assign dut_state[2176+:6]=dut.u_l09.d_pre;
assign dut_state[2182+:6]=dut.u_l09.q;
assign dut_state[2188+:1]=dut.u_l13.ck_d;
assign dut_state[2189+:6]=dut.u_l13.d_pre;
assign dut_state[2195+:6]=dut.u_l13.q;
assign dut_state[2201+:1]=dut.u_l24.ck_d;
assign dut_state[2202+:6]=dut.u_l24.d_pre;
assign dut_state[2208+:6]=dut.u_l24.q;
assign dut_probe[0+:4]=dut.u_a08.mem[0+(probe_index%256)];
assign dut_probe[4+:4]=dut.u_a10.mem[0+(probe_index%256)];
assign dut_probe[8+:4]=dut.u_a12.mem[0+(probe_index%256)];
assign dut_probe[12+:4]=dut.u_a18.mem[0+(probe_index%256)];
assign dut_probe[16+:4]=dut.u_a20.mem[0+(probe_index%256)];
assign dut_probe[20+:4]=dut.u_b08.mem[0+(probe_index%256)];
assign dut_probe[24+:4]=dut.u_b10.mem[0+(probe_index%256)];
assign dut_probe[28+:4]=dut.u_b12.mem[0+(probe_index%256)];
assign dut_probe[32+:4]=dut.u_b18.mem[0+(probe_index%256)];
assign dut_probe[36+:4]=dut.u_b20.mem[0+(probe_index%256)];
assign dut_probe[40+:4]=dut.u_c08.mem[0+(probe_index%256)];
assign dut_probe[44+:4]=dut.u_c10.mem[0+(probe_index%256)];
assign dut_probe[48+:4]=dut.u_c12.mem[0+(probe_index%256)];
assign dut_probe[52+:4]=dut.u_c18.mem[0+(probe_index%256)];
assign dut_probe[56+:4]=dut.u_c20.mem[0+(probe_index%256)];
assign dut_probe[60+:4]=dut.u_c22.mem[0+(probe_index%256)];
assign dut_probe[64+:4]=dut.u_d08.mem[0+(probe_index%256)];
assign dut_probe[68+:4]=dut.u_d10.mem[0+(probe_index%256)];
assign dut_probe[72+:4]=dut.u_d12.mem[0+(probe_index%256)];
assign dut_probe[76+:4]=dut.u_d18.mem[0+(probe_index%256)];
assign dut_probe[80+:4]=dut.u_d20.mem[0+(probe_index%256)];
assign all_helpers_frozen=&{dut.state_frozen,dut.u_a08.state_frozen,dut.u_a10.state_frozen,dut.u_a12.state_frozen,dut.u_a18.state_frozen,dut.u_a20.state_frozen,dut.u_b08.state_frozen,dut.u_b10.state_frozen,dut.u_b12.state_frozen,dut.u_b18.state_frozen,dut.u_b20.state_frozen,dut.u_c08.state_frozen,dut.u_c10.state_frozen,dut.u_c12.state_frozen,dut.u_c18.state_frozen,dut.u_c20.state_frozen,dut.u_c22.state_frozen,dut.u_d06.state_frozen,dut.u_d07.state_frozen,dut.u_d08.state_frozen,dut.u_d10.state_frozen,dut.u_d12.state_frozen,dut.u_d18.state_frozen,dut.u_d20.state_frozen,dut.u_e06.state_frozen,dut.u_e07.state_frozen,dut.u_f06.state_frozen,dut.u_f07.state_frozen,dut.u_g02.state_frozen,dut.u_g03.state_frozen,dut.u_h02.state_frozen,dut.u_h03.state_frozen,dut.u_h06.state_frozen,dut.u_h07.state_frozen,dut.u_i02.state_frozen,dut.u_i03.state_frozen,dut.u_i06.state_frozen,dut.u_i07.state_frozen,dut.u_i14.state_frozen,dut.u_j06.state_frozen,dut.u_j07.state_frozen,dut.u_k03.state_frozen,dut.u_k06.state_frozen,dut.u_k07.state_frozen,dut.u_l04.state_frozen};
endmodule
