module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [145:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [95:0] reference_outputs,dut_outputs,
 output wire [972:0] reference_state,dut_state,
 output wire [17:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_BMux_17__drv;
wire reference_CkMdParity_p___drv;
wire reference_Cnt_eq_Zero_p___drv;
wire reference_DMuxData__drv;
wire reference_FF_eq_030__drv;
wire reference_IOB_08__drv;
wire reference_IOB_09__drv;
wire reference_IOB_10__drv;
wire reference_IOB_11__drv;
wire reference_IOB_12__drv;
wire reference_IOB_13__drv;
wire reference_IOB_14__drv;
wire reference_IOB_15__drv;
wire reference_IOB_17__drv;
wire reference_IOPE__drv;
wire reference_IOin_p___drv;
wire reference_IOout_p___drv;
wire reference_LScopeFH__drv;
wire reference_MAR_08_p___drv;
wire reference_MAR_09_p___drv;
wire reference_MAR_10_p___drv;
wire reference_MAR_11_p___drv;
wire reference_MAR_12_p___drv;
wire reference_MAR_13_p___drv;
wire reference_MAR_14_p___drv;
wire reference_MAR_15_p___drv;
wire reference_MdPE__drv;
wire reference_MemBase_2__drv;
wire reference_MemBase_3__drv;
wire reference_Pdata_15__drv;
wire reference_PrHoldReq__drv;
wire reference_PropCnt_p___drv;
wire reference_Q_08__drv;
wire reference_QBit_p___drv;
wire reference_RScopeClk0_p___drv;
wire reference_RamPE__drv;
wire reference_RbAdr_0__drv;
wire reference_RbAdr_1__drv;
wire reference_RbAdr_2__drv;
wire reference_RbAdr_3__drv;
wire reference_RbBypass__drv;
wire reference_RbBypass_p___drv;
wire reference_RmOdd_p___drv;
wire reference_SelectRm_p_a__drv;
wire reference_SelectStk_p_a__drv;
wire reference_ShA_08__drv;
wire reference_ShA_09__drv;
wire reference_ShA_10__drv;
wire reference_ShA_11__drv;
wire reference_ShA_12__drv;
wire reference_ShA_13__drv;
wire reference_ShA_14__drv;
wire reference_ShA_15__drv;
wire reference_Shc_08__drv;
wire reference_Shc_09__drv;
wire reference_Shc_10__drv;
wire reference_Shc_11__drv;
wire reference_Shc_12__drv;
wire reference_Shc_13__drv;
wire reference_Shc_14__drv;
wire reference_Shc_15__drv;
wire reference_ShcAlu_0__drv;
wire reference_ShcAlu_1__drv;
wire reference_ShcAlu_2__drv;
wire reference_ShcAlu_3__drv;
wire reference_StkAdr_0a__drv;
wire reference_StkAdr_1a__drv;
wire reference_StkAdr_2a__drv;
wire reference_StkAdr_3a__drv;
wire reference_StkAdr_4a__drv;
wire reference_StkAdr_5a__drv;
wire reference_StkAdr_6a__drv;
wire reference_StkAdr_7a__drv;
wire reference_StkError__drv;
wire reference__u_MD__drv;
wire reference__u_MDI__drv;
wire reference__u_MDI_p___drv;
wire reference_alu_08__drv;
wire reference_alu_15__drv;
wire reference_aluC0__drv;
wire reference_aluF0__drv;
wire reference_aluF1__drv;
wire reference_aluF2__drv;
wire reference_aluF3__drv;
wire reference_aluG1__drv;
wire reference_aluM__drv;
wire reference_aluOut_eq_0_p___drv;
wire reference_aluP1__drv;
ProcL_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ALUCarry(stimulus[0]),
.ALUF_0(stimulus[1]),
.ALUF_1(stimulus[2]),
.ALUF_2(stimulus[3]),
.ALUF_3(stimulus[4]),
.ASEL_0_p_(stimulus[5]),
.ASEL_1_p_(stimulus[6]),
.ASEL_2_p_(stimulus[7]),
.BMux_08(stimulus[8] | reference_BMux_08__drv),
.BMux_09(stimulus[9] | reference_BMux_09__drv),
.BMux_10(stimulus[10] | reference_BMux_10__drv),
.BMux_11(stimulus[11] | reference_BMux_11__drv),
.BMux_12(stimulus[12] | reference_BMux_12__drv),
.BMux_13(stimulus[13] | reference_BMux_13__drv),
.BMux_14(stimulus[14] | reference_BMux_14__drv),
.BMux_15(stimulus[15] | reference_BMux_15__drv),
.BMux_17(stimulus[16] | reference_BMux_17__drv),
.BNTGtCT_p_a(stimulus[17]),
.BSEL_0_p_(stimulus[18]),
.BSEL_1_p_(stimulus[19]),
.BSEL_2_p_(stimulus[20]),
.CLK_pl_p_(stimulus[21]),
.CLKEnable_p_b(stimulus[22]),
.CkMdParity_p_(stimulus[23] | reference_CkMdParity_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | reference_DMuxData__drv),
.FF_0(stimulus[26]),
.FF_1(stimulus[27]),
.FF_2(stimulus[28]),
.FF_3(stimulus[29]),
.FF_4(stimulus[30]),
.FF_5(stimulus[31]),
.FF_6(stimulus[32]),
.FF_7(stimulus[33]),
.FFok_p_b(stimulus[34]),
.Freeze(stimulus[35]),
.IOB_08(stimulus[36] | reference_IOB_08__drv),
.IOB_09(stimulus[37] | reference_IOB_09__drv),
.IOB_10(stimulus[38] | reference_IOB_10__drv),
.IOB_11(stimulus[39] | reference_IOB_11__drv),
.IOB_12(stimulus[40] | reference_IOB_12__drv),
.IOB_13(stimulus[41] | reference_IOB_13__drv),
.IOB_14(stimulus[42] | reference_IOB_14__drv),
.IOB_15(stimulus[43] | reference_IOB_15__drv),
.IOB_17(stimulus[44] | reference_IOB_17__drv),
.IOin_p_(stimulus[45] | reference_IOin_p___drv),
.IfuData_0(stimulus[46]),
.IfuData_1(stimulus[47]),
.IfuData_2(stimulus[48]),
.IfuData_3(stimulus[49]),
.IfuData_4(stimulus[50]),
.IfuData_5(stimulus[51]),
.IfuData_6(stimulus[52]),
.IfuData_7(stimulus[53]),
.IfuRBaseSel_p_(stimulus[54]),
.LC_0(stimulus[55]),
.LC_1(stimulus[56]),
.LC_2(stimulus[57]),
.MAR_08_p_(stimulus[58] | reference_MAR_08_p___drv),
.MAR_09_p_(stimulus[59] | reference_MAR_09_p___drv),
.MAR_10_p_(stimulus[60] | reference_MAR_10_p___drv),
.MAR_11_p_(stimulus[61] | reference_MAR_11_p___drv),
.MAR_12_p_(stimulus[62] | reference_MAR_12_p___drv),
.MAR_13_p_(stimulus[63] | reference_MAR_13_p___drv),
.MAR_14_p_(stimulus[64] | reference_MAR_14_p___drv),
.MAR_15_p_(stimulus[65] | reference_MAR_15_p___drv),
.Next_0(stimulus[66]),
.Next_1(stimulus[67]),
.Next_2(stimulus[68]),
.Next_3(stimulus[69]),
.NextMacro(stimulus[70]),
.PRhold(stimulus[71]),
.Pdata_15(stimulus[72] | reference_Pdata_15__drv),
.PrBlock_p_(stimulus[73]),
.Q_07(stimulus[74]),
.Q_08(stimulus[75] | reference_Q_08__drv),
.RSTK_0(stimulus[76]),
.RSTK_1(stimulus[77]),
.RSTK_2(stimulus[78]),
.RSTK_3(stimulus[79]),
.RbBypass(stimulus[80] | reference_RbBypass__drv),
.RbBypass_p_(stimulus[81] | reference_RbBypass_p___drv),
.RmOdd_p_(stimulus[82] | reference_RmOdd_p___drv),
.ShA_00(stimulus[83]),
.ShA_01(stimulus[84]),
.ShA_02(stimulus[85]),
.ShA_03(stimulus[86]),
.ShA_04(stimulus[87]),
.ShA_05(stimulus[88]),
.ShA_06(stimulus[89]),
.ShA_07(stimulus[90]),
.ShA_08(stimulus[91] | reference_ShA_08__drv),
.ShA_09(stimulus[92] | reference_ShA_09__drv),
.ShA_10(stimulus[93] | reference_ShA_10__drv),
.ShA_11(stimulus[94] | reference_ShA_11__drv),
.ShA_12(stimulus[95] | reference_ShA_12__drv),
.ShA_13(stimulus[96] | reference_ShA_13__drv),
.ShA_14(stimulus[97] | reference_ShA_14__drv),
.ShA_15(stimulus[98] | reference_ShA_15__drv),
.Shc_02(stimulus[99]),
.Shc_03(stimulus[100]),
.Shc_04b(stimulus[101]),
.Shc_05b(stimulus[102]),
.Shc_06b(stimulus[103]),
.Shc_07b(stimulus[104]),
.Shc_08(stimulus[105] | reference_Shc_08__drv),
.Shc_09(stimulus[106] | reference_Shc_09__drv),
.Shc_10(stimulus[107] | reference_Shc_10__drv),
.Shc_11(stimulus[108] | reference_Shc_11__drv),
.Shc_12(stimulus[109] | reference_Shc_12__drv),
.Shc_13(stimulus[110] | reference_Shc_13__drv),
.Shc_14(stimulus[111] | reference_Shc_14__drv),
.Shc_15(stimulus[112] | reference_Shc_15__drv),
.ShcAlu_0(stimulus[113] | reference_ShcAlu_0__drv),
.ShcAlu_1(stimulus[114] | reference_ShcAlu_1__drv),
.ShcAlu_2(stimulus[115] | reference_ShcAlu_2__drv),
.ShcAlu_3(stimulus[116] | reference_ShcAlu_3__drv),
.SimHoldDis(stimulus[117]),
.StartCycle_p_a(stimulus[118]),
.StkError(stimulus[119] | reference_StkError__drv),
.SubTask_0(stimulus[120]),
.SubTask_1(stimulus[121]),
.TempRef(stimulus[122]),
._u_MD(stimulus[123] | reference__u_MD__drv),
._u_MDI(stimulus[124] | reference__u_MDI__drv),
._u_MDI_p_(stimulus[125] | reference__u_MDI_p___drv),
.alu_07(stimulus[126]),
.alu_08(stimulus[127] | reference_alu_08__drv),
.alu_15(stimulus[128] | reference_alu_15__drv),
.aluC0(stimulus[129] | reference_aluC0__drv),
.aluCout(stimulus[130]),
.aluF0(stimulus[131] | reference_aluF0__drv),
.aluF1(stimulus[132] | reference_aluF1__drv),
.aluF2(stimulus[133] | reference_aluF2__drv),
.aluF3(stimulus[134] | reference_aluF3__drv),
.aluM(stimulus[135] | reference_aluM__drv),
.dMD_08(stimulus[136]),
.dMD_09(stimulus[137]),
.dMD_10(stimulus[138]),
.dMD_11(stimulus[139]),
.dMD_12(stimulus[140]),
.dMD_13(stimulus[141]),
.dMD_14(stimulus[142]),
.dMD_15(stimulus[143]),
.dMD_17(stimulus[144]),
.jcnt(stimulus[145]),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.BMux_17__drv(reference_BMux_17__drv),
.CkMdParity_p___drv(reference_CkMdParity_p___drv),
.Cnt_eq_Zero_p___drv(reference_Cnt_eq_Zero_p___drv),
.DMuxData__drv(reference_DMuxData__drv),
.FF_eq_030__drv(reference_FF_eq_030__drv),
.IOB_08__drv(reference_IOB_08__drv),
.IOB_09__drv(reference_IOB_09__drv),
.IOB_10__drv(reference_IOB_10__drv),
.IOB_11__drv(reference_IOB_11__drv),
.IOB_12__drv(reference_IOB_12__drv),
.IOB_13__drv(reference_IOB_13__drv),
.IOB_14__drv(reference_IOB_14__drv),
.IOB_15__drv(reference_IOB_15__drv),
.IOB_17__drv(reference_IOB_17__drv),
.IOPE__drv(reference_IOPE__drv),
.IOin_p___drv(reference_IOin_p___drv),
.IOout_p___drv(reference_IOout_p___drv),
.LScopeFH__drv(reference_LScopeFH__drv),
.MAR_08_p___drv(reference_MAR_08_p___drv),
.MAR_09_p___drv(reference_MAR_09_p___drv),
.MAR_10_p___drv(reference_MAR_10_p___drv),
.MAR_11_p___drv(reference_MAR_11_p___drv),
.MAR_12_p___drv(reference_MAR_12_p___drv),
.MAR_13_p___drv(reference_MAR_13_p___drv),
.MAR_14_p___drv(reference_MAR_14_p___drv),
.MAR_15_p___drv(reference_MAR_15_p___drv),
.MdPE__drv(reference_MdPE__drv),
.MemBase_2__drv(reference_MemBase_2__drv),
.MemBase_3__drv(reference_MemBase_3__drv),
.Pdata_15__drv(reference_Pdata_15__drv),
.PrHoldReq__drv(reference_PrHoldReq__drv),
.PropCnt_p___drv(reference_PropCnt_p___drv),
.Q_08__drv(reference_Q_08__drv),
.QBit_p___drv(reference_QBit_p___drv),
.RScopeClk0_p___drv(reference_RScopeClk0_p___drv),
.RamPE__drv(reference_RamPE__drv),
.RbAdr_0__drv(reference_RbAdr_0__drv),
.RbAdr_1__drv(reference_RbAdr_1__drv),
.RbAdr_2__drv(reference_RbAdr_2__drv),
.RbAdr_3__drv(reference_RbAdr_3__drv),
.RbBypass__drv(reference_RbBypass__drv),
.RbBypass_p___drv(reference_RbBypass_p___drv),
.RmOdd_p___drv(reference_RmOdd_p___drv),
.SelectRm_p_a__drv(reference_SelectRm_p_a__drv),
.SelectStk_p_a__drv(reference_SelectStk_p_a__drv),
.ShA_08__drv(reference_ShA_08__drv),
.ShA_09__drv(reference_ShA_09__drv),
.ShA_10__drv(reference_ShA_10__drv),
.ShA_11__drv(reference_ShA_11__drv),
.ShA_12__drv(reference_ShA_12__drv),
.ShA_13__drv(reference_ShA_13__drv),
.ShA_14__drv(reference_ShA_14__drv),
.ShA_15__drv(reference_ShA_15__drv),
.Shc_08__drv(reference_Shc_08__drv),
.Shc_09__drv(reference_Shc_09__drv),
.Shc_10__drv(reference_Shc_10__drv),
.Shc_11__drv(reference_Shc_11__drv),
.Shc_12__drv(reference_Shc_12__drv),
.Shc_13__drv(reference_Shc_13__drv),
.Shc_14__drv(reference_Shc_14__drv),
.Shc_15__drv(reference_Shc_15__drv),
.ShcAlu_0__drv(reference_ShcAlu_0__drv),
.ShcAlu_1__drv(reference_ShcAlu_1__drv),
.ShcAlu_2__drv(reference_ShcAlu_2__drv),
.ShcAlu_3__drv(reference_ShcAlu_3__drv),
.StkAdr_0a__drv(reference_StkAdr_0a__drv),
.StkAdr_1a__drv(reference_StkAdr_1a__drv),
.StkAdr_2a__drv(reference_StkAdr_2a__drv),
.StkAdr_3a__drv(reference_StkAdr_3a__drv),
.StkAdr_4a__drv(reference_StkAdr_4a__drv),
.StkAdr_5a__drv(reference_StkAdr_5a__drv),
.StkAdr_6a__drv(reference_StkAdr_6a__drv),
.StkAdr_7a__drv(reference_StkAdr_7a__drv),
.StkError__drv(reference_StkError__drv),
._u_MD__drv(reference__u_MD__drv),
._u_MDI__drv(reference__u_MDI__drv),
._u_MDI_p___drv(reference__u_MDI_p___drv),
.alu_08__drv(reference_alu_08__drv),
.alu_15__drv(reference_alu_15__drv),
.aluC0__drv(reference_aluC0__drv),
.aluF0__drv(reference_aluF0__drv),
.aluF1__drv(reference_aluF1__drv),
.aluF2__drv(reference_aluF2__drv),
.aluF3__drv(reference_aluF3__drv),
.aluG1__drv(reference_aluG1__drv),
.aluM__drv(reference_aluM__drv),
.aluOut_eq_0_p___drv(reference_aluOut_eq_0_p___drv),
.aluP1__drv(reference_aluP1__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_aluP1__drv,reference_aluOut_eq_0_p___drv,reference_aluM__drv,reference_aluG1__drv,reference_aluF3__drv,reference_aluF2__drv,reference_aluF1__drv,reference_aluF0__drv,reference_aluC0__drv,reference_alu_15__drv,reference_alu_08__drv,reference__u_MDI_p___drv,reference__u_MDI__drv,reference__u_MD__drv,reference_StkError__drv,reference_StkAdr_7a__drv,reference_StkAdr_6a__drv,reference_StkAdr_5a__drv,reference_StkAdr_4a__drv,reference_StkAdr_3a__drv,reference_StkAdr_2a__drv,reference_StkAdr_1a__drv,reference_StkAdr_0a__drv,reference_ShcAlu_3__drv,reference_ShcAlu_2__drv,reference_ShcAlu_1__drv,reference_ShcAlu_0__drv,reference_Shc_15__drv,reference_Shc_14__drv,reference_Shc_13__drv,reference_Shc_12__drv,reference_Shc_11__drv,reference_Shc_10__drv,reference_Shc_09__drv,reference_Shc_08__drv,reference_ShA_15__drv,reference_ShA_14__drv,reference_ShA_13__drv,reference_ShA_12__drv,reference_ShA_11__drv,reference_ShA_10__drv,reference_ShA_09__drv,reference_ShA_08__drv,reference_SelectStk_p_a__drv,reference_SelectRm_p_a__drv,reference_RmOdd_p___drv,reference_RbBypass_p___drv,reference_RbBypass__drv,reference_RbAdr_3__drv,reference_RbAdr_2__drv,reference_RbAdr_1__drv,reference_RbAdr_0__drv,reference_RamPE__drv,reference_RScopeClk0_p___drv,reference_QBit_p___drv,reference_Q_08__drv,reference_PropCnt_p___drv,reference_PrHoldReq__drv,reference_Pdata_15__drv,reference_MemBase_3__drv,reference_MemBase_2__drv,reference_MdPE__drv,reference_MAR_15_p___drv,reference_MAR_14_p___drv,reference_MAR_13_p___drv,reference_MAR_12_p___drv,reference_MAR_11_p___drv,reference_MAR_10_p___drv,reference_MAR_09_p___drv,reference_MAR_08_p___drv,reference_LScopeFH__drv,reference_IOout_p___drv,reference_IOin_p___drv,reference_IOPE__drv,reference_IOB_17__drv,reference_IOB_15__drv,reference_IOB_14__drv,reference_IOB_13__drv,reference_IOB_12__drv,reference_IOB_11__drv,reference_IOB_10__drv,reference_IOB_09__drv,reference_IOB_08__drv,reference_FF_eq_030__drv,reference_DMuxData__drv,reference_Cnt_eq_Zero_p___drv,reference_CkMdParity_p___drv,reference_BMux_17__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv};
assign reference_state[0+:1]=reference.Clock1Bd;
assign reference_state[1+:1]=reference.Clock1_p_Aa;
assign reference_state[2+:1]=reference.Clock1_p_Ac;
assign reference_state[3+:1]=reference.Clock1_p_Ba;
assign reference_state[4+:1]=reference.Clock1_p_Bb;
assign reference_state[5+:1]=reference.Clock1_p_Ca;
assign reference_state[6+:1]=reference.Clock1_p_Cb;
assign reference_state[7+:1]=reference.Clock1_p_Da;
assign reference_state[8+:1]=reference.Clock1_p_Db;
assign reference_state[9+:1]=reference.Clock1_p_Dc;
assign reference_state[10+:1]=reference.u_a03.ck_d;
assign reference_state[11+:4]=reference.u_a03.d_pre;
assign reference_state[15+:4]=reference.u_a03.q;
assign reference_state[19+:1]=reference.u_a04.ck_d;
assign reference_state[20+:4]=reference.u_a04.d_pre;
assign reference_state[24+:4]=reference.u_a04.q;
assign reference_state[28+:1]=reference.u_a10.cka_d;
assign reference_state[29+:1]=reference.u_a10.ckb_d;
assign reference_state[30+:1]=reference.u_a10.d_pre_a;
assign reference_state[31+:1]=reference.u_a10.d_pre_b;
assign reference_state[32+:1]=reference.u_a10.qa;
assign reference_state[33+:1]=reference.u_a10.qb;
assign reference_state[34+:1]=reference.u_a11.cka_d;
assign reference_state[35+:1]=reference.u_a11.ckb_d;
assign reference_state[36+:1]=reference.u_a11.d_pre_a;
assign reference_state[37+:1]=reference.u_a11.d_pre_b;
assign reference_state[38+:1]=reference.u_a11.qa;
assign reference_state[39+:1]=reference.u_a11.qb;
assign reference_state[40+:4]=reference.u_a12.q;
assign reference_state[44+:4]=reference.u_a13.q;
assign reference_state[48+:1]=reference.u_a20.ck_d;
assign reference_state[49+:4]=reference.u_a20.d_pre;
assign reference_state[53+:1]=reference.u_a20.dl_pre;
assign reference_state[54+:1]=reference.u_a20.dr_pre;
assign reference_state[55+:4]=reference.u_a20.q;
assign reference_state[59+:2]=reference.u_a20.s_pre;
assign reference_state[61+:1]=reference.u_a21.ck_d;
assign reference_state[62+:4]=reference.u_a21.d_pre;
assign reference_state[66+:1]=reference.u_a21.dl_pre;
assign reference_state[67+:1]=reference.u_a21.dr_pre;
assign reference_state[68+:4]=reference.u_a21.q;
assign reference_state[72+:2]=reference.u_a21.s_pre;
assign reference_state[74+:4]=reference.u_b05.q;
assign reference_state[78+:1]=reference.u_b10.cka_d;
assign reference_state[79+:1]=reference.u_b10.ckb_d;
assign reference_state[80+:1]=reference.u_b10.d_pre_a;
assign reference_state[81+:1]=reference.u_b10.d_pre_b;
assign reference_state[82+:1]=reference.u_b10.qa;
assign reference_state[83+:1]=reference.u_b10.qb;
assign reference_state[84+:1]=reference.u_b11.ck_d;
assign reference_state[85+:4]=reference.u_b11.d_pre;
assign reference_state[89+:1]=reference.u_b11.dl_pre;
assign reference_state[90+:1]=reference.u_b11.dr_pre;
assign reference_state[91+:4]=reference.u_b11.q;
assign reference_state[95+:2]=reference.u_b11.s_pre;
assign reference_state[97+:4]=reference.u_b12.q;
assign reference_state[101+:4]=reference.u_b13.q;
assign reference_state[105+:1]=reference.u_b15.ck_d;
assign reference_state[106+:6]=reference.u_b15.d_pre;
assign reference_state[112+:6]=reference.u_b15.q;
assign reference_state[118+:4]=reference.u_c05.q;
assign reference_state[122+:1]=reference.u_c10.ck_d;
assign reference_state[123+:6]=reference.u_c10.d_pre;
assign reference_state[129+:6]=reference.u_c10.q;
assign reference_state[135+:1]=reference.u_c11.ck_d;
assign reference_state[136+:4]=reference.u_c11.d_pre;
assign reference_state[140+:1]=reference.u_c11.dl_pre;
assign reference_state[141+:1]=reference.u_c11.dr_pre;
assign reference_state[142+:4]=reference.u_c11.q;
assign reference_state[146+:2]=reference.u_c11.s_pre;
assign reference_state[148+:1]=reference.u_c12.ck_d;
assign reference_state[149+:4]=reference.u_c12.d_pre;
assign reference_state[153+:1]=reference.u_c12.dl_pre;
assign reference_state[154+:1]=reference.u_c12.dr_pre;
assign reference_state[155+:4]=reference.u_c12.q;
assign reference_state[159+:2]=reference.u_c12.s_pre;
assign reference_state[161+:4]=reference.u_d05.q;
assign reference_state[165+:1]=reference.u_d15.ck_d;
assign reference_state[166+:4]=reference.u_d15.q;
assign reference_state[170+:6]=reference.u_d15.setup_pre;
assign reference_state[176+:1]=reference.u_d17.ck_d;
assign reference_state[177+:6]=reference.u_d17.d_pre;
assign reference_state[183+:6]=reference.u_d17.q;
assign reference_state[189+:4]=reference.u_e05.q;
assign reference_state[193+:4]=reference.u_e06.q;
assign reference_state[197+:1]=reference.u_e12.ck_d;
assign reference_state[198+:6]=reference.u_e12.d_pre;
assign reference_state[204+:6]=reference.u_e12.q;
assign reference_state[210+:4]=reference.u_e13.a_lat;
assign reference_state[214+:1]=reference.u_e13.ce_lat;
assign reference_state[215+:4]=reference.u_e13.d_lat;
assign reference_state[219+:64]={reference.u_e13.mem[15],reference.u_e13.mem[14],reference.u_e13.mem[13],reference.u_e13.mem[12],reference.u_e13.mem[11],reference.u_e13.mem[10],reference.u_e13.mem[9],reference.u_e13.mem[8],reference.u_e13.mem[7],reference.u_e13.mem[6],reference.u_e13.mem[5],reference.u_e13.mem[4],reference.u_e13.mem[3],reference.u_e13.mem[2],reference.u_e13.mem[1],reference.u_e13.mem[0]};
assign reference_state[283+:1]=reference.u_e13.we_d;
assign reference_state[284+:4]=reference.u_e14.a_lat;
assign reference_state[288+:1]=reference.u_e14.ce_lat;
assign reference_state[289+:4]=reference.u_e14.d_lat;
assign reference_state[293+:64]={reference.u_e14.mem[15],reference.u_e14.mem[14],reference.u_e14.mem[13],reference.u_e14.mem[12],reference.u_e14.mem[11],reference.u_e14.mem[10],reference.u_e14.mem[9],reference.u_e14.mem[8],reference.u_e14.mem[7],reference.u_e14.mem[6],reference.u_e14.mem[5],reference.u_e14.mem[4],reference.u_e14.mem[3],reference.u_e14.mem[2],reference.u_e14.mem[1],reference.u_e14.mem[0]};
assign reference_state[357+:1]=reference.u_e14.we_d;
assign reference_state[358+:1]=reference.u_e15.ck_d;
assign reference_state[359+:4]=reference.u_e15.q;
assign reference_state[363+:6]=reference.u_e15.setup_pre;
assign reference_state[369+:1]=reference.u_e17.ck_d;
assign reference_state[370+:6]=reference.u_e17.d_pre;
assign reference_state[376+:6]=reference.u_e17.q;
assign reference_state[382+:4]=reference.u_f06.q;
assign reference_state[386+:4]=reference.u_f16.q;
assign reference_state[390+:4]=reference.u_g05.q;
assign reference_state[394+:4]=reference.u_g06.q;
assign reference_state[398+:4]=reference.u_g07.q;
assign reference_state[402+:1]=reference.u_g08.ck_d;
assign reference_state[403+:6]=reference.u_g08.d_pre;
assign reference_state[409+:6]=reference.u_g08.q;
assign reference_state[415+:1]=reference.u_g10.cka_d;
assign reference_state[416+:1]=reference.u_g10.ckb_d;
assign reference_state[417+:1]=reference.u_g10.d_pre_a;
assign reference_state[418+:1]=reference.u_g10.d_pre_b;
assign reference_state[419+:1]=reference.u_g10.qa;
assign reference_state[420+:1]=reference.u_g10.qb;
assign reference_state[421+:4]=reference.u_g14.q;
assign reference_state[425+:4]=reference.u_g15.a_lat;
assign reference_state[429+:1]=reference.u_g15.ce_lat;
assign reference_state[430+:4]=reference.u_g15.d_lat;
assign reference_state[434+:64]={reference.u_g15.mem[15],reference.u_g15.mem[14],reference.u_g15.mem[13],reference.u_g15.mem[12],reference.u_g15.mem[11],reference.u_g15.mem[10],reference.u_g15.mem[9],reference.u_g15.mem[8],reference.u_g15.mem[7],reference.u_g15.mem[6],reference.u_g15.mem[5],reference.u_g15.mem[4],reference.u_g15.mem[3],reference.u_g15.mem[2],reference.u_g15.mem[1],reference.u_g15.mem[0]};
assign reference_state[498+:1]=reference.u_g15.we_d;
assign reference_state[499+:1]=reference.u_g16.ck_d;
assign reference_state[500+:4]=reference.u_g16.d_pre;
assign reference_state[504+:4]=reference.u_g16.q;
assign reference_state[508+:1]=reference.u_g18.ck_d;
assign reference_state[509+:6]=reference.u_g18.d_pre;
assign reference_state[515+:6]=reference.u_g18.q;
assign reference_state[521+:1]=reference.u_g24.cka_d;
assign reference_state[522+:1]=reference.u_g24.ckb_d;
assign reference_state[523+:1]=reference.u_g24.d_pre_a;
assign reference_state[524+:1]=reference.u_g24.d_pre_b;
assign reference_state[525+:1]=reference.u_g24.qa;
assign reference_state[526+:1]=reference.u_g24.qb;
assign reference_state[527+:4]=reference.u_h05.q;
assign reference_state[531+:1]=reference.u_h10.cka_d;
assign reference_state[532+:1]=reference.u_h10.ckb_d;
assign reference_state[533+:1]=reference.u_h10.d_pre_a;
assign reference_state[534+:1]=reference.u_h10.d_pre_b;
assign reference_state[535+:1]=reference.u_h10.qa;
assign reference_state[536+:1]=reference.u_h10.qb;
assign reference_state[537+:1]=reference.u_h14.ck_d;
assign reference_state[538+:6]=reference.u_h14.d_pre;
assign reference_state[544+:6]=reference.u_h14.q;
assign reference_state[550+:4]=reference.u_h15.q;
assign reference_state[554+:1]=reference.u_h22.cka_d;
assign reference_state[555+:1]=reference.u_h22.ckb_d;
assign reference_state[556+:1]=reference.u_h22.d_pre_a;
assign reference_state[557+:1]=reference.u_h22.d_pre_b;
assign reference_state[558+:1]=reference.u_h22.qa;
assign reference_state[559+:1]=reference.u_h22.qb;
assign reference_state[560+:5]=reference.u_i01.q;
assign reference_state[565+:5]=reference.u_i02.q;
assign reference_state[570+:4]=reference.u_i03.q;
assign reference_state[574+:4]=reference.u_i04.q;
assign reference_state[578+:4]=reference.u_i13.a_lat;
assign reference_state[582+:1]=reference.u_i13.ce_lat;
assign reference_state[583+:4]=reference.u_i13.d_lat;
assign reference_state[587+:64]={reference.u_i13.mem[15],reference.u_i13.mem[14],reference.u_i13.mem[13],reference.u_i13.mem[12],reference.u_i13.mem[11],reference.u_i13.mem[10],reference.u_i13.mem[9],reference.u_i13.mem[8],reference.u_i13.mem[7],reference.u_i13.mem[6],reference.u_i13.mem[5],reference.u_i13.mem[4],reference.u_i13.mem[3],reference.u_i13.mem[2],reference.u_i13.mem[1],reference.u_i13.mem[0]};
assign reference_state[651+:1]=reference.u_i13.we_d;
assign reference_state[652+:1]=reference.u_i14.ck_d;
assign reference_state[653+:4]=reference.u_i14.d_pre;
assign reference_state[657+:1]=reference.u_i14.dl_pre;
assign reference_state[658+:1]=reference.u_i14.dr_pre;
assign reference_state[659+:4]=reference.u_i14.q;
assign reference_state[663+:2]=reference.u_i14.s_pre;
assign reference_state[665+:1]=reference.u_i15.ck_d;
assign reference_state[666+:6]=reference.u_i15.d_pre;
assign reference_state[672+:6]=reference.u_i15.q;
assign reference_state[678+:4]=reference.u_i16.q;
assign reference_state[682+:4]=reference.u_i17.q;
assign reference_state[686+:4]=reference.u_j01.q;
assign reference_state[690+:4]=reference.u_j02.q;
assign reference_state[694+:4]=reference.u_j03.q;
assign reference_state[698+:4]=reference.u_j04.q;
assign reference_state[702+:1]=reference.u_j11.ck_d;
assign reference_state[703+:6]=reference.u_j11.d_pre;
assign reference_state[709+:6]=reference.u_j11.q;
assign reference_state[715+:1]=reference.u_j19.cka_d;
assign reference_state[716+:1]=reference.u_j19.ckb_d;
assign reference_state[717+:1]=reference.u_j19.d_pre_a;
assign reference_state[718+:1]=reference.u_j19.d_pre_b;
assign reference_state[719+:1]=reference.u_j19.qa;
assign reference_state[720+:1]=reference.u_j19.qb;
assign reference_state[721+:4]=reference.u_k01.q;
assign reference_state[725+:4]=reference.u_k02.q;
assign reference_state[729+:1]=reference.u_k11.ck_d;
assign reference_state[730+:6]=reference.u_k11.d_pre;
assign reference_state[736+:6]=reference.u_k11.q;
assign reference_state[742+:1]=reference.u_k22.ck_d;
assign reference_state[743+:6]=reference.u_k22.d_pre;
assign reference_state[749+:6]=reference.u_k22.q;
assign reference_state[755+:1]=reference.u_l02.cka_d;
assign reference_state[756+:1]=reference.u_l02.ckb_d;
assign reference_state[757+:1]=reference.u_l02.d_pre_a;
assign reference_state[758+:1]=reference.u_l02.d_pre_b;
assign reference_state[759+:1]=reference.u_l02.qa;
assign reference_state[760+:1]=reference.u_l02.qb;
assign reference_state[761+:4]=reference.u_l03.a_lat;
assign reference_state[765+:1]=reference.u_l03.ce_lat;
assign reference_state[766+:4]=reference.u_l03.d_lat;
assign reference_state[770+:64]={reference.u_l03.mem[15],reference.u_l03.mem[14],reference.u_l03.mem[13],reference.u_l03.mem[12],reference.u_l03.mem[11],reference.u_l03.mem[10],reference.u_l03.mem[9],reference.u_l03.mem[8],reference.u_l03.mem[7],reference.u_l03.mem[6],reference.u_l03.mem[5],reference.u_l03.mem[4],reference.u_l03.mem[3],reference.u_l03.mem[2],reference.u_l03.mem[1],reference.u_l03.mem[0]};
assign reference_state[834+:1]=reference.u_l03.we_d;
assign reference_state[835+:4]=reference.u_l04.a_lat;
assign reference_state[839+:1]=reference.u_l04.ce_lat;
assign reference_state[840+:4]=reference.u_l04.d_lat;
assign reference_state[844+:64]={reference.u_l04.mem[15],reference.u_l04.mem[14],reference.u_l04.mem[13],reference.u_l04.mem[12],reference.u_l04.mem[11],reference.u_l04.mem[10],reference.u_l04.mem[9],reference.u_l04.mem[8],reference.u_l04.mem[7],reference.u_l04.mem[6],reference.u_l04.mem[5],reference.u_l04.mem[4],reference.u_l04.mem[3],reference.u_l04.mem[2],reference.u_l04.mem[1],reference.u_l04.mem[0]};
assign reference_state[908+:1]=reference.u_l04.we_d;
assign reference_state[909+:1]=reference.u_l06.cka_d;
assign reference_state[910+:1]=reference.u_l06.ckb_d;
assign reference_state[911+:1]=reference.u_l06.qa;
assign reference_state[912+:1]=reference.u_l06.qb;
assign reference_state[913+:1]=reference.u_l07.cka_d;
assign reference_state[914+:1]=reference.u_l07.ckb_d;
assign reference_state[915+:1]=reference.u_l07.qa;
assign reference_state[916+:1]=reference.u_l07.qb;
assign reference_state[917+:1]=reference.u_l11.cka_d;
assign reference_state[918+:1]=reference.u_l11.ckb_d;
assign reference_state[919+:1]=reference.u_l11.d_pre_a;
assign reference_state[920+:1]=reference.u_l11.d_pre_b;
assign reference_state[921+:1]=reference.u_l11.qa;
assign reference_state[922+:1]=reference.u_l11.qb;
assign reference_state[923+:1]=reference.u_l14.ck_d;
assign reference_state[924+:6]=reference.u_l14.d_pre;
assign reference_state[930+:6]=reference.u_l14.q;
assign reference_state[936+:1]=reference.u_l15.cka_d;
assign reference_state[937+:1]=reference.u_l15.ckb_d;
assign reference_state[938+:1]=reference.u_l15.d_pre_a;
assign reference_state[939+:1]=reference.u_l15.d_pre_b;
assign reference_state[940+:1]=reference.u_l15.qa;
assign reference_state[941+:1]=reference.u_l15.qb;
assign reference_state[942+:1]=reference.u_l16.ck_d;
assign reference_state[943+:4]=reference.u_l16.d_pre;
assign reference_state[947+:4]=reference.u_l16.q;
assign reference_state[951+:1]=reference.u_l18.ck_d;
assign reference_state[952+:4]=reference.u_l18.d_pre;
assign reference_state[956+:4]=reference.u_l18.q;
assign reference_state[960+:1]=reference.u_l22.ck_d;
assign reference_state[961+:6]=reference.u_l22.d_pre;
assign reference_state[967+:6]=reference.u_l22.q;
assign reference_probe[0+:4]=reference.u_h06.mem[0+(probe_index%256)];
assign reference_probe[4+:4]=reference.u_i06.mem[0+(probe_index%256)];
assign reference_probe[8+:1]=reference.u_i08.mem[0+(probe_index%256)];
assign reference_probe[9+:4]=reference.u_j06.mem[0+(probe_index%256)];
assign reference_probe[13+:1]=reference.u_j08.mem[0+(probe_index%256)];
assign reference_probe[14+:4]=reference.u_k06.mem[0+(probe_index%256)];
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_BMux_17__drv;
wire dut_CkMdParity_p___drv;
wire dut_Cnt_eq_Zero_p___drv;
wire dut_DMuxData__drv;
wire dut_FF_eq_030__drv;
wire dut_IOB_08__drv;
wire dut_IOB_09__drv;
wire dut_IOB_10__drv;
wire dut_IOB_11__drv;
wire dut_IOB_12__drv;
wire dut_IOB_13__drv;
wire dut_IOB_14__drv;
wire dut_IOB_15__drv;
wire dut_IOB_17__drv;
wire dut_IOPE__drv;
wire dut_IOin_p___drv;
wire dut_IOout_p___drv;
wire dut_LScopeFH__drv;
wire dut_MAR_08_p___drv;
wire dut_MAR_09_p___drv;
wire dut_MAR_10_p___drv;
wire dut_MAR_11_p___drv;
wire dut_MAR_12_p___drv;
wire dut_MAR_13_p___drv;
wire dut_MAR_14_p___drv;
wire dut_MAR_15_p___drv;
wire dut_MdPE__drv;
wire dut_MemBase_2__drv;
wire dut_MemBase_3__drv;
wire dut_Pdata_15__drv;
wire dut_PrHoldReq__drv;
wire dut_PropCnt_p___drv;
wire dut_Q_08__drv;
wire dut_QBit_p___drv;
wire dut_RScopeClk0_p___drv;
wire dut_RamPE__drv;
wire dut_RbAdr_0__drv;
wire dut_RbAdr_1__drv;
wire dut_RbAdr_2__drv;
wire dut_RbAdr_3__drv;
wire dut_RbBypass__drv;
wire dut_RbBypass_p___drv;
wire dut_RmOdd_p___drv;
wire dut_SelectRm_p_a__drv;
wire dut_SelectStk_p_a__drv;
wire dut_ShA_08__drv;
wire dut_ShA_09__drv;
wire dut_ShA_10__drv;
wire dut_ShA_11__drv;
wire dut_ShA_12__drv;
wire dut_ShA_13__drv;
wire dut_ShA_14__drv;
wire dut_ShA_15__drv;
wire dut_Shc_08__drv;
wire dut_Shc_09__drv;
wire dut_Shc_10__drv;
wire dut_Shc_11__drv;
wire dut_Shc_12__drv;
wire dut_Shc_13__drv;
wire dut_Shc_14__drv;
wire dut_Shc_15__drv;
wire dut_ShcAlu_0__drv;
wire dut_ShcAlu_1__drv;
wire dut_ShcAlu_2__drv;
wire dut_ShcAlu_3__drv;
wire dut_StkAdr_0a__drv;
wire dut_StkAdr_1a__drv;
wire dut_StkAdr_2a__drv;
wire dut_StkAdr_3a__drv;
wire dut_StkAdr_4a__drv;
wire dut_StkAdr_5a__drv;
wire dut_StkAdr_6a__drv;
wire dut_StkAdr_7a__drv;
wire dut_StkError__drv;
wire dut__u_MD__drv;
wire dut__u_MDI__drv;
wire dut__u_MDI_p___drv;
wire dut_alu_08__drv;
wire dut_alu_15__drv;
wire dut_aluC0__drv;
wire dut_aluF0__drv;
wire dut_aluF1__drv;
wire dut_aluF2__drv;
wire dut_aluF3__drv;
wire dut_aluG1__drv;
wire dut_aluM__drv;
wire dut_aluOut_eq_0_p___drv;
wire dut_aluP1__drv;
dorado_serial_ProcL #(.SYSPER(4)) dut(
.sys_clk(clk),
.ALUCarry(stimulus[0]),
.ALUF_0(stimulus[1]),
.ALUF_1(stimulus[2]),
.ALUF_2(stimulus[3]),
.ALUF_3(stimulus[4]),
.ASEL_0_p_(stimulus[5]),
.ASEL_1_p_(stimulus[6]),
.ASEL_2_p_(stimulus[7]),
.BMux_08(stimulus[8] | dut_BMux_08__drv),
.BMux_09(stimulus[9] | dut_BMux_09__drv),
.BMux_10(stimulus[10] | dut_BMux_10__drv),
.BMux_11(stimulus[11] | dut_BMux_11__drv),
.BMux_12(stimulus[12] | dut_BMux_12__drv),
.BMux_13(stimulus[13] | dut_BMux_13__drv),
.BMux_14(stimulus[14] | dut_BMux_14__drv),
.BMux_15(stimulus[15] | dut_BMux_15__drv),
.BMux_17(stimulus[16] | dut_BMux_17__drv),
.BNTGtCT_p_a(stimulus[17]),
.BSEL_0_p_(stimulus[18]),
.BSEL_1_p_(stimulus[19]),
.BSEL_2_p_(stimulus[20]),
.CLK_pl_p_(stimulus[21]),
.CLKEnable_p_b(stimulus[22]),
.CkMdParity_p_(stimulus[23] | dut_CkMdParity_p___drv),
.DMuxClk(stimulus[24]),
.DMuxData(stimulus[25] | dut_DMuxData__drv),
.FF_0(stimulus[26]),
.FF_1(stimulus[27]),
.FF_2(stimulus[28]),
.FF_3(stimulus[29]),
.FF_4(stimulus[30]),
.FF_5(stimulus[31]),
.FF_6(stimulus[32]),
.FF_7(stimulus[33]),
.FFok_p_b(stimulus[34]),
.Freeze(stimulus[35]),
.IOB_08(stimulus[36] | dut_IOB_08__drv),
.IOB_09(stimulus[37] | dut_IOB_09__drv),
.IOB_10(stimulus[38] | dut_IOB_10__drv),
.IOB_11(stimulus[39] | dut_IOB_11__drv),
.IOB_12(stimulus[40] | dut_IOB_12__drv),
.IOB_13(stimulus[41] | dut_IOB_13__drv),
.IOB_14(stimulus[42] | dut_IOB_14__drv),
.IOB_15(stimulus[43] | dut_IOB_15__drv),
.IOB_17(stimulus[44] | dut_IOB_17__drv),
.IOin_p_(stimulus[45] | dut_IOin_p___drv),
.IfuData_0(stimulus[46]),
.IfuData_1(stimulus[47]),
.IfuData_2(stimulus[48]),
.IfuData_3(stimulus[49]),
.IfuData_4(stimulus[50]),
.IfuData_5(stimulus[51]),
.IfuData_6(stimulus[52]),
.IfuData_7(stimulus[53]),
.IfuRBaseSel_p_(stimulus[54]),
.LC_0(stimulus[55]),
.LC_1(stimulus[56]),
.LC_2(stimulus[57]),
.MAR_08_p_(stimulus[58] | dut_MAR_08_p___drv),
.MAR_09_p_(stimulus[59] | dut_MAR_09_p___drv),
.MAR_10_p_(stimulus[60] | dut_MAR_10_p___drv),
.MAR_11_p_(stimulus[61] | dut_MAR_11_p___drv),
.MAR_12_p_(stimulus[62] | dut_MAR_12_p___drv),
.MAR_13_p_(stimulus[63] | dut_MAR_13_p___drv),
.MAR_14_p_(stimulus[64] | dut_MAR_14_p___drv),
.MAR_15_p_(stimulus[65] | dut_MAR_15_p___drv),
.Next_0(stimulus[66]),
.Next_1(stimulus[67]),
.Next_2(stimulus[68]),
.Next_3(stimulus[69]),
.NextMacro(stimulus[70]),
.PRhold(stimulus[71]),
.Pdata_15(stimulus[72] | dut_Pdata_15__drv),
.PrBlock_p_(stimulus[73]),
.Q_07(stimulus[74]),
.Q_08(stimulus[75] | dut_Q_08__drv),
.RSTK_0(stimulus[76]),
.RSTK_1(stimulus[77]),
.RSTK_2(stimulus[78]),
.RSTK_3(stimulus[79]),
.RbBypass(stimulus[80] | dut_RbBypass__drv),
.RbBypass_p_(stimulus[81] | dut_RbBypass_p___drv),
.RmOdd_p_(stimulus[82] | dut_RmOdd_p___drv),
.ShA_00(stimulus[83]),
.ShA_01(stimulus[84]),
.ShA_02(stimulus[85]),
.ShA_03(stimulus[86]),
.ShA_04(stimulus[87]),
.ShA_05(stimulus[88]),
.ShA_06(stimulus[89]),
.ShA_07(stimulus[90]),
.ShA_08(stimulus[91] | dut_ShA_08__drv),
.ShA_09(stimulus[92] | dut_ShA_09__drv),
.ShA_10(stimulus[93] | dut_ShA_10__drv),
.ShA_11(stimulus[94] | dut_ShA_11__drv),
.ShA_12(stimulus[95] | dut_ShA_12__drv),
.ShA_13(stimulus[96] | dut_ShA_13__drv),
.ShA_14(stimulus[97] | dut_ShA_14__drv),
.ShA_15(stimulus[98] | dut_ShA_15__drv),
.Shc_02(stimulus[99]),
.Shc_03(stimulus[100]),
.Shc_04b(stimulus[101]),
.Shc_05b(stimulus[102]),
.Shc_06b(stimulus[103]),
.Shc_07b(stimulus[104]),
.Shc_08(stimulus[105] | dut_Shc_08__drv),
.Shc_09(stimulus[106] | dut_Shc_09__drv),
.Shc_10(stimulus[107] | dut_Shc_10__drv),
.Shc_11(stimulus[108] | dut_Shc_11__drv),
.Shc_12(stimulus[109] | dut_Shc_12__drv),
.Shc_13(stimulus[110] | dut_Shc_13__drv),
.Shc_14(stimulus[111] | dut_Shc_14__drv),
.Shc_15(stimulus[112] | dut_Shc_15__drv),
.ShcAlu_0(stimulus[113] | dut_ShcAlu_0__drv),
.ShcAlu_1(stimulus[114] | dut_ShcAlu_1__drv),
.ShcAlu_2(stimulus[115] | dut_ShcAlu_2__drv),
.ShcAlu_3(stimulus[116] | dut_ShcAlu_3__drv),
.SimHoldDis(stimulus[117]),
.StartCycle_p_a(stimulus[118]),
.StkError(stimulus[119] | dut_StkError__drv),
.SubTask_0(stimulus[120]),
.SubTask_1(stimulus[121]),
.TempRef(stimulus[122]),
._u_MD(stimulus[123] | dut__u_MD__drv),
._u_MDI(stimulus[124] | dut__u_MDI__drv),
._u_MDI_p_(stimulus[125] | dut__u_MDI_p___drv),
.alu_07(stimulus[126]),
.alu_08(stimulus[127] | dut_alu_08__drv),
.alu_15(stimulus[128] | dut_alu_15__drv),
.aluC0(stimulus[129] | dut_aluC0__drv),
.aluCout(stimulus[130]),
.aluF0(stimulus[131] | dut_aluF0__drv),
.aluF1(stimulus[132] | dut_aluF1__drv),
.aluF2(stimulus[133] | dut_aluF2__drv),
.aluF3(stimulus[134] | dut_aluF3__drv),
.aluM(stimulus[135] | dut_aluM__drv),
.dMD_08(stimulus[136]),
.dMD_09(stimulus[137]),
.dMD_10(stimulus[138]),
.dMD_11(stimulus[139]),
.dMD_12(stimulus[140]),
.dMD_13(stimulus[141]),
.dMD_14(stimulus[142]),
.dMD_15(stimulus[143]),
.dMD_17(stimulus[144]),
.jcnt(stimulus[145]),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.BMux_17__drv(dut_BMux_17__drv),
.CkMdParity_p___drv(dut_CkMdParity_p___drv),
.Cnt_eq_Zero_p___drv(dut_Cnt_eq_Zero_p___drv),
.DMuxData__drv(dut_DMuxData__drv),
.FF_eq_030__drv(dut_FF_eq_030__drv),
.IOB_08__drv(dut_IOB_08__drv),
.IOB_09__drv(dut_IOB_09__drv),
.IOB_10__drv(dut_IOB_10__drv),
.IOB_11__drv(dut_IOB_11__drv),
.IOB_12__drv(dut_IOB_12__drv),
.IOB_13__drv(dut_IOB_13__drv),
.IOB_14__drv(dut_IOB_14__drv),
.IOB_15__drv(dut_IOB_15__drv),
.IOB_17__drv(dut_IOB_17__drv),
.IOPE__drv(dut_IOPE__drv),
.IOin_p___drv(dut_IOin_p___drv),
.IOout_p___drv(dut_IOout_p___drv),
.LScopeFH__drv(dut_LScopeFH__drv),
.MAR_08_p___drv(dut_MAR_08_p___drv),
.MAR_09_p___drv(dut_MAR_09_p___drv),
.MAR_10_p___drv(dut_MAR_10_p___drv),
.MAR_11_p___drv(dut_MAR_11_p___drv),
.MAR_12_p___drv(dut_MAR_12_p___drv),
.MAR_13_p___drv(dut_MAR_13_p___drv),
.MAR_14_p___drv(dut_MAR_14_p___drv),
.MAR_15_p___drv(dut_MAR_15_p___drv),
.MdPE__drv(dut_MdPE__drv),
.MemBase_2__drv(dut_MemBase_2__drv),
.MemBase_3__drv(dut_MemBase_3__drv),
.Pdata_15__drv(dut_Pdata_15__drv),
.PrHoldReq__drv(dut_PrHoldReq__drv),
.PropCnt_p___drv(dut_PropCnt_p___drv),
.Q_08__drv(dut_Q_08__drv),
.QBit_p___drv(dut_QBit_p___drv),
.RScopeClk0_p___drv(dut_RScopeClk0_p___drv),
.RamPE__drv(dut_RamPE__drv),
.RbAdr_0__drv(dut_RbAdr_0__drv),
.RbAdr_1__drv(dut_RbAdr_1__drv),
.RbAdr_2__drv(dut_RbAdr_2__drv),
.RbAdr_3__drv(dut_RbAdr_3__drv),
.RbBypass__drv(dut_RbBypass__drv),
.RbBypass_p___drv(dut_RbBypass_p___drv),
.RmOdd_p___drv(dut_RmOdd_p___drv),
.SelectRm_p_a__drv(dut_SelectRm_p_a__drv),
.SelectStk_p_a__drv(dut_SelectStk_p_a__drv),
.ShA_08__drv(dut_ShA_08__drv),
.ShA_09__drv(dut_ShA_09__drv),
.ShA_10__drv(dut_ShA_10__drv),
.ShA_11__drv(dut_ShA_11__drv),
.ShA_12__drv(dut_ShA_12__drv),
.ShA_13__drv(dut_ShA_13__drv),
.ShA_14__drv(dut_ShA_14__drv),
.ShA_15__drv(dut_ShA_15__drv),
.Shc_08__drv(dut_Shc_08__drv),
.Shc_09__drv(dut_Shc_09__drv),
.Shc_10__drv(dut_Shc_10__drv),
.Shc_11__drv(dut_Shc_11__drv),
.Shc_12__drv(dut_Shc_12__drv),
.Shc_13__drv(dut_Shc_13__drv),
.Shc_14__drv(dut_Shc_14__drv),
.Shc_15__drv(dut_Shc_15__drv),
.ShcAlu_0__drv(dut_ShcAlu_0__drv),
.ShcAlu_1__drv(dut_ShcAlu_1__drv),
.ShcAlu_2__drv(dut_ShcAlu_2__drv),
.ShcAlu_3__drv(dut_ShcAlu_3__drv),
.StkAdr_0a__drv(dut_StkAdr_0a__drv),
.StkAdr_1a__drv(dut_StkAdr_1a__drv),
.StkAdr_2a__drv(dut_StkAdr_2a__drv),
.StkAdr_3a__drv(dut_StkAdr_3a__drv),
.StkAdr_4a__drv(dut_StkAdr_4a__drv),
.StkAdr_5a__drv(dut_StkAdr_5a__drv),
.StkAdr_6a__drv(dut_StkAdr_6a__drv),
.StkAdr_7a__drv(dut_StkAdr_7a__drv),
.StkError__drv(dut_StkError__drv),
._u_MD__drv(dut__u_MD__drv),
._u_MDI__drv(dut__u_MDI__drv),
._u_MDI_p___drv(dut__u_MDI_p___drv),
.alu_08__drv(dut_alu_08__drv),
.alu_15__drv(dut_alu_15__drv),
.aluC0__drv(dut_aluC0__drv),
.aluF0__drv(dut_aluF0__drv),
.aluF1__drv(dut_aluF1__drv),
.aluF2__drv(dut_aluF2__drv),
.aluF3__drv(dut_aluF3__drv),
.aluG1__drv(dut_aluG1__drv),
.aluM__drv(dut_aluM__drv),
.aluOut_eq_0_p___drv(dut_aluOut_eq_0_p___drv),
.aluP1__drv(dut_aluP1__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[15:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_aluP1__drv,dut_aluOut_eq_0_p___drv,dut_aluM__drv,dut_aluG1__drv,dut_aluF3__drv,dut_aluF2__drv,dut_aluF1__drv,dut_aluF0__drv,dut_aluC0__drv,dut_alu_15__drv,dut_alu_08__drv,dut__u_MDI_p___drv,dut__u_MDI__drv,dut__u_MD__drv,dut_StkError__drv,dut_StkAdr_7a__drv,dut_StkAdr_6a__drv,dut_StkAdr_5a__drv,dut_StkAdr_4a__drv,dut_StkAdr_3a__drv,dut_StkAdr_2a__drv,dut_StkAdr_1a__drv,dut_StkAdr_0a__drv,dut_ShcAlu_3__drv,dut_ShcAlu_2__drv,dut_ShcAlu_1__drv,dut_ShcAlu_0__drv,dut_Shc_15__drv,dut_Shc_14__drv,dut_Shc_13__drv,dut_Shc_12__drv,dut_Shc_11__drv,dut_Shc_10__drv,dut_Shc_09__drv,dut_Shc_08__drv,dut_ShA_15__drv,dut_ShA_14__drv,dut_ShA_13__drv,dut_ShA_12__drv,dut_ShA_11__drv,dut_ShA_10__drv,dut_ShA_09__drv,dut_ShA_08__drv,dut_SelectStk_p_a__drv,dut_SelectRm_p_a__drv,dut_RmOdd_p___drv,dut_RbBypass_p___drv,dut_RbBypass__drv,dut_RbAdr_3__drv,dut_RbAdr_2__drv,dut_RbAdr_1__drv,dut_RbAdr_0__drv,dut_RamPE__drv,dut_RScopeClk0_p___drv,dut_QBit_p___drv,dut_Q_08__drv,dut_PropCnt_p___drv,dut_PrHoldReq__drv,dut_Pdata_15__drv,dut_MemBase_3__drv,dut_MemBase_2__drv,dut_MdPE__drv,dut_MAR_15_p___drv,dut_MAR_14_p___drv,dut_MAR_13_p___drv,dut_MAR_12_p___drv,dut_MAR_11_p___drv,dut_MAR_10_p___drv,dut_MAR_09_p___drv,dut_MAR_08_p___drv,dut_LScopeFH__drv,dut_IOout_p___drv,dut_IOin_p___drv,dut_IOPE__drv,dut_IOB_17__drv,dut_IOB_15__drv,dut_IOB_14__drv,dut_IOB_13__drv,dut_IOB_12__drv,dut_IOB_11__drv,dut_IOB_10__drv,dut_IOB_09__drv,dut_IOB_08__drv,dut_FF_eq_030__drv,dut_DMuxData__drv,dut_Cnt_eq_Zero_p___drv,dut_CkMdParity_p___drv,dut_BMux_17__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv};
assign dut_state[0+:1]=dut.Clock1Bd;
assign dut_state[1+:1]=dut.Clock1_p_Aa;
assign dut_state[2+:1]=dut.Clock1_p_Ac;
assign dut_state[3+:1]=dut.Clock1_p_Ba;
assign dut_state[4+:1]=dut.Clock1_p_Bb;
assign dut_state[5+:1]=dut.Clock1_p_Ca;
assign dut_state[6+:1]=dut.Clock1_p_Cb;
assign dut_state[7+:1]=dut.Clock1_p_Da;
assign dut_state[8+:1]=dut.Clock1_p_Db;
assign dut_state[9+:1]=dut.Clock1_p_Dc;
assign dut_state[10+:1]=dut.u_a03.ck_d;
assign dut_state[11+:4]=dut.u_a03.d_pre;
assign dut_state[15+:4]=dut.u_a03.q;
assign dut_state[19+:1]=dut.u_a04.ck_d;
assign dut_state[20+:4]=dut.u_a04.d_pre;
assign dut_state[24+:4]=dut.u_a04.q;
assign dut_state[28+:1]=dut.u_a10.cka_d;
assign dut_state[29+:1]=dut.u_a10.ckb_d;
assign dut_state[30+:1]=dut.u_a10.d_pre_a;
assign dut_state[31+:1]=dut.u_a10.d_pre_b;
assign dut_state[32+:1]=dut.u_a10.qa;
assign dut_state[33+:1]=dut.u_a10.qb;
assign dut_state[34+:1]=dut.u_a11.cka_d;
assign dut_state[35+:1]=dut.u_a11.ckb_d;
assign dut_state[36+:1]=dut.u_a11.d_pre_a;
assign dut_state[37+:1]=dut.u_a11.d_pre_b;
assign dut_state[38+:1]=dut.u_a11.qa;
assign dut_state[39+:1]=dut.u_a11.qb;
assign dut_state[40+:4]=dut.u_a12.q;
assign dut_state[44+:4]=dut.u_a13.q;
assign dut_state[48+:1]=dut.u_a20.ck_d;
assign dut_state[49+:4]=dut.u_a20.d_pre;
assign dut_state[53+:1]=dut.u_a20.dl_pre;
assign dut_state[54+:1]=dut.u_a20.dr_pre;
assign dut_state[55+:4]=dut.u_a20.q;
assign dut_state[59+:2]=dut.u_a20.s_pre;
assign dut_state[61+:1]=dut.u_a21.ck_d;
assign dut_state[62+:4]=dut.u_a21.d_pre;
assign dut_state[66+:1]=dut.u_a21.dl_pre;
assign dut_state[67+:1]=dut.u_a21.dr_pre;
assign dut_state[68+:4]=dut.u_a21.q;
assign dut_state[72+:2]=dut.u_a21.s_pre;
assign dut_state[74+:4]=dut.u_b05.q;
assign dut_state[78+:1]=dut.u_b10.cka_d;
assign dut_state[79+:1]=dut.u_b10.ckb_d;
assign dut_state[80+:1]=dut.u_b10.d_pre_a;
assign dut_state[81+:1]=dut.u_b10.d_pre_b;
assign dut_state[82+:1]=dut.u_b10.qa;
assign dut_state[83+:1]=dut.u_b10.qb;
assign dut_state[84+:1]=dut.u_b11.ck_d;
assign dut_state[85+:4]=dut.u_b11.d_pre;
assign dut_state[89+:1]=dut.u_b11.dl_pre;
assign dut_state[90+:1]=dut.u_b11.dr_pre;
assign dut_state[91+:4]=dut.u_b11.q;
assign dut_state[95+:2]=dut.u_b11.s_pre;
assign dut_state[97+:4]=dut.u_b12.q;
assign dut_state[101+:4]=dut.u_b13.q;
assign dut_state[105+:1]=dut.u_b15.ck_d;
assign dut_state[106+:6]=dut.u_b15.d_pre;
assign dut_state[112+:6]=dut.u_b15.q;
assign dut_state[118+:4]=dut.u_c05.q;
assign dut_state[122+:1]=dut.u_c10.ck_d;
assign dut_state[123+:6]=dut.u_c10.d_pre;
assign dut_state[129+:6]=dut.u_c10.q;
assign dut_state[135+:1]=dut.u_c11.ck_d;
assign dut_state[136+:4]=dut.u_c11.d_pre;
assign dut_state[140+:1]=dut.u_c11.dl_pre;
assign dut_state[141+:1]=dut.u_c11.dr_pre;
assign dut_state[142+:4]=dut.u_c11.q;
assign dut_state[146+:2]=dut.u_c11.s_pre;
assign dut_state[148+:1]=dut.u_c12.ck_d;
assign dut_state[149+:4]=dut.u_c12.d_pre;
assign dut_state[153+:1]=dut.u_c12.dl_pre;
assign dut_state[154+:1]=dut.u_c12.dr_pre;
assign dut_state[155+:4]=dut.u_c12.q;
assign dut_state[159+:2]=dut.u_c12.s_pre;
assign dut_state[161+:4]=dut.u_d05.q;
assign dut_state[165+:1]=dut.u_d15.ck_d;
assign dut_state[166+:4]=dut.u_d15.q;
assign dut_state[170+:6]=dut.u_d15.setup_pre;
assign dut_state[176+:1]=dut.u_d17.ck_d;
assign dut_state[177+:6]=dut.u_d17.d_pre;
assign dut_state[183+:6]=dut.u_d17.q;
assign dut_state[189+:4]=dut.u_e05.q;
assign dut_state[193+:4]=dut.u_e06.q;
assign dut_state[197+:1]=dut.u_e12.ck_d;
assign dut_state[198+:6]=dut.u_e12.d_pre;
assign dut_state[204+:6]=dut.u_e12.q;
assign dut_state[210+:4]=dut.u_e13.a_lat;
assign dut_state[214+:1]=dut.u_e13.ce_lat;
assign dut_state[215+:4]=dut.u_e13.d_lat;
assign dut_state[219+:64]={dut.u_e13.mem[15],dut.u_e13.mem[14],dut.u_e13.mem[13],dut.u_e13.mem[12],dut.u_e13.mem[11],dut.u_e13.mem[10],dut.u_e13.mem[9],dut.u_e13.mem[8],dut.u_e13.mem[7],dut.u_e13.mem[6],dut.u_e13.mem[5],dut.u_e13.mem[4],dut.u_e13.mem[3],dut.u_e13.mem[2],dut.u_e13.mem[1],dut.u_e13.mem[0]};
assign dut_state[283+:1]=dut.u_e13.we_d;
assign dut_state[284+:4]=dut.u_e14.a_lat;
assign dut_state[288+:1]=dut.u_e14.ce_lat;
assign dut_state[289+:4]=dut.u_e14.d_lat;
assign dut_state[293+:64]={dut.u_e14.mem[15],dut.u_e14.mem[14],dut.u_e14.mem[13],dut.u_e14.mem[12],dut.u_e14.mem[11],dut.u_e14.mem[10],dut.u_e14.mem[9],dut.u_e14.mem[8],dut.u_e14.mem[7],dut.u_e14.mem[6],dut.u_e14.mem[5],dut.u_e14.mem[4],dut.u_e14.mem[3],dut.u_e14.mem[2],dut.u_e14.mem[1],dut.u_e14.mem[0]};
assign dut_state[357+:1]=dut.u_e14.we_d;
assign dut_state[358+:1]=dut.u_e15.ck_d;
assign dut_state[359+:4]=dut.u_e15.q;
assign dut_state[363+:6]=dut.u_e15.setup_pre;
assign dut_state[369+:1]=dut.u_e17.ck_d;
assign dut_state[370+:6]=dut.u_e17.d_pre;
assign dut_state[376+:6]=dut.u_e17.q;
assign dut_state[382+:4]=dut.u_f06.q;
assign dut_state[386+:4]=dut.u_f16.q;
assign dut_state[390+:4]=dut.u_g05.q;
assign dut_state[394+:4]=dut.u_g06.q;
assign dut_state[398+:4]=dut.u_g07.q;
assign dut_state[402+:1]=dut.u_g08.ck_d;
assign dut_state[403+:6]=dut.u_g08.d_pre;
assign dut_state[409+:6]=dut.u_g08.q;
assign dut_state[415+:1]=dut.u_g10.cka_d;
assign dut_state[416+:1]=dut.u_g10.ckb_d;
assign dut_state[417+:1]=dut.u_g10.d_pre_a;
assign dut_state[418+:1]=dut.u_g10.d_pre_b;
assign dut_state[419+:1]=dut.u_g10.qa;
assign dut_state[420+:1]=dut.u_g10.qb;
assign dut_state[421+:4]=dut.u_g14.q;
assign dut_state[425+:4]=dut.u_g15.a_lat;
assign dut_state[429+:1]=dut.u_g15.ce_lat;
assign dut_state[430+:4]=dut.u_g15.d_lat;
assign dut_state[434+:64]={dut.u_g15.mem[15],dut.u_g15.mem[14],dut.u_g15.mem[13],dut.u_g15.mem[12],dut.u_g15.mem[11],dut.u_g15.mem[10],dut.u_g15.mem[9],dut.u_g15.mem[8],dut.u_g15.mem[7],dut.u_g15.mem[6],dut.u_g15.mem[5],dut.u_g15.mem[4],dut.u_g15.mem[3],dut.u_g15.mem[2],dut.u_g15.mem[1],dut.u_g15.mem[0]};
assign dut_state[498+:1]=dut.u_g15.we_d;
assign dut_state[499+:1]=dut.u_g16.ck_d;
assign dut_state[500+:4]=dut.u_g16.d_pre;
assign dut_state[504+:4]=dut.u_g16.q;
assign dut_state[508+:1]=dut.u_g18.ck_d;
assign dut_state[509+:6]=dut.u_g18.d_pre;
assign dut_state[515+:6]=dut.u_g18.q;
assign dut_state[521+:1]=dut.u_g24.cka_d;
assign dut_state[522+:1]=dut.u_g24.ckb_d;
assign dut_state[523+:1]=dut.u_g24.d_pre_a;
assign dut_state[524+:1]=dut.u_g24.d_pre_b;
assign dut_state[525+:1]=dut.u_g24.qa;
assign dut_state[526+:1]=dut.u_g24.qb;
assign dut_state[527+:4]=dut.u_h05.q;
assign dut_state[531+:1]=dut.u_h10.cka_d;
assign dut_state[532+:1]=dut.u_h10.ckb_d;
assign dut_state[533+:1]=dut.u_h10.d_pre_a;
assign dut_state[534+:1]=dut.u_h10.d_pre_b;
assign dut_state[535+:1]=dut.u_h10.qa;
assign dut_state[536+:1]=dut.u_h10.qb;
assign dut_state[537+:1]=dut.u_h14.ck_d;
assign dut_state[538+:6]=dut.u_h14.d_pre;
assign dut_state[544+:6]=dut.u_h14.q;
assign dut_state[550+:4]=dut.u_h15.q;
assign dut_state[554+:1]=dut.u_h22.cka_d;
assign dut_state[555+:1]=dut.u_h22.ckb_d;
assign dut_state[556+:1]=dut.u_h22.d_pre_a;
assign dut_state[557+:1]=dut.u_h22.d_pre_b;
assign dut_state[558+:1]=dut.u_h22.qa;
assign dut_state[559+:1]=dut.u_h22.qb;
assign dut_state[560+:5]=dut.u_i01.q;
assign dut_state[565+:5]=dut.u_i02.q;
assign dut_state[570+:4]=dut.u_i03.q;
assign dut_state[574+:4]=dut.u_i04.q;
assign dut_state[578+:4]=dut.u_i13.a_lat;
assign dut_state[582+:1]=dut.u_i13.ce_lat;
assign dut_state[583+:4]=dut.u_i13.d_lat;
assign dut_state[587+:64]={dut.u_i13.mem[15],dut.u_i13.mem[14],dut.u_i13.mem[13],dut.u_i13.mem[12],dut.u_i13.mem[11],dut.u_i13.mem[10],dut.u_i13.mem[9],dut.u_i13.mem[8],dut.u_i13.mem[7],dut.u_i13.mem[6],dut.u_i13.mem[5],dut.u_i13.mem[4],dut.u_i13.mem[3],dut.u_i13.mem[2],dut.u_i13.mem[1],dut.u_i13.mem[0]};
assign dut_state[651+:1]=dut.u_i13.we_d;
assign dut_state[652+:1]=dut.u_i14.ck_d;
assign dut_state[653+:4]=dut.u_i14.d_pre;
assign dut_state[657+:1]=dut.u_i14.dl_pre;
assign dut_state[658+:1]=dut.u_i14.dr_pre;
assign dut_state[659+:4]=dut.u_i14.q;
assign dut_state[663+:2]=dut.u_i14.s_pre;
assign dut_state[665+:1]=dut.u_i15.ck_d;
assign dut_state[666+:6]=dut.u_i15.d_pre;
assign dut_state[672+:6]=dut.u_i15.q;
assign dut_state[678+:4]=dut.u_i16.q;
assign dut_state[682+:4]=dut.u_i17.q;
assign dut_state[686+:4]=dut.u_j01.q;
assign dut_state[690+:4]=dut.u_j02.q;
assign dut_state[694+:4]=dut.u_j03.q;
assign dut_state[698+:4]=dut.u_j04.q;
assign dut_state[702+:1]=dut.u_j11.ck_d;
assign dut_state[703+:6]=dut.u_j11.d_pre;
assign dut_state[709+:6]=dut.u_j11.q;
assign dut_state[715+:1]=dut.u_j19.cka_d;
assign dut_state[716+:1]=dut.u_j19.ckb_d;
assign dut_state[717+:1]=dut.u_j19.d_pre_a;
assign dut_state[718+:1]=dut.u_j19.d_pre_b;
assign dut_state[719+:1]=dut.u_j19.qa;
assign dut_state[720+:1]=dut.u_j19.qb;
assign dut_state[721+:4]=dut.u_k01.q;
assign dut_state[725+:4]=dut.u_k02.q;
assign dut_state[729+:1]=dut.u_k11.ck_d;
assign dut_state[730+:6]=dut.u_k11.d_pre;
assign dut_state[736+:6]=dut.u_k11.q;
assign dut_state[742+:1]=dut.u_k22.ck_d;
assign dut_state[743+:6]=dut.u_k22.d_pre;
assign dut_state[749+:6]=dut.u_k22.q;
assign dut_state[755+:1]=dut.u_l02.cka_d;
assign dut_state[756+:1]=dut.u_l02.ckb_d;
assign dut_state[757+:1]=dut.u_l02.d_pre_a;
assign dut_state[758+:1]=dut.u_l02.d_pre_b;
assign dut_state[759+:1]=dut.u_l02.qa;
assign dut_state[760+:1]=dut.u_l02.qb;
assign dut_state[761+:4]=dut.u_l03.a_lat;
assign dut_state[765+:1]=dut.u_l03.ce_lat;
assign dut_state[766+:4]=dut.u_l03.d_lat;
assign dut_state[770+:64]={dut.u_l03.mem[15],dut.u_l03.mem[14],dut.u_l03.mem[13],dut.u_l03.mem[12],dut.u_l03.mem[11],dut.u_l03.mem[10],dut.u_l03.mem[9],dut.u_l03.mem[8],dut.u_l03.mem[7],dut.u_l03.mem[6],dut.u_l03.mem[5],dut.u_l03.mem[4],dut.u_l03.mem[3],dut.u_l03.mem[2],dut.u_l03.mem[1],dut.u_l03.mem[0]};
assign dut_state[834+:1]=dut.u_l03.we_d;
assign dut_state[835+:4]=dut.u_l04.a_lat;
assign dut_state[839+:1]=dut.u_l04.ce_lat;
assign dut_state[840+:4]=dut.u_l04.d_lat;
assign dut_state[844+:64]={dut.u_l04.mem[15],dut.u_l04.mem[14],dut.u_l04.mem[13],dut.u_l04.mem[12],dut.u_l04.mem[11],dut.u_l04.mem[10],dut.u_l04.mem[9],dut.u_l04.mem[8],dut.u_l04.mem[7],dut.u_l04.mem[6],dut.u_l04.mem[5],dut.u_l04.mem[4],dut.u_l04.mem[3],dut.u_l04.mem[2],dut.u_l04.mem[1],dut.u_l04.mem[0]};
assign dut_state[908+:1]=dut.u_l04.we_d;
assign dut_state[909+:1]=dut.u_l06.cka_d;
assign dut_state[910+:1]=dut.u_l06.ckb_d;
assign dut_state[911+:1]=dut.u_l06.qa;
assign dut_state[912+:1]=dut.u_l06.qb;
assign dut_state[913+:1]=dut.u_l07.cka_d;
assign dut_state[914+:1]=dut.u_l07.ckb_d;
assign dut_state[915+:1]=dut.u_l07.qa;
assign dut_state[916+:1]=dut.u_l07.qb;
assign dut_state[917+:1]=dut.u_l11.cka_d;
assign dut_state[918+:1]=dut.u_l11.ckb_d;
assign dut_state[919+:1]=dut.u_l11.d_pre_a;
assign dut_state[920+:1]=dut.u_l11.d_pre_b;
assign dut_state[921+:1]=dut.u_l11.qa;
assign dut_state[922+:1]=dut.u_l11.qb;
assign dut_state[923+:1]=dut.u_l14.ck_d;
assign dut_state[924+:6]=dut.u_l14.d_pre;
assign dut_state[930+:6]=dut.u_l14.q;
assign dut_state[936+:1]=dut.u_l15.cka_d;
assign dut_state[937+:1]=dut.u_l15.ckb_d;
assign dut_state[938+:1]=dut.u_l15.d_pre_a;
assign dut_state[939+:1]=dut.u_l15.d_pre_b;
assign dut_state[940+:1]=dut.u_l15.qa;
assign dut_state[941+:1]=dut.u_l15.qb;
assign dut_state[942+:1]=dut.u_l16.ck_d;
assign dut_state[943+:4]=dut.u_l16.d_pre;
assign dut_state[947+:4]=dut.u_l16.q;
assign dut_state[951+:1]=dut.u_l18.ck_d;
assign dut_state[952+:4]=dut.u_l18.d_pre;
assign dut_state[956+:4]=dut.u_l18.q;
assign dut_state[960+:1]=dut.u_l22.ck_d;
assign dut_state[961+:6]=dut.u_l22.d_pre;
assign dut_state[967+:6]=dut.u_l22.q;
assign dut_probe[0+:4]=dut.u_h06.mem[0+(probe_index%256)];
assign dut_probe[4+:4]=dut.u_i06.mem[0+(probe_index%256)];
assign dut_probe[8+:1]=dut.u_i08.mem[0+(probe_index%256)];
assign dut_probe[9+:4]=dut.u_j06.mem[0+(probe_index%256)];
assign dut_probe[13+:1]=dut.u_j08.mem[0+(probe_index%256)];
assign dut_probe[14+:4]=dut.u_k06.mem[0+(probe_index%256)];
assign all_helpers_frozen=&{dut.state_frozen,dut.u_e13.state_frozen,dut.u_e14.state_frozen,dut.u_g15.state_frozen,dut.u_h06.state_frozen,dut.u_i06.state_frozen,dut.u_i08.state_frozen,dut.u_i13.state_frozen,dut.u_j06.state_frozen,dut.u_j08.state_frozen,dut.u_k06.state_frozen,dut.u_l03.state_frozen,dut.u_l04.state_frozen};
endmodule
