// cell_SE10231 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 10 package position(s) across the sixteen boards.
//
// High-Speed Dual Type D Master-Slave Flip-Flop (Signetics second source for
// the Motorola MC10231 -- EclDict's alias table groups them). Same part, same
// treatment as cell_MC10231: MECL S/R are ACTIVE HIGH and dominate the clock.
//
// FEWER PINS THAN ITS TWIN, because a cell declares only what the BOARDS
// wire. This socket has no Set on either half and a Reset on the b half only
// (p13), so those are the only asynchronous inputs modelled. p9 is the CC
// common-clock pin, which the boards leave unused here.
//
// FPGA: on `sys_clk` with C as an enable -- see cell_MC10176.

`default_nettype none

module dorado_serial_DispY__cell_SE10231_snapshot #(parameter PRECAP = 1) (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,
    output wire [17:0] state_result,
    input  wire sys_clk,
    output wire p2,  // Q
    output wire p3,  // Q'
    input  wire p6,  // C
    input  wire p7,  // D
    input  wire p9,  // CC
    input  wire p10,  // D
    input  wire p11,  // C
    input  wire p13,  // R
    output wire p14,  // Q'
    output wire p15// Q
);


  // THE COMMON CLOCK, pin 9 (CC), was ignored here until 2026-08-16 -- the
  // same class of bug Tim found on the combinational cells, and the reason
  // tools/sil_check_cells.py now reads the dictionary's [FF ...] entries too:
  //   MC231/SE231  [FF 10 ...>(14 15) : CLK (9 11) ...]   [FF 7 ...>(2 3) : CLK (9 6) ...]
  // Pin 9 is in BOTH clocks.
  //
  // The data book (DL122 rev 7, MC10231) says how the two combine: "Each
  // flip-flop may be clocked separately by holding the common clock in the
  // low state and using the enable inputs for the clocking function. If the
  // common clock is to be used to clock the flip-flop, the Clock Enable
  // inputs must be in the low state." Either can clock it while the other is
  // held low -- an OR.
  wire clka = p9 | p6;
  wire clkb = p9 | p11;

  reg cka_d, ckb_d;
  
  wire cka_en = clka & ~cka_d;
  wire ckb_en = clkb & ~ckb_d;

  // PRE-EDGE CAPTURE -- the real flip-flop's SETUP TIME, as cell_MC10176 has
  // it. The oversampling transform detects the modelled clock's edge one
  // sys_clk after it happens, and by then a D that changed ON that same edge
  // has settled to its NEW value, so a same-edge register-to-register
  // transfer became a pass-through. This package is every board's
  // clock-phase enable flip-flop (ProcH/ProcL l02 sample Clk0En' =
  // StartCycle', ContA l06 samples preStartCycle, the memory and display
  // boards' l02 sample MemSH), and on ProcH the consequence was measured
  // (2026-09-05): pClock1En' took StartCycle's new phase at once, so SHCP'C
  // -- its complement, the clock of a21 (Curr <- Next) -- rose at the START
  // of the Clock1 window (+1) while Clock1'Ca, the clock of a20 (Last <-
  // Curr), rose at its END (+17). Last therefore copied the NEW Curr, and
  // every task's T-file write-back at a switch was addressed to the
  // INCOMING task's slot: the junk task's T read another task's word after a
  // one-instruction slice, and its AckJunkTW<-T then carried a 0 into
  // ShutUp. With the pre-edge copy the two registers shift on the same edge
  // and Last holds the outgoing task through the write-back pulse.
  reg d_pre_a, d_pre_b;
  

  wire d_a = PRECAP ? d_pre_a : p7;
  wire d_b = PRECAP ? d_pre_b : p10;
  reg qa, qb;
                         // D, no async on this half
  

  assign p2  =  qa;  assign p3  = ~qa;
  assign p15 =  qb;  assign p14 = ~qb;


  assign state_result = {12'b0,{cka_d,ckb_d,d_pre_a,d_pre_b,qa,qb}};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {cka_d,ckb_d,d_pre_a,d_pre_b,qa,qb} <= state_data[5:0];
    end else if (state_advance) begin
begin cka_d <= clka; ckb_d <= clkb; end
begin d_pre_a <= p7; d_pre_b <= p10; end
if (cka_en) qa <= d_a;
begin
    if (p13)         qb <= 1'b0;                 // R
    else if (ckb_en) qb <= d_b;                  // D
  end
    end
  end
endmodule

`default_nettype wire
