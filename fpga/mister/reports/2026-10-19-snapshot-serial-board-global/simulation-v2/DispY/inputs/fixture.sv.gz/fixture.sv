module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [93:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [58:0] reference_outputs,dut_outputs,
 output wire [1704:0] reference_state,dut_state,
 output wire [38:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire reference_video_field;
wire reference_n_24Bit__drv;
wire reference_A8B2__drv;
wire reference_AItem_0__drv;
wire reference_AItem_1__drv;
wire reference_AItem_2__drv;
wire reference_AItem_3__drv;
wire reference_AItem_4__drv;
wire reference_AItem_5__drv;
wire reference_AItem_6__drv;
wire reference_AItem_7__drv;
wire reference_AItemClkEn_p_b__drv;
wire reference_AOff__drv;
wire reference_AltoCSync_p___drv;
wire reference_AltoHSync__drv;
wire reference_AltoTTLVideo__drv;
wire reference_AltoVSync_p___drv;
wire reference_BByPass__drv;
wire reference_BItem_0__drv;
wire reference_BItem_1__drv;
wire reference_BItem_2__drv;
wire reference_BItem_3__drv;
wire reference_BItem_4__drv;
wire reference_BItem_5__drv;
wire reference_BItem_6__drv;
wire reference_BItem_7__drv;
wire reference_BItemClkEn_p_b__drv;
wire reference_BOff__drv;
wire reference_Crystal__drv;
wire reference_CursorData__drv;
wire reference_DMuxData__drv;
wire reference_GNDFour__drv;
wire reference_HBlank__drv;
wire reference_HSync__drv;
wire reference_HalfLine__drv;
wire reference_IOB_00__drv;
wire reference_IOB_15__drv;
wire reference_IOB_16__drv;
wire reference_IOB_17__drv;
wire reference_IOut_m___drv;
wire reference_JamVBlank__drv;
wire reference_OISClkA__drv;
wire reference_OISClkA_p___drv;
wire reference_OISClkB__drv;
wire reference_OISClkB_p___drv;
wire reference_OISData_0__drv;
wire reference_OISData_0_p___drv;
wire reference_OISData_1__drv;
wire reference_OISData_1_p___drv;
wire reference_OISData_2__drv;
wire reference_OISData_2_p___drv;
wire reference_OISData_3__drv;
wire reference_OISData_3_p___drv;
wire reference_SubTask_0__drv;
wire reference_TWReq_03__drv;
wire reference_TWReq_11__drv;
wire reference_VBlank__drv;
wire reference_VSync__drv;
wire reference_XSyncEn_p___drv;
DispY_full_snapshot_experiment  reference(
.sys_clk(clk),
.AItem_0(stimulus[0] | reference_AItem_0__drv),
.AItem_1(stimulus[1] | reference_AItem_1__drv),
.AItem_2(stimulus[2] | reference_AItem_2__drv),
.AItem_3(stimulus[3] | reference_AItem_3__drv),
.AItem_4(stimulus[4] | reference_AItem_4__drv),
.AItem_5(stimulus[5] | reference_AItem_5__drv),
.AItem_6(stimulus[6] | reference_AItem_6__drv),
.AItem_7(stimulus[7] | reference_AItem_7__drv),
.AOff(stimulus[8] | reference_AOff__drv),
.BItem_0(stimulus[9] | reference_BItem_0__drv),
.BItem_1(stimulus[10] | reference_BItem_1__drv),
.BItem_2(stimulus[11] | reference_BItem_2__drv),
.BItem_3(stimulus[12] | reference_BItem_3__drv),
.BItem_4(stimulus[13] | reference_BItem_4__drv),
.BItem_5(stimulus[14] | reference_BItem_5__drv),
.BItem_6(stimulus[15] | reference_BItem_6__drv),
.BItem_7(stimulus[16] | reference_BItem_7__drv),
.BNTGtCT_p_b(stimulus[17]),
.BOff(stimulus[18] | reference_BOff__drv),
.Block(stimulus[19]),
.CLK_display_p_(stimulus[20]),
.CLKEnable_p_b(stimulus[21]),
.CursorData(stimulus[22] | reference_CursorData__drv),
.DMuxClk(stimulus[23]),
.DMuxData(stimulus[24] | reference_DMuxData__drv),
.Fout_00(stimulus[25]),
.Fout_01(stimulus[26]),
.Fout_02(stimulus[27]),
.Fout_03(stimulus[28]),
.Fout_04(stimulus[29]),
.Fout_05(stimulus[30]),
.Fout_06(stimulus[31]),
.Fout_07(stimulus[32]),
.Fout_08(stimulus[33]),
.Fout_09(stimulus[34]),
.Fout_10(stimulus[35]),
.Fout_11(stimulus[36]),
.Fout_12(stimulus[37]),
.Fout_13(stimulus[38]),
.Fout_14(stimulus[39]),
.Fout_15(stimulus[40]),
.FoutNext(stimulus[41]),
.FoutSubTask_0(stimulus[42]),
.FoutTask_0(stimulus[43]),
.FoutTask_1(stimulus[44]),
.FoutTask_2(stimulus[45]),
.FoutTask_3(stimulus[46]),
.GNDFour(stimulus[47] | reference_GNDFour__drv),
.HBlank(stimulus[48] | reference_HBlank__drv),
.HSync(stimulus[49] | reference_HSync__drv),
.HalfLine(stimulus[50] | reference_HalfLine__drv),
.IOB_00(stimulus[51] | reference_IOB_00__drv),
.IOB_01(stimulus[52]),
.IOB_02(stimulus[53]),
.IOB_03(stimulus[54]),
.IOB_04(stimulus[55]),
.IOB_05(stimulus[56]),
.IOB_06(stimulus[57]),
.IOB_07(stimulus[58]),
.IOB_08(stimulus[59]),
.IOB_09(stimulus[60]),
.IOB_10(stimulus[61]),
.IOB_11(stimulus[62]),
.IOB_12(stimulus[63]),
.IOB_13(stimulus[64]),
.IOB_14(stimulus[65]),
.IOB_15(stimulus[66] | reference_IOB_15__drv),
.IOHold(stimulus[67]),
.IOReset(stimulus[68]),
.IOin_p_(stimulus[69]),
.IOout_p_(stimulus[70]),
.KeyboardData(stimulus[71]),
.MemClkEnable_p_a(stimulus[72]),
.MemSH_p_(stimulus[73]),
.Next_0(stimulus[74]),
.Next_1(stimulus[75]),
.Next_2(stimulus[76]),
.Next_3(stimulus[77]),
.PixelClkVCO(stimulus[78]),
.RawPixelClk(stimulus[79]),
.TIOA_0(stimulus[80]),
.TIOA_1(stimulus[81]),
.TIOA_2(stimulus[82]),
.TIOA_3(stimulus[83]),
.TIOA_4(stimulus[84]),
.TIOA_5(stimulus[85]),
.TIOA_6(stimulus[86]),
.TIOA_7(stimulus[87]),
.TWReq_03(stimulus[88] | reference_TWReq_03__drv),
.TermIsLF(stimulus[89]),
.VBlank(stimulus[90] | reference_VBlank__drv),
.VSync(stimulus[91] | reference_VSync__drv),
.XHsync(stimulus[92]),
.XSyncEn_p_(stimulus[93] | reference_XSyncEn_p___drv),
.video_field(reference_video_field),
.n_24Bit__drv(reference_n_24Bit__drv),
.A8B2__drv(reference_A8B2__drv),
.AItem_0__drv(reference_AItem_0__drv),
.AItem_1__drv(reference_AItem_1__drv),
.AItem_2__drv(reference_AItem_2__drv),
.AItem_3__drv(reference_AItem_3__drv),
.AItem_4__drv(reference_AItem_4__drv),
.AItem_5__drv(reference_AItem_5__drv),
.AItem_6__drv(reference_AItem_6__drv),
.AItem_7__drv(reference_AItem_7__drv),
.AItemClkEn_p_b__drv(reference_AItemClkEn_p_b__drv),
.AOff__drv(reference_AOff__drv),
.AltoCSync_p___drv(reference_AltoCSync_p___drv),
.AltoHSync__drv(reference_AltoHSync__drv),
.AltoTTLVideo__drv(reference_AltoTTLVideo__drv),
.AltoVSync_p___drv(reference_AltoVSync_p___drv),
.BByPass__drv(reference_BByPass__drv),
.BItem_0__drv(reference_BItem_0__drv),
.BItem_1__drv(reference_BItem_1__drv),
.BItem_2__drv(reference_BItem_2__drv),
.BItem_3__drv(reference_BItem_3__drv),
.BItem_4__drv(reference_BItem_4__drv),
.BItem_5__drv(reference_BItem_5__drv),
.BItem_6__drv(reference_BItem_6__drv),
.BItem_7__drv(reference_BItem_7__drv),
.BItemClkEn_p_b__drv(reference_BItemClkEn_p_b__drv),
.BOff__drv(reference_BOff__drv),
.Crystal__drv(reference_Crystal__drv),
.CursorData__drv(reference_CursorData__drv),
.DMuxData__drv(reference_DMuxData__drv),
.GNDFour__drv(reference_GNDFour__drv),
.HBlank__drv(reference_HBlank__drv),
.HSync__drv(reference_HSync__drv),
.HalfLine__drv(reference_HalfLine__drv),
.IOB_00__drv(reference_IOB_00__drv),
.IOB_15__drv(reference_IOB_15__drv),
.IOB_16__drv(reference_IOB_16__drv),
.IOB_17__drv(reference_IOB_17__drv),
.IOut_m___drv(reference_IOut_m___drv),
.JamVBlank__drv(reference_JamVBlank__drv),
.OISClkA__drv(reference_OISClkA__drv),
.OISClkA_p___drv(reference_OISClkA_p___drv),
.OISClkB__drv(reference_OISClkB__drv),
.OISClkB_p___drv(reference_OISClkB_p___drv),
.OISData_0__drv(reference_OISData_0__drv),
.OISData_0_p___drv(reference_OISData_0_p___drv),
.OISData_1__drv(reference_OISData_1__drv),
.OISData_1_p___drv(reference_OISData_1_p___drv),
.OISData_2__drv(reference_OISData_2__drv),
.OISData_2_p___drv(reference_OISData_2_p___drv),
.OISData_3__drv(reference_OISData_3__drv),
.OISData_3_p___drv(reference_OISData_3_p___drv),
.SubTask_0__drv(reference_SubTask_0__drv),
.TWReq_03__drv(reference_TWReq_03__drv),
.TWReq_11__drv(reference_TWReq_11__drv),
.VBlank__drv(reference_VBlank__drv),
.VSync__drv(reference_VSync__drv),
.XSyncEn_p___drv(reference_XSyncEn_p___drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[18:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_XSyncEn_p___drv,reference_VSync__drv,reference_VBlank__drv,reference_TWReq_11__drv,reference_TWReq_03__drv,reference_SubTask_0__drv,reference_OISData_3_p___drv,reference_OISData_3__drv,reference_OISData_2_p___drv,reference_OISData_2__drv,reference_OISData_1_p___drv,reference_OISData_1__drv,reference_OISData_0_p___drv,reference_OISData_0__drv,reference_OISClkB_p___drv,reference_OISClkB__drv,reference_OISClkA_p___drv,reference_OISClkA__drv,reference_JamVBlank__drv,reference_IOut_m___drv,reference_IOB_17__drv,reference_IOB_16__drv,reference_IOB_15__drv,reference_IOB_00__drv,reference_HalfLine__drv,reference_HSync__drv,reference_HBlank__drv,reference_GNDFour__drv,reference_DMuxData__drv,reference_CursorData__drv,reference_Crystal__drv,reference_BOff__drv,reference_BItemClkEn_p_b__drv,reference_BItem_7__drv,reference_BItem_6__drv,reference_BItem_5__drv,reference_BItem_4__drv,reference_BItem_3__drv,reference_BItem_2__drv,reference_BItem_1__drv,reference_BItem_0__drv,reference_BByPass__drv,reference_AltoVSync_p___drv,reference_AltoTTLVideo__drv,reference_AltoHSync__drv,reference_AltoCSync_p___drv,reference_AOff__drv,reference_AItemClkEn_p_b__drv,reference_AItem_7__drv,reference_AItem_6__drv,reference_AItem_5__drv,reference_AItem_4__drv,reference_AItem_3__drv,reference_AItem_2__drv,reference_AItem_1__drv,reference_AItem_0__drv,reference_A8B2__drv,reference_n_24Bit__drv,reference_video_field};
assign reference_state[0+:1]=reference.clk1_p_Aa;
assign reference_state[1+:1]=reference.clk1_p_Ab;
assign reference_state[2+:1]=reference.clk1_p_Ca;
assign reference_state[3+:1]=reference.clk1_p_Cb;
assign reference_state[4+:1]=reference.clk1_p_Cc;
assign reference_state[5+:1]=reference.clk1_p_Da;
assign reference_state[6+:1]=reference.clk1_p_Db;
assign reference_state[7+:1]=reference.clk1_p_Dc;
assign reference_state[8+:1]=reference.display_word_12.saved_q;
assign reference_state[9+:1]=reference.display_word_13.saved_q;
assign reference_state[10+:1]=reference.display_word_14.saved_q;
assign reference_state[11+:32]=reference.u_a05.acc;
assign reference_state[43+:1]=reference.u_a05.osc;
assign reference_state[44+:1]=reference.u_a07.ck_d;
assign reference_state[45+:4]=reference.u_a07.q;
assign reference_state[49+:6]=reference.u_a07.setup_pre;
assign reference_state[55+:1]=reference.u_a09.cka_d;
assign reference_state[56+:1]=reference.u_a09.ckb_d;
assign reference_state[57+:1]=reference.u_a09.d_pre_a;
assign reference_state[58+:1]=reference.u_a09.d_pre_b;
assign reference_state[59+:1]=reference.u_a09.qa;
assign reference_state[60+:1]=reference.u_a09.qb;
assign reference_state[61+:1]=reference.u_a10.ck_d;
assign reference_state[62+:4]=reference.u_a10.d_pre;
assign reference_state[66+:4]=reference.u_a10.q;
assign reference_state[70+:1]=reference.u_a11.ck_d;
assign reference_state[71+:4]=reference.u_a11.d_pre;
assign reference_state[75+:4]=reference.u_a11.q;
assign reference_state[79+:1]=reference.u_a12.ck_d;
assign reference_state[80+:4]=reference.u_a12.d_pre;
assign reference_state[84+:4]=reference.u_a12.q;
assign reference_state[88+:1]=reference.u_a13.ck_d;
assign reference_state[89+:6]=reference.u_a13.d_pre;
assign reference_state[95+:6]=reference.u_a13.q;
assign reference_state[101+:1]=reference.u_a14.ck_d;
assign reference_state[102+:6]=reference.u_a14.d_pre;
assign reference_state[108+:6]=reference.u_a14.q;
assign reference_state[114+:1]=reference.u_a15.ck_d;
assign reference_state[115+:6]=reference.u_a15.d_pre;
assign reference_state[121+:6]=reference.u_a15.q;
assign reference_state[127+:1]=reference.u_a16.ck_d;
assign reference_state[128+:6]=reference.u_a16.d_pre;
assign reference_state[134+:6]=reference.u_a16.q;
assign reference_state[140+:1]=reference.u_a17.ck_d;
assign reference_state[141+:6]=reference.u_a17.d_pre;
assign reference_state[147+:6]=reference.u_a17.q;
assign reference_state[153+:1]=reference.u_a18.ck_d;
assign reference_state[154+:6]=reference.u_a18.d_pre;
assign reference_state[160+:6]=reference.u_a18.q;
assign reference_state[166+:1]=reference.u_b03.ck_d;
assign reference_state[167+:4]=reference.u_b03.q;
assign reference_state[171+:6]=reference.u_b03.setup_pre;
assign reference_state[177+:1]=reference.u_b04.ck_d;
assign reference_state[178+:4]=reference.u_b04.q;
assign reference_state[182+:6]=reference.u_b04.setup_pre;
assign reference_state[188+:1]=reference.u_b07.ck_d;
assign reference_state[189+:4]=reference.u_b07.q;
assign reference_state[193+:6]=reference.u_b07.setup_pre;
assign reference_state[199+:1]=reference.u_b09.cka_d;
assign reference_state[200+:1]=reference.u_b09.ckb_d;
assign reference_state[201+:1]=reference.u_b09.d_pre_a;
assign reference_state[202+:1]=reference.u_b09.d_pre_b;
assign reference_state[203+:1]=reference.u_b09.qa;
assign reference_state[204+:1]=reference.u_b09.qb;
assign reference_state[205+:1]=reference.u_b10.ck_d;
assign reference_state[206+:4]=reference.u_b10.d_pre;
assign reference_state[210+:4]=reference.u_b10.q;
assign reference_state[214+:1]=reference.u_b11.ck_d;
assign reference_state[215+:4]=reference.u_b11.d_pre;
assign reference_state[219+:4]=reference.u_b11.q;
assign reference_state[223+:1]=reference.u_b12.ck_d;
assign reference_state[224+:4]=reference.u_b12.d_pre;
assign reference_state[228+:4]=reference.u_b12.q;
assign reference_state[232+:1]=reference.u_b13.ck_d;
assign reference_state[233+:6]=reference.u_b13.d_pre;
assign reference_state[239+:6]=reference.u_b13.q;
assign reference_state[245+:1]=reference.u_b14.ck_d;
assign reference_state[246+:6]=reference.u_b14.d_pre;
assign reference_state[252+:6]=reference.u_b14.q;
assign reference_state[258+:1]=reference.u_b15.ck_d;
assign reference_state[259+:6]=reference.u_b15.d_pre;
assign reference_state[265+:6]=reference.u_b15.q;
assign reference_state[271+:1]=reference.u_b16.ck_d;
assign reference_state[272+:6]=reference.u_b16.d_pre;
assign reference_state[278+:6]=reference.u_b16.q;
assign reference_state[284+:1]=reference.u_b17.ck_d;
assign reference_state[285+:6]=reference.u_b17.d_pre;
assign reference_state[291+:6]=reference.u_b17.q;
assign reference_state[297+:1]=reference.u_b18.ck_d;
assign reference_state[298+:6]=reference.u_b18.d_pre;
assign reference_state[304+:6]=reference.u_b18.q;
assign reference_state[310+:1]=reference.u_b23.ck_d;
assign reference_state[311+:6]=reference.u_b23.d_pre;
assign reference_state[317+:6]=reference.u_b23.q;
assign reference_state[323+:1]=reference.u_c01.ck_d;
assign reference_state[324+:4]=reference.u_c01.jk_pre;
assign reference_state[328+:1]=reference.u_c01.qa;
assign reference_state[329+:1]=reference.u_c01.qb;
assign reference_state[330+:1]=reference.u_c03.ck_d;
assign reference_state[331+:6]=reference.u_c03.d_pre;
assign reference_state[337+:6]=reference.u_c03.q;
assign reference_state[343+:1]=reference.u_c05.ck_d;
assign reference_state[344+:4]=reference.u_c05.d_pre;
assign reference_state[348+:4]=reference.u_c05.q;
assign reference_state[352+:1]=reference.u_c08.ck_d;
assign reference_state[353+:4]=reference.u_c08.q;
assign reference_state[357+:6]=reference.u_c08.setup_pre;
assign reference_state[363+:1]=reference.u_c10.ck_d;
assign reference_state[364+:4]=reference.u_c10.d_pre;
assign reference_state[368+:4]=reference.u_c10.q;
assign reference_state[372+:1]=reference.u_c11.ck_d;
assign reference_state[373+:4]=reference.u_c11.d_pre;
assign reference_state[377+:4]=reference.u_c11.q;
assign reference_state[381+:1]=reference.u_c12.ck_d;
assign reference_state[382+:4]=reference.u_c12.d_pre;
assign reference_state[386+:4]=reference.u_c12.q;
assign reference_state[390+:1]=reference.u_c13.ck_d;
assign reference_state[391+:4]=reference.u_c13.d_pre;
assign reference_state[395+:4]=reference.u_c13.q;
assign reference_state[399+:1]=reference.u_c14.ck_d;
assign reference_state[400+:4]=reference.u_c14.d_pre;
assign reference_state[404+:4]=reference.u_c14.q;
assign reference_state[408+:1]=reference.u_c15.ck_d;
assign reference_state[409+:4]=reference.u_c15.d_pre;
assign reference_state[413+:4]=reference.u_c15.q;
assign reference_state[417+:1]=reference.u_c16.ck_d;
assign reference_state[418+:4]=reference.u_c16.d_pre;
assign reference_state[422+:4]=reference.u_c16.q;
assign reference_state[426+:1]=reference.u_c17.ck_d;
assign reference_state[427+:4]=reference.u_c17.d_pre;
assign reference_state[431+:4]=reference.u_c17.q;
assign reference_state[435+:1]=reference.u_c20.ck_d;
assign reference_state[436+:4]=reference.u_c20.d_pre;
assign reference_state[440+:4]=reference.u_c20.q;
assign reference_state[444+:1]=reference.u_c21.ck_d;
assign reference_state[445+:4]=reference.u_c21.d_pre;
assign reference_state[449+:4]=reference.u_c21.q;
assign reference_state[453+:1]=reference.u_c22.cka_d;
assign reference_state[454+:1]=reference.u_c22.ckb_d;
assign reference_state[455+:1]=reference.u_c22.d_pre_a;
assign reference_state[456+:1]=reference.u_c22.d_pre_b;
assign reference_state[457+:1]=reference.u_c22.qa;
assign reference_state[458+:1]=reference.u_c22.qb;
assign reference_state[459+:1]=reference.u_c23.cka_d;
assign reference_state[460+:1]=reference.u_c23.ckb_d;
assign reference_state[461+:1]=reference.u_c23.d_pre_a;
assign reference_state[462+:1]=reference.u_c23.d_pre_b;
assign reference_state[463+:1]=reference.u_c23.qa;
assign reference_state[464+:1]=reference.u_c23.qb;
assign reference_state[465+:1]=reference.u_d01.ck_d;
assign reference_state[466+:6]=reference.u_d01.d_pre;
assign reference_state[472+:6]=reference.u_d01.q;
assign reference_state[478+:1]=reference.u_d02.ck_d;
assign reference_state[479+:6]=reference.u_d02.d_pre;
assign reference_state[485+:6]=reference.u_d02.q;
assign reference_state[491+:1]=reference.u_d03.cka_d;
assign reference_state[492+:1]=reference.u_d03.ckb_d;
assign reference_state[493+:1]=reference.u_d03.d_pre_a;
assign reference_state[494+:1]=reference.u_d03.d_pre_b;
assign reference_state[495+:1]=reference.u_d03.qa;
assign reference_state[496+:1]=reference.u_d03.qb;
assign reference_state[497+:1]=reference.u_d05.ck_d;
assign reference_state[498+:4]=reference.u_d05.q;
assign reference_state[502+:6]=reference.u_d05.setup_pre;
assign reference_state[508+:1]=reference.u_d08.ck_d;
assign reference_state[509+:4]=reference.u_d08.q;
assign reference_state[513+:6]=reference.u_d08.setup_pre;
assign reference_state[519+:1]=reference.u_d09.cka_d;
assign reference_state[520+:1]=reference.u_d09.ckb_d;
assign reference_state[521+:1]=reference.u_d09.d_pre_a;
assign reference_state[522+:1]=reference.u_d09.d_pre_b;
assign reference_state[523+:1]=reference.u_d09.qa;
assign reference_state[524+:1]=reference.u_d09.qb;
assign reference_state[525+:1]=reference.u_d10.ck_d;
assign reference_state[526+:4]=reference.u_d10.d_pre;
assign reference_state[530+:4]=reference.u_d10.q;
assign reference_state[534+:1]=reference.u_d11.ck_d;
assign reference_state[535+:4]=reference.u_d11.d_pre;
assign reference_state[539+:4]=reference.u_d11.q;
assign reference_state[543+:1]=reference.u_d12.ck_d;
assign reference_state[544+:4]=reference.u_d12.d_pre;
assign reference_state[548+:4]=reference.u_d12.q;
assign reference_state[552+:1]=reference.u_d13.ck_d;
assign reference_state[553+:4]=reference.u_d13.d_pre;
assign reference_state[557+:4]=reference.u_d13.q;
assign reference_state[561+:1]=reference.u_d14.ck_d;
assign reference_state[562+:4]=reference.u_d14.d_pre;
assign reference_state[566+:4]=reference.u_d14.q;
assign reference_state[570+:1]=reference.u_d15.ck_d;
assign reference_state[571+:4]=reference.u_d15.d_pre;
assign reference_state[575+:4]=reference.u_d15.q;
assign reference_state[579+:1]=reference.u_d16.ck_d;
assign reference_state[580+:4]=reference.u_d16.d_pre;
assign reference_state[584+:4]=reference.u_d16.q;
assign reference_state[588+:1]=reference.u_d17.ck_d;
assign reference_state[589+:4]=reference.u_d17.d_pre;
assign reference_state[593+:4]=reference.u_d17.q;
assign reference_state[597+:1]=reference.u_d20.ck_d;
assign reference_state[598+:4]=reference.u_d20.d_pre;
assign reference_state[602+:4]=reference.u_d20.q;
assign reference_state[606+:1]=reference.u_d21.ck_d;
assign reference_state[607+:4]=reference.u_d21.d_pre;
assign reference_state[611+:4]=reference.u_d21.q;
assign reference_state[615+:1]=reference.u_d23.ck_d;
assign reference_state[616+:4]=reference.u_d23.jk_pre;
assign reference_state[620+:1]=reference.u_d23.qa;
assign reference_state[621+:1]=reference.u_d23.qb;
assign reference_state[622+:1]=reference.u_e01.ck_d;
assign reference_state[623+:6]=reference.u_e01.d_pre;
assign reference_state[629+:6]=reference.u_e01.q;
assign reference_state[635+:1]=reference.u_e04.ck_d;
assign reference_state[636+:6]=reference.u_e04.d_pre;
assign reference_state[642+:6]=reference.u_e04.q;
assign reference_state[648+:1]=reference.u_e09.ck_d;
assign reference_state[649+:4]=reference.u_e09.jk_pre;
assign reference_state[653+:1]=reference.u_e09.qa;
assign reference_state[654+:1]=reference.u_e09.qb;
assign reference_state[655+:1]=reference.u_e10.ck_d;
assign reference_state[656+:4]=reference.u_e10.d_pre;
assign reference_state[660+:4]=reference.u_e10.q;
assign reference_state[664+:1]=reference.u_e11.ck_d;
assign reference_state[665+:4]=reference.u_e11.d_pre;
assign reference_state[669+:4]=reference.u_e11.q;
assign reference_state[673+:1]=reference.u_e12.ck_d;
assign reference_state[674+:4]=reference.u_e12.d_pre;
assign reference_state[678+:4]=reference.u_e12.q;
assign reference_state[682+:1]=reference.u_e13.ck_d;
assign reference_state[683+:4]=reference.u_e13.d_pre;
assign reference_state[687+:4]=reference.u_e13.q;
assign reference_state[691+:1]=reference.u_e14.ck_d;
assign reference_state[692+:4]=reference.u_e14.d_pre;
assign reference_state[696+:4]=reference.u_e14.q;
assign reference_state[700+:1]=reference.u_e23.ck_d;
assign reference_state[701+:4]=reference.u_e23.q;
assign reference_state[705+:6]=reference.u_e23.setup_pre;
assign reference_state[711+:1]=reference.u_e24.ck_d;
assign reference_state[712+:4]=reference.u_e24.q;
assign reference_state[716+:6]=reference.u_e24.setup_pre;
assign reference_state[722+:1]=reference.u_f01.ck_d;
assign reference_state[723+:4]=reference.u_f01.jk_pre;
assign reference_state[727+:1]=reference.u_f01.qa;
assign reference_state[728+:1]=reference.u_f01.qb;
assign reference_state[729+:1]=reference.u_f09.ck_d;
assign reference_state[730+:4]=reference.u_f09.jk_pre;
assign reference_state[734+:1]=reference.u_f09.qa;
assign reference_state[735+:1]=reference.u_f09.qb;
assign reference_state[736+:1]=reference.u_f11.ck_d;
assign reference_state[737+:4]=reference.u_f11.d_pre;
assign reference_state[741+:4]=reference.u_f11.q;
assign reference_state[745+:1]=reference.u_f14.ck_d;
assign reference_state[746+:6]=reference.u_f14.d_pre;
assign reference_state[752+:6]=reference.u_f14.q;
assign reference_state[758+:1]=reference.u_f15.cka_d;
assign reference_state[759+:1]=reference.u_f15.ckb_d;
assign reference_state[760+:1]=reference.u_f15.d_pre_a;
assign reference_state[761+:1]=reference.u_f15.d_pre_b;
assign reference_state[762+:1]=reference.u_f15.qa;
assign reference_state[763+:1]=reference.u_f15.qb;
assign reference_state[764+:1]=reference.u_f23.ck_d;
assign reference_state[765+:4]=reference.u_f23.q;
assign reference_state[769+:6]=reference.u_f23.setup_pre;
assign reference_state[775+:1]=reference.u_f24.cka_d;
assign reference_state[776+:1]=reference.u_f24.ckb_d;
assign reference_state[777+:1]=reference.u_f24.d_pre_a;
assign reference_state[778+:1]=reference.u_f24.d_pre_b;
assign reference_state[779+:1]=reference.u_f24.qa;
assign reference_state[780+:1]=reference.u_f24.qb;
assign reference_state[781+:4]=reference.u_g03.a_lat;
assign reference_state[785+:1]=reference.u_g03.ce_lat;
assign reference_state[786+:4]=reference.u_g03.d_lat;
assign reference_state[790+:64]={reference.u_g03.mem[15],reference.u_g03.mem[14],reference.u_g03.mem[13],reference.u_g03.mem[12],reference.u_g03.mem[11],reference.u_g03.mem[10],reference.u_g03.mem[9],reference.u_g03.mem[8],reference.u_g03.mem[7],reference.u_g03.mem[6],reference.u_g03.mem[5],reference.u_g03.mem[4],reference.u_g03.mem[3],reference.u_g03.mem[2],reference.u_g03.mem[1],reference.u_g03.mem[0]};
assign reference_state[854+:1]=reference.u_g03.we_d;
assign reference_state[855+:1]=reference.u_g06.ck_d;
assign reference_state[856+:4]=reference.u_g06.q;
assign reference_state[860+:6]=reference.u_g06.setup_pre;
assign reference_state[866+:1]=reference.u_g07.ck_d;
assign reference_state[867+:4]=reference.u_g07.q;
assign reference_state[871+:6]=reference.u_g07.setup_pre;
assign reference_state[877+:1]=reference.u_g08.ck_d;
assign reference_state[878+:4]=reference.u_g08.jk_pre;
assign reference_state[882+:1]=reference.u_g08.qa;
assign reference_state[883+:1]=reference.u_g08.qb;
assign reference_state[884+:1]=reference.u_g09.ck_d;
assign reference_state[885+:4]=reference.u_g09.q;
assign reference_state[889+:6]=reference.u_g09.setup_pre;
assign reference_state[895+:1]=reference.u_g10.ck_d;
assign reference_state[896+:4]=reference.u_g10.q;
assign reference_state[900+:6]=reference.u_g10.setup_pre;
assign reference_state[906+:1]=reference.u_g15.cka_d;
assign reference_state[907+:1]=reference.u_g15.ckb_d;
assign reference_state[908+:1]=reference.u_g15.d_pre_a;
assign reference_state[909+:1]=reference.u_g15.d_pre_b;
assign reference_state[910+:1]=reference.u_g15.qa;
assign reference_state[911+:1]=reference.u_g15.qb;
assign reference_state[912+:4]=reference.u_h02.a_lat;
assign reference_state[916+:1]=reference.u_h02.ce_lat;
assign reference_state[917+:4]=reference.u_h02.d_lat;
assign reference_state[921+:64]={reference.u_h02.mem[15],reference.u_h02.mem[14],reference.u_h02.mem[13],reference.u_h02.mem[12],reference.u_h02.mem[11],reference.u_h02.mem[10],reference.u_h02.mem[9],reference.u_h02.mem[8],reference.u_h02.mem[7],reference.u_h02.mem[6],reference.u_h02.mem[5],reference.u_h02.mem[4],reference.u_h02.mem[3],reference.u_h02.mem[2],reference.u_h02.mem[1],reference.u_h02.mem[0]};
assign reference_state[985+:1]=reference.u_h02.we_d;
assign reference_state[986+:1]=reference.u_h03.ck_d;
assign reference_state[987+:4]=reference.u_h03.d_pre;
assign reference_state[991+:1]=reference.u_h03.dl_pre;
assign reference_state[992+:1]=reference.u_h03.dr_pre;
assign reference_state[993+:4]=reference.u_h03.q;
assign reference_state[997+:2]=reference.u_h03.s_pre;
assign reference_state[999+:1]=reference.u_h05.cka_d;
assign reference_state[1000+:1]=reference.u_h05.ckb_d;
assign reference_state[1001+:1]=reference.u_h05.d_pre_a;
assign reference_state[1002+:1]=reference.u_h05.d_pre_b;
assign reference_state[1003+:1]=reference.u_h05.qa;
assign reference_state[1004+:1]=reference.u_h05.qb;
assign reference_state[1005+:1]=reference.u_h06.ck_d;
assign reference_state[1006+:4]=reference.u_h06.q;
assign reference_state[1010+:6]=reference.u_h06.setup_pre;
assign reference_state[1016+:1]=reference.u_h07.ck_d;
assign reference_state[1017+:4]=reference.u_h07.q;
assign reference_state[1021+:6]=reference.u_h07.setup_pre;
assign reference_state[1027+:1]=reference.u_h08.ck_d;
assign reference_state[1028+:4]=reference.u_h08.q;
assign reference_state[1032+:6]=reference.u_h08.setup_pre;
assign reference_state[1038+:1]=reference.u_h09.ck_d;
assign reference_state[1039+:4]=reference.u_h09.jk_pre;
assign reference_state[1043+:1]=reference.u_h09.qa;
assign reference_state[1044+:1]=reference.u_h09.qb;
assign reference_state[1045+:1]=reference.u_h10.ck_d;
assign reference_state[1046+:4]=reference.u_h10.q;
assign reference_state[1050+:6]=reference.u_h10.setup_pre;
assign reference_state[1056+:1]=reference.u_h11.ck_d;
assign reference_state[1057+:4]=reference.u_h11.q;
assign reference_state[1061+:6]=reference.u_h11.setup_pre;
assign reference_state[1067+:1]=reference.u_h13.ck_d;
assign reference_state[1068+:4]=reference.u_h13.q;
assign reference_state[1072+:6]=reference.u_h13.setup_pre;
assign reference_state[1078+:1]=reference.u_h15.cka_d;
assign reference_state[1079+:1]=reference.u_h15.ckb_d;
assign reference_state[1080+:1]=reference.u_h15.d_pre_a;
assign reference_state[1081+:1]=reference.u_h15.d_pre_b;
assign reference_state[1082+:1]=reference.u_h15.qa;
assign reference_state[1083+:1]=reference.u_h15.qb;
assign reference_state[1084+:1]=reference.u_i01.ck_d;
assign reference_state[1085+:6]=reference.u_i01.d_pre;
assign reference_state[1091+:6]=reference.u_i01.q;
assign reference_state[1097+:1]=reference.u_i03.ck_d;
assign reference_state[1098+:4]=reference.u_i03.d_pre;
assign reference_state[1102+:1]=reference.u_i03.dl_pre;
assign reference_state[1103+:1]=reference.u_i03.dr_pre;
assign reference_state[1104+:4]=reference.u_i03.q;
assign reference_state[1108+:2]=reference.u_i03.s_pre;
assign reference_state[1110+:1]=reference.u_i04.ck_d;
assign reference_state[1111+:4]=reference.u_i04.q;
assign reference_state[1115+:6]=reference.u_i04.setup_pre;
assign reference_state[1121+:1]=reference.u_i05.ck_d;
assign reference_state[1122+:6]=reference.u_i05.d_pre;
assign reference_state[1128+:6]=reference.u_i05.q;
assign reference_state[1134+:1]=reference.u_i08.ck_d;
assign reference_state[1135+:4]=reference.u_i08.q;
assign reference_state[1139+:6]=reference.u_i08.setup_pre;
assign reference_state[1145+:1]=reference.u_i09.ck_d;
assign reference_state[1146+:4]=reference.u_i09.q;
assign reference_state[1150+:6]=reference.u_i09.setup_pre;
assign reference_state[1156+:1]=reference.u_i10.ck_d;
assign reference_state[1157+:4]=reference.u_i10.q;
assign reference_state[1161+:6]=reference.u_i10.setup_pre;
assign reference_state[1167+:1]=reference.u_i11.ck_d;
assign reference_state[1168+:4]=reference.u_i11.q;
assign reference_state[1172+:6]=reference.u_i11.setup_pre;
assign reference_state[1178+:1]=reference.u_i13.ck_d;
assign reference_state[1179+:4]=reference.u_i13.q;
assign reference_state[1183+:6]=reference.u_i13.setup_pre;
assign reference_state[1189+:1]=reference.u_i16.ck_d;
assign reference_state[1190+:4]=reference.u_i16.q;
assign reference_state[1194+:6]=reference.u_i16.setup_pre;
assign reference_state[1200+:1]=reference.u_i17.ck_d;
assign reference_state[1201+:4]=reference.u_i17.q;
assign reference_state[1205+:6]=reference.u_i17.setup_pre;
assign reference_state[1211+:1]=reference.u_i20.cka_d;
assign reference_state[1212+:1]=reference.u_i20.ckb_d;
assign reference_state[1213+:1]=reference.u_i20.d_pre_a;
assign reference_state[1214+:1]=reference.u_i20.d_pre_b;
assign reference_state[1215+:1]=reference.u_i20.qa;
assign reference_state[1216+:1]=reference.u_i20.qb;
assign reference_state[1217+:1]=reference.u_i21.cka_d;
assign reference_state[1218+:1]=reference.u_i21.ckb_d;
assign reference_state[1219+:1]=reference.u_i21.d_pre_a;
assign reference_state[1220+:1]=reference.u_i21.d_pre_b;
assign reference_state[1221+:1]=reference.u_i21.qa;
assign reference_state[1222+:1]=reference.u_i21.qb;
assign reference_state[1223+:1]=reference.u_i22.cka_d;
assign reference_state[1224+:1]=reference.u_i22.ckb_d;
assign reference_state[1225+:1]=reference.u_i22.d_pre_a;
assign reference_state[1226+:1]=reference.u_i22.d_pre_b;
assign reference_state[1227+:1]=reference.u_i22.qa;
assign reference_state[1228+:1]=reference.u_i22.qb;
assign reference_state[1229+:1]=reference.u_i23.ck_d;
assign reference_state[1230+:6]=reference.u_i23.d_pre;
assign reference_state[1236+:6]=reference.u_i23.q;
assign reference_state[1242+:1]=reference.u_i24.ck_d;
assign reference_state[1243+:6]=reference.u_i24.d_pre;
assign reference_state[1249+:6]=reference.u_i24.q;
assign reference_state[1255+:1]=reference.u_j01.ck_d;
assign reference_state[1256+:6]=reference.u_j01.d_pre;
assign reference_state[1262+:6]=reference.u_j01.q;
assign reference_state[1268+:4]=reference.u_j02.a_lat;
assign reference_state[1272+:1]=reference.u_j02.ce_lat;
assign reference_state[1273+:4]=reference.u_j02.d_lat;
assign reference_state[1277+:64]={reference.u_j02.mem[15],reference.u_j02.mem[14],reference.u_j02.mem[13],reference.u_j02.mem[12],reference.u_j02.mem[11],reference.u_j02.mem[10],reference.u_j02.mem[9],reference.u_j02.mem[8],reference.u_j02.mem[7],reference.u_j02.mem[6],reference.u_j02.mem[5],reference.u_j02.mem[4],reference.u_j02.mem[3],reference.u_j02.mem[2],reference.u_j02.mem[1],reference.u_j02.mem[0]};
assign reference_state[1341+:1]=reference.u_j02.we_d;
assign reference_state[1342+:1]=reference.u_j03.ck_d;
assign reference_state[1343+:4]=reference.u_j03.d_pre;
assign reference_state[1347+:1]=reference.u_j03.dl_pre;
assign reference_state[1348+:1]=reference.u_j03.dr_pre;
assign reference_state[1349+:4]=reference.u_j03.q;
assign reference_state[1353+:2]=reference.u_j03.s_pre;
assign reference_state[1355+:1]=reference.u_j04.ck_d;
assign reference_state[1356+:4]=reference.u_j04.q;
assign reference_state[1360+:6]=reference.u_j04.setup_pre;
assign reference_state[1366+:1]=reference.u_j08.ck_d;
assign reference_state[1367+:4]=reference.u_j08.q;
assign reference_state[1371+:6]=reference.u_j08.setup_pre;
assign reference_state[1377+:1]=reference.u_j09.ck_d;
assign reference_state[1378+:4]=reference.u_j09.q;
assign reference_state[1382+:6]=reference.u_j09.setup_pre;
assign reference_state[1388+:1]=reference.u_j10.ck_d;
assign reference_state[1389+:4]=reference.u_j10.q;
assign reference_state[1393+:6]=reference.u_j10.setup_pre;
assign reference_state[1399+:1]=reference.u_j11.ck_d;
assign reference_state[1400+:4]=reference.u_j11.q;
assign reference_state[1404+:6]=reference.u_j11.setup_pre;
assign reference_state[1410+:1]=reference.u_j13.ck_d;
assign reference_state[1411+:4]=reference.u_j13.q;
assign reference_state[1415+:6]=reference.u_j13.setup_pre;
assign reference_state[1421+:1]=reference.u_j15.ck_d;
assign reference_state[1422+:6]=reference.u_j15.d_pre;
assign reference_state[1428+:6]=reference.u_j15.q;
assign reference_state[1434+:1]=reference.u_j16.ck_d;
assign reference_state[1435+:4]=reference.u_j16.q;
assign reference_state[1439+:6]=reference.u_j16.setup_pre;
assign reference_state[1445+:1]=reference.u_j17.ck_d;
assign reference_state[1446+:4]=reference.u_j17.q;
assign reference_state[1450+:6]=reference.u_j17.setup_pre;
assign reference_state[1456+:1]=reference.u_j21.cka_d;
assign reference_state[1457+:1]=reference.u_j21.ckb_d;
assign reference_state[1458+:1]=reference.u_j21.d_pre_a;
assign reference_state[1459+:1]=reference.u_j21.d_pre_b;
assign reference_state[1460+:1]=reference.u_j21.qa;
assign reference_state[1461+:1]=reference.u_j21.qb;
assign reference_state[1462+:1]=reference.u_j23.ck_d;
assign reference_state[1463+:6]=reference.u_j23.d_pre;
assign reference_state[1469+:6]=reference.u_j23.q;
assign reference_state[1475+:1]=reference.u_j24.ck_d;
assign reference_state[1476+:6]=reference.u_j24.d_pre;
assign reference_state[1482+:6]=reference.u_j24.q;
assign reference_state[1488+:1]=reference.u_k01.ck_d;
assign reference_state[1489+:6]=reference.u_k01.d_pre;
assign reference_state[1495+:6]=reference.u_k01.q;
assign reference_state[1501+:1]=reference.u_k02.ck_d;
assign reference_state[1502+:4]=reference.u_k02.q;
assign reference_state[1506+:6]=reference.u_k02.setup_pre;
assign reference_state[1512+:1]=reference.u_k04.ck_d;
assign reference_state[1513+:4]=reference.u_k04.q;
assign reference_state[1517+:6]=reference.u_k04.setup_pre;
assign reference_state[1523+:1]=reference.u_k09.ck_d;
assign reference_state[1524+:4]=reference.u_k09.q;
assign reference_state[1528+:6]=reference.u_k09.setup_pre;
assign reference_state[1534+:1]=reference.u_k15.ck_d;
assign reference_state[1535+:6]=reference.u_k15.d_pre;
assign reference_state[1541+:6]=reference.u_k15.q;
assign reference_state[1547+:1]=reference.u_k16.ck_d;
assign reference_state[1548+:4]=reference.u_k16.q;
assign reference_state[1552+:6]=reference.u_k16.setup_pre;
assign reference_state[1558+:1]=reference.u_k17.ck_d;
assign reference_state[1559+:4]=reference.u_k17.q;
assign reference_state[1563+:6]=reference.u_k17.setup_pre;
assign reference_state[1569+:1]=reference.u_k22.ck_d;
assign reference_state[1570+:6]=reference.u_k22.d_pre;
assign reference_state[1576+:6]=reference.u_k22.q;
assign reference_state[1582+:1]=reference.u_k23.ck_d;
assign reference_state[1583+:6]=reference.u_k23.d_pre;
assign reference_state[1589+:6]=reference.u_k23.q;
assign reference_state[1595+:1]=reference.u_k24.ck_d;
assign reference_state[1596+:6]=reference.u_k24.d_pre;
assign reference_state[1602+:6]=reference.u_k24.q;
assign reference_state[1608+:1]=reference.u_l01.cka_d;
assign reference_state[1609+:1]=reference.u_l01.ckb_d;
assign reference_state[1610+:1]=reference.u_l01.d_pre_a;
assign reference_state[1611+:1]=reference.u_l01.d_pre_b;
assign reference_state[1612+:1]=reference.u_l01.qa;
assign reference_state[1613+:1]=reference.u_l01.qb;
assign reference_state[1614+:1]=reference.u_l03.ck_d;
assign reference_state[1615+:4]=reference.u_l03.d_pre;
assign reference_state[1619+:1]=reference.u_l03.dl_pre;
assign reference_state[1620+:1]=reference.u_l03.dr_pre;
assign reference_state[1621+:4]=reference.u_l03.q;
assign reference_state[1625+:2]=reference.u_l03.s_pre;
assign reference_state[1627+:1]=reference.u_l09.ck_d;
assign reference_state[1628+:6]=reference.u_l09.d_pre;
assign reference_state[1634+:6]=reference.u_l09.q;
assign reference_state[1640+:1]=reference.u_l10.ck_d;
assign reference_state[1641+:4]=reference.u_l10.q;
assign reference_state[1645+:6]=reference.u_l10.setup_pre;
assign reference_state[1651+:1]=reference.u_l16.ck_d;
assign reference_state[1652+:4]=reference.u_l16.q;
assign reference_state[1656+:6]=reference.u_l16.setup_pre;
assign reference_state[1662+:1]=reference.u_l17.ck_d;
assign reference_state[1663+:4]=reference.u_l17.q;
assign reference_state[1667+:6]=reference.u_l17.setup_pre;
assign reference_state[1673+:1]=reference.u_l19.ck_d;
assign reference_state[1674+:6]=reference.u_l19.d_pre;
assign reference_state[1680+:6]=reference.u_l19.q;
assign reference_state[1686+:1]=reference.u_l21.cka_d;
assign reference_state[1687+:1]=reference.u_l21.ckb_d;
assign reference_state[1688+:1]=reference.u_l21.d_pre_a;
assign reference_state[1689+:1]=reference.u_l21.d_pre_b;
assign reference_state[1690+:1]=reference.u_l21.qa;
assign reference_state[1691+:1]=reference.u_l21.qb;
assign reference_state[1692+:1]=reference.u_l22.ck_d;
assign reference_state[1693+:6]=reference.u_l22.d_pre;
assign reference_state[1699+:6]=reference.u_l22.q;
assign reference_probe[0+:1]=reference.display_word_12.mem[0+(probe_index%1024)];
assign reference_probe[1+:1]=reference.display_word_13.mem[0+(probe_index%1024)];
assign reference_probe[2+:1]=reference.display_word_14.mem[0+(probe_index%1024)];
assign reference_probe[3+:4]=reference.u_f04.mem[0+(probe_index%256)];
assign reference_probe[7+:4]=reference.u_g16.mem[0+(probe_index%256)];
assign reference_probe[11+:4]=reference.u_g18.mem[0+(probe_index%256)];
assign reference_probe[15+:4]=reference.u_g20.mem[0+(probe_index%256)];
assign reference_probe[19+:4]=reference.u_g22.mem[0+(probe_index%256)];
assign reference_probe[23+:4]=reference.u_h16.mem[0+(probe_index%256)];
assign reference_probe[27+:4]=reference.u_h18.mem[0+(probe_index%256)];
assign reference_probe[31+:4]=reference.u_h20.mem[0+(probe_index%256)];
assign reference_probe[35+:4]=reference.u_h22.mem[0+(probe_index%256)];
wire dut_video_field;
wire dut_n_24Bit__drv;
wire dut_A8B2__drv;
wire dut_AItem_0__drv;
wire dut_AItem_1__drv;
wire dut_AItem_2__drv;
wire dut_AItem_3__drv;
wire dut_AItem_4__drv;
wire dut_AItem_5__drv;
wire dut_AItem_6__drv;
wire dut_AItem_7__drv;
wire dut_AItemClkEn_p_b__drv;
wire dut_AOff__drv;
wire dut_AltoCSync_p___drv;
wire dut_AltoHSync__drv;
wire dut_AltoTTLVideo__drv;
wire dut_AltoVSync_p___drv;
wire dut_BByPass__drv;
wire dut_BItem_0__drv;
wire dut_BItem_1__drv;
wire dut_BItem_2__drv;
wire dut_BItem_3__drv;
wire dut_BItem_4__drv;
wire dut_BItem_5__drv;
wire dut_BItem_6__drv;
wire dut_BItem_7__drv;
wire dut_BItemClkEn_p_b__drv;
wire dut_BOff__drv;
wire dut_Crystal__drv;
wire dut_CursorData__drv;
wire dut_DMuxData__drv;
wire dut_GNDFour__drv;
wire dut_HBlank__drv;
wire dut_HSync__drv;
wire dut_HalfLine__drv;
wire dut_IOB_00__drv;
wire dut_IOB_15__drv;
wire dut_IOB_16__drv;
wire dut_IOB_17__drv;
wire dut_IOut_m___drv;
wire dut_JamVBlank__drv;
wire dut_OISClkA__drv;
wire dut_OISClkA_p___drv;
wire dut_OISClkB__drv;
wire dut_OISClkB_p___drv;
wire dut_OISData_0__drv;
wire dut_OISData_0_p___drv;
wire dut_OISData_1__drv;
wire dut_OISData_1_p___drv;
wire dut_OISData_2__drv;
wire dut_OISData_2_p___drv;
wire dut_OISData_3__drv;
wire dut_OISData_3_p___drv;
wire dut_SubTask_0__drv;
wire dut_TWReq_03__drv;
wire dut_TWReq_11__drv;
wire dut_VBlank__drv;
wire dut_VSync__drv;
wire dut_XSyncEn_p___drv;
dorado_serial_DispY  dut(
.sys_clk(clk),
.AItem_0(stimulus[0] | dut_AItem_0__drv),
.AItem_1(stimulus[1] | dut_AItem_1__drv),
.AItem_2(stimulus[2] | dut_AItem_2__drv),
.AItem_3(stimulus[3] | dut_AItem_3__drv),
.AItem_4(stimulus[4] | dut_AItem_4__drv),
.AItem_5(stimulus[5] | dut_AItem_5__drv),
.AItem_6(stimulus[6] | dut_AItem_6__drv),
.AItem_7(stimulus[7] | dut_AItem_7__drv),
.AOff(stimulus[8] | dut_AOff__drv),
.BItem_0(stimulus[9] | dut_BItem_0__drv),
.BItem_1(stimulus[10] | dut_BItem_1__drv),
.BItem_2(stimulus[11] | dut_BItem_2__drv),
.BItem_3(stimulus[12] | dut_BItem_3__drv),
.BItem_4(stimulus[13] | dut_BItem_4__drv),
.BItem_5(stimulus[14] | dut_BItem_5__drv),
.BItem_6(stimulus[15] | dut_BItem_6__drv),
.BItem_7(stimulus[16] | dut_BItem_7__drv),
.BNTGtCT_p_b(stimulus[17]),
.BOff(stimulus[18] | dut_BOff__drv),
.Block(stimulus[19]),
.CLK_display_p_(stimulus[20]),
.CLKEnable_p_b(stimulus[21]),
.CursorData(stimulus[22] | dut_CursorData__drv),
.DMuxClk(stimulus[23]),
.DMuxData(stimulus[24] | dut_DMuxData__drv),
.Fout_00(stimulus[25]),
.Fout_01(stimulus[26]),
.Fout_02(stimulus[27]),
.Fout_03(stimulus[28]),
.Fout_04(stimulus[29]),
.Fout_05(stimulus[30]),
.Fout_06(stimulus[31]),
.Fout_07(stimulus[32]),
.Fout_08(stimulus[33]),
.Fout_09(stimulus[34]),
.Fout_10(stimulus[35]),
.Fout_11(stimulus[36]),
.Fout_12(stimulus[37]),
.Fout_13(stimulus[38]),
.Fout_14(stimulus[39]),
.Fout_15(stimulus[40]),
.FoutNext(stimulus[41]),
.FoutSubTask_0(stimulus[42]),
.FoutTask_0(stimulus[43]),
.FoutTask_1(stimulus[44]),
.FoutTask_2(stimulus[45]),
.FoutTask_3(stimulus[46]),
.GNDFour(stimulus[47] | dut_GNDFour__drv),
.HBlank(stimulus[48] | dut_HBlank__drv),
.HSync(stimulus[49] | dut_HSync__drv),
.HalfLine(stimulus[50] | dut_HalfLine__drv),
.IOB_00(stimulus[51] | dut_IOB_00__drv),
.IOB_01(stimulus[52]),
.IOB_02(stimulus[53]),
.IOB_03(stimulus[54]),
.IOB_04(stimulus[55]),
.IOB_05(stimulus[56]),
.IOB_06(stimulus[57]),
.IOB_07(stimulus[58]),
.IOB_08(stimulus[59]),
.IOB_09(stimulus[60]),
.IOB_10(stimulus[61]),
.IOB_11(stimulus[62]),
.IOB_12(stimulus[63]),
.IOB_13(stimulus[64]),
.IOB_14(stimulus[65]),
.IOB_15(stimulus[66] | dut_IOB_15__drv),
.IOHold(stimulus[67]),
.IOReset(stimulus[68]),
.IOin_p_(stimulus[69]),
.IOout_p_(stimulus[70]),
.KeyboardData(stimulus[71]),
.MemClkEnable_p_a(stimulus[72]),
.MemSH_p_(stimulus[73]),
.Next_0(stimulus[74]),
.Next_1(stimulus[75]),
.Next_2(stimulus[76]),
.Next_3(stimulus[77]),
.PixelClkVCO(stimulus[78]),
.RawPixelClk(stimulus[79]),
.TIOA_0(stimulus[80]),
.TIOA_1(stimulus[81]),
.TIOA_2(stimulus[82]),
.TIOA_3(stimulus[83]),
.TIOA_4(stimulus[84]),
.TIOA_5(stimulus[85]),
.TIOA_6(stimulus[86]),
.TIOA_7(stimulus[87]),
.TWReq_03(stimulus[88] | dut_TWReq_03__drv),
.TermIsLF(stimulus[89]),
.VBlank(stimulus[90] | dut_VBlank__drv),
.VSync(stimulus[91] | dut_VSync__drv),
.XHsync(stimulus[92]),
.XSyncEn_p_(stimulus[93] | dut_XSyncEn_p___drv),
.video_field(dut_video_field),
.n_24Bit__drv(dut_n_24Bit__drv),
.A8B2__drv(dut_A8B2__drv),
.AItem_0__drv(dut_AItem_0__drv),
.AItem_1__drv(dut_AItem_1__drv),
.AItem_2__drv(dut_AItem_2__drv),
.AItem_3__drv(dut_AItem_3__drv),
.AItem_4__drv(dut_AItem_4__drv),
.AItem_5__drv(dut_AItem_5__drv),
.AItem_6__drv(dut_AItem_6__drv),
.AItem_7__drv(dut_AItem_7__drv),
.AItemClkEn_p_b__drv(dut_AItemClkEn_p_b__drv),
.AOff__drv(dut_AOff__drv),
.AltoCSync_p___drv(dut_AltoCSync_p___drv),
.AltoHSync__drv(dut_AltoHSync__drv),
.AltoTTLVideo__drv(dut_AltoTTLVideo__drv),
.AltoVSync_p___drv(dut_AltoVSync_p___drv),
.BByPass__drv(dut_BByPass__drv),
.BItem_0__drv(dut_BItem_0__drv),
.BItem_1__drv(dut_BItem_1__drv),
.BItem_2__drv(dut_BItem_2__drv),
.BItem_3__drv(dut_BItem_3__drv),
.BItem_4__drv(dut_BItem_4__drv),
.BItem_5__drv(dut_BItem_5__drv),
.BItem_6__drv(dut_BItem_6__drv),
.BItem_7__drv(dut_BItem_7__drv),
.BItemClkEn_p_b__drv(dut_BItemClkEn_p_b__drv),
.BOff__drv(dut_BOff__drv),
.Crystal__drv(dut_Crystal__drv),
.CursorData__drv(dut_CursorData__drv),
.DMuxData__drv(dut_DMuxData__drv),
.GNDFour__drv(dut_GNDFour__drv),
.HBlank__drv(dut_HBlank__drv),
.HSync__drv(dut_HSync__drv),
.HalfLine__drv(dut_HalfLine__drv),
.IOB_00__drv(dut_IOB_00__drv),
.IOB_15__drv(dut_IOB_15__drv),
.IOB_16__drv(dut_IOB_16__drv),
.IOB_17__drv(dut_IOB_17__drv),
.IOut_m___drv(dut_IOut_m___drv),
.JamVBlank__drv(dut_JamVBlank__drv),
.OISClkA__drv(dut_OISClkA__drv),
.OISClkA_p___drv(dut_OISClkA_p___drv),
.OISClkB__drv(dut_OISClkB__drv),
.OISClkB_p___drv(dut_OISClkB_p___drv),
.OISData_0__drv(dut_OISData_0__drv),
.OISData_0_p___drv(dut_OISData_0_p___drv),
.OISData_1__drv(dut_OISData_1__drv),
.OISData_1_p___drv(dut_OISData_1_p___drv),
.OISData_2__drv(dut_OISData_2__drv),
.OISData_2_p___drv(dut_OISData_2_p___drv),
.OISData_3__drv(dut_OISData_3__drv),
.OISData_3_p___drv(dut_OISData_3_p___drv),
.SubTask_0__drv(dut_SubTask_0__drv),
.TWReq_03__drv(dut_TWReq_03__drv),
.TWReq_11__drv(dut_TWReq_11__drv),
.VBlank__drv(dut_VBlank__drv),
.VSync__drv(dut_VSync__drv),
.XSyncEn_p___drv(dut_XSyncEn_p___drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[18:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_XSyncEn_p___drv,dut_VSync__drv,dut_VBlank__drv,dut_TWReq_11__drv,dut_TWReq_03__drv,dut_SubTask_0__drv,dut_OISData_3_p___drv,dut_OISData_3__drv,dut_OISData_2_p___drv,dut_OISData_2__drv,dut_OISData_1_p___drv,dut_OISData_1__drv,dut_OISData_0_p___drv,dut_OISData_0__drv,dut_OISClkB_p___drv,dut_OISClkB__drv,dut_OISClkA_p___drv,dut_OISClkA__drv,dut_JamVBlank__drv,dut_IOut_m___drv,dut_IOB_17__drv,dut_IOB_16__drv,dut_IOB_15__drv,dut_IOB_00__drv,dut_HalfLine__drv,dut_HSync__drv,dut_HBlank__drv,dut_GNDFour__drv,dut_DMuxData__drv,dut_CursorData__drv,dut_Crystal__drv,dut_BOff__drv,dut_BItemClkEn_p_b__drv,dut_BItem_7__drv,dut_BItem_6__drv,dut_BItem_5__drv,dut_BItem_4__drv,dut_BItem_3__drv,dut_BItem_2__drv,dut_BItem_1__drv,dut_BItem_0__drv,dut_BByPass__drv,dut_AltoVSync_p___drv,dut_AltoTTLVideo__drv,dut_AltoHSync__drv,dut_AltoCSync_p___drv,dut_AOff__drv,dut_AItemClkEn_p_b__drv,dut_AItem_7__drv,dut_AItem_6__drv,dut_AItem_5__drv,dut_AItem_4__drv,dut_AItem_3__drv,dut_AItem_2__drv,dut_AItem_1__drv,dut_AItem_0__drv,dut_A8B2__drv,dut_n_24Bit__drv,dut_video_field};
assign dut_state[0+:1]=dut.clk1_p_Aa;
assign dut_state[1+:1]=dut.clk1_p_Ab;
assign dut_state[2+:1]=dut.clk1_p_Ca;
assign dut_state[3+:1]=dut.clk1_p_Cb;
assign dut_state[4+:1]=dut.clk1_p_Cc;
assign dut_state[5+:1]=dut.clk1_p_Da;
assign dut_state[6+:1]=dut.clk1_p_Db;
assign dut_state[7+:1]=dut.clk1_p_Dc;
assign dut_state[8+:1]=dut.display_word_12.saved_q;
assign dut_state[9+:1]=dut.display_word_13.saved_q;
assign dut_state[10+:1]=dut.display_word_14.saved_q;
assign dut_state[11+:32]=dut.u_a05.acc;
assign dut_state[43+:1]=dut.u_a05.osc;
assign dut_state[44+:1]=dut.u_a07.ck_d;
assign dut_state[45+:4]=dut.u_a07.q;
assign dut_state[49+:6]=dut.u_a07.setup_pre;
assign dut_state[55+:1]=dut.u_a09.cka_d;
assign dut_state[56+:1]=dut.u_a09.ckb_d;
assign dut_state[57+:1]=dut.u_a09.d_pre_a;
assign dut_state[58+:1]=dut.u_a09.d_pre_b;
assign dut_state[59+:1]=dut.u_a09.qa;
assign dut_state[60+:1]=dut.u_a09.qb;
assign dut_state[61+:1]=dut.u_a10.ck_d;
assign dut_state[62+:4]=dut.u_a10.d_pre;
assign dut_state[66+:4]=dut.u_a10.q;
assign dut_state[70+:1]=dut.u_a11.ck_d;
assign dut_state[71+:4]=dut.u_a11.d_pre;
assign dut_state[75+:4]=dut.u_a11.q;
assign dut_state[79+:1]=dut.u_a12.ck_d;
assign dut_state[80+:4]=dut.u_a12.d_pre;
assign dut_state[84+:4]=dut.u_a12.q;
assign dut_state[88+:1]=dut.u_a13.ck_d;
assign dut_state[89+:6]=dut.u_a13.d_pre;
assign dut_state[95+:6]=dut.u_a13.q;
assign dut_state[101+:1]=dut.u_a14.ck_d;
assign dut_state[102+:6]=dut.u_a14.d_pre;
assign dut_state[108+:6]=dut.u_a14.q;
assign dut_state[114+:1]=dut.u_a15.ck_d;
assign dut_state[115+:6]=dut.u_a15.d_pre;
assign dut_state[121+:6]=dut.u_a15.q;
assign dut_state[127+:1]=dut.u_a16.ck_d;
assign dut_state[128+:6]=dut.u_a16.d_pre;
assign dut_state[134+:6]=dut.u_a16.q;
assign dut_state[140+:1]=dut.u_a17.ck_d;
assign dut_state[141+:6]=dut.u_a17.d_pre;
assign dut_state[147+:6]=dut.u_a17.q;
assign dut_state[153+:1]=dut.u_a18.ck_d;
assign dut_state[154+:6]=dut.u_a18.d_pre;
assign dut_state[160+:6]=dut.u_a18.q;
assign dut_state[166+:1]=dut.u_b03.ck_d;
assign dut_state[167+:4]=dut.u_b03.q;
assign dut_state[171+:6]=dut.u_b03.setup_pre;
assign dut_state[177+:1]=dut.u_b04.ck_d;
assign dut_state[178+:4]=dut.u_b04.q;
assign dut_state[182+:6]=dut.u_b04.setup_pre;
assign dut_state[188+:1]=dut.u_b07.ck_d;
assign dut_state[189+:4]=dut.u_b07.q;
assign dut_state[193+:6]=dut.u_b07.setup_pre;
assign dut_state[199+:1]=dut.u_b09.cka_d;
assign dut_state[200+:1]=dut.u_b09.ckb_d;
assign dut_state[201+:1]=dut.u_b09.d_pre_a;
assign dut_state[202+:1]=dut.u_b09.d_pre_b;
assign dut_state[203+:1]=dut.u_b09.qa;
assign dut_state[204+:1]=dut.u_b09.qb;
assign dut_state[205+:1]=dut.u_b10.ck_d;
assign dut_state[206+:4]=dut.u_b10.d_pre;
assign dut_state[210+:4]=dut.u_b10.q;
assign dut_state[214+:1]=dut.u_b11.ck_d;
assign dut_state[215+:4]=dut.u_b11.d_pre;
assign dut_state[219+:4]=dut.u_b11.q;
assign dut_state[223+:1]=dut.u_b12.ck_d;
assign dut_state[224+:4]=dut.u_b12.d_pre;
assign dut_state[228+:4]=dut.u_b12.q;
assign dut_state[232+:1]=dut.u_b13.ck_d;
assign dut_state[233+:6]=dut.u_b13.d_pre;
assign dut_state[239+:6]=dut.u_b13.q;
assign dut_state[245+:1]=dut.u_b14.ck_d;
assign dut_state[246+:6]=dut.u_b14.d_pre;
assign dut_state[252+:6]=dut.u_b14.q;
assign dut_state[258+:1]=dut.u_b15.ck_d;
assign dut_state[259+:6]=dut.u_b15.d_pre;
assign dut_state[265+:6]=dut.u_b15.q;
assign dut_state[271+:1]=dut.u_b16.ck_d;
assign dut_state[272+:6]=dut.u_b16.d_pre;
assign dut_state[278+:6]=dut.u_b16.q;
assign dut_state[284+:1]=dut.u_b17.ck_d;
assign dut_state[285+:6]=dut.u_b17.d_pre;
assign dut_state[291+:6]=dut.u_b17.q;
assign dut_state[297+:1]=dut.u_b18.ck_d;
assign dut_state[298+:6]=dut.u_b18.d_pre;
assign dut_state[304+:6]=dut.u_b18.q;
assign dut_state[310+:1]=dut.u_b23.ck_d;
assign dut_state[311+:6]=dut.u_b23.d_pre;
assign dut_state[317+:6]=dut.u_b23.q;
assign dut_state[323+:1]=dut.u_c01.ck_d;
assign dut_state[324+:4]=dut.u_c01.jk_pre;
assign dut_state[328+:1]=dut.u_c01.qa;
assign dut_state[329+:1]=dut.u_c01.qb;
assign dut_state[330+:1]=dut.u_c03.ck_d;
assign dut_state[331+:6]=dut.u_c03.d_pre;
assign dut_state[337+:6]=dut.u_c03.q;
assign dut_state[343+:1]=dut.u_c05.ck_d;
assign dut_state[344+:4]=dut.u_c05.d_pre;
assign dut_state[348+:4]=dut.u_c05.q;
assign dut_state[352+:1]=dut.u_c08.ck_d;
assign dut_state[353+:4]=dut.u_c08.q;
assign dut_state[357+:6]=dut.u_c08.setup_pre;
assign dut_state[363+:1]=dut.u_c10.ck_d;
assign dut_state[364+:4]=dut.u_c10.d_pre;
assign dut_state[368+:4]=dut.u_c10.q;
assign dut_state[372+:1]=dut.u_c11.ck_d;
assign dut_state[373+:4]=dut.u_c11.d_pre;
assign dut_state[377+:4]=dut.u_c11.q;
assign dut_state[381+:1]=dut.u_c12.ck_d;
assign dut_state[382+:4]=dut.u_c12.d_pre;
assign dut_state[386+:4]=dut.u_c12.q;
assign dut_state[390+:1]=dut.u_c13.ck_d;
assign dut_state[391+:4]=dut.u_c13.d_pre;
assign dut_state[395+:4]=dut.u_c13.q;
assign dut_state[399+:1]=dut.u_c14.ck_d;
assign dut_state[400+:4]=dut.u_c14.d_pre;
assign dut_state[404+:4]=dut.u_c14.q;
assign dut_state[408+:1]=dut.u_c15.ck_d;
assign dut_state[409+:4]=dut.u_c15.d_pre;
assign dut_state[413+:4]=dut.u_c15.q;
assign dut_state[417+:1]=dut.u_c16.ck_d;
assign dut_state[418+:4]=dut.u_c16.d_pre;
assign dut_state[422+:4]=dut.u_c16.q;
assign dut_state[426+:1]=dut.u_c17.ck_d;
assign dut_state[427+:4]=dut.u_c17.d_pre;
assign dut_state[431+:4]=dut.u_c17.q;
assign dut_state[435+:1]=dut.u_c20.ck_d;
assign dut_state[436+:4]=dut.u_c20.d_pre;
assign dut_state[440+:4]=dut.u_c20.q;
assign dut_state[444+:1]=dut.u_c21.ck_d;
assign dut_state[445+:4]=dut.u_c21.d_pre;
assign dut_state[449+:4]=dut.u_c21.q;
assign dut_state[453+:1]=dut.u_c22.cka_d;
assign dut_state[454+:1]=dut.u_c22.ckb_d;
assign dut_state[455+:1]=dut.u_c22.d_pre_a;
assign dut_state[456+:1]=dut.u_c22.d_pre_b;
assign dut_state[457+:1]=dut.u_c22.qa;
assign dut_state[458+:1]=dut.u_c22.qb;
assign dut_state[459+:1]=dut.u_c23.cka_d;
assign dut_state[460+:1]=dut.u_c23.ckb_d;
assign dut_state[461+:1]=dut.u_c23.d_pre_a;
assign dut_state[462+:1]=dut.u_c23.d_pre_b;
assign dut_state[463+:1]=dut.u_c23.qa;
assign dut_state[464+:1]=dut.u_c23.qb;
assign dut_state[465+:1]=dut.u_d01.ck_d;
assign dut_state[466+:6]=dut.u_d01.d_pre;
assign dut_state[472+:6]=dut.u_d01.q;
assign dut_state[478+:1]=dut.u_d02.ck_d;
assign dut_state[479+:6]=dut.u_d02.d_pre;
assign dut_state[485+:6]=dut.u_d02.q;
assign dut_state[491+:1]=dut.u_d03.cka_d;
assign dut_state[492+:1]=dut.u_d03.ckb_d;
assign dut_state[493+:1]=dut.u_d03.d_pre_a;
assign dut_state[494+:1]=dut.u_d03.d_pre_b;
assign dut_state[495+:1]=dut.u_d03.qa;
assign dut_state[496+:1]=dut.u_d03.qb;
assign dut_state[497+:1]=dut.u_d05.ck_d;
assign dut_state[498+:4]=dut.u_d05.q;
assign dut_state[502+:6]=dut.u_d05.setup_pre;
assign dut_state[508+:1]=dut.u_d08.ck_d;
assign dut_state[509+:4]=dut.u_d08.q;
assign dut_state[513+:6]=dut.u_d08.setup_pre;
assign dut_state[519+:1]=dut.u_d09.cka_d;
assign dut_state[520+:1]=dut.u_d09.ckb_d;
assign dut_state[521+:1]=dut.u_d09.d_pre_a;
assign dut_state[522+:1]=dut.u_d09.d_pre_b;
assign dut_state[523+:1]=dut.u_d09.qa;
assign dut_state[524+:1]=dut.u_d09.qb;
assign dut_state[525+:1]=dut.u_d10.ck_d;
assign dut_state[526+:4]=dut.u_d10.d_pre;
assign dut_state[530+:4]=dut.u_d10.q;
assign dut_state[534+:1]=dut.u_d11.ck_d;
assign dut_state[535+:4]=dut.u_d11.d_pre;
assign dut_state[539+:4]=dut.u_d11.q;
assign dut_state[543+:1]=dut.u_d12.ck_d;
assign dut_state[544+:4]=dut.u_d12.d_pre;
assign dut_state[548+:4]=dut.u_d12.q;
assign dut_state[552+:1]=dut.u_d13.ck_d;
assign dut_state[553+:4]=dut.u_d13.d_pre;
assign dut_state[557+:4]=dut.u_d13.q;
assign dut_state[561+:1]=dut.u_d14.ck_d;
assign dut_state[562+:4]=dut.u_d14.d_pre;
assign dut_state[566+:4]=dut.u_d14.q;
assign dut_state[570+:1]=dut.u_d15.ck_d;
assign dut_state[571+:4]=dut.u_d15.d_pre;
assign dut_state[575+:4]=dut.u_d15.q;
assign dut_state[579+:1]=dut.u_d16.ck_d;
assign dut_state[580+:4]=dut.u_d16.d_pre;
assign dut_state[584+:4]=dut.u_d16.q;
assign dut_state[588+:1]=dut.u_d17.ck_d;
assign dut_state[589+:4]=dut.u_d17.d_pre;
assign dut_state[593+:4]=dut.u_d17.q;
assign dut_state[597+:1]=dut.u_d20.ck_d;
assign dut_state[598+:4]=dut.u_d20.d_pre;
assign dut_state[602+:4]=dut.u_d20.q;
assign dut_state[606+:1]=dut.u_d21.ck_d;
assign dut_state[607+:4]=dut.u_d21.d_pre;
assign dut_state[611+:4]=dut.u_d21.q;
assign dut_state[615+:1]=dut.u_d23.ck_d;
assign dut_state[616+:4]=dut.u_d23.jk_pre;
assign dut_state[620+:1]=dut.u_d23.qa;
assign dut_state[621+:1]=dut.u_d23.qb;
assign dut_state[622+:1]=dut.u_e01.ck_d;
assign dut_state[623+:6]=dut.u_e01.d_pre;
assign dut_state[629+:6]=dut.u_e01.q;
assign dut_state[635+:1]=dut.u_e04.ck_d;
assign dut_state[636+:6]=dut.u_e04.d_pre;
assign dut_state[642+:6]=dut.u_e04.q;
assign dut_state[648+:1]=dut.u_e09.ck_d;
assign dut_state[649+:4]=dut.u_e09.jk_pre;
assign dut_state[653+:1]=dut.u_e09.qa;
assign dut_state[654+:1]=dut.u_e09.qb;
assign dut_state[655+:1]=dut.u_e10.ck_d;
assign dut_state[656+:4]=dut.u_e10.d_pre;
assign dut_state[660+:4]=dut.u_e10.q;
assign dut_state[664+:1]=dut.u_e11.ck_d;
assign dut_state[665+:4]=dut.u_e11.d_pre;
assign dut_state[669+:4]=dut.u_e11.q;
assign dut_state[673+:1]=dut.u_e12.ck_d;
assign dut_state[674+:4]=dut.u_e12.d_pre;
assign dut_state[678+:4]=dut.u_e12.q;
assign dut_state[682+:1]=dut.u_e13.ck_d;
assign dut_state[683+:4]=dut.u_e13.d_pre;
assign dut_state[687+:4]=dut.u_e13.q;
assign dut_state[691+:1]=dut.u_e14.ck_d;
assign dut_state[692+:4]=dut.u_e14.d_pre;
assign dut_state[696+:4]=dut.u_e14.q;
assign dut_state[700+:1]=dut.u_e23.ck_d;
assign dut_state[701+:4]=dut.u_e23.q;
assign dut_state[705+:6]=dut.u_e23.setup_pre;
assign dut_state[711+:1]=dut.u_e24.ck_d;
assign dut_state[712+:4]=dut.u_e24.q;
assign dut_state[716+:6]=dut.u_e24.setup_pre;
assign dut_state[722+:1]=dut.u_f01.ck_d;
assign dut_state[723+:4]=dut.u_f01.jk_pre;
assign dut_state[727+:1]=dut.u_f01.qa;
assign dut_state[728+:1]=dut.u_f01.qb;
assign dut_state[729+:1]=dut.u_f09.ck_d;
assign dut_state[730+:4]=dut.u_f09.jk_pre;
assign dut_state[734+:1]=dut.u_f09.qa;
assign dut_state[735+:1]=dut.u_f09.qb;
assign dut_state[736+:1]=dut.u_f11.ck_d;
assign dut_state[737+:4]=dut.u_f11.d_pre;
assign dut_state[741+:4]=dut.u_f11.q;
assign dut_state[745+:1]=dut.u_f14.ck_d;
assign dut_state[746+:6]=dut.u_f14.d_pre;
assign dut_state[752+:6]=dut.u_f14.q;
assign dut_state[758+:1]=dut.u_f15.cka_d;
assign dut_state[759+:1]=dut.u_f15.ckb_d;
assign dut_state[760+:1]=dut.u_f15.d_pre_a;
assign dut_state[761+:1]=dut.u_f15.d_pre_b;
assign dut_state[762+:1]=dut.u_f15.qa;
assign dut_state[763+:1]=dut.u_f15.qb;
assign dut_state[764+:1]=dut.u_f23.ck_d;
assign dut_state[765+:4]=dut.u_f23.q;
assign dut_state[769+:6]=dut.u_f23.setup_pre;
assign dut_state[775+:1]=dut.u_f24.cka_d;
assign dut_state[776+:1]=dut.u_f24.ckb_d;
assign dut_state[777+:1]=dut.u_f24.d_pre_a;
assign dut_state[778+:1]=dut.u_f24.d_pre_b;
assign dut_state[779+:1]=dut.u_f24.qa;
assign dut_state[780+:1]=dut.u_f24.qb;
assign dut_state[781+:4]=dut.u_g03.a_lat;
assign dut_state[785+:1]=dut.u_g03.ce_lat;
assign dut_state[786+:4]=dut.u_g03.d_lat;
assign dut_state[790+:64]={dut.u_g03.mem[15],dut.u_g03.mem[14],dut.u_g03.mem[13],dut.u_g03.mem[12],dut.u_g03.mem[11],dut.u_g03.mem[10],dut.u_g03.mem[9],dut.u_g03.mem[8],dut.u_g03.mem[7],dut.u_g03.mem[6],dut.u_g03.mem[5],dut.u_g03.mem[4],dut.u_g03.mem[3],dut.u_g03.mem[2],dut.u_g03.mem[1],dut.u_g03.mem[0]};
assign dut_state[854+:1]=dut.u_g03.we_d;
assign dut_state[855+:1]=dut.u_g06.ck_d;
assign dut_state[856+:4]=dut.u_g06.q;
assign dut_state[860+:6]=dut.u_g06.setup_pre;
assign dut_state[866+:1]=dut.u_g07.ck_d;
assign dut_state[867+:4]=dut.u_g07.q;
assign dut_state[871+:6]=dut.u_g07.setup_pre;
assign dut_state[877+:1]=dut.u_g08.ck_d;
assign dut_state[878+:4]=dut.u_g08.jk_pre;
assign dut_state[882+:1]=dut.u_g08.qa;
assign dut_state[883+:1]=dut.u_g08.qb;
assign dut_state[884+:1]=dut.u_g09.ck_d;
assign dut_state[885+:4]=dut.u_g09.q;
assign dut_state[889+:6]=dut.u_g09.setup_pre;
assign dut_state[895+:1]=dut.u_g10.ck_d;
assign dut_state[896+:4]=dut.u_g10.q;
assign dut_state[900+:6]=dut.u_g10.setup_pre;
assign dut_state[906+:1]=dut.u_g15.cka_d;
assign dut_state[907+:1]=dut.u_g15.ckb_d;
assign dut_state[908+:1]=dut.u_g15.d_pre_a;
assign dut_state[909+:1]=dut.u_g15.d_pre_b;
assign dut_state[910+:1]=dut.u_g15.qa;
assign dut_state[911+:1]=dut.u_g15.qb;
assign dut_state[912+:4]=dut.u_h02.a_lat;
assign dut_state[916+:1]=dut.u_h02.ce_lat;
assign dut_state[917+:4]=dut.u_h02.d_lat;
assign dut_state[921+:64]={dut.u_h02.mem[15],dut.u_h02.mem[14],dut.u_h02.mem[13],dut.u_h02.mem[12],dut.u_h02.mem[11],dut.u_h02.mem[10],dut.u_h02.mem[9],dut.u_h02.mem[8],dut.u_h02.mem[7],dut.u_h02.mem[6],dut.u_h02.mem[5],dut.u_h02.mem[4],dut.u_h02.mem[3],dut.u_h02.mem[2],dut.u_h02.mem[1],dut.u_h02.mem[0]};
assign dut_state[985+:1]=dut.u_h02.we_d;
assign dut_state[986+:1]=dut.u_h03.ck_d;
assign dut_state[987+:4]=dut.u_h03.d_pre;
assign dut_state[991+:1]=dut.u_h03.dl_pre;
assign dut_state[992+:1]=dut.u_h03.dr_pre;
assign dut_state[993+:4]=dut.u_h03.q;
assign dut_state[997+:2]=dut.u_h03.s_pre;
assign dut_state[999+:1]=dut.u_h05.cka_d;
assign dut_state[1000+:1]=dut.u_h05.ckb_d;
assign dut_state[1001+:1]=dut.u_h05.d_pre_a;
assign dut_state[1002+:1]=dut.u_h05.d_pre_b;
assign dut_state[1003+:1]=dut.u_h05.qa;
assign dut_state[1004+:1]=dut.u_h05.qb;
assign dut_state[1005+:1]=dut.u_h06.ck_d;
assign dut_state[1006+:4]=dut.u_h06.q;
assign dut_state[1010+:6]=dut.u_h06.setup_pre;
assign dut_state[1016+:1]=dut.u_h07.ck_d;
assign dut_state[1017+:4]=dut.u_h07.q;
assign dut_state[1021+:6]=dut.u_h07.setup_pre;
assign dut_state[1027+:1]=dut.u_h08.ck_d;
assign dut_state[1028+:4]=dut.u_h08.q;
assign dut_state[1032+:6]=dut.u_h08.setup_pre;
assign dut_state[1038+:1]=dut.u_h09.ck_d;
assign dut_state[1039+:4]=dut.u_h09.jk_pre;
assign dut_state[1043+:1]=dut.u_h09.qa;
assign dut_state[1044+:1]=dut.u_h09.qb;
assign dut_state[1045+:1]=dut.u_h10.ck_d;
assign dut_state[1046+:4]=dut.u_h10.q;
assign dut_state[1050+:6]=dut.u_h10.setup_pre;
assign dut_state[1056+:1]=dut.u_h11.ck_d;
assign dut_state[1057+:4]=dut.u_h11.q;
assign dut_state[1061+:6]=dut.u_h11.setup_pre;
assign dut_state[1067+:1]=dut.u_h13.ck_d;
assign dut_state[1068+:4]=dut.u_h13.q;
assign dut_state[1072+:6]=dut.u_h13.setup_pre;
assign dut_state[1078+:1]=dut.u_h15.cka_d;
assign dut_state[1079+:1]=dut.u_h15.ckb_d;
assign dut_state[1080+:1]=dut.u_h15.d_pre_a;
assign dut_state[1081+:1]=dut.u_h15.d_pre_b;
assign dut_state[1082+:1]=dut.u_h15.qa;
assign dut_state[1083+:1]=dut.u_h15.qb;
assign dut_state[1084+:1]=dut.u_i01.ck_d;
assign dut_state[1085+:6]=dut.u_i01.d_pre;
assign dut_state[1091+:6]=dut.u_i01.q;
assign dut_state[1097+:1]=dut.u_i03.ck_d;
assign dut_state[1098+:4]=dut.u_i03.d_pre;
assign dut_state[1102+:1]=dut.u_i03.dl_pre;
assign dut_state[1103+:1]=dut.u_i03.dr_pre;
assign dut_state[1104+:4]=dut.u_i03.q;
assign dut_state[1108+:2]=dut.u_i03.s_pre;
assign dut_state[1110+:1]=dut.u_i04.ck_d;
assign dut_state[1111+:4]=dut.u_i04.q;
assign dut_state[1115+:6]=dut.u_i04.setup_pre;
assign dut_state[1121+:1]=dut.u_i05.ck_d;
assign dut_state[1122+:6]=dut.u_i05.d_pre;
assign dut_state[1128+:6]=dut.u_i05.q;
assign dut_state[1134+:1]=dut.u_i08.ck_d;
assign dut_state[1135+:4]=dut.u_i08.q;
assign dut_state[1139+:6]=dut.u_i08.setup_pre;
assign dut_state[1145+:1]=dut.u_i09.ck_d;
assign dut_state[1146+:4]=dut.u_i09.q;
assign dut_state[1150+:6]=dut.u_i09.setup_pre;
assign dut_state[1156+:1]=dut.u_i10.ck_d;
assign dut_state[1157+:4]=dut.u_i10.q;
assign dut_state[1161+:6]=dut.u_i10.setup_pre;
assign dut_state[1167+:1]=dut.u_i11.ck_d;
assign dut_state[1168+:4]=dut.u_i11.q;
assign dut_state[1172+:6]=dut.u_i11.setup_pre;
assign dut_state[1178+:1]=dut.u_i13.ck_d;
assign dut_state[1179+:4]=dut.u_i13.q;
assign dut_state[1183+:6]=dut.u_i13.setup_pre;
assign dut_state[1189+:1]=dut.u_i16.ck_d;
assign dut_state[1190+:4]=dut.u_i16.q;
assign dut_state[1194+:6]=dut.u_i16.setup_pre;
assign dut_state[1200+:1]=dut.u_i17.ck_d;
assign dut_state[1201+:4]=dut.u_i17.q;
assign dut_state[1205+:6]=dut.u_i17.setup_pre;
assign dut_state[1211+:1]=dut.u_i20.cka_d;
assign dut_state[1212+:1]=dut.u_i20.ckb_d;
assign dut_state[1213+:1]=dut.u_i20.d_pre_a;
assign dut_state[1214+:1]=dut.u_i20.d_pre_b;
assign dut_state[1215+:1]=dut.u_i20.qa;
assign dut_state[1216+:1]=dut.u_i20.qb;
assign dut_state[1217+:1]=dut.u_i21.cka_d;
assign dut_state[1218+:1]=dut.u_i21.ckb_d;
assign dut_state[1219+:1]=dut.u_i21.d_pre_a;
assign dut_state[1220+:1]=dut.u_i21.d_pre_b;
assign dut_state[1221+:1]=dut.u_i21.qa;
assign dut_state[1222+:1]=dut.u_i21.qb;
assign dut_state[1223+:1]=dut.u_i22.cka_d;
assign dut_state[1224+:1]=dut.u_i22.ckb_d;
assign dut_state[1225+:1]=dut.u_i22.d_pre_a;
assign dut_state[1226+:1]=dut.u_i22.d_pre_b;
assign dut_state[1227+:1]=dut.u_i22.qa;
assign dut_state[1228+:1]=dut.u_i22.qb;
assign dut_state[1229+:1]=dut.u_i23.ck_d;
assign dut_state[1230+:6]=dut.u_i23.d_pre;
assign dut_state[1236+:6]=dut.u_i23.q;
assign dut_state[1242+:1]=dut.u_i24.ck_d;
assign dut_state[1243+:6]=dut.u_i24.d_pre;
assign dut_state[1249+:6]=dut.u_i24.q;
assign dut_state[1255+:1]=dut.u_j01.ck_d;
assign dut_state[1256+:6]=dut.u_j01.d_pre;
assign dut_state[1262+:6]=dut.u_j01.q;
assign dut_state[1268+:4]=dut.u_j02.a_lat;
assign dut_state[1272+:1]=dut.u_j02.ce_lat;
assign dut_state[1273+:4]=dut.u_j02.d_lat;
assign dut_state[1277+:64]={dut.u_j02.mem[15],dut.u_j02.mem[14],dut.u_j02.mem[13],dut.u_j02.mem[12],dut.u_j02.mem[11],dut.u_j02.mem[10],dut.u_j02.mem[9],dut.u_j02.mem[8],dut.u_j02.mem[7],dut.u_j02.mem[6],dut.u_j02.mem[5],dut.u_j02.mem[4],dut.u_j02.mem[3],dut.u_j02.mem[2],dut.u_j02.mem[1],dut.u_j02.mem[0]};
assign dut_state[1341+:1]=dut.u_j02.we_d;
assign dut_state[1342+:1]=dut.u_j03.ck_d;
assign dut_state[1343+:4]=dut.u_j03.d_pre;
assign dut_state[1347+:1]=dut.u_j03.dl_pre;
assign dut_state[1348+:1]=dut.u_j03.dr_pre;
assign dut_state[1349+:4]=dut.u_j03.q;
assign dut_state[1353+:2]=dut.u_j03.s_pre;
assign dut_state[1355+:1]=dut.u_j04.ck_d;
assign dut_state[1356+:4]=dut.u_j04.q;
assign dut_state[1360+:6]=dut.u_j04.setup_pre;
assign dut_state[1366+:1]=dut.u_j08.ck_d;
assign dut_state[1367+:4]=dut.u_j08.q;
assign dut_state[1371+:6]=dut.u_j08.setup_pre;
assign dut_state[1377+:1]=dut.u_j09.ck_d;
assign dut_state[1378+:4]=dut.u_j09.q;
assign dut_state[1382+:6]=dut.u_j09.setup_pre;
assign dut_state[1388+:1]=dut.u_j10.ck_d;
assign dut_state[1389+:4]=dut.u_j10.q;
assign dut_state[1393+:6]=dut.u_j10.setup_pre;
assign dut_state[1399+:1]=dut.u_j11.ck_d;
assign dut_state[1400+:4]=dut.u_j11.q;
assign dut_state[1404+:6]=dut.u_j11.setup_pre;
assign dut_state[1410+:1]=dut.u_j13.ck_d;
assign dut_state[1411+:4]=dut.u_j13.q;
assign dut_state[1415+:6]=dut.u_j13.setup_pre;
assign dut_state[1421+:1]=dut.u_j15.ck_d;
assign dut_state[1422+:6]=dut.u_j15.d_pre;
assign dut_state[1428+:6]=dut.u_j15.q;
assign dut_state[1434+:1]=dut.u_j16.ck_d;
assign dut_state[1435+:4]=dut.u_j16.q;
assign dut_state[1439+:6]=dut.u_j16.setup_pre;
assign dut_state[1445+:1]=dut.u_j17.ck_d;
assign dut_state[1446+:4]=dut.u_j17.q;
assign dut_state[1450+:6]=dut.u_j17.setup_pre;
assign dut_state[1456+:1]=dut.u_j21.cka_d;
assign dut_state[1457+:1]=dut.u_j21.ckb_d;
assign dut_state[1458+:1]=dut.u_j21.d_pre_a;
assign dut_state[1459+:1]=dut.u_j21.d_pre_b;
assign dut_state[1460+:1]=dut.u_j21.qa;
assign dut_state[1461+:1]=dut.u_j21.qb;
assign dut_state[1462+:1]=dut.u_j23.ck_d;
assign dut_state[1463+:6]=dut.u_j23.d_pre;
assign dut_state[1469+:6]=dut.u_j23.q;
assign dut_state[1475+:1]=dut.u_j24.ck_d;
assign dut_state[1476+:6]=dut.u_j24.d_pre;
assign dut_state[1482+:6]=dut.u_j24.q;
assign dut_state[1488+:1]=dut.u_k01.ck_d;
assign dut_state[1489+:6]=dut.u_k01.d_pre;
assign dut_state[1495+:6]=dut.u_k01.q;
assign dut_state[1501+:1]=dut.u_k02.ck_d;
assign dut_state[1502+:4]=dut.u_k02.q;
assign dut_state[1506+:6]=dut.u_k02.setup_pre;
assign dut_state[1512+:1]=dut.u_k04.ck_d;
assign dut_state[1513+:4]=dut.u_k04.q;
assign dut_state[1517+:6]=dut.u_k04.setup_pre;
assign dut_state[1523+:1]=dut.u_k09.ck_d;
assign dut_state[1524+:4]=dut.u_k09.q;
assign dut_state[1528+:6]=dut.u_k09.setup_pre;
assign dut_state[1534+:1]=dut.u_k15.ck_d;
assign dut_state[1535+:6]=dut.u_k15.d_pre;
assign dut_state[1541+:6]=dut.u_k15.q;
assign dut_state[1547+:1]=dut.u_k16.ck_d;
assign dut_state[1548+:4]=dut.u_k16.q;
assign dut_state[1552+:6]=dut.u_k16.setup_pre;
assign dut_state[1558+:1]=dut.u_k17.ck_d;
assign dut_state[1559+:4]=dut.u_k17.q;
assign dut_state[1563+:6]=dut.u_k17.setup_pre;
assign dut_state[1569+:1]=dut.u_k22.ck_d;
assign dut_state[1570+:6]=dut.u_k22.d_pre;
assign dut_state[1576+:6]=dut.u_k22.q;
assign dut_state[1582+:1]=dut.u_k23.ck_d;
assign dut_state[1583+:6]=dut.u_k23.d_pre;
assign dut_state[1589+:6]=dut.u_k23.q;
assign dut_state[1595+:1]=dut.u_k24.ck_d;
assign dut_state[1596+:6]=dut.u_k24.d_pre;
assign dut_state[1602+:6]=dut.u_k24.q;
assign dut_state[1608+:1]=dut.u_l01.cka_d;
assign dut_state[1609+:1]=dut.u_l01.ckb_d;
assign dut_state[1610+:1]=dut.u_l01.d_pre_a;
assign dut_state[1611+:1]=dut.u_l01.d_pre_b;
assign dut_state[1612+:1]=dut.u_l01.qa;
assign dut_state[1613+:1]=dut.u_l01.qb;
assign dut_state[1614+:1]=dut.u_l03.ck_d;
assign dut_state[1615+:4]=dut.u_l03.d_pre;
assign dut_state[1619+:1]=dut.u_l03.dl_pre;
assign dut_state[1620+:1]=dut.u_l03.dr_pre;
assign dut_state[1621+:4]=dut.u_l03.q;
assign dut_state[1625+:2]=dut.u_l03.s_pre;
assign dut_state[1627+:1]=dut.u_l09.ck_d;
assign dut_state[1628+:6]=dut.u_l09.d_pre;
assign dut_state[1634+:6]=dut.u_l09.q;
assign dut_state[1640+:1]=dut.u_l10.ck_d;
assign dut_state[1641+:4]=dut.u_l10.q;
assign dut_state[1645+:6]=dut.u_l10.setup_pre;
assign dut_state[1651+:1]=dut.u_l16.ck_d;
assign dut_state[1652+:4]=dut.u_l16.q;
assign dut_state[1656+:6]=dut.u_l16.setup_pre;
assign dut_state[1662+:1]=dut.u_l17.ck_d;
assign dut_state[1663+:4]=dut.u_l17.q;
assign dut_state[1667+:6]=dut.u_l17.setup_pre;
assign dut_state[1673+:1]=dut.u_l19.ck_d;
assign dut_state[1674+:6]=dut.u_l19.d_pre;
assign dut_state[1680+:6]=dut.u_l19.q;
assign dut_state[1686+:1]=dut.u_l21.cka_d;
assign dut_state[1687+:1]=dut.u_l21.ckb_d;
assign dut_state[1688+:1]=dut.u_l21.d_pre_a;
assign dut_state[1689+:1]=dut.u_l21.d_pre_b;
assign dut_state[1690+:1]=dut.u_l21.qa;
assign dut_state[1691+:1]=dut.u_l21.qb;
assign dut_state[1692+:1]=dut.u_l22.ck_d;
assign dut_state[1693+:6]=dut.u_l22.d_pre;
assign dut_state[1699+:6]=dut.u_l22.q;
assign dut_probe[0+:1]=dut.display_word_12.mem[0+(probe_index%1024)];
assign dut_probe[1+:1]=dut.display_word_13.mem[0+(probe_index%1024)];
assign dut_probe[2+:1]=dut.display_word_14.mem[0+(probe_index%1024)];
assign dut_probe[3+:4]=dut.u_f04.mem[0+(probe_index%256)];
assign dut_probe[7+:4]=dut.u_g16.mem[0+(probe_index%256)];
assign dut_probe[11+:4]=dut.u_g18.mem[0+(probe_index%256)];
assign dut_probe[15+:4]=dut.u_g20.mem[0+(probe_index%256)];
assign dut_probe[19+:4]=dut.u_g22.mem[0+(probe_index%256)];
assign dut_probe[23+:4]=dut.u_h16.mem[0+(probe_index%256)];
assign dut_probe[27+:4]=dut.u_h18.mem[0+(probe_index%256)];
assign dut_probe[31+:4]=dut.u_h20.mem[0+(probe_index%256)];
assign dut_probe[35+:4]=dut.u_h22.mem[0+(probe_index%256)];
assign all_helpers_frozen=&{dut.display_word_12.frozen,dut.display_word_13.frozen,dut.display_word_14.frozen,dut.state_frozen,dut.u_a05.state_frozen,dut.u_f04.state_frozen,dut.u_g03.state_frozen,dut.u_g16.state_frozen,dut.u_g18.state_frozen,dut.u_g20.state_frozen,dut.u_g22.state_frozen,dut.u_h02.state_frozen,dut.u_h16.state_frozen,dut.u_h18.state_frozen,dut.u_h20.state_frozen,dut.u_h22.state_frozen,dut.u_j02.state_frozen};
endmodule
