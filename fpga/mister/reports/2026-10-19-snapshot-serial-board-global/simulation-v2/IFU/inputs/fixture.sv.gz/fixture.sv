module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [78:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [82:0] reference_outputs,dut_outputs,
 output wire [1004:0] reference_state,dut_state,
 output wire [26:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_CrryEvCntA__drv;
wire reference_DMuxData__drv;
wire reference_EnableFG_p___drv;
wire reference_GDv_p___drv;
wire reference_GLd_p___drv;
wire reference_GenOut_00__drv;
wire reference_GenOut_01__drv;
wire reference_GenOut_02__drv;
wire reference_GenOut_03__drv;
wire reference_GenOut_04__drv;
wire reference_GenOut_05__drv;
wire reference_GenOut_06__drv;
wire reference_GenOut_07__drv;
wire reference_GenOut_08__drv;
wire reference_GenOut_09__drv;
wire reference_GenOut_10__drv;
wire reference_GenOut_11__drv;
wire reference_GenOut_12__drv;
wire reference_GenOut_13__drv;
wire reference_GenOut_14__drv;
wire reference_GenOut_15__drv;
wire reference_IfuAck__drv;
wire reference_IfuAddr_04_p___drv;
wire reference_IfuAddr_05_p___drv;
wire reference_IfuAddr_06_p___drv;
wire reference_IfuAddr_07_p___drv;
wire reference_IfuAddr_08_p___drv;
wire reference_IfuAddr_09_p___drv;
wire reference_IfuAddr_10_p___drv;
wire reference_IfuAddr_11_p___drv;
wire reference_IfuAddr_12_p___drv;
wire reference_IfuAddr_13_p___drv;
wire reference_IfuData_0__drv;
wire reference_IfuData_1__drv;
wire reference_IfuData_2__drv;
wire reference_IfuData_3__drv;
wire reference_IfuData_4__drv;
wire reference_IfuData_5__drv;
wire reference_IfuData_6__drv;
wire reference_IfuData_7__drv;
wire reference_IfuFaultInEc2__drv;
wire reference_IfuRBaseSel_p___drv;
wire reference_MAR_00_p___drv;
wire reference_MAR_01_p___drv;
wire reference_MAR_02_p___drv;
wire reference_MAR_03_p___drv;
wire reference_MAR_04_p___drv;
wire reference_MAR_05_p___drv;
wire reference_MAR_06_p___drv;
wire reference_MAR_07_p___drv;
wire reference_MAR_08_p___drv;
wire reference_MAR_09_p___drv;
wire reference_MAR_10_p___drv;
wire reference_MAR_11_p___drv;
wire reference_MAR_12_p___drv;
wire reference_MAR_13_p___drv;
wire reference_MAR_14_p___drv;
wire reference_MAR_15_p___drv;
wire reference_MemBM_0__drv;
wire reference_MemBM_1__drv;
wire reference_MemBM34__drv;
wire reference_PcFG_15__drv;
wire reference_RefOutstanding_p___drv;
wire reference_SignIfuData__drv;
wire reference_TWReq_02__drv;
wire reference_WantIfuHold_p___drv;
wire reference_WantIfuRef_p___drv;
IFU_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ASEL_0_p_(stimulus[0]),
.BMux_00(stimulus[1] | reference_BMux_00__drv),
.BMux_01(stimulus[2] | reference_BMux_01__drv),
.BMux_02(stimulus[3] | reference_BMux_02__drv),
.BMux_03(stimulus[4] | reference_BMux_03__drv),
.BMux_04(stimulus[5] | reference_BMux_04__drv),
.BMux_05(stimulus[6] | reference_BMux_05__drv),
.BMux_06(stimulus[7] | reference_BMux_06__drv),
.BMux_07(stimulus[8] | reference_BMux_07__drv),
.BMux_08(stimulus[9] | reference_BMux_08__drv),
.BMux_09(stimulus[10] | reference_BMux_09__drv),
.BMux_10(stimulus[11] | reference_BMux_10__drv),
.BMux_11(stimulus[12] | reference_BMux_11__drv),
.BMux_12(stimulus[13] | reference_BMux_12__drv),
.BMux_13(stimulus[14] | reference_BMux_13__drv),
.BMux_14(stimulus[15] | reference_BMux_14__drv),
.BMux_15(stimulus[16] | reference_BMux_15__drv),
.CLK_ifu_p_(stimulus[17]),
.CLKEnable_p_a(stimulus[18]),
.CountMiss(stimulus[19]),
.DMuxClk(stimulus[20]),
.DMuxData(stimulus[21] | reference_DMuxData__drv),
.EmuOrFT_p_(stimulus[22]),
.EnableFG_p_(stimulus[23] | reference_EnableFG_p___drv),
.EventA(stimulus[24]),
.EventB(stimulus[25]),
.EventC(stimulus[26]),
.EventD(stimulus[27]),
.EventE(stimulus[28]),
.FA_eq_1_p_(stimulus[29]),
.FF_2(stimulus[30]),
.FF_3(stimulus[31]),
.FF_4(stimulus[32]),
.FF_5(stimulus[33]),
.FF_6(stimulus[34]),
.FF_7(stimulus[35]),
.FG_0(stimulus[36]),
.FG_1(stimulus[37]),
.FG_2(stimulus[38]),
.FG_3(stimulus[39]),
.FG_4(stimulus[40]),
.FG_5(stimulus[41]),
.FG_6(stimulus[42]),
.FG_7(stimulus[43]),
.FG_8(stimulus[44]),
.GDv_p_(stimulus[45] | reference_GDv_p___drv),
.GLd_p_(stimulus[46] | reference_GLd_p___drv),
.GenIn_00(stimulus[47]),
.GenIn_01(stimulus[48]),
.GenIn_02(stimulus[49]),
.GenIn_03(stimulus[50]),
.GenIn_04(stimulus[51]),
.GenIn_05(stimulus[52]),
.GenIn_06(stimulus[53]),
.GenIn_07(stimulus[54]),
.GenIn_08(stimulus[55]),
.GenIn_09(stimulus[56]),
.GenIn_10(stimulus[57]),
.GenIn_11(stimulus[58]),
.GenIn_12(stimulus[59]),
.GenIn_13(stimulus[60]),
.GenIn_14(stimulus[61]),
.GenIn_15(stimulus[62]),
.IOReset(stimulus[63]),
.IfuAWantsDifHit_p_(stimulus[64]),
.IfuAck(stimulus[65] | reference_IfuAck__drv),
.IfuFaultInEc2(stimulus[66] | reference_IfuFaultInEc2__drv),
.IfuHold(stimulus[67]),
.IfuNextMacro_p_(stimulus[68]),
.IfuStartMap_p_(stimulus[69]),
.MakeF_u_D(stimulus[70]),
.MemClkEn_p_a(stimulus[71]),
.MemSH(stimulus[72]),
.NextData_p_(stimulus[73]),
.Pendulum(stimulus[74]),
.RefOutstanding_p_(stimulus[75] | reference_RefOutstanding_p___drv),
.TempRef(stimulus[76]),
.WantIfuHold_p_(stimulus[77] | reference_WantIfuHold_p___drv),
.WantIfuRef_p_(stimulus[78] | reference_WantIfuRef_p___drv),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.CrryEvCntA__drv(reference_CrryEvCntA__drv),
.DMuxData__drv(reference_DMuxData__drv),
.EnableFG_p___drv(reference_EnableFG_p___drv),
.GDv_p___drv(reference_GDv_p___drv),
.GLd_p___drv(reference_GLd_p___drv),
.GenOut_00__drv(reference_GenOut_00__drv),
.GenOut_01__drv(reference_GenOut_01__drv),
.GenOut_02__drv(reference_GenOut_02__drv),
.GenOut_03__drv(reference_GenOut_03__drv),
.GenOut_04__drv(reference_GenOut_04__drv),
.GenOut_05__drv(reference_GenOut_05__drv),
.GenOut_06__drv(reference_GenOut_06__drv),
.GenOut_07__drv(reference_GenOut_07__drv),
.GenOut_08__drv(reference_GenOut_08__drv),
.GenOut_09__drv(reference_GenOut_09__drv),
.GenOut_10__drv(reference_GenOut_10__drv),
.GenOut_11__drv(reference_GenOut_11__drv),
.GenOut_12__drv(reference_GenOut_12__drv),
.GenOut_13__drv(reference_GenOut_13__drv),
.GenOut_14__drv(reference_GenOut_14__drv),
.GenOut_15__drv(reference_GenOut_15__drv),
.IfuAck__drv(reference_IfuAck__drv),
.IfuAddr_04_p___drv(reference_IfuAddr_04_p___drv),
.IfuAddr_05_p___drv(reference_IfuAddr_05_p___drv),
.IfuAddr_06_p___drv(reference_IfuAddr_06_p___drv),
.IfuAddr_07_p___drv(reference_IfuAddr_07_p___drv),
.IfuAddr_08_p___drv(reference_IfuAddr_08_p___drv),
.IfuAddr_09_p___drv(reference_IfuAddr_09_p___drv),
.IfuAddr_10_p___drv(reference_IfuAddr_10_p___drv),
.IfuAddr_11_p___drv(reference_IfuAddr_11_p___drv),
.IfuAddr_12_p___drv(reference_IfuAddr_12_p___drv),
.IfuAddr_13_p___drv(reference_IfuAddr_13_p___drv),
.IfuData_0__drv(reference_IfuData_0__drv),
.IfuData_1__drv(reference_IfuData_1__drv),
.IfuData_2__drv(reference_IfuData_2__drv),
.IfuData_3__drv(reference_IfuData_3__drv),
.IfuData_4__drv(reference_IfuData_4__drv),
.IfuData_5__drv(reference_IfuData_5__drv),
.IfuData_6__drv(reference_IfuData_6__drv),
.IfuData_7__drv(reference_IfuData_7__drv),
.IfuFaultInEc2__drv(reference_IfuFaultInEc2__drv),
.IfuRBaseSel_p___drv(reference_IfuRBaseSel_p___drv),
.MAR_00_p___drv(reference_MAR_00_p___drv),
.MAR_01_p___drv(reference_MAR_01_p___drv),
.MAR_02_p___drv(reference_MAR_02_p___drv),
.MAR_03_p___drv(reference_MAR_03_p___drv),
.MAR_04_p___drv(reference_MAR_04_p___drv),
.MAR_05_p___drv(reference_MAR_05_p___drv),
.MAR_06_p___drv(reference_MAR_06_p___drv),
.MAR_07_p___drv(reference_MAR_07_p___drv),
.MAR_08_p___drv(reference_MAR_08_p___drv),
.MAR_09_p___drv(reference_MAR_09_p___drv),
.MAR_10_p___drv(reference_MAR_10_p___drv),
.MAR_11_p___drv(reference_MAR_11_p___drv),
.MAR_12_p___drv(reference_MAR_12_p___drv),
.MAR_13_p___drv(reference_MAR_13_p___drv),
.MAR_14_p___drv(reference_MAR_14_p___drv),
.MAR_15_p___drv(reference_MAR_15_p___drv),
.MemBM_0__drv(reference_MemBM_0__drv),
.MemBM_1__drv(reference_MemBM_1__drv),
.MemBM34__drv(reference_MemBM34__drv),
.PcFG_15__drv(reference_PcFG_15__drv),
.RefOutstanding_p___drv(reference_RefOutstanding_p___drv),
.SignIfuData__drv(reference_SignIfuData__drv),
.TWReq_02__drv(reference_TWReq_02__drv),
.WantIfuHold_p___drv(reference_WantIfuHold_p___drv),
.WantIfuRef_p___drv(reference_WantIfuRef_p___drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[17:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_WantIfuRef_p___drv,reference_WantIfuHold_p___drv,reference_TWReq_02__drv,reference_SignIfuData__drv,reference_RefOutstanding_p___drv,reference_PcFG_15__drv,reference_MemBM34__drv,reference_MemBM_1__drv,reference_MemBM_0__drv,reference_MAR_15_p___drv,reference_MAR_14_p___drv,reference_MAR_13_p___drv,reference_MAR_12_p___drv,reference_MAR_11_p___drv,reference_MAR_10_p___drv,reference_MAR_09_p___drv,reference_MAR_08_p___drv,reference_MAR_07_p___drv,reference_MAR_06_p___drv,reference_MAR_05_p___drv,reference_MAR_04_p___drv,reference_MAR_03_p___drv,reference_MAR_02_p___drv,reference_MAR_01_p___drv,reference_MAR_00_p___drv,reference_IfuRBaseSel_p___drv,reference_IfuFaultInEc2__drv,reference_IfuData_7__drv,reference_IfuData_6__drv,reference_IfuData_5__drv,reference_IfuData_4__drv,reference_IfuData_3__drv,reference_IfuData_2__drv,reference_IfuData_1__drv,reference_IfuData_0__drv,reference_IfuAddr_13_p___drv,reference_IfuAddr_12_p___drv,reference_IfuAddr_11_p___drv,reference_IfuAddr_10_p___drv,reference_IfuAddr_09_p___drv,reference_IfuAddr_08_p___drv,reference_IfuAddr_07_p___drv,reference_IfuAddr_06_p___drv,reference_IfuAddr_05_p___drv,reference_IfuAddr_04_p___drv,reference_IfuAck__drv,reference_GenOut_15__drv,reference_GenOut_14__drv,reference_GenOut_13__drv,reference_GenOut_12__drv,reference_GenOut_11__drv,reference_GenOut_10__drv,reference_GenOut_09__drv,reference_GenOut_08__drv,reference_GenOut_07__drv,reference_GenOut_06__drv,reference_GenOut_05__drv,reference_GenOut_04__drv,reference_GenOut_03__drv,reference_GenOut_02__drv,reference_GenOut_01__drv,reference_GenOut_00__drv,reference_GLd_p___drv,reference_GDv_p___drv,reference_EnableFG_p___drv,reference_DMuxData__drv,reference_CrryEvCntA__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv};
assign reference_state[0+:1]=reference.clk1_p_Aa;
assign reference_state[1+:1]=reference.clk1_p_Ab;
assign reference_state[2+:1]=reference.clk1_p_Ac;
assign reference_state[3+:1]=reference.clk1_p_Da;
assign reference_state[4+:1]=reference.snapshot_bank_0.saved_q;
assign reference_state[5+:5]=reference.snapshot_bank_1.saved_q;
assign reference_state[10+:2]=reference.snapshot_bank_10.saved_q;
assign reference_state[12+:1]=reference.snapshot_bank_2.saved_q;
assign reference_state[13+:1]=reference.snapshot_bank_3.saved_q;
assign reference_state[14+:4]=reference.snapshot_bank_4.saved_q;
assign reference_state[18+:1]=reference.snapshot_bank_5.saved_q;
assign reference_state[19+:5]=reference.snapshot_bank_6.saved_q;
assign reference_state[24+:2]=reference.snapshot_bank_7.saved_q;
assign reference_state[26+:1]=reference.snapshot_bank_8.saved_q;
assign reference_state[27+:4]=reference.snapshot_bank_9.saved_q;
assign reference_state[31+:1]=reference.u_a04.ck_d;
assign reference_state[32+:4]=reference.u_a04.q;
assign reference_state[36+:6]=reference.u_a04.setup_pre;
assign reference_state[42+:1]=reference.u_a05.ck_d;
assign reference_state[43+:4]=reference.u_a05.q;
assign reference_state[47+:6]=reference.u_a05.setup_pre;
assign reference_state[53+:1]=reference.u_a08.ck_d;
assign reference_state[54+:4]=reference.u_a08.q;
assign reference_state[58+:6]=reference.u_a08.setup_pre;
assign reference_state[64+:1]=reference.u_a11.ck_d;
assign reference_state[65+:4]=reference.u_a11.q;
assign reference_state[69+:6]=reference.u_a11.setup_pre;
assign reference_state[75+:1]=reference.u_a13.ck_d;
assign reference_state[76+:6]=reference.u_a13.d_pre;
assign reference_state[82+:6]=reference.u_a13.q;
assign reference_state[88+:1]=reference.u_a15.ck_d;
assign reference_state[89+:4]=reference.u_a15.q;
assign reference_state[93+:6]=reference.u_a15.setup_pre;
assign reference_state[99+:1]=reference.u_a16.ck_d;
assign reference_state[100+:6]=reference.u_a16.d_pre;
assign reference_state[106+:6]=reference.u_a16.q;
assign reference_state[112+:1]=reference.u_a17.ck_d;
assign reference_state[113+:6]=reference.u_a17.d_pre;
assign reference_state[119+:6]=reference.u_a17.q;
assign reference_state[125+:1]=reference.u_a18.ck_d;
assign reference_state[126+:6]=reference.u_a18.d_pre;
assign reference_state[132+:6]=reference.u_a18.q;
assign reference_state[138+:1]=reference.u_a20.ck_d;
assign reference_state[139+:4]=reference.u_a20.q;
assign reference_state[143+:6]=reference.u_a20.setup_pre;
assign reference_state[149+:1]=reference.u_a21.cka_d;
assign reference_state[150+:1]=reference.u_a21.ckb_d;
assign reference_state[151+:1]=reference.u_a21.d_pre_a;
assign reference_state[152+:1]=reference.u_a21.d_pre_b;
assign reference_state[153+:1]=reference.u_a21.qa;
assign reference_state[154+:1]=reference.u_a21.qb;
assign reference_state[155+:4]=reference.u_b01.q;
assign reference_state[159+:1]=reference.u_b04.ck_d;
assign reference_state[160+:6]=reference.u_b04.d_pre;
assign reference_state[166+:6]=reference.u_b04.q;
assign reference_state[172+:1]=reference.u_b05.ck_d;
assign reference_state[173+:4]=reference.u_b05.d_pre;
assign reference_state[177+:1]=reference.u_b05.dl_pre;
assign reference_state[178+:1]=reference.u_b05.dr_pre;
assign reference_state[179+:4]=reference.u_b05.q;
assign reference_state[183+:2]=reference.u_b05.s_pre;
assign reference_state[185+:1]=reference.u_b06.ck_d;
assign reference_state[186+:4]=reference.u_b06.d_pre;
assign reference_state[190+:1]=reference.u_b06.dl_pre;
assign reference_state[191+:1]=reference.u_b06.dr_pre;
assign reference_state[192+:4]=reference.u_b06.q;
assign reference_state[196+:2]=reference.u_b06.s_pre;
assign reference_state[198+:1]=reference.u_b08.ck_d;
assign reference_state[199+:4]=reference.u_b08.q;
assign reference_state[203+:6]=reference.u_b08.setup_pre;
assign reference_state[209+:1]=reference.u_b11.ck_d;
assign reference_state[210+:4]=reference.u_b11.q;
assign reference_state[214+:6]=reference.u_b11.setup_pre;
assign reference_state[220+:1]=reference.u_b13.ck_d;
assign reference_state[221+:6]=reference.u_b13.d_pre;
assign reference_state[227+:6]=reference.u_b13.q;
assign reference_state[233+:1]=reference.u_b15.ck_d;
assign reference_state[234+:4]=reference.u_b15.q;
assign reference_state[238+:6]=reference.u_b15.setup_pre;
assign reference_state[244+:1]=reference.u_b16.ck_d;
assign reference_state[245+:6]=reference.u_b16.d_pre;
assign reference_state[251+:6]=reference.u_b16.q;
assign reference_state[257+:1]=reference.u_b18.ck_d;
assign reference_state[258+:6]=reference.u_b18.d_pre;
assign reference_state[264+:6]=reference.u_b18.q;
assign reference_state[270+:1]=reference.u_b20.ck_d;
assign reference_state[271+:6]=reference.u_b20.d_pre;
assign reference_state[277+:6]=reference.u_b20.q;
assign reference_state[283+:4]=reference.u_c01.q;
assign reference_state[287+:1]=reference.u_c04.ck_d;
assign reference_state[288+:4]=reference.u_c04.q;
assign reference_state[292+:6]=reference.u_c04.setup_pre;
assign reference_state[298+:1]=reference.u_c08.ck_d;
assign reference_state[299+:4]=reference.u_c08.q;
assign reference_state[303+:6]=reference.u_c08.setup_pre;
assign reference_state[309+:1]=reference.u_c11.ck_d;
assign reference_state[310+:4]=reference.u_c11.q;
assign reference_state[314+:6]=reference.u_c11.setup_pre;
assign reference_state[320+:1]=reference.u_c13.ck_d;
assign reference_state[321+:6]=reference.u_c13.d_pre;
assign reference_state[327+:6]=reference.u_c13.q;
assign reference_state[333+:1]=reference.u_c14.ck_d;
assign reference_state[334+:6]=reference.u_c14.d_pre;
assign reference_state[340+:6]=reference.u_c14.q;
assign reference_state[346+:1]=reference.u_c15.ck_d;
assign reference_state[347+:6]=reference.u_c15.d_pre;
assign reference_state[353+:6]=reference.u_c15.q;
assign reference_state[359+:1]=reference.u_c16.ck_d;
assign reference_state[360+:6]=reference.u_c16.d_pre;
assign reference_state[366+:6]=reference.u_c16.q;
assign reference_state[372+:1]=reference.u_c17.cka_d;
assign reference_state[373+:1]=reference.u_c17.ckb_d;
assign reference_state[374+:1]=reference.u_c17.d_pre_a;
assign reference_state[375+:1]=reference.u_c17.d_pre_b;
assign reference_state[376+:1]=reference.u_c17.qa;
assign reference_state[377+:1]=reference.u_c17.qb;
assign reference_state[378+:1]=reference.u_c20.ck_d;
assign reference_state[379+:6]=reference.u_c20.d_pre;
assign reference_state[385+:6]=reference.u_c20.q;
assign reference_state[391+:1]=reference.u_c22.ck_d;
assign reference_state[392+:6]=reference.u_c22.d_pre;
assign reference_state[398+:6]=reference.u_c22.q;
assign reference_state[404+:1]=reference.u_d04.ck_d;
assign reference_state[405+:4]=reference.u_d04.q;
assign reference_state[409+:6]=reference.u_d04.setup_pre;
assign reference_state[415+:1]=reference.u_d08.ck_d;
assign reference_state[416+:4]=reference.u_d08.q;
assign reference_state[420+:6]=reference.u_d08.setup_pre;
assign reference_state[426+:1]=reference.u_d11.ck_d;
assign reference_state[427+:4]=reference.u_d11.q;
assign reference_state[431+:6]=reference.u_d11.setup_pre;
assign reference_state[437+:1]=reference.u_d13.ck_d;
assign reference_state[438+:6]=reference.u_d13.d_pre;
assign reference_state[444+:6]=reference.u_d13.q;
assign reference_state[450+:1]=reference.u_d14.ck_d;
assign reference_state[451+:6]=reference.u_d14.d_pre;
assign reference_state[457+:6]=reference.u_d14.q;
assign reference_state[463+:1]=reference.u_d16.cka_d;
assign reference_state[464+:1]=reference.u_d16.ckb_d;
assign reference_state[465+:1]=reference.u_d16.d_pre_a;
assign reference_state[466+:1]=reference.u_d16.d_pre_b;
assign reference_state[467+:1]=reference.u_d16.qa;
assign reference_state[468+:1]=reference.u_d16.qb;
assign reference_state[469+:4]=reference.u_e01.q;
assign reference_state[473+:1]=reference.u_e04.ck_d;
assign reference_state[474+:6]=reference.u_e04.d_pre;
assign reference_state[480+:6]=reference.u_e04.q;
assign reference_state[486+:1]=reference.u_e06.ck_d;
assign reference_state[487+:4]=reference.u_e06.q;
assign reference_state[491+:6]=reference.u_e06.setup_pre;
assign reference_state[497+:1]=reference.u_e07.ck_d;
assign reference_state[498+:6]=reference.u_e07.d_pre;
assign reference_state[504+:6]=reference.u_e07.q;
assign reference_state[510+:1]=reference.u_e13.ck_d;
assign reference_state[511+:6]=reference.u_e13.d_pre;
assign reference_state[517+:6]=reference.u_e13.q;
assign reference_state[523+:1]=reference.u_e17.cka_d;
assign reference_state[524+:1]=reference.u_e17.ckb_d;
assign reference_state[525+:1]=reference.u_e17.d_pre_a;
assign reference_state[526+:1]=reference.u_e17.d_pre_b;
assign reference_state[527+:1]=reference.u_e17.qa;
assign reference_state[528+:1]=reference.u_e17.qb;
assign reference_state[529+:4]=reference.u_f01.q;
assign reference_state[533+:1]=reference.u_f03.ck_d;
assign reference_state[534+:4]=reference.u_f03.q;
assign reference_state[538+:6]=reference.u_f03.setup_pre;
assign reference_state[544+:1]=reference.u_f04.ck_d;
assign reference_state[545+:6]=reference.u_f04.d_pre;
assign reference_state[551+:6]=reference.u_f04.q;
assign reference_state[557+:1]=reference.u_f06.ck_d;
assign reference_state[558+:4]=reference.u_f06.q;
assign reference_state[562+:6]=reference.u_f06.setup_pre;
assign reference_state[568+:1]=reference.u_f14.ck_d;
assign reference_state[569+:4]=reference.u_f14.q;
assign reference_state[573+:6]=reference.u_f14.setup_pre;
assign reference_state[579+:1]=reference.u_f20.ck_d;
assign reference_state[580+:4]=reference.u_f20.jk_pre;
assign reference_state[584+:1]=reference.u_f20.qa;
assign reference_state[585+:1]=reference.u_f20.qb;
assign reference_state[586+:1]=reference.u_f21.ck_d;
assign reference_state[587+:4]=reference.u_f21.jk_pre;
assign reference_state[591+:1]=reference.u_f21.qa;
assign reference_state[592+:1]=reference.u_f21.qb;
assign reference_state[593+:1]=reference.u_f24.ck_d;
assign reference_state[594+:4]=reference.u_f24.q;
assign reference_state[598+:6]=reference.u_f24.setup_pre;
assign reference_state[604+:1]=reference.u_g04.ck_d;
assign reference_state[605+:6]=reference.u_g04.d_pre;
assign reference_state[611+:6]=reference.u_g04.q;
assign reference_state[617+:1]=reference.u_g05.ck_d;
assign reference_state[618+:6]=reference.u_g05.d_pre;
assign reference_state[624+:6]=reference.u_g05.q;
assign reference_state[630+:1]=reference.u_g07.ck_d;
assign reference_state[631+:6]=reference.u_g07.d_pre;
assign reference_state[637+:6]=reference.u_g07.q;
assign reference_state[643+:1]=reference.u_g19.ck_d;
assign reference_state[644+:4]=reference.u_g19.q;
assign reference_state[648+:6]=reference.u_g19.setup_pre;
assign reference_state[654+:1]=reference.u_h03.ck_d;
assign reference_state[655+:4]=reference.u_h03.q;
assign reference_state[659+:6]=reference.u_h03.setup_pre;
assign reference_state[665+:1]=reference.u_h04.ck_d;
assign reference_state[666+:4]=reference.u_h04.q;
assign reference_state[670+:6]=reference.u_h04.setup_pre;
assign reference_state[676+:1]=reference.u_h07.ck_d;
assign reference_state[677+:6]=reference.u_h07.d_pre;
assign reference_state[683+:6]=reference.u_h07.q;
assign reference_state[689+:1]=reference.u_h11.ck_d;
assign reference_state[690+:4]=reference.u_h11.q;
assign reference_state[694+:6]=reference.u_h11.setup_pre;
assign reference_state[700+:1]=reference.u_h12.ck_d;
assign reference_state[701+:4]=reference.u_h12.q;
assign reference_state[705+:6]=reference.u_h12.setup_pre;
assign reference_state[711+:1]=reference.u_h13.cka_d;
assign reference_state[712+:1]=reference.u_h13.ckb_d;
assign reference_state[713+:1]=reference.u_h13.d_pre_a;
assign reference_state[714+:1]=reference.u_h13.d_pre_b;
assign reference_state[715+:1]=reference.u_h13.qa;
assign reference_state[716+:1]=reference.u_h13.qb;
assign reference_state[717+:1]=reference.u_h17.ck_d;
assign reference_state[718+:4]=reference.u_h17.q;
assign reference_state[722+:6]=reference.u_h17.setup_pre;
assign reference_state[728+:1]=reference.u_i03.ck_d;
assign reference_state[729+:4]=reference.u_i03.q;
assign reference_state[733+:6]=reference.u_i03.setup_pre;
assign reference_state[739+:1]=reference.u_i04.ck_d;
assign reference_state[740+:4]=reference.u_i04.q;
assign reference_state[744+:6]=reference.u_i04.setup_pre;
assign reference_state[750+:1]=reference.u_i11.ck_d;
assign reference_state[751+:4]=reference.u_i11.q;
assign reference_state[755+:6]=reference.u_i11.setup_pre;
assign reference_state[761+:1]=reference.u_i12.ck_d;
assign reference_state[762+:4]=reference.u_i12.q;
assign reference_state[766+:6]=reference.u_i12.setup_pre;
assign reference_state[772+:1]=reference.u_i16.cka_d;
assign reference_state[773+:1]=reference.u_i16.ckb_d;
assign reference_state[774+:1]=reference.u_i16.d_pre_a;
assign reference_state[775+:1]=reference.u_i16.d_pre_b;
assign reference_state[776+:1]=reference.u_i16.qa;
assign reference_state[777+:1]=reference.u_i16.qb;
assign reference_state[778+:1]=reference.u_i20.ck_d;
assign reference_state[779+:4]=reference.u_i20.jk_pre;
assign reference_state[783+:1]=reference.u_i20.qa;
assign reference_state[784+:1]=reference.u_i20.qb;
assign reference_state[785+:1]=reference.u_i24.cka_d;
assign reference_state[786+:1]=reference.u_i24.ckb_d;
assign reference_state[787+:1]=reference.u_i24.d_pre_a;
assign reference_state[788+:1]=reference.u_i24.d_pre_b;
assign reference_state[789+:1]=reference.u_i24.qa;
assign reference_state[790+:1]=reference.u_i24.qb;
assign reference_state[791+:1]=reference.u_j06.cka_d;
assign reference_state[792+:1]=reference.u_j06.ckb_d;
assign reference_state[793+:1]=reference.u_j06.d_pre_a;
assign reference_state[794+:1]=reference.u_j06.d_pre_b;
assign reference_state[795+:1]=reference.u_j06.qa;
assign reference_state[796+:1]=reference.u_j06.qb;
assign reference_state[797+:1]=reference.u_j08.cka_d;
assign reference_state[798+:1]=reference.u_j08.ckb_d;
assign reference_state[799+:1]=reference.u_j08.d_pre_a;
assign reference_state[800+:1]=reference.u_j08.d_pre_b;
assign reference_state[801+:1]=reference.u_j08.qa;
assign reference_state[802+:1]=reference.u_j08.qb;
assign reference_state[803+:1]=reference.u_j11.ck_d;
assign reference_state[804+:4]=reference.u_j11.q;
assign reference_state[808+:6]=reference.u_j11.setup_pre;
assign reference_state[814+:1]=reference.u_j12.ck_d;
assign reference_state[815+:4]=reference.u_j12.q;
assign reference_state[819+:6]=reference.u_j12.setup_pre;
assign reference_state[825+:1]=reference.u_j20.cka_d;
assign reference_state[826+:1]=reference.u_j20.ckb_d;
assign reference_state[827+:1]=reference.u_j20.d_pre_a;
assign reference_state[828+:1]=reference.u_j20.d_pre_b;
assign reference_state[829+:1]=reference.u_j20.qa;
assign reference_state[830+:1]=reference.u_j20.qb;
assign reference_state[831+:1]=reference.u_j24.cka_d;
assign reference_state[832+:1]=reference.u_j24.ckb_d;
assign reference_state[833+:1]=reference.u_j24.d_pre_a;
assign reference_state[834+:1]=reference.u_j24.d_pre_b;
assign reference_state[835+:1]=reference.u_j24.qa;
assign reference_state[836+:1]=reference.u_j24.qb;
assign reference_state[837+:1]=reference.u_k03.ck_d;
assign reference_state[838+:4]=reference.u_k03.q;
assign reference_state[842+:6]=reference.u_k03.setup_pre;
assign reference_state[848+:1]=reference.u_k05.ck_d;
assign reference_state[849+:4]=reference.u_k05.q;
assign reference_state[853+:6]=reference.u_k05.setup_pre;
assign reference_state[859+:1]=reference.u_k06.ck_d;
assign reference_state[860+:6]=reference.u_k06.d_pre;
assign reference_state[866+:6]=reference.u_k06.q;
assign reference_state[872+:1]=reference.u_k08.cka_d;
assign reference_state[873+:1]=reference.u_k08.ckb_d;
assign reference_state[874+:1]=reference.u_k08.d_pre_a;
assign reference_state[875+:1]=reference.u_k08.d_pre_b;
assign reference_state[876+:1]=reference.u_k08.qa;
assign reference_state[877+:1]=reference.u_k08.qb;
assign reference_state[878+:1]=reference.u_k11.ck_d;
assign reference_state[879+:4]=reference.u_k11.q;
assign reference_state[883+:6]=reference.u_k11.setup_pre;
assign reference_state[889+:1]=reference.u_k12.ck_d;
assign reference_state[890+:4]=reference.u_k12.q;
assign reference_state[894+:6]=reference.u_k12.setup_pre;
assign reference_state[900+:1]=reference.u_k17.ck_d;
assign reference_state[901+:6]=reference.u_k17.d_pre;
assign reference_state[907+:6]=reference.u_k17.q;
assign reference_state[913+:1]=reference.u_k22.cka_d;
assign reference_state[914+:1]=reference.u_k22.ckb_d;
assign reference_state[915+:1]=reference.u_k22.d_pre_a;
assign reference_state[916+:1]=reference.u_k22.d_pre_b;
assign reference_state[917+:1]=reference.u_k22.qa;
assign reference_state[918+:1]=reference.u_k22.qb;
assign reference_state[919+:1]=reference.u_k23.cka_d;
assign reference_state[920+:1]=reference.u_k23.ckb_d;
assign reference_state[921+:1]=reference.u_k23.d_pre_a;
assign reference_state[922+:1]=reference.u_k23.d_pre_b;
assign reference_state[923+:1]=reference.u_k23.qa;
assign reference_state[924+:1]=reference.u_k23.qb;
assign reference_state[925+:1]=reference.u_k24.cka_d;
assign reference_state[926+:1]=reference.u_k24.ckb_d;
assign reference_state[927+:1]=reference.u_k24.d_pre_a;
assign reference_state[928+:1]=reference.u_k24.d_pre_b;
assign reference_state[929+:1]=reference.u_k24.qa;
assign reference_state[930+:1]=reference.u_k24.qb;
assign reference_state[931+:1]=reference.u_l01.cka_d;
assign reference_state[932+:1]=reference.u_l01.ckb_d;
assign reference_state[933+:1]=reference.u_l01.d_pre_a;
assign reference_state[934+:1]=reference.u_l01.d_pre_b;
assign reference_state[935+:1]=reference.u_l01.qa;
assign reference_state[936+:1]=reference.u_l01.qb;
assign reference_state[937+:1]=reference.u_l03.ck_d;
assign reference_state[938+:4]=reference.u_l03.q;
assign reference_state[942+:6]=reference.u_l03.setup_pre;
assign reference_state[948+:1]=reference.u_l04.ck_d;
assign reference_state[949+:4]=reference.u_l04.q;
assign reference_state[953+:6]=reference.u_l04.setup_pre;
assign reference_state[959+:1]=reference.u_l06.ck_d;
assign reference_state[960+:6]=reference.u_l06.d_pre;
assign reference_state[966+:6]=reference.u_l06.q;
assign reference_state[972+:1]=reference.u_l19.ck_d;
assign reference_state[973+:6]=reference.u_l19.d_pre;
assign reference_state[979+:6]=reference.u_l19.q;
assign reference_state[985+:1]=reference.u_l21.ck_d;
assign reference_state[986+:4]=reference.u_l21.jk_pre;
assign reference_state[990+:1]=reference.u_l21.qa;
assign reference_state[991+:1]=reference.u_l21.qb;
assign reference_state[992+:1]=reference.u_l22.ck_d;
assign reference_state[993+:6]=reference.u_l22.d_pre;
assign reference_state[999+:6]=reference.u_l22.q;
assign reference_probe[0+:1]=reference.snapshot_bank_0.mem[0+(probe_index%1024)];
assign reference_probe[1+:5]=reference.snapshot_bank_1.mem[0+(probe_index%1024)];
assign reference_probe[6+:2]=reference.snapshot_bank_10.mem[0+(probe_index%1024)];
assign reference_probe[8+:1]=reference.snapshot_bank_2.mem[0+(probe_index%1024)];
assign reference_probe[9+:1]=reference.snapshot_bank_3.mem[0+(probe_index%1024)];
assign reference_probe[10+:4]=reference.snapshot_bank_4.mem[0+(probe_index%1024)];
assign reference_probe[14+:1]=reference.snapshot_bank_5.mem[0+(probe_index%1024)];
assign reference_probe[15+:5]=reference.snapshot_bank_6.mem[0+(probe_index%1024)];
assign reference_probe[20+:2]=reference.snapshot_bank_7.mem[0+(probe_index%1024)];
assign reference_probe[22+:1]=reference.snapshot_bank_8.mem[0+(probe_index%1024)];
assign reference_probe[23+:4]=reference.snapshot_bank_9.mem[0+(probe_index%1024)];
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_CrryEvCntA__drv;
wire dut_DMuxData__drv;
wire dut_EnableFG_p___drv;
wire dut_GDv_p___drv;
wire dut_GLd_p___drv;
wire dut_GenOut_00__drv;
wire dut_GenOut_01__drv;
wire dut_GenOut_02__drv;
wire dut_GenOut_03__drv;
wire dut_GenOut_04__drv;
wire dut_GenOut_05__drv;
wire dut_GenOut_06__drv;
wire dut_GenOut_07__drv;
wire dut_GenOut_08__drv;
wire dut_GenOut_09__drv;
wire dut_GenOut_10__drv;
wire dut_GenOut_11__drv;
wire dut_GenOut_12__drv;
wire dut_GenOut_13__drv;
wire dut_GenOut_14__drv;
wire dut_GenOut_15__drv;
wire dut_IfuAck__drv;
wire dut_IfuAddr_04_p___drv;
wire dut_IfuAddr_05_p___drv;
wire dut_IfuAddr_06_p___drv;
wire dut_IfuAddr_07_p___drv;
wire dut_IfuAddr_08_p___drv;
wire dut_IfuAddr_09_p___drv;
wire dut_IfuAddr_10_p___drv;
wire dut_IfuAddr_11_p___drv;
wire dut_IfuAddr_12_p___drv;
wire dut_IfuAddr_13_p___drv;
wire dut_IfuData_0__drv;
wire dut_IfuData_1__drv;
wire dut_IfuData_2__drv;
wire dut_IfuData_3__drv;
wire dut_IfuData_4__drv;
wire dut_IfuData_5__drv;
wire dut_IfuData_6__drv;
wire dut_IfuData_7__drv;
wire dut_IfuFaultInEc2__drv;
wire dut_IfuRBaseSel_p___drv;
wire dut_MAR_00_p___drv;
wire dut_MAR_01_p___drv;
wire dut_MAR_02_p___drv;
wire dut_MAR_03_p___drv;
wire dut_MAR_04_p___drv;
wire dut_MAR_05_p___drv;
wire dut_MAR_06_p___drv;
wire dut_MAR_07_p___drv;
wire dut_MAR_08_p___drv;
wire dut_MAR_09_p___drv;
wire dut_MAR_10_p___drv;
wire dut_MAR_11_p___drv;
wire dut_MAR_12_p___drv;
wire dut_MAR_13_p___drv;
wire dut_MAR_14_p___drv;
wire dut_MAR_15_p___drv;
wire dut_MemBM_0__drv;
wire dut_MemBM_1__drv;
wire dut_MemBM34__drv;
wire dut_PcFG_15__drv;
wire dut_RefOutstanding_p___drv;
wire dut_SignIfuData__drv;
wire dut_TWReq_02__drv;
wire dut_WantIfuHold_p___drv;
wire dut_WantIfuRef_p___drv;
dorado_serial_IFU #(.SYSPER(4)) dut(
.sys_clk(clk),
.ASEL_0_p_(stimulus[0]),
.BMux_00(stimulus[1] | dut_BMux_00__drv),
.BMux_01(stimulus[2] | dut_BMux_01__drv),
.BMux_02(stimulus[3] | dut_BMux_02__drv),
.BMux_03(stimulus[4] | dut_BMux_03__drv),
.BMux_04(stimulus[5] | dut_BMux_04__drv),
.BMux_05(stimulus[6] | dut_BMux_05__drv),
.BMux_06(stimulus[7] | dut_BMux_06__drv),
.BMux_07(stimulus[8] | dut_BMux_07__drv),
.BMux_08(stimulus[9] | dut_BMux_08__drv),
.BMux_09(stimulus[10] | dut_BMux_09__drv),
.BMux_10(stimulus[11] | dut_BMux_10__drv),
.BMux_11(stimulus[12] | dut_BMux_11__drv),
.BMux_12(stimulus[13] | dut_BMux_12__drv),
.BMux_13(stimulus[14] | dut_BMux_13__drv),
.BMux_14(stimulus[15] | dut_BMux_14__drv),
.BMux_15(stimulus[16] | dut_BMux_15__drv),
.CLK_ifu_p_(stimulus[17]),
.CLKEnable_p_a(stimulus[18]),
.CountMiss(stimulus[19]),
.DMuxClk(stimulus[20]),
.DMuxData(stimulus[21] | dut_DMuxData__drv),
.EmuOrFT_p_(stimulus[22]),
.EnableFG_p_(stimulus[23] | dut_EnableFG_p___drv),
.EventA(stimulus[24]),
.EventB(stimulus[25]),
.EventC(stimulus[26]),
.EventD(stimulus[27]),
.EventE(stimulus[28]),
.FA_eq_1_p_(stimulus[29]),
.FF_2(stimulus[30]),
.FF_3(stimulus[31]),
.FF_4(stimulus[32]),
.FF_5(stimulus[33]),
.FF_6(stimulus[34]),
.FF_7(stimulus[35]),
.FG_0(stimulus[36]),
.FG_1(stimulus[37]),
.FG_2(stimulus[38]),
.FG_3(stimulus[39]),
.FG_4(stimulus[40]),
.FG_5(stimulus[41]),
.FG_6(stimulus[42]),
.FG_7(stimulus[43]),
.FG_8(stimulus[44]),
.GDv_p_(stimulus[45] | dut_GDv_p___drv),
.GLd_p_(stimulus[46] | dut_GLd_p___drv),
.GenIn_00(stimulus[47]),
.GenIn_01(stimulus[48]),
.GenIn_02(stimulus[49]),
.GenIn_03(stimulus[50]),
.GenIn_04(stimulus[51]),
.GenIn_05(stimulus[52]),
.GenIn_06(stimulus[53]),
.GenIn_07(stimulus[54]),
.GenIn_08(stimulus[55]),
.GenIn_09(stimulus[56]),
.GenIn_10(stimulus[57]),
.GenIn_11(stimulus[58]),
.GenIn_12(stimulus[59]),
.GenIn_13(stimulus[60]),
.GenIn_14(stimulus[61]),
.GenIn_15(stimulus[62]),
.IOReset(stimulus[63]),
.IfuAWantsDifHit_p_(stimulus[64]),
.IfuAck(stimulus[65] | dut_IfuAck__drv),
.IfuFaultInEc2(stimulus[66] | dut_IfuFaultInEc2__drv),
.IfuHold(stimulus[67]),
.IfuNextMacro_p_(stimulus[68]),
.IfuStartMap_p_(stimulus[69]),
.MakeF_u_D(stimulus[70]),
.MemClkEn_p_a(stimulus[71]),
.MemSH(stimulus[72]),
.NextData_p_(stimulus[73]),
.Pendulum(stimulus[74]),
.RefOutstanding_p_(stimulus[75] | dut_RefOutstanding_p___drv),
.TempRef(stimulus[76]),
.WantIfuHold_p_(stimulus[77] | dut_WantIfuHold_p___drv),
.WantIfuRef_p_(stimulus[78] | dut_WantIfuRef_p___drv),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.CrryEvCntA__drv(dut_CrryEvCntA__drv),
.DMuxData__drv(dut_DMuxData__drv),
.EnableFG_p___drv(dut_EnableFG_p___drv),
.GDv_p___drv(dut_GDv_p___drv),
.GLd_p___drv(dut_GLd_p___drv),
.GenOut_00__drv(dut_GenOut_00__drv),
.GenOut_01__drv(dut_GenOut_01__drv),
.GenOut_02__drv(dut_GenOut_02__drv),
.GenOut_03__drv(dut_GenOut_03__drv),
.GenOut_04__drv(dut_GenOut_04__drv),
.GenOut_05__drv(dut_GenOut_05__drv),
.GenOut_06__drv(dut_GenOut_06__drv),
.GenOut_07__drv(dut_GenOut_07__drv),
.GenOut_08__drv(dut_GenOut_08__drv),
.GenOut_09__drv(dut_GenOut_09__drv),
.GenOut_10__drv(dut_GenOut_10__drv),
.GenOut_11__drv(dut_GenOut_11__drv),
.GenOut_12__drv(dut_GenOut_12__drv),
.GenOut_13__drv(dut_GenOut_13__drv),
.GenOut_14__drv(dut_GenOut_14__drv),
.GenOut_15__drv(dut_GenOut_15__drv),
.IfuAck__drv(dut_IfuAck__drv),
.IfuAddr_04_p___drv(dut_IfuAddr_04_p___drv),
.IfuAddr_05_p___drv(dut_IfuAddr_05_p___drv),
.IfuAddr_06_p___drv(dut_IfuAddr_06_p___drv),
.IfuAddr_07_p___drv(dut_IfuAddr_07_p___drv),
.IfuAddr_08_p___drv(dut_IfuAddr_08_p___drv),
.IfuAddr_09_p___drv(dut_IfuAddr_09_p___drv),
.IfuAddr_10_p___drv(dut_IfuAddr_10_p___drv),
.IfuAddr_11_p___drv(dut_IfuAddr_11_p___drv),
.IfuAddr_12_p___drv(dut_IfuAddr_12_p___drv),
.IfuAddr_13_p___drv(dut_IfuAddr_13_p___drv),
.IfuData_0__drv(dut_IfuData_0__drv),
.IfuData_1__drv(dut_IfuData_1__drv),
.IfuData_2__drv(dut_IfuData_2__drv),
.IfuData_3__drv(dut_IfuData_3__drv),
.IfuData_4__drv(dut_IfuData_4__drv),
.IfuData_5__drv(dut_IfuData_5__drv),
.IfuData_6__drv(dut_IfuData_6__drv),
.IfuData_7__drv(dut_IfuData_7__drv),
.IfuFaultInEc2__drv(dut_IfuFaultInEc2__drv),
.IfuRBaseSel_p___drv(dut_IfuRBaseSel_p___drv),
.MAR_00_p___drv(dut_MAR_00_p___drv),
.MAR_01_p___drv(dut_MAR_01_p___drv),
.MAR_02_p___drv(dut_MAR_02_p___drv),
.MAR_03_p___drv(dut_MAR_03_p___drv),
.MAR_04_p___drv(dut_MAR_04_p___drv),
.MAR_05_p___drv(dut_MAR_05_p___drv),
.MAR_06_p___drv(dut_MAR_06_p___drv),
.MAR_07_p___drv(dut_MAR_07_p___drv),
.MAR_08_p___drv(dut_MAR_08_p___drv),
.MAR_09_p___drv(dut_MAR_09_p___drv),
.MAR_10_p___drv(dut_MAR_10_p___drv),
.MAR_11_p___drv(dut_MAR_11_p___drv),
.MAR_12_p___drv(dut_MAR_12_p___drv),
.MAR_13_p___drv(dut_MAR_13_p___drv),
.MAR_14_p___drv(dut_MAR_14_p___drv),
.MAR_15_p___drv(dut_MAR_15_p___drv),
.MemBM_0__drv(dut_MemBM_0__drv),
.MemBM_1__drv(dut_MemBM_1__drv),
.MemBM34__drv(dut_MemBM34__drv),
.PcFG_15__drv(dut_PcFG_15__drv),
.RefOutstanding_p___drv(dut_RefOutstanding_p___drv),
.SignIfuData__drv(dut_SignIfuData__drv),
.TWReq_02__drv(dut_TWReq_02__drv),
.WantIfuHold_p___drv(dut_WantIfuHold_p___drv),
.WantIfuRef_p___drv(dut_WantIfuRef_p___drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[17:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_WantIfuRef_p___drv,dut_WantIfuHold_p___drv,dut_TWReq_02__drv,dut_SignIfuData__drv,dut_RefOutstanding_p___drv,dut_PcFG_15__drv,dut_MemBM34__drv,dut_MemBM_1__drv,dut_MemBM_0__drv,dut_MAR_15_p___drv,dut_MAR_14_p___drv,dut_MAR_13_p___drv,dut_MAR_12_p___drv,dut_MAR_11_p___drv,dut_MAR_10_p___drv,dut_MAR_09_p___drv,dut_MAR_08_p___drv,dut_MAR_07_p___drv,dut_MAR_06_p___drv,dut_MAR_05_p___drv,dut_MAR_04_p___drv,dut_MAR_03_p___drv,dut_MAR_02_p___drv,dut_MAR_01_p___drv,dut_MAR_00_p___drv,dut_IfuRBaseSel_p___drv,dut_IfuFaultInEc2__drv,dut_IfuData_7__drv,dut_IfuData_6__drv,dut_IfuData_5__drv,dut_IfuData_4__drv,dut_IfuData_3__drv,dut_IfuData_2__drv,dut_IfuData_1__drv,dut_IfuData_0__drv,dut_IfuAddr_13_p___drv,dut_IfuAddr_12_p___drv,dut_IfuAddr_11_p___drv,dut_IfuAddr_10_p___drv,dut_IfuAddr_09_p___drv,dut_IfuAddr_08_p___drv,dut_IfuAddr_07_p___drv,dut_IfuAddr_06_p___drv,dut_IfuAddr_05_p___drv,dut_IfuAddr_04_p___drv,dut_IfuAck__drv,dut_GenOut_15__drv,dut_GenOut_14__drv,dut_GenOut_13__drv,dut_GenOut_12__drv,dut_GenOut_11__drv,dut_GenOut_10__drv,dut_GenOut_09__drv,dut_GenOut_08__drv,dut_GenOut_07__drv,dut_GenOut_06__drv,dut_GenOut_05__drv,dut_GenOut_04__drv,dut_GenOut_03__drv,dut_GenOut_02__drv,dut_GenOut_01__drv,dut_GenOut_00__drv,dut_GLd_p___drv,dut_GDv_p___drv,dut_EnableFG_p___drv,dut_DMuxData__drv,dut_CrryEvCntA__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv};
assign dut_state[0+:1]=dut.clk1_p_Aa;
assign dut_state[1+:1]=dut.clk1_p_Ab;
assign dut_state[2+:1]=dut.clk1_p_Ac;
assign dut_state[3+:1]=dut.clk1_p_Da;
assign dut_state[4+:1]=dut.snapshot_bank_0.saved_q;
assign dut_state[5+:5]=dut.snapshot_bank_1.saved_q;
assign dut_state[10+:2]=dut.snapshot_bank_10.saved_q;
assign dut_state[12+:1]=dut.snapshot_bank_2.saved_q;
assign dut_state[13+:1]=dut.snapshot_bank_3.saved_q;
assign dut_state[14+:4]=dut.snapshot_bank_4.saved_q;
assign dut_state[18+:1]=dut.snapshot_bank_5.saved_q;
assign dut_state[19+:5]=dut.snapshot_bank_6.saved_q;
assign dut_state[24+:2]=dut.snapshot_bank_7.saved_q;
assign dut_state[26+:1]=dut.snapshot_bank_8.saved_q;
assign dut_state[27+:4]=dut.snapshot_bank_9.saved_q;
assign dut_state[31+:1]=dut.u_a04.ck_d;
assign dut_state[32+:4]=dut.u_a04.q;
assign dut_state[36+:6]=dut.u_a04.setup_pre;
assign dut_state[42+:1]=dut.u_a05.ck_d;
assign dut_state[43+:4]=dut.u_a05.q;
assign dut_state[47+:6]=dut.u_a05.setup_pre;
assign dut_state[53+:1]=dut.u_a08.ck_d;
assign dut_state[54+:4]=dut.u_a08.q;
assign dut_state[58+:6]=dut.u_a08.setup_pre;
assign dut_state[64+:1]=dut.u_a11.ck_d;
assign dut_state[65+:4]=dut.u_a11.q;
assign dut_state[69+:6]=dut.u_a11.setup_pre;
assign dut_state[75+:1]=dut.u_a13.ck_d;
assign dut_state[76+:6]=dut.u_a13.d_pre;
assign dut_state[82+:6]=dut.u_a13.q;
assign dut_state[88+:1]=dut.u_a15.ck_d;
assign dut_state[89+:4]=dut.u_a15.q;
assign dut_state[93+:6]=dut.u_a15.setup_pre;
assign dut_state[99+:1]=dut.u_a16.ck_d;
assign dut_state[100+:6]=dut.u_a16.d_pre;
assign dut_state[106+:6]=dut.u_a16.q;
assign dut_state[112+:1]=dut.u_a17.ck_d;
assign dut_state[113+:6]=dut.u_a17.d_pre;
assign dut_state[119+:6]=dut.u_a17.q;
assign dut_state[125+:1]=dut.u_a18.ck_d;
assign dut_state[126+:6]=dut.u_a18.d_pre;
assign dut_state[132+:6]=dut.u_a18.q;
assign dut_state[138+:1]=dut.u_a20.ck_d;
assign dut_state[139+:4]=dut.u_a20.q;
assign dut_state[143+:6]=dut.u_a20.setup_pre;
assign dut_state[149+:1]=dut.u_a21.cka_d;
assign dut_state[150+:1]=dut.u_a21.ckb_d;
assign dut_state[151+:1]=dut.u_a21.d_pre_a;
assign dut_state[152+:1]=dut.u_a21.d_pre_b;
assign dut_state[153+:1]=dut.u_a21.qa;
assign dut_state[154+:1]=dut.u_a21.qb;
assign dut_state[155+:4]=dut.u_b01.q;
assign dut_state[159+:1]=dut.u_b04.ck_d;
assign dut_state[160+:6]=dut.u_b04.d_pre;
assign dut_state[166+:6]=dut.u_b04.q;
assign dut_state[172+:1]=dut.u_b05.ck_d;
assign dut_state[173+:4]=dut.u_b05.d_pre;
assign dut_state[177+:1]=dut.u_b05.dl_pre;
assign dut_state[178+:1]=dut.u_b05.dr_pre;
assign dut_state[179+:4]=dut.u_b05.q;
assign dut_state[183+:2]=dut.u_b05.s_pre;
assign dut_state[185+:1]=dut.u_b06.ck_d;
assign dut_state[186+:4]=dut.u_b06.d_pre;
assign dut_state[190+:1]=dut.u_b06.dl_pre;
assign dut_state[191+:1]=dut.u_b06.dr_pre;
assign dut_state[192+:4]=dut.u_b06.q;
assign dut_state[196+:2]=dut.u_b06.s_pre;
assign dut_state[198+:1]=dut.u_b08.ck_d;
assign dut_state[199+:4]=dut.u_b08.q;
assign dut_state[203+:6]=dut.u_b08.setup_pre;
assign dut_state[209+:1]=dut.u_b11.ck_d;
assign dut_state[210+:4]=dut.u_b11.q;
assign dut_state[214+:6]=dut.u_b11.setup_pre;
assign dut_state[220+:1]=dut.u_b13.ck_d;
assign dut_state[221+:6]=dut.u_b13.d_pre;
assign dut_state[227+:6]=dut.u_b13.q;
assign dut_state[233+:1]=dut.u_b15.ck_d;
assign dut_state[234+:4]=dut.u_b15.q;
assign dut_state[238+:6]=dut.u_b15.setup_pre;
assign dut_state[244+:1]=dut.u_b16.ck_d;
assign dut_state[245+:6]=dut.u_b16.d_pre;
assign dut_state[251+:6]=dut.u_b16.q;
assign dut_state[257+:1]=dut.u_b18.ck_d;
assign dut_state[258+:6]=dut.u_b18.d_pre;
assign dut_state[264+:6]=dut.u_b18.q;
assign dut_state[270+:1]=dut.u_b20.ck_d;
assign dut_state[271+:6]=dut.u_b20.d_pre;
assign dut_state[277+:6]=dut.u_b20.q;
assign dut_state[283+:4]=dut.u_c01.q;
assign dut_state[287+:1]=dut.u_c04.ck_d;
assign dut_state[288+:4]=dut.u_c04.q;
assign dut_state[292+:6]=dut.u_c04.setup_pre;
assign dut_state[298+:1]=dut.u_c08.ck_d;
assign dut_state[299+:4]=dut.u_c08.q;
assign dut_state[303+:6]=dut.u_c08.setup_pre;
assign dut_state[309+:1]=dut.u_c11.ck_d;
assign dut_state[310+:4]=dut.u_c11.q;
assign dut_state[314+:6]=dut.u_c11.setup_pre;
assign dut_state[320+:1]=dut.u_c13.ck_d;
assign dut_state[321+:6]=dut.u_c13.d_pre;
assign dut_state[327+:6]=dut.u_c13.q;
assign dut_state[333+:1]=dut.u_c14.ck_d;
assign dut_state[334+:6]=dut.u_c14.d_pre;
assign dut_state[340+:6]=dut.u_c14.q;
assign dut_state[346+:1]=dut.u_c15.ck_d;
assign dut_state[347+:6]=dut.u_c15.d_pre;
assign dut_state[353+:6]=dut.u_c15.q;
assign dut_state[359+:1]=dut.u_c16.ck_d;
assign dut_state[360+:6]=dut.u_c16.d_pre;
assign dut_state[366+:6]=dut.u_c16.q;
assign dut_state[372+:1]=dut.u_c17.cka_d;
assign dut_state[373+:1]=dut.u_c17.ckb_d;
assign dut_state[374+:1]=dut.u_c17.d_pre_a;
assign dut_state[375+:1]=dut.u_c17.d_pre_b;
assign dut_state[376+:1]=dut.u_c17.qa;
assign dut_state[377+:1]=dut.u_c17.qb;
assign dut_state[378+:1]=dut.u_c20.ck_d;
assign dut_state[379+:6]=dut.u_c20.d_pre;
assign dut_state[385+:6]=dut.u_c20.q;
assign dut_state[391+:1]=dut.u_c22.ck_d;
assign dut_state[392+:6]=dut.u_c22.d_pre;
assign dut_state[398+:6]=dut.u_c22.q;
assign dut_state[404+:1]=dut.u_d04.ck_d;
assign dut_state[405+:4]=dut.u_d04.q;
assign dut_state[409+:6]=dut.u_d04.setup_pre;
assign dut_state[415+:1]=dut.u_d08.ck_d;
assign dut_state[416+:4]=dut.u_d08.q;
assign dut_state[420+:6]=dut.u_d08.setup_pre;
assign dut_state[426+:1]=dut.u_d11.ck_d;
assign dut_state[427+:4]=dut.u_d11.q;
assign dut_state[431+:6]=dut.u_d11.setup_pre;
assign dut_state[437+:1]=dut.u_d13.ck_d;
assign dut_state[438+:6]=dut.u_d13.d_pre;
assign dut_state[444+:6]=dut.u_d13.q;
assign dut_state[450+:1]=dut.u_d14.ck_d;
assign dut_state[451+:6]=dut.u_d14.d_pre;
assign dut_state[457+:6]=dut.u_d14.q;
assign dut_state[463+:1]=dut.u_d16.cka_d;
assign dut_state[464+:1]=dut.u_d16.ckb_d;
assign dut_state[465+:1]=dut.u_d16.d_pre_a;
assign dut_state[466+:1]=dut.u_d16.d_pre_b;
assign dut_state[467+:1]=dut.u_d16.qa;
assign dut_state[468+:1]=dut.u_d16.qb;
assign dut_state[469+:4]=dut.u_e01.q;
assign dut_state[473+:1]=dut.u_e04.ck_d;
assign dut_state[474+:6]=dut.u_e04.d_pre;
assign dut_state[480+:6]=dut.u_e04.q;
assign dut_state[486+:1]=dut.u_e06.ck_d;
assign dut_state[487+:4]=dut.u_e06.q;
assign dut_state[491+:6]=dut.u_e06.setup_pre;
assign dut_state[497+:1]=dut.u_e07.ck_d;
assign dut_state[498+:6]=dut.u_e07.d_pre;
assign dut_state[504+:6]=dut.u_e07.q;
assign dut_state[510+:1]=dut.u_e13.ck_d;
assign dut_state[511+:6]=dut.u_e13.d_pre;
assign dut_state[517+:6]=dut.u_e13.q;
assign dut_state[523+:1]=dut.u_e17.cka_d;
assign dut_state[524+:1]=dut.u_e17.ckb_d;
assign dut_state[525+:1]=dut.u_e17.d_pre_a;
assign dut_state[526+:1]=dut.u_e17.d_pre_b;
assign dut_state[527+:1]=dut.u_e17.qa;
assign dut_state[528+:1]=dut.u_e17.qb;
assign dut_state[529+:4]=dut.u_f01.q;
assign dut_state[533+:1]=dut.u_f03.ck_d;
assign dut_state[534+:4]=dut.u_f03.q;
assign dut_state[538+:6]=dut.u_f03.setup_pre;
assign dut_state[544+:1]=dut.u_f04.ck_d;
assign dut_state[545+:6]=dut.u_f04.d_pre;
assign dut_state[551+:6]=dut.u_f04.q;
assign dut_state[557+:1]=dut.u_f06.ck_d;
assign dut_state[558+:4]=dut.u_f06.q;
assign dut_state[562+:6]=dut.u_f06.setup_pre;
assign dut_state[568+:1]=dut.u_f14.ck_d;
assign dut_state[569+:4]=dut.u_f14.q;
assign dut_state[573+:6]=dut.u_f14.setup_pre;
assign dut_state[579+:1]=dut.u_f20.ck_d;
assign dut_state[580+:4]=dut.u_f20.jk_pre;
assign dut_state[584+:1]=dut.u_f20.qa;
assign dut_state[585+:1]=dut.u_f20.qb;
assign dut_state[586+:1]=dut.u_f21.ck_d;
assign dut_state[587+:4]=dut.u_f21.jk_pre;
assign dut_state[591+:1]=dut.u_f21.qa;
assign dut_state[592+:1]=dut.u_f21.qb;
assign dut_state[593+:1]=dut.u_f24.ck_d;
assign dut_state[594+:4]=dut.u_f24.q;
assign dut_state[598+:6]=dut.u_f24.setup_pre;
assign dut_state[604+:1]=dut.u_g04.ck_d;
assign dut_state[605+:6]=dut.u_g04.d_pre;
assign dut_state[611+:6]=dut.u_g04.q;
assign dut_state[617+:1]=dut.u_g05.ck_d;
assign dut_state[618+:6]=dut.u_g05.d_pre;
assign dut_state[624+:6]=dut.u_g05.q;
assign dut_state[630+:1]=dut.u_g07.ck_d;
assign dut_state[631+:6]=dut.u_g07.d_pre;
assign dut_state[637+:6]=dut.u_g07.q;
assign dut_state[643+:1]=dut.u_g19.ck_d;
assign dut_state[644+:4]=dut.u_g19.q;
assign dut_state[648+:6]=dut.u_g19.setup_pre;
assign dut_state[654+:1]=dut.u_h03.ck_d;
assign dut_state[655+:4]=dut.u_h03.q;
assign dut_state[659+:6]=dut.u_h03.setup_pre;
assign dut_state[665+:1]=dut.u_h04.ck_d;
assign dut_state[666+:4]=dut.u_h04.q;
assign dut_state[670+:6]=dut.u_h04.setup_pre;
assign dut_state[676+:1]=dut.u_h07.ck_d;
assign dut_state[677+:6]=dut.u_h07.d_pre;
assign dut_state[683+:6]=dut.u_h07.q;
assign dut_state[689+:1]=dut.u_h11.ck_d;
assign dut_state[690+:4]=dut.u_h11.q;
assign dut_state[694+:6]=dut.u_h11.setup_pre;
assign dut_state[700+:1]=dut.u_h12.ck_d;
assign dut_state[701+:4]=dut.u_h12.q;
assign dut_state[705+:6]=dut.u_h12.setup_pre;
assign dut_state[711+:1]=dut.u_h13.cka_d;
assign dut_state[712+:1]=dut.u_h13.ckb_d;
assign dut_state[713+:1]=dut.u_h13.d_pre_a;
assign dut_state[714+:1]=dut.u_h13.d_pre_b;
assign dut_state[715+:1]=dut.u_h13.qa;
assign dut_state[716+:1]=dut.u_h13.qb;
assign dut_state[717+:1]=dut.u_h17.ck_d;
assign dut_state[718+:4]=dut.u_h17.q;
assign dut_state[722+:6]=dut.u_h17.setup_pre;
assign dut_state[728+:1]=dut.u_i03.ck_d;
assign dut_state[729+:4]=dut.u_i03.q;
assign dut_state[733+:6]=dut.u_i03.setup_pre;
assign dut_state[739+:1]=dut.u_i04.ck_d;
assign dut_state[740+:4]=dut.u_i04.q;
assign dut_state[744+:6]=dut.u_i04.setup_pre;
assign dut_state[750+:1]=dut.u_i11.ck_d;
assign dut_state[751+:4]=dut.u_i11.q;
assign dut_state[755+:6]=dut.u_i11.setup_pre;
assign dut_state[761+:1]=dut.u_i12.ck_d;
assign dut_state[762+:4]=dut.u_i12.q;
assign dut_state[766+:6]=dut.u_i12.setup_pre;
assign dut_state[772+:1]=dut.u_i16.cka_d;
assign dut_state[773+:1]=dut.u_i16.ckb_d;
assign dut_state[774+:1]=dut.u_i16.d_pre_a;
assign dut_state[775+:1]=dut.u_i16.d_pre_b;
assign dut_state[776+:1]=dut.u_i16.qa;
assign dut_state[777+:1]=dut.u_i16.qb;
assign dut_state[778+:1]=dut.u_i20.ck_d;
assign dut_state[779+:4]=dut.u_i20.jk_pre;
assign dut_state[783+:1]=dut.u_i20.qa;
assign dut_state[784+:1]=dut.u_i20.qb;
assign dut_state[785+:1]=dut.u_i24.cka_d;
assign dut_state[786+:1]=dut.u_i24.ckb_d;
assign dut_state[787+:1]=dut.u_i24.d_pre_a;
assign dut_state[788+:1]=dut.u_i24.d_pre_b;
assign dut_state[789+:1]=dut.u_i24.qa;
assign dut_state[790+:1]=dut.u_i24.qb;
assign dut_state[791+:1]=dut.u_j06.cka_d;
assign dut_state[792+:1]=dut.u_j06.ckb_d;
assign dut_state[793+:1]=dut.u_j06.d_pre_a;
assign dut_state[794+:1]=dut.u_j06.d_pre_b;
assign dut_state[795+:1]=dut.u_j06.qa;
assign dut_state[796+:1]=dut.u_j06.qb;
assign dut_state[797+:1]=dut.u_j08.cka_d;
assign dut_state[798+:1]=dut.u_j08.ckb_d;
assign dut_state[799+:1]=dut.u_j08.d_pre_a;
assign dut_state[800+:1]=dut.u_j08.d_pre_b;
assign dut_state[801+:1]=dut.u_j08.qa;
assign dut_state[802+:1]=dut.u_j08.qb;
assign dut_state[803+:1]=dut.u_j11.ck_d;
assign dut_state[804+:4]=dut.u_j11.q;
assign dut_state[808+:6]=dut.u_j11.setup_pre;
assign dut_state[814+:1]=dut.u_j12.ck_d;
assign dut_state[815+:4]=dut.u_j12.q;
assign dut_state[819+:6]=dut.u_j12.setup_pre;
assign dut_state[825+:1]=dut.u_j20.cka_d;
assign dut_state[826+:1]=dut.u_j20.ckb_d;
assign dut_state[827+:1]=dut.u_j20.d_pre_a;
assign dut_state[828+:1]=dut.u_j20.d_pre_b;
assign dut_state[829+:1]=dut.u_j20.qa;
assign dut_state[830+:1]=dut.u_j20.qb;
assign dut_state[831+:1]=dut.u_j24.cka_d;
assign dut_state[832+:1]=dut.u_j24.ckb_d;
assign dut_state[833+:1]=dut.u_j24.d_pre_a;
assign dut_state[834+:1]=dut.u_j24.d_pre_b;
assign dut_state[835+:1]=dut.u_j24.qa;
assign dut_state[836+:1]=dut.u_j24.qb;
assign dut_state[837+:1]=dut.u_k03.ck_d;
assign dut_state[838+:4]=dut.u_k03.q;
assign dut_state[842+:6]=dut.u_k03.setup_pre;
assign dut_state[848+:1]=dut.u_k05.ck_d;
assign dut_state[849+:4]=dut.u_k05.q;
assign dut_state[853+:6]=dut.u_k05.setup_pre;
assign dut_state[859+:1]=dut.u_k06.ck_d;
assign dut_state[860+:6]=dut.u_k06.d_pre;
assign dut_state[866+:6]=dut.u_k06.q;
assign dut_state[872+:1]=dut.u_k08.cka_d;
assign dut_state[873+:1]=dut.u_k08.ckb_d;
assign dut_state[874+:1]=dut.u_k08.d_pre_a;
assign dut_state[875+:1]=dut.u_k08.d_pre_b;
assign dut_state[876+:1]=dut.u_k08.qa;
assign dut_state[877+:1]=dut.u_k08.qb;
assign dut_state[878+:1]=dut.u_k11.ck_d;
assign dut_state[879+:4]=dut.u_k11.q;
assign dut_state[883+:6]=dut.u_k11.setup_pre;
assign dut_state[889+:1]=dut.u_k12.ck_d;
assign dut_state[890+:4]=dut.u_k12.q;
assign dut_state[894+:6]=dut.u_k12.setup_pre;
assign dut_state[900+:1]=dut.u_k17.ck_d;
assign dut_state[901+:6]=dut.u_k17.d_pre;
assign dut_state[907+:6]=dut.u_k17.q;
assign dut_state[913+:1]=dut.u_k22.cka_d;
assign dut_state[914+:1]=dut.u_k22.ckb_d;
assign dut_state[915+:1]=dut.u_k22.d_pre_a;
assign dut_state[916+:1]=dut.u_k22.d_pre_b;
assign dut_state[917+:1]=dut.u_k22.qa;
assign dut_state[918+:1]=dut.u_k22.qb;
assign dut_state[919+:1]=dut.u_k23.cka_d;
assign dut_state[920+:1]=dut.u_k23.ckb_d;
assign dut_state[921+:1]=dut.u_k23.d_pre_a;
assign dut_state[922+:1]=dut.u_k23.d_pre_b;
assign dut_state[923+:1]=dut.u_k23.qa;
assign dut_state[924+:1]=dut.u_k23.qb;
assign dut_state[925+:1]=dut.u_k24.cka_d;
assign dut_state[926+:1]=dut.u_k24.ckb_d;
assign dut_state[927+:1]=dut.u_k24.d_pre_a;
assign dut_state[928+:1]=dut.u_k24.d_pre_b;
assign dut_state[929+:1]=dut.u_k24.qa;
assign dut_state[930+:1]=dut.u_k24.qb;
assign dut_state[931+:1]=dut.u_l01.cka_d;
assign dut_state[932+:1]=dut.u_l01.ckb_d;
assign dut_state[933+:1]=dut.u_l01.d_pre_a;
assign dut_state[934+:1]=dut.u_l01.d_pre_b;
assign dut_state[935+:1]=dut.u_l01.qa;
assign dut_state[936+:1]=dut.u_l01.qb;
assign dut_state[937+:1]=dut.u_l03.ck_d;
assign dut_state[938+:4]=dut.u_l03.q;
assign dut_state[942+:6]=dut.u_l03.setup_pre;
assign dut_state[948+:1]=dut.u_l04.ck_d;
assign dut_state[949+:4]=dut.u_l04.q;
assign dut_state[953+:6]=dut.u_l04.setup_pre;
assign dut_state[959+:1]=dut.u_l06.ck_d;
assign dut_state[960+:6]=dut.u_l06.d_pre;
assign dut_state[966+:6]=dut.u_l06.q;
assign dut_state[972+:1]=dut.u_l19.ck_d;
assign dut_state[973+:6]=dut.u_l19.d_pre;
assign dut_state[979+:6]=dut.u_l19.q;
assign dut_state[985+:1]=dut.u_l21.ck_d;
assign dut_state[986+:4]=dut.u_l21.jk_pre;
assign dut_state[990+:1]=dut.u_l21.qa;
assign dut_state[991+:1]=dut.u_l21.qb;
assign dut_state[992+:1]=dut.u_l22.ck_d;
assign dut_state[993+:6]=dut.u_l22.d_pre;
assign dut_state[999+:6]=dut.u_l22.q;
assign dut_probe[0+:1]=dut.snapshot_bank_0.mem[0+(probe_index%1024)];
assign dut_probe[1+:5]=dut.snapshot_bank_1.mem[0+(probe_index%1024)];
assign dut_probe[6+:2]=dut.snapshot_bank_10.mem[0+(probe_index%1024)];
assign dut_probe[8+:1]=dut.snapshot_bank_2.mem[0+(probe_index%1024)];
assign dut_probe[9+:1]=dut.snapshot_bank_3.mem[0+(probe_index%1024)];
assign dut_probe[10+:4]=dut.snapshot_bank_4.mem[0+(probe_index%1024)];
assign dut_probe[14+:1]=dut.snapshot_bank_5.mem[0+(probe_index%1024)];
assign dut_probe[15+:5]=dut.snapshot_bank_6.mem[0+(probe_index%1024)];
assign dut_probe[20+:2]=dut.snapshot_bank_7.mem[0+(probe_index%1024)];
assign dut_probe[22+:1]=dut.snapshot_bank_8.mem[0+(probe_index%1024)];
assign dut_probe[23+:4]=dut.snapshot_bank_9.mem[0+(probe_index%1024)];
assign all_helpers_frozen=&{dut.snapshot_bank_0.frozen,dut.snapshot_bank_1.frozen,dut.snapshot_bank_10.frozen,dut.snapshot_bank_2.frozen,dut.snapshot_bank_3.frozen,dut.snapshot_bank_4.frozen,dut.snapshot_bank_5.frozen,dut.snapshot_bank_6.frozen,dut.snapshot_bank_7.frozen,dut.snapshot_bank_8.frozen,dut.snapshot_bank_9.frozen,dut.state_frozen};
endmodule
