module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [132:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [137:0] reference_outputs,dut_outputs,
 output wire [1352:0] reference_state,dut_state,
 output wire [0:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire [4:0] reference_instruction_signals;
wire [31:0] reference_processor_debug;
wire [14:0] reference_processor_control;
wire reference_BMux_00__drv;
wire reference_BMux_01__drv;
wire reference_BMux_02__drv;
wire reference_BMux_03__drv;
wire reference_BMux_04__drv;
wire reference_BMux_05__drv;
wire reference_BMux_06__drv;
wire reference_BMux_07__drv;
wire reference_BMux_08__drv;
wire reference_BMux_09__drv;
wire reference_BMux_10__drv;
wire reference_BMux_11__drv;
wire reference_BMux_12__drv;
wire reference_BMux_13__drv;
wire reference_BMux_14__drv;
wire reference_BMux_15__drv;
wire reference_BNPC_02__drv;
wire reference_BNPC_03__drv;
wire reference_BNPC_04__drv;
wire reference_BNPC_05__drv;
wire reference_BNPC_06__drv;
wire reference_BNPC_07__drv;
wire reference_BNPC_08__drv;
wire reference_BNPC_09__drv;
wire reference_BNPC_10__drv;
wire reference_BNPC_11__drv;
wire reference_BNPC_12__drv;
wire reference_BNPC_13__drv;
wire reference_BNPC_14__drv;
wire reference_BNPC_15__drv;
wire reference_BNTGtCT_p_a__drv;
wire reference_BNTGtCT_p_b__drv;
wire reference_Block__drv;
wire reference_CHoldReq__drv;
wire reference_CLKEnable_p_a__drv;
wire reference_CLKEnable_p_b__drv;
wire reference_CLKEnable_p_c__drv;
wire reference_CRamClock__drv;
wire reference_DMuxClk__drv;
wire reference_DMuxData__drv;
wire reference_DoCBr__drv;
wire reference_FF_0__drv;
wire reference_FF_1__drv;
wire reference_FF_2__drv;
wire reference_FF_3__drv;
wire reference_FF_4__drv;
wire reference_FF_5__drv;
wire reference_FF_6__drv;
wire reference_FF_7__drv;
wire reference_FFok_p_a__drv;
wire reference_FFok_p_b__drv;
wire reference_Freeze__drv;
wire reference_IMRHPE_p___drv;
wire reference_IfuNextMacro_p___drv;
wire reference_MemClkEnable_p_a__drv;
wire reference_MemClkEnable_p_b__drv;
wire reference_MemSH__drv;
wire reference_MemSH_p___drv;
wire reference_Next_0__drv;
wire reference_Next_1__drv;
wire reference_Next_2__drv;
wire reference_Next_3__drv;
wire reference_NextMacro__drv;
wire reference_PrBlock_p___drv;
wire reference_SW__drv;
wire reference_SWm__drv;
wire reference_StartCycle_p_a__drv;
wire reference_TNIA_02__drv;
wire reference_TNIA_03__drv;
wire reference_TNIA_04__drv;
wire reference_TNIA_05__drv;
wire reference_TNIA_06__drv;
wire reference_TNIA_07__drv;
wire reference_TNIA_08__drv;
wire reference_TNIA_09__drv;
wire reference_TNIA_10__drv;
wire reference_TNIA_11__drv;
wire reference_TNIA_12__drv;
wire reference_TNIA_13__drv;
wire reference_TNIA_14__drv;
wire reference_TNIA_15__drv;
wire reference_UseDMD__drv;
wire reference__u_Dbuf__drv;
wire reference__u_Map__drv;
wire reference_jcnt__drv;
wire reference_rMIRa__drv;
ContA_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.ALUCarry(stimulus[0]),
.ASEL_0_p_a(stimulus[1]),
.BMux_00(stimulus[2] | reference_BMux_00__drv),
.BMux_01(stimulus[3] | reference_BMux_01__drv),
.BMux_02(stimulus[4] | reference_BMux_02__drv),
.BMux_03(stimulus[5] | reference_BMux_03__drv),
.BMux_04(stimulus[6] | reference_BMux_04__drv),
.BMux_05(stimulus[7] | reference_BMux_05__drv),
.BMux_06(stimulus[8] | reference_BMux_06__drv),
.BMux_07(stimulus[9] | reference_BMux_07__drv),
.BMux_08(stimulus[10] | reference_BMux_08__drv),
.BMux_09(stimulus[11] | reference_BMux_09__drv),
.BMux_10(stimulus[12] | reference_BMux_10__drv),
.BMux_11(stimulus[13] | reference_BMux_11__drv),
.BMux_12(stimulus[14] | reference_BMux_12__drv),
.BMux_13(stimulus[15] | reference_BMux_13__drv),
.BMux_14(stimulus[16] | reference_BMux_14__drv),
.BMux_15(stimulus[17] | reference_BMux_15__drv),
.BNPC_02(stimulus[18] | reference_BNPC_02__drv),
.BNPC_03(stimulus[19] | reference_BNPC_03__drv),
.BNPC_04(stimulus[20] | reference_BNPC_04__drv),
.BNPC_05(stimulus[21] | reference_BNPC_05__drv),
.BNPC_06(stimulus[22] | reference_BNPC_06__drv),
.BNPC_07(stimulus[23] | reference_BNPC_07__drv),
.BNPC_08(stimulus[24] | reference_BNPC_08__drv),
.BNPC_09(stimulus[25] | reference_BNPC_09__drv),
.BNPC_10(stimulus[26] | reference_BNPC_10__drv),
.BNPC_11(stimulus[27] | reference_BNPC_11__drv),
.BNPC_12(stimulus[28] | reference_BNPC_12__drv),
.BNPC_13(stimulus[29] | reference_BNPC_13__drv),
.BNPC_14(stimulus[30] | reference_BNPC_14__drv),
.BNPC_15(stimulus[31] | reference_BNPC_15__drv),
.BSEL_0_p_(stimulus[32]),
.CLK_ca_p_(stimulus[33]),
.CPAddr_0_p_(stimulus[34]),
.CPAddr_1_p_(stimulus[35]),
.CPAddr_2_p_(stimulus[36]),
.CPOut_0(stimulus[37]),
.CPOut_1(stimulus[38]),
.CPOut_2(stimulus[39]),
.CPOut_3(stimulus[40]),
.CPOut_4(stimulus[41]),
.CPOut_5(stimulus[42]),
.CPOut_6(stimulus[43]),
.CPOut_7(stimulus[44]),
.CPOut_8(stimulus[45]),
.CPStrb_p_(stimulus[46]),
.Cnt_eq_Zero_p_(stimulus[47]),
.DMuxClk(stimulus[48] | reference_DMuxClk__drv),
.DMuxData(stimulus[49] | reference_DMuxData__drv),
.Error_p_(stimulus[50]),
.FF_0(stimulus[51] | reference_FF_0__drv),
.Hold(stimulus[52]),
.IOatt(stimulus[53]),
.IfuAddr_04_p_(stimulus[54]),
.IfuAddr_05_p_(stimulus[55]),
.IfuAddr_06_p_(stimulus[56]),
.IfuAddr_07_p_(stimulus[57]),
.IfuAddr_08_p_(stimulus[58]),
.IfuAddr_09_p_(stimulus[59]),
.IfuAddr_10_p_(stimulus[60]),
.IfuAddr_11_p_(stimulus[61]),
.IfuAddr_12_p_(stimulus[62]),
.IfuAddr_13_p_(stimulus[63]),
.Overflow_p_(stimulus[64]),
.QBit_p_(stimulus[65]),
.ResEqZero_p_(stimulus[66]),
.ResLtZero_p_(stimulus[67]),
.RmLtZero_p_(stimulus[68]),
.RmOdd_p_(stimulus[69]),
.SWm(stimulus[70] | reference_SWm__drv),
.SetRun(stimulus[71]),
.SetRunRfsh(stimulus[72]),
.SetSS_p_(stimulus[73]),
.StopMIRClk(stimulus[74]),
.TNIA_02(stimulus[75] | reference_TNIA_02__drv),
.TNIA_03(stimulus[76] | reference_TNIA_03__drv),
.TNIA_04(stimulus[77] | reference_TNIA_04__drv),
.TNIA_05(stimulus[78] | reference_TNIA_05__drv),
.TNIA_06(stimulus[79] | reference_TNIA_06__drv),
.TNIA_07(stimulus[80] | reference_TNIA_07__drv),
.TNIA_08(stimulus[81] | reference_TNIA_08__drv),
.TNIA_09(stimulus[82] | reference_TNIA_09__drv),
.TNIA_10(stimulus[83] | reference_TNIA_10__drv),
.TNIA_11(stimulus[84] | reference_TNIA_11__drv),
.TNIA_12(stimulus[85] | reference_TNIA_12__drv),
.TNIA_13(stimulus[86] | reference_TNIA_13__drv),
.TNIA_14(stimulus[87] | reference_TNIA_14__drv),
.TNIA_15(stimulus[88] | reference_TNIA_15__drv),
.TWReq_01(stimulus[89]),
.TWReq_02(stimulus[90]),
.TWReq_03(stimulus[91]),
.TWReq_04(stimulus[92]),
.TWReq_05(stimulus[93]),
.TWReq_06(stimulus[94]),
.TWReq_07(stimulus[95]),
.TWReq_08(stimulus[96]),
.TWReq_09(stimulus[97]),
.TWReq_10(stimulus[98]),
.TWReq_11(stimulus[99]),
.TWReq_12(stimulus[100]),
.TWReq_13(stimulus[101]),
.TWReq_14(stimulus[102]),
.TWReq_15(stimulus[103]),
.WantIfuHold_p_(stimulus[104]),
.dBlock_p_(stimulus[105]),
.dFF_0(stimulus[106]),
.dFF_1(stimulus[107]),
.dFF_2(stimulus[108]),
.dFF_3(stimulus[109]),
.dFF_4(stimulus[110]),
.dFF_5(stimulus[111]),
.dFF_6(stimulus[112]),
.dFF_7(stimulus[113]),
.dIMOut_07(stimulus[114]),
.dIMOut_08(stimulus[115]),
.dIMOut_09(stimulus[116]),
.dIMOut_10(stimulus[117]),
.dIMOut_11(stimulus[118]),
.dIMOut_12(stimulus[119]),
.dIMOut_13(stimulus[120]),
.dIMOut_14(stimulus[121]),
.dIMOut_15(stimulus[122]),
.dIMRH(stimulus[123]),
.dJCN_0(stimulus[124]),
.dJCN_1(stimulus[125]),
.dJCN_2(stimulus[126]),
.dJCN_3(stimulus[127]),
.dJCN_4(stimulus[128]),
.dJCN_5(stimulus[129]),
.dJCN_6(stimulus[130]),
.dJCN_7(stimulus[131]),
.rMIRa(stimulus[132] | reference_rMIRa__drv),
.instruction_signals(reference_instruction_signals),
.processor_debug(reference_processor_debug),
.processor_control(reference_processor_control),
.BMux_00__drv(reference_BMux_00__drv),
.BMux_01__drv(reference_BMux_01__drv),
.BMux_02__drv(reference_BMux_02__drv),
.BMux_03__drv(reference_BMux_03__drv),
.BMux_04__drv(reference_BMux_04__drv),
.BMux_05__drv(reference_BMux_05__drv),
.BMux_06__drv(reference_BMux_06__drv),
.BMux_07__drv(reference_BMux_07__drv),
.BMux_08__drv(reference_BMux_08__drv),
.BMux_09__drv(reference_BMux_09__drv),
.BMux_10__drv(reference_BMux_10__drv),
.BMux_11__drv(reference_BMux_11__drv),
.BMux_12__drv(reference_BMux_12__drv),
.BMux_13__drv(reference_BMux_13__drv),
.BMux_14__drv(reference_BMux_14__drv),
.BMux_15__drv(reference_BMux_15__drv),
.BNPC_02__drv(reference_BNPC_02__drv),
.BNPC_03__drv(reference_BNPC_03__drv),
.BNPC_04__drv(reference_BNPC_04__drv),
.BNPC_05__drv(reference_BNPC_05__drv),
.BNPC_06__drv(reference_BNPC_06__drv),
.BNPC_07__drv(reference_BNPC_07__drv),
.BNPC_08__drv(reference_BNPC_08__drv),
.BNPC_09__drv(reference_BNPC_09__drv),
.BNPC_10__drv(reference_BNPC_10__drv),
.BNPC_11__drv(reference_BNPC_11__drv),
.BNPC_12__drv(reference_BNPC_12__drv),
.BNPC_13__drv(reference_BNPC_13__drv),
.BNPC_14__drv(reference_BNPC_14__drv),
.BNPC_15__drv(reference_BNPC_15__drv),
.BNTGtCT_p_a__drv(reference_BNTGtCT_p_a__drv),
.BNTGtCT_p_b__drv(reference_BNTGtCT_p_b__drv),
.Block__drv(reference_Block__drv),
.CHoldReq__drv(reference_CHoldReq__drv),
.CLKEnable_p_a__drv(reference_CLKEnable_p_a__drv),
.CLKEnable_p_b__drv(reference_CLKEnable_p_b__drv),
.CLKEnable_p_c__drv(reference_CLKEnable_p_c__drv),
.CRamClock__drv(reference_CRamClock__drv),
.DMuxClk__drv(reference_DMuxClk__drv),
.DMuxData__drv(reference_DMuxData__drv),
.DoCBr__drv(reference_DoCBr__drv),
.FF_0__drv(reference_FF_0__drv),
.FF_1__drv(reference_FF_1__drv),
.FF_2__drv(reference_FF_2__drv),
.FF_3__drv(reference_FF_3__drv),
.FF_4__drv(reference_FF_4__drv),
.FF_5__drv(reference_FF_5__drv),
.FF_6__drv(reference_FF_6__drv),
.FF_7__drv(reference_FF_7__drv),
.FFok_p_a__drv(reference_FFok_p_a__drv),
.FFok_p_b__drv(reference_FFok_p_b__drv),
.Freeze__drv(reference_Freeze__drv),
.IMRHPE_p___drv(reference_IMRHPE_p___drv),
.IfuNextMacro_p___drv(reference_IfuNextMacro_p___drv),
.MemClkEnable_p_a__drv(reference_MemClkEnable_p_a__drv),
.MemClkEnable_p_b__drv(reference_MemClkEnable_p_b__drv),
.MemSH__drv(reference_MemSH__drv),
.MemSH_p___drv(reference_MemSH_p___drv),
.Next_0__drv(reference_Next_0__drv),
.Next_1__drv(reference_Next_1__drv),
.Next_2__drv(reference_Next_2__drv),
.Next_3__drv(reference_Next_3__drv),
.NextMacro__drv(reference_NextMacro__drv),
.PrBlock_p___drv(reference_PrBlock_p___drv),
.SW__drv(reference_SW__drv),
.SWm__drv(reference_SWm__drv),
.StartCycle_p_a__drv(reference_StartCycle_p_a__drv),
.TNIA_02__drv(reference_TNIA_02__drv),
.TNIA_03__drv(reference_TNIA_03__drv),
.TNIA_04__drv(reference_TNIA_04__drv),
.TNIA_05__drv(reference_TNIA_05__drv),
.TNIA_06__drv(reference_TNIA_06__drv),
.TNIA_07__drv(reference_TNIA_07__drv),
.TNIA_08__drv(reference_TNIA_08__drv),
.TNIA_09__drv(reference_TNIA_09__drv),
.TNIA_10__drv(reference_TNIA_10__drv),
.TNIA_11__drv(reference_TNIA_11__drv),
.TNIA_12__drv(reference_TNIA_12__drv),
.TNIA_13__drv(reference_TNIA_13__drv),
.TNIA_14__drv(reference_TNIA_14__drv),
.TNIA_15__drv(reference_TNIA_15__drv),
.UseDMD__drv(reference_UseDMD__drv),
._u_Dbuf__drv(reference__u_Dbuf__drv),
._u_Map__drv(reference__u_Map__drv),
.jcnt__drv(reference_jcnt__drv),
.rMIRa__drv(reference_rMIRa__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[11:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.scan_hold_required(reference_hold),
.scan_fault(reference_fault)
);
assign reference_outputs={reference_rMIRa__drv,reference_jcnt__drv,reference__u_Map__drv,reference__u_Dbuf__drv,reference_UseDMD__drv,reference_TNIA_15__drv,reference_TNIA_14__drv,reference_TNIA_13__drv,reference_TNIA_12__drv,reference_TNIA_11__drv,reference_TNIA_10__drv,reference_TNIA_09__drv,reference_TNIA_08__drv,reference_TNIA_07__drv,reference_TNIA_06__drv,reference_TNIA_05__drv,reference_TNIA_04__drv,reference_TNIA_03__drv,reference_TNIA_02__drv,reference_StartCycle_p_a__drv,reference_SWm__drv,reference_SW__drv,reference_PrBlock_p___drv,reference_NextMacro__drv,reference_Next_3__drv,reference_Next_2__drv,reference_Next_1__drv,reference_Next_0__drv,reference_MemSH_p___drv,reference_MemSH__drv,reference_MemClkEnable_p_b__drv,reference_MemClkEnable_p_a__drv,reference_IfuNextMacro_p___drv,reference_IMRHPE_p___drv,reference_Freeze__drv,reference_FFok_p_b__drv,reference_FFok_p_a__drv,reference_FF_7__drv,reference_FF_6__drv,reference_FF_5__drv,reference_FF_4__drv,reference_FF_3__drv,reference_FF_2__drv,reference_FF_1__drv,reference_FF_0__drv,reference_DoCBr__drv,reference_DMuxData__drv,reference_DMuxClk__drv,reference_CRamClock__drv,reference_CLKEnable_p_c__drv,reference_CLKEnable_p_b__drv,reference_CLKEnable_p_a__drv,reference_CHoldReq__drv,reference_Block__drv,reference_BNTGtCT_p_b__drv,reference_BNTGtCT_p_a__drv,reference_BNPC_15__drv,reference_BNPC_14__drv,reference_BNPC_13__drv,reference_BNPC_12__drv,reference_BNPC_11__drv,reference_BNPC_10__drv,reference_BNPC_09__drv,reference_BNPC_08__drv,reference_BNPC_07__drv,reference_BNPC_06__drv,reference_BNPC_05__drv,reference_BNPC_04__drv,reference_BNPC_03__drv,reference_BNPC_02__drv,reference_BMux_15__drv,reference_BMux_14__drv,reference_BMux_13__drv,reference_BMux_12__drv,reference_BMux_11__drv,reference_BMux_10__drv,reference_BMux_09__drv,reference_BMux_08__drv,reference_BMux_07__drv,reference_BMux_06__drv,reference_BMux_05__drv,reference_BMux_04__drv,reference_BMux_03__drv,reference_BMux_02__drv,reference_BMux_01__drv,reference_BMux_00__drv,reference_processor_control,reference_processor_debug,reference_instruction_signals};
assign reference_state[0+:1]=reference.clk1_p_Aa;
assign reference_state[1+:1]=reference.clk1_p_Ab;
assign reference_state[2+:1]=reference.clk1_p_Ac;
assign reference_state[3+:1]=reference.clk1_p_Ca;
assign reference_state[4+:1]=reference.clk1_p_Cb;
assign reference_state[5+:1]=reference.clk1_p_Da;
assign reference_state[6+:1]=reference.u_a03.ck_d;
assign reference_state[7+:6]=reference.u_a03.d_pre;
assign reference_state[13+:6]=reference.u_a03.q;
assign reference_state[19+:4]=reference.u_a04.a_lat;
assign reference_state[23+:1]=reference.u_a04.ce_lat;
assign reference_state[24+:4]=reference.u_a04.d_lat;
assign reference_state[28+:64]={reference.u_a04.mem[15],reference.u_a04.mem[14],reference.u_a04.mem[13],reference.u_a04.mem[12],reference.u_a04.mem[11],reference.u_a04.mem[10],reference.u_a04.mem[9],reference.u_a04.mem[8],reference.u_a04.mem[7],reference.u_a04.mem[6],reference.u_a04.mem[5],reference.u_a04.mem[4],reference.u_a04.mem[3],reference.u_a04.mem[2],reference.u_a04.mem[1],reference.u_a04.mem[0]};
assign reference_state[92+:1]=reference.u_a04.we_d;
assign reference_state[93+:1]=reference.u_a09.ck_d;
assign reference_state[94+:4]=reference.u_a09.d_pre;
assign reference_state[98+:4]=reference.u_a09.q;
assign reference_state[102+:1]=reference.u_a12.ck_d;
assign reference_state[103+:6]=reference.u_a12.d_pre;
assign reference_state[109+:6]=reference.u_a12.q;
assign reference_state[115+:1]=reference.u_a23.cka_d;
assign reference_state[116+:1]=reference.u_a23.ckb_d;
assign reference_state[117+:1]=reference.u_a23.d_pre_a;
assign reference_state[118+:1]=reference.u_a23.d_pre_b;
assign reference_state[119+:1]=reference.u_a23.qa;
assign reference_state[120+:1]=reference.u_a23.qb;
assign reference_state[121+:1]=reference.u_a24.cka_d;
assign reference_state[122+:1]=reference.u_a24.ckb_d;
assign reference_state[123+:1]=reference.u_a24.d_pre_a;
assign reference_state[124+:1]=reference.u_a24.d_pre_b;
assign reference_state[125+:1]=reference.u_a24.qa;
assign reference_state[126+:1]=reference.u_a24.qb;
assign reference_state[127+:4]=reference.u_b04.a_lat;
assign reference_state[131+:1]=reference.u_b04.ce_lat;
assign reference_state[132+:4]=reference.u_b04.d_lat;
assign reference_state[136+:64]={reference.u_b04.mem[15],reference.u_b04.mem[14],reference.u_b04.mem[13],reference.u_b04.mem[12],reference.u_b04.mem[11],reference.u_b04.mem[10],reference.u_b04.mem[9],reference.u_b04.mem[8],reference.u_b04.mem[7],reference.u_b04.mem[6],reference.u_b04.mem[5],reference.u_b04.mem[4],reference.u_b04.mem[3],reference.u_b04.mem[2],reference.u_b04.mem[1],reference.u_b04.mem[0]};
assign reference_state[200+:1]=reference.u_b04.we_d;
assign reference_state[201+:1]=reference.u_b09.ck_d;
assign reference_state[202+:4]=reference.u_b09.d_pre;
assign reference_state[206+:4]=reference.u_b09.q;
assign reference_state[210+:1]=reference.u_b12.ck_d;
assign reference_state[211+:6]=reference.u_b12.d_pre;
assign reference_state[217+:6]=reference.u_b12.q;
assign reference_state[223+:1]=reference.u_b13.ck_d;
assign reference_state[224+:4]=reference.u_b13.q;
assign reference_state[228+:6]=reference.u_b13.setup_pre;
assign reference_state[234+:1]=reference.u_b23.cka_d;
assign reference_state[235+:1]=reference.u_b23.ckb_d;
assign reference_state[236+:1]=reference.u_b23.d_pre_a;
assign reference_state[237+:1]=reference.u_b23.d_pre_b;
assign reference_state[238+:1]=reference.u_b23.qa;
assign reference_state[239+:1]=reference.u_b23.qb;
assign reference_state[240+:1]=reference.u_b24.cka_d;
assign reference_state[241+:1]=reference.u_b24.ckb_d;
assign reference_state[242+:1]=reference.u_b24.d_pre_a;
assign reference_state[243+:1]=reference.u_b24.d_pre_b;
assign reference_state[244+:1]=reference.u_b24.qa;
assign reference_state[245+:1]=reference.u_b24.qb;
assign reference_state[246+:4]=reference.u_c04.a_lat;
assign reference_state[250+:1]=reference.u_c04.ce_lat;
assign reference_state[251+:4]=reference.u_c04.d_lat;
assign reference_state[255+:64]={reference.u_c04.mem[15],reference.u_c04.mem[14],reference.u_c04.mem[13],reference.u_c04.mem[12],reference.u_c04.mem[11],reference.u_c04.mem[10],reference.u_c04.mem[9],reference.u_c04.mem[8],reference.u_c04.mem[7],reference.u_c04.mem[6],reference.u_c04.mem[5],reference.u_c04.mem[4],reference.u_c04.mem[3],reference.u_c04.mem[2],reference.u_c04.mem[1],reference.u_c04.mem[0]};
assign reference_state[319+:1]=reference.u_c04.we_d;
assign reference_state[320+:1]=reference.u_c09.ck_d;
assign reference_state[321+:4]=reference.u_c09.d_pre;
assign reference_state[325+:4]=reference.u_c09.q;
assign reference_state[329+:1]=reference.u_c13.ck_d;
assign reference_state[330+:6]=reference.u_c13.d_pre;
assign reference_state[336+:6]=reference.u_c13.q;
assign reference_state[342+:1]=reference.u_c14.ck_d;
assign reference_state[343+:4]=reference.u_c14.q;
assign reference_state[347+:6]=reference.u_c14.setup_pre;
assign reference_state[353+:1]=reference.u_c17.ck_d;
assign reference_state[354+:6]=reference.u_c17.d_pre;
assign reference_state[360+:6]=reference.u_c17.q;
assign reference_state[366+:1]=reference.u_c23.cka_d;
assign reference_state[367+:1]=reference.u_c23.ckb_d;
assign reference_state[368+:1]=reference.u_c23.d_pre_a;
assign reference_state[369+:1]=reference.u_c23.d_pre_b;
assign reference_state[370+:1]=reference.u_c23.qa;
assign reference_state[371+:1]=reference.u_c23.qb;
assign reference_state[372+:1]=reference.u_c24.cka_d;
assign reference_state[373+:1]=reference.u_c24.ckb_d;
assign reference_state[374+:1]=reference.u_c24.d_pre_a;
assign reference_state[375+:1]=reference.u_c24.d_pre_b;
assign reference_state[376+:1]=reference.u_c24.qa;
assign reference_state[377+:1]=reference.u_c24.qb;
assign reference_state[378+:4]=reference.u_d04.a_lat;
assign reference_state[382+:1]=reference.u_d04.ce_lat;
assign reference_state[383+:4]=reference.u_d04.d_lat;
assign reference_state[387+:64]={reference.u_d04.mem[15],reference.u_d04.mem[14],reference.u_d04.mem[13],reference.u_d04.mem[12],reference.u_d04.mem[11],reference.u_d04.mem[10],reference.u_d04.mem[9],reference.u_d04.mem[8],reference.u_d04.mem[7],reference.u_d04.mem[6],reference.u_d04.mem[5],reference.u_d04.mem[4],reference.u_d04.mem[3],reference.u_d04.mem[2],reference.u_d04.mem[1],reference.u_d04.mem[0]};
assign reference_state[451+:1]=reference.u_d04.we_d;
assign reference_state[452+:1]=reference.u_d09.ck_d;
assign reference_state[453+:4]=reference.u_d09.d_pre;
assign reference_state[457+:4]=reference.u_d09.q;
assign reference_state[461+:1]=reference.u_d14.ck_d;
assign reference_state[462+:4]=reference.u_d14.q;
assign reference_state[466+:6]=reference.u_d14.setup_pre;
assign reference_state[472+:1]=reference.u_d17.ck_d;
assign reference_state[473+:6]=reference.u_d17.d_pre;
assign reference_state[479+:6]=reference.u_d17.q;
assign reference_state[485+:1]=reference.u_d23.cka_d;
assign reference_state[486+:1]=reference.u_d23.ckb_d;
assign reference_state[487+:1]=reference.u_d23.d_pre_a;
assign reference_state[488+:1]=reference.u_d23.d_pre_b;
assign reference_state[489+:1]=reference.u_d23.qa;
assign reference_state[490+:1]=reference.u_d23.qb;
assign reference_state[491+:1]=reference.u_d24.cka_d;
assign reference_state[492+:1]=reference.u_d24.ckb_d;
assign reference_state[493+:1]=reference.u_d24.d_pre_a;
assign reference_state[494+:1]=reference.u_d24.d_pre_b;
assign reference_state[495+:1]=reference.u_d24.qa;
assign reference_state[496+:1]=reference.u_d24.qb;
assign reference_state[497+:4]=reference.u_e04.a_lat;
assign reference_state[501+:1]=reference.u_e04.ce_lat;
assign reference_state[502+:4]=reference.u_e04.d_lat;
assign reference_state[506+:64]={reference.u_e04.mem[15],reference.u_e04.mem[14],reference.u_e04.mem[13],reference.u_e04.mem[12],reference.u_e04.mem[11],reference.u_e04.mem[10],reference.u_e04.mem[9],reference.u_e04.mem[8],reference.u_e04.mem[7],reference.u_e04.mem[6],reference.u_e04.mem[5],reference.u_e04.mem[4],reference.u_e04.mem[3],reference.u_e04.mem[2],reference.u_e04.mem[1],reference.u_e04.mem[0]};
assign reference_state[570+:1]=reference.u_e04.we_d;
assign reference_state[571+:1]=reference.u_e07.ck_d;
assign reference_state[572+:6]=reference.u_e07.d_pre;
assign reference_state[578+:6]=reference.u_e07.q;
assign reference_state[584+:1]=reference.u_e08.ck_d;
assign reference_state[585+:6]=reference.u_e08.d_pre;
assign reference_state[591+:6]=reference.u_e08.q;
assign reference_state[597+:1]=reference.u_e14.ck_d;
assign reference_state[598+:4]=reference.u_e14.q;
assign reference_state[602+:6]=reference.u_e14.setup_pre;
assign reference_state[608+:1]=reference.u_e23.cka_d;
assign reference_state[609+:1]=reference.u_e23.ckb_d;
assign reference_state[610+:1]=reference.u_e23.d_pre_a;
assign reference_state[611+:1]=reference.u_e23.d_pre_b;
assign reference_state[612+:1]=reference.u_e23.qa;
assign reference_state[613+:1]=reference.u_e23.qb;
assign reference_state[614+:1]=reference.u_e24.cka_d;
assign reference_state[615+:1]=reference.u_e24.ckb_d;
assign reference_state[616+:1]=reference.u_e24.d_pre_a;
assign reference_state[617+:1]=reference.u_e24.d_pre_b;
assign reference_state[618+:1]=reference.u_e24.qa;
assign reference_state[619+:1]=reference.u_e24.qb;
assign reference_state[620+:1]=reference.u_f02.ck_d;
assign reference_state[621+:6]=reference.u_f02.d_pre;
assign reference_state[627+:6]=reference.u_f02.q;
assign reference_state[633+:1]=reference.u_f04.ck_d;
assign reference_state[634+:4]=reference.u_f04.q;
assign reference_state[638+:6]=reference.u_f04.setup_pre;
assign reference_state[644+:1]=reference.u_f05.cka_d;
assign reference_state[645+:1]=reference.u_f05.ckb_d;
assign reference_state[646+:1]=reference.u_f05.d_pre_a;
assign reference_state[647+:1]=reference.u_f05.d_pre_b;
assign reference_state[648+:1]=reference.u_f05.qa;
assign reference_state[649+:1]=reference.u_f05.qb;
assign reference_state[650+:1]=reference.u_f06.cka_d;
assign reference_state[651+:1]=reference.u_f06.ckb_d;
assign reference_state[652+:1]=reference.u_f06.d_pre_a;
assign reference_state[653+:1]=reference.u_f06.d_pre_b;
assign reference_state[654+:1]=reference.u_f06.qa;
assign reference_state[655+:1]=reference.u_f06.qb;
assign reference_state[656+:1]=reference.u_f14.cka_d;
assign reference_state[657+:1]=reference.u_f14.ckb_d;
assign reference_state[658+:1]=reference.u_f14.d_pre_a;
assign reference_state[659+:1]=reference.u_f14.d_pre_b;
assign reference_state[660+:1]=reference.u_f14.qa;
assign reference_state[661+:1]=reference.u_f14.qb;
assign reference_state[662+:1]=reference.u_f15.cka_d;
assign reference_state[663+:1]=reference.u_f15.ckb_d;
assign reference_state[664+:1]=reference.u_f15.d_pre_a;
assign reference_state[665+:1]=reference.u_f15.d_pre_b;
assign reference_state[666+:1]=reference.u_f15.qa;
assign reference_state[667+:1]=reference.u_f15.qb;
assign reference_state[668+:1]=reference.u_g02.ck_d;
assign reference_state[669+:6]=reference.u_g02.d_pre;
assign reference_state[675+:6]=reference.u_g02.q;
assign reference_state[681+:1]=reference.u_g06.cka_d;
assign reference_state[682+:1]=reference.u_g06.ckb_d;
assign reference_state[683+:1]=reference.u_g06.d_pre_a;
assign reference_state[684+:1]=reference.u_g06.d_pre_b;
assign reference_state[685+:1]=reference.u_g06.qa;
assign reference_state[686+:1]=reference.u_g06.qb;
assign reference_state[687+:1]=reference.u_g07.cka_d;
assign reference_state[688+:1]=reference.u_g07.ckb_d;
assign reference_state[689+:1]=reference.u_g07.d_pre_a;
assign reference_state[690+:1]=reference.u_g07.d_pre_b;
assign reference_state[691+:1]=reference.u_g07.qa;
assign reference_state[692+:1]=reference.u_g07.qb;
assign reference_state[693+:1]=reference.u_g16.cka_d;
assign reference_state[694+:1]=reference.u_g16.ckb_d;
assign reference_state[695+:1]=reference.u_g16.d_pre_a;
assign reference_state[696+:1]=reference.u_g16.d_pre_b;
assign reference_state[697+:1]=reference.u_g16.qa;
assign reference_state[698+:1]=reference.u_g16.qb;
assign reference_state[699+:1]=reference.u_h02.ck_d;
assign reference_state[700+:6]=reference.u_h02.d_pre;
assign reference_state[706+:6]=reference.u_h02.q;
assign reference_state[712+:1]=reference.u_h05.ck_d;
assign reference_state[713+:6]=reference.u_h05.d_pre;
assign reference_state[719+:6]=reference.u_h05.q;
assign reference_state[725+:1]=reference.u_h08.ck_d;
assign reference_state[726+:4]=reference.u_h08.d_pre;
assign reference_state[730+:1]=reference.u_h08.dl_pre;
assign reference_state[731+:1]=reference.u_h08.dr_pre;
assign reference_state[732+:4]=reference.u_h08.q;
assign reference_state[736+:2]=reference.u_h08.s_pre;
assign reference_state[738+:1]=reference.u_h09.ck_d;
assign reference_state[739+:4]=reference.u_h09.d_pre;
assign reference_state[743+:1]=reference.u_h09.dl_pre;
assign reference_state[744+:1]=reference.u_h09.dr_pre;
assign reference_state[745+:4]=reference.u_h09.q;
assign reference_state[749+:2]=reference.u_h09.s_pre;
assign reference_state[751+:1]=reference.u_h12.ck_d;
assign reference_state[752+:6]=reference.u_h12.d_pre;
assign reference_state[758+:6]=reference.u_h12.q;
assign reference_state[764+:1]=reference.u_i02.ck_d;
assign reference_state[765+:6]=reference.u_i02.d_pre;
assign reference_state[771+:6]=reference.u_i02.q;
assign reference_state[777+:1]=reference.u_i03.ck_d;
assign reference_state[778+:6]=reference.u_i03.d_pre;
assign reference_state[784+:6]=reference.u_i03.q;
assign reference_state[790+:4]=reference.u_i13.a_lat;
assign reference_state[794+:1]=reference.u_i13.ce_lat;
assign reference_state[795+:4]=reference.u_i13.d_lat;
assign reference_state[799+:64]={reference.u_i13.mem[15],reference.u_i13.mem[14],reference.u_i13.mem[13],reference.u_i13.mem[12],reference.u_i13.mem[11],reference.u_i13.mem[10],reference.u_i13.mem[9],reference.u_i13.mem[8],reference.u_i13.mem[7],reference.u_i13.mem[6],reference.u_i13.mem[5],reference.u_i13.mem[4],reference.u_i13.mem[3],reference.u_i13.mem[2],reference.u_i13.mem[1],reference.u_i13.mem[0]};
assign reference_state[863+:1]=reference.u_i13.we_d;
assign reference_state[864+:4]=reference.u_i14.q;
assign reference_state[868+:1]=reference.u_i15.ck_d;
assign reference_state[869+:4]=reference.u_i15.q;
assign reference_state[873+:6]=reference.u_i15.setup_pre;
assign reference_state[879+:1]=reference.u_j01.cka_d;
assign reference_state[880+:1]=reference.u_j01.ckb_d;
assign reference_state[881+:1]=reference.u_j01.d_pre_a;
assign reference_state[882+:1]=reference.u_j01.d_pre_b;
assign reference_state[883+:1]=reference.u_j01.qa;
assign reference_state[884+:1]=reference.u_j01.qb;
assign reference_state[885+:1]=reference.u_j02.ck_d;
assign reference_state[886+:6]=reference.u_j02.d_pre;
assign reference_state[892+:6]=reference.u_j02.q;
assign reference_state[898+:1]=reference.u_j04.cka_d;
assign reference_state[899+:1]=reference.u_j04.ckb_d;
assign reference_state[900+:1]=reference.u_j04.d_pre_a;
assign reference_state[901+:1]=reference.u_j04.d_pre_b;
assign reference_state[902+:1]=reference.u_j04.qa;
assign reference_state[903+:1]=reference.u_j04.qb;
assign reference_state[904+:1]=reference.u_j08.cka_d;
assign reference_state[905+:1]=reference.u_j08.ckb_d;
assign reference_state[906+:1]=reference.u_j08.d_pre_a;
assign reference_state[907+:1]=reference.u_j08.d_pre_b;
assign reference_state[908+:1]=reference.u_j08.qa;
assign reference_state[909+:1]=reference.u_j08.qb;
assign reference_state[910+:1]=reference.u_j09.cka_d;
assign reference_state[911+:1]=reference.u_j09.ckb_d;
assign reference_state[912+:1]=reference.u_j09.d_pre_a;
assign reference_state[913+:1]=reference.u_j09.d_pre_b;
assign reference_state[914+:1]=reference.u_j09.qa;
assign reference_state[915+:1]=reference.u_j09.qb;
assign reference_state[916+:4]=reference.u_j13.a_lat;
assign reference_state[920+:1]=reference.u_j13.ce_lat;
assign reference_state[921+:4]=reference.u_j13.d_lat;
assign reference_state[925+:64]={reference.u_j13.mem[15],reference.u_j13.mem[14],reference.u_j13.mem[13],reference.u_j13.mem[12],reference.u_j13.mem[11],reference.u_j13.mem[10],reference.u_j13.mem[9],reference.u_j13.mem[8],reference.u_j13.mem[7],reference.u_j13.mem[6],reference.u_j13.mem[5],reference.u_j13.mem[4],reference.u_j13.mem[3],reference.u_j13.mem[2],reference.u_j13.mem[1],reference.u_j13.mem[0]};
assign reference_state[989+:1]=reference.u_j13.we_d;
assign reference_state[990+:4]=reference.u_j14.q;
assign reference_state[994+:1]=reference.u_j15.ck_d;
assign reference_state[995+:4]=reference.u_j15.q;
assign reference_state[999+:6]=reference.u_j15.setup_pre;
assign reference_state[1005+:1]=reference.u_j16.ck_d;
assign reference_state[1006+:6]=reference.u_j16.d_pre;
assign reference_state[1012+:6]=reference.u_j16.q;
assign reference_state[1018+:1]=reference.u_k01.cka_d;
assign reference_state[1019+:1]=reference.u_k01.ckb_d;
assign reference_state[1020+:1]=reference.u_k01.d_pre_a;
assign reference_state[1021+:1]=reference.u_k01.d_pre_b;
assign reference_state[1022+:1]=reference.u_k01.qa;
assign reference_state[1023+:1]=reference.u_k01.qb;
assign reference_state[1024+:1]=reference.u_k02.cka_d;
assign reference_state[1025+:1]=reference.u_k02.ckb_d;
assign reference_state[1026+:1]=reference.u_k02.d_pre_a;
assign reference_state[1027+:1]=reference.u_k02.d_pre_b;
assign reference_state[1028+:1]=reference.u_k02.qa;
assign reference_state[1029+:1]=reference.u_k02.qb;
assign reference_state[1030+:1]=reference.u_k03.cka_d;
assign reference_state[1031+:1]=reference.u_k03.ckb_d;
assign reference_state[1032+:1]=reference.u_k03.d_pre_a;
assign reference_state[1033+:1]=reference.u_k03.d_pre_b;
assign reference_state[1034+:1]=reference.u_k03.qa;
assign reference_state[1035+:1]=reference.u_k03.qb;
assign reference_state[1036+:1]=reference.u_k04.cka_d;
assign reference_state[1037+:1]=reference.u_k04.ckb_d;
assign reference_state[1038+:1]=reference.u_k04.d_pre_a;
assign reference_state[1039+:1]=reference.u_k04.d_pre_b;
assign reference_state[1040+:1]=reference.u_k04.qa;
assign reference_state[1041+:1]=reference.u_k04.qb;
assign reference_state[1042+:1]=reference.u_k05.cka_d;
assign reference_state[1043+:1]=reference.u_k05.ckb_d;
assign reference_state[1044+:1]=reference.u_k05.d_pre_a;
assign reference_state[1045+:1]=reference.u_k05.d_pre_b;
assign reference_state[1046+:1]=reference.u_k05.qa;
assign reference_state[1047+:1]=reference.u_k05.qb;
assign reference_state[1048+:1]=reference.u_k10.ck_d;
assign reference_state[1049+:6]=reference.u_k10.d_pre;
assign reference_state[1055+:6]=reference.u_k10.q;
assign reference_state[1061+:1]=reference.u_k12.ck_d;
assign reference_state[1062+:6]=reference.u_k12.d_pre;
assign reference_state[1068+:6]=reference.u_k12.q;
assign reference_state[1074+:4]=reference.u_k13.a_lat;
assign reference_state[1078+:1]=reference.u_k13.ce_lat;
assign reference_state[1079+:4]=reference.u_k13.d_lat;
assign reference_state[1083+:64]={reference.u_k13.mem[15],reference.u_k13.mem[14],reference.u_k13.mem[13],reference.u_k13.mem[12],reference.u_k13.mem[11],reference.u_k13.mem[10],reference.u_k13.mem[9],reference.u_k13.mem[8],reference.u_k13.mem[7],reference.u_k13.mem[6],reference.u_k13.mem[5],reference.u_k13.mem[4],reference.u_k13.mem[3],reference.u_k13.mem[2],reference.u_k13.mem[1],reference.u_k13.mem[0]};
assign reference_state[1147+:1]=reference.u_k13.we_d;
assign reference_state[1148+:4]=reference.u_k14.q;
assign reference_state[1152+:1]=reference.u_k15.ck_d;
assign reference_state[1153+:4]=reference.u_k15.q;
assign reference_state[1157+:6]=reference.u_k15.setup_pre;
assign reference_state[1163+:1]=reference.u_k16.ck_d;
assign reference_state[1164+:6]=reference.u_k16.d_pre;
assign reference_state[1170+:6]=reference.u_k16.q;
assign reference_state[1176+:1]=reference.u_l02.cka_d;
assign reference_state[1177+:1]=reference.u_l02.ckb_d;
assign reference_state[1178+:1]=reference.u_l02.d_pre_a;
assign reference_state[1179+:1]=reference.u_l02.d_pre_b;
assign reference_state[1180+:1]=reference.u_l02.qa;
assign reference_state[1181+:1]=reference.u_l02.qb;
assign reference_state[1182+:1]=reference.u_l03.cka_d;
assign reference_state[1183+:1]=reference.u_l03.ckb_d;
assign reference_state[1184+:1]=reference.u_l03.d_pre_a;
assign reference_state[1185+:1]=reference.u_l03.d_pre_b;
assign reference_state[1186+:1]=reference.u_l03.qa;
assign reference_state[1187+:1]=reference.u_l03.qb;
assign reference_state[1188+:1]=reference.u_l04.cka_d;
assign reference_state[1189+:1]=reference.u_l04.ckb_d;
assign reference_state[1190+:1]=reference.u_l04.d_pre_a;
assign reference_state[1191+:1]=reference.u_l04.d_pre_b;
assign reference_state[1192+:1]=reference.u_l04.qa;
assign reference_state[1193+:1]=reference.u_l04.qb;
assign reference_state[1194+:1]=reference.u_l05.cka_d;
assign reference_state[1195+:1]=reference.u_l05.ckb_d;
assign reference_state[1196+:1]=reference.u_l05.d_pre_a;
assign reference_state[1197+:1]=reference.u_l05.d_pre_b;
assign reference_state[1198+:1]=reference.u_l05.qa;
assign reference_state[1199+:1]=reference.u_l05.qb;
assign reference_state[1200+:1]=reference.u_l06.cka_d;
assign reference_state[1201+:1]=reference.u_l06.ckb_d;
assign reference_state[1202+:1]=reference.u_l06.d_pre_a;
assign reference_state[1203+:1]=reference.u_l06.d_pre_b;
assign reference_state[1204+:1]=reference.u_l06.qa;
assign reference_state[1205+:1]=reference.u_l06.qb;
assign reference_state[1206+:1]=reference.u_l07.cka_d;
assign reference_state[1207+:1]=reference.u_l07.ckb_d;
assign reference_state[1208+:1]=reference.u_l07.d_pre_a;
assign reference_state[1209+:1]=reference.u_l07.d_pre_b;
assign reference_state[1210+:1]=reference.u_l07.qa;
assign reference_state[1211+:1]=reference.u_l07.qb;
assign reference_state[1212+:1]=reference.u_l11.ck_d;
assign reference_state[1213+:6]=reference.u_l11.d_pre;
assign reference_state[1219+:6]=reference.u_l11.q;
assign reference_state[1225+:1]=reference.u_l12.ck_d;
assign reference_state[1226+:6]=reference.u_l12.d_pre;
assign reference_state[1232+:6]=reference.u_l12.q;
assign reference_state[1238+:4]=reference.u_l13.a_lat;
assign reference_state[1242+:1]=reference.u_l13.ce_lat;
assign reference_state[1243+:4]=reference.u_l13.d_lat;
assign reference_state[1247+:64]={reference.u_l13.mem[15],reference.u_l13.mem[14],reference.u_l13.mem[13],reference.u_l13.mem[12],reference.u_l13.mem[11],reference.u_l13.mem[10],reference.u_l13.mem[9],reference.u_l13.mem[8],reference.u_l13.mem[7],reference.u_l13.mem[6],reference.u_l13.mem[5],reference.u_l13.mem[4],reference.u_l13.mem[3],reference.u_l13.mem[2],reference.u_l13.mem[1],reference.u_l13.mem[0]};
assign reference_state[1311+:1]=reference.u_l13.we_d;
assign reference_state[1312+:4]=reference.u_l14.q;
assign reference_state[1316+:1]=reference.u_l15.ck_d;
assign reference_state[1317+:4]=reference.u_l15.q;
assign reference_state[1321+:6]=reference.u_l15.setup_pre;
assign reference_state[1327+:1]=reference.u_l16.ck_d;
assign reference_state[1328+:6]=reference.u_l16.d_pre;
assign reference_state[1334+:6]=reference.u_l16.q;
assign reference_state[1340+:1]=reference.u_l17.ck_d;
assign reference_state[1341+:6]=reference.u_l17.d_pre;
assign reference_state[1347+:6]=reference.u_l17.q;
assign reference_probe=1'b0;
wire [4:0] dut_instruction_signals;
wire [31:0] dut_processor_debug;
wire [14:0] dut_processor_control;
wire dut_BMux_00__drv;
wire dut_BMux_01__drv;
wire dut_BMux_02__drv;
wire dut_BMux_03__drv;
wire dut_BMux_04__drv;
wire dut_BMux_05__drv;
wire dut_BMux_06__drv;
wire dut_BMux_07__drv;
wire dut_BMux_08__drv;
wire dut_BMux_09__drv;
wire dut_BMux_10__drv;
wire dut_BMux_11__drv;
wire dut_BMux_12__drv;
wire dut_BMux_13__drv;
wire dut_BMux_14__drv;
wire dut_BMux_15__drv;
wire dut_BNPC_02__drv;
wire dut_BNPC_03__drv;
wire dut_BNPC_04__drv;
wire dut_BNPC_05__drv;
wire dut_BNPC_06__drv;
wire dut_BNPC_07__drv;
wire dut_BNPC_08__drv;
wire dut_BNPC_09__drv;
wire dut_BNPC_10__drv;
wire dut_BNPC_11__drv;
wire dut_BNPC_12__drv;
wire dut_BNPC_13__drv;
wire dut_BNPC_14__drv;
wire dut_BNPC_15__drv;
wire dut_BNTGtCT_p_a__drv;
wire dut_BNTGtCT_p_b__drv;
wire dut_Block__drv;
wire dut_CHoldReq__drv;
wire dut_CLKEnable_p_a__drv;
wire dut_CLKEnable_p_b__drv;
wire dut_CLKEnable_p_c__drv;
wire dut_CRamClock__drv;
wire dut_DMuxClk__drv;
wire dut_DMuxData__drv;
wire dut_DoCBr__drv;
wire dut_FF_0__drv;
wire dut_FF_1__drv;
wire dut_FF_2__drv;
wire dut_FF_3__drv;
wire dut_FF_4__drv;
wire dut_FF_5__drv;
wire dut_FF_6__drv;
wire dut_FF_7__drv;
wire dut_FFok_p_a__drv;
wire dut_FFok_p_b__drv;
wire dut_Freeze__drv;
wire dut_IMRHPE_p___drv;
wire dut_IfuNextMacro_p___drv;
wire dut_MemClkEnable_p_a__drv;
wire dut_MemClkEnable_p_b__drv;
wire dut_MemSH__drv;
wire dut_MemSH_p___drv;
wire dut_Next_0__drv;
wire dut_Next_1__drv;
wire dut_Next_2__drv;
wire dut_Next_3__drv;
wire dut_NextMacro__drv;
wire dut_PrBlock_p___drv;
wire dut_SW__drv;
wire dut_SWm__drv;
wire dut_StartCycle_p_a__drv;
wire dut_TNIA_02__drv;
wire dut_TNIA_03__drv;
wire dut_TNIA_04__drv;
wire dut_TNIA_05__drv;
wire dut_TNIA_06__drv;
wire dut_TNIA_07__drv;
wire dut_TNIA_08__drv;
wire dut_TNIA_09__drv;
wire dut_TNIA_10__drv;
wire dut_TNIA_11__drv;
wire dut_TNIA_12__drv;
wire dut_TNIA_13__drv;
wire dut_TNIA_14__drv;
wire dut_TNIA_15__drv;
wire dut_UseDMD__drv;
wire dut__u_Dbuf__drv;
wire dut__u_Map__drv;
wire dut_jcnt__drv;
wire dut_rMIRa__drv;
dorado_serial_ContA #(.SYSPER(4)) dut(
.sys_clk(clk),
.ALUCarry(stimulus[0]),
.ASEL_0_p_a(stimulus[1]),
.BMux_00(stimulus[2] | dut_BMux_00__drv),
.BMux_01(stimulus[3] | dut_BMux_01__drv),
.BMux_02(stimulus[4] | dut_BMux_02__drv),
.BMux_03(stimulus[5] | dut_BMux_03__drv),
.BMux_04(stimulus[6] | dut_BMux_04__drv),
.BMux_05(stimulus[7] | dut_BMux_05__drv),
.BMux_06(stimulus[8] | dut_BMux_06__drv),
.BMux_07(stimulus[9] | dut_BMux_07__drv),
.BMux_08(stimulus[10] | dut_BMux_08__drv),
.BMux_09(stimulus[11] | dut_BMux_09__drv),
.BMux_10(stimulus[12] | dut_BMux_10__drv),
.BMux_11(stimulus[13] | dut_BMux_11__drv),
.BMux_12(stimulus[14] | dut_BMux_12__drv),
.BMux_13(stimulus[15] | dut_BMux_13__drv),
.BMux_14(stimulus[16] | dut_BMux_14__drv),
.BMux_15(stimulus[17] | dut_BMux_15__drv),
.BNPC_02(stimulus[18] | dut_BNPC_02__drv),
.BNPC_03(stimulus[19] | dut_BNPC_03__drv),
.BNPC_04(stimulus[20] | dut_BNPC_04__drv),
.BNPC_05(stimulus[21] | dut_BNPC_05__drv),
.BNPC_06(stimulus[22] | dut_BNPC_06__drv),
.BNPC_07(stimulus[23] | dut_BNPC_07__drv),
.BNPC_08(stimulus[24] | dut_BNPC_08__drv),
.BNPC_09(stimulus[25] | dut_BNPC_09__drv),
.BNPC_10(stimulus[26] | dut_BNPC_10__drv),
.BNPC_11(stimulus[27] | dut_BNPC_11__drv),
.BNPC_12(stimulus[28] | dut_BNPC_12__drv),
.BNPC_13(stimulus[29] | dut_BNPC_13__drv),
.BNPC_14(stimulus[30] | dut_BNPC_14__drv),
.BNPC_15(stimulus[31] | dut_BNPC_15__drv),
.BSEL_0_p_(stimulus[32]),
.CLK_ca_p_(stimulus[33]),
.CPAddr_0_p_(stimulus[34]),
.CPAddr_1_p_(stimulus[35]),
.CPAddr_2_p_(stimulus[36]),
.CPOut_0(stimulus[37]),
.CPOut_1(stimulus[38]),
.CPOut_2(stimulus[39]),
.CPOut_3(stimulus[40]),
.CPOut_4(stimulus[41]),
.CPOut_5(stimulus[42]),
.CPOut_6(stimulus[43]),
.CPOut_7(stimulus[44]),
.CPOut_8(stimulus[45]),
.CPStrb_p_(stimulus[46]),
.Cnt_eq_Zero_p_(stimulus[47]),
.DMuxClk(stimulus[48] | dut_DMuxClk__drv),
.DMuxData(stimulus[49] | dut_DMuxData__drv),
.Error_p_(stimulus[50]),
.FF_0(stimulus[51] | dut_FF_0__drv),
.Hold(stimulus[52]),
.IOatt(stimulus[53]),
.IfuAddr_04_p_(stimulus[54]),
.IfuAddr_05_p_(stimulus[55]),
.IfuAddr_06_p_(stimulus[56]),
.IfuAddr_07_p_(stimulus[57]),
.IfuAddr_08_p_(stimulus[58]),
.IfuAddr_09_p_(stimulus[59]),
.IfuAddr_10_p_(stimulus[60]),
.IfuAddr_11_p_(stimulus[61]),
.IfuAddr_12_p_(stimulus[62]),
.IfuAddr_13_p_(stimulus[63]),
.Overflow_p_(stimulus[64]),
.QBit_p_(stimulus[65]),
.ResEqZero_p_(stimulus[66]),
.ResLtZero_p_(stimulus[67]),
.RmLtZero_p_(stimulus[68]),
.RmOdd_p_(stimulus[69]),
.SWm(stimulus[70] | dut_SWm__drv),
.SetRun(stimulus[71]),
.SetRunRfsh(stimulus[72]),
.SetSS_p_(stimulus[73]),
.StopMIRClk(stimulus[74]),
.TNIA_02(stimulus[75] | dut_TNIA_02__drv),
.TNIA_03(stimulus[76] | dut_TNIA_03__drv),
.TNIA_04(stimulus[77] | dut_TNIA_04__drv),
.TNIA_05(stimulus[78] | dut_TNIA_05__drv),
.TNIA_06(stimulus[79] | dut_TNIA_06__drv),
.TNIA_07(stimulus[80] | dut_TNIA_07__drv),
.TNIA_08(stimulus[81] | dut_TNIA_08__drv),
.TNIA_09(stimulus[82] | dut_TNIA_09__drv),
.TNIA_10(stimulus[83] | dut_TNIA_10__drv),
.TNIA_11(stimulus[84] | dut_TNIA_11__drv),
.TNIA_12(stimulus[85] | dut_TNIA_12__drv),
.TNIA_13(stimulus[86] | dut_TNIA_13__drv),
.TNIA_14(stimulus[87] | dut_TNIA_14__drv),
.TNIA_15(stimulus[88] | dut_TNIA_15__drv),
.TWReq_01(stimulus[89]),
.TWReq_02(stimulus[90]),
.TWReq_03(stimulus[91]),
.TWReq_04(stimulus[92]),
.TWReq_05(stimulus[93]),
.TWReq_06(stimulus[94]),
.TWReq_07(stimulus[95]),
.TWReq_08(stimulus[96]),
.TWReq_09(stimulus[97]),
.TWReq_10(stimulus[98]),
.TWReq_11(stimulus[99]),
.TWReq_12(stimulus[100]),
.TWReq_13(stimulus[101]),
.TWReq_14(stimulus[102]),
.TWReq_15(stimulus[103]),
.WantIfuHold_p_(stimulus[104]),
.dBlock_p_(stimulus[105]),
.dFF_0(stimulus[106]),
.dFF_1(stimulus[107]),
.dFF_2(stimulus[108]),
.dFF_3(stimulus[109]),
.dFF_4(stimulus[110]),
.dFF_5(stimulus[111]),
.dFF_6(stimulus[112]),
.dFF_7(stimulus[113]),
.dIMOut_07(stimulus[114]),
.dIMOut_08(stimulus[115]),
.dIMOut_09(stimulus[116]),
.dIMOut_10(stimulus[117]),
.dIMOut_11(stimulus[118]),
.dIMOut_12(stimulus[119]),
.dIMOut_13(stimulus[120]),
.dIMOut_14(stimulus[121]),
.dIMOut_15(stimulus[122]),
.dIMRH(stimulus[123]),
.dJCN_0(stimulus[124]),
.dJCN_1(stimulus[125]),
.dJCN_2(stimulus[126]),
.dJCN_3(stimulus[127]),
.dJCN_4(stimulus[128]),
.dJCN_5(stimulus[129]),
.dJCN_6(stimulus[130]),
.dJCN_7(stimulus[131]),
.rMIRa(stimulus[132] | dut_rMIRa__drv),
.instruction_signals(dut_instruction_signals),
.processor_debug(dut_processor_debug),
.processor_control(dut_processor_control),
.BMux_00__drv(dut_BMux_00__drv),
.BMux_01__drv(dut_BMux_01__drv),
.BMux_02__drv(dut_BMux_02__drv),
.BMux_03__drv(dut_BMux_03__drv),
.BMux_04__drv(dut_BMux_04__drv),
.BMux_05__drv(dut_BMux_05__drv),
.BMux_06__drv(dut_BMux_06__drv),
.BMux_07__drv(dut_BMux_07__drv),
.BMux_08__drv(dut_BMux_08__drv),
.BMux_09__drv(dut_BMux_09__drv),
.BMux_10__drv(dut_BMux_10__drv),
.BMux_11__drv(dut_BMux_11__drv),
.BMux_12__drv(dut_BMux_12__drv),
.BMux_13__drv(dut_BMux_13__drv),
.BMux_14__drv(dut_BMux_14__drv),
.BMux_15__drv(dut_BMux_15__drv),
.BNPC_02__drv(dut_BNPC_02__drv),
.BNPC_03__drv(dut_BNPC_03__drv),
.BNPC_04__drv(dut_BNPC_04__drv),
.BNPC_05__drv(dut_BNPC_05__drv),
.BNPC_06__drv(dut_BNPC_06__drv),
.BNPC_07__drv(dut_BNPC_07__drv),
.BNPC_08__drv(dut_BNPC_08__drv),
.BNPC_09__drv(dut_BNPC_09__drv),
.BNPC_10__drv(dut_BNPC_10__drv),
.BNPC_11__drv(dut_BNPC_11__drv),
.BNPC_12__drv(dut_BNPC_12__drv),
.BNPC_13__drv(dut_BNPC_13__drv),
.BNPC_14__drv(dut_BNPC_14__drv),
.BNPC_15__drv(dut_BNPC_15__drv),
.BNTGtCT_p_a__drv(dut_BNTGtCT_p_a__drv),
.BNTGtCT_p_b__drv(dut_BNTGtCT_p_b__drv),
.Block__drv(dut_Block__drv),
.CHoldReq__drv(dut_CHoldReq__drv),
.CLKEnable_p_a__drv(dut_CLKEnable_p_a__drv),
.CLKEnable_p_b__drv(dut_CLKEnable_p_b__drv),
.CLKEnable_p_c__drv(dut_CLKEnable_p_c__drv),
.CRamClock__drv(dut_CRamClock__drv),
.DMuxClk__drv(dut_DMuxClk__drv),
.DMuxData__drv(dut_DMuxData__drv),
.DoCBr__drv(dut_DoCBr__drv),
.FF_0__drv(dut_FF_0__drv),
.FF_1__drv(dut_FF_1__drv),
.FF_2__drv(dut_FF_2__drv),
.FF_3__drv(dut_FF_3__drv),
.FF_4__drv(dut_FF_4__drv),
.FF_5__drv(dut_FF_5__drv),
.FF_6__drv(dut_FF_6__drv),
.FF_7__drv(dut_FF_7__drv),
.FFok_p_a__drv(dut_FFok_p_a__drv),
.FFok_p_b__drv(dut_FFok_p_b__drv),
.Freeze__drv(dut_Freeze__drv),
.IMRHPE_p___drv(dut_IMRHPE_p___drv),
.IfuNextMacro_p___drv(dut_IfuNextMacro_p___drv),
.MemClkEnable_p_a__drv(dut_MemClkEnable_p_a__drv),
.MemClkEnable_p_b__drv(dut_MemClkEnable_p_b__drv),
.MemSH__drv(dut_MemSH__drv),
.MemSH_p___drv(dut_MemSH_p___drv),
.Next_0__drv(dut_Next_0__drv),
.Next_1__drv(dut_Next_1__drv),
.Next_2__drv(dut_Next_2__drv),
.Next_3__drv(dut_Next_3__drv),
.NextMacro__drv(dut_NextMacro__drv),
.PrBlock_p___drv(dut_PrBlock_p___drv),
.SW__drv(dut_SW__drv),
.SWm__drv(dut_SWm__drv),
.StartCycle_p_a__drv(dut_StartCycle_p_a__drv),
.TNIA_02__drv(dut_TNIA_02__drv),
.TNIA_03__drv(dut_TNIA_03__drv),
.TNIA_04__drv(dut_TNIA_04__drv),
.TNIA_05__drv(dut_TNIA_05__drv),
.TNIA_06__drv(dut_TNIA_06__drv),
.TNIA_07__drv(dut_TNIA_07__drv),
.TNIA_08__drv(dut_TNIA_08__drv),
.TNIA_09__drv(dut_TNIA_09__drv),
.TNIA_10__drv(dut_TNIA_10__drv),
.TNIA_11__drv(dut_TNIA_11__drv),
.TNIA_12__drv(dut_TNIA_12__drv),
.TNIA_13__drv(dut_TNIA_13__drv),
.TNIA_14__drv(dut_TNIA_14__drv),
.TNIA_15__drv(dut_TNIA_15__drv),
.UseDMD__drv(dut_UseDMD__drv),
._u_Dbuf__drv(dut__u_Dbuf__drv),
._u_Map__drv(dut__u_Map__drv),
.jcnt__drv(dut_jcnt__drv),
.rMIRa__drv(dut_rMIRa__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[11:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_rMIRa__drv,dut_jcnt__drv,dut__u_Map__drv,dut__u_Dbuf__drv,dut_UseDMD__drv,dut_TNIA_15__drv,dut_TNIA_14__drv,dut_TNIA_13__drv,dut_TNIA_12__drv,dut_TNIA_11__drv,dut_TNIA_10__drv,dut_TNIA_09__drv,dut_TNIA_08__drv,dut_TNIA_07__drv,dut_TNIA_06__drv,dut_TNIA_05__drv,dut_TNIA_04__drv,dut_TNIA_03__drv,dut_TNIA_02__drv,dut_StartCycle_p_a__drv,dut_SWm__drv,dut_SW__drv,dut_PrBlock_p___drv,dut_NextMacro__drv,dut_Next_3__drv,dut_Next_2__drv,dut_Next_1__drv,dut_Next_0__drv,dut_MemSH_p___drv,dut_MemSH__drv,dut_MemClkEnable_p_b__drv,dut_MemClkEnable_p_a__drv,dut_IfuNextMacro_p___drv,dut_IMRHPE_p___drv,dut_Freeze__drv,dut_FFok_p_b__drv,dut_FFok_p_a__drv,dut_FF_7__drv,dut_FF_6__drv,dut_FF_5__drv,dut_FF_4__drv,dut_FF_3__drv,dut_FF_2__drv,dut_FF_1__drv,dut_FF_0__drv,dut_DoCBr__drv,dut_DMuxData__drv,dut_DMuxClk__drv,dut_CRamClock__drv,dut_CLKEnable_p_c__drv,dut_CLKEnable_p_b__drv,dut_CLKEnable_p_a__drv,dut_CHoldReq__drv,dut_Block__drv,dut_BNTGtCT_p_b__drv,dut_BNTGtCT_p_a__drv,dut_BNPC_15__drv,dut_BNPC_14__drv,dut_BNPC_13__drv,dut_BNPC_12__drv,dut_BNPC_11__drv,dut_BNPC_10__drv,dut_BNPC_09__drv,dut_BNPC_08__drv,dut_BNPC_07__drv,dut_BNPC_06__drv,dut_BNPC_05__drv,dut_BNPC_04__drv,dut_BNPC_03__drv,dut_BNPC_02__drv,dut_BMux_15__drv,dut_BMux_14__drv,dut_BMux_13__drv,dut_BMux_12__drv,dut_BMux_11__drv,dut_BMux_10__drv,dut_BMux_09__drv,dut_BMux_08__drv,dut_BMux_07__drv,dut_BMux_06__drv,dut_BMux_05__drv,dut_BMux_04__drv,dut_BMux_03__drv,dut_BMux_02__drv,dut_BMux_01__drv,dut_BMux_00__drv,dut_processor_control,dut_processor_debug,dut_instruction_signals};
assign dut_state[0+:1]=dut.clk1_p_Aa;
assign dut_state[1+:1]=dut.clk1_p_Ab;
assign dut_state[2+:1]=dut.clk1_p_Ac;
assign dut_state[3+:1]=dut.clk1_p_Ca;
assign dut_state[4+:1]=dut.clk1_p_Cb;
assign dut_state[5+:1]=dut.clk1_p_Da;
assign dut_state[6+:1]=dut.u_a03.ck_d;
assign dut_state[7+:6]=dut.u_a03.d_pre;
assign dut_state[13+:6]=dut.u_a03.q;
assign dut_state[19+:4]=dut.u_a04.a_lat;
assign dut_state[23+:1]=dut.u_a04.ce_lat;
assign dut_state[24+:4]=dut.u_a04.d_lat;
assign dut_state[28+:64]={dut.u_a04.mem[15],dut.u_a04.mem[14],dut.u_a04.mem[13],dut.u_a04.mem[12],dut.u_a04.mem[11],dut.u_a04.mem[10],dut.u_a04.mem[9],dut.u_a04.mem[8],dut.u_a04.mem[7],dut.u_a04.mem[6],dut.u_a04.mem[5],dut.u_a04.mem[4],dut.u_a04.mem[3],dut.u_a04.mem[2],dut.u_a04.mem[1],dut.u_a04.mem[0]};
assign dut_state[92+:1]=dut.u_a04.we_d;
assign dut_state[93+:1]=dut.u_a09.ck_d;
assign dut_state[94+:4]=dut.u_a09.d_pre;
assign dut_state[98+:4]=dut.u_a09.q;
assign dut_state[102+:1]=dut.u_a12.ck_d;
assign dut_state[103+:6]=dut.u_a12.d_pre;
assign dut_state[109+:6]=dut.u_a12.q;
assign dut_state[115+:1]=dut.u_a23.cka_d;
assign dut_state[116+:1]=dut.u_a23.ckb_d;
assign dut_state[117+:1]=dut.u_a23.d_pre_a;
assign dut_state[118+:1]=dut.u_a23.d_pre_b;
assign dut_state[119+:1]=dut.u_a23.qa;
assign dut_state[120+:1]=dut.u_a23.qb;
assign dut_state[121+:1]=dut.u_a24.cka_d;
assign dut_state[122+:1]=dut.u_a24.ckb_d;
assign dut_state[123+:1]=dut.u_a24.d_pre_a;
assign dut_state[124+:1]=dut.u_a24.d_pre_b;
assign dut_state[125+:1]=dut.u_a24.qa;
assign dut_state[126+:1]=dut.u_a24.qb;
assign dut_state[127+:4]=dut.u_b04.a_lat;
assign dut_state[131+:1]=dut.u_b04.ce_lat;
assign dut_state[132+:4]=dut.u_b04.d_lat;
assign dut_state[136+:64]={dut.u_b04.mem[15],dut.u_b04.mem[14],dut.u_b04.mem[13],dut.u_b04.mem[12],dut.u_b04.mem[11],dut.u_b04.mem[10],dut.u_b04.mem[9],dut.u_b04.mem[8],dut.u_b04.mem[7],dut.u_b04.mem[6],dut.u_b04.mem[5],dut.u_b04.mem[4],dut.u_b04.mem[3],dut.u_b04.mem[2],dut.u_b04.mem[1],dut.u_b04.mem[0]};
assign dut_state[200+:1]=dut.u_b04.we_d;
assign dut_state[201+:1]=dut.u_b09.ck_d;
assign dut_state[202+:4]=dut.u_b09.d_pre;
assign dut_state[206+:4]=dut.u_b09.q;
assign dut_state[210+:1]=dut.u_b12.ck_d;
assign dut_state[211+:6]=dut.u_b12.d_pre;
assign dut_state[217+:6]=dut.u_b12.q;
assign dut_state[223+:1]=dut.u_b13.ck_d;
assign dut_state[224+:4]=dut.u_b13.q;
assign dut_state[228+:6]=dut.u_b13.setup_pre;
assign dut_state[234+:1]=dut.u_b23.cka_d;
assign dut_state[235+:1]=dut.u_b23.ckb_d;
assign dut_state[236+:1]=dut.u_b23.d_pre_a;
assign dut_state[237+:1]=dut.u_b23.d_pre_b;
assign dut_state[238+:1]=dut.u_b23.qa;
assign dut_state[239+:1]=dut.u_b23.qb;
assign dut_state[240+:1]=dut.u_b24.cka_d;
assign dut_state[241+:1]=dut.u_b24.ckb_d;
assign dut_state[242+:1]=dut.u_b24.d_pre_a;
assign dut_state[243+:1]=dut.u_b24.d_pre_b;
assign dut_state[244+:1]=dut.u_b24.qa;
assign dut_state[245+:1]=dut.u_b24.qb;
assign dut_state[246+:4]=dut.u_c04.a_lat;
assign dut_state[250+:1]=dut.u_c04.ce_lat;
assign dut_state[251+:4]=dut.u_c04.d_lat;
assign dut_state[255+:64]={dut.u_c04.mem[15],dut.u_c04.mem[14],dut.u_c04.mem[13],dut.u_c04.mem[12],dut.u_c04.mem[11],dut.u_c04.mem[10],dut.u_c04.mem[9],dut.u_c04.mem[8],dut.u_c04.mem[7],dut.u_c04.mem[6],dut.u_c04.mem[5],dut.u_c04.mem[4],dut.u_c04.mem[3],dut.u_c04.mem[2],dut.u_c04.mem[1],dut.u_c04.mem[0]};
assign dut_state[319+:1]=dut.u_c04.we_d;
assign dut_state[320+:1]=dut.u_c09.ck_d;
assign dut_state[321+:4]=dut.u_c09.d_pre;
assign dut_state[325+:4]=dut.u_c09.q;
assign dut_state[329+:1]=dut.u_c13.ck_d;
assign dut_state[330+:6]=dut.u_c13.d_pre;
assign dut_state[336+:6]=dut.u_c13.q;
assign dut_state[342+:1]=dut.u_c14.ck_d;
assign dut_state[343+:4]=dut.u_c14.q;
assign dut_state[347+:6]=dut.u_c14.setup_pre;
assign dut_state[353+:1]=dut.u_c17.ck_d;
assign dut_state[354+:6]=dut.u_c17.d_pre;
assign dut_state[360+:6]=dut.u_c17.q;
assign dut_state[366+:1]=dut.u_c23.cka_d;
assign dut_state[367+:1]=dut.u_c23.ckb_d;
assign dut_state[368+:1]=dut.u_c23.d_pre_a;
assign dut_state[369+:1]=dut.u_c23.d_pre_b;
assign dut_state[370+:1]=dut.u_c23.qa;
assign dut_state[371+:1]=dut.u_c23.qb;
assign dut_state[372+:1]=dut.u_c24.cka_d;
assign dut_state[373+:1]=dut.u_c24.ckb_d;
assign dut_state[374+:1]=dut.u_c24.d_pre_a;
assign dut_state[375+:1]=dut.u_c24.d_pre_b;
assign dut_state[376+:1]=dut.u_c24.qa;
assign dut_state[377+:1]=dut.u_c24.qb;
assign dut_state[378+:4]=dut.u_d04.a_lat;
assign dut_state[382+:1]=dut.u_d04.ce_lat;
assign dut_state[383+:4]=dut.u_d04.d_lat;
assign dut_state[387+:64]={dut.u_d04.mem[15],dut.u_d04.mem[14],dut.u_d04.mem[13],dut.u_d04.mem[12],dut.u_d04.mem[11],dut.u_d04.mem[10],dut.u_d04.mem[9],dut.u_d04.mem[8],dut.u_d04.mem[7],dut.u_d04.mem[6],dut.u_d04.mem[5],dut.u_d04.mem[4],dut.u_d04.mem[3],dut.u_d04.mem[2],dut.u_d04.mem[1],dut.u_d04.mem[0]};
assign dut_state[451+:1]=dut.u_d04.we_d;
assign dut_state[452+:1]=dut.u_d09.ck_d;
assign dut_state[453+:4]=dut.u_d09.d_pre;
assign dut_state[457+:4]=dut.u_d09.q;
assign dut_state[461+:1]=dut.u_d14.ck_d;
assign dut_state[462+:4]=dut.u_d14.q;
assign dut_state[466+:6]=dut.u_d14.setup_pre;
assign dut_state[472+:1]=dut.u_d17.ck_d;
assign dut_state[473+:6]=dut.u_d17.d_pre;
assign dut_state[479+:6]=dut.u_d17.q;
assign dut_state[485+:1]=dut.u_d23.cka_d;
assign dut_state[486+:1]=dut.u_d23.ckb_d;
assign dut_state[487+:1]=dut.u_d23.d_pre_a;
assign dut_state[488+:1]=dut.u_d23.d_pre_b;
assign dut_state[489+:1]=dut.u_d23.qa;
assign dut_state[490+:1]=dut.u_d23.qb;
assign dut_state[491+:1]=dut.u_d24.cka_d;
assign dut_state[492+:1]=dut.u_d24.ckb_d;
assign dut_state[493+:1]=dut.u_d24.d_pre_a;
assign dut_state[494+:1]=dut.u_d24.d_pre_b;
assign dut_state[495+:1]=dut.u_d24.qa;
assign dut_state[496+:1]=dut.u_d24.qb;
assign dut_state[497+:4]=dut.u_e04.a_lat;
assign dut_state[501+:1]=dut.u_e04.ce_lat;
assign dut_state[502+:4]=dut.u_e04.d_lat;
assign dut_state[506+:64]={dut.u_e04.mem[15],dut.u_e04.mem[14],dut.u_e04.mem[13],dut.u_e04.mem[12],dut.u_e04.mem[11],dut.u_e04.mem[10],dut.u_e04.mem[9],dut.u_e04.mem[8],dut.u_e04.mem[7],dut.u_e04.mem[6],dut.u_e04.mem[5],dut.u_e04.mem[4],dut.u_e04.mem[3],dut.u_e04.mem[2],dut.u_e04.mem[1],dut.u_e04.mem[0]};
assign dut_state[570+:1]=dut.u_e04.we_d;
assign dut_state[571+:1]=dut.u_e07.ck_d;
assign dut_state[572+:6]=dut.u_e07.d_pre;
assign dut_state[578+:6]=dut.u_e07.q;
assign dut_state[584+:1]=dut.u_e08.ck_d;
assign dut_state[585+:6]=dut.u_e08.d_pre;
assign dut_state[591+:6]=dut.u_e08.q;
assign dut_state[597+:1]=dut.u_e14.ck_d;
assign dut_state[598+:4]=dut.u_e14.q;
assign dut_state[602+:6]=dut.u_e14.setup_pre;
assign dut_state[608+:1]=dut.u_e23.cka_d;
assign dut_state[609+:1]=dut.u_e23.ckb_d;
assign dut_state[610+:1]=dut.u_e23.d_pre_a;
assign dut_state[611+:1]=dut.u_e23.d_pre_b;
assign dut_state[612+:1]=dut.u_e23.qa;
assign dut_state[613+:1]=dut.u_e23.qb;
assign dut_state[614+:1]=dut.u_e24.cka_d;
assign dut_state[615+:1]=dut.u_e24.ckb_d;
assign dut_state[616+:1]=dut.u_e24.d_pre_a;
assign dut_state[617+:1]=dut.u_e24.d_pre_b;
assign dut_state[618+:1]=dut.u_e24.qa;
assign dut_state[619+:1]=dut.u_e24.qb;
assign dut_state[620+:1]=dut.u_f02.ck_d;
assign dut_state[621+:6]=dut.u_f02.d_pre;
assign dut_state[627+:6]=dut.u_f02.q;
assign dut_state[633+:1]=dut.u_f04.ck_d;
assign dut_state[634+:4]=dut.u_f04.q;
assign dut_state[638+:6]=dut.u_f04.setup_pre;
assign dut_state[644+:1]=dut.u_f05.cka_d;
assign dut_state[645+:1]=dut.u_f05.ckb_d;
assign dut_state[646+:1]=dut.u_f05.d_pre_a;
assign dut_state[647+:1]=dut.u_f05.d_pre_b;
assign dut_state[648+:1]=dut.u_f05.qa;
assign dut_state[649+:1]=dut.u_f05.qb;
assign dut_state[650+:1]=dut.u_f06.cka_d;
assign dut_state[651+:1]=dut.u_f06.ckb_d;
assign dut_state[652+:1]=dut.u_f06.d_pre_a;
assign dut_state[653+:1]=dut.u_f06.d_pre_b;
assign dut_state[654+:1]=dut.u_f06.qa;
assign dut_state[655+:1]=dut.u_f06.qb;
assign dut_state[656+:1]=dut.u_f14.cka_d;
assign dut_state[657+:1]=dut.u_f14.ckb_d;
assign dut_state[658+:1]=dut.u_f14.d_pre_a;
assign dut_state[659+:1]=dut.u_f14.d_pre_b;
assign dut_state[660+:1]=dut.u_f14.qa;
assign dut_state[661+:1]=dut.u_f14.qb;
assign dut_state[662+:1]=dut.u_f15.cka_d;
assign dut_state[663+:1]=dut.u_f15.ckb_d;
assign dut_state[664+:1]=dut.u_f15.d_pre_a;
assign dut_state[665+:1]=dut.u_f15.d_pre_b;
assign dut_state[666+:1]=dut.u_f15.qa;
assign dut_state[667+:1]=dut.u_f15.qb;
assign dut_state[668+:1]=dut.u_g02.ck_d;
assign dut_state[669+:6]=dut.u_g02.d_pre;
assign dut_state[675+:6]=dut.u_g02.q;
assign dut_state[681+:1]=dut.u_g06.cka_d;
assign dut_state[682+:1]=dut.u_g06.ckb_d;
assign dut_state[683+:1]=dut.u_g06.d_pre_a;
assign dut_state[684+:1]=dut.u_g06.d_pre_b;
assign dut_state[685+:1]=dut.u_g06.qa;
assign dut_state[686+:1]=dut.u_g06.qb;
assign dut_state[687+:1]=dut.u_g07.cka_d;
assign dut_state[688+:1]=dut.u_g07.ckb_d;
assign dut_state[689+:1]=dut.u_g07.d_pre_a;
assign dut_state[690+:1]=dut.u_g07.d_pre_b;
assign dut_state[691+:1]=dut.u_g07.qa;
assign dut_state[692+:1]=dut.u_g07.qb;
assign dut_state[693+:1]=dut.u_g16.cka_d;
assign dut_state[694+:1]=dut.u_g16.ckb_d;
assign dut_state[695+:1]=dut.u_g16.d_pre_a;
assign dut_state[696+:1]=dut.u_g16.d_pre_b;
assign dut_state[697+:1]=dut.u_g16.qa;
assign dut_state[698+:1]=dut.u_g16.qb;
assign dut_state[699+:1]=dut.u_h02.ck_d;
assign dut_state[700+:6]=dut.u_h02.d_pre;
assign dut_state[706+:6]=dut.u_h02.q;
assign dut_state[712+:1]=dut.u_h05.ck_d;
assign dut_state[713+:6]=dut.u_h05.d_pre;
assign dut_state[719+:6]=dut.u_h05.q;
assign dut_state[725+:1]=dut.u_h08.ck_d;
assign dut_state[726+:4]=dut.u_h08.d_pre;
assign dut_state[730+:1]=dut.u_h08.dl_pre;
assign dut_state[731+:1]=dut.u_h08.dr_pre;
assign dut_state[732+:4]=dut.u_h08.q;
assign dut_state[736+:2]=dut.u_h08.s_pre;
assign dut_state[738+:1]=dut.u_h09.ck_d;
assign dut_state[739+:4]=dut.u_h09.d_pre;
assign dut_state[743+:1]=dut.u_h09.dl_pre;
assign dut_state[744+:1]=dut.u_h09.dr_pre;
assign dut_state[745+:4]=dut.u_h09.q;
assign dut_state[749+:2]=dut.u_h09.s_pre;
assign dut_state[751+:1]=dut.u_h12.ck_d;
assign dut_state[752+:6]=dut.u_h12.d_pre;
assign dut_state[758+:6]=dut.u_h12.q;
assign dut_state[764+:1]=dut.u_i02.ck_d;
assign dut_state[765+:6]=dut.u_i02.d_pre;
assign dut_state[771+:6]=dut.u_i02.q;
assign dut_state[777+:1]=dut.u_i03.ck_d;
assign dut_state[778+:6]=dut.u_i03.d_pre;
assign dut_state[784+:6]=dut.u_i03.q;
assign dut_state[790+:4]=dut.u_i13.a_lat;
assign dut_state[794+:1]=dut.u_i13.ce_lat;
assign dut_state[795+:4]=dut.u_i13.d_lat;
assign dut_state[799+:64]={dut.u_i13.mem[15],dut.u_i13.mem[14],dut.u_i13.mem[13],dut.u_i13.mem[12],dut.u_i13.mem[11],dut.u_i13.mem[10],dut.u_i13.mem[9],dut.u_i13.mem[8],dut.u_i13.mem[7],dut.u_i13.mem[6],dut.u_i13.mem[5],dut.u_i13.mem[4],dut.u_i13.mem[3],dut.u_i13.mem[2],dut.u_i13.mem[1],dut.u_i13.mem[0]};
assign dut_state[863+:1]=dut.u_i13.we_d;
assign dut_state[864+:4]=dut.u_i14.q;
assign dut_state[868+:1]=dut.u_i15.ck_d;
assign dut_state[869+:4]=dut.u_i15.q;
assign dut_state[873+:6]=dut.u_i15.setup_pre;
assign dut_state[879+:1]=dut.u_j01.cka_d;
assign dut_state[880+:1]=dut.u_j01.ckb_d;
assign dut_state[881+:1]=dut.u_j01.d_pre_a;
assign dut_state[882+:1]=dut.u_j01.d_pre_b;
assign dut_state[883+:1]=dut.u_j01.qa;
assign dut_state[884+:1]=dut.u_j01.qb;
assign dut_state[885+:1]=dut.u_j02.ck_d;
assign dut_state[886+:6]=dut.u_j02.d_pre;
assign dut_state[892+:6]=dut.u_j02.q;
assign dut_state[898+:1]=dut.u_j04.cka_d;
assign dut_state[899+:1]=dut.u_j04.ckb_d;
assign dut_state[900+:1]=dut.u_j04.d_pre_a;
assign dut_state[901+:1]=dut.u_j04.d_pre_b;
assign dut_state[902+:1]=dut.u_j04.qa;
assign dut_state[903+:1]=dut.u_j04.qb;
assign dut_state[904+:1]=dut.u_j08.cka_d;
assign dut_state[905+:1]=dut.u_j08.ckb_d;
assign dut_state[906+:1]=dut.u_j08.d_pre_a;
assign dut_state[907+:1]=dut.u_j08.d_pre_b;
assign dut_state[908+:1]=dut.u_j08.qa;
assign dut_state[909+:1]=dut.u_j08.qb;
assign dut_state[910+:1]=dut.u_j09.cka_d;
assign dut_state[911+:1]=dut.u_j09.ckb_d;
assign dut_state[912+:1]=dut.u_j09.d_pre_a;
assign dut_state[913+:1]=dut.u_j09.d_pre_b;
assign dut_state[914+:1]=dut.u_j09.qa;
assign dut_state[915+:1]=dut.u_j09.qb;
assign dut_state[916+:4]=dut.u_j13.a_lat;
assign dut_state[920+:1]=dut.u_j13.ce_lat;
assign dut_state[921+:4]=dut.u_j13.d_lat;
assign dut_state[925+:64]={dut.u_j13.mem[15],dut.u_j13.mem[14],dut.u_j13.mem[13],dut.u_j13.mem[12],dut.u_j13.mem[11],dut.u_j13.mem[10],dut.u_j13.mem[9],dut.u_j13.mem[8],dut.u_j13.mem[7],dut.u_j13.mem[6],dut.u_j13.mem[5],dut.u_j13.mem[4],dut.u_j13.mem[3],dut.u_j13.mem[2],dut.u_j13.mem[1],dut.u_j13.mem[0]};
assign dut_state[989+:1]=dut.u_j13.we_d;
assign dut_state[990+:4]=dut.u_j14.q;
assign dut_state[994+:1]=dut.u_j15.ck_d;
assign dut_state[995+:4]=dut.u_j15.q;
assign dut_state[999+:6]=dut.u_j15.setup_pre;
assign dut_state[1005+:1]=dut.u_j16.ck_d;
assign dut_state[1006+:6]=dut.u_j16.d_pre;
assign dut_state[1012+:6]=dut.u_j16.q;
assign dut_state[1018+:1]=dut.u_k01.cka_d;
assign dut_state[1019+:1]=dut.u_k01.ckb_d;
assign dut_state[1020+:1]=dut.u_k01.d_pre_a;
assign dut_state[1021+:1]=dut.u_k01.d_pre_b;
assign dut_state[1022+:1]=dut.u_k01.qa;
assign dut_state[1023+:1]=dut.u_k01.qb;
assign dut_state[1024+:1]=dut.u_k02.cka_d;
assign dut_state[1025+:1]=dut.u_k02.ckb_d;
assign dut_state[1026+:1]=dut.u_k02.d_pre_a;
assign dut_state[1027+:1]=dut.u_k02.d_pre_b;
assign dut_state[1028+:1]=dut.u_k02.qa;
assign dut_state[1029+:1]=dut.u_k02.qb;
assign dut_state[1030+:1]=dut.u_k03.cka_d;
assign dut_state[1031+:1]=dut.u_k03.ckb_d;
assign dut_state[1032+:1]=dut.u_k03.d_pre_a;
assign dut_state[1033+:1]=dut.u_k03.d_pre_b;
assign dut_state[1034+:1]=dut.u_k03.qa;
assign dut_state[1035+:1]=dut.u_k03.qb;
assign dut_state[1036+:1]=dut.u_k04.cka_d;
assign dut_state[1037+:1]=dut.u_k04.ckb_d;
assign dut_state[1038+:1]=dut.u_k04.d_pre_a;
assign dut_state[1039+:1]=dut.u_k04.d_pre_b;
assign dut_state[1040+:1]=dut.u_k04.qa;
assign dut_state[1041+:1]=dut.u_k04.qb;
assign dut_state[1042+:1]=dut.u_k05.cka_d;
assign dut_state[1043+:1]=dut.u_k05.ckb_d;
assign dut_state[1044+:1]=dut.u_k05.d_pre_a;
assign dut_state[1045+:1]=dut.u_k05.d_pre_b;
assign dut_state[1046+:1]=dut.u_k05.qa;
assign dut_state[1047+:1]=dut.u_k05.qb;
assign dut_state[1048+:1]=dut.u_k10.ck_d;
assign dut_state[1049+:6]=dut.u_k10.d_pre;
assign dut_state[1055+:6]=dut.u_k10.q;
assign dut_state[1061+:1]=dut.u_k12.ck_d;
assign dut_state[1062+:6]=dut.u_k12.d_pre;
assign dut_state[1068+:6]=dut.u_k12.q;
assign dut_state[1074+:4]=dut.u_k13.a_lat;
assign dut_state[1078+:1]=dut.u_k13.ce_lat;
assign dut_state[1079+:4]=dut.u_k13.d_lat;
assign dut_state[1083+:64]={dut.u_k13.mem[15],dut.u_k13.mem[14],dut.u_k13.mem[13],dut.u_k13.mem[12],dut.u_k13.mem[11],dut.u_k13.mem[10],dut.u_k13.mem[9],dut.u_k13.mem[8],dut.u_k13.mem[7],dut.u_k13.mem[6],dut.u_k13.mem[5],dut.u_k13.mem[4],dut.u_k13.mem[3],dut.u_k13.mem[2],dut.u_k13.mem[1],dut.u_k13.mem[0]};
assign dut_state[1147+:1]=dut.u_k13.we_d;
assign dut_state[1148+:4]=dut.u_k14.q;
assign dut_state[1152+:1]=dut.u_k15.ck_d;
assign dut_state[1153+:4]=dut.u_k15.q;
assign dut_state[1157+:6]=dut.u_k15.setup_pre;
assign dut_state[1163+:1]=dut.u_k16.ck_d;
assign dut_state[1164+:6]=dut.u_k16.d_pre;
assign dut_state[1170+:6]=dut.u_k16.q;
assign dut_state[1176+:1]=dut.u_l02.cka_d;
assign dut_state[1177+:1]=dut.u_l02.ckb_d;
assign dut_state[1178+:1]=dut.u_l02.d_pre_a;
assign dut_state[1179+:1]=dut.u_l02.d_pre_b;
assign dut_state[1180+:1]=dut.u_l02.qa;
assign dut_state[1181+:1]=dut.u_l02.qb;
assign dut_state[1182+:1]=dut.u_l03.cka_d;
assign dut_state[1183+:1]=dut.u_l03.ckb_d;
assign dut_state[1184+:1]=dut.u_l03.d_pre_a;
assign dut_state[1185+:1]=dut.u_l03.d_pre_b;
assign dut_state[1186+:1]=dut.u_l03.qa;
assign dut_state[1187+:1]=dut.u_l03.qb;
assign dut_state[1188+:1]=dut.u_l04.cka_d;
assign dut_state[1189+:1]=dut.u_l04.ckb_d;
assign dut_state[1190+:1]=dut.u_l04.d_pre_a;
assign dut_state[1191+:1]=dut.u_l04.d_pre_b;
assign dut_state[1192+:1]=dut.u_l04.qa;
assign dut_state[1193+:1]=dut.u_l04.qb;
assign dut_state[1194+:1]=dut.u_l05.cka_d;
assign dut_state[1195+:1]=dut.u_l05.ckb_d;
assign dut_state[1196+:1]=dut.u_l05.d_pre_a;
assign dut_state[1197+:1]=dut.u_l05.d_pre_b;
assign dut_state[1198+:1]=dut.u_l05.qa;
assign dut_state[1199+:1]=dut.u_l05.qb;
assign dut_state[1200+:1]=dut.u_l06.cka_d;
assign dut_state[1201+:1]=dut.u_l06.ckb_d;
assign dut_state[1202+:1]=dut.u_l06.d_pre_a;
assign dut_state[1203+:1]=dut.u_l06.d_pre_b;
assign dut_state[1204+:1]=dut.u_l06.qa;
assign dut_state[1205+:1]=dut.u_l06.qb;
assign dut_state[1206+:1]=dut.u_l07.cka_d;
assign dut_state[1207+:1]=dut.u_l07.ckb_d;
assign dut_state[1208+:1]=dut.u_l07.d_pre_a;
assign dut_state[1209+:1]=dut.u_l07.d_pre_b;
assign dut_state[1210+:1]=dut.u_l07.qa;
assign dut_state[1211+:1]=dut.u_l07.qb;
assign dut_state[1212+:1]=dut.u_l11.ck_d;
assign dut_state[1213+:6]=dut.u_l11.d_pre;
assign dut_state[1219+:6]=dut.u_l11.q;
assign dut_state[1225+:1]=dut.u_l12.ck_d;
assign dut_state[1226+:6]=dut.u_l12.d_pre;
assign dut_state[1232+:6]=dut.u_l12.q;
assign dut_state[1238+:4]=dut.u_l13.a_lat;
assign dut_state[1242+:1]=dut.u_l13.ce_lat;
assign dut_state[1243+:4]=dut.u_l13.d_lat;
assign dut_state[1247+:64]={dut.u_l13.mem[15],dut.u_l13.mem[14],dut.u_l13.mem[13],dut.u_l13.mem[12],dut.u_l13.mem[11],dut.u_l13.mem[10],dut.u_l13.mem[9],dut.u_l13.mem[8],dut.u_l13.mem[7],dut.u_l13.mem[6],dut.u_l13.mem[5],dut.u_l13.mem[4],dut.u_l13.mem[3],dut.u_l13.mem[2],dut.u_l13.mem[1],dut.u_l13.mem[0]};
assign dut_state[1311+:1]=dut.u_l13.we_d;
assign dut_state[1312+:4]=dut.u_l14.q;
assign dut_state[1316+:1]=dut.u_l15.ck_d;
assign dut_state[1317+:4]=dut.u_l15.q;
assign dut_state[1321+:6]=dut.u_l15.setup_pre;
assign dut_state[1327+:1]=dut.u_l16.ck_d;
assign dut_state[1328+:6]=dut.u_l16.d_pre;
assign dut_state[1334+:6]=dut.u_l16.q;
assign dut_state[1340+:1]=dut.u_l17.ck_d;
assign dut_state[1341+:6]=dut.u_l17.d_pre;
assign dut_state[1347+:6]=dut.u_l17.q;
assign dut_probe=1'b0;
assign all_helpers_frozen=&{dut.state_frozen,dut.u_a04.state_frozen,dut.u_b04.state_frozen,dut.u_c04.state_frozen,dut.u_d04.state_frozen,dut.u_e04.state_frozen,dut.u_i13.state_frozen,dut.u_j13.state_frozen,dut.u_k13.state_frozen,dut.u_l13.state_frozen};
endmodule
