module snapshot_fit(input wire host_clk,advance,freeze,held,request,write,system_reset,
 input wire [63:0] pins,input wire [16:0] index,input wire [17:0] data,
 output reg [99:0] outputs,output reg [17:0] result,output reg frozen,done,error,scan_hold_required,scan_fault);
 reg [104:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={system_reset,advance,freeze,held,request,write,pins,index,data};
 always @(posedge host_clk)launch<=input_stage;
 wire system_reset_r,advance_r,freeze_r,held_r,request_r,write_r;wire [63:0] pins_r;wire [16:0] index_r;wire [17:0] data_r;
 assign {system_reset_r,advance_r,freeze_r,held_r,request_r,write_r,pins_r,index_r,data_r}=launch;
 wire [99:0] outputs_w;wire [17:0] result_w;wire frozen_w,done_w,error_w,scan_hold_w,scan_fault_w;
 always @(posedge host_clk){outputs,result,frozen,done,error,scan_hold_required,scan_fault}<={outputs_w,result_w,frozen_w,done_w,error_w,scan_hold_w,scan_fault_w};
wire [31:0] baseboard_debug;
wire ACPI_0__drv;
wire ACPI_1__drv;
wire ACPI_2__drv;
wire ACPI_3__drv;
wire ACPI_4__drv;
wire ACPIGnd_0__drv;
wire ACPIGnd_1__drv;
wire ACPIGnd_2__drv;
wire ACPIGnd_3__drv;
wire ACPIGnd_4__drv;
wire BootMC_p___drv;
wire BootNO__drv;
wire CLK_OutBase_p___drv;
wire CLK_ca_p___drv;
wire CLK_cb_p___drv;
wire CLK_disk_p___drv;
wire CLK_display_p___drv;
wire CLK_ifu_p___drv;
wire CLK_io20_p___drv;
wire CLK_io21_p___drv;
wire CLK_io22_p___drv;
wire CLK_io23_p___drv;
wire CLK_io24_p___drv;
wire CLK_mc_p___drv;
wire CLK_md_p___drv;
wire CLK_ms0Even_p___drv;
wire CLK_ms0Odd_p___drv;
wire CLK_ms1Even_p___drv;
wire CLK_ms1Odd_p___drv;
wire CLK_ms2Even_p___drv;
wire CLK_ms2Odd_p___drv;
wire CLK_ms3Even_p___drv;
wire CLK_ms3Odd_p___drv;
wire CLK_mx_p___drv;
wire CLK_ph_p___drv;
wire CLK_pl_p___drv;
wire CPAddr_0_p___drv;
wire CPAddr_1_p___drv;
wire CPAddr_2_p___drv;
wire CPOut_0__drv;
wire CPOut_1__drv;
wire CPOut_2__drv;
wire CPOut_3__drv;
wire CPOut_4__drv;
wire CPOut_5__drv;
wire CPOut_6__drv;
wire CPOut_7__drv;
wire CPOut_8__drv;
wire CPStrb_p___drv;
wire DMuxClk__drv;
wire DMuxData__drv;
wire IOReset__drv;
wire KeyboardData__drv;
wire Pendulum__drv;
wire RfshPeriod__drv;
wire Sequence0_p___drv;
wire SetRun__drv;
wire SetRunRfsh__drv;
wire SetSS_p___drv;
wire SkipWait_p___drv;
wire StartClockPulse__drv;
wire TTLIOReset_p___drv;
wire TempRef__drv;
wire TurnOff2v__drv;
wire TurnOnDisk_p___drv;
wire TurnOnLED_p___drv;
wire TurnOnPwr_p___drv;
wire UseDMD__drv;
assign outputs_w={UseDMD__drv,TurnOnPwr_p___drv,TurnOnLED_p___drv,TurnOnDisk_p___drv,TurnOff2v__drv,TempRef__drv,TTLIOReset_p___drv,StartClockPulse__drv,SkipWait_p___drv,SetSS_p___drv,SetRunRfsh__drv,SetRun__drv,Sequence0_p___drv,RfshPeriod__drv,Pendulum__drv,KeyboardData__drv,IOReset__drv,DMuxData__drv,DMuxClk__drv,CPStrb_p___drv,CPOut_8__drv,CPOut_7__drv,CPOut_6__drv,CPOut_5__drv,CPOut_4__drv,CPOut_3__drv,CPOut_2__drv,CPOut_1__drv,CPOut_0__drv,CPAddr_2_p___drv,CPAddr_1_p___drv,CPAddr_0_p___drv,CLK_pl_p___drv,CLK_ph_p___drv,CLK_mx_p___drv,CLK_ms3Odd_p___drv,CLK_ms3Even_p___drv,CLK_ms2Odd_p___drv,CLK_ms2Even_p___drv,CLK_ms1Odd_p___drv,CLK_ms1Even_p___drv,CLK_ms0Odd_p___drv,CLK_ms0Even_p___drv,CLK_md_p___drv,CLK_mc_p___drv,CLK_io24_p___drv,CLK_io23_p___drv,CLK_io22_p___drv,CLK_io21_p___drv,CLK_io20_p___drv,CLK_ifu_p___drv,CLK_display_p___drv,CLK_disk_p___drv,CLK_cb_p___drv,CLK_ca_p___drv,CLK_OutBase_p___drv,BootNO__drv,BootMC_p___drv,ACPIGnd_4__drv,ACPIGnd_3__drv,ACPIGnd_2__drv,ACPIGnd_1__drv,ACPIGnd_0__drv,ACPI_4__drv,ACPI_3__drv,ACPI_2__drv,ACPI_1__drv,ACPI_0__drv,baseboard_debug};
`ifdef SNAPSHOT_BANK_EXPERIMENT
BaseBd_full_snapshot_experiment #(.SYSPER(4)) board(
 .state_system_reset(system_reset_r),.state_scan_hold_required(scan_hold_w),.state_scan_fault(scan_fault_w),
 .state_host_clk(host_clk),.state_guest_advance(advance_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w),.state_done(done_w),.state_error(error_w),.state_result(result_w),
.sys_clk(host_clk),.baseboard_boot_n(pins_r[0]),.ACPABus_0_p_(pins_r[1]),.ACPABus_1_p_(pins_r[2]),.ACPABus_2_p_(pins_r[3]),.ACPBus_0_p_(pins_r[4]),.ACPBus_1_p_(pins_r[5]),.ACPBus_2_p_(pins_r[6]),.ACPBus_3_p_(pins_r[7]),.ACPBus_4_p_(pins_r[8]),.ACPBus_5_p_(pins_r[9]),.ACPBus_6_p_(pins_r[10]),.ACPBus_7_p_(pins_r[11]),.ACPBus_8_p_(pins_r[12]),.ACPGnd_00(pins_r[13]),.ACPGnd_01(pins_r[14]),.ACPGnd_02(pins_r[15]),.ACPGnd_03(pins_r[16]),.ACPGnd_04(pins_r[17]),.ACPGnd_05(pins_r[18]),.ACPGnd_06(pins_r[19]),.ACPGnd_07(pins_r[20]),.ACPGnd_08(pins_r[21]),.ACPGnd_09(pins_r[22]),.ACPGnd_10(pins_r[23]),.ACPGnd_11(pins_r[24]),.ACPGnd_12(pins_r[25]),.ACPStrb_p_(pins_r[26]),.BootMC_p_(pins_r[27] | BootMC_p___drv),.CBTempSense(pins_r[28]),.CICC__m_SS(pins_r[29]),.CICC_EOS(pins_r[30]),.CIDD__m_SS(pins_r[31]),.CIDD_EOS(pins_r[32]),.CIEE__m_SS(pins_r[33]),.CIEE_EOS(pins_r[34]),.CITT__pl_SS(pins_r[35]),.CITT_EOS(pins_r[36]),.CLK_InBase(pins_r[37]),.CPIn_0(pins_r[38]),.CPIn_1(pins_r[39]),.CPIn_2(pins_r[40]),.CPIn_3(pins_r[41]),.Collision(pins_r[42]),.DMuxClk(pins_r[43] | DMuxClk__drv),.DMuxData(pins_r[44] | DMuxData__drv),.DiskOnRet(pins_r[45]),.LEDOnRet(pins_r[46]),.OISData(pins_r[47]),.OISData_p_(pins_r[48]),.PwrOnRet(pins_r[49]),.RcvData(pins_r[50]),.Sequence0_p_(pins_r[51] | Sequence0_p___drv),.Serial_1(pins_r[52]),.Serial_10(pins_r[53]),.Serial_100(pins_r[54]),.Serial_2(pins_r[55]),.Serial_20(pins_r[56]),.Serial_200(pins_r[57]),.Serial_4(pins_r[58]),.Serial_40(pins_r[59]),.TTLIOReset_p_(pins_r[60] | TTLIOReset_p___drv),.UseDMD(pins_r[61] | UseDMD__drv),.XmtData_p_(pins_r[62]),.dStartClockPulse(pins_r[63]),.baseboard_debug(baseboard_debug),.ACPI_0__drv(ACPI_0__drv),.ACPI_1__drv(ACPI_1__drv),.ACPI_2__drv(ACPI_2__drv),.ACPI_3__drv(ACPI_3__drv),.ACPI_4__drv(ACPI_4__drv),.ACPIGnd_0__drv(ACPIGnd_0__drv),.ACPIGnd_1__drv(ACPIGnd_1__drv),.ACPIGnd_2__drv(ACPIGnd_2__drv),.ACPIGnd_3__drv(ACPIGnd_3__drv),.ACPIGnd_4__drv(ACPIGnd_4__drv),.BootMC_p___drv(BootMC_p___drv),.BootNO__drv(BootNO__drv),.CLK_OutBase_p___drv(CLK_OutBase_p___drv),.CLK_ca_p___drv(CLK_ca_p___drv),.CLK_cb_p___drv(CLK_cb_p___drv),.CLK_disk_p___drv(CLK_disk_p___drv),.CLK_display_p___drv(CLK_display_p___drv),.CLK_ifu_p___drv(CLK_ifu_p___drv),.CLK_io20_p___drv(CLK_io20_p___drv),.CLK_io21_p___drv(CLK_io21_p___drv),.CLK_io22_p___drv(CLK_io22_p___drv),.CLK_io23_p___drv(CLK_io23_p___drv),.CLK_io24_p___drv(CLK_io24_p___drv),.CLK_mc_p___drv(CLK_mc_p___drv),.CLK_md_p___drv(CLK_md_p___drv),.CLK_ms0Even_p___drv(CLK_ms0Even_p___drv),.CLK_ms0Odd_p___drv(CLK_ms0Odd_p___drv),.CLK_ms1Even_p___drv(CLK_ms1Even_p___drv),.CLK_ms1Odd_p___drv(CLK_ms1Odd_p___drv),.CLK_ms2Even_p___drv(CLK_ms2Even_p___drv),.CLK_ms2Odd_p___drv(CLK_ms2Odd_p___drv),.CLK_ms3Even_p___drv(CLK_ms3Even_p___drv),.CLK_ms3Odd_p___drv(CLK_ms3Odd_p___drv),.CLK_mx_p___drv(CLK_mx_p___drv),.CLK_ph_p___drv(CLK_ph_p___drv),.CLK_pl_p___drv(CLK_pl_p___drv),.CPAddr_0_p___drv(CPAddr_0_p___drv),.CPAddr_1_p___drv(CPAddr_1_p___drv),.CPAddr_2_p___drv(CPAddr_2_p___drv),.CPOut_0__drv(CPOut_0__drv),.CPOut_1__drv(CPOut_1__drv),.CPOut_2__drv(CPOut_2__drv),.CPOut_3__drv(CPOut_3__drv),.CPOut_4__drv(CPOut_4__drv),.CPOut_5__drv(CPOut_5__drv),.CPOut_6__drv(CPOut_6__drv),.CPOut_7__drv(CPOut_7__drv),.CPOut_8__drv(CPOut_8__drv),.CPStrb_p___drv(CPStrb_p___drv),.DMuxClk__drv(DMuxClk__drv),.DMuxData__drv(DMuxData__drv),.IOReset__drv(IOReset__drv),.KeyboardData__drv(KeyboardData__drv),.Pendulum__drv(Pendulum__drv),.RfshPeriod__drv(RfshPeriod__drv),.Sequence0_p___drv(Sequence0_p___drv),.SetRun__drv(SetRun__drv),.SetRunRfsh__drv(SetRunRfsh__drv),.SetSS_p___drv(SetSS_p___drv),.SkipWait_p___drv(SkipWait_p___drv),.StartClockPulse__drv(StartClockPulse__drv),.TTLIOReset_p___drv(TTLIOReset_p___drv),.TempRef__drv(TempRef__drv),.TurnOff2v__drv(TurnOff2v__drv),.TurnOnDisk_p___drv(TurnOnDisk_p___drv),.TurnOnLED_p___drv(TurnOnLED_p___drv),.TurnOnPwr_p___drv(TurnOnPwr_p___drv),.UseDMD__drv(UseDMD__drv));
`else
 assign {frozen_w,done_w,error_w,result_w}=21'b0;
BaseBd_m_Rev_m_Am_nominal #(.SYSPER(4)) board(.sys_clk(host_clk),.baseboard_boot_n(pins_r[0]),.ACPABus_0_p_(pins_r[1]),.ACPABus_1_p_(pins_r[2]),.ACPABus_2_p_(pins_r[3]),.ACPBus_0_p_(pins_r[4]),.ACPBus_1_p_(pins_r[5]),.ACPBus_2_p_(pins_r[6]),.ACPBus_3_p_(pins_r[7]),.ACPBus_4_p_(pins_r[8]),.ACPBus_5_p_(pins_r[9]),.ACPBus_6_p_(pins_r[10]),.ACPBus_7_p_(pins_r[11]),.ACPBus_8_p_(pins_r[12]),.ACPGnd_00(pins_r[13]),.ACPGnd_01(pins_r[14]),.ACPGnd_02(pins_r[15]),.ACPGnd_03(pins_r[16]),.ACPGnd_04(pins_r[17]),.ACPGnd_05(pins_r[18]),.ACPGnd_06(pins_r[19]),.ACPGnd_07(pins_r[20]),.ACPGnd_08(pins_r[21]),.ACPGnd_09(pins_r[22]),.ACPGnd_10(pins_r[23]),.ACPGnd_11(pins_r[24]),.ACPGnd_12(pins_r[25]),.ACPStrb_p_(pins_r[26]),.BootMC_p_(pins_r[27] | BootMC_p___drv),.CBTempSense(pins_r[28]),.CICC__m_SS(pins_r[29]),.CICC_EOS(pins_r[30]),.CIDD__m_SS(pins_r[31]),.CIDD_EOS(pins_r[32]),.CIEE__m_SS(pins_r[33]),.CIEE_EOS(pins_r[34]),.CITT__pl_SS(pins_r[35]),.CITT_EOS(pins_r[36]),.CLK_InBase(pins_r[37]),.CPIn_0(pins_r[38]),.CPIn_1(pins_r[39]),.CPIn_2(pins_r[40]),.CPIn_3(pins_r[41]),.Collision(pins_r[42]),.DMuxClk(pins_r[43] | DMuxClk__drv),.DMuxData(pins_r[44] | DMuxData__drv),.DiskOnRet(pins_r[45]),.LEDOnRet(pins_r[46]),.OISData(pins_r[47]),.OISData_p_(pins_r[48]),.PwrOnRet(pins_r[49]),.RcvData(pins_r[50]),.Sequence0_p_(pins_r[51] | Sequence0_p___drv),.Serial_1(pins_r[52]),.Serial_10(pins_r[53]),.Serial_100(pins_r[54]),.Serial_2(pins_r[55]),.Serial_20(pins_r[56]),.Serial_200(pins_r[57]),.Serial_4(pins_r[58]),.Serial_40(pins_r[59]),.TTLIOReset_p_(pins_r[60] | TTLIOReset_p___drv),.UseDMD(pins_r[61] | UseDMD__drv),.XmtData_p_(pins_r[62]),.dStartClockPulse(pins_r[63]),.baseboard_debug(baseboard_debug),.ACPI_0__drv(ACPI_0__drv),.ACPI_1__drv(ACPI_1__drv),.ACPI_2__drv(ACPI_2__drv),.ACPI_3__drv(ACPI_3__drv),.ACPI_4__drv(ACPI_4__drv),.ACPIGnd_0__drv(ACPIGnd_0__drv),.ACPIGnd_1__drv(ACPIGnd_1__drv),.ACPIGnd_2__drv(ACPIGnd_2__drv),.ACPIGnd_3__drv(ACPIGnd_3__drv),.ACPIGnd_4__drv(ACPIGnd_4__drv),.BootMC_p___drv(BootMC_p___drv),.BootNO__drv(BootNO__drv),.CLK_OutBase_p___drv(CLK_OutBase_p___drv),.CLK_ca_p___drv(CLK_ca_p___drv),.CLK_cb_p___drv(CLK_cb_p___drv),.CLK_disk_p___drv(CLK_disk_p___drv),.CLK_display_p___drv(CLK_display_p___drv),.CLK_ifu_p___drv(CLK_ifu_p___drv),.CLK_io20_p___drv(CLK_io20_p___drv),.CLK_io21_p___drv(CLK_io21_p___drv),.CLK_io22_p___drv(CLK_io22_p___drv),.CLK_io23_p___drv(CLK_io23_p___drv),.CLK_io24_p___drv(CLK_io24_p___drv),.CLK_mc_p___drv(CLK_mc_p___drv),.CLK_md_p___drv(CLK_md_p___drv),.CLK_ms0Even_p___drv(CLK_ms0Even_p___drv),.CLK_ms0Odd_p___drv(CLK_ms0Odd_p___drv),.CLK_ms1Even_p___drv(CLK_ms1Even_p___drv),.CLK_ms1Odd_p___drv(CLK_ms1Odd_p___drv),.CLK_ms2Even_p___drv(CLK_ms2Even_p___drv),.CLK_ms2Odd_p___drv(CLK_ms2Odd_p___drv),.CLK_ms3Even_p___drv(CLK_ms3Even_p___drv),.CLK_ms3Odd_p___drv(CLK_ms3Odd_p___drv),.CLK_mx_p___drv(CLK_mx_p___drv),.CLK_ph_p___drv(CLK_ph_p___drv),.CLK_pl_p___drv(CLK_pl_p___drv),.CPAddr_0_p___drv(CPAddr_0_p___drv),.CPAddr_1_p___drv(CPAddr_1_p___drv),.CPAddr_2_p___drv(CPAddr_2_p___drv),.CPOut_0__drv(CPOut_0__drv),.CPOut_1__drv(CPOut_1__drv),.CPOut_2__drv(CPOut_2__drv),.CPOut_3__drv(CPOut_3__drv),.CPOut_4__drv(CPOut_4__drv),.CPOut_5__drv(CPOut_5__drv),.CPOut_6__drv(CPOut_6__drv),.CPOut_7__drv(CPOut_7__drv),.CPOut_8__drv(CPOut_8__drv),.CPStrb_p___drv(CPStrb_p___drv),.DMuxClk__drv(DMuxClk__drv),.DMuxData__drv(DMuxData__drv),.IOReset__drv(IOReset__drv),.KeyboardData__drv(KeyboardData__drv),.Pendulum__drv(Pendulum__drv),.RfshPeriod__drv(RfshPeriod__drv),.Sequence0_p___drv(Sequence0_p___drv),.SetRun__drv(SetRun__drv),.SetRunRfsh__drv(SetRunRfsh__drv),.SetSS_p___drv(SetSS_p___drv),.SkipWait_p___drv(SkipWait_p___drv),.StartClockPulse__drv(StartClockPulse__drv),.TTLIOReset_p___drv(TTLIOReset_p___drv),.TempRef__drv(TempRef__drv),.TurnOff2v__drv(TurnOff2v__drv),.TurnOnDisk_p___drv(TurnOnDisk_p___drv),.TurnOnLED_p___drv(TurnOnLED_p___drv),.TurnOnPwr_p___drv(TurnOnPwr_p___drv),.UseDMD__drv(UseDMD__drv));
`endif
endmodule
