module global_fixture(
 input wire clk,advance,freeze,held,system_reset,global_hold,global_abort,request,write,
 input wire [63:0] stimulus,input wire [23:0] index,input wire [17:0] data,
 input wire [15:0] probe_index,
 output wire [99:0] reference_outputs,dut_outputs,
 output wire [7597:0] reference_state,dut_state,
 output wire [31:0] reference_probe,dut_probe,
 output wire all_helpers_frozen,
 output wire reference_frozen,reference_done,reference_error,reference_hold,reference_fault,
 output wire dut_frozen,dut_done,dut_error,dut_hold,dut_fault,
 output wire [17:0] reference_result,dut_result);
wire [31:0] reference_baseboard_debug;
wire reference_ACPI_0__drv;
wire reference_ACPI_1__drv;
wire reference_ACPI_2__drv;
wire reference_ACPI_3__drv;
wire reference_ACPI_4__drv;
wire reference_ACPIGnd_0__drv;
wire reference_ACPIGnd_1__drv;
wire reference_ACPIGnd_2__drv;
wire reference_ACPIGnd_3__drv;
wire reference_ACPIGnd_4__drv;
wire reference_BootMC_p___drv;
wire reference_BootNO__drv;
wire reference_CLK_OutBase_p___drv;
wire reference_CLK_ca_p___drv;
wire reference_CLK_cb_p___drv;
wire reference_CLK_disk_p___drv;
wire reference_CLK_display_p___drv;
wire reference_CLK_ifu_p___drv;
wire reference_CLK_io20_p___drv;
wire reference_CLK_io21_p___drv;
wire reference_CLK_io22_p___drv;
wire reference_CLK_io23_p___drv;
wire reference_CLK_io24_p___drv;
wire reference_CLK_mc_p___drv;
wire reference_CLK_md_p___drv;
wire reference_CLK_ms0Even_p___drv;
wire reference_CLK_ms0Odd_p___drv;
wire reference_CLK_ms1Even_p___drv;
wire reference_CLK_ms1Odd_p___drv;
wire reference_CLK_ms2Even_p___drv;
wire reference_CLK_ms2Odd_p___drv;
wire reference_CLK_ms3Even_p___drv;
wire reference_CLK_ms3Odd_p___drv;
wire reference_CLK_mx_p___drv;
wire reference_CLK_ph_p___drv;
wire reference_CLK_pl_p___drv;
wire reference_CPAddr_0_p___drv;
wire reference_CPAddr_1_p___drv;
wire reference_CPAddr_2_p___drv;
wire reference_CPOut_0__drv;
wire reference_CPOut_1__drv;
wire reference_CPOut_2__drv;
wire reference_CPOut_3__drv;
wire reference_CPOut_4__drv;
wire reference_CPOut_5__drv;
wire reference_CPOut_6__drv;
wire reference_CPOut_7__drv;
wire reference_CPOut_8__drv;
wire reference_CPStrb_p___drv;
wire reference_DMuxClk__drv;
wire reference_DMuxData__drv;
wire reference_IOReset__drv;
wire reference_KeyboardData__drv;
wire reference_Pendulum__drv;
wire reference_RfshPeriod__drv;
wire reference_Sequence0_p___drv;
wire reference_SetRun__drv;
wire reference_SetRunRfsh__drv;
wire reference_SetSS_p___drv;
wire reference_SkipWait_p___drv;
wire reference_StartClockPulse__drv;
wire reference_TTLIOReset_p___drv;
wire reference_TempRef__drv;
wire reference_TurnOff2v__drv;
wire reference_TurnOnDisk_p___drv;
wire reference_TurnOnLED_p___drv;
wire reference_TurnOnPwr_p___drv;
wire reference_UseDMD__drv;
BaseBd_full_snapshot_experiment #(.SYSPER(4)) reference(
.sys_clk(clk),
.baseboard_boot_n(stimulus[0]),
.ACPABus_0_p_(stimulus[1]),
.ACPABus_1_p_(stimulus[2]),
.ACPABus_2_p_(stimulus[3]),
.ACPBus_0_p_(stimulus[4]),
.ACPBus_1_p_(stimulus[5]),
.ACPBus_2_p_(stimulus[6]),
.ACPBus_3_p_(stimulus[7]),
.ACPBus_4_p_(stimulus[8]),
.ACPBus_5_p_(stimulus[9]),
.ACPBus_6_p_(stimulus[10]),
.ACPBus_7_p_(stimulus[11]),
.ACPBus_8_p_(stimulus[12]),
.ACPGnd_00(stimulus[13]),
.ACPGnd_01(stimulus[14]),
.ACPGnd_02(stimulus[15]),
.ACPGnd_03(stimulus[16]),
.ACPGnd_04(stimulus[17]),
.ACPGnd_05(stimulus[18]),
.ACPGnd_06(stimulus[19]),
.ACPGnd_07(stimulus[20]),
.ACPGnd_08(stimulus[21]),
.ACPGnd_09(stimulus[22]),
.ACPGnd_10(stimulus[23]),
.ACPGnd_11(stimulus[24]),
.ACPGnd_12(stimulus[25]),
.ACPStrb_p_(stimulus[26]),
.BootMC_p_(stimulus[27] | reference_BootMC_p___drv),
.CBTempSense(stimulus[28]),
.CICC__m_SS(stimulus[29]),
.CICC_EOS(stimulus[30]),
.CIDD__m_SS(stimulus[31]),
.CIDD_EOS(stimulus[32]),
.CIEE__m_SS(stimulus[33]),
.CIEE_EOS(stimulus[34]),
.CITT__pl_SS(stimulus[35]),
.CITT_EOS(stimulus[36]),
.CLK_InBase(stimulus[37]),
.CPIn_0(stimulus[38]),
.CPIn_1(stimulus[39]),
.CPIn_2(stimulus[40]),
.CPIn_3(stimulus[41]),
.Collision(stimulus[42]),
.DMuxClk(stimulus[43] | reference_DMuxClk__drv),
.DMuxData(stimulus[44] | reference_DMuxData__drv),
.DiskOnRet(stimulus[45]),
.LEDOnRet(stimulus[46]),
.OISData(stimulus[47]),
.OISData_p_(stimulus[48]),
.PwrOnRet(stimulus[49]),
.RcvData(stimulus[50]),
.Sequence0_p_(stimulus[51] | reference_Sequence0_p___drv),
.Serial_1(stimulus[52]),
.Serial_10(stimulus[53]),
.Serial_100(stimulus[54]),
.Serial_2(stimulus[55]),
.Serial_20(stimulus[56]),
.Serial_200(stimulus[57]),
.Serial_4(stimulus[58]),
.Serial_40(stimulus[59]),
.TTLIOReset_p_(stimulus[60] | reference_TTLIOReset_p___drv),
.UseDMD(stimulus[61] | reference_UseDMD__drv),
.XmtData_p_(stimulus[62]),
.dStartClockPulse(stimulus[63]),
.baseboard_debug(reference_baseboard_debug),
.ACPI_0__drv(reference_ACPI_0__drv),
.ACPI_1__drv(reference_ACPI_1__drv),
.ACPI_2__drv(reference_ACPI_2__drv),
.ACPI_3__drv(reference_ACPI_3__drv),
.ACPI_4__drv(reference_ACPI_4__drv),
.ACPIGnd_0__drv(reference_ACPIGnd_0__drv),
.ACPIGnd_1__drv(reference_ACPIGnd_1__drv),
.ACPIGnd_2__drv(reference_ACPIGnd_2__drv),
.ACPIGnd_3__drv(reference_ACPIGnd_3__drv),
.ACPIGnd_4__drv(reference_ACPIGnd_4__drv),
.BootMC_p___drv(reference_BootMC_p___drv),
.BootNO__drv(reference_BootNO__drv),
.CLK_OutBase_p___drv(reference_CLK_OutBase_p___drv),
.CLK_ca_p___drv(reference_CLK_ca_p___drv),
.CLK_cb_p___drv(reference_CLK_cb_p___drv),
.CLK_disk_p___drv(reference_CLK_disk_p___drv),
.CLK_display_p___drv(reference_CLK_display_p___drv),
.CLK_ifu_p___drv(reference_CLK_ifu_p___drv),
.CLK_io20_p___drv(reference_CLK_io20_p___drv),
.CLK_io21_p___drv(reference_CLK_io21_p___drv),
.CLK_io22_p___drv(reference_CLK_io22_p___drv),
.CLK_io23_p___drv(reference_CLK_io23_p___drv),
.CLK_io24_p___drv(reference_CLK_io24_p___drv),
.CLK_mc_p___drv(reference_CLK_mc_p___drv),
.CLK_md_p___drv(reference_CLK_md_p___drv),
.CLK_ms0Even_p___drv(reference_CLK_ms0Even_p___drv),
.CLK_ms0Odd_p___drv(reference_CLK_ms0Odd_p___drv),
.CLK_ms1Even_p___drv(reference_CLK_ms1Even_p___drv),
.CLK_ms1Odd_p___drv(reference_CLK_ms1Odd_p___drv),
.CLK_ms2Even_p___drv(reference_CLK_ms2Even_p___drv),
.CLK_ms2Odd_p___drv(reference_CLK_ms2Odd_p___drv),
.CLK_ms3Even_p___drv(reference_CLK_ms3Even_p___drv),
.CLK_ms3Odd_p___drv(reference_CLK_ms3Odd_p___drv),
.CLK_mx_p___drv(reference_CLK_mx_p___drv),
.CLK_ph_p___drv(reference_CLK_ph_p___drv),
.CLK_pl_p___drv(reference_CLK_pl_p___drv),
.CPAddr_0_p___drv(reference_CPAddr_0_p___drv),
.CPAddr_1_p___drv(reference_CPAddr_1_p___drv),
.CPAddr_2_p___drv(reference_CPAddr_2_p___drv),
.CPOut_0__drv(reference_CPOut_0__drv),
.CPOut_1__drv(reference_CPOut_1__drv),
.CPOut_2__drv(reference_CPOut_2__drv),
.CPOut_3__drv(reference_CPOut_3__drv),
.CPOut_4__drv(reference_CPOut_4__drv),
.CPOut_5__drv(reference_CPOut_5__drv),
.CPOut_6__drv(reference_CPOut_6__drv),
.CPOut_7__drv(reference_CPOut_7__drv),
.CPOut_8__drv(reference_CPOut_8__drv),
.CPStrb_p___drv(reference_CPStrb_p___drv),
.DMuxClk__drv(reference_DMuxClk__drv),
.DMuxData__drv(reference_DMuxData__drv),
.IOReset__drv(reference_IOReset__drv),
.KeyboardData__drv(reference_KeyboardData__drv),
.Pendulum__drv(reference_Pendulum__drv),
.RfshPeriod__drv(reference_RfshPeriod__drv),
.Sequence0_p___drv(reference_Sequence0_p___drv),
.SetRun__drv(reference_SetRun__drv),
.SetRunRfsh__drv(reference_SetRunRfsh__drv),
.SetSS_p___drv(reference_SetSS_p___drv),
.SkipWait_p___drv(reference_SkipWait_p___drv),
.StartClockPulse__drv(reference_StartClockPulse__drv),
.TTLIOReset_p___drv(reference_TTLIOReset_p___drv),
.TempRef__drv(reference_TempRef__drv),
.TurnOff2v__drv(reference_TurnOff2v__drv),
.TurnOnDisk_p___drv(reference_TurnOnDisk_p___drv),
.TurnOnLED_p___drv(reference_TurnOnLED_p___drv),
.TurnOnPwr_p___drv(reference_TurnOnPwr_p___drv),
.UseDMD__drv(reference_UseDMD__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze || global_hold),
.state_guest_held(held || global_hold),
.state_system_reset(system_reset),
.state_request(request && freeze && held && !global_abort),
.state_write(write),
.state_index(index[16:0]),
.state_data(data),
.state_frozen(reference_frozen),
.state_done(reference_done),
.state_error(reference_error),
.state_result(reference_result),
.state_scan_hold_required(reference_hold),
.state_scan_fault(reference_fault)
);
assign reference_outputs={reference_UseDMD__drv,reference_TurnOnPwr_p___drv,reference_TurnOnLED_p___drv,reference_TurnOnDisk_p___drv,reference_TurnOff2v__drv,reference_TempRef__drv,reference_TTLIOReset_p___drv,reference_StartClockPulse__drv,reference_SkipWait_p___drv,reference_SetSS_p___drv,reference_SetRunRfsh__drv,reference_SetRun__drv,reference_Sequence0_p___drv,reference_RfshPeriod__drv,reference_Pendulum__drv,reference_KeyboardData__drv,reference_IOReset__drv,reference_DMuxData__drv,reference_DMuxClk__drv,reference_CPStrb_p___drv,reference_CPOut_8__drv,reference_CPOut_7__drv,reference_CPOut_6__drv,reference_CPOut_5__drv,reference_CPOut_4__drv,reference_CPOut_3__drv,reference_CPOut_2__drv,reference_CPOut_1__drv,reference_CPOut_0__drv,reference_CPAddr_2_p___drv,reference_CPAddr_1_p___drv,reference_CPAddr_0_p___drv,reference_CLK_pl_p___drv,reference_CLK_ph_p___drv,reference_CLK_mx_p___drv,reference_CLK_ms3Odd_p___drv,reference_CLK_ms3Even_p___drv,reference_CLK_ms2Odd_p___drv,reference_CLK_ms2Even_p___drv,reference_CLK_ms1Odd_p___drv,reference_CLK_ms1Even_p___drv,reference_CLK_ms0Odd_p___drv,reference_CLK_ms0Even_p___drv,reference_CLK_md_p___drv,reference_CLK_mc_p___drv,reference_CLK_io24_p___drv,reference_CLK_io23_p___drv,reference_CLK_io22_p___drv,reference_CLK_io21_p___drv,reference_CLK_io20_p___drv,reference_CLK_ifu_p___drv,reference_CLK_display_p___drv,reference_CLK_disk_p___drv,reference_CLK_cb_p___drv,reference_CLK_ca_p___drv,reference_CLK_OutBase_p___drv,reference_BootNO__drv,reference_BootMC_p___drv,reference_ACPIGnd_4__drv,reference_ACPIGnd_3__drv,reference_ACPIGnd_2__drv,reference_ACPIGnd_1__drv,reference_ACPIGnd_0__drv,reference_ACPI_4__drv,reference_ACPI_3__drv,reference_ACPI_2__drv,reference_ACPI_1__drv,reference_ACPI_0__drv,reference_baseboard_debug};
assign reference_state[0+:8]=reference.snapshot_sram_0.memory.saved_q;
assign reference_state[8+:8]=reference.snapshot_sram_1.memory.saved_q;
assign reference_state[16+:8]=reference.snapshot_sram_2.memory.saved_q;
assign reference_state[24+:8]=reference.snapshot_sram_3.memory.saved_q;
assign reference_state[32+:1]=reference.u_a01.ck_d;
assign reference_state[33+:6]=reference.u_a01.d_pre;
assign reference_state[39+:6]=reference.u_a01.q;
assign reference_state[45+:1]=reference.u_b02.cin_pre;
assign reference_state[46+:1]=reference.u_b02.ck_d;
assign reference_state[47+:4]=reference.u_b02.d_pre;
assign reference_state[51+:4]=reference.u_b02.q;
assign reference_state[55+:1]=reference.u_b02.sd_pre;
assign reference_state[56+:1]=reference.u_b02.su_pre;
assign reference_state[57+:8]=reference.u_b60.d;
assign reference_state[65+:1]=reference.u_b60.en_q;
assign reference_state[66+:8]=reference.u_b61.d;
assign reference_state[74+:1]=reference.u_b61.en_q;
assign reference_state[75+:8]=reference.u_c20.q;
assign reference_state[83+:8]=reference.u_c60.d;
assign reference_state[91+:1]=reference.u_c60.en_q;
assign reference_state[92+:8]=reference.u_c61.d;
assign reference_state[100+:1]=reference.u_c61.en_q;
assign reference_state[101+:1]=reference.u_c62.phase_d;
assign reference_state[102+:8]=reference.u_c62.u_riot.d_out;
assign reference_state[110+:8]=reference.u_c62.u_riot.dir_a;
assign reference_state[118+:8]=reference.u_c62.u_riot.dir_b;
assign reference_state[126+:1]=reference.u_c62.u_riot.edge_detect;
assign reference_state[127+:2]=reference.u_c62.u_riot.incr;
assign reference_state[129+:8]=reference.u_c62.u_riot.interrupt;
assign reference_state[137+:2]=reference.u_c62.u_riot.irq_en;
assign reference_state[139+:1]=reference.u_c62.u_riot.old_pa7;
assign reference_state[140+:8]=reference.u_c62.u_riot.out_a;
assign reference_state[148+:8]=reference.u_c62.u_riot.out_b;
assign reference_state[156+:10]=reference.u_c62.u_riot.prescaler;
assign reference_state[166+:1024]={reference.u_c62.u_riot.riot_ram[127],reference.u_c62.u_riot.riot_ram[126],reference.u_c62.u_riot.riot_ram[125],reference.u_c62.u_riot.riot_ram[124],reference.u_c62.u_riot.riot_ram[123],reference.u_c62.u_riot.riot_ram[122],reference.u_c62.u_riot.riot_ram[121],reference.u_c62.u_riot.riot_ram[120],reference.u_c62.u_riot.riot_ram[119],reference.u_c62.u_riot.riot_ram[118],reference.u_c62.u_riot.riot_ram[117],reference.u_c62.u_riot.riot_ram[116],reference.u_c62.u_riot.riot_ram[115],reference.u_c62.u_riot.riot_ram[114],reference.u_c62.u_riot.riot_ram[113],reference.u_c62.u_riot.riot_ram[112],reference.u_c62.u_riot.riot_ram[111],reference.u_c62.u_riot.riot_ram[110],reference.u_c62.u_riot.riot_ram[109],reference.u_c62.u_riot.riot_ram[108],reference.u_c62.u_riot.riot_ram[107],reference.u_c62.u_riot.riot_ram[106],reference.u_c62.u_riot.riot_ram[105],reference.u_c62.u_riot.riot_ram[104],reference.u_c62.u_riot.riot_ram[103],reference.u_c62.u_riot.riot_ram[102],reference.u_c62.u_riot.riot_ram[101],reference.u_c62.u_riot.riot_ram[100],reference.u_c62.u_riot.riot_ram[99],reference.u_c62.u_riot.riot_ram[98],reference.u_c62.u_riot.riot_ram[97],reference.u_c62.u_riot.riot_ram[96],reference.u_c62.u_riot.riot_ram[95],reference.u_c62.u_riot.riot_ram[94],reference.u_c62.u_riot.riot_ram[93],reference.u_c62.u_riot.riot_ram[92],reference.u_c62.u_riot.riot_ram[91],reference.u_c62.u_riot.riot_ram[90],reference.u_c62.u_riot.riot_ram[89],reference.u_c62.u_riot.riot_ram[88],reference.u_c62.u_riot.riot_ram[87],reference.u_c62.u_riot.riot_ram[86],reference.u_c62.u_riot.riot_ram[85],reference.u_c62.u_riot.riot_ram[84],reference.u_c62.u_riot.riot_ram[83],reference.u_c62.u_riot.riot_ram[82],reference.u_c62.u_riot.riot_ram[81],reference.u_c62.u_riot.riot_ram[80],reference.u_c62.u_riot.riot_ram[79],reference.u_c62.u_riot.riot_ram[78],reference.u_c62.u_riot.riot_ram[77],reference.u_c62.u_riot.riot_ram[76],reference.u_c62.u_riot.riot_ram[75],reference.u_c62.u_riot.riot_ram[74],reference.u_c62.u_riot.riot_ram[73],reference.u_c62.u_riot.riot_ram[72],reference.u_c62.u_riot.riot_ram[71],reference.u_c62.u_riot.riot_ram[70],reference.u_c62.u_riot.riot_ram[69],reference.u_c62.u_riot.riot_ram[68],reference.u_c62.u_riot.riot_ram[67],reference.u_c62.u_riot.riot_ram[66],reference.u_c62.u_riot.riot_ram[65],reference.u_c62.u_riot.riot_ram[64],reference.u_c62.u_riot.riot_ram[63],reference.u_c62.u_riot.riot_ram[62],reference.u_c62.u_riot.riot_ram[61],reference.u_c62.u_riot.riot_ram[60],reference.u_c62.u_riot.riot_ram[59],reference.u_c62.u_riot.riot_ram[58],reference.u_c62.u_riot.riot_ram[57],reference.u_c62.u_riot.riot_ram[56],reference.u_c62.u_riot.riot_ram[55],reference.u_c62.u_riot.riot_ram[54],reference.u_c62.u_riot.riot_ram[53],reference.u_c62.u_riot.riot_ram[52],reference.u_c62.u_riot.riot_ram[51],reference.u_c62.u_riot.riot_ram[50],reference.u_c62.u_riot.riot_ram[49],reference.u_c62.u_riot.riot_ram[48],reference.u_c62.u_riot.riot_ram[47],reference.u_c62.u_riot.riot_ram[46],reference.u_c62.u_riot.riot_ram[45],reference.u_c62.u_riot.riot_ram[44],reference.u_c62.u_riot.riot_ram[43],reference.u_c62.u_riot.riot_ram[42],reference.u_c62.u_riot.riot_ram[41],reference.u_c62.u_riot.riot_ram[40],reference.u_c62.u_riot.riot_ram[39],reference.u_c62.u_riot.riot_ram[38],reference.u_c62.u_riot.riot_ram[37],reference.u_c62.u_riot.riot_ram[36],reference.u_c62.u_riot.riot_ram[35],reference.u_c62.u_riot.riot_ram[34],reference.u_c62.u_riot.riot_ram[33],reference.u_c62.u_riot.riot_ram[32],reference.u_c62.u_riot.riot_ram[31],reference.u_c62.u_riot.riot_ram[30],reference.u_c62.u_riot.riot_ram[29],reference.u_c62.u_riot.riot_ram[28],reference.u_c62.u_riot.riot_ram[27],reference.u_c62.u_riot.riot_ram[26],reference.u_c62.u_riot.riot_ram[25],reference.u_c62.u_riot.riot_ram[24],reference.u_c62.u_riot.riot_ram[23],reference.u_c62.u_riot.riot_ram[22],reference.u_c62.u_riot.riot_ram[21],reference.u_c62.u_riot.riot_ram[20],reference.u_c62.u_riot.riot_ram[19],reference.u_c62.u_riot.riot_ram[18],reference.u_c62.u_riot.riot_ram[17],reference.u_c62.u_riot.riot_ram[16],reference.u_c62.u_riot.riot_ram[15],reference.u_c62.u_riot.riot_ram[14],reference.u_c62.u_riot.riot_ram[13],reference.u_c62.u_riot.riot_ram[12],reference.u_c62.u_riot.riot_ram[11],reference.u_c62.u_riot.riot_ram[10],reference.u_c62.u_riot.riot_ram[9],reference.u_c62.u_riot.riot_ram[8],reference.u_c62.u_riot.riot_ram[7],reference.u_c62.u_riot.riot_ram[6],reference.u_c62.u_riot.riot_ram[5],reference.u_c62.u_riot.riot_ram[4],reference.u_c62.u_riot.riot_ram[3],reference.u_c62.u_riot.riot_ram[2],reference.u_c62.u_riot.riot_ram[1],reference.u_c62.u_riot.riot_ram[0]};
assign reference_state[1190+:1]=reference.u_c62.u_riot.rollover;
assign reference_state[1191+:8]=reference.u_c62.u_riot.timer;
assign reference_state[1199+:2]=reference.u_clockgen.phase;
assign reference_state[1201+:3]=reference.u_d08.osc_div;
assign reference_state[1204+:1]=reference.u_e07.ck_d;
assign reference_state[1205+:4]=reference.u_e07.q;
assign reference_state[1209+:8]=reference.u_e60.d;
assign reference_state[1217+:1]=reference.u_e60.en_q;
assign reference_state[1218+:1]=reference.u_f19.ck_d;
assign reference_state[1219+:6]=reference.u_f19.d_pre;
assign reference_state[1225+:6]=reference.u_f19.q;
assign reference_state[1231+:1]=reference.u_f20.ck_d;
assign reference_state[1232+:6]=reference.u_f20.d_pre;
assign reference_state[1238+:6]=reference.u_f20.q;
assign reference_state[1244+:8]=reference.u_f60.d;
assign reference_state[1252+:1]=reference.u_f60.en_q;
assign reference_state[1253+:1725]=reference.u_f61.u_cpu.q;
assign reference_state[2978+:1]=reference.u_f62.phase_d;
assign reference_state[2979+:8]=reference.u_f62.u_riot.d_out;
assign reference_state[2987+:8]=reference.u_f62.u_riot.dir_a;
assign reference_state[2995+:8]=reference.u_f62.u_riot.dir_b;
assign reference_state[3003+:1]=reference.u_f62.u_riot.edge_detect;
assign reference_state[3004+:2]=reference.u_f62.u_riot.incr;
assign reference_state[3006+:8]=reference.u_f62.u_riot.interrupt;
assign reference_state[3014+:2]=reference.u_f62.u_riot.irq_en;
assign reference_state[3016+:1]=reference.u_f62.u_riot.old_pa7;
assign reference_state[3017+:8]=reference.u_f62.u_riot.out_a;
assign reference_state[3025+:8]=reference.u_f62.u_riot.out_b;
assign reference_state[3033+:10]=reference.u_f62.u_riot.prescaler;
assign reference_state[3043+:1024]={reference.u_f62.u_riot.riot_ram[127],reference.u_f62.u_riot.riot_ram[126],reference.u_f62.u_riot.riot_ram[125],reference.u_f62.u_riot.riot_ram[124],reference.u_f62.u_riot.riot_ram[123],reference.u_f62.u_riot.riot_ram[122],reference.u_f62.u_riot.riot_ram[121],reference.u_f62.u_riot.riot_ram[120],reference.u_f62.u_riot.riot_ram[119],reference.u_f62.u_riot.riot_ram[118],reference.u_f62.u_riot.riot_ram[117],reference.u_f62.u_riot.riot_ram[116],reference.u_f62.u_riot.riot_ram[115],reference.u_f62.u_riot.riot_ram[114],reference.u_f62.u_riot.riot_ram[113],reference.u_f62.u_riot.riot_ram[112],reference.u_f62.u_riot.riot_ram[111],reference.u_f62.u_riot.riot_ram[110],reference.u_f62.u_riot.riot_ram[109],reference.u_f62.u_riot.riot_ram[108],reference.u_f62.u_riot.riot_ram[107],reference.u_f62.u_riot.riot_ram[106],reference.u_f62.u_riot.riot_ram[105],reference.u_f62.u_riot.riot_ram[104],reference.u_f62.u_riot.riot_ram[103],reference.u_f62.u_riot.riot_ram[102],reference.u_f62.u_riot.riot_ram[101],reference.u_f62.u_riot.riot_ram[100],reference.u_f62.u_riot.riot_ram[99],reference.u_f62.u_riot.riot_ram[98],reference.u_f62.u_riot.riot_ram[97],reference.u_f62.u_riot.riot_ram[96],reference.u_f62.u_riot.riot_ram[95],reference.u_f62.u_riot.riot_ram[94],reference.u_f62.u_riot.riot_ram[93],reference.u_f62.u_riot.riot_ram[92],reference.u_f62.u_riot.riot_ram[91],reference.u_f62.u_riot.riot_ram[90],reference.u_f62.u_riot.riot_ram[89],reference.u_f62.u_riot.riot_ram[88],reference.u_f62.u_riot.riot_ram[87],reference.u_f62.u_riot.riot_ram[86],reference.u_f62.u_riot.riot_ram[85],reference.u_f62.u_riot.riot_ram[84],reference.u_f62.u_riot.riot_ram[83],reference.u_f62.u_riot.riot_ram[82],reference.u_f62.u_riot.riot_ram[81],reference.u_f62.u_riot.riot_ram[80],reference.u_f62.u_riot.riot_ram[79],reference.u_f62.u_riot.riot_ram[78],reference.u_f62.u_riot.riot_ram[77],reference.u_f62.u_riot.riot_ram[76],reference.u_f62.u_riot.riot_ram[75],reference.u_f62.u_riot.riot_ram[74],reference.u_f62.u_riot.riot_ram[73],reference.u_f62.u_riot.riot_ram[72],reference.u_f62.u_riot.riot_ram[71],reference.u_f62.u_riot.riot_ram[70],reference.u_f62.u_riot.riot_ram[69],reference.u_f62.u_riot.riot_ram[68],reference.u_f62.u_riot.riot_ram[67],reference.u_f62.u_riot.riot_ram[66],reference.u_f62.u_riot.riot_ram[65],reference.u_f62.u_riot.riot_ram[64],reference.u_f62.u_riot.riot_ram[63],reference.u_f62.u_riot.riot_ram[62],reference.u_f62.u_riot.riot_ram[61],reference.u_f62.u_riot.riot_ram[60],reference.u_f62.u_riot.riot_ram[59],reference.u_f62.u_riot.riot_ram[58],reference.u_f62.u_riot.riot_ram[57],reference.u_f62.u_riot.riot_ram[56],reference.u_f62.u_riot.riot_ram[55],reference.u_f62.u_riot.riot_ram[54],reference.u_f62.u_riot.riot_ram[53],reference.u_f62.u_riot.riot_ram[52],reference.u_f62.u_riot.riot_ram[51],reference.u_f62.u_riot.riot_ram[50],reference.u_f62.u_riot.riot_ram[49],reference.u_f62.u_riot.riot_ram[48],reference.u_f62.u_riot.riot_ram[47],reference.u_f62.u_riot.riot_ram[46],reference.u_f62.u_riot.riot_ram[45],reference.u_f62.u_riot.riot_ram[44],reference.u_f62.u_riot.riot_ram[43],reference.u_f62.u_riot.riot_ram[42],reference.u_f62.u_riot.riot_ram[41],reference.u_f62.u_riot.riot_ram[40],reference.u_f62.u_riot.riot_ram[39],reference.u_f62.u_riot.riot_ram[38],reference.u_f62.u_riot.riot_ram[37],reference.u_f62.u_riot.riot_ram[36],reference.u_f62.u_riot.riot_ram[35],reference.u_f62.u_riot.riot_ram[34],reference.u_f62.u_riot.riot_ram[33],reference.u_f62.u_riot.riot_ram[32],reference.u_f62.u_riot.riot_ram[31],reference.u_f62.u_riot.riot_ram[30],reference.u_f62.u_riot.riot_ram[29],reference.u_f62.u_riot.riot_ram[28],reference.u_f62.u_riot.riot_ram[27],reference.u_f62.u_riot.riot_ram[26],reference.u_f62.u_riot.riot_ram[25],reference.u_f62.u_riot.riot_ram[24],reference.u_f62.u_riot.riot_ram[23],reference.u_f62.u_riot.riot_ram[22],reference.u_f62.u_riot.riot_ram[21],reference.u_f62.u_riot.riot_ram[20],reference.u_f62.u_riot.riot_ram[19],reference.u_f62.u_riot.riot_ram[18],reference.u_f62.u_riot.riot_ram[17],reference.u_f62.u_riot.riot_ram[16],reference.u_f62.u_riot.riot_ram[15],reference.u_f62.u_riot.riot_ram[14],reference.u_f62.u_riot.riot_ram[13],reference.u_f62.u_riot.riot_ram[12],reference.u_f62.u_riot.riot_ram[11],reference.u_f62.u_riot.riot_ram[10],reference.u_f62.u_riot.riot_ram[9],reference.u_f62.u_riot.riot_ram[8],reference.u_f62.u_riot.riot_ram[7],reference.u_f62.u_riot.riot_ram[6],reference.u_f62.u_riot.riot_ram[5],reference.u_f62.u_riot.riot_ram[4],reference.u_f62.u_riot.riot_ram[3],reference.u_f62.u_riot.riot_ram[2],reference.u_f62.u_riot.riot_ram[1],reference.u_f62.u_riot.riot_ram[0]};
assign reference_state[4067+:1]=reference.u_f62.u_riot.rollover;
assign reference_state[4068+:8]=reference.u_f62.u_riot.timer;
assign reference_state[4076+:1]=reference.u_f63.phase_d;
assign reference_state[4077+:8]=reference.u_f63.u_riot.d_out;
assign reference_state[4085+:8]=reference.u_f63.u_riot.dir_a;
assign reference_state[4093+:8]=reference.u_f63.u_riot.dir_b;
assign reference_state[4101+:1]=reference.u_f63.u_riot.edge_detect;
assign reference_state[4102+:2]=reference.u_f63.u_riot.incr;
assign reference_state[4104+:8]=reference.u_f63.u_riot.interrupt;
assign reference_state[4112+:2]=reference.u_f63.u_riot.irq_en;
assign reference_state[4114+:1]=reference.u_f63.u_riot.old_pa7;
assign reference_state[4115+:8]=reference.u_f63.u_riot.out_a;
assign reference_state[4123+:8]=reference.u_f63.u_riot.out_b;
assign reference_state[4131+:10]=reference.u_f63.u_riot.prescaler;
assign reference_state[4141+:1024]={reference.u_f63.u_riot.riot_ram[127],reference.u_f63.u_riot.riot_ram[126],reference.u_f63.u_riot.riot_ram[125],reference.u_f63.u_riot.riot_ram[124],reference.u_f63.u_riot.riot_ram[123],reference.u_f63.u_riot.riot_ram[122],reference.u_f63.u_riot.riot_ram[121],reference.u_f63.u_riot.riot_ram[120],reference.u_f63.u_riot.riot_ram[119],reference.u_f63.u_riot.riot_ram[118],reference.u_f63.u_riot.riot_ram[117],reference.u_f63.u_riot.riot_ram[116],reference.u_f63.u_riot.riot_ram[115],reference.u_f63.u_riot.riot_ram[114],reference.u_f63.u_riot.riot_ram[113],reference.u_f63.u_riot.riot_ram[112],reference.u_f63.u_riot.riot_ram[111],reference.u_f63.u_riot.riot_ram[110],reference.u_f63.u_riot.riot_ram[109],reference.u_f63.u_riot.riot_ram[108],reference.u_f63.u_riot.riot_ram[107],reference.u_f63.u_riot.riot_ram[106],reference.u_f63.u_riot.riot_ram[105],reference.u_f63.u_riot.riot_ram[104],reference.u_f63.u_riot.riot_ram[103],reference.u_f63.u_riot.riot_ram[102],reference.u_f63.u_riot.riot_ram[101],reference.u_f63.u_riot.riot_ram[100],reference.u_f63.u_riot.riot_ram[99],reference.u_f63.u_riot.riot_ram[98],reference.u_f63.u_riot.riot_ram[97],reference.u_f63.u_riot.riot_ram[96],reference.u_f63.u_riot.riot_ram[95],reference.u_f63.u_riot.riot_ram[94],reference.u_f63.u_riot.riot_ram[93],reference.u_f63.u_riot.riot_ram[92],reference.u_f63.u_riot.riot_ram[91],reference.u_f63.u_riot.riot_ram[90],reference.u_f63.u_riot.riot_ram[89],reference.u_f63.u_riot.riot_ram[88],reference.u_f63.u_riot.riot_ram[87],reference.u_f63.u_riot.riot_ram[86],reference.u_f63.u_riot.riot_ram[85],reference.u_f63.u_riot.riot_ram[84],reference.u_f63.u_riot.riot_ram[83],reference.u_f63.u_riot.riot_ram[82],reference.u_f63.u_riot.riot_ram[81],reference.u_f63.u_riot.riot_ram[80],reference.u_f63.u_riot.riot_ram[79],reference.u_f63.u_riot.riot_ram[78],reference.u_f63.u_riot.riot_ram[77],reference.u_f63.u_riot.riot_ram[76],reference.u_f63.u_riot.riot_ram[75],reference.u_f63.u_riot.riot_ram[74],reference.u_f63.u_riot.riot_ram[73],reference.u_f63.u_riot.riot_ram[72],reference.u_f63.u_riot.riot_ram[71],reference.u_f63.u_riot.riot_ram[70],reference.u_f63.u_riot.riot_ram[69],reference.u_f63.u_riot.riot_ram[68],reference.u_f63.u_riot.riot_ram[67],reference.u_f63.u_riot.riot_ram[66],reference.u_f63.u_riot.riot_ram[65],reference.u_f63.u_riot.riot_ram[64],reference.u_f63.u_riot.riot_ram[63],reference.u_f63.u_riot.riot_ram[62],reference.u_f63.u_riot.riot_ram[61],reference.u_f63.u_riot.riot_ram[60],reference.u_f63.u_riot.riot_ram[59],reference.u_f63.u_riot.riot_ram[58],reference.u_f63.u_riot.riot_ram[57],reference.u_f63.u_riot.riot_ram[56],reference.u_f63.u_riot.riot_ram[55],reference.u_f63.u_riot.riot_ram[54],reference.u_f63.u_riot.riot_ram[53],reference.u_f63.u_riot.riot_ram[52],reference.u_f63.u_riot.riot_ram[51],reference.u_f63.u_riot.riot_ram[50],reference.u_f63.u_riot.riot_ram[49],reference.u_f63.u_riot.riot_ram[48],reference.u_f63.u_riot.riot_ram[47],reference.u_f63.u_riot.riot_ram[46],reference.u_f63.u_riot.riot_ram[45],reference.u_f63.u_riot.riot_ram[44],reference.u_f63.u_riot.riot_ram[43],reference.u_f63.u_riot.riot_ram[42],reference.u_f63.u_riot.riot_ram[41],reference.u_f63.u_riot.riot_ram[40],reference.u_f63.u_riot.riot_ram[39],reference.u_f63.u_riot.riot_ram[38],reference.u_f63.u_riot.riot_ram[37],reference.u_f63.u_riot.riot_ram[36],reference.u_f63.u_riot.riot_ram[35],reference.u_f63.u_riot.riot_ram[34],reference.u_f63.u_riot.riot_ram[33],reference.u_f63.u_riot.riot_ram[32],reference.u_f63.u_riot.riot_ram[31],reference.u_f63.u_riot.riot_ram[30],reference.u_f63.u_riot.riot_ram[29],reference.u_f63.u_riot.riot_ram[28],reference.u_f63.u_riot.riot_ram[27],reference.u_f63.u_riot.riot_ram[26],reference.u_f63.u_riot.riot_ram[25],reference.u_f63.u_riot.riot_ram[24],reference.u_f63.u_riot.riot_ram[23],reference.u_f63.u_riot.riot_ram[22],reference.u_f63.u_riot.riot_ram[21],reference.u_f63.u_riot.riot_ram[20],reference.u_f63.u_riot.riot_ram[19],reference.u_f63.u_riot.riot_ram[18],reference.u_f63.u_riot.riot_ram[17],reference.u_f63.u_riot.riot_ram[16],reference.u_f63.u_riot.riot_ram[15],reference.u_f63.u_riot.riot_ram[14],reference.u_f63.u_riot.riot_ram[13],reference.u_f63.u_riot.riot_ram[12],reference.u_f63.u_riot.riot_ram[11],reference.u_f63.u_riot.riot_ram[10],reference.u_f63.u_riot.riot_ram[9],reference.u_f63.u_riot.riot_ram[8],reference.u_f63.u_riot.riot_ram[7],reference.u_f63.u_riot.riot_ram[6],reference.u_f63.u_riot.riot_ram[5],reference.u_f63.u_riot.riot_ram[4],reference.u_f63.u_riot.riot_ram[3],reference.u_f63.u_riot.riot_ram[2],reference.u_f63.u_riot.riot_ram[1],reference.u_f63.u_riot.riot_ram[0]};
assign reference_state[5165+:1]=reference.u_f63.u_riot.rollover;
assign reference_state[5166+:8]=reference.u_f63.u_riot.timer;
assign reference_state[5174+:1]=reference.u_g03.ck_d;
assign reference_state[5175+:1]=reference.u_g03.q;
assign reference_state[5176+:1]=reference.u_g04.ck_d;
assign reference_state[5177+:1]=reference.u_g04.q;
assign reference_state[5178+:1]=reference.u_g07.ck_d;
assign reference_state[5179+:2]=reference.u_g07.q;
assign reference_state[5181+:1]=reference.u_g08.cka_d;
assign reference_state[5182+:1]=reference.u_g08.ckb_d;
assign reference_state[5183+:1]=reference.u_g08.qa;
assign reference_state[5184+:1]=reference.u_g08.qb;
assign reference_state[5185+:1]=reference.u_g20.ck_d;
assign reference_state[5186+:6]=reference.u_g20.d_pre;
assign reference_state[5192+:6]=reference.u_g20.q;
assign reference_state[5198+:1]=reference.u_g21.ck_d;
assign reference_state[5199+:24]=reference.u_g21.cnt;
assign reference_state[5223+:1]=reference.u_g22.cka_d;
assign reference_state[5224+:1]=reference.u_g22.ckb_d;
assign reference_state[5225+:1]=reference.u_g22.qa;
assign reference_state[5226+:1]=reference.u_g22.qb;
assign reference_state[5227+:1]=reference.u_h03.ck_d;
assign reference_state[5228+:1]=reference.u_h03.q;
assign reference_state[5229+:1]=reference.u_h04.ck_d;
assign reference_state[5230+:1]=reference.u_h04.q;
assign reference_state[5231+:16]=reference.u_h06.por;
assign reference_state[5247+:2]=reference.u_h06.vco;
assign reference_state[5249+:1]=reference.u_h20.ck_d;
assign reference_state[5250+:6]=reference.u_h20.d_pre;
assign reference_state[5256+:6]=reference.u_h20.q;
assign reference_state[5262+:8]=reference.u_h61.d;
assign reference_state[5270+:1]=reference.u_h61.en_q;
assign reference_state[5271+:8]=reference.u_i61.d;
assign reference_state[5279+:1]=reference.u_i61.en_q;
assign reference_state[5280+:1]=reference.u_i62.phase_d;
assign reference_state[5281+:8]=reference.u_i62.u_riot.d_out;
assign reference_state[5289+:8]=reference.u_i62.u_riot.dir_a;
assign reference_state[5297+:8]=reference.u_i62.u_riot.dir_b;
assign reference_state[5305+:1]=reference.u_i62.u_riot.edge_detect;
assign reference_state[5306+:2]=reference.u_i62.u_riot.incr;
assign reference_state[5308+:8]=reference.u_i62.u_riot.interrupt;
assign reference_state[5316+:2]=reference.u_i62.u_riot.irq_en;
assign reference_state[5318+:1]=reference.u_i62.u_riot.old_pa7;
assign reference_state[5319+:8]=reference.u_i62.u_riot.out_a;
assign reference_state[5327+:8]=reference.u_i62.u_riot.out_b;
assign reference_state[5335+:10]=reference.u_i62.u_riot.prescaler;
assign reference_state[5345+:1024]={reference.u_i62.u_riot.riot_ram[127],reference.u_i62.u_riot.riot_ram[126],reference.u_i62.u_riot.riot_ram[125],reference.u_i62.u_riot.riot_ram[124],reference.u_i62.u_riot.riot_ram[123],reference.u_i62.u_riot.riot_ram[122],reference.u_i62.u_riot.riot_ram[121],reference.u_i62.u_riot.riot_ram[120],reference.u_i62.u_riot.riot_ram[119],reference.u_i62.u_riot.riot_ram[118],reference.u_i62.u_riot.riot_ram[117],reference.u_i62.u_riot.riot_ram[116],reference.u_i62.u_riot.riot_ram[115],reference.u_i62.u_riot.riot_ram[114],reference.u_i62.u_riot.riot_ram[113],reference.u_i62.u_riot.riot_ram[112],reference.u_i62.u_riot.riot_ram[111],reference.u_i62.u_riot.riot_ram[110],reference.u_i62.u_riot.riot_ram[109],reference.u_i62.u_riot.riot_ram[108],reference.u_i62.u_riot.riot_ram[107],reference.u_i62.u_riot.riot_ram[106],reference.u_i62.u_riot.riot_ram[105],reference.u_i62.u_riot.riot_ram[104],reference.u_i62.u_riot.riot_ram[103],reference.u_i62.u_riot.riot_ram[102],reference.u_i62.u_riot.riot_ram[101],reference.u_i62.u_riot.riot_ram[100],reference.u_i62.u_riot.riot_ram[99],reference.u_i62.u_riot.riot_ram[98],reference.u_i62.u_riot.riot_ram[97],reference.u_i62.u_riot.riot_ram[96],reference.u_i62.u_riot.riot_ram[95],reference.u_i62.u_riot.riot_ram[94],reference.u_i62.u_riot.riot_ram[93],reference.u_i62.u_riot.riot_ram[92],reference.u_i62.u_riot.riot_ram[91],reference.u_i62.u_riot.riot_ram[90],reference.u_i62.u_riot.riot_ram[89],reference.u_i62.u_riot.riot_ram[88],reference.u_i62.u_riot.riot_ram[87],reference.u_i62.u_riot.riot_ram[86],reference.u_i62.u_riot.riot_ram[85],reference.u_i62.u_riot.riot_ram[84],reference.u_i62.u_riot.riot_ram[83],reference.u_i62.u_riot.riot_ram[82],reference.u_i62.u_riot.riot_ram[81],reference.u_i62.u_riot.riot_ram[80],reference.u_i62.u_riot.riot_ram[79],reference.u_i62.u_riot.riot_ram[78],reference.u_i62.u_riot.riot_ram[77],reference.u_i62.u_riot.riot_ram[76],reference.u_i62.u_riot.riot_ram[75],reference.u_i62.u_riot.riot_ram[74],reference.u_i62.u_riot.riot_ram[73],reference.u_i62.u_riot.riot_ram[72],reference.u_i62.u_riot.riot_ram[71],reference.u_i62.u_riot.riot_ram[70],reference.u_i62.u_riot.riot_ram[69],reference.u_i62.u_riot.riot_ram[68],reference.u_i62.u_riot.riot_ram[67],reference.u_i62.u_riot.riot_ram[66],reference.u_i62.u_riot.riot_ram[65],reference.u_i62.u_riot.riot_ram[64],reference.u_i62.u_riot.riot_ram[63],reference.u_i62.u_riot.riot_ram[62],reference.u_i62.u_riot.riot_ram[61],reference.u_i62.u_riot.riot_ram[60],reference.u_i62.u_riot.riot_ram[59],reference.u_i62.u_riot.riot_ram[58],reference.u_i62.u_riot.riot_ram[57],reference.u_i62.u_riot.riot_ram[56],reference.u_i62.u_riot.riot_ram[55],reference.u_i62.u_riot.riot_ram[54],reference.u_i62.u_riot.riot_ram[53],reference.u_i62.u_riot.riot_ram[52],reference.u_i62.u_riot.riot_ram[51],reference.u_i62.u_riot.riot_ram[50],reference.u_i62.u_riot.riot_ram[49],reference.u_i62.u_riot.riot_ram[48],reference.u_i62.u_riot.riot_ram[47],reference.u_i62.u_riot.riot_ram[46],reference.u_i62.u_riot.riot_ram[45],reference.u_i62.u_riot.riot_ram[44],reference.u_i62.u_riot.riot_ram[43],reference.u_i62.u_riot.riot_ram[42],reference.u_i62.u_riot.riot_ram[41],reference.u_i62.u_riot.riot_ram[40],reference.u_i62.u_riot.riot_ram[39],reference.u_i62.u_riot.riot_ram[38],reference.u_i62.u_riot.riot_ram[37],reference.u_i62.u_riot.riot_ram[36],reference.u_i62.u_riot.riot_ram[35],reference.u_i62.u_riot.riot_ram[34],reference.u_i62.u_riot.riot_ram[33],reference.u_i62.u_riot.riot_ram[32],reference.u_i62.u_riot.riot_ram[31],reference.u_i62.u_riot.riot_ram[30],reference.u_i62.u_riot.riot_ram[29],reference.u_i62.u_riot.riot_ram[28],reference.u_i62.u_riot.riot_ram[27],reference.u_i62.u_riot.riot_ram[26],reference.u_i62.u_riot.riot_ram[25],reference.u_i62.u_riot.riot_ram[24],reference.u_i62.u_riot.riot_ram[23],reference.u_i62.u_riot.riot_ram[22],reference.u_i62.u_riot.riot_ram[21],reference.u_i62.u_riot.riot_ram[20],reference.u_i62.u_riot.riot_ram[19],reference.u_i62.u_riot.riot_ram[18],reference.u_i62.u_riot.riot_ram[17],reference.u_i62.u_riot.riot_ram[16],reference.u_i62.u_riot.riot_ram[15],reference.u_i62.u_riot.riot_ram[14],reference.u_i62.u_riot.riot_ram[13],reference.u_i62.u_riot.riot_ram[12],reference.u_i62.u_riot.riot_ram[11],reference.u_i62.u_riot.riot_ram[10],reference.u_i62.u_riot.riot_ram[9],reference.u_i62.u_riot.riot_ram[8],reference.u_i62.u_riot.riot_ram[7],reference.u_i62.u_riot.riot_ram[6],reference.u_i62.u_riot.riot_ram[5],reference.u_i62.u_riot.riot_ram[4],reference.u_i62.u_riot.riot_ram[3],reference.u_i62.u_riot.riot_ram[2],reference.u_i62.u_riot.riot_ram[1],reference.u_i62.u_riot.riot_ram[0]};
assign reference_state[6369+:1]=reference.u_i62.u_riot.rollover;
assign reference_state[6370+:8]=reference.u_i62.u_riot.timer;
assign reference_state[6378+:1]=reference.u_j08.cka_d;
assign reference_state[6379+:1]=reference.u_j08.ckb_d;
assign reference_state[6380+:1]=reference.u_j08.qa;
assign reference_state[6381+:1]=reference.u_j08.qb;
assign reference_state[6382+:1]=reference.u_k02.cin_pre;
assign reference_state[6383+:1]=reference.u_k02.ck_d;
assign reference_state[6384+:4]=reference.u_k02.d_pre;
assign reference_state[6388+:4]=reference.u_k02.q;
assign reference_state[6392+:1]=reference.u_k02.sd_pre;
assign reference_state[6393+:1]=reference.u_k02.su_pre;
assign reference_state[6394+:1]=reference.u_k03.cin_pre;
assign reference_state[6395+:1]=reference.u_k03.ck_d;
assign reference_state[6396+:4]=reference.u_k03.d_pre;
assign reference_state[6400+:4]=reference.u_k03.q;
assign reference_state[6404+:1]=reference.u_k03.sd_pre;
assign reference_state[6405+:1]=reference.u_k03.su_pre;
assign reference_state[6406+:1]=reference.u_k07.ck_d;
assign reference_state[6407+:6]=reference.u_k07.d_pre;
assign reference_state[6413+:6]=reference.u_k07.q;
assign reference_state[6419+:1]=reference.u_k08.ck_d;
assign reference_state[6420+:6]=reference.u_k08.d_pre;
assign reference_state[6426+:6]=reference.u_k08.q;
assign reference_state[6432+:1]=reference.u_k09.ck_d;
assign reference_state[6433+:6]=reference.u_k09.d_pre;
assign reference_state[6439+:6]=reference.u_k09.q;
assign reference_state[6445+:1]=reference.u_l07.ck_d;
assign reference_state[6446+:6]=reference.u_l07.d_pre;
assign reference_state[6452+:6]=reference.u_l07.q;
assign reference_state[6458+:1]=reference.u_l08.ck_d;
assign reference_state[6459+:6]=reference.u_l08.d_pre;
assign reference_state[6465+:6]=reference.u_l08.q;
assign reference_state[6471+:1]=reference.u_l18.ck_d;
assign reference_state[6472+:2]=reference.u_l18.q;
assign reference_state[6474+:1]=reference.u_l21.ck_d;
assign reference_state[6475+:6]=reference.u_l21.d_pre;
assign reference_state[6481+:6]=reference.u_l21.q;
assign reference_state[6487+:1]=reference.u_l22.ck_d;
assign reference_state[6488+:6]=reference.u_l22.d_pre;
assign reference_state[6494+:6]=reference.u_l22.q;
assign reference_state[6500+:1]=reference.u_l62.phase_d;
assign reference_state[6501+:8]=reference.u_l62.u_riot.d_out;
assign reference_state[6509+:8]=reference.u_l62.u_riot.dir_a;
assign reference_state[6517+:8]=reference.u_l62.u_riot.dir_b;
assign reference_state[6525+:1]=reference.u_l62.u_riot.edge_detect;
assign reference_state[6526+:2]=reference.u_l62.u_riot.incr;
assign reference_state[6528+:8]=reference.u_l62.u_riot.interrupt;
assign reference_state[6536+:2]=reference.u_l62.u_riot.irq_en;
assign reference_state[6538+:1]=reference.u_l62.u_riot.old_pa7;
assign reference_state[6539+:8]=reference.u_l62.u_riot.out_a;
assign reference_state[6547+:8]=reference.u_l62.u_riot.out_b;
assign reference_state[6555+:10]=reference.u_l62.u_riot.prescaler;
assign reference_state[6565+:1024]={reference.u_l62.u_riot.riot_ram[127],reference.u_l62.u_riot.riot_ram[126],reference.u_l62.u_riot.riot_ram[125],reference.u_l62.u_riot.riot_ram[124],reference.u_l62.u_riot.riot_ram[123],reference.u_l62.u_riot.riot_ram[122],reference.u_l62.u_riot.riot_ram[121],reference.u_l62.u_riot.riot_ram[120],reference.u_l62.u_riot.riot_ram[119],reference.u_l62.u_riot.riot_ram[118],reference.u_l62.u_riot.riot_ram[117],reference.u_l62.u_riot.riot_ram[116],reference.u_l62.u_riot.riot_ram[115],reference.u_l62.u_riot.riot_ram[114],reference.u_l62.u_riot.riot_ram[113],reference.u_l62.u_riot.riot_ram[112],reference.u_l62.u_riot.riot_ram[111],reference.u_l62.u_riot.riot_ram[110],reference.u_l62.u_riot.riot_ram[109],reference.u_l62.u_riot.riot_ram[108],reference.u_l62.u_riot.riot_ram[107],reference.u_l62.u_riot.riot_ram[106],reference.u_l62.u_riot.riot_ram[105],reference.u_l62.u_riot.riot_ram[104],reference.u_l62.u_riot.riot_ram[103],reference.u_l62.u_riot.riot_ram[102],reference.u_l62.u_riot.riot_ram[101],reference.u_l62.u_riot.riot_ram[100],reference.u_l62.u_riot.riot_ram[99],reference.u_l62.u_riot.riot_ram[98],reference.u_l62.u_riot.riot_ram[97],reference.u_l62.u_riot.riot_ram[96],reference.u_l62.u_riot.riot_ram[95],reference.u_l62.u_riot.riot_ram[94],reference.u_l62.u_riot.riot_ram[93],reference.u_l62.u_riot.riot_ram[92],reference.u_l62.u_riot.riot_ram[91],reference.u_l62.u_riot.riot_ram[90],reference.u_l62.u_riot.riot_ram[89],reference.u_l62.u_riot.riot_ram[88],reference.u_l62.u_riot.riot_ram[87],reference.u_l62.u_riot.riot_ram[86],reference.u_l62.u_riot.riot_ram[85],reference.u_l62.u_riot.riot_ram[84],reference.u_l62.u_riot.riot_ram[83],reference.u_l62.u_riot.riot_ram[82],reference.u_l62.u_riot.riot_ram[81],reference.u_l62.u_riot.riot_ram[80],reference.u_l62.u_riot.riot_ram[79],reference.u_l62.u_riot.riot_ram[78],reference.u_l62.u_riot.riot_ram[77],reference.u_l62.u_riot.riot_ram[76],reference.u_l62.u_riot.riot_ram[75],reference.u_l62.u_riot.riot_ram[74],reference.u_l62.u_riot.riot_ram[73],reference.u_l62.u_riot.riot_ram[72],reference.u_l62.u_riot.riot_ram[71],reference.u_l62.u_riot.riot_ram[70],reference.u_l62.u_riot.riot_ram[69],reference.u_l62.u_riot.riot_ram[68],reference.u_l62.u_riot.riot_ram[67],reference.u_l62.u_riot.riot_ram[66],reference.u_l62.u_riot.riot_ram[65],reference.u_l62.u_riot.riot_ram[64],reference.u_l62.u_riot.riot_ram[63],reference.u_l62.u_riot.riot_ram[62],reference.u_l62.u_riot.riot_ram[61],reference.u_l62.u_riot.riot_ram[60],reference.u_l62.u_riot.riot_ram[59],reference.u_l62.u_riot.riot_ram[58],reference.u_l62.u_riot.riot_ram[57],reference.u_l62.u_riot.riot_ram[56],reference.u_l62.u_riot.riot_ram[55],reference.u_l62.u_riot.riot_ram[54],reference.u_l62.u_riot.riot_ram[53],reference.u_l62.u_riot.riot_ram[52],reference.u_l62.u_riot.riot_ram[51],reference.u_l62.u_riot.riot_ram[50],reference.u_l62.u_riot.riot_ram[49],reference.u_l62.u_riot.riot_ram[48],reference.u_l62.u_riot.riot_ram[47],reference.u_l62.u_riot.riot_ram[46],reference.u_l62.u_riot.riot_ram[45],reference.u_l62.u_riot.riot_ram[44],reference.u_l62.u_riot.riot_ram[43],reference.u_l62.u_riot.riot_ram[42],reference.u_l62.u_riot.riot_ram[41],reference.u_l62.u_riot.riot_ram[40],reference.u_l62.u_riot.riot_ram[39],reference.u_l62.u_riot.riot_ram[38],reference.u_l62.u_riot.riot_ram[37],reference.u_l62.u_riot.riot_ram[36],reference.u_l62.u_riot.riot_ram[35],reference.u_l62.u_riot.riot_ram[34],reference.u_l62.u_riot.riot_ram[33],reference.u_l62.u_riot.riot_ram[32],reference.u_l62.u_riot.riot_ram[31],reference.u_l62.u_riot.riot_ram[30],reference.u_l62.u_riot.riot_ram[29],reference.u_l62.u_riot.riot_ram[28],reference.u_l62.u_riot.riot_ram[27],reference.u_l62.u_riot.riot_ram[26],reference.u_l62.u_riot.riot_ram[25],reference.u_l62.u_riot.riot_ram[24],reference.u_l62.u_riot.riot_ram[23],reference.u_l62.u_riot.riot_ram[22],reference.u_l62.u_riot.riot_ram[21],reference.u_l62.u_riot.riot_ram[20],reference.u_l62.u_riot.riot_ram[19],reference.u_l62.u_riot.riot_ram[18],reference.u_l62.u_riot.riot_ram[17],reference.u_l62.u_riot.riot_ram[16],reference.u_l62.u_riot.riot_ram[15],reference.u_l62.u_riot.riot_ram[14],reference.u_l62.u_riot.riot_ram[13],reference.u_l62.u_riot.riot_ram[12],reference.u_l62.u_riot.riot_ram[11],reference.u_l62.u_riot.riot_ram[10],reference.u_l62.u_riot.riot_ram[9],reference.u_l62.u_riot.riot_ram[8],reference.u_l62.u_riot.riot_ram[7],reference.u_l62.u_riot.riot_ram[6],reference.u_l62.u_riot.riot_ram[5],reference.u_l62.u_riot.riot_ram[4],reference.u_l62.u_riot.riot_ram[3],reference.u_l62.u_riot.riot_ram[2],reference.u_l62.u_riot.riot_ram[1],reference.u_l62.u_riot.riot_ram[0]};
assign reference_state[7589+:1]=reference.u_l62.u_riot.rollover;
assign reference_state[7590+:8]=reference.u_l62.u_riot.timer;
assign reference_probe[0+:8]=reference.snapshot_sram_0.memory.mem[0+(probe_index%1024)];
assign reference_probe[8+:8]=reference.snapshot_sram_1.memory.mem[0+(probe_index%1024)];
assign reference_probe[16+:8]=reference.snapshot_sram_2.memory.mem[0+(probe_index%1024)];
assign reference_probe[24+:8]=reference.snapshot_sram_3.memory.mem[0+(probe_index%1024)];
wire [31:0] dut_baseboard_debug;
wire dut_ACPI_0__drv;
wire dut_ACPI_1__drv;
wire dut_ACPI_2__drv;
wire dut_ACPI_3__drv;
wire dut_ACPI_4__drv;
wire dut_ACPIGnd_0__drv;
wire dut_ACPIGnd_1__drv;
wire dut_ACPIGnd_2__drv;
wire dut_ACPIGnd_3__drv;
wire dut_ACPIGnd_4__drv;
wire dut_BootMC_p___drv;
wire dut_BootNO__drv;
wire dut_CLK_OutBase_p___drv;
wire dut_CLK_ca_p___drv;
wire dut_CLK_cb_p___drv;
wire dut_CLK_disk_p___drv;
wire dut_CLK_display_p___drv;
wire dut_CLK_ifu_p___drv;
wire dut_CLK_io20_p___drv;
wire dut_CLK_io21_p___drv;
wire dut_CLK_io22_p___drv;
wire dut_CLK_io23_p___drv;
wire dut_CLK_io24_p___drv;
wire dut_CLK_mc_p___drv;
wire dut_CLK_md_p___drv;
wire dut_CLK_ms0Even_p___drv;
wire dut_CLK_ms0Odd_p___drv;
wire dut_CLK_ms1Even_p___drv;
wire dut_CLK_ms1Odd_p___drv;
wire dut_CLK_ms2Even_p___drv;
wire dut_CLK_ms2Odd_p___drv;
wire dut_CLK_ms3Even_p___drv;
wire dut_CLK_ms3Odd_p___drv;
wire dut_CLK_mx_p___drv;
wire dut_CLK_ph_p___drv;
wire dut_CLK_pl_p___drv;
wire dut_CPAddr_0_p___drv;
wire dut_CPAddr_1_p___drv;
wire dut_CPAddr_2_p___drv;
wire dut_CPOut_0__drv;
wire dut_CPOut_1__drv;
wire dut_CPOut_2__drv;
wire dut_CPOut_3__drv;
wire dut_CPOut_4__drv;
wire dut_CPOut_5__drv;
wire dut_CPOut_6__drv;
wire dut_CPOut_7__drv;
wire dut_CPOut_8__drv;
wire dut_CPStrb_p___drv;
wire dut_DMuxClk__drv;
wire dut_DMuxData__drv;
wire dut_IOReset__drv;
wire dut_KeyboardData__drv;
wire dut_Pendulum__drv;
wire dut_RfshPeriod__drv;
wire dut_Sequence0_p___drv;
wire dut_SetRun__drv;
wire dut_SetRunRfsh__drv;
wire dut_SetSS_p___drv;
wire dut_SkipWait_p___drv;
wire dut_StartClockPulse__drv;
wire dut_TTLIOReset_p___drv;
wire dut_TempRef__drv;
wire dut_TurnOff2v__drv;
wire dut_TurnOnDisk_p___drv;
wire dut_TurnOnLED_p___drv;
wire dut_TurnOnPwr_p___drv;
wire dut_UseDMD__drv;
dorado_serial_BaseBd #(.SYSPER(4)) dut(
.sys_clk(clk),
.baseboard_boot_n(stimulus[0]),
.ACPABus_0_p_(stimulus[1]),
.ACPABus_1_p_(stimulus[2]),
.ACPABus_2_p_(stimulus[3]),
.ACPBus_0_p_(stimulus[4]),
.ACPBus_1_p_(stimulus[5]),
.ACPBus_2_p_(stimulus[6]),
.ACPBus_3_p_(stimulus[7]),
.ACPBus_4_p_(stimulus[8]),
.ACPBus_5_p_(stimulus[9]),
.ACPBus_6_p_(stimulus[10]),
.ACPBus_7_p_(stimulus[11]),
.ACPBus_8_p_(stimulus[12]),
.ACPGnd_00(stimulus[13]),
.ACPGnd_01(stimulus[14]),
.ACPGnd_02(stimulus[15]),
.ACPGnd_03(stimulus[16]),
.ACPGnd_04(stimulus[17]),
.ACPGnd_05(stimulus[18]),
.ACPGnd_06(stimulus[19]),
.ACPGnd_07(stimulus[20]),
.ACPGnd_08(stimulus[21]),
.ACPGnd_09(stimulus[22]),
.ACPGnd_10(stimulus[23]),
.ACPGnd_11(stimulus[24]),
.ACPGnd_12(stimulus[25]),
.ACPStrb_p_(stimulus[26]),
.BootMC_p_(stimulus[27] | dut_BootMC_p___drv),
.CBTempSense(stimulus[28]),
.CICC__m_SS(stimulus[29]),
.CICC_EOS(stimulus[30]),
.CIDD__m_SS(stimulus[31]),
.CIDD_EOS(stimulus[32]),
.CIEE__m_SS(stimulus[33]),
.CIEE_EOS(stimulus[34]),
.CITT__pl_SS(stimulus[35]),
.CITT_EOS(stimulus[36]),
.CLK_InBase(stimulus[37]),
.CPIn_0(stimulus[38]),
.CPIn_1(stimulus[39]),
.CPIn_2(stimulus[40]),
.CPIn_3(stimulus[41]),
.Collision(stimulus[42]),
.DMuxClk(stimulus[43] | dut_DMuxClk__drv),
.DMuxData(stimulus[44] | dut_DMuxData__drv),
.DiskOnRet(stimulus[45]),
.LEDOnRet(stimulus[46]),
.OISData(stimulus[47]),
.OISData_p_(stimulus[48]),
.PwrOnRet(stimulus[49]),
.RcvData(stimulus[50]),
.Sequence0_p_(stimulus[51] | dut_Sequence0_p___drv),
.Serial_1(stimulus[52]),
.Serial_10(stimulus[53]),
.Serial_100(stimulus[54]),
.Serial_2(stimulus[55]),
.Serial_20(stimulus[56]),
.Serial_200(stimulus[57]),
.Serial_4(stimulus[58]),
.Serial_40(stimulus[59]),
.TTLIOReset_p_(stimulus[60] | dut_TTLIOReset_p___drv),
.UseDMD(stimulus[61] | dut_UseDMD__drv),
.XmtData_p_(stimulus[62]),
.dStartClockPulse(stimulus[63]),
.baseboard_debug(dut_baseboard_debug),
.ACPI_0__drv(dut_ACPI_0__drv),
.ACPI_1__drv(dut_ACPI_1__drv),
.ACPI_2__drv(dut_ACPI_2__drv),
.ACPI_3__drv(dut_ACPI_3__drv),
.ACPI_4__drv(dut_ACPI_4__drv),
.ACPIGnd_0__drv(dut_ACPIGnd_0__drv),
.ACPIGnd_1__drv(dut_ACPIGnd_1__drv),
.ACPIGnd_2__drv(dut_ACPIGnd_2__drv),
.ACPIGnd_3__drv(dut_ACPIGnd_3__drv),
.ACPIGnd_4__drv(dut_ACPIGnd_4__drv),
.BootMC_p___drv(dut_BootMC_p___drv),
.BootNO__drv(dut_BootNO__drv),
.CLK_OutBase_p___drv(dut_CLK_OutBase_p___drv),
.CLK_ca_p___drv(dut_CLK_ca_p___drv),
.CLK_cb_p___drv(dut_CLK_cb_p___drv),
.CLK_disk_p___drv(dut_CLK_disk_p___drv),
.CLK_display_p___drv(dut_CLK_display_p___drv),
.CLK_ifu_p___drv(dut_CLK_ifu_p___drv),
.CLK_io20_p___drv(dut_CLK_io20_p___drv),
.CLK_io21_p___drv(dut_CLK_io21_p___drv),
.CLK_io22_p___drv(dut_CLK_io22_p___drv),
.CLK_io23_p___drv(dut_CLK_io23_p___drv),
.CLK_io24_p___drv(dut_CLK_io24_p___drv),
.CLK_mc_p___drv(dut_CLK_mc_p___drv),
.CLK_md_p___drv(dut_CLK_md_p___drv),
.CLK_ms0Even_p___drv(dut_CLK_ms0Even_p___drv),
.CLK_ms0Odd_p___drv(dut_CLK_ms0Odd_p___drv),
.CLK_ms1Even_p___drv(dut_CLK_ms1Even_p___drv),
.CLK_ms1Odd_p___drv(dut_CLK_ms1Odd_p___drv),
.CLK_ms2Even_p___drv(dut_CLK_ms2Even_p___drv),
.CLK_ms2Odd_p___drv(dut_CLK_ms2Odd_p___drv),
.CLK_ms3Even_p___drv(dut_CLK_ms3Even_p___drv),
.CLK_ms3Odd_p___drv(dut_CLK_ms3Odd_p___drv),
.CLK_mx_p___drv(dut_CLK_mx_p___drv),
.CLK_ph_p___drv(dut_CLK_ph_p___drv),
.CLK_pl_p___drv(dut_CLK_pl_p___drv),
.CPAddr_0_p___drv(dut_CPAddr_0_p___drv),
.CPAddr_1_p___drv(dut_CPAddr_1_p___drv),
.CPAddr_2_p___drv(dut_CPAddr_2_p___drv),
.CPOut_0__drv(dut_CPOut_0__drv),
.CPOut_1__drv(dut_CPOut_1__drv),
.CPOut_2__drv(dut_CPOut_2__drv),
.CPOut_3__drv(dut_CPOut_3__drv),
.CPOut_4__drv(dut_CPOut_4__drv),
.CPOut_5__drv(dut_CPOut_5__drv),
.CPOut_6__drv(dut_CPOut_6__drv),
.CPOut_7__drv(dut_CPOut_7__drv),
.CPOut_8__drv(dut_CPOut_8__drv),
.CPStrb_p___drv(dut_CPStrb_p___drv),
.DMuxClk__drv(dut_DMuxClk__drv),
.DMuxData__drv(dut_DMuxData__drv),
.IOReset__drv(dut_IOReset__drv),
.KeyboardData__drv(dut_KeyboardData__drv),
.Pendulum__drv(dut_Pendulum__drv),
.RfshPeriod__drv(dut_RfshPeriod__drv),
.Sequence0_p___drv(dut_Sequence0_p___drv),
.SetRun__drv(dut_SetRun__drv),
.SetRunRfsh__drv(dut_SetRunRfsh__drv),
.SetSS_p___drv(dut_SetSS_p___drv),
.SkipWait_p___drv(dut_SkipWait_p___drv),
.StartClockPulse__drv(dut_StartClockPulse__drv),
.TTLIOReset_p___drv(dut_TTLIOReset_p___drv),
.TempRef__drv(dut_TempRef__drv),
.TurnOff2v__drv(dut_TurnOff2v__drv),
.TurnOnDisk_p___drv(dut_TurnOnDisk_p___drv),
.TurnOnLED_p___drv(dut_TurnOnLED_p___drv),
.TurnOnPwr_p___drv(dut_TurnOnPwr_p___drv),
.UseDMD__drv(dut_UseDMD__drv),
.state_host_clk(clk),
.state_guest_advance(advance),
.state_freeze(freeze),
.state_guest_held(held),
.state_system_reset(system_reset),
.state_request(request),
.state_write(write),
.state_index(index[16:0]),
.state_data(data),
.state_frozen(dut_frozen),
.state_done(dut_done),
.state_error(dut_error),
.state_result(dut_result),
.state_scan_hold_required(dut_hold),
.state_scan_fault(dut_fault),
.state_global_hold(global_hold),
.state_global_abort(global_abort)
);
assign dut_outputs={dut_UseDMD__drv,dut_TurnOnPwr_p___drv,dut_TurnOnLED_p___drv,dut_TurnOnDisk_p___drv,dut_TurnOff2v__drv,dut_TempRef__drv,dut_TTLIOReset_p___drv,dut_StartClockPulse__drv,dut_SkipWait_p___drv,dut_SetSS_p___drv,dut_SetRunRfsh__drv,dut_SetRun__drv,dut_Sequence0_p___drv,dut_RfshPeriod__drv,dut_Pendulum__drv,dut_KeyboardData__drv,dut_IOReset__drv,dut_DMuxData__drv,dut_DMuxClk__drv,dut_CPStrb_p___drv,dut_CPOut_8__drv,dut_CPOut_7__drv,dut_CPOut_6__drv,dut_CPOut_5__drv,dut_CPOut_4__drv,dut_CPOut_3__drv,dut_CPOut_2__drv,dut_CPOut_1__drv,dut_CPOut_0__drv,dut_CPAddr_2_p___drv,dut_CPAddr_1_p___drv,dut_CPAddr_0_p___drv,dut_CLK_pl_p___drv,dut_CLK_ph_p___drv,dut_CLK_mx_p___drv,dut_CLK_ms3Odd_p___drv,dut_CLK_ms3Even_p___drv,dut_CLK_ms2Odd_p___drv,dut_CLK_ms2Even_p___drv,dut_CLK_ms1Odd_p___drv,dut_CLK_ms1Even_p___drv,dut_CLK_ms0Odd_p___drv,dut_CLK_ms0Even_p___drv,dut_CLK_md_p___drv,dut_CLK_mc_p___drv,dut_CLK_io24_p___drv,dut_CLK_io23_p___drv,dut_CLK_io22_p___drv,dut_CLK_io21_p___drv,dut_CLK_io20_p___drv,dut_CLK_ifu_p___drv,dut_CLK_display_p___drv,dut_CLK_disk_p___drv,dut_CLK_cb_p___drv,dut_CLK_ca_p___drv,dut_CLK_OutBase_p___drv,dut_BootNO__drv,dut_BootMC_p___drv,dut_ACPIGnd_4__drv,dut_ACPIGnd_3__drv,dut_ACPIGnd_2__drv,dut_ACPIGnd_1__drv,dut_ACPIGnd_0__drv,dut_ACPI_4__drv,dut_ACPI_3__drv,dut_ACPI_2__drv,dut_ACPI_1__drv,dut_ACPI_0__drv,dut_baseboard_debug};
assign dut_state[0+:8]=dut.snapshot_sram_0.memory.saved_q;
assign dut_state[8+:8]=dut.snapshot_sram_1.memory.saved_q;
assign dut_state[16+:8]=dut.snapshot_sram_2.memory.saved_q;
assign dut_state[24+:8]=dut.snapshot_sram_3.memory.saved_q;
assign dut_state[32+:1]=dut.u_a01.ck_d;
assign dut_state[33+:6]=dut.u_a01.d_pre;
assign dut_state[39+:6]=dut.u_a01.q;
assign dut_state[45+:1]=dut.u_b02.cin_pre;
assign dut_state[46+:1]=dut.u_b02.ck_d;
assign dut_state[47+:4]=dut.u_b02.d_pre;
assign dut_state[51+:4]=dut.u_b02.q;
assign dut_state[55+:1]=dut.u_b02.sd_pre;
assign dut_state[56+:1]=dut.u_b02.su_pre;
assign dut_state[57+:8]=dut.u_b60.d;
assign dut_state[65+:1]=dut.u_b60.en_q;
assign dut_state[66+:8]=dut.u_b61.d;
assign dut_state[74+:1]=dut.u_b61.en_q;
assign dut_state[75+:8]=dut.u_c20.q;
assign dut_state[83+:8]=dut.u_c60.d;
assign dut_state[91+:1]=dut.u_c60.en_q;
assign dut_state[92+:8]=dut.u_c61.d;
assign dut_state[100+:1]=dut.u_c61.en_q;
assign dut_state[101+:1]=dut.u_c62.phase_d;
assign dut_state[102+:8]=dut.u_c62.u_riot.d_out;
assign dut_state[110+:8]=dut.u_c62.u_riot.dir_a;
assign dut_state[118+:8]=dut.u_c62.u_riot.dir_b;
assign dut_state[126+:1]=dut.u_c62.u_riot.edge_detect;
assign dut_state[127+:2]=dut.u_c62.u_riot.incr;
assign dut_state[129+:8]=dut.u_c62.u_riot.interrupt;
assign dut_state[137+:2]=dut.u_c62.u_riot.irq_en;
assign dut_state[139+:1]=dut.u_c62.u_riot.old_pa7;
assign dut_state[140+:8]=dut.u_c62.u_riot.out_a;
assign dut_state[148+:8]=dut.u_c62.u_riot.out_b;
assign dut_state[156+:10]=dut.u_c62.u_riot.prescaler;
assign dut_state[166+:1024]={dut.u_c62.u_riot.riot_ram[127],dut.u_c62.u_riot.riot_ram[126],dut.u_c62.u_riot.riot_ram[125],dut.u_c62.u_riot.riot_ram[124],dut.u_c62.u_riot.riot_ram[123],dut.u_c62.u_riot.riot_ram[122],dut.u_c62.u_riot.riot_ram[121],dut.u_c62.u_riot.riot_ram[120],dut.u_c62.u_riot.riot_ram[119],dut.u_c62.u_riot.riot_ram[118],dut.u_c62.u_riot.riot_ram[117],dut.u_c62.u_riot.riot_ram[116],dut.u_c62.u_riot.riot_ram[115],dut.u_c62.u_riot.riot_ram[114],dut.u_c62.u_riot.riot_ram[113],dut.u_c62.u_riot.riot_ram[112],dut.u_c62.u_riot.riot_ram[111],dut.u_c62.u_riot.riot_ram[110],dut.u_c62.u_riot.riot_ram[109],dut.u_c62.u_riot.riot_ram[108],dut.u_c62.u_riot.riot_ram[107],dut.u_c62.u_riot.riot_ram[106],dut.u_c62.u_riot.riot_ram[105],dut.u_c62.u_riot.riot_ram[104],dut.u_c62.u_riot.riot_ram[103],dut.u_c62.u_riot.riot_ram[102],dut.u_c62.u_riot.riot_ram[101],dut.u_c62.u_riot.riot_ram[100],dut.u_c62.u_riot.riot_ram[99],dut.u_c62.u_riot.riot_ram[98],dut.u_c62.u_riot.riot_ram[97],dut.u_c62.u_riot.riot_ram[96],dut.u_c62.u_riot.riot_ram[95],dut.u_c62.u_riot.riot_ram[94],dut.u_c62.u_riot.riot_ram[93],dut.u_c62.u_riot.riot_ram[92],dut.u_c62.u_riot.riot_ram[91],dut.u_c62.u_riot.riot_ram[90],dut.u_c62.u_riot.riot_ram[89],dut.u_c62.u_riot.riot_ram[88],dut.u_c62.u_riot.riot_ram[87],dut.u_c62.u_riot.riot_ram[86],dut.u_c62.u_riot.riot_ram[85],dut.u_c62.u_riot.riot_ram[84],dut.u_c62.u_riot.riot_ram[83],dut.u_c62.u_riot.riot_ram[82],dut.u_c62.u_riot.riot_ram[81],dut.u_c62.u_riot.riot_ram[80],dut.u_c62.u_riot.riot_ram[79],dut.u_c62.u_riot.riot_ram[78],dut.u_c62.u_riot.riot_ram[77],dut.u_c62.u_riot.riot_ram[76],dut.u_c62.u_riot.riot_ram[75],dut.u_c62.u_riot.riot_ram[74],dut.u_c62.u_riot.riot_ram[73],dut.u_c62.u_riot.riot_ram[72],dut.u_c62.u_riot.riot_ram[71],dut.u_c62.u_riot.riot_ram[70],dut.u_c62.u_riot.riot_ram[69],dut.u_c62.u_riot.riot_ram[68],dut.u_c62.u_riot.riot_ram[67],dut.u_c62.u_riot.riot_ram[66],dut.u_c62.u_riot.riot_ram[65],dut.u_c62.u_riot.riot_ram[64],dut.u_c62.u_riot.riot_ram[63],dut.u_c62.u_riot.riot_ram[62],dut.u_c62.u_riot.riot_ram[61],dut.u_c62.u_riot.riot_ram[60],dut.u_c62.u_riot.riot_ram[59],dut.u_c62.u_riot.riot_ram[58],dut.u_c62.u_riot.riot_ram[57],dut.u_c62.u_riot.riot_ram[56],dut.u_c62.u_riot.riot_ram[55],dut.u_c62.u_riot.riot_ram[54],dut.u_c62.u_riot.riot_ram[53],dut.u_c62.u_riot.riot_ram[52],dut.u_c62.u_riot.riot_ram[51],dut.u_c62.u_riot.riot_ram[50],dut.u_c62.u_riot.riot_ram[49],dut.u_c62.u_riot.riot_ram[48],dut.u_c62.u_riot.riot_ram[47],dut.u_c62.u_riot.riot_ram[46],dut.u_c62.u_riot.riot_ram[45],dut.u_c62.u_riot.riot_ram[44],dut.u_c62.u_riot.riot_ram[43],dut.u_c62.u_riot.riot_ram[42],dut.u_c62.u_riot.riot_ram[41],dut.u_c62.u_riot.riot_ram[40],dut.u_c62.u_riot.riot_ram[39],dut.u_c62.u_riot.riot_ram[38],dut.u_c62.u_riot.riot_ram[37],dut.u_c62.u_riot.riot_ram[36],dut.u_c62.u_riot.riot_ram[35],dut.u_c62.u_riot.riot_ram[34],dut.u_c62.u_riot.riot_ram[33],dut.u_c62.u_riot.riot_ram[32],dut.u_c62.u_riot.riot_ram[31],dut.u_c62.u_riot.riot_ram[30],dut.u_c62.u_riot.riot_ram[29],dut.u_c62.u_riot.riot_ram[28],dut.u_c62.u_riot.riot_ram[27],dut.u_c62.u_riot.riot_ram[26],dut.u_c62.u_riot.riot_ram[25],dut.u_c62.u_riot.riot_ram[24],dut.u_c62.u_riot.riot_ram[23],dut.u_c62.u_riot.riot_ram[22],dut.u_c62.u_riot.riot_ram[21],dut.u_c62.u_riot.riot_ram[20],dut.u_c62.u_riot.riot_ram[19],dut.u_c62.u_riot.riot_ram[18],dut.u_c62.u_riot.riot_ram[17],dut.u_c62.u_riot.riot_ram[16],dut.u_c62.u_riot.riot_ram[15],dut.u_c62.u_riot.riot_ram[14],dut.u_c62.u_riot.riot_ram[13],dut.u_c62.u_riot.riot_ram[12],dut.u_c62.u_riot.riot_ram[11],dut.u_c62.u_riot.riot_ram[10],dut.u_c62.u_riot.riot_ram[9],dut.u_c62.u_riot.riot_ram[8],dut.u_c62.u_riot.riot_ram[7],dut.u_c62.u_riot.riot_ram[6],dut.u_c62.u_riot.riot_ram[5],dut.u_c62.u_riot.riot_ram[4],dut.u_c62.u_riot.riot_ram[3],dut.u_c62.u_riot.riot_ram[2],dut.u_c62.u_riot.riot_ram[1],dut.u_c62.u_riot.riot_ram[0]};
assign dut_state[1190+:1]=dut.u_c62.u_riot.rollover;
assign dut_state[1191+:8]=dut.u_c62.u_riot.timer;
assign dut_state[1199+:2]=dut.u_clockgen.phase;
assign dut_state[1201+:3]=dut.u_d08.osc_div;
assign dut_state[1204+:1]=dut.u_e07.ck_d;
assign dut_state[1205+:4]=dut.u_e07.q;
assign dut_state[1209+:8]=dut.u_e60.d;
assign dut_state[1217+:1]=dut.u_e60.en_q;
assign dut_state[1218+:1]=dut.u_f19.ck_d;
assign dut_state[1219+:6]=dut.u_f19.d_pre;
assign dut_state[1225+:6]=dut.u_f19.q;
assign dut_state[1231+:1]=dut.u_f20.ck_d;
assign dut_state[1232+:6]=dut.u_f20.d_pre;
assign dut_state[1238+:6]=dut.u_f20.q;
assign dut_state[1244+:8]=dut.u_f60.d;
assign dut_state[1252+:1]=dut.u_f60.en_q;
assign dut_state[1253+:1725]=dut.u_f61.u_cpu.q;
assign dut_state[2978+:1]=dut.u_f62.phase_d;
assign dut_state[2979+:8]=dut.u_f62.u_riot.d_out;
assign dut_state[2987+:8]=dut.u_f62.u_riot.dir_a;
assign dut_state[2995+:8]=dut.u_f62.u_riot.dir_b;
assign dut_state[3003+:1]=dut.u_f62.u_riot.edge_detect;
assign dut_state[3004+:2]=dut.u_f62.u_riot.incr;
assign dut_state[3006+:8]=dut.u_f62.u_riot.interrupt;
assign dut_state[3014+:2]=dut.u_f62.u_riot.irq_en;
assign dut_state[3016+:1]=dut.u_f62.u_riot.old_pa7;
assign dut_state[3017+:8]=dut.u_f62.u_riot.out_a;
assign dut_state[3025+:8]=dut.u_f62.u_riot.out_b;
assign dut_state[3033+:10]=dut.u_f62.u_riot.prescaler;
assign dut_state[3043+:1024]={dut.u_f62.u_riot.riot_ram[127],dut.u_f62.u_riot.riot_ram[126],dut.u_f62.u_riot.riot_ram[125],dut.u_f62.u_riot.riot_ram[124],dut.u_f62.u_riot.riot_ram[123],dut.u_f62.u_riot.riot_ram[122],dut.u_f62.u_riot.riot_ram[121],dut.u_f62.u_riot.riot_ram[120],dut.u_f62.u_riot.riot_ram[119],dut.u_f62.u_riot.riot_ram[118],dut.u_f62.u_riot.riot_ram[117],dut.u_f62.u_riot.riot_ram[116],dut.u_f62.u_riot.riot_ram[115],dut.u_f62.u_riot.riot_ram[114],dut.u_f62.u_riot.riot_ram[113],dut.u_f62.u_riot.riot_ram[112],dut.u_f62.u_riot.riot_ram[111],dut.u_f62.u_riot.riot_ram[110],dut.u_f62.u_riot.riot_ram[109],dut.u_f62.u_riot.riot_ram[108],dut.u_f62.u_riot.riot_ram[107],dut.u_f62.u_riot.riot_ram[106],dut.u_f62.u_riot.riot_ram[105],dut.u_f62.u_riot.riot_ram[104],dut.u_f62.u_riot.riot_ram[103],dut.u_f62.u_riot.riot_ram[102],dut.u_f62.u_riot.riot_ram[101],dut.u_f62.u_riot.riot_ram[100],dut.u_f62.u_riot.riot_ram[99],dut.u_f62.u_riot.riot_ram[98],dut.u_f62.u_riot.riot_ram[97],dut.u_f62.u_riot.riot_ram[96],dut.u_f62.u_riot.riot_ram[95],dut.u_f62.u_riot.riot_ram[94],dut.u_f62.u_riot.riot_ram[93],dut.u_f62.u_riot.riot_ram[92],dut.u_f62.u_riot.riot_ram[91],dut.u_f62.u_riot.riot_ram[90],dut.u_f62.u_riot.riot_ram[89],dut.u_f62.u_riot.riot_ram[88],dut.u_f62.u_riot.riot_ram[87],dut.u_f62.u_riot.riot_ram[86],dut.u_f62.u_riot.riot_ram[85],dut.u_f62.u_riot.riot_ram[84],dut.u_f62.u_riot.riot_ram[83],dut.u_f62.u_riot.riot_ram[82],dut.u_f62.u_riot.riot_ram[81],dut.u_f62.u_riot.riot_ram[80],dut.u_f62.u_riot.riot_ram[79],dut.u_f62.u_riot.riot_ram[78],dut.u_f62.u_riot.riot_ram[77],dut.u_f62.u_riot.riot_ram[76],dut.u_f62.u_riot.riot_ram[75],dut.u_f62.u_riot.riot_ram[74],dut.u_f62.u_riot.riot_ram[73],dut.u_f62.u_riot.riot_ram[72],dut.u_f62.u_riot.riot_ram[71],dut.u_f62.u_riot.riot_ram[70],dut.u_f62.u_riot.riot_ram[69],dut.u_f62.u_riot.riot_ram[68],dut.u_f62.u_riot.riot_ram[67],dut.u_f62.u_riot.riot_ram[66],dut.u_f62.u_riot.riot_ram[65],dut.u_f62.u_riot.riot_ram[64],dut.u_f62.u_riot.riot_ram[63],dut.u_f62.u_riot.riot_ram[62],dut.u_f62.u_riot.riot_ram[61],dut.u_f62.u_riot.riot_ram[60],dut.u_f62.u_riot.riot_ram[59],dut.u_f62.u_riot.riot_ram[58],dut.u_f62.u_riot.riot_ram[57],dut.u_f62.u_riot.riot_ram[56],dut.u_f62.u_riot.riot_ram[55],dut.u_f62.u_riot.riot_ram[54],dut.u_f62.u_riot.riot_ram[53],dut.u_f62.u_riot.riot_ram[52],dut.u_f62.u_riot.riot_ram[51],dut.u_f62.u_riot.riot_ram[50],dut.u_f62.u_riot.riot_ram[49],dut.u_f62.u_riot.riot_ram[48],dut.u_f62.u_riot.riot_ram[47],dut.u_f62.u_riot.riot_ram[46],dut.u_f62.u_riot.riot_ram[45],dut.u_f62.u_riot.riot_ram[44],dut.u_f62.u_riot.riot_ram[43],dut.u_f62.u_riot.riot_ram[42],dut.u_f62.u_riot.riot_ram[41],dut.u_f62.u_riot.riot_ram[40],dut.u_f62.u_riot.riot_ram[39],dut.u_f62.u_riot.riot_ram[38],dut.u_f62.u_riot.riot_ram[37],dut.u_f62.u_riot.riot_ram[36],dut.u_f62.u_riot.riot_ram[35],dut.u_f62.u_riot.riot_ram[34],dut.u_f62.u_riot.riot_ram[33],dut.u_f62.u_riot.riot_ram[32],dut.u_f62.u_riot.riot_ram[31],dut.u_f62.u_riot.riot_ram[30],dut.u_f62.u_riot.riot_ram[29],dut.u_f62.u_riot.riot_ram[28],dut.u_f62.u_riot.riot_ram[27],dut.u_f62.u_riot.riot_ram[26],dut.u_f62.u_riot.riot_ram[25],dut.u_f62.u_riot.riot_ram[24],dut.u_f62.u_riot.riot_ram[23],dut.u_f62.u_riot.riot_ram[22],dut.u_f62.u_riot.riot_ram[21],dut.u_f62.u_riot.riot_ram[20],dut.u_f62.u_riot.riot_ram[19],dut.u_f62.u_riot.riot_ram[18],dut.u_f62.u_riot.riot_ram[17],dut.u_f62.u_riot.riot_ram[16],dut.u_f62.u_riot.riot_ram[15],dut.u_f62.u_riot.riot_ram[14],dut.u_f62.u_riot.riot_ram[13],dut.u_f62.u_riot.riot_ram[12],dut.u_f62.u_riot.riot_ram[11],dut.u_f62.u_riot.riot_ram[10],dut.u_f62.u_riot.riot_ram[9],dut.u_f62.u_riot.riot_ram[8],dut.u_f62.u_riot.riot_ram[7],dut.u_f62.u_riot.riot_ram[6],dut.u_f62.u_riot.riot_ram[5],dut.u_f62.u_riot.riot_ram[4],dut.u_f62.u_riot.riot_ram[3],dut.u_f62.u_riot.riot_ram[2],dut.u_f62.u_riot.riot_ram[1],dut.u_f62.u_riot.riot_ram[0]};
assign dut_state[4067+:1]=dut.u_f62.u_riot.rollover;
assign dut_state[4068+:8]=dut.u_f62.u_riot.timer;
assign dut_state[4076+:1]=dut.u_f63.phase_d;
assign dut_state[4077+:8]=dut.u_f63.u_riot.d_out;
assign dut_state[4085+:8]=dut.u_f63.u_riot.dir_a;
assign dut_state[4093+:8]=dut.u_f63.u_riot.dir_b;
assign dut_state[4101+:1]=dut.u_f63.u_riot.edge_detect;
assign dut_state[4102+:2]=dut.u_f63.u_riot.incr;
assign dut_state[4104+:8]=dut.u_f63.u_riot.interrupt;
assign dut_state[4112+:2]=dut.u_f63.u_riot.irq_en;
assign dut_state[4114+:1]=dut.u_f63.u_riot.old_pa7;
assign dut_state[4115+:8]=dut.u_f63.u_riot.out_a;
assign dut_state[4123+:8]=dut.u_f63.u_riot.out_b;
assign dut_state[4131+:10]=dut.u_f63.u_riot.prescaler;
assign dut_state[4141+:1024]={dut.u_f63.u_riot.riot_ram[127],dut.u_f63.u_riot.riot_ram[126],dut.u_f63.u_riot.riot_ram[125],dut.u_f63.u_riot.riot_ram[124],dut.u_f63.u_riot.riot_ram[123],dut.u_f63.u_riot.riot_ram[122],dut.u_f63.u_riot.riot_ram[121],dut.u_f63.u_riot.riot_ram[120],dut.u_f63.u_riot.riot_ram[119],dut.u_f63.u_riot.riot_ram[118],dut.u_f63.u_riot.riot_ram[117],dut.u_f63.u_riot.riot_ram[116],dut.u_f63.u_riot.riot_ram[115],dut.u_f63.u_riot.riot_ram[114],dut.u_f63.u_riot.riot_ram[113],dut.u_f63.u_riot.riot_ram[112],dut.u_f63.u_riot.riot_ram[111],dut.u_f63.u_riot.riot_ram[110],dut.u_f63.u_riot.riot_ram[109],dut.u_f63.u_riot.riot_ram[108],dut.u_f63.u_riot.riot_ram[107],dut.u_f63.u_riot.riot_ram[106],dut.u_f63.u_riot.riot_ram[105],dut.u_f63.u_riot.riot_ram[104],dut.u_f63.u_riot.riot_ram[103],dut.u_f63.u_riot.riot_ram[102],dut.u_f63.u_riot.riot_ram[101],dut.u_f63.u_riot.riot_ram[100],dut.u_f63.u_riot.riot_ram[99],dut.u_f63.u_riot.riot_ram[98],dut.u_f63.u_riot.riot_ram[97],dut.u_f63.u_riot.riot_ram[96],dut.u_f63.u_riot.riot_ram[95],dut.u_f63.u_riot.riot_ram[94],dut.u_f63.u_riot.riot_ram[93],dut.u_f63.u_riot.riot_ram[92],dut.u_f63.u_riot.riot_ram[91],dut.u_f63.u_riot.riot_ram[90],dut.u_f63.u_riot.riot_ram[89],dut.u_f63.u_riot.riot_ram[88],dut.u_f63.u_riot.riot_ram[87],dut.u_f63.u_riot.riot_ram[86],dut.u_f63.u_riot.riot_ram[85],dut.u_f63.u_riot.riot_ram[84],dut.u_f63.u_riot.riot_ram[83],dut.u_f63.u_riot.riot_ram[82],dut.u_f63.u_riot.riot_ram[81],dut.u_f63.u_riot.riot_ram[80],dut.u_f63.u_riot.riot_ram[79],dut.u_f63.u_riot.riot_ram[78],dut.u_f63.u_riot.riot_ram[77],dut.u_f63.u_riot.riot_ram[76],dut.u_f63.u_riot.riot_ram[75],dut.u_f63.u_riot.riot_ram[74],dut.u_f63.u_riot.riot_ram[73],dut.u_f63.u_riot.riot_ram[72],dut.u_f63.u_riot.riot_ram[71],dut.u_f63.u_riot.riot_ram[70],dut.u_f63.u_riot.riot_ram[69],dut.u_f63.u_riot.riot_ram[68],dut.u_f63.u_riot.riot_ram[67],dut.u_f63.u_riot.riot_ram[66],dut.u_f63.u_riot.riot_ram[65],dut.u_f63.u_riot.riot_ram[64],dut.u_f63.u_riot.riot_ram[63],dut.u_f63.u_riot.riot_ram[62],dut.u_f63.u_riot.riot_ram[61],dut.u_f63.u_riot.riot_ram[60],dut.u_f63.u_riot.riot_ram[59],dut.u_f63.u_riot.riot_ram[58],dut.u_f63.u_riot.riot_ram[57],dut.u_f63.u_riot.riot_ram[56],dut.u_f63.u_riot.riot_ram[55],dut.u_f63.u_riot.riot_ram[54],dut.u_f63.u_riot.riot_ram[53],dut.u_f63.u_riot.riot_ram[52],dut.u_f63.u_riot.riot_ram[51],dut.u_f63.u_riot.riot_ram[50],dut.u_f63.u_riot.riot_ram[49],dut.u_f63.u_riot.riot_ram[48],dut.u_f63.u_riot.riot_ram[47],dut.u_f63.u_riot.riot_ram[46],dut.u_f63.u_riot.riot_ram[45],dut.u_f63.u_riot.riot_ram[44],dut.u_f63.u_riot.riot_ram[43],dut.u_f63.u_riot.riot_ram[42],dut.u_f63.u_riot.riot_ram[41],dut.u_f63.u_riot.riot_ram[40],dut.u_f63.u_riot.riot_ram[39],dut.u_f63.u_riot.riot_ram[38],dut.u_f63.u_riot.riot_ram[37],dut.u_f63.u_riot.riot_ram[36],dut.u_f63.u_riot.riot_ram[35],dut.u_f63.u_riot.riot_ram[34],dut.u_f63.u_riot.riot_ram[33],dut.u_f63.u_riot.riot_ram[32],dut.u_f63.u_riot.riot_ram[31],dut.u_f63.u_riot.riot_ram[30],dut.u_f63.u_riot.riot_ram[29],dut.u_f63.u_riot.riot_ram[28],dut.u_f63.u_riot.riot_ram[27],dut.u_f63.u_riot.riot_ram[26],dut.u_f63.u_riot.riot_ram[25],dut.u_f63.u_riot.riot_ram[24],dut.u_f63.u_riot.riot_ram[23],dut.u_f63.u_riot.riot_ram[22],dut.u_f63.u_riot.riot_ram[21],dut.u_f63.u_riot.riot_ram[20],dut.u_f63.u_riot.riot_ram[19],dut.u_f63.u_riot.riot_ram[18],dut.u_f63.u_riot.riot_ram[17],dut.u_f63.u_riot.riot_ram[16],dut.u_f63.u_riot.riot_ram[15],dut.u_f63.u_riot.riot_ram[14],dut.u_f63.u_riot.riot_ram[13],dut.u_f63.u_riot.riot_ram[12],dut.u_f63.u_riot.riot_ram[11],dut.u_f63.u_riot.riot_ram[10],dut.u_f63.u_riot.riot_ram[9],dut.u_f63.u_riot.riot_ram[8],dut.u_f63.u_riot.riot_ram[7],dut.u_f63.u_riot.riot_ram[6],dut.u_f63.u_riot.riot_ram[5],dut.u_f63.u_riot.riot_ram[4],dut.u_f63.u_riot.riot_ram[3],dut.u_f63.u_riot.riot_ram[2],dut.u_f63.u_riot.riot_ram[1],dut.u_f63.u_riot.riot_ram[0]};
assign dut_state[5165+:1]=dut.u_f63.u_riot.rollover;
assign dut_state[5166+:8]=dut.u_f63.u_riot.timer;
assign dut_state[5174+:1]=dut.u_g03.ck_d;
assign dut_state[5175+:1]=dut.u_g03.q;
assign dut_state[5176+:1]=dut.u_g04.ck_d;
assign dut_state[5177+:1]=dut.u_g04.q;
assign dut_state[5178+:1]=dut.u_g07.ck_d;
assign dut_state[5179+:2]=dut.u_g07.q;
assign dut_state[5181+:1]=dut.u_g08.cka_d;
assign dut_state[5182+:1]=dut.u_g08.ckb_d;
assign dut_state[5183+:1]=dut.u_g08.qa;
assign dut_state[5184+:1]=dut.u_g08.qb;
assign dut_state[5185+:1]=dut.u_g20.ck_d;
assign dut_state[5186+:6]=dut.u_g20.d_pre;
assign dut_state[5192+:6]=dut.u_g20.q;
assign dut_state[5198+:1]=dut.u_g21.ck_d;
assign dut_state[5199+:24]=dut.u_g21.cnt;
assign dut_state[5223+:1]=dut.u_g22.cka_d;
assign dut_state[5224+:1]=dut.u_g22.ckb_d;
assign dut_state[5225+:1]=dut.u_g22.qa;
assign dut_state[5226+:1]=dut.u_g22.qb;
assign dut_state[5227+:1]=dut.u_h03.ck_d;
assign dut_state[5228+:1]=dut.u_h03.q;
assign dut_state[5229+:1]=dut.u_h04.ck_d;
assign dut_state[5230+:1]=dut.u_h04.q;
assign dut_state[5231+:16]=dut.u_h06.por;
assign dut_state[5247+:2]=dut.u_h06.vco;
assign dut_state[5249+:1]=dut.u_h20.ck_d;
assign dut_state[5250+:6]=dut.u_h20.d_pre;
assign dut_state[5256+:6]=dut.u_h20.q;
assign dut_state[5262+:8]=dut.u_h61.d;
assign dut_state[5270+:1]=dut.u_h61.en_q;
assign dut_state[5271+:8]=dut.u_i61.d;
assign dut_state[5279+:1]=dut.u_i61.en_q;
assign dut_state[5280+:1]=dut.u_i62.phase_d;
assign dut_state[5281+:8]=dut.u_i62.u_riot.d_out;
assign dut_state[5289+:8]=dut.u_i62.u_riot.dir_a;
assign dut_state[5297+:8]=dut.u_i62.u_riot.dir_b;
assign dut_state[5305+:1]=dut.u_i62.u_riot.edge_detect;
assign dut_state[5306+:2]=dut.u_i62.u_riot.incr;
assign dut_state[5308+:8]=dut.u_i62.u_riot.interrupt;
assign dut_state[5316+:2]=dut.u_i62.u_riot.irq_en;
assign dut_state[5318+:1]=dut.u_i62.u_riot.old_pa7;
assign dut_state[5319+:8]=dut.u_i62.u_riot.out_a;
assign dut_state[5327+:8]=dut.u_i62.u_riot.out_b;
assign dut_state[5335+:10]=dut.u_i62.u_riot.prescaler;
assign dut_state[5345+:1024]={dut.u_i62.u_riot.riot_ram[127],dut.u_i62.u_riot.riot_ram[126],dut.u_i62.u_riot.riot_ram[125],dut.u_i62.u_riot.riot_ram[124],dut.u_i62.u_riot.riot_ram[123],dut.u_i62.u_riot.riot_ram[122],dut.u_i62.u_riot.riot_ram[121],dut.u_i62.u_riot.riot_ram[120],dut.u_i62.u_riot.riot_ram[119],dut.u_i62.u_riot.riot_ram[118],dut.u_i62.u_riot.riot_ram[117],dut.u_i62.u_riot.riot_ram[116],dut.u_i62.u_riot.riot_ram[115],dut.u_i62.u_riot.riot_ram[114],dut.u_i62.u_riot.riot_ram[113],dut.u_i62.u_riot.riot_ram[112],dut.u_i62.u_riot.riot_ram[111],dut.u_i62.u_riot.riot_ram[110],dut.u_i62.u_riot.riot_ram[109],dut.u_i62.u_riot.riot_ram[108],dut.u_i62.u_riot.riot_ram[107],dut.u_i62.u_riot.riot_ram[106],dut.u_i62.u_riot.riot_ram[105],dut.u_i62.u_riot.riot_ram[104],dut.u_i62.u_riot.riot_ram[103],dut.u_i62.u_riot.riot_ram[102],dut.u_i62.u_riot.riot_ram[101],dut.u_i62.u_riot.riot_ram[100],dut.u_i62.u_riot.riot_ram[99],dut.u_i62.u_riot.riot_ram[98],dut.u_i62.u_riot.riot_ram[97],dut.u_i62.u_riot.riot_ram[96],dut.u_i62.u_riot.riot_ram[95],dut.u_i62.u_riot.riot_ram[94],dut.u_i62.u_riot.riot_ram[93],dut.u_i62.u_riot.riot_ram[92],dut.u_i62.u_riot.riot_ram[91],dut.u_i62.u_riot.riot_ram[90],dut.u_i62.u_riot.riot_ram[89],dut.u_i62.u_riot.riot_ram[88],dut.u_i62.u_riot.riot_ram[87],dut.u_i62.u_riot.riot_ram[86],dut.u_i62.u_riot.riot_ram[85],dut.u_i62.u_riot.riot_ram[84],dut.u_i62.u_riot.riot_ram[83],dut.u_i62.u_riot.riot_ram[82],dut.u_i62.u_riot.riot_ram[81],dut.u_i62.u_riot.riot_ram[80],dut.u_i62.u_riot.riot_ram[79],dut.u_i62.u_riot.riot_ram[78],dut.u_i62.u_riot.riot_ram[77],dut.u_i62.u_riot.riot_ram[76],dut.u_i62.u_riot.riot_ram[75],dut.u_i62.u_riot.riot_ram[74],dut.u_i62.u_riot.riot_ram[73],dut.u_i62.u_riot.riot_ram[72],dut.u_i62.u_riot.riot_ram[71],dut.u_i62.u_riot.riot_ram[70],dut.u_i62.u_riot.riot_ram[69],dut.u_i62.u_riot.riot_ram[68],dut.u_i62.u_riot.riot_ram[67],dut.u_i62.u_riot.riot_ram[66],dut.u_i62.u_riot.riot_ram[65],dut.u_i62.u_riot.riot_ram[64],dut.u_i62.u_riot.riot_ram[63],dut.u_i62.u_riot.riot_ram[62],dut.u_i62.u_riot.riot_ram[61],dut.u_i62.u_riot.riot_ram[60],dut.u_i62.u_riot.riot_ram[59],dut.u_i62.u_riot.riot_ram[58],dut.u_i62.u_riot.riot_ram[57],dut.u_i62.u_riot.riot_ram[56],dut.u_i62.u_riot.riot_ram[55],dut.u_i62.u_riot.riot_ram[54],dut.u_i62.u_riot.riot_ram[53],dut.u_i62.u_riot.riot_ram[52],dut.u_i62.u_riot.riot_ram[51],dut.u_i62.u_riot.riot_ram[50],dut.u_i62.u_riot.riot_ram[49],dut.u_i62.u_riot.riot_ram[48],dut.u_i62.u_riot.riot_ram[47],dut.u_i62.u_riot.riot_ram[46],dut.u_i62.u_riot.riot_ram[45],dut.u_i62.u_riot.riot_ram[44],dut.u_i62.u_riot.riot_ram[43],dut.u_i62.u_riot.riot_ram[42],dut.u_i62.u_riot.riot_ram[41],dut.u_i62.u_riot.riot_ram[40],dut.u_i62.u_riot.riot_ram[39],dut.u_i62.u_riot.riot_ram[38],dut.u_i62.u_riot.riot_ram[37],dut.u_i62.u_riot.riot_ram[36],dut.u_i62.u_riot.riot_ram[35],dut.u_i62.u_riot.riot_ram[34],dut.u_i62.u_riot.riot_ram[33],dut.u_i62.u_riot.riot_ram[32],dut.u_i62.u_riot.riot_ram[31],dut.u_i62.u_riot.riot_ram[30],dut.u_i62.u_riot.riot_ram[29],dut.u_i62.u_riot.riot_ram[28],dut.u_i62.u_riot.riot_ram[27],dut.u_i62.u_riot.riot_ram[26],dut.u_i62.u_riot.riot_ram[25],dut.u_i62.u_riot.riot_ram[24],dut.u_i62.u_riot.riot_ram[23],dut.u_i62.u_riot.riot_ram[22],dut.u_i62.u_riot.riot_ram[21],dut.u_i62.u_riot.riot_ram[20],dut.u_i62.u_riot.riot_ram[19],dut.u_i62.u_riot.riot_ram[18],dut.u_i62.u_riot.riot_ram[17],dut.u_i62.u_riot.riot_ram[16],dut.u_i62.u_riot.riot_ram[15],dut.u_i62.u_riot.riot_ram[14],dut.u_i62.u_riot.riot_ram[13],dut.u_i62.u_riot.riot_ram[12],dut.u_i62.u_riot.riot_ram[11],dut.u_i62.u_riot.riot_ram[10],dut.u_i62.u_riot.riot_ram[9],dut.u_i62.u_riot.riot_ram[8],dut.u_i62.u_riot.riot_ram[7],dut.u_i62.u_riot.riot_ram[6],dut.u_i62.u_riot.riot_ram[5],dut.u_i62.u_riot.riot_ram[4],dut.u_i62.u_riot.riot_ram[3],dut.u_i62.u_riot.riot_ram[2],dut.u_i62.u_riot.riot_ram[1],dut.u_i62.u_riot.riot_ram[0]};
assign dut_state[6369+:1]=dut.u_i62.u_riot.rollover;
assign dut_state[6370+:8]=dut.u_i62.u_riot.timer;
assign dut_state[6378+:1]=dut.u_j08.cka_d;
assign dut_state[6379+:1]=dut.u_j08.ckb_d;
assign dut_state[6380+:1]=dut.u_j08.qa;
assign dut_state[6381+:1]=dut.u_j08.qb;
assign dut_state[6382+:1]=dut.u_k02.cin_pre;
assign dut_state[6383+:1]=dut.u_k02.ck_d;
assign dut_state[6384+:4]=dut.u_k02.d_pre;
assign dut_state[6388+:4]=dut.u_k02.q;
assign dut_state[6392+:1]=dut.u_k02.sd_pre;
assign dut_state[6393+:1]=dut.u_k02.su_pre;
assign dut_state[6394+:1]=dut.u_k03.cin_pre;
assign dut_state[6395+:1]=dut.u_k03.ck_d;
assign dut_state[6396+:4]=dut.u_k03.d_pre;
assign dut_state[6400+:4]=dut.u_k03.q;
assign dut_state[6404+:1]=dut.u_k03.sd_pre;
assign dut_state[6405+:1]=dut.u_k03.su_pre;
assign dut_state[6406+:1]=dut.u_k07.ck_d;
assign dut_state[6407+:6]=dut.u_k07.d_pre;
assign dut_state[6413+:6]=dut.u_k07.q;
assign dut_state[6419+:1]=dut.u_k08.ck_d;
assign dut_state[6420+:6]=dut.u_k08.d_pre;
assign dut_state[6426+:6]=dut.u_k08.q;
assign dut_state[6432+:1]=dut.u_k09.ck_d;
assign dut_state[6433+:6]=dut.u_k09.d_pre;
assign dut_state[6439+:6]=dut.u_k09.q;
assign dut_state[6445+:1]=dut.u_l07.ck_d;
assign dut_state[6446+:6]=dut.u_l07.d_pre;
assign dut_state[6452+:6]=dut.u_l07.q;
assign dut_state[6458+:1]=dut.u_l08.ck_d;
assign dut_state[6459+:6]=dut.u_l08.d_pre;
assign dut_state[6465+:6]=dut.u_l08.q;
assign dut_state[6471+:1]=dut.u_l18.ck_d;
assign dut_state[6472+:2]=dut.u_l18.q;
assign dut_state[6474+:1]=dut.u_l21.ck_d;
assign dut_state[6475+:6]=dut.u_l21.d_pre;
assign dut_state[6481+:6]=dut.u_l21.q;
assign dut_state[6487+:1]=dut.u_l22.ck_d;
assign dut_state[6488+:6]=dut.u_l22.d_pre;
assign dut_state[6494+:6]=dut.u_l22.q;
assign dut_state[6500+:1]=dut.u_l62.phase_d;
assign dut_state[6501+:8]=dut.u_l62.u_riot.d_out;
assign dut_state[6509+:8]=dut.u_l62.u_riot.dir_a;
assign dut_state[6517+:8]=dut.u_l62.u_riot.dir_b;
assign dut_state[6525+:1]=dut.u_l62.u_riot.edge_detect;
assign dut_state[6526+:2]=dut.u_l62.u_riot.incr;
assign dut_state[6528+:8]=dut.u_l62.u_riot.interrupt;
assign dut_state[6536+:2]=dut.u_l62.u_riot.irq_en;
assign dut_state[6538+:1]=dut.u_l62.u_riot.old_pa7;
assign dut_state[6539+:8]=dut.u_l62.u_riot.out_a;
assign dut_state[6547+:8]=dut.u_l62.u_riot.out_b;
assign dut_state[6555+:10]=dut.u_l62.u_riot.prescaler;
assign dut_state[6565+:1024]={dut.u_l62.u_riot.riot_ram[127],dut.u_l62.u_riot.riot_ram[126],dut.u_l62.u_riot.riot_ram[125],dut.u_l62.u_riot.riot_ram[124],dut.u_l62.u_riot.riot_ram[123],dut.u_l62.u_riot.riot_ram[122],dut.u_l62.u_riot.riot_ram[121],dut.u_l62.u_riot.riot_ram[120],dut.u_l62.u_riot.riot_ram[119],dut.u_l62.u_riot.riot_ram[118],dut.u_l62.u_riot.riot_ram[117],dut.u_l62.u_riot.riot_ram[116],dut.u_l62.u_riot.riot_ram[115],dut.u_l62.u_riot.riot_ram[114],dut.u_l62.u_riot.riot_ram[113],dut.u_l62.u_riot.riot_ram[112],dut.u_l62.u_riot.riot_ram[111],dut.u_l62.u_riot.riot_ram[110],dut.u_l62.u_riot.riot_ram[109],dut.u_l62.u_riot.riot_ram[108],dut.u_l62.u_riot.riot_ram[107],dut.u_l62.u_riot.riot_ram[106],dut.u_l62.u_riot.riot_ram[105],dut.u_l62.u_riot.riot_ram[104],dut.u_l62.u_riot.riot_ram[103],dut.u_l62.u_riot.riot_ram[102],dut.u_l62.u_riot.riot_ram[101],dut.u_l62.u_riot.riot_ram[100],dut.u_l62.u_riot.riot_ram[99],dut.u_l62.u_riot.riot_ram[98],dut.u_l62.u_riot.riot_ram[97],dut.u_l62.u_riot.riot_ram[96],dut.u_l62.u_riot.riot_ram[95],dut.u_l62.u_riot.riot_ram[94],dut.u_l62.u_riot.riot_ram[93],dut.u_l62.u_riot.riot_ram[92],dut.u_l62.u_riot.riot_ram[91],dut.u_l62.u_riot.riot_ram[90],dut.u_l62.u_riot.riot_ram[89],dut.u_l62.u_riot.riot_ram[88],dut.u_l62.u_riot.riot_ram[87],dut.u_l62.u_riot.riot_ram[86],dut.u_l62.u_riot.riot_ram[85],dut.u_l62.u_riot.riot_ram[84],dut.u_l62.u_riot.riot_ram[83],dut.u_l62.u_riot.riot_ram[82],dut.u_l62.u_riot.riot_ram[81],dut.u_l62.u_riot.riot_ram[80],dut.u_l62.u_riot.riot_ram[79],dut.u_l62.u_riot.riot_ram[78],dut.u_l62.u_riot.riot_ram[77],dut.u_l62.u_riot.riot_ram[76],dut.u_l62.u_riot.riot_ram[75],dut.u_l62.u_riot.riot_ram[74],dut.u_l62.u_riot.riot_ram[73],dut.u_l62.u_riot.riot_ram[72],dut.u_l62.u_riot.riot_ram[71],dut.u_l62.u_riot.riot_ram[70],dut.u_l62.u_riot.riot_ram[69],dut.u_l62.u_riot.riot_ram[68],dut.u_l62.u_riot.riot_ram[67],dut.u_l62.u_riot.riot_ram[66],dut.u_l62.u_riot.riot_ram[65],dut.u_l62.u_riot.riot_ram[64],dut.u_l62.u_riot.riot_ram[63],dut.u_l62.u_riot.riot_ram[62],dut.u_l62.u_riot.riot_ram[61],dut.u_l62.u_riot.riot_ram[60],dut.u_l62.u_riot.riot_ram[59],dut.u_l62.u_riot.riot_ram[58],dut.u_l62.u_riot.riot_ram[57],dut.u_l62.u_riot.riot_ram[56],dut.u_l62.u_riot.riot_ram[55],dut.u_l62.u_riot.riot_ram[54],dut.u_l62.u_riot.riot_ram[53],dut.u_l62.u_riot.riot_ram[52],dut.u_l62.u_riot.riot_ram[51],dut.u_l62.u_riot.riot_ram[50],dut.u_l62.u_riot.riot_ram[49],dut.u_l62.u_riot.riot_ram[48],dut.u_l62.u_riot.riot_ram[47],dut.u_l62.u_riot.riot_ram[46],dut.u_l62.u_riot.riot_ram[45],dut.u_l62.u_riot.riot_ram[44],dut.u_l62.u_riot.riot_ram[43],dut.u_l62.u_riot.riot_ram[42],dut.u_l62.u_riot.riot_ram[41],dut.u_l62.u_riot.riot_ram[40],dut.u_l62.u_riot.riot_ram[39],dut.u_l62.u_riot.riot_ram[38],dut.u_l62.u_riot.riot_ram[37],dut.u_l62.u_riot.riot_ram[36],dut.u_l62.u_riot.riot_ram[35],dut.u_l62.u_riot.riot_ram[34],dut.u_l62.u_riot.riot_ram[33],dut.u_l62.u_riot.riot_ram[32],dut.u_l62.u_riot.riot_ram[31],dut.u_l62.u_riot.riot_ram[30],dut.u_l62.u_riot.riot_ram[29],dut.u_l62.u_riot.riot_ram[28],dut.u_l62.u_riot.riot_ram[27],dut.u_l62.u_riot.riot_ram[26],dut.u_l62.u_riot.riot_ram[25],dut.u_l62.u_riot.riot_ram[24],dut.u_l62.u_riot.riot_ram[23],dut.u_l62.u_riot.riot_ram[22],dut.u_l62.u_riot.riot_ram[21],dut.u_l62.u_riot.riot_ram[20],dut.u_l62.u_riot.riot_ram[19],dut.u_l62.u_riot.riot_ram[18],dut.u_l62.u_riot.riot_ram[17],dut.u_l62.u_riot.riot_ram[16],dut.u_l62.u_riot.riot_ram[15],dut.u_l62.u_riot.riot_ram[14],dut.u_l62.u_riot.riot_ram[13],dut.u_l62.u_riot.riot_ram[12],dut.u_l62.u_riot.riot_ram[11],dut.u_l62.u_riot.riot_ram[10],dut.u_l62.u_riot.riot_ram[9],dut.u_l62.u_riot.riot_ram[8],dut.u_l62.u_riot.riot_ram[7],dut.u_l62.u_riot.riot_ram[6],dut.u_l62.u_riot.riot_ram[5],dut.u_l62.u_riot.riot_ram[4],dut.u_l62.u_riot.riot_ram[3],dut.u_l62.u_riot.riot_ram[2],dut.u_l62.u_riot.riot_ram[1],dut.u_l62.u_riot.riot_ram[0]};
assign dut_state[7589+:1]=dut.u_l62.u_riot.rollover;
assign dut_state[7590+:8]=dut.u_l62.u_riot.timer;
assign dut_probe[0+:8]=dut.snapshot_sram_0.memory.mem[0+(probe_index%1024)];
assign dut_probe[8+:8]=dut.snapshot_sram_1.memory.mem[0+(probe_index%1024)];
assign dut_probe[16+:8]=dut.snapshot_sram_2.memory.mem[0+(probe_index%1024)];
assign dut_probe[24+:8]=dut.snapshot_sram_3.memory.mem[0+(probe_index%1024)];
assign all_helpers_frozen=&{dut.snapshot_sram_0.memory.frozen,dut.snapshot_sram_1.memory.frozen,dut.snapshot_sram_2.memory.frozen,dut.snapshot_sram_3.memory.frozen,dut.u_b60.state_frozen,dut.u_b61.state_frozen,dut.u_c60.state_frozen,dut.u_c61.state_frozen,dut.u_c62.phase_frozen,dut.u_c62.u_riot.state_frozen,dut.u_e60.state_frozen,dut.u_f60.state_frozen,dut.u_f62.phase_frozen,dut.u_f62.u_riot.state_frozen,dut.u_f63.phase_frozen,dut.u_f63.u_riot.state_frozen,dut.u_h61.state_frozen,dut.u_i61.state_frozen,dut.u_i62.phase_frozen,dut.u_i62.u_riot.state_frozen,dut.u_l62.phase_frozen,dut.u_l62.u_riot.state_frozen};
endmodule
