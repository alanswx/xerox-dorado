module snapshot_fit(
 input wire host_clk,input wire [4:0] advance,ce_n,we_n,freeze,held,request,write,
 input wire [49:0] address,input wire [89:0] data,state_data,
 input wire [54:0] word_index,output reg [89:0] q,result,
 output reg [4:0] frozen,done,error);
 // Matched negative-edge launch/capture,50MHz/10ns internal paths in both
 // variants. Independent bank pins prevent artificial cross-width sharing.

 reg [63:0] launch_0;
 always @(negedge host_clk)launch_0<=
  {advance[0],address[0+:10],data[0+:18],ce_n[0],we_n[0],
    freeze[0],held[0],request[0],write[0],word_index[0+:11],state_data[0+:18]};
 wire step_0,ce_0,we_0,freeze_0,held_0,request_0,write_0;
 wire [9:0] address_0;wire [17:0] data_0,state_0;wire [10:0] word_0;
 assign {step_0,address_0,data_0,ce_0,we_0,freeze_0,held_0,request_0,write_0,word_0,state_0}=launch_0;
 wire [0:0] q_0;wire [17:0] result_0;wire frozen_0,done_0,error_0;
 always @(negedge host_clk)
  {q[0+:18],frozen[0],done[0],error[0],result[0+:18]}<=
  {{17{1'b0}},q_0,frozen_0,done_0,error_0,result_0};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_word_bank #(.WIDTH(1)) bank_0(
  .host_clk(host_clk),.guest_advance(step_0),.address(address_0),.data(data_0[0:0]),
  .ce_n(ce_0),.we_n(we_0),.q(q_0),.freeze(freeze_0),.guest_held(held_0),.frozen(frozen_0),
  .request(request_0),.write(write_0),.word_index(word_0),.state_data(state_0),
  .done(done_0),.error(error_0),.result(result_0));
`else
 assign frozen_0=0;assign done_0=0;assign error_0=0;assign result_0=0;
 genvar b_0;
 generate for(b_0=0;b_0<1;b_0=b_0+1)begin:original_0
  cell_F10415A bit_cell(host_clk,address_0[9],address_0[8],address_0[7],address_0[6],
   address_0[5],address_0[4],address_0[3],address_0[2],address_0[1],address_0[0],
   data_0[b_0],ce_0,we_0,q_0[b_0]);
 end endgenerate
`endif

 reg [63:0] launch_1;
 always @(negedge host_clk)launch_1<=
  {advance[1],address[10+:10],data[18+:18],ce_n[1],we_n[1],
    freeze[1],held[1],request[1],write[1],word_index[11+:11],state_data[18+:18]};
 wire step_1,ce_1,we_1,freeze_1,held_1,request_1,write_1;
 wire [9:0] address_1;wire [17:0] data_1,state_1;wire [10:0] word_1;
 assign {step_1,address_1,data_1,ce_1,we_1,freeze_1,held_1,request_1,write_1,word_1,state_1}=launch_1;
 wire [1:0] q_1;wire [17:0] result_1;wire frozen_1,done_1,error_1;
 always @(negedge host_clk)
  {q[18+:18],frozen[1],done[1],error[1],result[18+:18]}<=
  {{16{1'b0}},q_1,frozen_1,done_1,error_1,result_1};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_word_bank #(.WIDTH(2)) bank_1(
  .host_clk(host_clk),.guest_advance(step_1),.address(address_1),.data(data_1[1:0]),
  .ce_n(ce_1),.we_n(we_1),.q(q_1),.freeze(freeze_1),.guest_held(held_1),.frozen(frozen_1),
  .request(request_1),.write(write_1),.word_index(word_1),.state_data(state_1),
  .done(done_1),.error(error_1),.result(result_1));
`else
 assign frozen_1=0;assign done_1=0;assign error_1=0;assign result_1=0;
 genvar b_1;
 generate for(b_1=0;b_1<2;b_1=b_1+1)begin:original_1
  cell_F10415A bit_cell(host_clk,address_1[9],address_1[8],address_1[7],address_1[6],
   address_1[5],address_1[4],address_1[3],address_1[2],address_1[1],address_1[0],
   data_1[b_1],ce_1,we_1,q_1[b_1]);
 end endgenerate
`endif

 reg [63:0] launch_2;
 always @(negedge host_clk)launch_2<=
  {advance[2],address[20+:10],data[36+:18],ce_n[2],we_n[2],
    freeze[2],held[2],request[2],write[2],word_index[22+:11],state_data[36+:18]};
 wire step_2,ce_2,we_2,freeze_2,held_2,request_2,write_2;
 wire [9:0] address_2;wire [17:0] data_2,state_2;wire [10:0] word_2;
 assign {step_2,address_2,data_2,ce_2,we_2,freeze_2,held_2,request_2,write_2,word_2,state_2}=launch_2;
 wire [3:0] q_2;wire [17:0] result_2;wire frozen_2,done_2,error_2;
 always @(negedge host_clk)
  {q[36+:18],frozen[2],done[2],error[2],result[36+:18]}<=
  {{14{1'b0}},q_2,frozen_2,done_2,error_2,result_2};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_word_bank #(.WIDTH(4)) bank_2(
  .host_clk(host_clk),.guest_advance(step_2),.address(address_2),.data(data_2[3:0]),
  .ce_n(ce_2),.we_n(we_2),.q(q_2),.freeze(freeze_2),.guest_held(held_2),.frozen(frozen_2),
  .request(request_2),.write(write_2),.word_index(word_2),.state_data(state_2),
  .done(done_2),.error(error_2),.result(result_2));
`else
 assign frozen_2=0;assign done_2=0;assign error_2=0;assign result_2=0;
 genvar b_2;
 generate for(b_2=0;b_2<4;b_2=b_2+1)begin:original_2
  cell_F10415A bit_cell(host_clk,address_2[9],address_2[8],address_2[7],address_2[6],
   address_2[5],address_2[4],address_2[3],address_2[2],address_2[1],address_2[0],
   data_2[b_2],ce_2,we_2,q_2[b_2]);
 end endgenerate
`endif

 reg [63:0] launch_3;
 always @(negedge host_clk)launch_3<=
  {advance[3],address[30+:10],data[54+:18],ce_n[3],we_n[3],
    freeze[3],held[3],request[3],write[3],word_index[33+:11],state_data[54+:18]};
 wire step_3,ce_3,we_3,freeze_3,held_3,request_3,write_3;
 wire [9:0] address_3;wire [17:0] data_3,state_3;wire [10:0] word_3;
 assign {step_3,address_3,data_3,ce_3,we_3,freeze_3,held_3,request_3,write_3,word_3,state_3}=launch_3;
 wire [4:0] q_3;wire [17:0] result_3;wire frozen_3,done_3,error_3;
 always @(negedge host_clk)
  {q[54+:18],frozen[3],done[3],error[3],result[54+:18]}<=
  {{13{1'b0}},q_3,frozen_3,done_3,error_3,result_3};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_word_bank #(.WIDTH(5)) bank_3(
  .host_clk(host_clk),.guest_advance(step_3),.address(address_3),.data(data_3[4:0]),
  .ce_n(ce_3),.we_n(we_3),.q(q_3),.freeze(freeze_3),.guest_held(held_3),.frozen(frozen_3),
  .request(request_3),.write(write_3),.word_index(word_3),.state_data(state_3),
  .done(done_3),.error(error_3),.result(result_3));
`else
 assign frozen_3=0;assign done_3=0;assign error_3=0;assign result_3=0;
 genvar b_3;
 generate for(b_3=0;b_3<5;b_3=b_3+1)begin:original_3
  cell_F10415A bit_cell(host_clk,address_3[9],address_3[8],address_3[7],address_3[6],
   address_3[5],address_3[4],address_3[3],address_3[2],address_3[1],address_3[0],
   data_3[b_3],ce_3,we_3,q_3[b_3]);
 end endgenerate
`endif

 reg [63:0] launch_4;
 always @(negedge host_clk)launch_4<=
  {advance[4],address[40+:10],data[72+:18],ce_n[4],we_n[4],
    freeze[4],held[4],request[4],write[4],word_index[44+:11],state_data[72+:18]};
 wire step_4,ce_4,we_4,freeze_4,held_4,request_4,write_4;
 wire [9:0] address_4;wire [17:0] data_4,state_4;wire [10:0] word_4;
 assign {step_4,address_4,data_4,ce_4,we_4,freeze_4,held_4,request_4,write_4,word_4,state_4}=launch_4;
 wire [17:0] q_4;wire [17:0] result_4;wire frozen_4,done_4,error_4;
 always @(negedge host_clk)
  {q[72+:18],frozen[4],done[4],error[4],result[72+:18]}<=
  {{0{1'b0}},q_4,frozen_4,done_4,error_4,result_4};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10415_word_bank #(.WIDTH(18)) bank_4(
  .host_clk(host_clk),.guest_advance(step_4),.address(address_4),.data(data_4[17:0]),
  .ce_n(ce_4),.we_n(we_4),.q(q_4),.freeze(freeze_4),.guest_held(held_4),.frozen(frozen_4),
  .request(request_4),.write(write_4),.word_index(word_4),.state_data(state_4),
  .done(done_4),.error(error_4),.result(result_4));
`else
 assign frozen_4=0;assign done_4=0;assign error_4=0;assign result_4=0;
 genvar b_4;
 generate for(b_4=0;b_4<18;b_4=b_4+1)begin:original_4
  cell_F10415A bit_cell(host_clk,address_4[9],address_4[8],address_4[7],address_4[6],
   address_4[5],address_4[4],address_4[3],address_4[2],address_4[1],address_4[0],
   data_4[b_4],ce_4,we_4,q_4[b_4]);
 end endgenerate
`endif
endmodule
