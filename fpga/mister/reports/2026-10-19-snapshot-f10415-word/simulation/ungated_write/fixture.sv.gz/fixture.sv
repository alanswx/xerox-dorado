module word_bank_fixture(
 input wire host_clk,ref_clk,advance,freeze,held,request,write,
 input wire [9:0] address,input wire [17:0] data,
 input wire ce_n,we_n,input wire [10:0] word_index,
 input wire [17:0] state_data[10],
 output wire [9:0] frozen,done,error,
 output wire [17:0] q[10],original_q[10],result[10]);
 function integer width_for(input integer n);
  case(n%5)0:width_for=1;1:width_for=2;2:width_for=4;3:width_for=5;default:width_for=18;endcase
 endfunction
 genvar k,b;
 generate for(k=0;k<10;k=k+1)begin:banks
  localparam integer W=width_for(k);
  wire [W-1:0] q_w,original_w;
  if(k<5)begin:connected
   dorado_snapshot_f10415_word_bank #(.WIDTH(W)) candidate(
    .host_clk(host_clk),.guest_advance(advance),.address(address),.data(data[W-1:0]),
    .ce_n(ce_n),.we_n(we_n),.q(q_w),.freeze(freeze),.guest_held(held),.frozen(frozen[k]),
    .request(request),.write(write),.word_index(word_index),.state_data(state_data[k]),
    .done(done[k]),.error(error[k]),.result(result[k]));
   for(b=0;b<W;b=b+1)begin:bits
    cell_F10415A original(ref_clk,address[9],address[8],address[7],address[6],address[5],
      address[4],address[3],address[2],address[1],address[0],data[b],ce_n,we_n,original_w[b]);
   end
  end else begin:omitted
   // Preserve the original IFUM omission in BOTH interfaces. No explicit
   // zero tie-off or four-state/X equivalence is claimed by Verilator.
   dorado_snapshot_f10415_word_bank #(.WIDTH(W)) candidate(
    .host_clk(host_clk),.guest_advance(advance),.address(address),.data(data[W-1:0]),
    .we_n(we_n),.q(q_w),.freeze(freeze),.guest_held(held),.frozen(frozen[k]),
    .request(request),.write(write),.word_index(word_index),.state_data(state_data[k]),
    .done(done[k]),.error(error[k]),.result(result[k]));
   for(b=0;b<W;b=b+1)begin:bits
    cell_F10415A original(.sys_clk(ref_clk),.p2(address[9]),.p3(address[8]),.p4(address[7]),
      .p5(address[6]),.p6(address[5]),.p7(address[4]),.p9(address[3]),.p10(address[2]),
      .p11(address[1]),.p12(address[0]),.p15(data[b]),.p13(we_n),.p1(original_w[b]));
   end
  end
  assign q[k]={{(18-W){1'b0}},q_w};
  assign original_q[k]={{(18-W){1'b0}},original_w};
 end endgenerate
endmodule
