module f10470_word_fixture(
 input wire host_clk,ref_clk,advance,freeze,held,request,write,
 input wire [11:0] address,input wire [17:0] data,
 input wire ce_n,we_n,input wire [12:0] word_index,
 input wire [17:0] state_data[6],output wire [5:0] frozen,done,error,
 output wire [17:0] q[6],original_q[6],result[6]);
 function integer width_for(input integer n);
  case(n)0:width_for=1;1:width_for=3;2:width_for=5;3:width_for=6;4:width_for=9;default:width_for=18;endcase
 endfunction
 genvar k,b;
 generate for(k=0;k<6;k=k+1)begin:banks
  localparam integer W=width_for(k);
  wire [W-1:0] q_w,original_w;
  dorado_snapshot_f10470_word_bank #(.WIDTH(W)) candidate(
    .host_clk(host_clk),.guest_advance(advance),.address(address),.data(data[W-1:0]),
    .ce_n(ce_n),.we_n(we_n),.q(q_w),.freeze(freeze),.guest_held(held),.frozen(frozen[k]),
    .request(request),.write(write),.word_index(word_index),.state_data(state_data[k]),
    .done(done[k]),.error(error[k]),.result(result[k]));
  for(b=0;b<W;b=b+1)begin:bits
    cell_F10470 original(.sys_clk(ref_clk),.p2(address[11]),.p3(address[10]),
      .p4(address[9]),.p5(address[8]),.p6(address[7]),.p7(address[6]),.p8(address[5]),
      .p10(address[4]),.p11(address[3]),.p12(address[2]),.p13(address[1]),.p14(address[0]),
      .p17(data[b]),.p16(ce_n),.p15(we_n),.p1(original_w[b]),.p9(1'b0),.p18(1'b0));
  end
  assign q[k]={{(18-W){1'b0}},q_w};
  assign original_q[k]={{(18-W){1'b0}},original_w};
 end endgenerate
endmodule
