module snapshot_fit(
 input wire host_clk,input wire [5:0] advance,ce_n,we_n,freeze,held,request,write,
 input wire [71:0] address,input wire [107:0] data,state_data,
 input wire [77:0] word_index,output reg [107:0] q,result,
 output reg [5:0] frozen,done,error);
 // Matched negative-edge launch/capture,50MHz/10ns internal paths in both
 // variants. Independent bank pins prevent artificial cross-width sharing.

 reg [67:0] launch_0;
 always @(negedge host_clk)launch_0<=
  {advance[0],address[0+:12],data[0+:18],ce_n[0],we_n[0],
    freeze[0],held[0],request[0],write[0],word_index[0+:13],state_data[0+:18]};
 wire step_0,ce_0,we_0,freeze_0,held_0,request_0,write_0;
 wire [11:0] address_0;wire [17:0] data_0,state_0;wire [12:0] word_0;
 assign {step_0,address_0,data_0,ce_0,we_0,freeze_0,held_0,request_0,write_0,word_0,state_0}=launch_0;
 wire [0:0] q_0;wire [17:0] result_0;wire frozen_0,done_0,error_0;
 always @(negedge host_clk)
  {q[0+:18],frozen[0],done[0],error[0],result[0+:18]}<=
  {{17{1'b0}},q_0,frozen_0,done_0,error_0,result_0};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(1)) bank_0(
  .host_clk(host_clk),.guest_advance(step_0),.address(address_0),.data(data_0[0:0]),
  .ce_n(ce_0),.we_n(we_0),.q(q_0),.freeze(freeze_0),.guest_held(held_0),.frozen(frozen_0),
  .request(request_0),.write(write_0),.word_index(word_0),.state_data(state_0),
  .done(done_0),.error(error_0),.result(result_0));
`else
 assign frozen_0=0;assign done_0=0;assign error_0=0;assign result_0=0;
 genvar b_0;
 generate for(b_0=0;b_0<1;b_0=b_0+1)begin:original_0
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_0[11]),.p3(address_0[10]),
   .p4(address_0[9]),.p5(address_0[8]),.p6(address_0[7]),.p7(address_0[6]),.p8(address_0[5]),
   .p10(address_0[4]),.p11(address_0[3]),.p12(address_0[2]),.p13(address_0[1]),.p14(address_0[0]),
   .p17(data_0[b_0]),.p16(ce_0),.p15(we_0),.p1(q_0[b_0]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif

 reg [67:0] launch_1;
 always @(negedge host_clk)launch_1<=
  {advance[1],address[12+:12],data[18+:18],ce_n[1],we_n[1],
    freeze[1],held[1],request[1],write[1],word_index[13+:13],state_data[18+:18]};
 wire step_1,ce_1,we_1,freeze_1,held_1,request_1,write_1;
 wire [11:0] address_1;wire [17:0] data_1,state_1;wire [12:0] word_1;
 assign {step_1,address_1,data_1,ce_1,we_1,freeze_1,held_1,request_1,write_1,word_1,state_1}=launch_1;
 wire [2:0] q_1;wire [17:0] result_1;wire frozen_1,done_1,error_1;
 always @(negedge host_clk)
  {q[18+:18],frozen[1],done[1],error[1],result[18+:18]}<=
  {{15{1'b0}},q_1,frozen_1,done_1,error_1,result_1};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(3)) bank_1(
  .host_clk(host_clk),.guest_advance(step_1),.address(address_1),.data(data_1[2:0]),
  .ce_n(ce_1),.we_n(we_1),.q(q_1),.freeze(freeze_1),.guest_held(held_1),.frozen(frozen_1),
  .request(request_1),.write(write_1),.word_index(word_1),.state_data(state_1),
  .done(done_1),.error(error_1),.result(result_1));
`else
 assign frozen_1=0;assign done_1=0;assign error_1=0;assign result_1=0;
 genvar b_1;
 generate for(b_1=0;b_1<3;b_1=b_1+1)begin:original_1
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_1[11]),.p3(address_1[10]),
   .p4(address_1[9]),.p5(address_1[8]),.p6(address_1[7]),.p7(address_1[6]),.p8(address_1[5]),
   .p10(address_1[4]),.p11(address_1[3]),.p12(address_1[2]),.p13(address_1[1]),.p14(address_1[0]),
   .p17(data_1[b_1]),.p16(ce_1),.p15(we_1),.p1(q_1[b_1]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif

 reg [67:0] launch_2;
 always @(negedge host_clk)launch_2<=
  {advance[2],address[24+:12],data[36+:18],ce_n[2],we_n[2],
    freeze[2],held[2],request[2],write[2],word_index[26+:13],state_data[36+:18]};
 wire step_2,ce_2,we_2,freeze_2,held_2,request_2,write_2;
 wire [11:0] address_2;wire [17:0] data_2,state_2;wire [12:0] word_2;
 assign {step_2,address_2,data_2,ce_2,we_2,freeze_2,held_2,request_2,write_2,word_2,state_2}=launch_2;
 wire [4:0] q_2;wire [17:0] result_2;wire frozen_2,done_2,error_2;
 always @(negedge host_clk)
  {q[36+:18],frozen[2],done[2],error[2],result[36+:18]}<=
  {{13{1'b0}},q_2,frozen_2,done_2,error_2,result_2};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(5)) bank_2(
  .host_clk(host_clk),.guest_advance(step_2),.address(address_2),.data(data_2[4:0]),
  .ce_n(ce_2),.we_n(we_2),.q(q_2),.freeze(freeze_2),.guest_held(held_2),.frozen(frozen_2),
  .request(request_2),.write(write_2),.word_index(word_2),.state_data(state_2),
  .done(done_2),.error(error_2),.result(result_2));
`else
 assign frozen_2=0;assign done_2=0;assign error_2=0;assign result_2=0;
 genvar b_2;
 generate for(b_2=0;b_2<5;b_2=b_2+1)begin:original_2
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_2[11]),.p3(address_2[10]),
   .p4(address_2[9]),.p5(address_2[8]),.p6(address_2[7]),.p7(address_2[6]),.p8(address_2[5]),
   .p10(address_2[4]),.p11(address_2[3]),.p12(address_2[2]),.p13(address_2[1]),.p14(address_2[0]),
   .p17(data_2[b_2]),.p16(ce_2),.p15(we_2),.p1(q_2[b_2]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif

 reg [67:0] launch_3;
 always @(negedge host_clk)launch_3<=
  {advance[3],address[36+:12],data[54+:18],ce_n[3],we_n[3],
    freeze[3],held[3],request[3],write[3],word_index[39+:13],state_data[54+:18]};
 wire step_3,ce_3,we_3,freeze_3,held_3,request_3,write_3;
 wire [11:0] address_3;wire [17:0] data_3,state_3;wire [12:0] word_3;
 assign {step_3,address_3,data_3,ce_3,we_3,freeze_3,held_3,request_3,write_3,word_3,state_3}=launch_3;
 wire [5:0] q_3;wire [17:0] result_3;wire frozen_3,done_3,error_3;
 always @(negedge host_clk)
  {q[54+:18],frozen[3],done[3],error[3],result[54+:18]}<=
  {{12{1'b0}},q_3,frozen_3,done_3,error_3,result_3};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(6)) bank_3(
  .host_clk(host_clk),.guest_advance(step_3),.address(address_3),.data(data_3[5:0]),
  .ce_n(ce_3),.we_n(we_3),.q(q_3),.freeze(freeze_3),.guest_held(held_3),.frozen(frozen_3),
  .request(request_3),.write(write_3),.word_index(word_3),.state_data(state_3),
  .done(done_3),.error(error_3),.result(result_3));
`else
 assign frozen_3=0;assign done_3=0;assign error_3=0;assign result_3=0;
 genvar b_3;
 generate for(b_3=0;b_3<6;b_3=b_3+1)begin:original_3
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_3[11]),.p3(address_3[10]),
   .p4(address_3[9]),.p5(address_3[8]),.p6(address_3[7]),.p7(address_3[6]),.p8(address_3[5]),
   .p10(address_3[4]),.p11(address_3[3]),.p12(address_3[2]),.p13(address_3[1]),.p14(address_3[0]),
   .p17(data_3[b_3]),.p16(ce_3),.p15(we_3),.p1(q_3[b_3]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif

 reg [67:0] launch_4;
 always @(negedge host_clk)launch_4<=
  {advance[4],address[48+:12],data[72+:18],ce_n[4],we_n[4],
    freeze[4],held[4],request[4],write[4],word_index[52+:13],state_data[72+:18]};
 wire step_4,ce_4,we_4,freeze_4,held_4,request_4,write_4;
 wire [11:0] address_4;wire [17:0] data_4,state_4;wire [12:0] word_4;
 assign {step_4,address_4,data_4,ce_4,we_4,freeze_4,held_4,request_4,write_4,word_4,state_4}=launch_4;
 wire [8:0] q_4;wire [17:0] result_4;wire frozen_4,done_4,error_4;
 always @(negedge host_clk)
  {q[72+:18],frozen[4],done[4],error[4],result[72+:18]}<=
  {{9{1'b0}},q_4,frozen_4,done_4,error_4,result_4};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(9)) bank_4(
  .host_clk(host_clk),.guest_advance(step_4),.address(address_4),.data(data_4[8:0]),
  .ce_n(ce_4),.we_n(we_4),.q(q_4),.freeze(freeze_4),.guest_held(held_4),.frozen(frozen_4),
  .request(request_4),.write(write_4),.word_index(word_4),.state_data(state_4),
  .done(done_4),.error(error_4),.result(result_4));
`else
 assign frozen_4=0;assign done_4=0;assign error_4=0;assign result_4=0;
 genvar b_4;
 generate for(b_4=0;b_4<9;b_4=b_4+1)begin:original_4
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_4[11]),.p3(address_4[10]),
   .p4(address_4[9]),.p5(address_4[8]),.p6(address_4[7]),.p7(address_4[6]),.p8(address_4[5]),
   .p10(address_4[4]),.p11(address_4[3]),.p12(address_4[2]),.p13(address_4[1]),.p14(address_4[0]),
   .p17(data_4[b_4]),.p16(ce_4),.p15(we_4),.p1(q_4[b_4]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif

 reg [67:0] launch_5;
 always @(negedge host_clk)launch_5<=
  {advance[5],address[60+:12],data[90+:18],ce_n[5],we_n[5],
    freeze[5],held[5],request[5],write[5],word_index[65+:13],state_data[90+:18]};
 wire step_5,ce_5,we_5,freeze_5,held_5,request_5,write_5;
 wire [11:0] address_5;wire [17:0] data_5,state_5;wire [12:0] word_5;
 assign {step_5,address_5,data_5,ce_5,we_5,freeze_5,held_5,request_5,write_5,word_5,state_5}=launch_5;
 wire [17:0] q_5;wire [17:0] result_5;wire frozen_5,done_5,error_5;
 always @(negedge host_clk)
  {q[90+:18],frozen[5],done[5],error[5],result[90+:18]}<=
  {{0{1'b0}},q_5,frozen_5,done_5,error_5,result_5};
`ifdef SNAPSHOT_BANK_EXPERIMENT
 dorado_snapshot_f10470_word_bank #(.WIDTH(18)) bank_5(
  .host_clk(host_clk),.guest_advance(step_5),.address(address_5),.data(data_5[17:0]),
  .ce_n(ce_5),.we_n(we_5),.q(q_5),.freeze(freeze_5),.guest_held(held_5),.frozen(frozen_5),
  .request(request_5),.write(write_5),.word_index(word_5),.state_data(state_5),
  .done(done_5),.error(error_5),.result(result_5));
`else
 assign frozen_5=0;assign done_5=0;assign error_5=0;assign result_5=0;
 genvar b_5;
 generate for(b_5=0;b_5<18;b_5=b_5+1)begin:original_5
  cell_F10470 bit_cell(.sys_clk(host_clk),.p2(address_5[11]),.p3(address_5[10]),
   .p4(address_5[9]),.p5(address_5[8]),.p6(address_5[7]),.p7(address_5[6]),.p8(address_5[5]),
   .p10(address_5[4]),.p11(address_5[3]),.p12(address_5[2]),.p13(address_5[1]),.p14(address_5[0]),
   .p17(data_5[b_5]),.p16(ce_5),.p15(we_5),.p1(q_5[b_5]),.p9(1'b0),.p18(1'b0));
 end endgenerate
`endif
endmodule
