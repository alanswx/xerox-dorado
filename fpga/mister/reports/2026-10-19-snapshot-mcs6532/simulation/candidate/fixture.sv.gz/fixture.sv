module mcs6532_fixture(
 input host_clk,ref_clk,advance,freeze,held,request,write,
 input [7:0] index,input [17:0] data,input [37:0] pins,
 output frozen,done,error,output [17:0] result,
 output [1097:0] physical,original_state,output [25:0] outputs,original_outputs);
 cell_MCS6532_snapshot candidate(.state_host_clk(host_clk),.state_advance(advance),
 .state_freeze(freeze),.state_guest_held(held),.state_request(request),.state_write(write),
 .state_index(index),.state_data(data),.state_frozen(frozen),.state_done(done),
 .state_error(error),.state_result(result),.sys_clk(ref_clk),.p39(pins[37]),.p34(pins[1]),.p38(pins[19]),.p37(pins[20]),.p36(pins[18]),.p35(pins[9]),
.p7(pins[2]),.p6(pins[3]),.p5(pins[4]),.p4(pins[5]),.p3(pins[6]),.p2(pins[7]),.p40(pins[8]),
.d_in(pins[17:10]),.pa_in(pins[28:21]),.pb_in(pins[36:29]),
.p33(outputs[0]),.p32(outputs[1]),.p31(outputs[2]),.p30(outputs[3]),.p29(outputs[4]),.p28(outputs[5]),.p27(outputs[6]),.p26(outputs[7]),
.p8(outputs[8]),.p9(outputs[9]),.p10(outputs[10]),.p11(outputs[11]),.p12(outputs[12]),.p13(outputs[13]),.p14(outputs[14]),.p15(outputs[15]),
.p24(outputs[16]),.p23(outputs[17]),.p22(outputs[18]),.p21(outputs[19]),.p19(outputs[20]),.p18(outputs[21]),.p17(outputs[22]),.p16(outputs[23]),
.p25(outputs[24]),.p1(1'b0),.p20(1'b1));
 cell_MCS6532 original(.sys_clk(ref_clk),.p39(pins[37]),.p34(pins[1]),.p38(pins[19]),.p37(pins[20]),.p36(pins[18]),.p35(pins[9]),
.p7(pins[2]),.p6(pins[3]),.p5(pins[4]),.p4(pins[5]),.p3(pins[6]),.p2(pins[7]),.p40(pins[8]),
.d_in(pins[17:10]),.pa_in(pins[28:21]),.pb_in(pins[36:29]),
.p33(original_outputs[0]),.p32(original_outputs[1]),.p31(original_outputs[2]),.p30(original_outputs[3]),.p29(original_outputs[4]),.p28(original_outputs[5]),.p27(original_outputs[6]),.p26(original_outputs[7]),
.p8(original_outputs[8]),.p9(original_outputs[9]),.p10(original_outputs[10]),.p11(original_outputs[11]),.p12(original_outputs[12]),.p13(original_outputs[13]),.p14(original_outputs[14]),.p15(original_outputs[15]),
.p24(original_outputs[16]),.p23(original_outputs[17]),.p22(original_outputs[18]),.p21(original_outputs[19]),.p19(original_outputs[20]),.p18(original_outputs[21]),.p17(original_outputs[22]),.p16(original_outputs[23]),
.p25(original_outputs[24]),.p1(1'b0),.p20(1'b1));
 genvar i;generate for(i=0;i<128;i=i+1)begin:ram
  assign physical[8*i+:8]=candidate.u_riot.riot_ram[i];
  assign original_state[8*i+:8]=original.u_riot.riot_ram[i];
 end endgenerate
 assign physical[1096:1024]={candidate.u_riot.old_pa7,candidate.u_riot.rollover,candidate.u_riot.edge_detect,candidate.u_riot.irq_en,candidate.u_riot.incr,candidate.u_riot.prescaler,candidate.u_riot.timer,candidate.u_riot.interrupt,candidate.u_riot.dir_b,candidate.u_riot.dir_a,candidate.u_riot.out_b,candidate.u_riot.out_a,candidate.u_riot.d_out};
 assign original_state[1096:1024]={original.u_riot.riot_stuff.old_pa7,original.u_riot.rollover,original.u_riot.edge_detect,original.u_riot.irq_en,original.u_riot.incr,original.u_riot.prescaler,original.u_riot.timer,original.u_riot.interrupt,original.u_riot.dir_b,original.u_riot.dir_a,original.u_riot.out_b,original.u_riot.out_a,original.u_riot.d_out};
 assign physical[1097]=candidate.phase_d;assign original_state[1097]=original.phase_d;
 assign outputs[25]=candidate.oe;assign original_outputs[25]=original.oe;
endmodule
