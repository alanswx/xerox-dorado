module snapshot_fit(
 input wire host_clk,advance,freeze,held,request,write,
 input wire [7:0] index,input wire [17:0] data,input wire [37:0] pins,
 output reg [17:0] result,output reg [25:0] outputs,output reg frozen,done,error);
 reg [68:0] input_stage,launch;
 always @(negedge host_clk)input_stage<={advance,freeze,held,request,write,index,data,pins};
 always @(posedge host_clk)launch<=input_stage;
 wire step_r,freeze_r,held_r,request_r,write_r;wire [7:0] index_r;wire [17:0] data_r;wire [37:0] pins_r;
 assign {step_r,freeze_r,held_r,request_r,write_r,index_r,data_r,pins_r}=launch;
 wire [17:0] result_w;wire [25:0] outputs_w;wire frozen_w,done_w,error_w;
 always @(posedge host_clk){result,outputs,frozen,done,error}<={result_w,outputs_w,frozen_w,done_w,error_w};
 assign outputs_w[25]=pins_r[19] && !pins_r[20] && pins_r[9];
`ifdef SNAPSHOT_BANK_EXPERIMENT
 cell_MCS6532_snapshot cell_inst(
 .state_host_clk(host_clk),.state_advance(step_r),.state_freeze(freeze_r),.state_guest_held(held_r),
 .state_request(request_r),.state_write(write_r),.state_index(index_r),.state_data(data_r),
 .state_frozen(frozen_w),.state_done(done_w),.state_error(error_w),.state_result(result_w),
`else
 assign {frozen_w,done_w,error_w,result_w}=21'b0;
 cell_MCS6532 cell_inst(
`endif
 .sys_clk(host_clk),.p39(pins_r[37]),.p34(pins_r[1]),.p38(pins_r[19]),.p37(pins_r[20]),.p36(pins_r[18]),.p35(pins_r[9]),
.p7(pins_r[2]),.p6(pins_r[3]),.p5(pins_r[4]),.p4(pins_r[5]),.p3(pins_r[6]),.p2(pins_r[7]),.p40(pins_r[8]),
.d_in(pins_r[17:10]),.pa_in(pins_r[28:21]),.pb_in(pins_r[36:29]),
.p33(outputs_w[0]),.p32(outputs_w[1]),.p31(outputs_w[2]),.p30(outputs_w[3]),.p29(outputs_w[4]),.p28(outputs_w[5]),.p27(outputs_w[6]),.p26(outputs_w[7]),
.p8(outputs_w[8]),.p9(outputs_w[9]),.p10(outputs_w[10]),.p11(outputs_w[11]),.p12(outputs_w[12]),.p13(outputs_w[13]),.p14(outputs_w[14]),.p15(outputs_w[15]),
.p24(outputs_w[16]),.p23(outputs_w[17]),.p22(outputs_w[18]),.p21(outputs_w[19]),.p19(outputs_w[20]),.p18(outputs_w[21]),.p17(outputs_w[22]),.p16(outputs_w[23]),
.p25(outputs_w[24]),.p1(1'b0),.p20(1'b1));
endmodule
