// VENDORED, WITH A MINIMAL PATCH.
//
// Source: MiSTer-devel/Atari7800_MiSTer rtl/RIOT/M6532.sv (k7800 by Jamie
// Blanks). The Atari 7800 core's RIOT is SystemVerilog; the 2600 core's is
// VHDL, which Verilator cannot take -- hence this one.
//
// *** LICENCE: CC BY-NC 4.0 -- NONCOMMERCIAL. ***
// That is more restrictive than the rest of this repository. See
// verilog/vendor/LICENSES.md before shipping anything that includes it.
//
// PATCH: the output ports assigned inside always blocks are declared
// `output logic` rather than `output wire`. Quartus infers that; Verilator
// follows IEEE 1800 strictly and rejects a procedural assignment to a wire
// (PROCASSWIRE).
// PATCH: the registered read data honors ce, just as writes and timers do.
// ce=1 retains the original PHI2-clocked behavior; a fabric-clock wrapper
// can now preserve that behavior with one enable per PHI2 rising edge.

// k7800 (c) by Jamie Blanks

// k7800 is licensed under a
// Creative Commons Attribution-NonCommercial 4.0 International License.

// You should have received a copy of the license along with this
// work. If not, see http://creativecommons.org/licenses/by-nc/4.0/.


module M6532_snapshot
(
    input state_host_clk,state_advance,state_freeze,state_guest_held,state_request,state_write,
    input [7:0] state_index,input [17:0] state_data,
    output reg state_frozen=1'b0,state_done=1'b0,state_error=1'b0,
    output reg [17:0] state_result,
	input        clk,       // PHI 2
	input        ce,        // Clock enable
	input        res_n,     // reset
	input  [6:0] addr,      // Address
	input        RW_n,      // 1 = read, 0 = write
	input  [7:0] d_in,
	output logic [7:0] d_out,
	input        RS_n,      // RAM select
	output       logic       IRQ_n,
	input        CS1,       // Chip select 1, 1 = selected
	input        CS2_n,     // Chip select 2, 0 = selected
	input  [7:0] PA_in,     // Port ins and outs
	output logic [7:0] PA_out,    // NOTE that port output must be fed back to input
	input  [7:0] PB_in,     // if not altered by a peripheral, in order for
	output logic [7:0] PB_out,    // the chip to read properly!
	output       logic       oe         // Output enabled (always 8 bits)
);

parameter init_7800 = 0;

reg [7:0] riot_ram[128];
reg [7:0] out_a, out_b, data;
reg [7:0] dir_a, dir_b;
reg [7:0] interrupt;
reg [7:0] timer;
reg [9:0] prescaler;

reg [1:0] incr;
logic rollover;
reg [1:0] irq_en;
reg edge_detect;

assign IRQ_n = ~((interrupt[7] & irq_en[1]) | (interrupt[6] & irq_en[0]));

// These wires have a weak pull up, so any undriven wires will be high
assign PA_out = out_a | ~dir_a;
assign PB_out = out_b | ~dir_b;

assign oe = (CS1 & ~CS2_n) && RW_n;

wire pa7 = dir_a[7] ? PA_out[7] : PA_in[7];
wire p1 = incr == 2'd0 || rollover;
wire p8 = ~|prescaler[2:0] && incr == 2'd1;
wire p64 = ~|prescaler[5:0] && incr == 2'd2;
wire p1024 = ~|prescaler[9:0] && incr == 2'd3;
wire tick_inc = p1 || p8 || p64 || p1024;


reg old_pa7;
wire state_hold=state_freeze && state_guest_held;
wire state_accept=state_hold && state_frozen && state_request;
wire state_valid=state_index<8'd133;
always @(posedge state_host_clk)begin
    state_frozen<=state_hold;state_done<=state_accept;state_error<=state_accept && !state_valid;
    if(state_accept)begin
        state_result<=18'b0;
        if(state_valid)begin
            if(!state_index[7])begin
                if(!state_write)state_result<={10'b0,ram_read_data};
            end else case(state_index)
                8'd128:if(state_write){out_b[1:0],out_a[7:0],d_out[7:0]}<=state_data[17:0];else state_result<={out_b[1:0],out_a[7:0],d_out[7:0]};
                8'd129:if(state_write){dir_b[3:0],dir_a[7:0],out_b[7:2]}<=state_data[17:0];else state_result<={dir_b[3:0],dir_a[7:0],out_b[7:2]};
                8'd130:if(state_write){timer[5:0],interrupt[7:0],dir_b[7:4]}<=state_data[17:0];else state_result<={timer[5:0],interrupt[7:0],dir_b[7:4]};
                8'd131:if(state_write){rollover,edge_detect,irq_en[1:0],incr[1:0],prescaler[9:0],timer[7:6]}<=state_data[17:0];else state_result<={rollover,edge_detect,irq_en[1:0],incr[1:0],prescaler[9:0],timer[7:6]};
                8'd132:if(state_write)old_pa7<=state_data[0:0];else state_result<={17'b0,old_pa7};
                default:;
            endcase
        end
    end
    if(!state_hold && state_advance)begin
begin
	// The BaseBoard wrapper oversamples PHI2 on its fabric clock. Reads
	// must obey the same enable as writes/timers, preserving the original
	// PHI2-edge output register rather than updating on every fabric edge.
	if (ce && (CS1 & ~CS2_n) && RW_n) begin
		if (~RS_n) begin // RAM selected
			d_out <= ram_read_data;
		end else if (~addr[2]) begin // Address registers
			case(addr[1:0])
				2'b01: d_out <= dir_a; // DDRA
				2'b11: d_out <= dir_b; // DDRB
				2'b00: d_out <= (PA_in & PA_out); // Input A
				2'b10: d_out <= (PB_in & PB_out); // Input B
			endcase
		end else if (addr[2])begin // Timer & Interrupts
			if (~addr[0])
				d_out <= timer[7:0];
			else
				d_out <= {interrupt[7:6], 6'd0};
		end
	end
	if (~res_n)
		d_out <= 8'hFF;
end

if (~res_n) begin
	// Set to specific value on atari 7800 version, 0 on MOS version


	out_a <= 8'h00;
	out_b <= 8'h00;
	dir_a <= 8'h00;
	dir_b <= 8'h00;
	{interrupt, irq_en, edge_detect} <= '0;
	incr <= 2'b10; // Increment resets to 64
	timer <= 8'hFF;   // Timer resets to FF
	prescaler <= 0;
	rollover <= 0;
end else begin
	
	if (ce) begin : riot_stuff

	
		prescaler <= prescaler + 1'd1;
	
		if (tick_inc)
			timer <= timer - 8'd1;

		if (CS1 & ~CS2_n) begin
			if (~RS_n) begin // RAM selected
				if (~RW_n)
					begin end // RAM write uses the shared port below.
			end else if (~addr[2]) begin // Address registers
				if (~RW_n) begin
					case(addr[1:0])
						2'b01: dir_a <= d_in; // DDRA
						2'b11: dir_b <= d_in; // DDRB
						2'b00: out_a <= d_in; // Output A
						2'b10: out_b <= d_in; // Output B
					endcase
				end
			end else begin // Timer & Interrupts
				if (~RW_n) begin
					if (addr[4])begin
						prescaler <= 10'd0;
						rollover <= 0;
						interrupt[7] <= 0;
						incr <= addr[1:0];
						timer <= d_in;
						irq_en[1] <= addr[3];
					end else begin
						irq_en[0] <= addr[1];
						edge_detect <= addr[0];
					end
				end else begin
					if (~addr[0]) begin
						irq_en[1] <= addr[3];
						rollover <= 0;
						interrupt[7] <= 0;
					end else
						interrupt[6] <= 0;
				end
			end
		end
	
		if (tick_inc && timer == 0) begin
			interrupt[7] <= 1;
			rollover <= 1;
		end
	
		// Edge detection
		old_pa7 <= pa7;
		if ((edge_detect && ~old_pa7 && pa7) || (~edge_detect && old_pa7 && ~pa7))
			interrupt[6] <= 1;
	end
end

    end
end

// Normal and administrative accesses are mutually exclusive at state_hold.
// A single address/data/write-enable port retains read-before-write behavior.
wire ram_normal = !state_hold && state_advance;
wire ram_admin_write = state_accept && state_valid && !state_index[7] && state_write;
wire ram_guest_write = ram_normal && res_n && ce && CS1 && !CS2_n && !RS_n && !RW_n;
wire [6:0] ram_address = state_hold ? state_index[6:0] : addr;
wire [7:0] ram_write_data = state_hold ? state_data[7:0] : d_in;
wire [7:0] ram_read_data = riot_ram[ram_address];
wire ram_reset = !res_n;
wire ram_write = ram_admin_write || ram_guest_write;
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd0] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd0)riot_ram[7'd0] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd1] <= init_7800 ? 8'h00 : 8'h00;
    else if(ram_write && ram_address==7'd1)riot_ram[7'd1] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd2] <= init_7800 ? 8'hAA : 8'h00;
    else if(ram_write && ram_address==7'd2)riot_ram[7'd2] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd3] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd3)riot_ram[7'd3] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd4] <= init_7800 ? 8'h01 : 8'h00;
    else if(ram_write && ram_address==7'd4)riot_ram[7'd4] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd5] <= init_7800 ? 8'h95 : 8'h00;
    else if(ram_write && ram_address==7'd5)riot_ram[7'd5] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd6] <= init_7800 ? 8'h03 : 8'h00;
    else if(ram_write && ram_address==7'd6)riot_ram[7'd6] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd7] <= init_7800 ? 8'hE8 : 8'h00;
    else if(ram_write && ram_address==7'd7)riot_ram[7'd7] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd8] <= init_7800 ? 8'h00 : 8'h00;
    else if(ram_write && ram_address==7'd8)riot_ram[7'd8] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd9] <= init_7800 ? 8'h2A : 8'h00;
    else if(ram_write && ram_address==7'd9)riot_ram[7'd9] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd10] <= init_7800 ? 8'hD0 : 8'h00;
    else if(ram_write && ram_address==7'd10)riot_ram[7'd10] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd11] <= init_7800 ? 8'hF9 : 8'h00;
    else if(ram_write && ram_address==7'd11)riot_ram[7'd11] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd12] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd12)riot_ram[7'd12] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd13] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd13)riot_ram[7'd13] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd14] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd14)riot_ram[7'd14] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd15] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd15)riot_ram[7'd15] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd16] <= init_7800 ? 8'hEA : 8'h00;
    else if(ram_write && ram_address==7'd16)riot_ram[7'd16] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd17] <= init_7800 ? 8'h30 : 8'h00;
    else if(ram_write && ram_address==7'd17)riot_ram[7'd17] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd18] <= init_7800 ? 8'h23 : 8'h00;
    else if(ram_write && ram_address==7'd18)riot_ram[7'd18] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd19] <= init_7800 ? 8'hA2 : 8'h00;
    else if(ram_write && ram_address==7'd19)riot_ram[7'd19] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd20] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd20)riot_ram[7'd20] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd21] <= init_7800 ? 8'hCA : 8'h00;
    else if(ram_write && ram_address==7'd21)riot_ram[7'd21] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd22] <= init_7800 ? 8'h10 : 8'h00;
    else if(ram_write && ram_address==7'd22)riot_ram[7'd22] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd23] <= init_7800 ? 8'hFD : 8'h00;
    else if(ram_write && ram_address==7'd23)riot_ram[7'd23] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd24] <= init_7800 ? 8'h9A : 8'h00;
    else if(ram_write && ram_address==7'd24)riot_ram[7'd24] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd25] <= init_7800 ? 8'h8D : 8'h00;
    else if(ram_write && ram_address==7'd25)riot_ram[7'd25] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd26] <= init_7800 ? 8'h10 : 8'h00;
    else if(ram_write && ram_address==7'd26)riot_ram[7'd26] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd27] <= init_7800 ? 8'h01 : 8'h00;
    else if(ram_write && ram_address==7'd27)riot_ram[7'd27] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd28] <= init_7800 ? 8'h20 : 8'h00;
    else if(ram_write && ram_address==7'd28)riot_ram[7'd28] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd29] <= init_7800 ? 8'hCB : 8'h00;
    else if(ram_write && ram_address==7'd29)riot_ram[7'd29] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd30] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd30)riot_ram[7'd30] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd31] <= init_7800 ? 8'h20 : 8'h00;
    else if(ram_write && ram_address==7'd31)riot_ram[7'd31] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd32] <= init_7800 ? 8'hCB : 8'h00;
    else if(ram_write && ram_address==7'd32)riot_ram[7'd32] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd33] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd33)riot_ram[7'd33] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd34] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd34)riot_ram[7'd34] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd35] <= init_7800 ? 8'h11 : 8'h00;
    else if(ram_write && ram_address==7'd35)riot_ram[7'd35] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd36] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd36)riot_ram[7'd36] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd37] <= init_7800 ? 8'h1B : 8'h00;
    else if(ram_write && ram_address==7'd37)riot_ram[7'd37] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd38] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd38)riot_ram[7'd38] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd39] <= init_7800 ? 8'h1C : 8'h00;
    else if(ram_write && ram_address==7'd39)riot_ram[7'd39] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd40] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd40)riot_ram[7'd40] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd41] <= init_7800 ? 8'h0F : 8'h00;
    else if(ram_write && ram_address==7'd41)riot_ram[7'd41] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd42] <= init_7800 ? 8'hEA : 8'h00;
    else if(ram_write && ram_address==7'd42)riot_ram[7'd42] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd43] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd43)riot_ram[7'd43] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd44] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd44)riot_ram[7'd44] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd45] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd45)riot_ram[7'd45] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd46] <= init_7800 ? 8'h00 : 8'h00;
    else if(ram_write && ram_address==7'd46)riot_ram[7'd46] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd47] <= init_7800 ? 8'hEA : 8'h00;
    else if(ram_write && ram_address==7'd47)riot_ram[7'd47] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd48] <= init_7800 ? 8'h30 : 8'h00;
    else if(ram_write && ram_address==7'd48)riot_ram[7'd48] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd49] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd49)riot_ram[7'd49] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd50] <= init_7800 ? 8'h24 : 8'h00;
    else if(ram_write && ram_address==7'd50)riot_ram[7'd50] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd51] <= init_7800 ? 8'h03 : 8'h00;
    else if(ram_write && ram_address==7'd51)riot_ram[7'd51] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd52] <= init_7800 ? 8'h30 : 8'h00;
    else if(ram_write && ram_address==7'd52)riot_ram[7'd52] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd53] <= init_7800 ? 8'h09 : 8'h00;
    else if(ram_write && ram_address==7'd53)riot_ram[7'd53] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd54] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd54)riot_ram[7'd54] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd55] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd55)riot_ram[7'd55] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd56] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd56)riot_ram[7'd56] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd57] <= init_7800 ? 8'h09 : 8'h00;
    else if(ram_write && ram_address==7'd57)riot_ram[7'd57] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd58] <= init_7800 ? 8'h8D : 8'h00;
    else if(ram_write && ram_address==7'd58)riot_ram[7'd58] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd59] <= init_7800 ? 8'h12 : 8'h00;
    else if(ram_write && ram_address==7'd59)riot_ram[7'd59] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd60] <= init_7800 ? 8'hF1 : 8'h00;
    else if(ram_write && ram_address==7'd60)riot_ram[7'd60] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd61] <= init_7800 ? 8'hD0 : 8'h00;
    else if(ram_write && ram_address==7'd61)riot_ram[7'd61] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd62] <= init_7800 ? 8'h1E : 8'h00;
    else if(ram_write && ram_address==7'd62)riot_ram[7'd62] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd63] <= init_7800 ? 8'h24 : 8'h00;
    else if(ram_write && ram_address==7'd63)riot_ram[7'd63] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd64] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd64)riot_ram[7'd64] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd65] <= init_7800 ? 8'h30 : 8'h00;
    else if(ram_write && ram_address==7'd65)riot_ram[7'd65] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd66] <= init_7800 ? 8'h0C : 8'h00;
    else if(ram_write && ram_address==7'd66)riot_ram[7'd66] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd67] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd67)riot_ram[7'd67] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd68] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd68)riot_ram[7'd68] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd69] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd69)riot_ram[7'd69] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd70] <= init_7800 ? 8'h06 : 8'h00;
    else if(ram_write && ram_address==7'd70)riot_ram[7'd70] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd71] <= init_7800 ? 8'h8D : 8'h00;
    else if(ram_write && ram_address==7'd71)riot_ram[7'd71] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd72] <= init_7800 ? 8'h18 : 8'h00;
    else if(ram_write && ram_address==7'd72)riot_ram[7'd72] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd73] <= init_7800 ? 8'hF1 : 8'h00;
    else if(ram_write && ram_address==7'd73)riot_ram[7'd73] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd74] <= init_7800 ? 8'h8D : 8'h00;
    else if(ram_write && ram_address==7'd74)riot_ram[7'd74] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd75] <= init_7800 ? 8'h60 : 8'h00;
    else if(ram_write && ram_address==7'd75)riot_ram[7'd75] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd76] <= init_7800 ? 8'hF4 : 8'h00;
    else if(ram_write && ram_address==7'd76)riot_ram[7'd76] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd77] <= init_7800 ? 8'hD0 : 8'h00;
    else if(ram_write && ram_address==7'd77)riot_ram[7'd77] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd78] <= init_7800 ? 8'h0E : 8'h00;
    else if(ram_write && ram_address==7'd78)riot_ram[7'd78] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd79] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd79)riot_ram[7'd79] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd80] <= init_7800 ? 8'h2C : 8'h00;
    else if(ram_write && ram_address==7'd80)riot_ram[7'd80] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd81] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd81)riot_ram[7'd81] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd82] <= init_7800 ? 8'h08 : 8'h00;
    else if(ram_write && ram_address==7'd82)riot_ram[7'd82] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd83] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd83)riot_ram[7'd83] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd84] <= init_7800 ? 8'h1B : 8'h00;
    else if(ram_write && ram_address==7'd84)riot_ram[7'd84] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd85] <= init_7800 ? 8'h20 : 8'h00;
    else if(ram_write && ram_address==7'd85)riot_ram[7'd85] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd86] <= init_7800 ? 8'hCB : 8'h00;
    else if(ram_write && ram_address==7'd86)riot_ram[7'd86] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd87] <= init_7800 ? 8'h04 : 8'h00;
    else if(ram_write && ram_address==7'd87)riot_ram[7'd87] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd88] <= init_7800 ? 8'hEA : 8'h00;
    else if(ram_write && ram_address==7'd88)riot_ram[7'd88] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd89] <= init_7800 ? 8'h24 : 8'h00;
    else if(ram_write && ram_address==7'd89)riot_ram[7'd89] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd90] <= init_7800 ? 8'h02 : 8'h00;
    else if(ram_write && ram_address==7'd90)riot_ram[7'd90] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd91] <= init_7800 ? 8'h30 : 8'h00;
    else if(ram_write && ram_address==7'd91)riot_ram[7'd91] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd92] <= init_7800 ? 8'hD9 : 8'h00;
    else if(ram_write && ram_address==7'd92)riot_ram[7'd92] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd93] <= init_7800 ? 8'hA9 : 8'h00;
    else if(ram_write && ram_address==7'd93)riot_ram[7'd93] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd94] <= init_7800 ? 8'hFD : 8'h00;
    else if(ram_write && ram_address==7'd94)riot_ram[7'd94] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd95] <= init_7800 ? 8'h85 : 8'h00;
    else if(ram_write && ram_address==7'd95)riot_ram[7'd95] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd96] <= init_7800 ? 8'h08 : 8'h00;
    else if(ram_write && ram_address==7'd96)riot_ram[7'd96] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd97] <= init_7800 ? 8'h6C : 8'h00;
    else if(ram_write && ram_address==7'd97)riot_ram[7'd97] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd98] <= init_7800 ? 8'hFC : 8'h00;
    else if(ram_write && ram_address==7'd98)riot_ram[7'd98] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd99] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd99)riot_ram[7'd99] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd100] <= init_7800 ? 8'hEA : 8'h00;
    else if(ram_write && ram_address==7'd100)riot_ram[7'd100] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd101] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd101)riot_ram[7'd101] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd102] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd102)riot_ram[7'd102] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd103] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd103)riot_ram[7'd103] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd104] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd104)riot_ram[7'd104] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd105] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd105)riot_ram[7'd105] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd106] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd106)riot_ram[7'd106] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd107] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd107)riot_ram[7'd107] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd108] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd108)riot_ram[7'd108] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd109] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd109)riot_ram[7'd109] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd110] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd110)riot_ram[7'd110] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd111] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd111)riot_ram[7'd111] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd112] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd112)riot_ram[7'd112] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd113] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd113)riot_ram[7'd113] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd114] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd114)riot_ram[7'd114] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd115] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd115)riot_ram[7'd115] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd116] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd116)riot_ram[7'd116] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd117] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd117)riot_ram[7'd117] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd118] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd118)riot_ram[7'd118] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd119] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd119)riot_ram[7'd119] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd120] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd120)riot_ram[7'd120] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd121] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd121)riot_ram[7'd121] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd122] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd122)riot_ram[7'd122] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd123] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd123)riot_ram[7'd123] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd124] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd124)riot_ram[7'd124] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd125] <= init_7800 ? 8'hFF : 8'h00;
    else if(ram_write && ram_address==7'd125)riot_ram[7'd125] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd126] <= init_7800 ? 8'h00 : 8'h00;
    else if(ram_write && ram_address==7'd126)riot_ram[7'd126] <= ram_write_data;
end
always @(posedge state_host_clk)begin
    if(ram_reset)riot_ram[7'd127] <= init_7800 ? 8'h00 : 8'h00;
    else if(ram_write && ram_address==7'd127)riot_ram[7'd127] <= ram_write_data;
end

endmodule
