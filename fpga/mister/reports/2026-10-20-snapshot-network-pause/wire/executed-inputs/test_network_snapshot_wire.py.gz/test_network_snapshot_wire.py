#!/usr/bin/env python3
"""Snapshot continuation through actual production mux/UIO/DDR/serial-wire RTL.

Enable the new pause only in the extracted fixture. Observe every sequential
bit and both packet RAMs; Main ordering, physical DDR visibility and complete
machine restore remain separate qualification requirements.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import test_ddr_wire as wire
import test_network_snapshot as engine

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def run(out):
    out.mkdir(parents=True,exist_ok=False);inputs=out/'executed-inputs';inputs.mkdir()
    names=('Dorado.sv','dorado_ethernet_ddr.sv','dorado_ethernet_uio.sv','dorado_ethernet_wire.sv')
    for name in names:(inputs/name).write_bytes((ROOT/'fpga/mister'/name).read_bytes())
    source=(inputs/'Dorado.sv').read_text();top=wire.fixture(source)
    top=engine.once(top,' input wire clk_sys,pll_locked,machine_enable,ethernet_tx_n,',
        ' input wire snapshot_hold,output wire snapshot_idle,\n input wire clk_sys,pll_locked,machine_enable,ethernet_tx_n,')
    top=engine.once(top,'dorado_ethernet_ddr u_network_ddr (','dorado_ethernet_ddr #(.SNAPSHOT_PAUSE(1)) u_network_ddr (')
    top=engine.once(top,".snapshot_hold(1'b0),.snapshot_idle(),",'.snapshot_hold(snapshot_hold),.snapshot_idle(snapshot_idle),')
    (inputs/'fixture.sv').write_text(top)
    rtl=[str(inputs/n)for n in names[1:]]
    cmd=['verilator','--xml-only','--top-module','dorado_ddr_wire_fixture','-Wno-fatal','--xml-output',str(out/'fixture.xml'),str(inputs/'fixture.sv'),*rtl]
    (out/'xml-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with(out/'xml.log').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
    raw=(out/'fixture.xml').read_bytes();data=engine.inventory.inventory(raw);tree=ET.fromstring(raw)
    observed=[];review=[];bits=0;arrays=[]
    modules={m.get('name'):m for m in tree.findall('.//module')}
    for row in data['candidates']:
        name=row['path'].removeprefix('dorado_ddr_wire_fixture.')
        if row['category']=='subroutine_review'and '.@'in name:
            assert name.startswith('u_network_wire.@')and name.endswith('.crc_bit')and row['bits']==16
            module=modules[row['module']];func=module.findall('./func');assert len(func)==1 and func[0].get('name')=='crc_bit'
            local={v.get('name')for v in func[0].findall('.//var')};assert not func[0].findall('.//assigndly')
            for assign in func[0].iter('assign'):assert engine.inventory.destinations(assign[1])<=local
            assert 'function automatic [15:0] crc_bit'in(inputs/'dorado_ethernet_wire.sv').read_text()
            review.append(dict(path=row['path'],bits=16,reason='Automatic function return, no global writes/NBAs.'));continue
        if row['category']not in('sequential','subroutine_review'):continue
        if row['category']=='subroutine_review':
            assert name in{'u_network_ddr.'+n for n in('ddram_addr','ddram_be','ddram_wdata','return_state')}
        if '.@'in name:
            assert name.startswith('u_network_ddr.@')and name.endswith('.updated')and row['bits']==64
            name='u_network_ddr.pack_word.updated'
        assert name=='network_step'or name.startswith(('u_network_ddr.','u_network_wire.','u_network_uio.'))
        if row['unpacked_dimensions']:
            assert name in('u_network_wire.rx_buffer','u_network_wire.tx_buffer')and row['width']==16 and row['unpacked_dimensions']==[[0,1023]]
            arrays.append(name);observed.extend(name+'['+str(i)+']'for i in range(1024))
        else:observed.append(name)
        bits+=row['bits']
    assert sorted(arrays)==['u_network_wire.rx_buffer','u_network_wire.tx_buffer']and len(review)==1 and bits>33000
    description=dict(observed_bits=bits,packet_ram_bits=32768,function_scratch_review=review,sequential_exclusions=[],observed_expressions=observed)
    (out/'state-review.json').write_text(json.dumps(description,indent=2)+'\n')
    top=engine.once(top,'module dorado_ddr_wire_fixture(',f'module dorado_ddr_wire_fixture(\n output wire [{bits-1}:0] observed_state,')
    top=engine.once(top,'endmodule','''// Test-only arbitrary power-up contents, including unused packet words.
initial begin
 for(integer i=0;i<1024;i++)begin
  u_network_wire.rx_buffer[i]=16'((i*16'h9e37)^16'ha36c);
  u_network_wire.tx_buffer[i]=16'((i*16'h531b)^16'h6ca3);
 end
end
assign observed_state={\n'''+',\n'.join(observed)+'};\nendmodule')
    legacy=(HERE/'test_ddr_wire.cpp').read_text();legacy=engine.once(legacy,'t.clk_sys=0;t.pll_locked=0;','t.snapshot_hold=0;t.clk_sys=0;t.pll_locked=0;')
    legacy=engine.once(legacy,'m.reads,m.writes,m.holds,m.immediate);\n}', 'm.reads,m.writes,m.holds,m.immediate);\nreturn 0;\n}')
    (inputs/'legacy_wire_test.cpp').write_text(legacy)
    for name in('dorado_ddr_ring.c','dorado_ddr_ring.h','test_network_snapshot_wire.cpp','test_network_snapshot_wire.py','test_ddr_wire.cpp','test_ddr_wire.py'):
        (inputs/name).write_bytes((HERE/name).read_bytes())
    host=out/'host.o';cc=[os.environ.get('CC','cc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(inputs),'-c',str(inputs/'dorado_ddr_ring.c'),'-o',str(host)]
    (out/'c-command.json').write_text(json.dumps(cc,indent=2)+'\n');subprocess.run(cc,check=True,capture_output=True)
    cases=[('candidate',top,None),('ungated_guest',engine.once(top,'always @(negedge clk_sys) network_step <= machine_enable;',"always @(negedge clk_sys) network_step <= 1'b1;"),'held network state changed')]
    results=[]
    for label,fixture,diagnostic in cases:
        case=out/label;case.mkdir();(case/'fixture.sv').write_text(fixture)
        cmd=['verilator','--cc','--exe','--build','-j','4','--top-module','dorado_ddr_wire_fixture','-Wno-fatal','-Wno-PROCASSINIT','--Mdir',str(case/'obj'),str(case/'fixture.sv'),*rtl,
             str(inputs/'test_network_snapshot_wire.cpp'),'-CFLAGS',f'-std=c++17 -I{inputs} -DNETWORK_STATE_WORDS={(bits+31)//32} -DNETWORK_STATE_BITS={bits}','-LDFLAGS',str(host)]
        (case/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
        with(case/'build.log').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
        result=subprocess.run([str(case/'obj/Vdorado_ddr_wire_fixture')],capture_output=True,text=True,timeout=90)
        text=result.stdout+result.stderr;(case/'test.log').write_text(text)
        if diagnostic:assert result.returncode==23 and diagnostic in text,text
        else:assert not result.returncode and'NETWORK WIRE SNAPSHOT PASS'in text and'DDR WIRE PASS'in text,text
        print(label+': '+(diagnostic or text.splitlines()[-1]),flush=True)
        results.append(dict(case=label,returncode=result.returncode,expected_failure=diagnostic,log_sha256=engine.sha((case/'test.log').read_bytes())))
    (out/'qualification.json').write_text(json.dumps(dict(status='PASS',scope=__doc__,state_review=description,cases=results,inputs={p.name:engine.sha(p.read_bytes())for p in inputs.iterdir()},
        limits='Fixture enables pause with explicit idle-SPI and two wire-settling clocks. Not Main coordination, native integration, physical DDR visibility, state import or complete restore.'),indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.output.resolve())
