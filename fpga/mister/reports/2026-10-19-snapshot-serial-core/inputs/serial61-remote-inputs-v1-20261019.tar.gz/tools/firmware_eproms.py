#!/usr/bin/env python3
"""Put the BaseBoard's ROM into the RTL's eight 2716 sockets.

Slices the base ROM into 2K blocks and writes a `.mem` per populated socket
for `cell_i2716`'s `$readmemh`.

THE BYTES ARE STORED BIT-REVERSED, and that is not a quirk of this script --
it is how the BaseBoard is wired. PARC's wire list puts the 2716's pin 9 on
`MCD.7` and its pin 17 on `MCD.0`, while the 6502's pin 26 (DB7) is on `MCD.7`
and its pin 33 (DB0) on `MCD.0`. The data sheet calls 2716 pin 9 O0 and pin 17
O7, so the ROM's least significant output feeds the processor's most
significant data bit: the whole byte arrives reversed, and the chips were
therefore blown reversed. (The address lines are NOT crossed -- pin 19 is A10
on both the board and the data sheet -- so this is a deliberate data-bus
reversal, not a numbering artifact.)

The 1987 chip dumps in `firmware/` prove it. `B-08.BIN` read bit-reversed is
byte-for-byte identical to this image's 0xF000 block, all 2048 of them, and
`B-10.BIN` reversed yields NMI=0xF000 / RESET=0xF3A7 / IRQ=0xF2A2 -- this
image's own vectors. Two artifacts that share no lineage, a physical chip read
in 1987 and a `.MB` from the archive, agreeing once the bits are put back.
That also retires an old note here: those dumps were dismissed as "a different
set or a different layout" because no image had a plausible 6502 vector
triple in its tail. They had one all along. Reversed, they land on exactly the
four populated sockets:

    B-08 -> c61 (0xF000)    C-08 -> f60 (0xC000)
    B-10 -> b61 (0xF800)    C-10 -> e60 (0xC800)

Only B-08 matches byte for byte; the other three are a later build than the
archived `.MB`, which is what the 1987 date on the chips would suggest.

WHERE THE CONTENTS COME FROM, and it is `chm/`, not `firmware/`, so that the
RTL and the C emulator run the same bytes. The C emulator boots
`chm/dorado/doradobaserom.mb!13` -- the archive's base ROM, placed at absolute
6502 addresses by `baseboard_load_rom()` -- so that is the authority, and
using it keeps the two models comparable: whatever the RTL's 6502 fetches is
byte-for-byte what the C one fetches.

That image validates itself three more ways: its vectors are NMI=0xF000,
RESET=0xF3A7, IRQ=0xF2A2, all inside the ROM area; its 6,955 non-zero bytes
fall in exactly four 2K blocks; and those blocks are C000, C800, F000 and
F800 -- which is the 1981 Hardware Manual's "4 EPROMs at F000, F800, C000,
C800", four chips in eight sockets. (The manual's later 5th chip at
D000-D7FF is not in this image.)

Feed it `dorado/build/baseboard_rom_dump`, which runs the emulator's own
loader.

HOW THE MAPPING WAS DERIVED, since it is not written down anywhere:

  * The eight sockets are chip-selected by `Rom0'`..`Rom7'`, the outputs of the
    SN74LS138 at BaseBd g11, whose select inputs are `RSA.0/1/2` (pins 1/2/3 =
    A/B/C, so RSA.0 is the least significant).
  * Each socket's address pins take `MCA.10` down to `MCA.00` -- the 6502's
    A10..A0, a clean 2K window. (Mind that PARC names those pins MSB-first:
    the dictionary's `A0` is pin 19, which the data sheet calls A10.)
  * `RSA.0/1/2` are not driven by any gate. They arrive on `c07`, an Augat
    connector, which also brings `MCA.11`, `MCA.12`, `MCA.13` and `MCA.14`
    OUT. It is a strap block: you choose which address bits bank the ROMs.
  * With 2K parts the only strapping that tiles the space is
    RSA.0/1/2 = MCA.11/12/13, giving eight consecutive 2K blocks.
  * `baseboard.h` puts the ROM area at 0xC000-0xFFFF, which is exactly those
    16K, so Rom<n> is at 0xC000 + n*0x800.

That lands the base ROM's four blocks on Rom0, Rom1, Rom6 and Rom7, leaving
the other four sockets empty -- four chips in eight sockets, as the 1981
manual describes.

    Rom0  f60  0xC000      Rom2  c60  0xD000      Rom4  h61  0xE000
    Rom1  e60  0xC800      Rom3  b60  0xD800      Rom5  i61  0xE800
                                                  Rom6  c61  0xF000
                                                  Rom7  b61  0xF800

Usage:
    firmware_eproms.py --dump FILE            print the map and what is in it
    firmware_eproms.py --dump FILE --emit DIR write the populated sockets
"""

from __future__ import annotations

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# socket -> (Rom number, base address)
SOCKETS = {
    'f60': (0, 0xC000), 'e60': (1, 0xC800), 'c60': (2, 0xD000),
    'b60': (3, 0xD800), 'h61': (4, 0xE000), 'i61': (5, 0xE800),
    'c61': (6, 0xF000), 'b61': (7, 0xF800),
}

BOARD = 'BaseBd'


# Which sockets the base ROM actually fills. Populated at import time from a
# dump when one is given; the generator asks for this by socket.
POPULATED = ('f60', 'e60', 'c61', 'b61')


def images() -> dict[str, str]:
    """socket -> .mem basename, for the sockets the base ROM fills."""
    return {sock: f'{BOARD}-{sock}.mem' for sock in POPULATED}


def read_dump(path: str) -> dict[int, int]:
    rom = {}
    for line in open(path):
        parts = line.split()
        if len(parts) == 2:
            rom[int(parts[0], 16)] = int(parts[1], 16)
    return rom


def bit_reverse(b: int) -> int:
    """The byte as the chip stores it -- see the note above."""
    return int(f'{b:08b}'[::-1], 2)


def emit(dump: str, outdir: str) -> int:
    rom = read_dump(dump)
    os.makedirs(outdir, exist_ok=True)
    n = 0
    for sock, (num, base) in sorted(SOCKETS.items(), key=lambda kv: kv[1][0]):
        block = [rom.get(base + i, 0) for i in range(2048)]
        if not any(block):
            continue                      # an empty socket stays empty
        path = os.path.join(outdir, f'{BOARD}-{sock}.mem')
        with open(path, 'w') as fh:
            fh.write(f'// {BOARD} {sock} = Rom{num} at 0x{base:04X}\n')
            fh.write('// Generated by tools/firmware_eproms.py from the base '
                     'ROM the C emulator\n// boots. Do not edit; regenerate.\n')
            fh.write('// Bytes are BIT-REVERSED, as the real chips are: the '
                     'board crosses the\n// EPROM data bus end for end. See '
                     'the module docstring.\n')
            for b in block:
                fh.write(f'{bit_reverse(b):02X}\n')
        n += 1
    print(f'wrote {n} EPROM images into {outdir}')
    return 0


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--dump', metavar='FILE',
                    default=os.path.join(HERE, '..', 'dorado', 'build',
                                         'baseboard_rom_dump.txt'))
    ap.add_argument('--emit', metavar='DIR')
    args = ap.parse_args(argv[1:])
    if args.emit:
        return emit(args.dump, args.emit)
    rom = read_dump(args.dump)
    print(f'{"socket":<8}{"Rom":<5}{"address":<10}bytes')
    for sock, (num, base) in sorted(SOCKETS.items(), key=lambda kv: kv[1][0]):
        n = sum(1 for i in range(2048) if rom.get(base + i, 0))
        print(f'{sock:<8}{num:<5}0x{base:04X}    '
              f'{n if n else "(empty socket)"}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
