// cell_F10414 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 4 package position(s) across the sixteen boards.
//
// 256 x 1 RAM (Fairchild F10K). EclDict states it as a memory:
//
//   [M 13 {B-1.0 2.0}>15 : CLK 14 (...) ADDR (1 2 3 4 9 10 11 12) (...)
//                          CE (5 6 7) (...)]
//
// so pin 13 is the data in, pin 15 the data out, pin 14 the write, the eight
// address pins are A0..A7 = 1, 2, 3, 4, 9, 10, 11, 12 -- MSB-first, as PARC
// numbers everything -- and the three chip selects are 5, 6, 7.
//
// The board wires only CS2' (pin 7); the other two are tied low, so they are
// not declared here.
//
// Like its 1024 x 1 sibling F10415A: the write is level-sensitive on the real
// part and is SYNCHRONOUS here, on `sys_clk` with the part's own levels as
// enables. A transparent write makes every read-modify-write path in the
// machine a combinational loop, and a latch does not synthesise; the read
// stays combinational, which is what the timing assumes and what distributed
// RAM gives you. An ECL RAM's open-emitter output goes low when deselected.

`default_nettype none

module dorado_serial_ProcL__cell_F10414_snapshot (
    input wire state_host_clk, state_advance, state_freeze, state_guest_held,
    input wire state_request, state_write,
    input wire [8:0] state_index,
    input wire [3:0] state_data,
    output reg state_frozen = 1'b0,
    output reg state_done = 1'b0, state_error = 1'b0,
    output reg [3:0] state_result,
    input  wire sys_clk,
    input  wire p1,  // A0
    input  wire p2,  // A1
    input  wire p3,  // A2
    input  wire p4,  // A3
    input  wire p7,  // CS2'
    input  wire p9,  // A4
    input  wire p10,  // A5
    input  wire p11,  // A6
    input  wire p12,  // A7
    input  wire p13,  // b_IN0
    input  wire p14,  // WE'
    output wire p15// b_OUT
);

  wire [7:0] a  = {p1, p2, p3, p4, p9, p10, p11, p12};   // A0..A7, MSB first
  wire       sel = ~p7;                                  // CS2'

  (* ramstyle = "MLAB, no_rw_check" *) reg mem [0:255];
  // One physical RAM/read port; state scans temporarily borrow its address.
  wire state_hold = state_freeze && state_guest_held;
  wire state_accept = state_hold && state_frozen && state_request;
  wire state_valid = !state_index[8];
  wire [7:0] state_address = state_hold ? state_index[7:0] : a;
  wire [0:0] state_read = mem[state_address];
  wire state_restore = state_accept && state_write && state_valid;
  wire state_guest_write = !state_hold && state_advance && (sel && !p14);
  wire [0:0] state_write_data = state_hold ? state_data[0] : p13;
  always @(posedge state_host_clk) begin
    state_frozen <= state_hold;
    state_done <= state_accept;
    state_error <= state_accept && !state_valid;
    if (state_accept) begin
      state_result <= state_valid && !state_write ? {3'b0,state_read} : 4'b0;
    end
    if (state_restore || state_guest_write)
      mem[state_address] <= state_write_data;
  end

  assign p15 = sel ? state_read[0] : 1'b0;
endmodule

`default_nettype wire
