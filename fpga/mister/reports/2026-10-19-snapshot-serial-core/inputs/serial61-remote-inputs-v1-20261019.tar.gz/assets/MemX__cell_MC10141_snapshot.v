// cell_MC10141 -- Four-Bit Universal Shift Register
//
// Pins: PARC's EclDict.Analyze. Function: the part's TRUTH TABLE, read from
// two independent Motorola books that agree exactly --
// DoradoDocs/datasheets/Motorola_MECL_DataBook_1978.pdf p.3-53 and
// ON_MECL_DataBook_DL122_rev7.pdf p.333.  Used in 60 package position(s).
//
//   SELECT              OUTPUTS (after a positive edge at C)
//   S1 S2  MODE         Q0n+1  Q1n+1  Q2n+1  Q3n+1
//   L  L   Parallel      D0     D1     D2     D3
//   L  H   Shift Right   Q1n    Q2n    Q3n    DR
//   H  L   Shift Left    DL     Q0n    Q1n    Q2n
//   H  H   Stop Shift    Q0n    Q1n    Q2n    Q3n
//
// DIP pin assignment, both books: 2=Q2 3=Q3 4=C 5=DR 6=D3 7=S2 9=D2 10=S1
// 11=D1 12=D0 13=DL 14=Q0 15=Q1.
//
// PARC NAMES TWO PAIRS OF PINS THE OTHER WAY ROUND, and that is not an error
// on either side -- it is which end of a 16-bit register you call "left".
// EclDict calls pin 5 DL and pin 13 DR (Motorola: DR and DL), and pin 10 SL'
// and pin 7 SR' (Motorola: S1 and S2).  The two swaps are consistent with each
// other: the mode PARC calls shift-left is selected by its SL' and consumes
// its DL, exactly as its names promise.  So the BOARD reads correctly under
// PARC's names and the CELL must implement Motorola's function per PIN NUMBER.
// Do not "fix" the dictionary's names into this file; pin numbers are the only
// thing the two sources share, and they agree on every one.

`default_nettype none

module dorado_serial_MemX__cell_MC10141_snapshot #(parameter PRECAP = 1) (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,
    output wire [17:0] state_result,
    input  wire sys_clk,
    input  wire p4,
    input  wire p12,
    input  wire p11,
    input  wire p9,
    input  wire p6,
    input  wire p5,
    input  wire p13,
    input  wire p10,
    input  wire p7,
    output wire p14,
    output wire p15,
    output wire p2,
    output wire p3,
    input  wire p1,
    input  wire p8
);

  reg [3:0] q;   // q[3:0] = Q3,Q2,Q1,Q0

  // FPGA: ONE CLOCK, and the ECL clock net becomes an ENABLE.
  //
  // The Dorado clocks this part from a distributed ECL clock net (CLK.ph'
  // and friends, fanned out by the BaseBoard). Taking that literally gives
  // the fabric a gated clock off combinational logic -- 1,201 packages across
  // the machine do it -- which no FPGA can route. So every flip-flop here
  // runs on `sys_clk` and transfers on the sys_clk edge FOLLOWING an edge of
  // the modelled clock net. That is the usual oversampling transform, and it
  // matches the part as long as sys_clk is faster than the clock net, which
  // dorado_machine guarantees by dividing.
  reg ck_d;
  
  wire ck_en = p4 & ~ck_d;

  // PRE-EDGE CAPTURE -- the real part's SETUP TIME, as cell_MC10176 has it.
  // The edge is detected one sys_clk after the modelled clock rises, and by
  // then a D that moved ON that edge has settled to its new value. ProcH a21
  // is this part with D = Next and clock = SHCP'C, and Next (ContA h14,
  // Switcha ? BNT : CTask) moves on the same sys_clk SHCP'C rises, so a21
  // loaded the INCOMING task a whole cycle early; a20 (Last <- Curr, on
  // Clock1'Ca, +16 later) then copied it, and every T-file write-back at a
  // task switch was addressed to the incoming task's slot (measured
  // 2026-09-05: task 0's T into the junk task's slot, the junk task's T into
  // the display task's). With the pre-edge copy Curr takes Next at the NEXT
  // SHCP'C edge, Last holds the outgoing task through the write-back pulse,
  // and both slots receive their own task's T. The selects and shift inputs
  // get the same treatment: a coincidence is a coincidence on any pin.
  reg [3:0] d_pre; reg [1:0] s_pre; reg dr_pre, dl_pre;
  
  // PRECAP=1 (default) is the pre-edge capture that fixes ProcH a21, the
  // task-switch Curr<-Next register (2026-09-05). The parameter exists so the
  // choice CAN be made per package via CELL_PARAMS. TESTED AND NEGATIVE
  // (2026-09-07): setting MemC i10 -- this same part, holding the cache's
  // DIRTY flags -- to PRECAP=0 under derived clock depth does NOT fix
  // `memrun-test`'s "the Store did not dirty the flushed line". That failure
  // is not this register's capture mode; see docs/verilog-handoff.md.
  wire [3:0] d_use  = PRECAP ? d_pre  : {p6, p9, p11, p12};
  wire [1:0] s_use  = PRECAP ? s_pre  : {p10, p7};
  wire       dr_use = PRECAP ? dr_pre : p5;
  wire       dl_use = PRECAP ? dl_pre : p13;
  
  assign {p3, p2, p15, p14} = q;           // Q3, Q2, Q1, Q0


  // Board-wired pins not named above (power and the like)
  wire _unused_pins = &{1'b0, p1, p8, 1'b0};


  assign state_result = {5'b0,{ck_d,dl_pre,dr_pre,s_pre,d_pre,q}};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {ck_d,dl_pre,dr_pre,s_pre,d_pre,q} <= state_data[12:0];
    end else if (state_advance) begin
ck_d <= p4;
begin
    d_pre <= {p6, p9, p11, p12}; s_pre <= {p10, p7}; dr_pre <= p5; dl_pre <= p13;
  end
if (ck_en) begin
    case (s_use)                           // S1, S2
      2'b00: q <= d_use;                   // Parallel:    Q3<-D3 Q2<-D2 Q1<-D1 Q0<-D0
      2'b01: q <= {dr_use, q[3:1]};        // Shift Right: Q3<-DR, each Q takes the next
      2'b10: q <= {q[2:0], dl_use};        // Shift Left:  Q0<-DL, each Q takes the previous
      default: q <= q;                     // Stop shift
    endcase
  end
    end
  end
endmodule

`default_nettype wire
