// cell_MC1690 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 4 package position(s) across the sixteen boards.
//
// Type D master-slave flip-flop (MECL III), the fastest part in the machine.
// EclDict names the pins the boards use: D1=11, C1=7, Q=2, Q'=3.
//
// All four packages are the BaseBoard's CLOCK GENERATOR. g04 and h04 are
// cross-coupled on one clock phase -- g04.D = h04.Q', h04.D = g04.Q -- which
// is a Johnson counter dividing by four; g03 and h03 delay g04's output on
// the opposite phase. Out of that come `StartClockPulse'` (g04.Q') and
// `EndClockPulse` (h03.Q), which the MC10210 at j02 fans out to every slot
// as CLK.ph', CLK.mc' and the rest.
//
// FPGA: on `sys_clk` with C1 as an enable, like every other clocked cell
// here -- see cell_MC10176 for the reasoning.

`default_nettype none

module dorado_serial_BaseBd__cell_MC1690_snapshot (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [1:0] state_index,input wire [17:0] state_data,output reg [17:0] state_result,
    input wire state_scan_in,output wire [1:0] state_scan_out,
    input  wire sys_clk,
    output wire p2,  // Q
    output wire p3,  // Q'
    input  wire p7,  // C1
    input  wire p11// D1
);

  reg ck_d, q;
  wire ck_en = p7 & ~ck_d;
  assign p2 =  q;       // Q
  assign p3 = ~q;       // Q'
 always @* begin
  state_result=18'b0;
  case(state_index)
   2'd0:state_result={16'b0,{ck_d,q}};
   default:state_result=18'b0;
  endcase
 end
 always @(posedge state_host_clk)begin
  if(state_hold)begin
   if(state_write){ck_d,q} <= {state_scan_in,state_scan_out[1:1]};
  end else if(state_advance)begin
ck_d <= p7;
if (ck_en) q <= p11;
  end
 end
 assign state_scan_out={ck_d,q};
endmodule

`default_nettype wire
