// cell_SN74LS174 -- MECL model for the Xerox Dorado
//
// Ports: pin numbers and signal names from PARC's EclDict.Analyze.
// Directions: observed in the .wl wire lists across all boards.
// Used in 16 package position(s) across the sixteen boards.
//
// Hex D Flip-Flop with direct clear (TTL). PARC's TtlDict gives the whole
// part in one line -- data to output, clock and clear:
//
//   [FF 3>2, 4>5, 6>7, 11>10, 13>12, 14>15 : CLK 9 RS 1]
//
// which is the standard 74174 pinout: CLR' on pin 1, CLK on 9, six D/Q pairs.
// Positive-edge triggered, clear active LOW and asynchronous.
//
// FPGA: on `sys_clk` with the clock as an enable, and the clear level-tested
// on the same edge -- see cell_MC10176 for why.

`default_nettype none

module dorado_serial_BaseBd__cell_SN74LS174_snapshot #(parameter integer PRECAP=0) (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,output wire [17:0] state_result,
    input wire state_scan_in,output wire [12:0] state_scan_out,
    input  wire sys_clk,
    input  wire p1,  // CL'
    output wire p2,  // Q0
    input  wire p3,  // D0
    input  wire p4,  // D1
    output wire p5,  // Q1
    input  wire p6,  // D2
    output wire p7,  // Q2
    input  wire p8,  // (no name in EclDict)
    input  wire p9,  // CK
    output wire p10,  // Q3
    input  wire p11,  // D3
    output wire p12,  // Q4
    input  wire p13,  // D4
    input  wire p14,  // D5
    output wire p15,  // Q5
    input  wire p16// (no name in EclDict)
);

  reg ck_d;
  
  wire ck_en = p9 & ~ck_d;

  // Optional setup-value capture, as in cell_MC10176. BaseBd's manifold
  // shift register clocks when its serial selector changes to readback;
  // those two packages must retain the data present before that edge.
  reg [5:0] d_pre;
  

  reg [5:0] q;
  

  assign {p15, p12, p10, p7, p5, p2} = q;             // Q6..Q1

  wire _unused_pins = &{1'b0, p8, p16, 1'b0};         // GND, VCC

 assign state_result={5'b0,{ck_d,d_pre,q}};
 always @(posedge state_host_clk)begin
  if(state_hold)begin
   if(state_write){ck_d,d_pre,q} <= {state_scan_in,state_scan_out[12:1]};
  end else if(state_advance)begin
ck_d <= p9;
d_pre <= {p14,p13,p11,p6,p4,p3};
begin
    if (!p1)        q <= 6'd0;                        // CLR', asynchronous
    else if (ck_en) q <= PRECAP ? d_pre : {p14,p13,p11,p6,p4,p3};
  end
  end
 end
 assign state_scan_out={ck_d,d_pre,q};
endmodule

`default_nettype wire
