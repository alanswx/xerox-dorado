// cell_MC10135 -- Dual J-K Master-Slave Flip-Flop
//
// Pins: PARC's EclDict/TtlDict.Analyze. Used in 29 package position(s).

`default_nettype none

module dorado_serial_MemX__cell_MC10135_snapshot #(parameter PRECAP = 0,
    parameter PRECAP_A = PRECAP, parameter PRECAP_B = PRECAP) (
    input wire state_host_clk,state_advance,state_hold,state_write,
    input wire [17:0] state_data,output wire [17:0] state_result,
    input  wire sys_clk,
    input  wire p9,
    input  wire p7,
    input  wire p6,
    input  wire p4,
    input  wire p5,
    output wire p2,
    output wire p3,
    input  wire p10,
    input  wire p11,
    input  wire p13,
    input  wire p12,
    output wire p15,
    output wire p14
);

  // CC=9 common clock; J'/K' are ACTIVE LOW (the dictionary names them with
  // primes); R/S asynchronous, active high.
  reg qa, qb;
  // Preserve setup J/K when a control changes on the same modeled edge.
  // DskEth c16 uses this: releasing IOHold at clk1 must not clear OutReg
  // before c15's pre-edge underflow checker observes that read. The default
  // retains existing timing for other packages pending their own audit.
  reg [3:0] jk_pre;
  
  // The two independent flip-flops can have different setup paths. Ether06
  // l06 B captures the Output handshake before its modeled clock edge;
  // A retains the existing receive-data-late timing. PRECAP still selects
  // both halves for existing placements such as DskEth c16.
  wire ja = ~(PRECAP_A ? jk_pre[0] : p7);
  wire ka = ~(PRECAP_A ? jk_pre[1] : p6);
  wire jb = ~(PRECAP_B ? jk_pre[2] : p10);
  wire kb = ~(PRECAP_B ? jk_pre[3] : p11);

  // FPGA: ONE CLOCK, and the ECL clock net becomes an ENABLE.
  //
  // The Dorado clocks this part from a distributed ECL clock net (CLK.ph'
  // and friends, fanned out by the BaseBoard). Taking that literally gives
  // the fabric a gated clock off combinational logic -- 1,201 packages across
  // the machine do it -- which no FPGA can route. So every flip-flop here
  // runs on `sys_clk` and transfers on the sys_clk edge FOLLOWING an edge of
  // the modelled clock net. That is the usual oversampling transform, and it
  // matches the part as long as sys_clk is faster than the clock net, which
  // dorado_machine guarantees by dividing.
  //
  // Asynchronous inputs (MR, S/R, CL') are LEVEL-tested every sys_clk edge --
  // the same treatment, and it keeps them out of the fabric's reset network.
  reg ck_d;
  
  wire ck_en = p9 & ~ck_d;

  
  
  assign p2 = qa; assign p3 = ~qa;
  assign p15 = qb; assign p14 = ~qb;



  assign state_result={11'b0,ck_d,jk_pre,qb,qa};
  always @(posedge state_host_clk) begin
    if (state_hold) begin
      if (state_write) {ck_d,jk_pre,qb,qa}<=state_data[6:0];
    end else if (state_advance) begin
jk_pre <= {p11,p10,p6,p7};
ck_d <= p9;
begin
    if (p5)         qa <= 1'b1;
    else if (p4)    qa <= 1'b0;
    else if (ck_en) qa <= (ja & ~qa) | (~ka & qa);
  end
begin
    if (p12)        qb <= 1'b1;
    else if (p13)   qb <= 1'b0;
    else if (ck_en) qb <= (jb & ~qb) | (~kb & qb);
  end
    end
  end
endmodule

`default_nettype wire
