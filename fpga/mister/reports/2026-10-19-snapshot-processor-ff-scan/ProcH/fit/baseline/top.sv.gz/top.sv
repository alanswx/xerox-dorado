module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [159:0] stimulus,
 input wire freeze,held,request,write,input wire [15:0] index,
 input wire [17:0] state_data,output reg [74:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both processor neighbors sample on positive host edges; full20ns budgets.
 reg [199:0] launch;
 always @(posedge host_clk)
  launch<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [159:0] stimulus_r;wire [15:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [74:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_ALUCarry__drv;
wire bank_BMux_00__drv;
wire bank_BMux_01__drv;
wire bank_BMux_02__drv;
wire bank_BMux_03__drv;
wire bank_BMux_04__drv;
wire bank_BMux_05__drv;
wire bank_BMux_06__drv;
wire bank_BMux_07__drv;
wire bank_BMux_16__drv;
wire bank_Cnt_eq_Zero_p___drv;
wire bank_DMuxData__drv;
wire bank_FA_eq_0_p___drv;
wire bank_FA_eq_1_p___drv;
wire bank_FF_0mem_p___drv;
wire bank_FF_1mem__drv;
wire bank_IOB_00__drv;
wire bank_IOB_01__drv;
wire bank_IOB_02__drv;
wire bank_IOB_03__drv;
wire bank_IOB_04__drv;
wire bank_IOB_05__drv;
wire bank_IOB_06__drv;
wire bank_IOB_07__drv;
wire bank_IOB_16__drv;
wire bank_IOPE__drv;
wire bank_IOatt__drv;
wire bank_MAR_00_p___drv;
wire bank_MAR_01_p___drv;
wire bank_MAR_02_p___drv;
wire bank_MAR_03_p___drv;
wire bank_MAR_04_p___drv;
wire bank_MAR_05_p___drv;
wire bank_MAR_06_p___drv;
wire bank_MAR_07_p___drv;
wire bank_MdPE__drv;
wire bank_MemBase_0__drv;
wire bank_MemBase_1__drv;
wire bank_MemBase_2__drv;
wire bank_MemBase_3__drv;
wire bank_MemBase_4__drv;
wire bank_NextData_p___drv;
wire bank_Overflow_p___drv;
wire bank_Pdata_15__drv;
wire bank_Q_07__drv;
wire bank_RamPE__drv;
wire bank_ResEqZero_p___drv;
wire bank_ResLtZero_p___drv;
wire bank_RmLtZero_p___drv;
wire bank_ShA_00__drv;
wire bank_ShA_01__drv;
wire bank_ShA_02__drv;
wire bank_ShA_03__drv;
wire bank_ShA_04__drv;
wire bank_ShA_05__drv;
wire bank_ShA_06__drv;
wire bank_ShA_07__drv;
wire bank_Shc_02__drv;
wire bank_Shc_03__drv;
wire bank_Shc_04b__drv;
wire bank_Shc_05b__drv;
wire bank_Shc_06b__drv;
wire bank_Shc_07b__drv;
wire bank_TIOA_0__drv;
wire bank_TIOA_1__drv;
wire bank_TIOA_2__drv;
wire bank_TIOA_3__drv;
wire bank_TIOA_4__drv;
wire bank_TIOA_5__drv;
wire bank_TIOA_6__drv;
wire bank_TIOA_7__drv;
wire bank_TestTW__drv;
wire bank_alu_07__drv;
wire bank_aluCout__drv;
wire bank_aluOut_eq_0_p___drv;
assign bank_q={bank_aluOut_eq_0_p___drv,bank_aluCout__drv,bank_alu_07__drv,bank_TestTW__drv,bank_TIOA_7__drv,bank_TIOA_6__drv,bank_TIOA_5__drv,bank_TIOA_4__drv,bank_TIOA_3__drv,bank_TIOA_2__drv,bank_TIOA_1__drv,bank_TIOA_0__drv,bank_Shc_07b__drv,bank_Shc_06b__drv,bank_Shc_05b__drv,bank_Shc_04b__drv,bank_Shc_03__drv,bank_Shc_02__drv,bank_ShA_07__drv,bank_ShA_06__drv,bank_ShA_05__drv,bank_ShA_04__drv,bank_ShA_03__drv,bank_ShA_02__drv,bank_ShA_01__drv,bank_ShA_00__drv,bank_RmLtZero_p___drv,bank_ResLtZero_p___drv,bank_ResEqZero_p___drv,bank_RamPE__drv,bank_Q_07__drv,bank_Pdata_15__drv,bank_Overflow_p___drv,bank_NextData_p___drv,bank_MemBase_4__drv,bank_MemBase_3__drv,bank_MemBase_2__drv,bank_MemBase_1__drv,bank_MemBase_0__drv,bank_MdPE__drv,bank_MAR_07_p___drv,bank_MAR_06_p___drv,bank_MAR_05_p___drv,bank_MAR_04_p___drv,bank_MAR_03_p___drv,bank_MAR_02_p___drv,bank_MAR_01_p___drv,bank_MAR_00_p___drv,bank_IOatt__drv,bank_IOPE__drv,bank_IOB_16__drv,bank_IOB_07__drv,bank_IOB_06__drv,bank_IOB_05__drv,bank_IOB_04__drv,bank_IOB_03__drv,bank_IOB_02__drv,bank_IOB_01__drv,bank_IOB_00__drv,bank_FF_1mem__drv,bank_FF_0mem_p___drv,bank_FA_eq_1_p___drv,bank_FA_eq_0_p___drv,bank_DMuxData__drv,bank_Cnt_eq_Zero_p___drv,bank_BMux_16__drv,bank_BMux_07__drv,bank_BMux_06__drv,bank_BMux_05__drv,bank_BMux_04__drv,bank_BMux_03__drv,bank_BMux_02__drv,bank_BMux_01__drv,bank_BMux_00__drv,bank_ALUCarry__drv};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 ProcH_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 ProcH_m_Rev_m_Ce #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.ALUCarry(stimulus_r[0] | bank_ALUCarry__drv),
.ALUF_0(stimulus_r[1]),
.ALUF_1(stimulus_r[2]),
.ALUF_2(stimulus_r[3]),
.ASEL_0_p_(stimulus_r[4]),
.ASEL_1_p_(stimulus_r[5]),
.ASEL_2_p_(stimulus_r[6]),
.BMux_00(stimulus_r[7] | bank_BMux_00__drv),
.BMux_01(stimulus_r[8] | bank_BMux_01__drv),
.BMux_02(stimulus_r[9] | bank_BMux_02__drv),
.BMux_03(stimulus_r[10] | bank_BMux_03__drv),
.BMux_04(stimulus_r[11] | bank_BMux_04__drv),
.BMux_05(stimulus_r[12] | bank_BMux_05__drv),
.BMux_06(stimulus_r[13] | bank_BMux_06__drv),
.BMux_07(stimulus_r[14] | bank_BMux_07__drv),
.BMux_16(stimulus_r[15] | bank_BMux_16__drv),
.BNTGtCT_p_a(stimulus_r[16]),
.BSEL_0_p_(stimulus_r[17]),
.BSEL_1_p_(stimulus_r[18]),
.BSEL_2_p_(stimulus_r[19]),
.CLK_ph_p_(stimulus_r[20]),
.CLKEnable_p_c(stimulus_r[21]),
.CkMdParity_p_(stimulus_r[22]),
.Cnt_eq_Zero_p_(stimulus_r[23] | bank_Cnt_eq_Zero_p___drv),
.DMuxClk(stimulus_r[24]),
.DMuxData(stimulus_r[25] | bank_DMuxData__drv),
.FF_0(stimulus_r[26]),
.FF_0mem_p_(stimulus_r[27] | bank_FF_0mem_p___drv),
.FF_1(stimulus_r[28]),
.FF_1mem(stimulus_r[29] | bank_FF_1mem__drv),
.FF_2(stimulus_r[30]),
.FF_3(stimulus_r[31]),
.FF_4(stimulus_r[32]),
.FF_5(stimulus_r[33]),
.FF_6(stimulus_r[34]),
.FF_7(stimulus_r[35]),
.FFok_p_a(stimulus_r[36]),
.Freeze(stimulus_r[37]),
.IOB_00(stimulus_r[38] | bank_IOB_00__drv),
.IOB_01(stimulus_r[39] | bank_IOB_01__drv),
.IOB_02(stimulus_r[40] | bank_IOB_02__drv),
.IOB_03(stimulus_r[41] | bank_IOB_03__drv),
.IOB_04(stimulus_r[42] | bank_IOB_04__drv),
.IOB_05(stimulus_r[43] | bank_IOB_05__drv),
.IOB_06(stimulus_r[44] | bank_IOB_06__drv),
.IOB_07(stimulus_r[45] | bank_IOB_07__drv),
.IOB_16(stimulus_r[46] | bank_IOB_16__drv),
.IOatt(stimulus_r[47] | bank_IOatt__drv),
.LC_0(stimulus_r[48]),
.LC_1(stimulus_r[49]),
.LC_2(stimulus_r[50]),
.MAR_00_p_(stimulus_r[51] | bank_MAR_00_p___drv),
.MAR_01_p_(stimulus_r[52] | bank_MAR_01_p___drv),
.MAR_02_p_(stimulus_r[53] | bank_MAR_02_p___drv),
.MAR_03_p_(stimulus_r[54] | bank_MAR_03_p___drv),
.MAR_04_p_(stimulus_r[55] | bank_MAR_04_p___drv),
.MAR_05_p_(stimulus_r[56] | bank_MAR_05_p___drv),
.MAR_06_p_(stimulus_r[57] | bank_MAR_06_p___drv),
.MAR_07_p_(stimulus_r[58] | bank_MAR_07_p___drv),
.MemBM_0(stimulus_r[59]),
.MemBM_1(stimulus_r[60]),
.MemBM34(stimulus_r[61]),
.MemBase_0(stimulus_r[62] | bank_MemBase_0__drv),
.MemBase_1(stimulus_r[63] | bank_MemBase_1__drv),
.Next_0(stimulus_r[64]),
.Next_1(stimulus_r[65]),
.Next_2(stimulus_r[66]),
.Next_3(stimulus_r[67]),
.NextData_p_(stimulus_r[68] | bank_NextData_p___drv),
.NextMacro(stimulus_r[69]),
.Overflow_p_(stimulus_r[70] | bank_Overflow_p___drv),
.PRhold(stimulus_r[71]),
.PropCnt_p_(stimulus_r[72]),
.Q_07(stimulus_r[73] | bank_Q_07__drv),
.Q_08(stimulus_r[74]),
.RSTK_0(stimulus_r[75]),
.RSTK_1(stimulus_r[76]),
.RSTK_2(stimulus_r[77]),
.RSTK_3(stimulus_r[78]),
.RbAdr_0(stimulus_r[79]),
.RbAdr_1(stimulus_r[80]),
.RbAdr_2(stimulus_r[81]),
.RbAdr_3(stimulus_r[82]),
.RbBypass(stimulus_r[83]),
.RbBypass_p_(stimulus_r[84]),
.ResEqZero_p_(stimulus_r[85] | bank_ResEqZero_p___drv),
.ResLtZero_p_(stimulus_r[86] | bank_ResLtZero_p___drv),
.RmLtZero_p_(stimulus_r[87] | bank_RmLtZero_p___drv),
.SelectRm_p_a(stimulus_r[88]),
.SelectStk_p_a(stimulus_r[89]),
.ShA_00(stimulus_r[90] | bank_ShA_00__drv),
.ShA_01(stimulus_r[91] | bank_ShA_01__drv),
.ShA_02(stimulus_r[92] | bank_ShA_02__drv),
.ShA_03(stimulus_r[93] | bank_ShA_03__drv),
.ShA_04(stimulus_r[94] | bank_ShA_04__drv),
.ShA_05(stimulus_r[95] | bank_ShA_05__drv),
.ShA_06(stimulus_r[96] | bank_ShA_06__drv),
.ShA_08(stimulus_r[97]),
.ShA_09(stimulus_r[98]),
.ShA_10(stimulus_r[99]),
.ShA_11(stimulus_r[100]),
.ShA_12(stimulus_r[101]),
.ShA_13(stimulus_r[102]),
.ShA_14(stimulus_r[103]),
.ShA_15(stimulus_r[104]),
.Shc_02(stimulus_r[105] | bank_Shc_02__drv),
.Shc_03(stimulus_r[106] | bank_Shc_03__drv),
.Shc_08(stimulus_r[107]),
.Shc_09(stimulus_r[108]),
.Shc_10(stimulus_r[109]),
.Shc_11(stimulus_r[110]),
.Shc_12(stimulus_r[111]),
.Shc_13(stimulus_r[112]),
.Shc_14(stimulus_r[113]),
.Shc_15(stimulus_r[114]),
.ShcAlu_0(stimulus_r[115]),
.ShcAlu_1(stimulus_r[116]),
.ShcAlu_2(stimulus_r[117]),
.ShcAlu_3(stimulus_r[118]),
.SignIfuData(stimulus_r[119]),
.StartCycle_p_a(stimulus_r[120]),
.StkAdr_0a(stimulus_r[121]),
.StkAdr_1a(stimulus_r[122]),
.StkAdr_2a(stimulus_r[123]),
.StkAdr_3a(stimulus_r[124]),
.StkAdr_4a(stimulus_r[125]),
.StkAdr_5a(stimulus_r[126]),
.StkAdr_6a(stimulus_r[127]),
.StkAdr_7a(stimulus_r[128]),
.TIOA_0(stimulus_r[129] | bank_TIOA_0__drv),
.TIOA_1(stimulus_r[130] | bank_TIOA_1__drv),
.TIOA_2(stimulus_r[131] | bank_TIOA_2__drv),
.TIOA_3(stimulus_r[132] | bank_TIOA_3__drv),
.TIOA_4(stimulus_r[133] | bank_TIOA_4__drv),
.TIOA_5(stimulus_r[134] | bank_TIOA_5__drv),
.TIOA_6(stimulus_r[135] | bank_TIOA_6__drv),
.TIOA_7(stimulus_r[136] | bank_TIOA_7__drv),
.TempRef(stimulus_r[137]),
.alu_07(stimulus_r[138] | bank_alu_07__drv),
.alu_08(stimulus_r[139]),
.alu_15(stimulus_r[140]),
.aluC0(stimulus_r[141]),
.aluCout(stimulus_r[142] | bank_aluCout__drv),
.aluF0(stimulus_r[143]),
.aluF1(stimulus_r[144]),
.aluF2(stimulus_r[145]),
.aluF3(stimulus_r[146]),
.aluG1(stimulus_r[147]),
.aluM(stimulus_r[148]),
.aluOut_eq_0_p_(stimulus_r[149] | bank_aluOut_eq_0_p___drv),
.aluP1(stimulus_r[150]),
.dMD_00(stimulus_r[151]),
.dMD_01(stimulus_r[152]),
.dMD_02(stimulus_r[153]),
.dMD_03(stimulus_r[154]),
.dMD_04(stimulus_r[155]),
.dMD_05(stimulus_r[156]),
.dMD_06(stimulus_r[157]),
.dMD_07(stimulus_r[158]),
.dMD_16(stimulus_r[159]),
.ALUCarry__drv(bank_ALUCarry__drv),
.BMux_00__drv(bank_BMux_00__drv),
.BMux_01__drv(bank_BMux_01__drv),
.BMux_02__drv(bank_BMux_02__drv),
.BMux_03__drv(bank_BMux_03__drv),
.BMux_04__drv(bank_BMux_04__drv),
.BMux_05__drv(bank_BMux_05__drv),
.BMux_06__drv(bank_BMux_06__drv),
.BMux_07__drv(bank_BMux_07__drv),
.BMux_16__drv(bank_BMux_16__drv),
.Cnt_eq_Zero_p___drv(bank_Cnt_eq_Zero_p___drv),
.DMuxData__drv(bank_DMuxData__drv),
.FA_eq_0_p___drv(bank_FA_eq_0_p___drv),
.FA_eq_1_p___drv(bank_FA_eq_1_p___drv),
.FF_0mem_p___drv(bank_FF_0mem_p___drv),
.FF_1mem__drv(bank_FF_1mem__drv),
.IOB_00__drv(bank_IOB_00__drv),
.IOB_01__drv(bank_IOB_01__drv),
.IOB_02__drv(bank_IOB_02__drv),
.IOB_03__drv(bank_IOB_03__drv),
.IOB_04__drv(bank_IOB_04__drv),
.IOB_05__drv(bank_IOB_05__drv),
.IOB_06__drv(bank_IOB_06__drv),
.IOB_07__drv(bank_IOB_07__drv),
.IOB_16__drv(bank_IOB_16__drv),
.IOPE__drv(bank_IOPE__drv),
.IOatt__drv(bank_IOatt__drv),
.MAR_00_p___drv(bank_MAR_00_p___drv),
.MAR_01_p___drv(bank_MAR_01_p___drv),
.MAR_02_p___drv(bank_MAR_02_p___drv),
.MAR_03_p___drv(bank_MAR_03_p___drv),
.MAR_04_p___drv(bank_MAR_04_p___drv),
.MAR_05_p___drv(bank_MAR_05_p___drv),
.MAR_06_p___drv(bank_MAR_06_p___drv),
.MAR_07_p___drv(bank_MAR_07_p___drv),
.MdPE__drv(bank_MdPE__drv),
.MemBase_0__drv(bank_MemBase_0__drv),
.MemBase_1__drv(bank_MemBase_1__drv),
.MemBase_2__drv(bank_MemBase_2__drv),
.MemBase_3__drv(bank_MemBase_3__drv),
.MemBase_4__drv(bank_MemBase_4__drv),
.NextData_p___drv(bank_NextData_p___drv),
.Overflow_p___drv(bank_Overflow_p___drv),
.Pdata_15__drv(bank_Pdata_15__drv),
.Q_07__drv(bank_Q_07__drv),
.RamPE__drv(bank_RamPE__drv),
.ResEqZero_p___drv(bank_ResEqZero_p___drv),
.ResLtZero_p___drv(bank_ResLtZero_p___drv),
.RmLtZero_p___drv(bank_RmLtZero_p___drv),
.ShA_00__drv(bank_ShA_00__drv),
.ShA_01__drv(bank_ShA_01__drv),
.ShA_02__drv(bank_ShA_02__drv),
.ShA_03__drv(bank_ShA_03__drv),
.ShA_04__drv(bank_ShA_04__drv),
.ShA_05__drv(bank_ShA_05__drv),
.ShA_06__drv(bank_ShA_06__drv),
.ShA_07__drv(bank_ShA_07__drv),
.Shc_02__drv(bank_Shc_02__drv),
.Shc_03__drv(bank_Shc_03__drv),
.Shc_04b__drv(bank_Shc_04b__drv),
.Shc_05b__drv(bank_Shc_05b__drv),
.Shc_06b__drv(bank_Shc_06b__drv),
.Shc_07b__drv(bank_Shc_07b__drv),
.TIOA_0__drv(bank_TIOA_0__drv),
.TIOA_1__drv(bank_TIOA_1__drv),
.TIOA_2__drv(bank_TIOA_2__drv),
.TIOA_3__drv(bank_TIOA_3__drv),
.TIOA_4__drv(bank_TIOA_4__drv),
.TIOA_5__drv(bank_TIOA_5__drv),
.TIOA_6__drv(bank_TIOA_6__drv),
.TIOA_7__drv(bank_TIOA_7__drv),
.TestTW__drv(bank_TestTW__drv),
.alu_07__drv(bank_alu_07__drv),
.aluCout__drv(bank_aluCout__drv),
.aluOut_eq_0_p___drv(bank_aluOut_eq_0_p___drv)
);
endmodule
