module snapshot_fit(
 input wire host_clk,advance,system_reset,input wire [145:0] stimulus,
 input wire freeze,held,request,write,input wire [15:0] index,
 input wire [17:0] state_data,output reg [95:0] q,
 output reg frozen,done,error,scan_hold_required,scan_fault,output reg [17:0] result);
 // Both processor neighbors sample on positive host edges; full20ns budgets.
 reg [185:0] launch;
 always @(posedge host_clk)
  launch<={system_reset,advance,stimulus,freeze,held,request,write,index,state_data};
 wire system_reset_r,step_r,freeze_r,held_r,request_r,write_r;
 wire [145:0] stimulus_r;wire [15:0] index_r;wire [17:0] state_r;
 assign {system_reset_r,step_r,stimulus_r,freeze_r,held_r,request_r,write_r,index_r,state_r}=launch;
 wire bank_scan_hold,bank_scan_fault,bank_frozen,bank_done,bank_error;wire [17:0] bank_result;
 wire [95:0] bank_q;
 always @(posedge host_clk){q,frozen,done,error,result,scan_hold_required,scan_fault}<={bank_q,bank_frozen,bank_done,bank_error,bank_result,bank_scan_hold,bank_scan_fault};

wire bank_BMux_08__drv;
wire bank_BMux_09__drv;
wire bank_BMux_10__drv;
wire bank_BMux_11__drv;
wire bank_BMux_12__drv;
wire bank_BMux_13__drv;
wire bank_BMux_14__drv;
wire bank_BMux_15__drv;
wire bank_BMux_17__drv;
wire bank_CkMdParity_p___drv;
wire bank_Cnt_eq_Zero_p___drv;
wire bank_DMuxData__drv;
wire bank_FF_eq_030__drv;
wire bank_IOB_08__drv;
wire bank_IOB_09__drv;
wire bank_IOB_10__drv;
wire bank_IOB_11__drv;
wire bank_IOB_12__drv;
wire bank_IOB_13__drv;
wire bank_IOB_14__drv;
wire bank_IOB_15__drv;
wire bank_IOB_17__drv;
wire bank_IOPE__drv;
wire bank_IOin_p___drv;
wire bank_IOout_p___drv;
wire bank_LScopeFH__drv;
wire bank_MAR_08_p___drv;
wire bank_MAR_09_p___drv;
wire bank_MAR_10_p___drv;
wire bank_MAR_11_p___drv;
wire bank_MAR_12_p___drv;
wire bank_MAR_13_p___drv;
wire bank_MAR_14_p___drv;
wire bank_MAR_15_p___drv;
wire bank_MdPE__drv;
wire bank_MemBase_2__drv;
wire bank_MemBase_3__drv;
wire bank_Pdata_15__drv;
wire bank_PrHoldReq__drv;
wire bank_PropCnt_p___drv;
wire bank_Q_08__drv;
wire bank_QBit_p___drv;
wire bank_RScopeClk0_p___drv;
wire bank_RamPE__drv;
wire bank_RbAdr_0__drv;
wire bank_RbAdr_1__drv;
wire bank_RbAdr_2__drv;
wire bank_RbAdr_3__drv;
wire bank_RbBypass__drv;
wire bank_RbBypass_p___drv;
wire bank_RmOdd_p___drv;
wire bank_SelectRm_p_a__drv;
wire bank_SelectStk_p_a__drv;
wire bank_ShA_08__drv;
wire bank_ShA_09__drv;
wire bank_ShA_10__drv;
wire bank_ShA_11__drv;
wire bank_ShA_12__drv;
wire bank_ShA_13__drv;
wire bank_ShA_14__drv;
wire bank_ShA_15__drv;
wire bank_Shc_08__drv;
wire bank_Shc_09__drv;
wire bank_Shc_10__drv;
wire bank_Shc_11__drv;
wire bank_Shc_12__drv;
wire bank_Shc_13__drv;
wire bank_Shc_14__drv;
wire bank_Shc_15__drv;
wire bank_ShcAlu_0__drv;
wire bank_ShcAlu_1__drv;
wire bank_ShcAlu_2__drv;
wire bank_ShcAlu_3__drv;
wire bank_StkAdr_0a__drv;
wire bank_StkAdr_1a__drv;
wire bank_StkAdr_2a__drv;
wire bank_StkAdr_3a__drv;
wire bank_StkAdr_4a__drv;
wire bank_StkAdr_5a__drv;
wire bank_StkAdr_6a__drv;
wire bank_StkAdr_7a__drv;
wire bank_StkError__drv;
wire bank__u_MD__drv;
wire bank__u_MDI__drv;
wire bank__u_MDI_p___drv;
wire bank_alu_08__drv;
wire bank_alu_15__drv;
wire bank_aluC0__drv;
wire bank_aluF0__drv;
wire bank_aluF1__drv;
wire bank_aluF2__drv;
wire bank_aluF3__drv;
wire bank_aluG1__drv;
wire bank_aluM__drv;
wire bank_aluOut_eq_0_p___drv;
wire bank_aluP1__drv;
assign bank_q={bank_aluP1__drv,bank_aluOut_eq_0_p___drv,bank_aluM__drv,bank_aluG1__drv,bank_aluF3__drv,bank_aluF2__drv,bank_aluF1__drv,bank_aluF0__drv,bank_aluC0__drv,bank_alu_15__drv,bank_alu_08__drv,bank__u_MDI_p___drv,bank__u_MDI__drv,bank__u_MD__drv,bank_StkError__drv,bank_StkAdr_7a__drv,bank_StkAdr_6a__drv,bank_StkAdr_5a__drv,bank_StkAdr_4a__drv,bank_StkAdr_3a__drv,bank_StkAdr_2a__drv,bank_StkAdr_1a__drv,bank_StkAdr_0a__drv,bank_ShcAlu_3__drv,bank_ShcAlu_2__drv,bank_ShcAlu_1__drv,bank_ShcAlu_0__drv,bank_Shc_15__drv,bank_Shc_14__drv,bank_Shc_13__drv,bank_Shc_12__drv,bank_Shc_11__drv,bank_Shc_10__drv,bank_Shc_09__drv,bank_Shc_08__drv,bank_ShA_15__drv,bank_ShA_14__drv,bank_ShA_13__drv,bank_ShA_12__drv,bank_ShA_11__drv,bank_ShA_10__drv,bank_ShA_09__drv,bank_ShA_08__drv,bank_SelectStk_p_a__drv,bank_SelectRm_p_a__drv,bank_RmOdd_p___drv,bank_RbBypass_p___drv,bank_RbBypass__drv,bank_RbAdr_3__drv,bank_RbAdr_2__drv,bank_RbAdr_1__drv,bank_RbAdr_0__drv,bank_RamPE__drv,bank_RScopeClk0_p___drv,bank_QBit_p___drv,bank_Q_08__drv,bank_PropCnt_p___drv,bank_PrHoldReq__drv,bank_Pdata_15__drv,bank_MemBase_3__drv,bank_MemBase_2__drv,bank_MdPE__drv,bank_MAR_15_p___drv,bank_MAR_14_p___drv,bank_MAR_13_p___drv,bank_MAR_12_p___drv,bank_MAR_11_p___drv,bank_MAR_10_p___drv,bank_MAR_09_p___drv,bank_MAR_08_p___drv,bank_LScopeFH__drv,bank_IOout_p___drv,bank_IOin_p___drv,bank_IOPE__drv,bank_IOB_17__drv,bank_IOB_15__drv,bank_IOB_14__drv,bank_IOB_13__drv,bank_IOB_12__drv,bank_IOB_11__drv,bank_IOB_10__drv,bank_IOB_09__drv,bank_IOB_08__drv,bank_FF_eq_030__drv,bank_DMuxData__drv,bank_Cnt_eq_Zero_p___drv,bank_CkMdParity_p___drv,bank_BMux_17__drv,bank_BMux_15__drv,bank_BMux_14__drv,bank_BMux_13__drv,bank_BMux_12__drv,bank_BMux_11__drv,bank_BMux_10__drv,bank_BMux_09__drv,bank_BMux_08__drv};
assign {bank_scan_hold,bank_scan_fault}=2'b0;
`ifdef SNAPSHOT_BANK_EXPERIMENT
 ProcL_full_snapshot_experiment #(.SYSPER(4)) bank(
 .state_host_clk(host_clk),.state_guest_advance(step_r),.state_freeze(freeze_r),
 .state_guest_held(held_r),.state_request(request_r),.state_write(write_r),
 .state_index(index_r),.state_data(state_r),.state_frozen(bank_frozen),
 .state_done(bank_done),.state_error(bank_error),.state_result(bank_result),
`else
 assign {bank_frozen,bank_done,bank_error,bank_result}=21'b0;
 ProcL_m_Rev_m_Ci #(.SYSPER(4)) bank(
`endif
.sys_clk(host_clk),
.ALUCarry(stimulus_r[0]),
.ALUF_0(stimulus_r[1]),
.ALUF_1(stimulus_r[2]),
.ALUF_2(stimulus_r[3]),
.ALUF_3(stimulus_r[4]),
.ASEL_0_p_(stimulus_r[5]),
.ASEL_1_p_(stimulus_r[6]),
.ASEL_2_p_(stimulus_r[7]),
.BMux_08(stimulus_r[8] | bank_BMux_08__drv),
.BMux_09(stimulus_r[9] | bank_BMux_09__drv),
.BMux_10(stimulus_r[10] | bank_BMux_10__drv),
.BMux_11(stimulus_r[11] | bank_BMux_11__drv),
.BMux_12(stimulus_r[12] | bank_BMux_12__drv),
.BMux_13(stimulus_r[13] | bank_BMux_13__drv),
.BMux_14(stimulus_r[14] | bank_BMux_14__drv),
.BMux_15(stimulus_r[15] | bank_BMux_15__drv),
.BMux_17(stimulus_r[16] | bank_BMux_17__drv),
.BNTGtCT_p_a(stimulus_r[17]),
.BSEL_0_p_(stimulus_r[18]),
.BSEL_1_p_(stimulus_r[19]),
.BSEL_2_p_(stimulus_r[20]),
.CLK_pl_p_(stimulus_r[21]),
.CLKEnable_p_b(stimulus_r[22]),
.CkMdParity_p_(stimulus_r[23] | bank_CkMdParity_p___drv),
.DMuxClk(stimulus_r[24]),
.DMuxData(stimulus_r[25] | bank_DMuxData__drv),
.FF_0(stimulus_r[26]),
.FF_1(stimulus_r[27]),
.FF_2(stimulus_r[28]),
.FF_3(stimulus_r[29]),
.FF_4(stimulus_r[30]),
.FF_5(stimulus_r[31]),
.FF_6(stimulus_r[32]),
.FF_7(stimulus_r[33]),
.FFok_p_b(stimulus_r[34]),
.Freeze(stimulus_r[35]),
.IOB_08(stimulus_r[36] | bank_IOB_08__drv),
.IOB_09(stimulus_r[37] | bank_IOB_09__drv),
.IOB_10(stimulus_r[38] | bank_IOB_10__drv),
.IOB_11(stimulus_r[39] | bank_IOB_11__drv),
.IOB_12(stimulus_r[40] | bank_IOB_12__drv),
.IOB_13(stimulus_r[41] | bank_IOB_13__drv),
.IOB_14(stimulus_r[42] | bank_IOB_14__drv),
.IOB_15(stimulus_r[43] | bank_IOB_15__drv),
.IOB_17(stimulus_r[44] | bank_IOB_17__drv),
.IOin_p_(stimulus_r[45] | bank_IOin_p___drv),
.IfuData_0(stimulus_r[46]),
.IfuData_1(stimulus_r[47]),
.IfuData_2(stimulus_r[48]),
.IfuData_3(stimulus_r[49]),
.IfuData_4(stimulus_r[50]),
.IfuData_5(stimulus_r[51]),
.IfuData_6(stimulus_r[52]),
.IfuData_7(stimulus_r[53]),
.IfuRBaseSel_p_(stimulus_r[54]),
.LC_0(stimulus_r[55]),
.LC_1(stimulus_r[56]),
.LC_2(stimulus_r[57]),
.MAR_08_p_(stimulus_r[58] | bank_MAR_08_p___drv),
.MAR_09_p_(stimulus_r[59] | bank_MAR_09_p___drv),
.MAR_10_p_(stimulus_r[60] | bank_MAR_10_p___drv),
.MAR_11_p_(stimulus_r[61] | bank_MAR_11_p___drv),
.MAR_12_p_(stimulus_r[62] | bank_MAR_12_p___drv),
.MAR_13_p_(stimulus_r[63] | bank_MAR_13_p___drv),
.MAR_14_p_(stimulus_r[64] | bank_MAR_14_p___drv),
.MAR_15_p_(stimulus_r[65] | bank_MAR_15_p___drv),
.Next_0(stimulus_r[66]),
.Next_1(stimulus_r[67]),
.Next_2(stimulus_r[68]),
.Next_3(stimulus_r[69]),
.NextMacro(stimulus_r[70]),
.PRhold(stimulus_r[71]),
.Pdata_15(stimulus_r[72] | bank_Pdata_15__drv),
.PrBlock_p_(stimulus_r[73]),
.Q_07(stimulus_r[74]),
.Q_08(stimulus_r[75] | bank_Q_08__drv),
.RSTK_0(stimulus_r[76]),
.RSTK_1(stimulus_r[77]),
.RSTK_2(stimulus_r[78]),
.RSTK_3(stimulus_r[79]),
.RbBypass(stimulus_r[80] | bank_RbBypass__drv),
.RbBypass_p_(stimulus_r[81] | bank_RbBypass_p___drv),
.RmOdd_p_(stimulus_r[82] | bank_RmOdd_p___drv),
.ShA_00(stimulus_r[83]),
.ShA_01(stimulus_r[84]),
.ShA_02(stimulus_r[85]),
.ShA_03(stimulus_r[86]),
.ShA_04(stimulus_r[87]),
.ShA_05(stimulus_r[88]),
.ShA_06(stimulus_r[89]),
.ShA_07(stimulus_r[90]),
.ShA_08(stimulus_r[91] | bank_ShA_08__drv),
.ShA_09(stimulus_r[92] | bank_ShA_09__drv),
.ShA_10(stimulus_r[93] | bank_ShA_10__drv),
.ShA_11(stimulus_r[94] | bank_ShA_11__drv),
.ShA_12(stimulus_r[95] | bank_ShA_12__drv),
.ShA_13(stimulus_r[96] | bank_ShA_13__drv),
.ShA_14(stimulus_r[97] | bank_ShA_14__drv),
.ShA_15(stimulus_r[98] | bank_ShA_15__drv),
.Shc_02(stimulus_r[99]),
.Shc_03(stimulus_r[100]),
.Shc_04b(stimulus_r[101]),
.Shc_05b(stimulus_r[102]),
.Shc_06b(stimulus_r[103]),
.Shc_07b(stimulus_r[104]),
.Shc_08(stimulus_r[105] | bank_Shc_08__drv),
.Shc_09(stimulus_r[106] | bank_Shc_09__drv),
.Shc_10(stimulus_r[107] | bank_Shc_10__drv),
.Shc_11(stimulus_r[108] | bank_Shc_11__drv),
.Shc_12(stimulus_r[109] | bank_Shc_12__drv),
.Shc_13(stimulus_r[110] | bank_Shc_13__drv),
.Shc_14(stimulus_r[111] | bank_Shc_14__drv),
.Shc_15(stimulus_r[112] | bank_Shc_15__drv),
.ShcAlu_0(stimulus_r[113] | bank_ShcAlu_0__drv),
.ShcAlu_1(stimulus_r[114] | bank_ShcAlu_1__drv),
.ShcAlu_2(stimulus_r[115] | bank_ShcAlu_2__drv),
.ShcAlu_3(stimulus_r[116] | bank_ShcAlu_3__drv),
.SimHoldDis(stimulus_r[117]),
.StartCycle_p_a(stimulus_r[118]),
.StkError(stimulus_r[119] | bank_StkError__drv),
.SubTask_0(stimulus_r[120]),
.SubTask_1(stimulus_r[121]),
.TempRef(stimulus_r[122]),
._u_MD(stimulus_r[123] | bank__u_MD__drv),
._u_MDI(stimulus_r[124] | bank__u_MDI__drv),
._u_MDI_p_(stimulus_r[125] | bank__u_MDI_p___drv),
.alu_07(stimulus_r[126]),
.alu_08(stimulus_r[127] | bank_alu_08__drv),
.alu_15(stimulus_r[128] | bank_alu_15__drv),
.aluC0(stimulus_r[129] | bank_aluC0__drv),
.aluCout(stimulus_r[130]),
.aluF0(stimulus_r[131] | bank_aluF0__drv),
.aluF1(stimulus_r[132] | bank_aluF1__drv),
.aluF2(stimulus_r[133] | bank_aluF2__drv),
.aluF3(stimulus_r[134] | bank_aluF3__drv),
.aluM(stimulus_r[135] | bank_aluM__drv),
.dMD_08(stimulus_r[136]),
.dMD_09(stimulus_r[137]),
.dMD_10(stimulus_r[138]),
.dMD_11(stimulus_r[139]),
.dMD_12(stimulus_r[140]),
.dMD_13(stimulus_r[141]),
.dMD_14(stimulus_r[142]),
.dMD_15(stimulus_r[143]),
.dMD_17(stimulus_r[144]),
.jcnt(stimulus_r[145]),
.BMux_08__drv(bank_BMux_08__drv),
.BMux_09__drv(bank_BMux_09__drv),
.BMux_10__drv(bank_BMux_10__drv),
.BMux_11__drv(bank_BMux_11__drv),
.BMux_12__drv(bank_BMux_12__drv),
.BMux_13__drv(bank_BMux_13__drv),
.BMux_14__drv(bank_BMux_14__drv),
.BMux_15__drv(bank_BMux_15__drv),
.BMux_17__drv(bank_BMux_17__drv),
.CkMdParity_p___drv(bank_CkMdParity_p___drv),
.Cnt_eq_Zero_p___drv(bank_Cnt_eq_Zero_p___drv),
.DMuxData__drv(bank_DMuxData__drv),
.FF_eq_030__drv(bank_FF_eq_030__drv),
.IOB_08__drv(bank_IOB_08__drv),
.IOB_09__drv(bank_IOB_09__drv),
.IOB_10__drv(bank_IOB_10__drv),
.IOB_11__drv(bank_IOB_11__drv),
.IOB_12__drv(bank_IOB_12__drv),
.IOB_13__drv(bank_IOB_13__drv),
.IOB_14__drv(bank_IOB_14__drv),
.IOB_15__drv(bank_IOB_15__drv),
.IOB_17__drv(bank_IOB_17__drv),
.IOPE__drv(bank_IOPE__drv),
.IOin_p___drv(bank_IOin_p___drv),
.IOout_p___drv(bank_IOout_p___drv),
.LScopeFH__drv(bank_LScopeFH__drv),
.MAR_08_p___drv(bank_MAR_08_p___drv),
.MAR_09_p___drv(bank_MAR_09_p___drv),
.MAR_10_p___drv(bank_MAR_10_p___drv),
.MAR_11_p___drv(bank_MAR_11_p___drv),
.MAR_12_p___drv(bank_MAR_12_p___drv),
.MAR_13_p___drv(bank_MAR_13_p___drv),
.MAR_14_p___drv(bank_MAR_14_p___drv),
.MAR_15_p___drv(bank_MAR_15_p___drv),
.MdPE__drv(bank_MdPE__drv),
.MemBase_2__drv(bank_MemBase_2__drv),
.MemBase_3__drv(bank_MemBase_3__drv),
.Pdata_15__drv(bank_Pdata_15__drv),
.PrHoldReq__drv(bank_PrHoldReq__drv),
.PropCnt_p___drv(bank_PropCnt_p___drv),
.Q_08__drv(bank_Q_08__drv),
.QBit_p___drv(bank_QBit_p___drv),
.RScopeClk0_p___drv(bank_RScopeClk0_p___drv),
.RamPE__drv(bank_RamPE__drv),
.RbAdr_0__drv(bank_RbAdr_0__drv),
.RbAdr_1__drv(bank_RbAdr_1__drv),
.RbAdr_2__drv(bank_RbAdr_2__drv),
.RbAdr_3__drv(bank_RbAdr_3__drv),
.RbBypass__drv(bank_RbBypass__drv),
.RbBypass_p___drv(bank_RbBypass_p___drv),
.RmOdd_p___drv(bank_RmOdd_p___drv),
.SelectRm_p_a__drv(bank_SelectRm_p_a__drv),
.SelectStk_p_a__drv(bank_SelectStk_p_a__drv),
.ShA_08__drv(bank_ShA_08__drv),
.ShA_09__drv(bank_ShA_09__drv),
.ShA_10__drv(bank_ShA_10__drv),
.ShA_11__drv(bank_ShA_11__drv),
.ShA_12__drv(bank_ShA_12__drv),
.ShA_13__drv(bank_ShA_13__drv),
.ShA_14__drv(bank_ShA_14__drv),
.ShA_15__drv(bank_ShA_15__drv),
.Shc_08__drv(bank_Shc_08__drv),
.Shc_09__drv(bank_Shc_09__drv),
.Shc_10__drv(bank_Shc_10__drv),
.Shc_11__drv(bank_Shc_11__drv),
.Shc_12__drv(bank_Shc_12__drv),
.Shc_13__drv(bank_Shc_13__drv),
.Shc_14__drv(bank_Shc_14__drv),
.Shc_15__drv(bank_Shc_15__drv),
.ShcAlu_0__drv(bank_ShcAlu_0__drv),
.ShcAlu_1__drv(bank_ShcAlu_1__drv),
.ShcAlu_2__drv(bank_ShcAlu_2__drv),
.ShcAlu_3__drv(bank_ShcAlu_3__drv),
.StkAdr_0a__drv(bank_StkAdr_0a__drv),
.StkAdr_1a__drv(bank_StkAdr_1a__drv),
.StkAdr_2a__drv(bank_StkAdr_2a__drv),
.StkAdr_3a__drv(bank_StkAdr_3a__drv),
.StkAdr_4a__drv(bank_StkAdr_4a__drv),
.StkAdr_5a__drv(bank_StkAdr_5a__drv),
.StkAdr_6a__drv(bank_StkAdr_6a__drv),
.StkAdr_7a__drv(bank_StkAdr_7a__drv),
.StkError__drv(bank_StkError__drv),
._u_MD__drv(bank__u_MD__drv),
._u_MDI__drv(bank__u_MDI__drv),
._u_MDI_p___drv(bank__u_MDI_p___drv),
.alu_08__drv(bank_alu_08__drv),
.alu_15__drv(bank_alu_15__drv),
.aluC0__drv(bank_aluC0__drv),
.aluF0__drv(bank_aluF0__drv),
.aluF1__drv(bank_aluF1__drv),
.aluF2__drv(bank_aluF2__drv),
.aluF3__drv(bank_aluF3__drv),
.aluG1__drv(bank_aluG1__drv),
.aluM__drv(bank_aluM__drv),
.aluOut_eq_0_p___drv(bank_aluOut_eq_0_p___drv),
.aluP1__drv(bank_aluP1__drv)
);
endmodule
